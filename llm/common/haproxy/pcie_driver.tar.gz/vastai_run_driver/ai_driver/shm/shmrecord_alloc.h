#ifndef __SHMRECORD_ALLOC_H__
#define __SHMRECORD_ALLOC_H__

#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include "vastai_pci.h"

#define rt_align(d, a)       ((a > 0) ? (((d) + (((__typeof__(d))a) - 1)) & ~(((__typeof__(d))a) - 1)) : (d))
#define rt_align_down(d, a)  ((a > 0) ? ((d) & ~(((__typeof__(d))a) - 1)) : (d))
#define rt_boundary(d, b, a) ((d < b) ? (rt_align(d + 1, a) == rt_align(b, a)) : (rt_align(d, a) == rt_align(b + 1, a)))

#define SHM_INUSE_BITS    0x01
#define is_inuse(size)    ((size) & (__typeof__(size))(SHM_INUSE_BITS))
#define set_inuse(size)   ((size) |= (__typeof__(size))(SHM_INUSE_BITS))
#define clear_inuse(size) ((size) &= ~(__typeof__(size))(SHM_INUSE_BITS))
#define get_size(size)    ((size) & ~(__typeof__(size))(SHM_INUSE_BITS))
#define MEM_ALIGN         sizeof(size_t)

#define SHMRE_ALLOCATOR(name)                          \
    shmre_allocator_t name = {                         \
            .shmallocator.shm_base = NULL,             \
            .shmallocator.shmalloc_head = NULL,        \
            .shmallocator.malloc = shm_alloc,          \
            .shmallocator.malloc_off = shm_alloc_off,  \
            .shmallocator.free = shm_free,             \
            .shmallocator.free_off = shm_free_off,     \
            .shmallocator.memcpy = shm_memcpy,         \
            .shmallocator.memcpy_off = shm_memcpy_off, \
            .shmallocator.memset = shm_memset,         \
            .shmallocator.memset_off = shm_memset_off, \
            .shmallocator.off2ptr = shm_off2ptr,       \
            .shmallocator.ptr2off = shm_ptr2off,       \
            .check_memory = 0,                         \
            .shmre_alloc_head = NULL,                  \
            .malloc = shmre_alloc,                     \
            .free = shmre_free,                        \
            .chunk2ptr = shmre_chunk2ptr,              \
            .chunk2addr = shmre_chunk2addr,            \
    }

#define VASTAI_ZONE_MAX_NUM 4

typedef struct shmre_alloc_chunk {
    size_t size; // bit 0:1 used
    size_t data;
    uint8_t bank_id : 8;
    uint64_t : 56;
    struct list_head node;
    struct list_head node_free;
    struct list_head node_owner; // process or model
} shmre_alloc_chunk_t;

typedef struct shmre_alloc_bank {
    size_t base; // soc address, shm record allocator address
    size_t data; // available base
    size_t size; // available size
    size_t total_size;
} shmre_alloc_bank_t;

typedef struct shmre_alloc_head {
    uint8_t bank_num : 8;
    uint64_t : 56;
    shmre_alloc_bank_t bank[VASTAI_ZONE_MAX_NUM];
    size_t free_size;
    size_t total_size; // share memory record device memory size
    uint32_t align; // malloc size align
    uint32_t : 32;
    struct mutex mutex;
    struct list_head head;
    struct list_head head_free;
} shmre_alloc_head_t;

typedef struct shmre_allocator {
    uint32_t check_memory; // check memory flag
    // used malloc and free
    // shmallocator_t shmallocator; 
    shmre_alloc_head_t shmre_alloc_head;
    // allocate a memory block
    shmre_alloc_chunk_t *(*malloc)(struct shmre_allocator *allocator, size_t size, size_t bound, size_t head);
    // allocate a memory block, confine to the boundary
    // shmre_alloc_chunk_t *(*malloc_boundary)(struct shmre_allocator *allocator, size_t size, size_t bound);
    // allocate a memory block, start with align head
    // shmre_alloc_chunk_t *(*malloc_align)(struct shmre_allocator *allocator, size_t size, size_t head, size_t bound);
    // free the allocated memory(shmre_alloc_chunk_t)
    void (*free)(struct shmre_allocator *allocator, shmre_alloc_chunk_t *chunk);
    void *(*chunk2ptr)(const shmre_alloc_chunk_t *chunk);
    size_t (*chunk2addr)(const shmre_alloc_chunk_t *chunk);
    void (*free_shm)(struct shmre_allocator *allocator);
} shmre_allocator_t;

// allocate a memory block
shmre_alloc_chunk_t *shmre_alloc(shmre_allocator_t *allocator, size_t size, size_t bound, size_t head);

// allocate a memory block, confine to the boundary
// shmre_alloc_chunk_t *shmre_alloc_boundary(shmre_allocator_t *allocator, size_t size, size_t bound);

// allocate a memory block, start with align head
// shmre_alloc_chunk_t *shmre_alloc_align(shmre_allocator_t *allocator, size_t size, size_t head, size_t bound);

// free the allocated memory(shmre_alloc_chunk_t)
void shmre_free(shmre_allocator_t *allocator, shmre_alloc_chunk_t *chunk);

void shmre_free_shm(shmre_allocator_t *allocator);

static inline void *shmre_chunk2ptr(const shmre_alloc_chunk_t *chunk)
{
    // assert(chunk);
    return (void *)chunk->data;
}

static inline size_t shmre_chunk2addr(const shmre_alloc_chunk_t *chunk)
{
    // assert(chunk);
    return chunk->data;
}

static inline void INIT_SHMRE_ALLOCATOR(shmre_allocator_t *allocator)
{
    // INIT_SHM_ALLOCATOR(&allocator->shmallocator);
    // allocator->shmre_alloc_head = NULL;
    allocator->malloc = shmre_alloc;
    // allocator->malloc_boundary = shmre_alloc_boundary;
    // allocator->malloc_align = shmre_alloc_align;
    allocator->free = shmre_free;
    allocator->chunk2ptr = shmre_chunk2ptr;
    allocator->chunk2addr = shmre_chunk2addr;
    allocator->free_shm = shmre_free_shm;
    #if 0
    char *memory_check = getenv("VACC_RT_MEMORY_CHECK_EN");
    if (memory_check) {
        allocator->check_memory = 1;
    } else {
        allocator->check_memory = 0;
    }
    #else
    allocator->check_memory = 0;
    #endif
}

static inline void shmre_alloc_head_init(shmre_alloc_head_t *self, uint8_t bank_num, size_t *base,
                                         size_t *total_size, uint32_t align)
{
    uint32_t i = 0;

    self->bank_num = bank_num;
    self->align = align;
    self->total_size = 0;
    for (i = 0; i < bank_num; i++) {
        self->bank[i].base = *base;
        self->bank[i].total_size = *total_size;
        self->total_size += *total_size;
        base++;
        total_size++;
    }
    self->free_size = self->total_size;

    mutex_init(&self->mutex);
    INIT_LIST_HEAD(&self->head);
    INIT_LIST_HEAD(&self->head_free);
}

void _shmre_print_memroy_info(shmre_allocator_t *allocator);

#endif /* __SHMRECORD_ALLOC_H__ */