#include "shmrecord_alloc.h"

#define SHM_HEAD_SIZE rt_align(sizeof(shmre_alloc_head_t), MEM_ALIGN)
#define SHM_NODE_SIZE rt_align(sizeof(shmre_alloc_chunk_t), MEM_ALIGN)

static inline int vaccrt_list_is_first(const struct list_head *list,
				       const struct list_head *head)
{
	return list->prev == head;
}

static bool _shmre_chunk_safe_check(shmre_alloc_head_t *shmre_alloc_head, shmre_alloc_chunk_t *shmre_alloc_chunk)
{
    bool check_passed = true;
    shmre_alloc_chunk_t *shmre_alloc_chunk_prev = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk_next = NULL;

    // can not malloc memory, return false
    if (shmre_alloc_chunk == NULL) {
        return false;
    }

    if (likely(!list_empty(&shmre_alloc_head->head))) {
        if (likely(!vaccrt_list_is_first(&shmre_alloc_chunk->node, &shmre_alloc_head->head)))
            shmre_alloc_chunk_prev = (shmre_alloc_chunk_t *)list_prev_entry(shmre_alloc_chunk, node);
        if (shmre_alloc_chunk_prev && shmre_alloc_chunk_prev->bank_id != shmre_alloc_chunk->bank_id)
            shmre_alloc_chunk_prev = NULL;

        if (likely(!list_is_last(&shmre_alloc_chunk->node, &shmre_alloc_head->head)))
            shmre_alloc_chunk_next = (shmre_alloc_chunk_t *)list_next_entry(shmre_alloc_chunk, node);
        if (shmre_alloc_chunk_next && shmre_alloc_chunk_next->bank_id != shmre_alloc_chunk->bank_id)
            shmre_alloc_chunk_next = NULL;

        if (likely(shmre_alloc_chunk_prev != NULL && shmre_alloc_chunk_next != NULL)) {
            if (unlikely(((shmre_alloc_chunk->data + get_size(shmre_alloc_chunk->size)) !=
                          shmre_alloc_chunk_next->data) ||
                         ((shmre_alloc_chunk_prev->data + get_size(shmre_alloc_chunk_prev->size)) !=
                          shmre_alloc_chunk->data))) {
                check_passed = false;
            }
        } else if (shmre_alloc_chunk_prev == NULL && shmre_alloc_chunk_next != NULL) {
            if (unlikely((shmre_alloc_head->bank[shmre_alloc_chunk->bank_id].data != shmre_alloc_chunk->data) ||
                         (shmre_alloc_chunk->data + get_size(shmre_alloc_chunk->size)) !=
                                 shmre_alloc_chunk_next->data)) {
                check_passed = false;
            }
        } else if (shmre_alloc_chunk_next == NULL && shmre_alloc_chunk_prev != NULL) {
            if (unlikely(((shmre_alloc_chunk_prev->data + get_size(shmre_alloc_chunk_prev->size)) !=
                          shmre_alloc_chunk->data) ||
                         ((shmre_alloc_head->bank[shmre_alloc_chunk->bank_id].data +
                           shmre_alloc_head->bank[shmre_alloc_chunk->bank_id].size) !=
                          (shmre_alloc_chunk->data + get_size(shmre_alloc_chunk->size))))) {
                check_passed = false;
            }
        } else {
            if (unlikely((shmre_alloc_head->bank[shmre_alloc_chunk->bank_id].data != shmre_alloc_chunk->data) ||
                         (shmre_alloc_head->bank[shmre_alloc_chunk->bank_id].size !=
                          get_size(shmre_alloc_chunk->size)))) {
                check_passed = false;
            }
        }
    }
    return check_passed;
}

static void print_chunk_addr_and_size(shmre_alloc_head_t *shmre_alloc_head)
{
    shmre_alloc_chunk_t *shmre_alloc_chunk_c = NULL;

    if (likely(!list_empty(&shmre_alloc_head->head))) {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "start print_chunk_addr_and_size .\n");
        list_for_each_entry(shmre_alloc_chunk_c, &shmre_alloc_head->head, node)
        {
            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk data: 0x%zx, size: 0x%zx, data + size addr: 0x%zx, inuse:%zu\n",
                           shmre_alloc_chunk_c->data, get_size(shmre_alloc_chunk_c->size),
                           (shmre_alloc_chunk_c->data + get_size(shmre_alloc_chunk_c->size)),
                           is_inuse(shmre_alloc_chunk_c->size));
        }
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "end print_chunk_addr_and_size.\n");
    }
}

static void _shmre_insert(shmre_allocator_t *allocator, shmre_alloc_chunk_t *chunk)
{
    shmre_alloc_head_t *shmre_alloc_head = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;

    shmre_alloc_head = &allocator->shmre_alloc_head;

    if (likely(!list_empty(&shmre_alloc_head->head_free))) {
        list_for_each_entry(shmre_alloc_chunk, &shmre_alloc_head->head_free, node_free)
        {
            if (chunk->size <= shmre_alloc_chunk->size) {
                list_add_tail(&chunk->node_free, &shmre_alloc_chunk->node_free);
                break;
            }

            if (unlikely(list_is_last(&shmre_alloc_chunk->node_free, &shmre_alloc_head->head_free))) {
                list_add(&chunk->node_free, &shmre_alloc_chunk->node_free);
                break;
            }
        }
    } else {
        list_add(&chunk->node_free, &shmre_alloc_head->head_free);
    }
}

static bool _shmre_chunk_align_split(shmre_allocator_t *allocator, shmre_alloc_chunk_t **shmre_alloc_chunk,
                                     size_t alloc_size, size_t align_head, size_t data_temp)
{
    // assert(allocator);
    size_t size_temp = 0;
    shmre_alloc_chunk_t *shmre_alloc_chunk_new = NULL;
    shmre_alloc_head_t *shmre_alloc_head = &allocator->shmre_alloc_head;
    // assert(shmre_alloc_head);
    // shmallocator_t *shmallocator = &allocator->shmallocator;
    // assert(shmallocator);

    shmre_alloc_chunk_t *shmre_alloc_chunk_temp = *shmre_alloc_chunk;
    // assert(shmre_alloc_chunk_temp);

    list_del(&shmre_alloc_chunk_temp->node_free);
    if (data_temp > shmre_alloc_chunk_temp->data) {
        #if 0
        shmre_alloc_chunk_new = (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
        assert(shmre_alloc_chunk_new);
        #else
        shmre_alloc_chunk_new =
            (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
        if (unlikely(!shmre_alloc_chunk_new)) {
            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
                "shmre_alloc_chunk kzalloc failed.\n");
            return false;
        }
        #endif

        shmre_alloc_chunk_new->data = shmre_alloc_chunk_temp->data;
        shmre_alloc_chunk_new->size = data_temp - shmre_alloc_chunk_temp->data;
        shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk_temp->bank_id;
        list_add_tail(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk_temp->node);
        _shmre_insert(allocator, shmre_alloc_chunk_new);

        shmre_alloc_chunk_temp->size = shmre_alloc_chunk_temp->data + shmre_alloc_chunk_temp->size - data_temp;
        shmre_alloc_chunk_temp->data = data_temp;
    }

    size_temp = shmre_alloc_chunk_temp->data + shmre_alloc_chunk_temp->size - data_temp;
    if (size_temp >= alloc_size + shmre_alloc_head->align) {
        #if 0
        shmre_alloc_chunk_new = (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
        assert(shmre_alloc_chunk_new);
        #else
        shmre_alloc_chunk_new =
            (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
        if (unlikely(!shmre_alloc_chunk_new)) {
            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
                "shmre_alloc_chunk kzalloc failed.\n");
            return false;
        }
        #endif

        shmre_alloc_chunk_new->data = data_temp;
        shmre_alloc_chunk_new->size = alloc_size;
        shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk_temp->bank_id;
        list_add_tail(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk_temp->node);

        shmre_alloc_chunk_temp->data = data_temp + alloc_size;
        shmre_alloc_chunk_temp->size = size_temp - alloc_size;
        _shmre_insert(allocator, shmre_alloc_chunk_temp);

        *shmre_alloc_chunk = shmre_alloc_chunk_new;
    }

    return true;
}

static shmre_alloc_chunk_t *_shmre_alloc_boundary(shmre_allocator_t *allocator, size_t size, size_t bound, size_t head)
{
    // int ret = 0;
    // void *shm_base = NULL;
    size_t alloc_size = 0;
    // shmallocator_t *shmallocator = NULL;
    shmre_alloc_head_t *shmre_alloc_head = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk_new = NULL;
    size_t align_head = head;
    size_t boundary = bound;
    uint32_t i = 0;
    size_t data_temp = 0, size_temp = 0;

    // assert(size > 0);
    // assert(allocator);
    shmre_alloc_head = &allocator->shmre_alloc_head;
    // assert(shmre_alloc_head);
    // shmallocator = &allocator->shmallocator;
    // assert(shmallocator);
    // shm_base = shmallocator->shm_base;
    // assert(shm_base);

    // size_t align_head = head;

    // size_t boundary = bound;
    // size_t boundary = rt_align_down(bound, shmre_alloc_head->align);
    if (boundary && size > boundary) {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc allocate size > boundary\n");
        goto out;
    }

    mutex_lock(&shmre_alloc_head->mutex);

    // init
    if (unlikely(list_empty(&shmre_alloc_head->head))) {
        shmre_alloc_head->total_size = 0;
        // uint32_t i = 0;
        for (i = 0; i < shmre_alloc_head->bank_num; i++) {
            // assert(shmre_alloc_head->total_size > MEM_ALIGN + SHM_MAGIC_SIZE + SHM_HEAD_SIZE + SHM_NODE_SIZE);
            // INIT_SHM_LIST_HEAD(&shmre_alloc_head->head, shm_base);
            // INIT_SHM_LIST_HEAD(&shmre_alloc_head->head_free, shm_base);
            shmre_alloc_head->bank[i].data = rt_align(shmre_alloc_head->bank[i].base, shmre_alloc_head->align);
            if (unlikely(rt_align_down(shmre_alloc_head->bank[i].base + shmre_alloc_head->bank[i].total_size,
                                       shmre_alloc_head->align) <=
                         shmre_alloc_head->bank[i].data + shmre_alloc_head->align)) {
                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_head total memory too small\n");
                goto unlock;
            }
            shmre_alloc_head->bank[i].size =
                    rt_align_down(shmre_alloc_head->bank[i].base + shmre_alloc_head->bank[i].total_size,
                                  shmre_alloc_head->align) -
                    shmre_alloc_head->bank[i].data;
            shmre_alloc_head->total_size += shmre_alloc_head->bank[i].total_size;

            #if 0
            shmre_alloc_chunk = (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
            if (unlikely(!shmre_alloc_chunk)) {
                VART_LOG_ERROR("shmre_alloc_chunk is not find");
                goto unlock;
            }
            #else
            shmre_alloc_chunk = (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
            if (unlikely(!shmre_alloc_chunk)) {
                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk is not find\n");
                goto unlock;
            }
            #endif
            // memset(shmre_alloc_chunk, 0, sizeof(shmre_alloc_chunk_t));
            // INIT_SHM_LIST_HEAD(&shmre_alloc_chunk->node, shmre_alloc_head);
            // INIT_SHM_LIST_HEAD(&shmre_alloc_chunk->node_free, shmre_alloc_head);
            shmre_alloc_chunk->data = shmre_alloc_head->bank[i].data;
            shmre_alloc_chunk->size = shmre_alloc_head->bank[i].size;
            shmre_alloc_chunk->bank_id = i;

            // printk("%s: 001: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__, shmre_alloc_chunk->data,
            //        shmre_alloc_chunk->size, shmre_alloc_chunk->bank_id);
            list_add(&shmre_alloc_chunk->node, &shmre_alloc_head->head);
            _shmre_insert(allocator, shmre_alloc_chunk);
        }
        shmre_alloc_head->free_size = shmre_alloc_head->total_size;
    }

    // allocate
    alloc_size = rt_align(size, shmre_alloc_head->align);
    // assert(alloc_size);
    if (likely(!list_empty(&shmre_alloc_head->head_free))) {
        list_for_each_entry(shmre_alloc_chunk, &shmre_alloc_head->head_free, node_free)
        {
            if (shmre_alloc_chunk->size >= alloc_size) {
                if (!boundary) {
                    if (align_head) {
                        size_t data_temp = rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size,
                                                         align_head);

                        if (data_temp >= shmre_alloc_chunk->data) {
                            #if 0
                            list_del(&shmre_alloc_chunk->node_free);

                            if (data_temp > shmre_alloc_chunk->data) {
                                #if 0
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                #else
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                if (unlikely(!shmre_alloc_chunk_new)) {
                                    VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                }
                                #endif

                                shmre_alloc_chunk_new->data = shmre_alloc_chunk->data;
                                shmre_alloc_chunk_new->size = data_temp - shmre_alloc_chunk->data;
                                shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                list_add_tail(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                                // printk("%s: 002: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                                //        shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                                //        shmre_alloc_chunk_new->bank_id);
                                _shmre_insert(allocator, shmre_alloc_chunk_new);

                                shmre_alloc_chunk->size = shmre_alloc_chunk->data + shmre_alloc_chunk->size - data_temp;
                                shmre_alloc_chunk->data = data_temp;
                            }

                            size_temp = shmre_alloc_chunk->data + shmre_alloc_chunk->size - data_temp;
                            if (size_temp >= alloc_size + shmre_alloc_head->align) {
                                #if 0
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                #else
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                if (unlikely(!shmre_alloc_chunk_new)) {
                                    VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                }
                                #endif

                                shmre_alloc_chunk_new->data = data_temp;
                                shmre_alloc_chunk_new->size = alloc_size;
                                shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                list_add_tail(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                                // printk("%s: 003: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                                //        shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                                //        shmre_alloc_chunk_new->bank_id);

                                shmre_alloc_chunk->data = data_temp + alloc_size;
                                shmre_alloc_chunk->size = size_temp - alloc_size;
                                _shmre_insert(allocator, shmre_alloc_chunk);

                                shmre_alloc_chunk = shmre_alloc_chunk_new;
                            }
                            #else
                            if (!_shmre_chunk_align_split(allocator, &shmre_alloc_chunk, alloc_size, align_head, data_temp)) {
                                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_chunk_align_split failed\n");
                                shmre_alloc_chunk = NULL;
                                goto unlock;
                            }
                            #endif

                            if (unlikely(shmre_alloc_head->free_size < shmre_alloc_chunk->size)) {
                                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc free_size calculation mistake\n");
                                shmre_alloc_chunk = NULL;
                                goto unlock;
                            }

                            shmre_alloc_head->free_size -= shmre_alloc_chunk->size;
                            set_inuse(shmre_alloc_chunk->size);
                            goto unlock;
                        }
                    } else {
                        list_del(&shmre_alloc_chunk->node_free);
                        if (shmre_alloc_chunk->size >= alloc_size + shmre_alloc_head->align) {
                            #if 0
                            shmre_alloc_chunk_new =
                                    (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                            assert(shmre_alloc_chunk_new);
                            #else
                            shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                            if (unlikely(!shmre_alloc_chunk_new)) {
                                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                shmre_alloc_chunk = NULL;
                                goto unlock;
                            }
                            #endif
                            shmre_alloc_chunk_new->data =
                                    shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size;
                            shmre_alloc_chunk_new->size = alloc_size;
                            shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                            list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                            // printk("%s: 004: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                            //            shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                            //            shmre_alloc_chunk_new->bank_id);
                            // shmre_alloc_chunk->data += alloc_size;
                            shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                            _shmre_insert(allocator, shmre_alloc_chunk);
                            //  note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                            shmre_alloc_chunk = shmre_alloc_chunk_new;
                        }
                        if (unlikely(shmre_alloc_head->free_size < shmre_alloc_chunk->size)) {
                            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc free_size calculation mistake\n");
                            shmre_alloc_chunk = NULL;
                            goto unlock;
                        }
                        shmre_alloc_head->free_size -= shmre_alloc_chunk->size;
                        set_inuse(shmre_alloc_chunk->size);
                        // INIT_SHM_LIST_HEAD(&shmre_alloc_chunk->node_owner, shm_base);

                        goto unlock;
                    }
                } else {
                    #if 0
                    if (shmre_alloc_chunk->size < alloc_size + shmre_alloc_head->align) {
                        // note: alloc_size <= shmre_alloc_chunk->size
                        if (rt_boundary(shmre_alloc_chunk->data, shmre_alloc_chunk->data + alloc_size, boundary)) {
                            list_del(&shmre_alloc_chunk->node_free);
                            goto alloca_out;
                        }
                    } else {
                        // note: alloc_size <= shmre_alloc_chunk->size
                        if (rt_boundary(shmre_alloc_chunk->data + shmre_alloc_chunk->size,
                                        shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size, boundary)) {
                            list_del(&shmre_alloc_chunk->node_free);
                            #if 0
                            shmre_alloc_chunk_new =
                                    (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                            assert(shmre_alloc_chunk_new);
                            #else
                            shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                            if (unlikely(!shmre_alloc_chunk_new)) {
                                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                            }
                            #endif
                            shmre_alloc_chunk_new->data =
                                    shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size;
                            shmre_alloc_chunk_new->size = alloc_size;
                            shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                            list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                            // printk("%s: 005: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                            //            shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                            //            shmre_alloc_chunk_new->bank_id);
                            // shmre_alloc_chunk->data += alloc_size;
                            shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                            // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                            _shmre_insert(allocator, shmre_alloc_chunk);
                            shmre_alloc_chunk = shmre_alloc_chunk_new;
                            goto alloca_out;
                        }
                        /*
                         else if (rt_align_down(shmre_alloc_chunk->data, boundary) ==
                                   rt_align_down(shmre_alloc_chunk->data + alloc_size, boundary)) {
                            shmre_alloc_chunk_new =
                                    (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                            assert(shmre_alloc_chunk_new);
                            shmre_alloc_chunk_new->data = shmre_alloc_chunk->data + alloc_size;
                            shmre_alloc_chunk_new->size = shmre_alloc_chunk->size - alloc_size;
                            shm_list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node, shm_base);
                            shm_list_add(&shmre_alloc_chunk_new->node_free, &shmre_alloc_chunk->node_free, shm_base);
                            // shmre_alloc_chunk->data += alloc_size;
                            shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                            shm_list_del(&shmre_alloc_chunk->node_free, shm_base);
                            // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                            // shmre_alloc_chunk = shmre_alloc_chunk_new;
                            goto alloca_out;
                        }
                        */
                        // note: rt_align_down size maybe < alloc_size
                        else if (rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size, boundary) >=
                                 alloc_size + shmre_alloc_chunk->data) {
                            list_del(&shmre_alloc_chunk->node_free);
                            data_temp =
                                    rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size, boundary) -
                                    alloc_size;
                            size_temp = shmre_alloc_chunk->data + shmre_alloc_chunk->size - data_temp;
                            if (size_temp >= alloc_size + shmre_alloc_head->align) {
                                #if 0
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                #else
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                if (unlikely(!shmre_alloc_chunk_new)) {
                                    VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                }
                                #endif
                                shmre_alloc_chunk_new->data = data_temp + alloc_size;
                                shmre_alloc_chunk_new->size =
                                        shmre_alloc_chunk->data + shmre_alloc_chunk->size - shmre_alloc_chunk_new->data;
                                shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                                // printk("%s: 006: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                                //        shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                                //        shmre_alloc_chunk_new->bank_id);
                                // shm_list_add(&shmre_alloc_chunk_new->node_free, &shmre_alloc_chunk->node_free,
                                //              shm_base);
                                _shmre_insert(allocator, shmre_alloc_chunk_new);
                                size_temp = alloc_size;
                            }
                            if (shmre_alloc_chunk->data != data_temp) {
                                #if 0
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                #else
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                if (unlikely(!shmre_alloc_chunk_new)) {
                                    VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                }
                                #endif
                                shmre_alloc_chunk_new->data = data_temp;
                                shmre_alloc_chunk_new->size = size_temp;
                                shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);

                                // printk("%s: 007: alloc_chunk: data = %lx, size = %lx, bank_id = %d\n", __func__,
                                //        shmre_alloc_chunk_new->data, shmre_alloc_chunk_new->size,
                                //        shmre_alloc_chunk_new->bank_id);
                                // shmre_alloc_chunk->data += alloc_size;
                                shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                                // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                                _shmre_insert(allocator, shmre_alloc_chunk);
                                shmre_alloc_chunk = shmre_alloc_chunk_new;
                            } else {
                                shmre_alloc_chunk->size = size_temp;
                                // shm_list_del(&shmre_alloc_chunk->node_free, shm_base);
                            }
                            goto alloca_out;
                        }
                    }
                    #else
                    if (align_head) {
                        size_t data_temp = rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size,
                                                         align_head);
                        while (true) {
                            if (data_temp >= shmre_alloc_chunk->data) {
                                if (rt_boundary(data_temp, data_temp + alloc_size, boundary)) {
                                    if (!_shmre_chunk_align_split(allocator, &shmre_alloc_chunk, alloc_size, align_head,
                                                             data_temp)) {
                                        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_chunk_align_split failed\n");
                                        shmre_alloc_chunk = NULL;
                                        goto unlock;
                                    }

                                    if (unlikely(shmre_alloc_head->free_size < shmre_alloc_chunk->size)) {
                                        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc free_size calculation mistake.\n");
                                        shmre_alloc_chunk = NULL;
                                        goto unlock;
                                    }

                                    shmre_alloc_head->free_size -= shmre_alloc_chunk->size;
                                    set_inuse(shmre_alloc_chunk->size);
                                    goto unlock;
                                }

                                data_temp -= align_head;
                            } else {
                                break;
                            }
                        }
                    } else {
                        if (shmre_alloc_chunk->size < alloc_size + shmre_alloc_head->align) {
                            // note: alloc_size <= shmre_alloc_chunk->size
                            if (rt_boundary(shmre_alloc_chunk->data, shmre_alloc_chunk->data + alloc_size, boundary)) {
                                list_del(&shmre_alloc_chunk->node_free);
                                goto alloca_out;
                            }
                        } else {
                            // note: alloc_size <= shmre_alloc_chunk->size
                            if (rt_boundary(shmre_alloc_chunk->data + shmre_alloc_chunk->size,
                                            shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size, boundary)) {
                                list_del(&shmre_alloc_chunk->node_free);
                                #if 0
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                #else
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                if (unlikely(!shmre_alloc_chunk_new)) {
                                    VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                    shmre_alloc_chunk = NULL;
                                    goto unlock;
                                }
                                #endif

                                shmre_alloc_chunk_new->data =
                                        shmre_alloc_chunk->data + shmre_alloc_chunk->size - alloc_size;
                                shmre_alloc_chunk_new->size = alloc_size;
                                shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);
                                // shmre_alloc_chunk->data += alloc_size;
                                shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                                // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                                _shmre_insert(allocator, shmre_alloc_chunk);
                                shmre_alloc_chunk = shmre_alloc_chunk_new;
                                goto alloca_out;
                            }
                            /*
                            else if (rt_align_down(shmre_alloc_chunk->data, boundary) ==
                                    rt_align_down(shmre_alloc_chunk->data + alloc_size, boundary)) {
                                shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                assert(shmre_alloc_chunk_new);
                                shmre_alloc_chunk_new->data = shmre_alloc_chunk->data + alloc_size;
                                shmre_alloc_chunk_new->size = shmre_alloc_chunk->size - alloc_size;
                                shm_list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node, shm_base);
                                shm_list_add(&shmre_alloc_chunk_new->node_free, &shmre_alloc_chunk->node_free, shm_base);
                                // shmre_alloc_chunk->data += alloc_size;
                                shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                                shm_list_del(&shmre_alloc_chunk->node_free, shm_base);
                                // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                                // shmre_alloc_chunk = shmre_alloc_chunk_new;
                                goto alloca_out;
                            }
                            */
                            // note: rt_align_down size maybe < alloc_size
                            else if (rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size, boundary) >=
                                    alloc_size + shmre_alloc_chunk->data) {
                                list_del(&shmre_alloc_chunk->node_free);
                                data_temp =
                                        rt_align_down(shmre_alloc_chunk->data + shmre_alloc_chunk->size, boundary) -
                                        alloc_size;
                                size_temp = shmre_alloc_chunk->data + shmre_alloc_chunk->size - data_temp;
                                if (size_temp >= alloc_size + shmre_alloc_head->align) {
                                    #if 0
                                    shmre_alloc_chunk_new =
                                            (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                    assert(shmre_alloc_chunk_new);
                                    #else
                                    shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                    if (unlikely(!shmre_alloc_chunk_new)) {
                                        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                        shmre_alloc_chunk = NULL;
                                        goto unlock;
                                    }
                                    #endif
                                    shmre_alloc_chunk_new->data = data_temp + alloc_size;
                                    shmre_alloc_chunk_new->size =
                                            shmre_alloc_chunk->data + shmre_alloc_chunk->size - shmre_alloc_chunk_new->data;
                                    shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                    list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);
                                    // shm_list_add(&shmre_alloc_chunk_new->node_free, &shmre_alloc_chunk->node_free,
                                    //              shm_base);
                                    _shmre_insert(allocator, shmre_alloc_chunk_new);
                                    size_temp = alloc_size;
                                }
                                if (shmre_alloc_chunk->data != data_temp) {
                                    #if 0
                                    shmre_alloc_chunk_new =
                                            (shmre_alloc_chunk_t *)shmallocator->malloc(shmallocator, SHM_NODE_SIZE);
                                    assert(shmre_alloc_chunk_new);
                                    #else
                                    shmre_alloc_chunk_new =
                                        (shmre_alloc_chunk_t *)kzalloc(SHM_NODE_SIZE, GFP_KERNEL);
                                    if (unlikely(!shmre_alloc_chunk_new)) {
                                        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc_chunk kzalloc failed.\n");
                                        shmre_alloc_chunk = NULL;
                                        goto unlock;
                                    }
                                    #endif
                                    shmre_alloc_chunk_new->data = data_temp;
                                    shmre_alloc_chunk_new->size = size_temp;
                                    shmre_alloc_chunk_new->bank_id = shmre_alloc_chunk->bank_id;
                                    list_add(&shmre_alloc_chunk_new->node, &shmre_alloc_chunk->node);
                                    // shmre_alloc_chunk->data += alloc_size;
                                    shmre_alloc_chunk->size = shmre_alloc_chunk_new->data - shmre_alloc_chunk->data;
                                    // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
                                    _shmre_insert(allocator, shmre_alloc_chunk);
                                    shmre_alloc_chunk = shmre_alloc_chunk_new;
                                } else {
                                    shmre_alloc_chunk->size = size_temp;
                                    // shm_list_del(&shmre_alloc_chunk->node_free, shm_base);
                                }
                                goto alloca_out;
                            }
                        }
                    }
                    #endif
                    
                    continue;

                alloca_out:
                    if (unlikely(shmre_alloc_head->free_size < shmre_alloc_chunk->size)) {
                        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc free_size calculation mistake\n");
                        shmre_alloc_chunk = NULL;
                        goto unlock;
                    }
                    shmre_alloc_head->free_size -= shmre_alloc_chunk->size;
                    set_inuse(shmre_alloc_chunk->size);
                    // INIT_SHM_LIST_HEAD(&shmre_alloc_chunk->node_owner, shm_base);

                    goto unlock;
                }
            }
        }
    }
    shmre_alloc_chunk = NULL;
    // VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc no free chunk to allocate\n");

unlock:
    if (allocator->check_memory) {
        if (!_shmre_chunk_safe_check(shmre_alloc_head, shmre_alloc_chunk)) {
            print_chunk_addr_and_size(shmre_alloc_head);
        }
    }
    mutex_unlock(&shmre_alloc_head->mutex);

out:
    return shmre_alloc_chunk;
}

shmre_alloc_chunk_t *shmre_alloc(shmre_allocator_t *allocator, size_t size, size_t bound, size_t head)
{
    return _shmre_alloc_boundary(allocator, size, bound, head);
}

// shmre_alloc_chunk_t *shmre_alloc_boundary(shmre_allocator_t *allocator, size_t size, size_t bound)
// {
//     return _shmre_alloc_boundary(allocator, size, bound, 0);
// }
// 
// shmre_alloc_chunk_t *shmre_alloc_align(shmre_allocator_t *allocator, size_t size, size_t head, size_t bound)
// {
//     return _shmre_alloc_boundary(allocator, size, bound, head);
// }

void shmre_free(shmre_allocator_t *allocator, shmre_alloc_chunk_t *chunk)
{
    // int ret = 0;
    // uint32_t ptr_off = 0;
    shmre_alloc_head_t *shmre_alloc_head = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;
    shmre_alloc_chunk_t *shmre_alloc_chunk_merge = NULL;

    // printk("%s data = %lx, size = %lx\n", __func__, chunk->data, chunk->size);

    // assert(chunk);
    // assert(allocator);
    shmre_alloc_head = &allocator->shmre_alloc_head;
    // assert(shmre_alloc_head);

    shmre_alloc_chunk = chunk;
    if (unlikely(!is_inuse(shmre_alloc_chunk->size))) {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_free double free chunk %p\n", shmre_alloc_chunk);
        return;
    }

    mutex_lock(&shmre_alloc_head->mutex);
    clear_inuse(shmre_alloc_chunk->size);
    
    if (unlikely(shmre_alloc_head->free_size + get_size(shmre_alloc_chunk->size) > shmre_alloc_head->total_size))
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "shmre_alloc free_size calculation mistake\n");
    else
        shmre_alloc_head->free_size += get_size(shmre_alloc_chunk->size);
    // free
    if (likely(!vaccrt_list_is_first(&shmre_alloc_chunk->node, &shmre_alloc_head->head))) {
        shmre_alloc_chunk_merge = (shmre_alloc_chunk_t *)list_prev_entry(shmre_alloc_chunk, node);
        if (!is_inuse(shmre_alloc_chunk_merge->size) &&
            shmre_alloc_chunk_merge->bank_id == shmre_alloc_chunk->bank_id) {
            list_del(&shmre_alloc_chunk_merge->node_free);
            shmre_alloc_chunk_merge->size += get_size(shmre_alloc_chunk->size);
            list_del(&shmre_alloc_chunk->node);
            // list_del(&shmre_alloc_chunk->node_owner);
            kfree(shmre_alloc_chunk);
            shmre_alloc_chunk = shmre_alloc_chunk_merge;
            // note: if used rb_tree need update shmre_alloc_chunk(free list), todo
        }
    }
    if (likely(!list_is_last(&shmre_alloc_chunk->node, &shmre_alloc_head->head))) {
        shmre_alloc_chunk_merge = (shmre_alloc_chunk_t *)list_next_entry(shmre_alloc_chunk, node);
        if (!is_inuse(shmre_alloc_chunk_merge->size) &&
            shmre_alloc_chunk_merge->bank_id == shmre_alloc_chunk->bank_id) {
            list_del(&shmre_alloc_chunk_merge->node_free);
            shmre_alloc_chunk->size += get_size(shmre_alloc_chunk_merge->size);
            list_del(&shmre_alloc_chunk_merge->node);
            // list_del(&shmre_alloc_chunk->node_owner);
            kfree(shmre_alloc_chunk_merge);
        }
    }
    
    _shmre_insert(allocator, shmre_alloc_chunk);

    if (allocator->check_memory) {
        if (!_shmre_chunk_safe_check(shmre_alloc_head, shmre_alloc_chunk)) {
            print_chunk_addr_and_size(shmre_alloc_head);
        }
    }
    mutex_unlock(&shmre_alloc_head->mutex);
}

void shmre_free_shm(shmre_allocator_t *allocator)
{
	shmre_alloc_chunk_t *chunk = NULL, *chunk_tmp = NULL;
	shmre_alloc_head_t *shmre_alloc_head = &allocator->shmre_alloc_head;

	mutex_lock(&shmre_alloc_head->mutex);
	list_for_each_entry_safe (chunk, chunk_tmp, &shmre_alloc_head->head, node) {
		list_del(&chunk->node);
		kfree(chunk);
	}
	mutex_unlock(&shmre_alloc_head->mutex);
}