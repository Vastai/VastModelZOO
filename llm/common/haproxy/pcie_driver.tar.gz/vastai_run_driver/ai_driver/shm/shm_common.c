#include "shm_common.h"
#include "shmrecord_alloc.h"
#include "vastai_ai.h"

char zone_name[zone_count][32] = { "zn_stream", "zn_model", "zn_vdsp_op",
				   "zn_share", "zn_odsp_op", "zn_cmcu_op" };
char operator_name[operator_count][32] = { "vdsp_op", "odsp_op", "cmcu_op" };

void vaccrt_shm_init(struct vastai_cdev *va_dev)
{
	struct vastai_zone *zone = NULL;
	size_t bases[VASTAI_ZONE_MAX_NUM] = { 0 };
	size_t sizes[VASTAI_ZONE_MAX_NUM] = { 0 };
	uint32_t zone_index = 0;

	for (zone_index = 0; zone_index < zone_count; zone_index++) {
		uint32_t align = 0, i = 0;
		INIT_SHMRE_ALLOCATOR(&(va_dev->device_ddr_alloc[zone_index]));
		zone = &(va_dev->zone[zone_index]);
		align = zone->alig_ddr_start;
		for (i = 0; i < zone->bank_num; i++) {
			bases[i] = zone->bank[i].base;
			sizes[i] = zone->bank[i].size;
		}
		shmre_alloc_head_init(
			&va_dev->device_ddr_alloc[zone_index].shmre_alloc_head,
			zone->bank_num, bases, sizes, align);
	}
}

int vaccrt_shmre_alloc(struct vastai_cdev *va_dev,
		       struct dev_process *dev_process,
		       shmre_alloc_cmd_t *shmre_alloc_cmd)
{
	int ret = 0;
	// find shmre_allocator according to shmre_index
	shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;
	shmre_allocator_t *shmre_allocator = NULL;
	struct device_ddr_proxy *device_ddr_proxy = NULL;
	struct mutex *mutex_owner = NULL;
	uint64_t *device_ddr_size_used = NULL;
	uint32_t zone_index = 0;
	mem_chunk_hnode_t *mem_chunk_hnode = NULL;

	if (shmre_alloc_cmd->shmre_index >= zone_count) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "invalid shmre_index = %d.\n",
			       shmre_alloc_cmd->shmre_index);
		return -EINVAL;
	}

	zone_index = shmre_alloc_cmd->shmre_index;
	shmre_allocator = &va_dev->device_ddr_alloc[zone_index];
	device_ddr_proxy = &dev_process->device_ddr_proxy[zone_index];
	mutex_owner = &device_ddr_proxy->mutex;

	device_ddr_size_used = &dev_process->device_ddr_size_used[zone_index];

	// add shmre_alloc_chunk to head_list
	mutex_lock(mutex_owner);
	// shmre_alloc_chunk = va_dev->ddr_share_alloc.
	shmre_alloc_chunk =
		shmre_allocator->malloc(shmre_allocator, shmre_alloc_cmd->size,
					shmre_alloc_cmd->bound,
					shmre_alloc_cmd->head);
	if (shmre_alloc_chunk == NULL) {
		// VASTAI_PCI_ERR(
		// 	va_dev->pci_info, va_dev->die_id,
		// 	"shmre_allocator alloc failed. alloc_addr = 0x%llx, size = 0x%llx\n",
		// 	shmre_alloc_cmd->param, shmre_alloc_cmd->size);
		ret = -ENOMEM;
		goto __out;
	}

	mem_chunk_hnode = (mem_chunk_hnode_t *)kzalloc(
		sizeof(mem_chunk_hnode_t), GFP_KERNEL);
	if (mem_chunk_hnode) {
		mem_chunk_hnode->chunk = shmre_alloc_chunk;
		hash_add(device_ddr_proxy->hash_map, &mem_chunk_hnode->node,
			 shmre_alloc_chunk->data);
	} else {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: kzalloc(mem_chunk_hnode_t) failed.\n",
			       __func__);
		shmre_allocator->free(
			shmre_allocator,
			shmre_alloc_chunk); // make sure shmre_alloc_chunk be free
		ret = -ENOMEM;
		goto __out;
	}

	*device_ddr_size_used += get_size(shmre_alloc_chunk->size);
	shmre_alloc_cmd->size = get_size(shmre_alloc_chunk->size);
	shmre_alloc_cmd->data = shmre_alloc_chunk->data;

__out:
	mutex_unlock(mutex_owner);

	return ret;
}

int vaccrt_shmre_free(struct vastai_cdev *va_dev,
		      struct dev_process *dev_process,
		      shmre_free_cmd_t *shmre_free_cmd)
{
	int ret = 0;
	shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;
	shmre_allocator_t *shmre_allocator = NULL;
	struct device_ddr_proxy *device_ddr_proxy = NULL;
	struct mutex *mutex_owner = NULL;
	uint64_t *device_ddr_size_used = NULL;
	uint32_t zone_index = 0;
	mem_chunk_hnode_t *mem_chunk_hnode = NULL;

	if (shmre_free_cmd->shmre_index >= zone_count) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "invalid shmre_index = %d.\n",
			       shmre_free_cmd->shmre_index);
		return -EINVAL;
	}

	zone_index = shmre_free_cmd->shmre_index;
	shmre_allocator = &va_dev->device_ddr_alloc[zone_index];
	device_ddr_proxy = &dev_process->device_ddr_proxy[zone_index];
	mutex_owner = &device_ddr_proxy->mutex;

	device_ddr_size_used = &dev_process->device_ddr_size_used[zone_index];

	mutex_lock(mutex_owner);
	// use hashmap to find the shmre_alloc_chunk
	hash_for_each_possible (device_ddr_proxy->hash_map,
				mem_chunk_hnode, node,
				(size_t)shmre_free_cmd->data) {
		if (mem_chunk_hnode->chunk->data == (size_t)shmre_free_cmd->data) {
			shmre_alloc_chunk = mem_chunk_hnode->chunk;
			break;
		}
	}
	if (shmre_alloc_chunk == NULL) {
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"shmre_alloc_chunk[%llx] not found.\n",
				shmre_free_cmd->data);
		ret = -EINVAL;
		goto __out;
	}
	*device_ddr_size_used -= get_size(shmre_alloc_chunk->size);;
	shmre_allocator->free(shmre_allocator, shmre_alloc_chunk);
	hash_del(&mem_chunk_hnode->node);
	kfree(mem_chunk_hnode);

__out:
	mutex_unlock(mutex_owner);

	return ret;
}

int vaccrt_vdsp_get(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		    vdsp_used_cmd_t *vdsp_used_cmd)
{
	int i = 0, min = 0, min_index = 0;
	if (va_dev->vdsp_used_counter.vdsp_num == 0) {
		vdsp_used_cmd->vdsp_id = 0;
		return 0;
	}
	mutex_lock(&va_dev->vdsp_used_counter.mutex);
	min = va_dev->vdsp_used_counter.used_counts[0];
	min_index = 0;
	for (i = 0; i < va_dev->vdsp_used_counter.vdsp_num; i++) {
		if (min > va_dev->vdsp_used_counter.used_counts[i]) {
			min = va_dev->vdsp_used_counter.used_counts[i];
			min_index = i;
		}
	}
	dev_process->vdsp_used_count[min_index]++;
	va_dev->vdsp_used_counter.used_counts[min_index]++;
	vdsp_used_cmd->vdsp_id = min_index;
	mutex_unlock(&va_dev->vdsp_used_counter.mutex);
	return 0;
}

int vaccrt_vdsp_put(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		    vdsp_used_cmd_t *vdsp_used_cmd)
{
	int ret = 0;
	int index = vdsp_used_cmd->vdsp_id;
	if (va_dev->vdsp_used_counter.vdsp_num == 0) {
		return 0;
	}
	if (vdsp_used_cmd->vdsp_id >= va_dev->vdsp_used_counter.vdsp_num) {
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"invalid vdsp_id = %d.\n",
				vdsp_used_cmd->vdsp_id);
		return -EINVAL;
	}
	mutex_lock(&va_dev->vdsp_used_counter.mutex);
	if (dev_process->vdsp_used_count[index] <= 0) {
		VASTAI_PCI_INFO(
			va_dev->pci_info, va_dev->die_id,
			"dev_process->vdsp_used_count[%d] = %d invalid.\n",
			index, dev_process->vdsp_used_count[index]);
		dev_process->vdsp_used_count[index] = 0;
		ret = -EINVAL;
	} else {
		dev_process->vdsp_used_count[index]--;
	}
	if (va_dev->vdsp_used_counter.used_counts[index] <= 0) {
		VASTAI_PCI_INFO(
			va_dev->pci_info, va_dev->die_id,
			"va_dev->vdsp_used_counter.used_counts[%d] = %d invalid.\n",
			index, va_dev->vdsp_used_counter.used_counts[index]);
		va_dev->vdsp_used_counter.used_counts[index] = 0;
		ret = -EINVAL;
	} else {
		va_dev->vdsp_used_counter.used_counts[index]--;
	}
	mutex_unlock(&va_dev->vdsp_used_counter.mutex);
	return ret;
}