#ifndef __SHM_COMMON_H__
#define __SHM_COMMON_H__

#include "vastai_ai.h"
#include "vastai_common.h"

void vaccrt_shm_init(struct vastai_cdev *va_dev);

int vaccrt_shmre_alloc(struct vastai_cdev *va_dev,
		       struct dev_process *dev_process,
		       shmre_alloc_cmd_t *shmre_alloc_cmd);

int vaccrt_shmre_free(struct vastai_cdev *va_dev,
		      struct dev_process *dev_process,
		      shmre_free_cmd_t *shmre_free_cmd);

int vaccrt_vdsp_get(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		    vdsp_used_cmd_t *vdsp_used_cmd);

int vaccrt_vdsp_put(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		    vdsp_used_cmd_t *vdsp_used_cmd);
#endif