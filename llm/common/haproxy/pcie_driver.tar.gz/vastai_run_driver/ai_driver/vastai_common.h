/*
 * vastai_ai - driver a Vastai ai device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2021/02/20
 */

#ifndef __VASTAI_COMMON_H__
#define __VASTAI_COMMON_H__

#include <linux/kernel.h>
#include <linux/wait.h>
#include <linux/hashtable.h>
#include "vastai_ai.h"
#include "vastai_pci.h"
#include "vastai_pci_api.h"
#include "shmrecord_alloc.h"

#define VASTAI_MAX_OUT_COUNT (0x01 << 16)
#define VASTAI_MAX_STREAM_COUNT	(0x01 << 16)

#define VASTAI_CANCEL_KERNEL_DEV_MASK (0x01 << 24)

#define AI_IRQ_NUM_ARRAY                                                       \
	{                                                                      \
		CMCU_2_HOST_INT0, VDSP0_2_HOST_INT0, VDSP1_2_HOST_INT0,        \
			VDSP2_2_HOST_INT0, VDSP3_2_HOST_INT0                   \
	}

struct __attribute__((packed)) dev_out_desc {
	/* refer to VASTAI_TRANSFER_SUBTYPE */
	u32 dev : 32;
	u32 pid : 32;
	u64 stream_id : 64;
	u64 data_id : 64;
	/* dev soc entry addr */
	u64 stream_addr : 64;
	u32 context_id : 32;
	/* error code */
	u32 error_code;
	/* reserved 64bit */
	u64 : 64;
	struct list_head node;
	struct work_struct work;
	void *ctxt;
};

struct device_ddr_proxy {
	struct mutex mutex;
	DECLARE_HASHTABLE(hash_map, 10);
};

typedef struct _mem_chunk_hnode_t {
    shmre_alloc_chunk_t *chunk;
    struct hlist_node node;
} mem_chunk_hnode_t;

typedef enum {
	stream_state_idle = 0,
	stream_state_get_out,
	stream_state_destroyed,
} stream_state_t;

typedef enum {
	stream_type_sync = 0,
	stream_type_async = 1,
} stream_type_t;

typedef struct _stream_node_t {
	u32 stream_id;
	u32 state; // 0 idle, 1 get_out_desc ing, 2 need to be destroy
	u32 type; // 0 sync, 1 async
	wait_queue_head_t wait;
	struct list_head head_out_desc;
	struct mutex mutex_out_desc;
	struct list_head node;
} stream_node_t;

struct dev_process {
	struct delayed_work work;
	struct list_head node;

	// out_desc_head/mutex/wait in process still keep for old version runtime
	struct list_head head; // list head for out_desc
	struct mutex mutex; // mutex for out_desc
	wait_queue_head_t wait; // wait for out_desc

	pid_t pid;
	pid_t vpid;
	u32 level;
	u64 ns;
	atomic_t ref_num;
	atomic_t run_ref_num;
	atomic_t ker_ref_num;
	atomic_t out_ref_num;
	int proc_state; // 1 process release
	void *ctxt;

	// stream mgr in ai_driver
	struct list_head stream_head;
	atomic_t stream_num;
	struct mutex stream_mutex;

	// device_ddr_proxy we can use list/hashmap/... to hold and manage shmre_chunk alloced from allocator
	struct device_ddr_proxy device_ddr_proxy[zone_count];

	u64 device_ddr_size_used[zone_count];

	int *vdsp_used_count;

	struct mutex mutex_operator_head[operator_count];
	atomic_t operator_ref_num[operator_count];
	struct list_head operator_head[operator_count];
};

struct dev_trans {
	struct mutex mutex;
	struct list_head head; // dev_process
	atomic_t dev_process_num;
	struct workqueue_struct *workqueue;
};

struct queue_desc {
	size_t lenth;
	loff_t pos;
	void *buffer;
};

union vastai_cmd {
	struct {
		// 0 idle, user space to kernel space
		// 1 curren process init mmap, kernel space to user space
		// 2 has been initialized, kernel space to user space, or user space to kernel space
		u32 state : 2;
		u32 : 30;
		u32 pid : 32;
		u64 addr : 64;
		u32 size : 32;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) mmap_init;
	struct {
		u32 dev : 32;
		// u32 cmd : 32;
		u32 pid : 32;
		u32 model_id : 32;
		u32 data_id : 32;
		/* dev soc entry addr */
		u32 model_addr : 32;
		u32 inout_addr : 32;
		u64 : 64;
	} __attribute__((packed)) run_load_model;
	struct {
		u32 dev : 32;
		// u32 cmd : 32;
		u32 pid : 32;
		u32 operator_type;
		u32 : 32;
		/* dev soc entry addr */
		u32 operator_addr : 32;
		u32 operator_size : 32;
		u64 : 64;
	} __attribute__((packed)) run_load_operator;
	struct {
		u32 dev : 32;
		u32 pid : 32;
		u64 src : 64; // host put bin here. offset in vf buffer
		u64 dst : 64; // dsp copy bin to here. offset in custom_op pool
		u32 operator_size : 32; // operator size
		u32 operator_addr : 32;
	} __attribute__((packed)) run_load_operator_sg100;
	struct {
		u32 dev : 32;
		// u32 cmd : 32;
		u32 pid : 32;
		u32 stream_id : 32;
		u32 data_id : 32;
		/* dev soc entry addr */
		u32 stream_addr : 32;
		/* reserved 32bit */
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) run_stream;
	struct {
		u32 pid : 32;
		u32 stream_id : 32;    
		u32 engine_type : 8;
		u32 work_size : 24;
		u32 kernel_addr : 32;
		u32 args_addr : 32;
		u32 data_id : 32;
		u64 : 64;
	} __attribute__((packed)) run_kernel;
	struct {
		u32 pid : 32;
		u32 : 32;    
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) cancel_kernel;
	struct {
		u32 dev;
		u32 pid : 32;
		u32 stream_id : 32;
		u32 data_id;
		/* dev soc entry addr */
		u32 stream_addr;
		u32 context_id;
		u32 error_code;
		u32 timeout;
	} __attribute__((packed)) get_desc;
	struct {
		u32 pid : 32;
		u32 vpid : 32; // VACC_GET_CURRENT_PID
		u64 ns : 64; // VACC_GET_CURRENT_PID
		u32 level : 32; // VACC_GET_CURRENT_PID
		// VACC_GET_PROCESS
		// 0 process exit, 1 process at vacc_dev->process_head
		// VACC_RELEASE_PROCESS
		// 0 process not used, 1 process used not to release
		u32 state : 2;
		// VACC_RELEASE_PROCESS
		// 0 normal release
		// 1 warn release, not all results were taken
		// 2 error release, not getting enough task results
		u32 release : 2;
		u32 : 28;
		u64 : 64;
	} __attribute__((packed)) process;

	struct {
		u32 remote_die;
		u32 len;
		u32 is_local_2_remote : 8;
		/* reserved 8bit */
		u32 : 8;
		u64 local_address : 40;
		u64 remote_address : 40;
		/* reserved 32bit */
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) dev_2_dev;

	struct {
		u32 remote_die;
		u32 len;
		u32 is_local_2_remote : 8;
		/* reserved 8bit */
		u32 : 8;
		u64 local_address;
		u64 remote_address;
		u32 : 32;
		u16 : 16;
	} __attribute__((packed)) peer_2_peer;

	struct {
		u64 src_addr;
		u64 dst_addr;
		u32 size;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) ddr_2_ddr;

	struct {
		u32 size;
		int dma_buf_fd;
		u64 dma_addr_t;
	} __attribute__((packed)) dmabuf_alloc_cmd;

	struct {
		u32 is_dev_to_host;
		u32 dma_buf_fd;
		u64 axi_addr;
		u32 size;
		u32 die_index;
	} __attribute__((packed)) dmabuf_start_cmd;

	struct {
		u32 is_dev_to_host;
		u64 vir_addr;
		u64 axi_addr;
		u32 length;
		u32 die_index;
		int pid;
	} __attribute__((packed)) dmabuf_trans_cmd;

	struct {
		u64 size;
		u64 dma_addr_t;
		int dma_buf_fd;
		rdma_mem_type_t mem_type;
	} __attribute__((packed)) vccl_dmabuf_alloc_cmd;

	struct {
		int dmabuf_fd;
		u32 buf_num;
		void *buf_list;
	} __attribute__((packed)) vccl_rdma_hostbuf_cmd;

	struct {
		u32 stream_id;
		u32 type;
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) create_stream_cmd;

	struct {
		u32 stream_id;
		u32 type;
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) destroy_stream_cmd;
};

// struct dev_process *get_dev_process(struct vastai_cdev *va_dev, pid_t pid);

int vaccrt_cmd_run(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		   union vastai_cmd *run, u32 cmd);
int vaccrt_cmd_get_desc(struct vastai_cdev *va_dev,
			struct dev_process *dev_process,
			union vastai_cmd *get_desc);
// int vastai_release_dev_process(struct vastai_cdev *, pid_t pid);
int vaccrt_add_dev_process(struct vastai_cdev *, struct dev_process **);
void vaccrt_remove_dev_process(struct vastai_cdev *, struct dev_process *);

int vaccrt_map_read(struct vastai_cdev *, char __user *, size_t, loff_t);
size_t vaccrt_add_read_queue(struct vastai_cdev *, struct queue_desc *);
int vaccrt_map_write(struct vastai_cdev *, const char __user *, size_t, loff_t);
size_t vaccrt_add_write_queue(struct vastai_cdev *, struct queue_desc *);

int vaccrt_pci_transfer_init(struct vastai_cdev *);
void vaccrt_pci_transfer_exit(struct vastai_cdev *);
int vaccrt_ai_callback_reg(void *, struct vastai_cdev *);
int vaccrt_ai_callback_unreg(void *pcie_dev, struct vastai_cdev *va_dev);
int vaccrt_ai_trans_call(void *pci_dev, u32 die_index, int irq,void *ctxt, void *out);
void vastai_cmcu_call_back(void *arg);
int vaccrt_ai_data_movement(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd);
int vaccrt_ai_data_movement_peers(struct vastai_cdev *va_dev,
				  union vastai_cmd *vastai_cmd);
int vaccrt_ai_data_movement_inner(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd, pid_t pid);
extern bool iommu_is_enable(struct vastai_pci_info *pci_info);

unsigned long vaccrt_ai_copy_to_user(void __user *to, const void *from, unsigned long n);
unsigned long vaccrt_ai_copy_from_user(void *to, const void __user *from, unsigned long n);

int vaccrt_vacc_read_info(struct vastai_cdev *vacc_dev, char __user *buffer,
			  loff_t *len);

int vaccrt_ai_create_stream(struct vastai_cdev *va_dev,
			    struct dev_process *dev_process,
			    union vastai_cmd *vastai_cmd);
int vaccrt_ai_destroy_stream(struct vastai_cdev *va_dev,
			     struct dev_process *dev_process,
			     union vastai_cmd *vastai_cmd);
				 
#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_ai_reset_handler(u32 die_index, u32 core_bit, reset_event event);
#endif

#endif /* end of __VASTAI_COMMON_H__ */
