#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/list.h>
#include <linux/printk.h>
#include <linux/slab.h>
#include <linux/completion.h>
#include <linux/sched/signal.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,11,0)
#include <linux/signal.h>
#else
#include <linux/sched/signal.h>
#endif
#include <linux/uaccess.h>
#include <linux/workqueue.h>
#include <linux/pid_namespace.h>

#include "vastai_operator.h"
#include "shm_common.h"

#if CONFIG_VASTAI_SOC_HW_TYPE==2
#include "vastai_ai_info.h"
#endif

static int __alloc_ddr(struct operator_manager *operator_manager,
		       uint64_t *data_addr, uint64_t *data_size,
		       uint64_t *code_addr, uint64_t *code_size)
{
	int ret = 0;
	shmre_alloc_chunk_t *shmre_alloc_chunk_data = NULL,
			    *shmre_alloc_chunk_code = NULL;
	shmre_allocator_t *shmre_allocator_data = NULL,
			  *shmre_allocator_code = NULL;
	struct list_head *head_owner_data = NULL, *head_owner_code = NULL;
	struct mutex *mutex_owner = NULL;
	uint64_t *device_data_ddr_size_used = NULL,
		 *device_code_ddr_size_used = NULL;
	uint32_t zone_index = 0;
	struct vastai_cdev *va_dev =
		(struct vastai_cdev *)operator_manager->private_data;

	zone_index = operator_manager->zone_index;
	mutex_owner = &operator_manager->mutex_ddr_head;
	shmre_allocator_code = &va_dev->device_ddr_alloc[zone_model];
	shmre_allocator_data = &va_dev->device_ddr_alloc[zone_index];
	head_owner_data = &operator_manager->device_ddr_head;
	head_owner_code = &operator_manager->device_code_ddr_head;
	device_data_ddr_size_used = &operator_manager->device_ddr_size_used;
	device_code_ddr_size_used =
		&operator_manager->device_code_ddr_size_used;

	*data_addr = 0;
	*code_addr = 0;

	mutex_lock(mutex_owner);

	if (*code_size) {
		// need alloc ddr for operator code section
		shmre_alloc_chunk_code = shmre_allocator_code->malloc(
			shmre_allocator_code, (size_t)*code_size, 0, 0);
		if (shmre_alloc_chunk_code == NULL) {
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"%s: alloc ddr for operator code section failed. code_size = 0x%llX",
				__func__, *code_size);
			ret = -ENOMEM;
			goto __out;
		}
	}

	if (*data_size) {
		// need alloc ddr for operator data section
		shmre_alloc_chunk_data = shmre_allocator_data->malloc(
			shmre_allocator_data, (size_t)*data_size, 0, 0);
		if (shmre_alloc_chunk_data == NULL) {
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"%s: alloc ddr for operator data section failed. data_size = 0x%llX",
				__func__, *data_size);
			ret = -ENOMEM;
			goto __out;
		}
	}

__out:

	if (ret) {
		// failed, free alloc_chunk from allocator
		if (shmre_alloc_chunk_code)
			shmre_allocator_code->free(shmre_allocator_code,
					      shmre_alloc_chunk_code);

		if (shmre_alloc_chunk_data)
			shmre_allocator_data->free(shmre_allocator_data,
					      shmre_alloc_chunk_data);
	} else {
		// succeed, insert alloc_chunk into head_owner
		if (shmre_alloc_chunk_code) {
			list_add(&shmre_alloc_chunk_code->node_owner, head_owner_code);
			*device_code_ddr_size_used +=
				get_size(shmre_alloc_chunk_code->size);
			*code_addr = shmre_alloc_chunk_code->data;
			*code_size = get_size(shmre_alloc_chunk_code->size);
		}
		
		if (shmre_alloc_chunk_data) {
			list_add(&shmre_alloc_chunk_data->node_owner, head_owner_data);
			*device_data_ddr_size_used +=
				get_size(shmre_alloc_chunk_data->size);
			*data_addr = shmre_alloc_chunk_data->data;
			*data_size = get_size(shmre_alloc_chunk_data->size);
		}
	}
	mutex_unlock(mutex_owner);
	return ret;
}

static int __free_ddr(struct operator_manager *operator_manager, uint64_t data_addr, uint64_t code_addr)
{
	int ret = 0;
	shmre_alloc_chunk_t *shmre_alloc_chunk = NULL;
	shmre_alloc_chunk_t *pos = NULL;
	shmre_allocator_t *shmre_allocator_code = NULL, *shmre_allocator_data = NULL;
	struct list_head *head_owner_code = NULL, *head_owner_data = NULL;
	struct mutex *mutex_owner = NULL;
	uint64_t *device_code_ddr_size_used = NULL, *device_data_ddr_size_used = NULL;
	uint32_t zone_index = 0;
	struct vastai_cdev *va_dev =
		(struct vastai_cdev *)operator_manager->private_data;

	zone_index = operator_manager->zone_index;
	shmre_allocator_data = &va_dev->device_ddr_alloc[zone_index];
	shmre_allocator_code = &va_dev->device_ddr_alloc[zone_model];
	head_owner_data = &operator_manager->device_ddr_head;
	head_owner_code = &operator_manager->device_code_ddr_head;
	mutex_owner = &operator_manager->mutex_ddr_head;
	device_data_ddr_size_used = &operator_manager->device_ddr_size_used;
	device_code_ddr_size_used = &operator_manager->device_code_ddr_size_used;

	mutex_lock(mutex_owner);

	if (code_addr) {
		shmre_alloc_chunk = NULL;
		list_for_each_entry (pos, head_owner_code, node_owner) {
			if (pos->data == (size_t)code_addr) {
				shmre_alloc_chunk = pos;
				break;
			}
		}
		if (shmre_alloc_chunk == NULL) {
			VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
					"operator code shmre_alloc_chunk[%llx] not found.\n", code_addr);
			ret = -EINVAL;
			goto __out;
		}
		list_del(&shmre_alloc_chunk->node_owner);
		*device_code_ddr_size_used -= get_size(shmre_alloc_chunk->size);
		shmre_allocator_code->free(shmre_allocator_code, shmre_alloc_chunk);
	}

	if (data_addr) {
		shmre_alloc_chunk = NULL;
		list_for_each_entry (pos, head_owner_data, node_owner) {
			if (pos->data == (size_t)data_addr) {
				shmre_alloc_chunk = pos;
				break;
			}
		}
		if (shmre_alloc_chunk == NULL) {
			VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
					"operator data shmre_alloc_chunk[%llx] not found.\n", data_addr);
			ret = -EINVAL;
			goto __out;
		}
		list_del(&shmre_alloc_chunk->node_owner);
		*device_data_ddr_size_used -= get_size(shmre_alloc_chunk->size);
		shmre_allocator_data->free(shmre_allocator_data, shmre_alloc_chunk);
	}

__out:
	mutex_unlock(mutex_owner);
	return ret;
}

static void __free_shm(struct operator_manager *operator_manager)
{
	shmre_alloc_chunk_t *chunk = NULL, *chunk_tmp = NULL;
	shmre_allocator_t *shmre_allocator = NULL;
	uint32_t zone_index = 0;
	struct vastai_cdev *va_dev =
		(struct vastai_cdev *)operator_manager->private_data;

	zone_index = operator_manager->zone_index;
	
	mutex_lock(&operator_manager->mutex_ddr_head);

	shmre_allocator = &va_dev->device_ddr_alloc[zone_model];
	list_for_each_entry_safe (chunk, chunk_tmp,
				  &operator_manager->device_code_ddr_head,
				  node_owner) {
		list_del(&chunk->node_owner);
		operator_manager->device_code_ddr_size_used -= get_size(chunk->size);
		shmre_allocator->free(shmre_allocator, chunk);
	}

	shmre_allocator = &va_dev->device_ddr_alloc[zone_index];
	list_for_each_entry_safe (chunk, chunk_tmp,
				  &operator_manager->device_ddr_head,
				  node_owner) {
		list_del(&chunk->node_owner);
		operator_manager->device_ddr_size_used -= get_size(chunk->size);
		shmre_allocator->free(shmre_allocator, chunk);
	}

	mutex_unlock(&operator_manager->mutex_ddr_head);
}

static void __operator_node_init(struct operator_node *operator_node,
				 const uint32_t id[], uint64_t addr,
				 uint64_t size, uint64_t code_addr, uint64_t code_size)
{
	mutex_init(&operator_node->mutex_ref_process);
	init_waitqueue_head(&operator_node->wait);
	INIT_LIST_HEAD(&operator_node->ref_process_head);
	atomic_set(&operator_node->process_ref_num, 0);
	memcpy((void *)operator_node->id, (void *)id, OP_ID_BYTE_LEN);
	operator_node->addr = addr;
	operator_node->size = size;
	operator_node->code_addr = code_addr;
	operator_node->code_size = code_size;
}

int operator_manager_init(struct operator_manager *operator_manager,
			  operator_type_t operator_type, void *private_data)
{
	struct vastai_cdev *va_dev = (struct vastai_cdev *)private_data;
	mutex_init(&operator_manager->mutex);
	INIT_LIST_HEAD(&operator_manager->head);
	atomic_set(&operator_manager->operator_num, 0);

	mutex_init(&operator_manager->mutex_ddr_head);
	INIT_LIST_HEAD(&operator_manager->device_ddr_head);
	INIT_LIST_HEAD(&operator_manager->device_code_ddr_head);
	operator_manager->device_ddr_size_used = 0;
	operator_manager->device_code_ddr_size_used = 0;

	operator_manager->private_data = private_data;
	operator_manager->operator_type = operator_type;
	operator_manager->zone_index = zone_vdsp_operator; // default
	if (operator_type == vdsp_operator) {
		operator_manager->zone_index = zone_vdsp_operator;
		sprintf(operator_manager->name, "vdsp_operator");
	} else if (operator_type == odsp_operator) {
		operator_manager->zone_index = zone_odsp_operator;
		sprintf(operator_manager->name, "odsp_operator");
	} else if (operator_type == cmcu_operator) {
		operator_manager->zone_index = zone_cmcu_operator;
		sprintf(operator_manager->name, "cmcu_operator");
	} else {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "invalid operator_type = %d\n", operator_type);
		return -1;
	}

	return 0;
}

void operator_manager_exit(struct operator_manager *operator_manager, int force)
{
	struct operator_node *op_node = NULL, *op_node_tmp = NULL;
	struct ref_process *ref_process = NULL, *ref_process_tmp = NULL;
	struct vastai_cdev *va_dev =
		(struct vastai_cdev *)operator_manager->private_data;

	mutex_lock(&operator_manager->mutex);
	list_for_each_entry_safe (op_node, op_node_tmp, &operator_manager->head,
				  node) {
		// when dsp_reset happend, _dsp_reset_clean_operator-->operator_manager_exit
		// if op_unload or op_loading, we will keep this op_node;
		if ((!force) && (op_node->load_state == op_unload ||
				 op_node->load_state == op_loading)) {
			VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
					"%s: reserve %s[%08X%08X%08X%08X].\n",
					__func__, operator_manager->name,
					op_node->id[0], op_node->id[1],
					op_node->id[2], op_node->id[3]);
			continue;
		}
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"%s: remove %s[%08X%08X%08X%08X].\n", __func__,
				operator_manager->name, op_node->id[0],
				op_node->id[1], op_node->id[2], op_node->id[3]);
		mutex_lock(&op_node->mutex_ref_process);
		list_for_each_entry_safe (ref_process, ref_process_tmp,
					  &op_node->ref_process_head, node) {
			list_del(&ref_process->node);
			kfree(ref_process);
			atomic_dec(&op_node->process_ref_num);
		}
		list_del(&op_node->node);
		mutex_unlock(&op_node->mutex_ref_process);
		__free_ddr(operator_manager, op_node->addr, op_node->code_addr);
		kfree(op_node);
		atomic_dec(&operator_manager->operator_num);
	}
	if (force)
		__free_shm(operator_manager);
	mutex_unlock(&operator_manager->mutex);
}

void operator_manager_detach_process(struct operator_manager *operator_manager,
				     pid_t pid)
{
	struct operator_node *op_node = NULL, *op_node_tmp = NULL;
	struct ref_process *ref_process = NULL, *ref_process_tmp = NULL;

	mutex_lock(&operator_manager->mutex);
	list_for_each_entry_safe (op_node, op_node_tmp, &operator_manager->head,
				  node) {
		mutex_lock(&op_node->mutex_ref_process);
		list_for_each_entry_safe (ref_process, ref_process_tmp,
					  &op_node->ref_process_head, node) {
			if (ref_process->pid == pid) {
				list_del(&ref_process->node);
				kfree(ref_process);
				atomic_dec(&op_node->process_ref_num);
			}
		}
		mutex_unlock(&op_node->mutex_ref_process);

		if (list_empty(&op_node->ref_process_head)) {
			list_del(&op_node->node);
			__free_ddr(operator_manager, op_node->addr, op_node->code_addr);
			kfree(op_node);
			atomic_dec(&operator_manager->operator_num);
		}
	}
	mutex_unlock(&operator_manager->mutex);
}

void operator_print(struct vastai_cdev *vacc_dev)
{
	int i = 0;
	struct operator_node *op_node = NULL;
	struct operator_manager *operator_manager = NULL;
	struct ref_process *ref_process = NULL;
	for (i = 0; i < operator_count; i++) {
		int node_i = 0;
		operator_manager = &vacc_dev->operator_manager[i];
		printk("---------------------[%s]-------------------------\n", operator_manager->name);
		mutex_lock(&operator_manager->mutex);
		printk("operator_num: %d, ddr_used = 0x%llX\n",
		       atomic_read(&operator_manager->operator_num),
		       operator_manager->device_ddr_size_used);
		printk("[  #]: %32s %15s\n", "operator_id", "ref_process_num");
		list_for_each_entry (op_node, &operator_manager->head, node) {
			printk("[%3d]: %08X%08X%08X%08X %15d\n", node_i++,
			       op_node->id[0], op_node->id[1], op_node->id[2],
			       op_node->id[3],
			       atomic_read(&op_node->process_ref_num));
			mutex_lock(&op_node->mutex_ref_process);
			list_for_each_entry (ref_process,
					     &op_node->ref_process_head, node) {
				printk("                                             pid[%5d]\n",
				       ref_process->pid);
			}
			mutex_unlock(&op_node->mutex_ref_process);
		}
		mutex_unlock(&operator_manager->mutex);
		printk("\n");
	}
}

static void _dsp_reset_clean_operator(struct vastai_cdev *vacc_dev,
				      uint32_t op_type)
{
	struct operator_manager *operator_manager = NULL;
	if (op_type >= operator_count) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid operator type = %d.\n", __func__,
			       op_type);
		return;
	}
	operator_manager = &vacc_dev->operator_manager[op_type];
	VASTAI_PCI_INFO(vacc_dev->pci_info, vacc_dev->die_id,
			"dsp_reset cause [%s] clean operator node.\n",
			operator_manager->name);
	operator_manager_exit(operator_manager, 0);
}

void on_vdsp_reset_handle(struct vastai_cdev *vacc_dev, uint32_t core_bit)
{
	_dsp_reset_clean_operator(vacc_dev, vdsp_operator);
}

void on_odsp_reset_handle(struct vastai_cdev *vacc_dev, uint32_t core_bit)
{
	_dsp_reset_clean_operator(vacc_dev, odsp_operator);
}

static ssize_t __operator_write(struct vastai_cdev *vacc_dev,
				const char __user *buffer, size_t size,
				uint64_t pos)
{
	int ret = 0;
	u32 i, j;
	// loff_t pos = *ppos;
	loff_t lenth = size;
	struct queue_desc *queue_desc = NULL;
	// struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	// struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	struct vastai_soc soc = vacc_dev->soc;
	struct vastai_zone *zone = vacc_dev->zone;

	if (0 == lenth) {
		ret = -EINVAL;
		goto out;
	}

	for (i = 0; i < soc.zone_num; i++) {
		for (j = 0; j < zone->bank_num; j++) {
			if (pos >= zone->bank[j].base &&
			    pos < zone->bank[j].base + zone->bank[j].size) {
				if (lenth > zone->bank[j].base +
						    zone->bank[j].size - pos)
					lenth = zone->bank[j].base +
						zone->bank[j].size - pos;
				if (zone_stream == i)
					goto csram;
				else
					goto ddr;
			}
		}

		zone++;
	}
	for (i = 0; i < soc.vdsp_num; i++) {
		if (pos >= vacc_dev->vdsp[i].base &&
		    pos < vacc_dev->vdsp[i].base + vacc_dev->vdsp[i].size) {
			if (lenth > vacc_dev->vdsp[i].base +
					    vacc_dev->vdsp[i].size - pos)
				lenth = vacc_dev->vdsp[i].base +
					vacc_dev->vdsp[i].size - pos;
			goto ddr;
		}
	}
	for (i = 0; i < soc.core_num; i++) {
		if (pos >= vacc_dev->odsp[i].base &&
		    pos < vacc_dev->odsp[i].base + vacc_dev->odsp[i].size) {
			if (lenth > vacc_dev->odsp[i].base +
					    vacc_dev->odsp[i].size - pos)
				lenth = vacc_dev->odsp[i].base +
					vacc_dev->odsp[i].size - pos;
			goto ddr;
		}
	}
	ret = -EINVAL;
	goto out;

csram:
	ret = vaccrt_map_write(vacc_dev, buffer, lenth, pos);
	if (!ret) {
		ret = lenth;
	}
	goto out;

ddr:
	queue_desc = (struct queue_desc *)kzalloc(sizeof(struct queue_desc),
						   GFP_KERNEL);
	if (!queue_desc) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: failed to kzalloc queue_desc\n",
			       __func__);
		ret = -ENOMEM;
		goto out;
	}

	queue_desc->pos = pos;
	queue_desc->lenth = lenth;
	queue_desc->buffer = (void *)buffer;

	ret = vaccrt_add_write_queue(vacc_dev, queue_desc);
	kfree(queue_desc);

out:
	return ret;
}

#if CONFIG_VASTAI_SOC_HW_TYPE==1

static struct operator_node *
__get_operator_node(struct operator_manager *operator_manager,
		    const uint32_t id[])
{
	struct operator_node *op_pos = NULL, *op_node = NULL;
	list_for_each_entry (op_pos, &operator_manager->head, node) {
		if (memcmp((void *)op_pos->id, (void *)id, OP_ID_BYTE_LEN) ==
		    0) {
			op_node = op_pos;
			break;
		}
	}
	return op_node;
}

int operator_load(struct vastai_cdev *vacc_dev, struct dev_process *dev_process,
		  void *cmd_buffer, int version)
{
	int ret = 0;
	int do_copy_load = 0;
	unsigned int cmd = 0;
	union vastai_cmd vastai_cmd;
	struct operator_manager *operator_manager = NULL;
	struct operator_node *op_node = NULL;
	struct vastai_zone *zone = vacc_dev->zone;
	u64 addr = 0, addr_min = 0, addr_max = 0;
	uint32_t core_num = 0, index = 0;
	uint64_t base_temp = 0, offset = 0, base0 = 0, addr_to = 0, data_dst_addr0 = 0;
	void __user *buffer = NULL;
	u32 operator_type = 0;
	size_t op_code_size = 0, op_data_size = 0;
	int flag_kernel_op = 0;
	u32 op_id[MD5_OPERATOR_ID_LEN];
	operator_load_cmd_t *operator_load_cmd = NULL;
	operator_load_v2_cmd_t *operator_load_v2_cmd = NULL;

	operator_load_cmd = (operator_load_cmd_t *)cmd_buffer;
	operator_load_v2_cmd = (operator_load_v2_cmd_t *)cmd_buffer;

	memset(&vastai_cmd, 0, sizeof(vastai_cmd));
	if (version == 1) {
		memcpy((void *)op_id, (void *)operator_load_v2_cmd->id,
		       sizeof(u32) * MD5_OPERATOR_ID_LEN);
		operator_type = operator_load_v2_cmd->operator_type;
	} else {
		memcpy((void *)op_id, (void *)operator_load_cmd->id,
		       sizeof(u32) * MD5_OPERATOR_ID_LEN);
		operator_type = operator_load_cmd->operator_type;
	}

	if (operator_type >= operator_count) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "invalid operator type [%d]\n", operator_type);
		return -EINVAL;
	}

	if (version == 1) {
		if (operator_load_v2_cmd->flag) {
			flag_kernel_op = 0; // flag as 1, use ring buffer
		} else {
			flag_kernel_op = 1; // flag as 0 (default), use command buffer
		}
	}

	vastai_cmd.run_load_operator.dev = operator_load_cmd->dev;
	vastai_cmd.run_load_operator.pid = dev_process->pid;
	vastai_cmd.run_load_operator.operator_type = operator_type;
	vastai_cmd.run_load_operator.operator_addr = 0;
	vastai_cmd.run_load_operator.operator_size = 0;

	operator_manager = &vacc_dev->operator_manager[operator_type];

	// check code entry addr is invalid here ?
	if (operator_load_v2_cmd->op_code_addr) {
		addr = operator_load_v2_cmd->op_code_addr;
		addr_min = zone[zone_model].entry;
		addr_max = zone[zone_model].entry + zone[zone_model].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			addr_min = zone[zone_model].entry1;
			addr_max = zone[zone_model].entry1 + zone[zone_model].bank[1].size;
			if (addr < addr_min || addr >= addr_max) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] %s[%08X%08X%08X%08X] operator_code_addr:0x%llx, [min_0:0x%llx, max_0:0x%llx], [min_1:0x%llx, max_1:0x%llx]\n",
					operator_manager->name, op_id[0],
					op_id[1], op_id[2], op_id[3], addr,
					(u64)zone[zone_model].entry,
					(u64)(zone[zone_model].entry +
					      zone[zone_model].bank[0].size),
					(u64)zone[zone_model].entry1,
					(u64)(zone[zone_model].entry1 +
					      zone[zone_model].bank[1].size));
				return -EINVAL;
			}
		}
	}

	if (version == 1) {
		addr = operator_load_v2_cmd->op_data_addr;
	} else {
		addr = operator_load_cmd->operator_addr;
	}
	if (operator_type == vdsp_operator) {
		core_num = vacc_dev->soc.vdsp_num;
		// addr = operator_load_cmd->operator_addr;
		addr_min = zone[zone_vdsp_operator].entry;
		addr_max = zone[zone_vdsp_operator].entry +
			   zone[zone_vdsp_operator].bank[0].size;
		cmd = flag_kernel_op ? CMD_LOAD_OPERATOR : CMD_LOAD_VDSP_OPERATOR;
	} else if (operator_type == odsp_operator) {
		core_num = vacc_dev->soc.core_num;
		// addr = operator_load_cmd->operator_addr;
		addr_min = zone[zone_odsp_operator].entry;
		addr_max = zone[zone_odsp_operator].entry +
			   zone[zone_odsp_operator].bank[0].size;
		cmd = flag_kernel_op ? CMD_LOAD_OPERATOR : CMD_LOAD_ODSP_OPERATOR;
	} else if (operator_type == cmcu_operator) {
		core_num = 1; // only one cmcu in current_system
		// addr = operator_load_cmd->operator_addr;
		addr_min = zone[zone_cmcu_operator].entry;
		addr_max = zone[zone_cmcu_operator].entry + zone[zone_cmcu_operator].bank[0].size;
		cmd = CMD_LOAD_OPERATOR; // cmcu_operator must use command_buffer
	} else {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "invalid operator type [%d]\n", operator_type);
		return -EINVAL;
	}
	if (addr < addr_min || addr >= addr_max) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"[vaerr] %s[%08X%08X%08X%08X] operator_data_addr:0x%llx, min:0x%llx, max:0x%llx\n",
			operator_manager->name, op_id[0], op_id[1], op_id[2],
			op_id[3], addr, addr_min, addr_max);
		return -EINVAL;
	}
	if (core_num == 0) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: core_num is zero.\n", __func__);
		return -EINVAL;
	}

__retry:
	mutex_lock(&operator_manager->mutex);
	do_copy_load = 0;
	op_node = __get_operator_node(operator_manager, op_id);
	if (op_node == NULL) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"%s: %s[%08X%08X%08X%08X] is not found before copy_and_load.\n",
			__func__, operator_manager->name, op_id[0], op_id[1],
			op_id[2], op_id[3]);
		ret = -EINVAL;
		mutex_unlock(&operator_manager->mutex);
		return ret;
	}
	// check data_ddr_addr and code_ddr_addr is invalid ?
	if (version == 1) {
		if ((op_node->addr != operator_load_v2_cmd->dst_data_addr) ||
		    (op_node->code_addr !=
		     operator_load_v2_cmd->dst_code_addr)) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: %s[%08X%08X%08X%08X] ddr addr is not match, data_addr[0x%llX, 0x%llX], code_addr[0x%llX, 0x%llX].\n",
				__func__, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3], op_node->addr,
				operator_load_v2_cmd->dst_data_addr,
				op_node->code_addr,
				operator_load_v2_cmd->dst_code_addr);
			ret = -EINVAL;
			mutex_unlock(&operator_manager->mutex);
			return ret;
		}
	} else {
		if (op_node->addr != operator_load_cmd->dst_addr) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: %s[%08X%08X%08X%08X] addr is not match, op_addr = 0x%llX, cmd_addr = 0x%llX.\n",
				__func__, operator_manager->name, op_id[0], op_id[1],
				op_id[2], op_id[3], op_node->addr,
				operator_load_cmd->dst_addr);
			ret = -EINVAL;
			mutex_unlock(&operator_manager->mutex);
			return ret;
		}
	}
	if (op_node->load_state == op_unload) {
		op_node->load_state = op_loading;
		do_copy_load = 1;
	} else if (op_node->load_state == op_loaded) {
		ret = 0;
		mutex_unlock(&operator_manager->mutex);
		// VASTAI_PCI_INFO(
		// 	vacc_dev->pci_info, vacc_dev->die_id,
		// 	"operator %s[%08X%08X%08X%08X] has been loaded into dsp.\n",
		// 	operator_manager->name,,
		// 	op_id[0], op_id[1],
		// 	op_id[2], op_id[3]);
		return ret;
	}
	mutex_unlock(&operator_manager->mutex);

	// op_node->load_state == op_loading --> do_copy_load = 1
	// op_node->load_state == op_unload ---> op_node->load_state => op_loading
	// op_node->load_state == op_loaded ---> return 0
	if (do_copy_load) {
		goto __do_copy_and_load;
	}

	// load_state == op_loading will suspend to wait;
	// load_state == op_unload, op_loaded, will goto __retry
	// -EINTR or -ERESTARTSYS will return -EINTR
	ret = wait_event_interruptible(op_node->wait, (op_node->load_state != op_loading));
	if (!ret) {
		// VASTAI_PCI_INFO(
		// 	vacc_dev->pci_info, vacc_dev->die_id,
		// 	"%s: be wake up, goto __retry, op_node->load_state = %d\n",
		// 	__func__, op_node->load_state);
		goto __retry;
	} else { // -EINTR or -ERESTARTSYS
		// VASTAI_PCI_ERR(
		// 	vacc_dev->pci_info, vacc_dev->die_id,
		// 	"%s: wait_event_interruptible interrupted, ret = %d\n",
		// 	__func__, ret);
		ret = -EINTR;
		return ret;
	}

__do_copy_and_load:
	// VASTAI_PCI_INFO(vacc_dev->pci_info, vacc_dev->die_id,
	// 		"load operator [%08X%08X%08X%08X] into dsp.\n",
	// 		op_id[0], op_id[1],
	// 		op_id[2], op_id[3]);

	if (version == 1) {
		op_code_size = operator_load_v2_cmd->op_code_size;;
		op_data_size = operator_load_v2_cmd->op_data_size;
	} else {
		op_code_size = 0;
		op_data_size = operator_load_cmd->operator_size;
	}

	// copy operator code section
	if (version == 1 && (op_code_size > 0)) {
		buffer = (void __user *)operator_load_v2_cmd->src_code_addr;
		addr_to = operator_load_v2_cmd->dst_code_addr;
		if ((ret = __operator_write(vacc_dev, buffer, op_code_size,
					    addr_to)) < 0) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: %s[%08X%08X%08X%08X] __operator_write_code_section failed.\n",
				__func__, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);
			goto __out;
		}
	}

	if (version == 1) {
		buffer = (void __user *)operator_load_v2_cmd->src_data_addr;
		data_dst_addr0 = operator_load_v2_cmd->dst_data_addr;
	} else {
		buffer = (void __user *)operator_load_cmd->src_addr;
		data_dst_addr0 = operator_load_cmd->dst_addr;
	}

	// copy operator data section
	if (operator_type == odsp_operator) {
		base0 = vacc_dev->odsp[0].base;
	} else if (operator_type == vdsp_operator) {
		base0 = vacc_dev->vdsp[0].base;
	} else if (operator_type == cmcu_operator) {
		base0 = vacc_dev->cmcu[0].base;
	}

	for (index = 0; index < core_num; index++) {
		if (operator_type == odsp_operator) {
			base_temp = vacc_dev->odsp[index].base;
		} else if (operator_type == vdsp_operator) {
			base_temp = vacc_dev->vdsp[index].base;
		} else if (operator_type == cmcu_operator) {
			base_temp = vacc_dev->cmcu[index].base;
		}

		offset = data_dst_addr0 - base0;
		addr_to = base_temp + offset;
		if ((ret = __operator_write(vacc_dev, buffer,
					    op_data_size,
					    addr_to)) < 0) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: %s[%08X%08X%08X%08X] __operator_write(dps %d) failed.\n",
				__func__, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3], index);
			goto __out;
		}
	}

	// flush code cache
	if (version == 1 && (op_code_size > 0)) {
		vastai_cmd.run_load_operator.operator_addr = operator_load_v2_cmd->op_code_addr;
		vastai_cmd.run_load_operator.operator_size = operator_load_v2_cmd->op_code_size;
		ret = vaccrt_cmd_run(vacc_dev, dev_process, &vastai_cmd, cmd);
		if (-EINTR == ret) {
			// VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			// 	       "%s: vaccrt_cmd_run interrupted, ret = %d\n",
			// 	       __func__, ret);
		} else if (ret != 0) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"load operator %s[%08X%08X%08X%08X] flush code cache failed.\n",
				operator_manager->name, op_id[0], op_id[1], op_id[2],
				op_id[3]);
		}
		if (ret != 0) {
			goto __out;
		}
	}
	
	// flush data cache
	if (version == 1) {
		vastai_cmd.run_load_operator.operator_addr = operator_load_v2_cmd->op_data_addr;
		vastai_cmd.run_load_operator.operator_size = operator_load_v2_cmd->op_data_size;
	} else {
		vastai_cmd.run_load_operator.operator_addr = operator_load_cmd->operator_addr;
		vastai_cmd.run_load_operator.operator_size = operator_load_cmd->operator_size;
	}
	ret = vaccrt_cmd_run(vacc_dev, dev_process, &vastai_cmd, cmd);
	if (-EINTR == ret) {
		// VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
		// 	       "%s: vaccrt_cmd_run interrupted, ret = %d\n",
		// 	       __func__, ret);
	} else if (ret != 0) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"load operator %s[%08X%08X%08X%08X] flush data cache failed.\n",
			operator_manager->name, op_id[0], op_id[1], op_id[2],
			op_id[3]);
	}

__out:
	mutex_lock(&operator_manager->mutex);
	op_node = __get_operator_node(operator_manager, op_id);
	if (op_node == NULL) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"%s: %s[%08X%08X%08X%08X] is not found after copy_and_load.\n",
			__func__, operator_manager->name, op_id[0], op_id[1],
			op_id[2], op_id[3]);
		ret = -EINVAL;
		mutex_unlock(&operator_manager->mutex);
		return ret;
	}
	// the process who does _copy_load must set op_node->load_state and wake_up(op_node->wait), 
	// whatever the ret result be;
	if (ret == 0) {
		op_node->load_state = op_loaded;
	} else {
		op_node->load_state = op_unload;
	}
	wake_up_interruptible(&op_node->wait);
	mutex_unlock(&operator_manager->mutex);

	return ret;
}
#elif CONFIG_VASTAI_SOC_HW_TYPE==2
// ---------------------------------------------- SG100 operator_load -------------------------------------------------------------
// HOST_DDR --- COPY ---> DEVICE_SHARED_DDR
// DEVICE_SHARED_DDR --- COPY ---> DSP_DDR
// --------------------------------------------------------------------------------------------------------------------------------
// vastai_cmd.run_load_operator_sg100.src(64) 				---- address for HOST_DDR
// vastai_cmd.run_load_operator_sg100.dst(64) 				---- address for DEVICE_SHARED_DDR
// vastai_cmd.run_load_operator_sg100.operator_addr(32)		---- entry address for DSP_OPERATOR (operator_addr)
// --------------------------------------------------------------------------------------------------------------------------------
// cmd_copy_operator_desc.src_offset(64)					---- address for DEVICE_SHARED_DDR - DEVICE_SHARED_BASE
// cmd_copy_operator_desc.dst_offset(64)					---- entry address for DSP_OPERATOR (operator_addr) - dsp_base
// cmd_copy_operator_desc.operator_addr(32)					---- entry address for DSP_OPERATOR (operator_addr)
// --------------------------------------------------------------------------------------------------------------------------------
int operator_load(struct vastai_cdev *vacc_dev, struct dev_process *dev_process,
		  const operator_load_cmd_t *operator_load_cmd)
{
	int ret = 0;
	unsigned int cmd = 0;
	union vastai_cmd vastai_cmd;
	struct operator_manager *operator_manager = NULL;
	struct operator_node *op_pos = NULL, *op_node = NULL;
	uint32_t op_type = operator_load_cmd->operator_type;
	struct vastai_zone *zone = vacc_dev->zone;
	uint64_t addr = 0, addr_min = 0, addr_max = 0;
	uint64_t dsp_base = 0, dsp_size = 0;
	uint32_t dsp_entry = 0;
	uint8_t dsp_num = 0;
	// void __user *buffer = (void __user *)operator_load_cmd->src_addr;

	if (op_type == vdsp_operator) {
		dsp_base = zone[zone_vdsp_operator].bank[0].base;
		dsp_size = zone[zone_vdsp_operator].bank[0].size;
		dsp_entry = zone[zone_vdsp_operator].entry;
		dsp_num = vacc_dev->soc.vdsp_num;
		addr = operator_load_cmd->operator_addr;
		addr_min = zone[zone_vdsp_operator].entry;
		addr_max = zone[zone_vdsp_operator].entry +
			   zone[zone_vdsp_operator].bank[0].size;
	} else if (op_type == odsp_operator) {
		dsp_base = zone[zone_odsp_operator].bank[0].base;
		dsp_size = zone[zone_odsp_operator].bank[0].size;
		dsp_entry = zone[zone_odsp_operator].entry;
		dsp_num = vacc_dev->soc.core_num;
		addr = operator_load_cmd->operator_addr;
		addr_min = zone[zone_odsp_operator].entry;
		addr_max = zone[zone_odsp_operator].entry +
			   zone[zone_odsp_operator].bank[0].size;
	} else {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid operator type = %d.\n", __func__,
			       op_type);
		return -EINVAL;
	}

	if (dsp_num == 0) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: vdsp_num is zero.\n", __func__);
		return -EINVAL;
	}

	if (addr < addr_min || addr >= addr_max) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"[vaerr] operator_addr:0x%llx, min:0x%llx, max:0x%llx\n",
			addr, addr_min, addr_max);
		return -EINVAL;
	}

	operator_manager = &vacc_dev->operator_manager[op_type];

	mutex_lock(&operator_manager->mutex);
	list_for_each_entry (op_pos, &operator_manager->head, node) {
		if (memcmp((void *)op_pos->id, (void *)operator_load_cmd->id,
			   OP_ID_BYTE_LEN) == 0) {
			op_node = op_pos;
			break;
		}
	}

	if (op_node == NULL) {
		ret = -EINVAL;
		goto __out;
	}

	// if (op_node->addr != operator_load_cmd->addr) {
	// 	ret = -EINVAL;
	// 	goto __out;
	// }

	if (op_node->load_state == op_loaded) {
		// VASTAI_PCI_INFO(
		// 	vacc_dev->pci_info, vacc_dev->die_id,
		// 	"operator [%08X%08X%08X%08X] has been loaded into dsp.\n",
		// 	op_node->id[0], op_node->id[1], op_node->id[2],
		// 	op_node->id[3]);
		goto __out;
	}

	// VASTAI_PCI_INFO(
	// 		vacc_dev->pci_info, vacc_dev->die_id,
	// 		"load operator [%08X%08X%08X%08X] into dsp.\n",
	// 		op_node->id[0], op_node->id[1], op_node->id[2],
	// 		op_node->id[3]);

	// __operator_write copy elf(operator.bin) from host_ddr to device_share_ddr
	ret = __operator_write(vacc_dev,
			       (void __user *)operator_load_cmd->src_addr,
			       operator_load_cmd->operator_size,
						   operator_load_cmd->dst_addr);
	if (ret < 0) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: __operator_write failed.\n", __func__);
		goto __out;
	}

	/****************************************************************************************************
	 * cmd_copy_operator_desc.src_offset = vastai_cmd.run_load_operator_sg100.operator_addr - dsp_base;
	 * cmd_copy_operator_desc.dst_offset = vastai_cmd.run_load_operator_sg100.dst;
	 * cmd_copy_operator_desc.operator_addr = vastai_cmd.run_load_operator_sg100.operator_addr
	 ***************************************************************************************************/
	vastai_cmd.run_load_operator_sg100.dev = operator_load_cmd->dev;
	vastai_cmd.run_load_operator_sg100.pid = operator_load_cmd->pid;
	vastai_cmd.run_load_operator_sg100.src =
		operator_load_cmd->dst_addr - VA_DDR_BASE_ADDR;
	vastai_cmd.run_load_operator_sg100.dst =
		operator_load_cmd->operator_addr - dsp_entry;
	vastai_cmd.run_load_operator_sg100.operator_size =
		operator_load_cmd->operator_size;
	vastai_cmd.run_load_operator_sg100.operator_addr =
		operator_load_cmd->operator_addr;
	if (operator_load_cmd->operator_type == vdsp_operator) {
		cmd = CMD_COPY_VDSP_OPERATOR;
	} else if (operator_load_cmd->operator_type == odsp_operator) {
		cmd = CMD_COPY_ODSP_OPERATOR;
	}

	ret = vaccrt_cmd_run(vacc_dev, dev_process, &vastai_cmd, cmd);
	if (ret == 0) {
		op_node->load_state = op_loaded;
	} else {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"load %s_operator [%08X%08X%08X%08X] into dsp failed.\n",
			(vdsp_operator == op_type) ? "vdsp" : "odsp",
			op_node->id[0], op_node->id[1], op_node->id[2],
			op_node->id[3]);
	}

__out:
	mutex_unlock(&operator_manager->mutex);
	
	return ret;
}
#else
#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
#endif

static inline int _ref_process_is_in_opnode_head(pid_t pid,
						 struct operator_node *op_node)
{
	int ret = 0;
	struct ref_process *ref_process = NULL;
	mutex_lock(&op_node->mutex_ref_process);
	list_for_each_entry (ref_process, &op_node->ref_process_head, node) {
		if (ref_process->pid == pid) {
			ret = 1;
			break;
		}
	}
	mutex_unlock(&op_node->mutex_ref_process);
	return ret;
}

int operator_manager_register_op(struct vastai_cdev *vacc_dev,
				 struct dev_process *dev_process,
				 void *cmd_buffer, int version)
{
    int ret = 0;
    struct operator_node *pos_op = NULL, *operator_node = NULL;
    struct ref_process *ref_process = NULL; // *pos_process = NULL, 
    struct ref_operator_node *pos_rof = NULL, *ref_operator_node = NULL;
    uint64_t addr = 0;
    uint64_t size = 0; // operator_register_cmd->operator_size;
	uint64_t code_addr = 0;
    uint64_t code_size = 0; // operator_register_cmd->operator_size;
	uint32_t op_id[MD5_OPERATOR_ID_LEN] = { 0 };
    pid_t pid = dev_process->pid;
	struct operator_manager *operator_manager = NULL;
	struct mutex *mutex_operator_head = NULL;
	struct list_head *operator_head = NULL;
	atomic_t *operator_ref_num = NULL;
	operator_register_cmd_t *operator_register_cmd = NULL;
	operator_register_v2_cmd_t *operator_register_v2_cmd = NULL;
	u32 operator_type = 0;
	
	operator_register_v2_cmd = (operator_register_v2_cmd_t *)cmd_buffer;
	operator_register_cmd = (operator_register_cmd_t *)cmd_buffer;
	operator_type = operator_register_cmd->operator_type;
	memcpy((void *)op_id, (void *)operator_register_cmd->id,
	       sizeof(u32) * MD5_OPERATOR_ID_LEN);

	if (version == 1) {
		size = operator_register_v2_cmd->data_size;
		code_size = operator_register_v2_cmd->code_size;
	} else {
		size = operator_register_cmd->operator_size;
	}

	if (operator_type >= operator_count) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid operator type = %d.\n", __func__,
			       operator_type);
		ret = -EINVAL;
		return ret;
	}

	operator_manager = &vacc_dev->operator_manager[operator_type];
	mutex_operator_head = &dev_process->mutex_operator_head[operator_type];
	operator_head = &dev_process->operator_head[operator_type];
	operator_ref_num = &dev_process->operator_ref_num[operator_type];

	mutex_lock(mutex_operator_head);
	list_for_each_entry (pos_rof, operator_head, node) {
		if (memcmp((void *)pos_rof->id, (void *)op_id,
			   OP_ID_BYTE_LEN) == 0) {
			ref_operator_node = pos_rof;
			break;
		}
    }

    mutex_lock(&operator_manager->mutex);
    list_for_each_entry (pos_op, &operator_manager->head, node) {
	    if (memcmp((void *)pos_op->id, (void *)op_id, OP_ID_BYTE_LEN) ==
		0) {
		    operator_node = pos_op;
		    break;
	    }
    }
	// mutex_unlock(&operator_manager->mutex);

    if (ref_operator_node) {
		if (operator_node) {
			// ref_operator_node exist in dev_process->operator_head, operator_node exist in operator_manager->head
			// return directly, do nothing;
			ret = op_state_exist_create;
		} else {
			// maybe dsp_reset happend re-create
			ret = op_state_re_create;
		}
    } else {
		if (operator_node) {
			// ref_operator_node not exist, operator_node exist, means the operator is registed by other dev_process
			// create ref_process into operator_node->process_head, inc(operator_node->ref_process_num) then return;
			ret = op_state_attach_create;
		} else {
			// ref_operator_node not exist, operator_node not exist, new-create
			ret = op_state_new_create;
		}
    }

    if (ret == op_state_new_create || ret == op_state_re_create) {
		//  1. allocate ddr address
		//  2. allocate operator_node and init it
		//  3. attach ref_process in operator_node->process_head
		//  4. insert ref_operator_node into dev_process->operator_head (re/new)
		//  5. insert operator_node into operator_manager->head

		//  1. allocate ddr address
		if (__alloc_ddr(operator_manager, &addr, &size, &code_addr,
				&code_size) != 0) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: pid[%d] %s[%08X%08X%08X%08X] allocate ddr failed, data_size = 0x%llX, code_size = 0x%llX\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3], size, code_size);
			ret = -ENOMEM;
			goto __out;
		} else {
			// 1.1 kzalloc all need first and check null
			operator_node = kzalloc(sizeof(struct operator_node),
						GFP_KERNEL);
			if (operator_node == NULL) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"%s:%d %s[%08X%08X%08X%08X] kzalloc(operator_node) failed.\n",
					__func__, __LINE__,
					operator_manager->name, op_id[0],
					op_id[1], op_id[2], op_id[3]);
				__free_ddr(operator_manager, addr, code_addr);
				ret = -ENOMEM;
				goto __out;
			}

			ref_process =
				kzalloc(sizeof(struct ref_process), GFP_KERNEL);
			if (ref_process == NULL) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"%s:%d %s[%08X%08X%08X%08X] kzalloc(ref_process) failed.\n",
					__func__, __LINE__,
					operator_manager->name, op_id[0],
					op_id[1], op_id[2], op_id[3]);
				__free_ddr(operator_manager, addr, code_addr);
				kfree(operator_node);
				ret = -ENOMEM;
				goto __out;
			}

			if (ret == op_state_new_create) {
				ref_operator_node = kzalloc(
					sizeof(struct ref_operator_node),
					GFP_KERNEL);
				if (ref_operator_node == NULL) {
					VASTAI_PCI_ERR(
						vacc_dev->pci_info,
						vacc_dev->die_id,
						"%s:%d %s[%08X%08X%08X%08X] kzalloc(ref_operator_node) failed.\n",
						__func__, __LINE__,
						operator_manager->name,
						op_id[0], op_id[1], op_id[2],
						op_id[3]);
					__free_ddr(operator_manager, addr, code_addr);
					kfree(operator_node);
					kfree(ref_process);
					ret = -ENOMEM;
					goto __out;
				}
			}

			//  2. allocate operator_node and init it
			__operator_node_init(operator_node, op_id, addr, size,
					     code_addr, code_size);

			//  3. attach ref_process in operator_node->process_head
			mutex_lock(&operator_node->mutex_ref_process);
			ref_process->pid = pid;
			list_add_tail(&ref_process->node,
				      &operator_node->ref_process_head);
			atomic_inc(&operator_node->process_ref_num);
			mutex_unlock(&operator_node->mutex_ref_process);

			//  4. insert ref_operator_node into dev_process->operator_head (re/new)
			if (ret == op_state_new_create) {
				memcpy((void *)ref_operator_node->id,
				       (void *)op_id, OP_ID_BYTE_LEN);
				list_add_tail(&ref_operator_node->node,
					      operator_head);
				atomic_inc(operator_ref_num);
			}

			// 5. insert operator_node into operator_manager->head
			list_add_tail(&operator_node->node,
				      &operator_manager->head);
			atomic_inc(&operator_manager->operator_num);
		}
    } else if (ret == op_state_attach_create) {
		// prev
		ref_operator_node =
			kzalloc(sizeof(struct ref_operator_node), GFP_KERNEL);
		if (ref_operator_node == NULL) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s:%d %s[%08X%08X%08X%08X] kzalloc(ref_operator_node) failed.\n",
				__func__, __LINE__, operator_manager->name,
				op_id[0], op_id[1], op_id[2], op_id[3]);
			ret = -ENOMEM;
			goto __out;
		}

		// inc process_ref_num, check current dev_process->pid is in ref_process_head ?
		// do check, give warning if the ref_process has exist
		if (unlikely(_ref_process_is_in_opnode_head(
				     pid, operator_node) == 1)) {
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: %s[%08X%08X%08X%08X] ref_process[%d] should not exist in operator_node->ref_process_head here.\n",
				__func__, operator_manager->name, pid, op_id[0],
				op_id[1], op_id[2], op_id[3]);
		} else {
			ref_process =
				kzalloc(sizeof(struct ref_process), GFP_KERNEL);
			if (ref_process == NULL) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"%s:%d %s[%08X%08X%08X%08X] kzalloc(ref_process) failed.\n",
					__func__, __LINE__,
					operator_manager->name, op_id[0],
					op_id[1], op_id[2], op_id[3]);
				kfree(ref_operator_node);
				ret = -ENOMEM;
				goto __out;
			}

			mutex_lock(&operator_node->mutex_ref_process);
			ref_process->pid = pid;
			list_add_tail(&ref_process->node,
				      &operator_node->ref_process_head);
			atomic_inc(&operator_node->process_ref_num);
			mutex_unlock(&operator_node->mutex_ref_process);
		}

		// insert ref_operator_node into dev_process->operator_head
		memcpy((void *)ref_operator_node->id, (void *)op_id,
		       OP_ID_BYTE_LEN);
		list_add_tail(&ref_operator_node->node, operator_head);
		atomic_inc(operator_ref_num);

		addr = operator_node->addr;
		size = operator_node->size;
		code_addr = operator_node->code_addr;
		code_size = operator_node->code_size;
    } else if (ret == op_state_exist_create) {
		// check ref_process in operator_node->head, it should be exist at here.
		if (unlikely(_ref_process_is_in_opnode_head(
				     pid, operator_node) == 0)) {
			// CASE: dsp_reset happend, operator_node[op_id] and ref_process[current_pid] be cleaned, other process new_create this operator_node[op_id] at that time,
			//		 when current process call operator_register, we will find ref_process[current_pid] is not in operator_node[op_id]->ref_process_head list, so we
			//		 will get into such case to print info message;
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: ref_process[%d] %s[%08X%08X%08X%08X] should exist in operator_node->ref_process_head here, maybe caused by dsp_reset.\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);

			ref_process =
				kzalloc(sizeof(struct ref_process), GFP_KERNEL);
			if (ref_process == NULL) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"%s:%d %s[%08X%08X%08X%08X] kzalloc(ref_process) failed.\n",
					__func__, __LINE__,
					operator_manager->name, op_id[0],
					op_id[1], op_id[2], op_id[3]);
				ret = -ENOMEM;
				goto __out;
			}

			mutex_lock(&operator_node->mutex_ref_process);
			ref_process->pid = pid;
			list_add_tail(&ref_process->node,
				      &operator_node->ref_process_head);
			atomic_inc(&operator_node->process_ref_num);
			mutex_unlock(&operator_node->mutex_ref_process);
		}
		addr = operator_node->addr;
		size = operator_node->size;
		code_addr = operator_node->code_addr;
		code_size = operator_node->code_size;
	}

	if (ret >= op_state_new_create && ret <= op_state_attach_create) {

		if (version == 1) {
			operator_register_v2_cmd->data_addr = addr;
			operator_register_v2_cmd->data_size = size;
			operator_register_v2_cmd->code_addr = code_addr;
			operator_register_v2_cmd->code_size = code_size;
			operator_register_v2_cmd->state = ret;
		} else {
			operator_register_cmd->operator_addr = addr;
			operator_register_cmd->operator_size = size;
			operator_register_cmd->state = ret;
		}
		
		ret = 0;
	} else {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid op_state = %d\n", __func__, ret);
		if (version == 1) {
			operator_register_v2_cmd->state = op_state_unknow;
		} else {
			operator_register_cmd->state = op_state_unknow;
		}
		ret = -EAGAIN;
	}

__out:

	mutex_unlock(&operator_manager->mutex);

    mutex_unlock(mutex_operator_head);

	// operator_print(vacc_dev);

    return ret;
}

int operator_manager_unregister_op(
	struct vastai_cdev *vacc_dev, struct dev_process *dev_process,
	operator_unregister_cmd_t *operator_unregister_cmd)
{
    int ret = 0;
    struct operator_node *pos_op = NULL, *operator_node = NULL;
    struct ref_process *pos_process = NULL, *ref_process = NULL;
    struct ref_operator_node *pos_rof = NULL, *ref_operator_node = NULL;
	struct operator_manager *operator_manager = NULL;
	struct mutex *mutex_operator_head = NULL;
	struct list_head *operator_head = NULL;
	atomic_t *operator_ref_num = NULL;
	pid_t pid = dev_process->pid;
	int ref_operator_node_found = 0;
	uint32_t op_id[MD5_OPERATOR_ID_LEN] = { 0 };
	u32 operator_type = operator_unregister_cmd->operator_type;
	memcpy((void *)op_id, (void *)operator_unregister_cmd->id,
	       sizeof(u32) * MD5_OPERATOR_ID_LEN);

	if (operator_type >= operator_count) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid operator type = %d.\n", __func__,
			       operator_type);
		ret = -EINVAL;
		return ret;
	}

	operator_manager = &vacc_dev->operator_manager[operator_type];
	mutex_operator_head = &dev_process->mutex_operator_head[operator_type];
	operator_head = &dev_process->operator_head[operator_type];
	operator_ref_num = &dev_process->operator_ref_num[operator_type];

	mutex_lock(mutex_operator_head);
	list_for_each_entry (pos_rof, operator_head, node) {
		if (memcmp((void *)pos_rof->id, (void *)op_id,
			   OP_ID_BYTE_LEN) == 0) {
			ref_operator_node = pos_rof;
			ref_operator_node_found = 1;
			break;
		}
    }

    mutex_lock(&operator_manager->mutex);
    list_for_each_entry (pos_op, &operator_manager->head, node) {
	    if (memcmp((void *)pos_op->id, (void *)op_id, OP_ID_BYTE_LEN) ==
		0) {
		    operator_node = pos_op;
		    break;
	    }
    }

    if (ref_operator_node) {
		atomic_dec(operator_ref_num);
		list_del(&ref_operator_node->node);
		kfree(ref_operator_node);
		ref_operator_node = NULL;
    } else {
		// WARNING, some error happend
		// ref_operator_node = 0, operator_node = 0 ---> maybe double unregister-ioctl be called
		// ref_operator_node = 0, operator_node = 1 ---> it isn't legal, some error happend

		if (operator_node) {
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: pid[%d] %s[%08X%08X%08X%08X] ref_op_node not exist, but op_node exit, some blind case.\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);
		} else {
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: pid[%d] %s[%08X%08X%08X%08X] ref_op_node not exist, op_node not exit, maybe repeat unregister.\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);
			ret = op_state_repeat_delete;
			goto __out;
		}
    }

    if (operator_node) {
		mutex_lock(&operator_node->mutex_ref_process);
		list_for_each_entry (pos_process,
				     &operator_node->ref_process_head, node) {
			if (pos_process->pid == pid) {
				ref_process = pos_process;
				break;
			}
		}

		if (likely(ref_process)) {
			atomic_dec(&operator_node->process_ref_num);
			list_del(&ref_process->node);
			kfree(ref_process);
			ref_process = NULL;
		} else {
			// CASE: dsp_reset happend, operator_node[op_id] and ref_process[current_pid] be cleaned, other process new_create this operator_node[op_id] at that time,
			//		 when current process call operator_unregister, we will find ref_process[current_pid] is not in operator_node[op_id]->ref_process_head list, so we
			//		 will get into such case to print info message;
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: pid[%d] %s[%08X%08X%08X%08X] ref_process not exist, some blind case, maybe caused by dsp_reset.\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);
		}

		// remove operator_node from [operator_manager->head] first during the mutex_ref_process
		// then release resource(ddr_address and mem)
		if (list_empty(&operator_node->ref_process_head)) {
			list_del(&operator_node->node);
		}
		mutex_unlock(&operator_node->mutex_ref_process);

		// operator_node is not in operator_manager->head, we can release it safe;
		if (list_empty(&operator_node->ref_process_head)) {
			__free_ddr(operator_manager, operator_node->addr,
				   operator_node->code_addr);
			kfree(operator_node);
			atomic_dec(&operator_manager->operator_num);
			operator_node = NULL;
			ret = op_state_abs_delete;
		} else {
			ret = op_state_detach_delete;
		}
    } else {
		// means dsp_reset happend
		// ref_operator_node = 1, operator_node = 0 ---> dsp_reset happend, clean the operator_node left ref_operator_node
		// ref_operator_node = 0, operator_node = 0 ---> previous said double unregister be called.
		if (ref_operator_node_found == 1) {
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"%s: pid[%d] %s[%08X%08X%08X%08X] ref_op_node exist, op_node not exist, maybe dsp_reset.\n",
				__func__, pid, operator_manager->name, op_id[0],
				op_id[1], op_id[2], op_id[3]);
			ret = op_state_reset_delete;
		} else {
			// VASTAI_PCI_INFO(
			// 	vacc_dev->pci_info, vacc_dev->die_id,
			// 	"ref_op_node not exist, op_node not exit, maybe repeat unregister.\n");
			ret = op_state_repeat_delete;
		}
    }

__out:
	if (ret >= op_state_abs_delete && ret <= op_state_detach_delete) {
		operator_unregister_cmd->state = ret;
		ret = 0;
	} else {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: invalid op_state = %d\n", __func__, ret);
		operator_unregister_cmd->state = op_state_unknow;
		ret = -EAGAIN;
	}

	mutex_unlock(&operator_manager->mutex);

    mutex_unlock(mutex_operator_head);

	// operator_print(vacc_dev);

    return ret;
}
