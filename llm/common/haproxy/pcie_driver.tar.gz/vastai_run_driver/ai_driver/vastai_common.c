#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/list.h>
#include <linux/printk.h>
#include <linux/slab.h>
#include <linux/completion.h>
#include <linux/sched/signal.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,11,0)
#include <linux/signal.h>
#else
#include <linux/sched/signal.h>
#endif
#include <linux/uaccess.h>
#include <linux/workqueue.h>
#include <linux/pid_namespace.h>
#include <linux/compat.h>

#include "vastai_common.h"
#include "shm_common.h"
#include "vastai_operator.h"

#include "hw_config.h"
#if CONFIG_VASTAI_SOC_HW_TYPE==2
#include "vastai_udma_engine.h"
#include "vastai_pcie_public.h"

#endif

#include "vatools.h"

static void _dev_process_free_operator(struct vastai_cdev *va_dev,
				       struct dev_process *dev_process)
{
	int i = 0;
	struct mutex *mutex_operator_head = NULL;
	struct list_head *operator_head = NULL;
	atomic_t *operator_ref_num = NULL;
	struct ref_operator_node *ref_op_node = NULL, *ref_op_node_tmp = NULL;

	for (i = 0; i < operator_count; i++) {
		mutex_operator_head = &dev_process->mutex_operator_head[i];
		operator_head = &dev_process->operator_head[i];
		operator_ref_num = &dev_process->operator_ref_num[i];
		mutex_lock(mutex_operator_head);
		list_for_each_entry_safe (ref_op_node, ref_op_node_tmp,
					  operator_head, node) {
			list_del(&ref_op_node->node);
			atomic_dec(operator_ref_num);
			kfree(ref_op_node);
		}
		mutex_unlock(mutex_operator_head);

		operator_manager_detach_process(&va_dev->operator_manager[i],
						dev_process->pid);
	}

	// operator_print(va_dev);
}

extern char zone_name[zone_count][32];
static void _dev_process_free_shm(struct vastai_cdev *va_dev, struct dev_process *dev_process)
{
	shmre_allocator_t *shmre_allocator = NULL;
	struct device_ddr_proxy *device_ddr_proxy = NULL;
	mem_chunk_hnode_t *mem_chunk_hnode = NULL;
	struct hlist_node *tmp_hnode = NULL;
	int bkt = 0;
	uint32_t i = 0;

	for (i = 0; i < zone_count; i++) {
		shmre_allocator = &va_dev->device_ddr_alloc[i];
		device_ddr_proxy = &dev_process->device_ddr_proxy[i];
		mutex_lock(&device_ddr_proxy->mutex);
		hash_for_each_safe (device_ddr_proxy->hash_map, bkt, tmp_hnode,
				    mem_chunk_hnode, node) {
			// printk("%s: free_chunk (data: 0x%lX,  size: 0x%lX)\n",
			//        __func__, mem_chunk_hnode->chunk->data,
			//        mem_chunk_hnode->chunk->size);
			shmre_allocator->free(shmre_allocator,
					      mem_chunk_hnode->chunk);
			hash_del(&mem_chunk_hnode->node);
			kfree(mem_chunk_hnode);
		}
		mutex_unlock(&device_ddr_proxy->mutex);
	}

	// printk("---------------- [device %d] zone usage ----------------\n",
	//        va_dev->soc.vacc_id);
	// printk("%-20s   %-20s   %-20s   %-20s\n", "zone_name", "total_size",
	//        "free_size", "used_size");
	// for (i = 0; i < zone_count; i++) {
	// 	printk("%-20s   0x%-20lx   0x%-20lx   0x%-20lx\n", zone_name[i],
	// 	       va_dev->device_ddr_alloc[i].shmre_alloc_head.total_size,
	// 	       va_dev->device_ddr_alloc[i].shmre_alloc_head.free_size,
	// 	       va_dev->device_ddr_alloc[i].shmre_alloc_head.total_size -
	// 		       va_dev->device_ddr_alloc[i]
	// 			       .shmre_alloc_head.free_size);
	// }
}

static void _dev_process_free_vdsp_used_count(struct vastai_cdev *va_dev,
					      struct dev_process *dev_process)
{
	if (dev_process->vdsp_used_count) {
		uint32_t i = 0;
		mutex_lock(&va_dev->vdsp_used_counter.mutex);
		for (i = 0; i < va_dev->vdsp_used_counter.vdsp_num; i++) {
			if (dev_process->vdsp_used_count[i] >= 0) {
				va_dev->vdsp_used_counter.used_counts[i] -=
					dev_process->vdsp_used_count[i];
				if (va_dev->vdsp_used_counter.used_counts[i] <
				    0) {
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: pid[%d]: vdsp_used_counter.used_counts[%d] = %d invalid\n",
						__func__, dev_process->pid, i,
						va_dev->vdsp_used_counter
							.used_counts[i]);
					va_dev->vdsp_used_counter
						.used_counts[i] = 0;
				}
			} else {
				VASTAI_PCI_ERR(
					va_dev->pci_info, va_dev->die_id,
					"%s: pid[%d]: dev_process->vdsp_used_count[%d] = %d invalid\n",
					__func__, dev_process->pid, i,
					dev_process->vdsp_used_count[i]);
			}
		}
		mutex_unlock(&va_dev->vdsp_used_counter.mutex);
		kfree(dev_process->vdsp_used_count);
		dev_process->vdsp_used_count = NULL;
	}
}

static void _dev_process_free_out_desc(struct vastai_cdev *va_dev,
				       struct dev_process *dev_process)
{
	struct dev_out_desc *out_desc = NULL, *out_desc_temp = NULL;
	if (atomic_read(&dev_process->out_ref_num)) {
		// VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
		// 	"%s: pid:%u out_ref_num = %d\n", __func__,
		// 	dev_process->pid,
		// 	atomic_read(&dev_process->out_ref_num));
		mutex_lock(&dev_process->mutex);
		list_for_each_entry_safe (out_desc, out_desc_temp,
					  &dev_process->head, node) {
			list_del(&out_desc->node);
			kfree(out_desc);
		}
		mutex_unlock(&dev_process->mutex);
	}
}

static void _dev_process_free_stream(struct vastai_cdev *va_dev,
				     struct dev_process *dev_process)
{
	stream_node_t *stream_node = NULL, *stream_node_temp = NULL;
	struct dev_out_desc *out_desc = NULL, *out_desc_temp = NULL;
	mutex_lock(&dev_process->stream_mutex);
	// if (atomic_read(&dev_process->stream_num)) {
	// 	VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
	// 		"%s: pid:%u stream_num = %d\n", __func__,
	// 		dev_process->pid,
	// 		atomic_read(&dev_process->stream_num));
	// }
	list_for_each_entry_safe (stream_node, stream_node_temp,
				  &dev_process->stream_head, node) {
		
		// clean out_desc in list_head_out_desc 
		mutex_lock(&stream_node->mutex_out_desc);
		list_for_each_entry_safe (out_desc, out_desc_temp,
					&stream_node->head_out_desc, node) {
			list_del(&out_desc->node);
			kfree(out_desc);
		}
		mutex_unlock(&stream_node->mutex_out_desc);

		list_del(&stream_node->node);
		kfree(stream_node);
		if (unlikely(atomic_dec_if_positive(&dev_process->stream_num) <
			     0)) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: pid:%u failed to stream_num--\n",
				       __func__, dev_process->pid);
		}
	}
	mutex_unlock(&dev_process->stream_mutex);
}

static void __pre_cancel_process_delayed_work(struct vastai_cdev *va_dev,
					      struct dev_process *dev_process)
{
	list_del(&dev_process->node);
	if (list_empty(&va_dev->dev_trans_ai->head)) {
		va_dev->mmap.state = mmap_idle;
	}
	// free out_desc, op, shm, vdsp_used_count, stream for dev_process in advance
	_dev_process_free_out_desc(va_dev, dev_process);
	_dev_process_free_operator(va_dev, dev_process);
	_dev_process_free_shm(va_dev, dev_process);
	_dev_process_free_vdsp_used_count(va_dev, dev_process);
	_dev_process_free_stream(va_dev, dev_process);
	if (unlikely(atomic_dec_if_positive(
			     &va_dev->dev_trans_ai->dev_process_num) < 0)) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: dev_process_num invalid.\n", __func__);
	}

	if (cancel_delayed_work_sync(&dev_process->work)) {
		// cancel_delayed_work_sync succeed, remove from timer_list,
		// pending state, release dev_process
		kfree(dev_process);
	} /* else {
		// cancel_delayed_work_sync failed, because the work has enqueued wq, 
		// it will be carry-out by flush_workqueue
	} */
}

static void vaccrt_ai_out_work(struct work_struct *work)
{
	int is_find = 0, is_insert = 0, is_cancel_kernel_ret = 0;
	struct vastai_cdev *va_dev = NULL;
	struct dev_process *dev_process = NULL;
	struct dev_out_desc *out_desc = NULL;
	stream_node_t *stream_node = NULL, *stream_node_temp = NULL;
	atomic_t *p_ref_num = NULL;

	out_desc = container_of(work, struct dev_out_desc, work);
	va_dev = (struct vastai_cdev *)out_desc->ctxt;

	if (out_desc->dev & VASTAI_CANCEL_KERNEL_DEV_MASK)
		is_cancel_kernel_ret = 1;

	if (out_desc->context_id >> 31) {
		wake_up_interruptible(&va_dev->wait_runsteam);
		VASTAI_PCI_DBG(va_dev->pci_info, va_dev->die_id,
			       "%s: wake up va_dev->wait_runsteam\n", __func__);
	}

	mutex_lock(&va_dev->dev_trans_ai->mutex);
	list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head, node) {
		if (dev_process->pid == out_desc->pid) {

			if (out_desc->dev == 0 || is_cancel_kernel_ret) {
				p_ref_num = &dev_process->ker_ref_num;
			} else {
				p_ref_num = &dev_process->run_ref_num;
			}

			if (out_desc->context_id >> 31) {
				if (unlikely(atomic_dec_if_positive(p_ref_num) < 0))
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: pid:%u failed to run_ker_ref_num--\n",
						__func__, dev_process->pid);
				if (unlikely(atomic_inc_return( &dev_process->out_ref_num) > VASTAI_MAX_OUT_COUNT))
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: pid:%u failed to out_ref_num++\n",
						__func__, dev_process->pid);
			}
			
			if (is_cancel_kernel_ret) {
				if (unlikely(!atomic_read(&dev_process->run_ref_num))) { // && unlikely(!atomic_read(&dev_process->ker _ref_num))
					// CANCEL_KERNEL_CMD return out_desc
					// run _ref_num > 0 run_stream task can not be cancelled by cmcu, so we will wait until delayed_work be excuted
					// ker _ref_num == 0, means task is empty in host, delayed_work can be cancelled
					__pre_cancel_process_delayed_work(va_dev, dev_process);
				}
			} else {
				// if current proc_state 0 >> 1, assert delays work queue to execute after this
				if (likely(!dev_process->proc_state)) {
					if (atomic_read(&dev_process->stream_num) == 0) {
						mutex_lock(&dev_process->mutex);
						list_add_tail(&out_desc->node, &dev_process->head);
						mutex_unlock(&dev_process->mutex);
						wake_up_interruptible(&dev_process->wait);
						is_insert = 1;
					} else {
						mutex_lock(&dev_process->stream_mutex);
						stream_node = NULL;
						list_for_each_entry (stream_node_temp, &dev_process->stream_head, node) {
							if (stream_node_temp->stream_id == out_desc->stream_id) {
								stream_node = stream_node_temp;
								break;
							}
						}
						if (stream_node) {
							mutex_lock(&stream_node->mutex_out_desc);
							list_add_tail(&out_desc->node, &stream_node->head_out_desc);
							mutex_unlock(&stream_node->mutex_out_desc);
							wake_up_interruptible(&stream_node->wait);
							is_insert = 1;
						}
						mutex_unlock(&dev_process->stream_mutex);
					}
				} else {
					if (unlikely(!atomic_read(&dev_process->run_ref_num)) 
						&& unlikely(!atomic_read(&dev_process->ker_ref_num))) {
						__pre_cancel_process_delayed_work(va_dev, dev_process);
					}
				}
			}
			is_find = 1;
			break;
		}
	}
	mutex_unlock(&va_dev->dev_trans_ai->mutex);

	if (unlikely(!is_insert)) {
		if (unlikely(!is_find))
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: pid:%u failed to get process\n",
				       __func__, out_desc->pid);
		kfree(out_desc);
	}
}

static void vaccrt_ai_del_work(struct work_struct *work)
{
	struct vastai_cdev *va_dev = NULL;
	struct dev_process *dev_process = NULL;

	dev_process = container_of((struct delayed_work *)work,
				   struct dev_process, work);
	va_dev = (struct vastai_cdev *)dev_process->ctxt;

	// note: proc_state == 1
	mutex_lock(&va_dev->dev_trans_ai->mutex);
	if ((dev_process->node).next != LIST_POISON1 || (dev_process->node).prev != LIST_POISON2) {
		list_del(&dev_process->node);
		if (unlikely(atomic_dec_if_positive(
				     &va_dev->dev_trans_ai->dev_process_num) <
			     0)) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: dev_process_num invalid.\n",
				       __func__);
		}
	}
	if (list_empty(&va_dev->dev_trans_ai->head)) {
		va_dev->mmap.state = mmap_idle;
	}
	mutex_unlock(&va_dev->dev_trans_ai->mutex);

	if (unlikely(atomic_read(&dev_process->run_ref_num)))
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u dev_process run_ref_num > 0\n",
				__func__, dev_process->pid);
	
	if (unlikely(atomic_read(&dev_process->ker_ref_num)))
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u dev_process ker_ref_num > 0\n",
				__func__, dev_process->pid);

	// free out_desc, op, shm, vdsp_used_count, stream for dev_process
	_dev_process_free_out_desc(va_dev, dev_process);
	_dev_process_free_operator(va_dev, dev_process);
	_dev_process_free_shm(va_dev, dev_process);
	_dev_process_free_vdsp_used_count(va_dev, dev_process);
	_dev_process_free_stream(va_dev, dev_process);

	kfree(dev_process);
}

#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_ai_reset_handler(u32 die_index, u32 core_bit, reset_event event)
{
	struct vastai_pci_info *pcie_dev = NULL;
	struct vastai_cdev *vacc_dev = NULL;
	int dsp_e = 0;
	union die_index_data did = { .val = (u32)die_index };

	pcie_dev = get_vastai_pci_device_info(did.dev_id);
	if (!pcie_dev) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: invalid die_index = %X\n", __func__,
			       die_index);
		return -1;
	}

	if (event == RESET_END || event == RESET_START) {
		list_for_each_entry (
			vacc_dev,
			&((struct vastai_pci_info *)pcie_dev)->vacc_dev_head,
			vacc_dev_node) {
			if (vacc_dev->die_index == die_index) {
				wake_up_interruptible(&vacc_dev->wait_runsteam);
				VASTAI_PCI_DBG(
					vacc_dev->pci_info, vacc_dev->die_id,
					"%s: wake up vacc_dev->wait_runsteam\n",
					__func__);
				break;
			}
		}
	}

	if (RESET_START != event) {
		// ignore event not cared
		return 0;
	}

	switch (core_bit) {
		case CORE_POINT_ODSP0:
		case CORE_POINT_ODSP1:
		case CORE_POINT_ODSP2:
		case CORE_POINT_ODSP3:
		case CORE_POINT_ODSP4:
		case CORE_POINT_ODSP5:
		case CORE_POINT_ODSP6:
		case CORE_POINT_ODSP7:
			dsp_e = 0;
			break;
		case CORE_POINT_VDSP0:
		case CORE_POINT_VDSP1:
		case CORE_POINT_VDSP2:
		case CORE_POINT_VDSP3:
			dsp_e = 1;
			break;
		case CORE_TOTAL_NUM:	// board-level reset
			dsp_e = 2;
			break;
		default:
			// ignore core_bit not cared
			return 0;
	}

	list_for_each_entry (
		vacc_dev, &((struct vastai_pci_info *)pcie_dev)->vacc_dev_head,
		vacc_dev_node) {
		if (vacc_dev->die_index == die_index) {
			if (dsp_e == 0) {
				on_odsp_reset_handle(vacc_dev, core_bit);
			} else if (dsp_e == 1) {
				on_vdsp_reset_handle(vacc_dev, core_bit);
			} else if (dsp_e == 2) {
				on_odsp_reset_handle(vacc_dev, core_bit);
				on_vdsp_reset_handle(vacc_dev, core_bit);
			}
			break;
		}
	}

	return 0;
}
#endif
int vaccrt_ai_trans_call(void *pci_dev, u32 die_index, int irq,
				void *ctxt, void *out)
{
	struct vastai_cdev *va_dev = (struct vastai_cdev *)ctxt;
	struct dev_out_desc *out_desc =
		kzalloc(sizeof(struct dev_out_desc), GFP_ATOMIC);

	if (!out_desc) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: can not get buf\n", __func__);
		BUG_ON(!out_desc);
	}
	memcpy(out_desc, out, sizeof(struct out_desc));
	// done
	out_desc->ctxt = ctxt;
	INIT_WORK(&out_desc->work, vaccrt_ai_out_work);
	queue_work(va_dev->dev_trans_ai->workqueue, &out_desc->work);
	// schedule_work(&out_desc->work);

	return 0;
}

// void vastai_pci_resource_recycling(struct work_struct *work)
// {
// 	struct out_desc *out_desc = NULL;
// 	struct vastai_cdev *va_dev = NULL;
// 	out_desc = container_of(work, struct out_desc, dma_work);
// 	va_dev = (struct vastai_cdev *)out_desc->ctxt;
// 	if(va_dev->fasync){
		// kill_fasync(&va_dev->fasync,SIGIO,POLL_HUP);
//     }
// }
int vaccrt_map_read(struct vastai_cdev *va_dev, char __user *buffer,
		    size_t lenth, loff_t pos)
{
	int ret = 0;
	void *data = NULL;
	if (!va_dev) {
		return -EINVAL;
	}

	data = kzalloc(lenth, GFP_KERNEL);
	if (!data) {
		VASTAI_PCI_ERR(
			va_dev->pci_info, va_dev->die_id,
			"[vaerr] %s: failed to kzalloc dma_data_struct\n",
			__func__);
		ret = -ENOMEM;
		goto out;
	}
	/* TODO : pls tell pcie driver which pcie device and which die */
	ret = vastai_pci_mem_read(va_dev->pci_info, va_dev->die_index, pos,
				  data, lenth);
	if (ret)
		goto out;
	ret = vaccrt_ai_copy_to_user(buffer, data, lenth);
	if (ret) {
		ret = -EFAULT;
		goto out;
	}

out:
	kfree(data);
	return ret;
}

size_t vaccrt_add_read_queue(struct vastai_cdev *va_dev,
			     struct queue_desc *desc)
{
	union core_bitmap core_id = { .val = 0x0 };
	int ret = 0;
	void *vir_addr = desc->buffer;
	u64 dev_addr = desc->pos;
	size_t dma_lenth = desc->lenth;
	struct vastai_dmadesc *dmadesc;
	int dma_desc_unit = 0;
	pid_t pid = task_tgid_nr(current);

	dma_desc_unit = DIV_ROUND_UP(desc->lenth, VASTAI_MAX_DMA_BUF);

	dmadesc = kzalloc(sizeof(struct vastai_dmadesc) * dma_desc_unit,
			   GFP_KERNEL);
	if (!dmadesc)
		return -ENOMEM;

	if (iommu_is_enable(va_dev->pci_info) &&
	    ((u64)vir_addr % PAGE_SIZE == 0)) {
		#if CONFIG_VASTAI_SOC_HW_TYPE==1
		ret = vastai_pci_dma_transfer_by_uaddr(
			va_dev->pci_info, va_dev->die_index, core_id, 0,
			dev_addr, (u64)vir_addr, dma_lenth);
		#elif CONFIG_VASTAI_SOC_HW_TYPE==2
		ret = vastai_sdma_transfer_by_uaddr(
			va_dev->pci_info, va_dev->die_index, core_id, 0,
			dev_addr, (u64)vir_addr, dma_lenth);
		#else
		#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
		#endif
	} else {
		int i = 0;
		for (i = 0; dma_lenth > 0; i++) {
			dmadesc[i].is_src_dma_addr = 0;
			dmadesc[i].is_host_to_dev = 0;
			dmadesc[i].is_src_not_user_mem = 0;
			dmadesc[i].host_addr.vir_addr = vir_addr;
			dmadesc[i].dev_addr = dev_addr;

			if (dma_lenth < VASTAI_MAX_DMA_BUF) {
				dmadesc[i].dma_lenth = dma_lenth;
			} else {
				dmadesc[i].dma_lenth = VASTAI_MAX_DMA_BUF;
			}

			vir_addr = (void *)((u64)vir_addr + dmadesc[i].dma_lenth);
			dev_addr += dmadesc[i].dma_lenth;
			dma_lenth -= dmadesc[i].dma_lenth;
		}
		#if CONFIG_VASTAI_SOC_HW_TYPE==1
		ret = vastai_pci_dma_transfer_sync_pid(va_dev->pci_info,
						       va_dev->die_index,
						       core_id, dmadesc, i,
						       pid);
		#elif CONFIG_VASTAI_SOC_HW_TYPE==2
		ret = vastai_sdma_transfer_sync_pid(va_dev->pci_info,
						       va_dev->die_index,
						       core_id, dmadesc, i,
						       pid);
		#else
		#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
		#endif
	}

	kfree(dmadesc);
	if (ret < 0) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "[vaerr] %s: dma_transfer_error %d\n", __func__,
			       ret);
		return ret;
	} else {
		return desc->lenth;
	}
}

int vaccrt_map_write(struct vastai_cdev *va_dev, const char __user *buffer,
		     size_t lenth, loff_t pos)
{
	int ret = 0;
	void *data = NULL;
	if (!va_dev) {
		return -EINVAL;
	}

	data = kzalloc(lenth, GFP_KERNEL);
	if (!data) {
		VASTAI_PCI_ERR(
			va_dev->pci_info, va_dev->die_id,
			"[vaerr] %s: failed to kzalloc dma_data_struct\n",
			__func__);
		ret = -ENOMEM;
		goto out;
	}
	ret = vaccrt_ai_copy_from_user(data, buffer, lenth);
	if (ret) {
		ret = -EFAULT;
		goto out;
	}
	/* TODO : pls tell pcie driver which pcie device and which die */
	ret = vastai_pci_mem_write(va_dev->pci_info, va_dev->die_index, pos,
				   data, lenth);
	if (ret)
		goto out;

out:
	kfree(data);
	return ret;
}

size_t vaccrt_add_write_queue(struct vastai_cdev *va_dev,
			      struct queue_desc *desc)
{
	union core_bitmap core_id = { .val = 0x0 };
	int ret = 0;
	void *vir_addr = desc->buffer;
	u64 dev_addr = desc->pos;
	size_t dma_lenth = desc->lenth;
	struct vastai_dmadesc *dmadesc;
	int dma_desc_unit = 0;
	pid_t pid = task_tgid_nr(current);

	dma_desc_unit = DIV_ROUND_UP(desc->lenth, VASTAI_MAX_DMA_BUF);

	dmadesc = kzalloc(sizeof(struct vastai_dmadesc) * dma_desc_unit,
			   GFP_KERNEL);
	if (!dmadesc)
		return -ENOMEM;

	if (iommu_is_enable(va_dev->pci_info) &&
	    ((u64)vir_addr % PAGE_SIZE == 0)) {
		#if CONFIG_VASTAI_SOC_HW_TYPE==1
		ret = vastai_pci_dma_transfer_by_uaddr(
			va_dev->pci_info, va_dev->die_index, core_id, 1,
			dev_addr, (u64)vir_addr, dma_lenth);
		#elif CONFIG_VASTAI_SOC_HW_TYPE==2
		ret = vastai_sdma_transfer_by_uaddr(
			va_dev->pci_info, va_dev->die_index, core_id, 1,
			dev_addr, (u64)vir_addr, dma_lenth);
		#else
		#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
		#endif

	} else {
		int i = 0;
		for (i = 0; dma_lenth > 0; i++) {
			dmadesc[i].is_src_dma_addr = 0;
			dmadesc[i].is_host_to_dev = 1;
			dmadesc[i].is_src_not_user_mem = 0;
			dmadesc[i].host_addr.vir_addr = vir_addr;
			dmadesc[i].dev_addr = dev_addr;

			if (dma_lenth < VASTAI_MAX_DMA_BUF) {
				dmadesc[i].dma_lenth = dma_lenth;
			} else {
				dmadesc[i].dma_lenth = VASTAI_MAX_DMA_BUF;
			}

			vir_addr = (void *)((u64)vir_addr + dmadesc[i].dma_lenth);
			dev_addr += dmadesc[i].dma_lenth;
			dma_lenth -= dmadesc[i].dma_lenth;
		}
		#if CONFIG_VASTAI_SOC_HW_TYPE==1
		ret = vastai_pci_dma_transfer_sync_pid(va_dev->pci_info,
						       va_dev->die_index,
						       core_id, dmadesc, i,
						       pid);
		#elif CONFIG_VASTAI_SOC_HW_TYPE==2
		ret = vastai_sdma_transfer_sync_pid(va_dev->pci_info,
						       va_dev->die_index,
						       core_id, dmadesc, i,
						       pid);
		#else
		#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
		#endif
	}

	kfree(dmadesc);
	if (ret < 0) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "[vaerr] %s: dma_transfer_error %d\n", __func__,
			       ret);
		return ret;
	} else {
		return desc->lenth;
	}
}

static inline int _inc_or_dec_run_ref_num(struct vastai_cdev *va_dev,
					  atomic_t *p_ref_num, pid_t pid, int inc)
{
	int ret = 0;
	if (inc) {
		if (unlikely(atomic_inc_return(p_ref_num) >
			     VASTAI_MAX_OUT_COUNT)) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: pid:%u failed to run_ref_num++\n",
				       __func__, pid);
			ret = -1;
		}
	} else {
		if (unlikely(atomic_dec_if_positive(p_ref_num) < 0)) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: pid:%u failed to run_ref_num--\n",
				       __func__, pid);
			ret = -1;
		}
	}
	return ret;
}

#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_cmd_run(struct vastai_cdev *va_dev, struct dev_process *dev_process,
		   union vastai_cmd *run, u32 cmd)
{
	int ret = 0;
	int is_interrupt_come = 0;
	struct buf_desc cmd_desc = {0};
	union core_bitmap core_id;
	int use_command_buffer = 0;
	pid_t pid = task_tgid_nr(current);
#ifdef VATOOLS_PROFILER_ENABLE
	profiler_msg_checkpoint_t msg_profiler;
#endif

	if (!va_dev || !run) {
		ret = -EINVAL;
		goto out;
	}

	switch (cmd) {
	case CMD_LOAD_VDSP_OPERATOR:
		if (va_dev->soc.vdsp_num <= 4) {
			cmd_desc.data.cmd_model_desc.dev =
				0x0F << (run->run_load_model.dev + 8);
			core_id.val = cmd_desc.data.cmd_model_desc.dev;
		} else if (va_dev->soc.vdsp_num <= 12) {
			cmd_desc.data.cmd_model_desc.dev =
				0x0F << (run->run_load_model.dev + 8) |
				0x0F << (run->run_load_model.dev + 20) |
				0x0F << (run->run_load_model.dev + 28);
			core_id.val = cmd_desc.data.cmd_model_desc.dev;
		} else {
			// invalid vdsp num
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "cmd_load_vdsp_operator invalid vdsp_num %d.\n",
				       va_dev->soc.vdsp_num);
			ret = -EINVAL;
			goto out;
		}
		break;
	case CMD_LOAD_ODSP_OPERATOR:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		core_id.val = 0x1; /* CMCU only one, CMCU -> ODSP */
		break;
	case CMD_RUN_STREAM:
		if (run->run_load_model.dev < 4) {
			// vdsp 0~3
			cmd_desc.data.cmd_model_desc.dev =
				0x01 << (run->run_load_model.dev + 8);
		} else if (run->run_load_model.dev < 8) {
			// vdsp 4~7 ==> odsp 0~3
			cmd_desc.data.cmd_model_desc.dev =
				0x01 << ((run->run_load_model.dev - 4) + 20);
		} else if (run->run_load_model.dev < 12) {
			// vdsp 8~11 ==> odsp 4~7
			cmd_desc.data.cmd_model_desc.dev =
				0x01 << ((run->run_load_model.dev - 8) + 28);
		} else {
			// invalid vdsp index
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "cmd_run_stream invalid vdsp %d.\n",
				       run->run_load_model.dev);
			ret = -EINVAL;
			goto out;
		}
		core_id.val = cmd_desc.data.cmd_model_desc.dev;
		break;
	case CMD_RUN_MODEL:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		core_id.val = 0x1; /* CMCU only one */
		break;
	case CMD_RUN_KERENL:
		cmd_desc.data.cmd_kernel_desc.cmd = cmd;
		cmd_desc.data.cmd_kernel_desc.engine_type = run->run_kernel.engine_type;
		cmd_desc.data.cmd_kernel_desc.pid = run->run_kernel.pid;
		cmd_desc.data.cmd_kernel_desc.stream_id = run->run_kernel.stream_id;
		cmd_desc.data.cmd_kernel_desc.data_id = run->run_kernel.data_id;
		cmd_desc.data.cmd_kernel_desc.work_size = run->run_kernel.work_size;
		cmd_desc.data.cmd_kernel_desc.kernel_addr = run->run_kernel.kernel_addr;
		cmd_desc.data.cmd_kernel_desc.args_addr = run->run_kernel.args_addr;
		use_command_buffer = 1;
		break;
	case CMD_CANCEL_KENREL:
		cmd_desc.data.cmd_kernel_cancel_desc.dev = VASTAI_CANCEL_KERNEL_DEV_MASK;
		cmd_desc.data.cmd_kernel_cancel_desc.cmd = cmd;
		cmd_desc.data.cmd_kernel_cancel_desc.pid = run->cancel_kernel.pid;
		use_command_buffer = 1;
		break;
	case CMD_LOAD_OPERATOR:
		cmd_desc.data.cmd_kernel_op_desc.cmd = cmd;
		cmd_desc.data.cmd_kernel_op_desc.dev = run->run_load_operator.dev;
		cmd_desc.data.cmd_kernel_op_desc.pid = run->run_load_operator.pid;
		cmd_desc.data.cmd_kernel_op_desc.engine_type = run->run_load_operator.operator_type;
		cmd_desc.data.cmd_kernel_op_desc.data_id = 0;
		cmd_desc.data.cmd_kernel_op_desc.op_addr = run->run_load_operator.operator_addr;
		cmd_desc.data.cmd_kernel_op_desc.op_size = run->run_load_operator.operator_size;
		use_command_buffer = 1;
		break;
	case CMD_LOAD_MODEL:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		core_id.val = 0x1; /* CMCU only one */
		goto out;
		break;
	case CMD_DESTROY_MODEL:
		// pr_info("CMD_DESTROY_MODEL is not supported now!\n");
		goto out;
	default:
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "cmd 0x%x is not supported!\n", cmd);
		ret = -EINVAL;
		goto out;
	}

	if (CMD_RUN_STREAM == cmd || CMD_RUN_MODEL == cmd) {
		if (_inc_or_dec_run_ref_num(va_dev, &dev_process->run_ref_num,
					    dev_process->pid, 1)) {
			ret = -EINVAL;
			goto out;
		}
	} else if (CMD_RUN_KERENL == cmd || CMD_CANCEL_KENREL == cmd) {
		if (_inc_or_dec_run_ref_num(va_dev, &dev_process->ker_ref_num,
					    dev_process->pid, 1)) {
			ret = -EINVAL;
			goto out;
		}
	}

	if (use_command_buffer == 0) {
		cmd_desc.data.cmd_model_desc.cmd = cmd;
		cmd_desc.data.cmd_model_desc.pid = run->run_load_model.pid;
		cmd_desc.data.cmd_model_desc.model_id = run->run_load_model.model_id;
		cmd_desc.data.cmd_model_desc.data_id = run->run_load_model.data_id;
		cmd_desc.data.cmd_model_desc.model_addr =
			run->run_load_model.model_addr;
		cmd_desc.data.cmd_model_desc.inout_addr =
			run->run_load_model.inout_addr;
		if (CMD_LOAD_ODSP_OPERATOR == cmd) {
			if (va_dev->soc.type == VASTAI_SV100_HV)
				cmd_desc.data.cmd_operator_desc.odsp_core_flag =
					((va_dev->soc.harvest_core_flag & 0xFF) |
					(va_dev->soc.harvest_core_flag >> 16 & 0x0F));
			else if (va_dev->soc.type == VASTAI_SV100)
				cmd_desc.data.cmd_operator_desc.odsp_core_flag = 0xFF;
			else if (va_dev->soc.type == VASTAI_SG100)
				cmd_desc.data.cmd_operator_desc.odsp_core_flag = 0x03;
			else
				VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
						"soc type is not supported!\n");
		}
	}

#ifdef VATOOLS_PROFILER_ENABLE
	memset(&msg_profiler, 0, sizeof(profiler_msg_checkpoint_t));
	msg_profiler.dev_id = vastai_pci_info_get_dev_id(va_dev->pci_info);
	msg_profiler.die_id = va_dev->die_id;
	msg_profiler.die_index = va_dev->die_index;
	msg_profiler.time_of_host_send_msg = vastai_get_host_time_ns();
	msg_profiler.pid = pid;
	msg_profiler.core_bitmap = core_id.val;
	msg_profiler.msg_cmd = cmd;
#endif

	if (use_command_buffer) {
		// command_buffer[0] is the special command_buffer which has high priority
		// command_buffer[1 ~ 4] are normal command_buffer for send tasks in stream
		// command_buffer[5] are cancel command_buffer for cancel task in stream
		u32 buf_index = 0;
		if (cmd == CMD_CANCEL_KENREL) {
			buf_index = VASTAI_CMD_BUF_NR;
		} else {
			buf_index = (cmd == CMD_RUN_KERENL) ? ((cmd_desc.data.cmd_kernel_desc.stream_id % (VASTAI_CMD_BUF_NR-1)) + 1) : 0;
		}
		is_interrupt_come = wait_event_interruptible(
			va_dev->wait_runsteam,
			(ret = vastai_pci_send_cmdbuf_pid(
				 va_dev->pci_info, va_dev->die_index, buf_index,
				 &cmd_desc, sizeof(cmd_desc), pid)) != -ENOMEM);
	} else {
		is_interrupt_come = wait_event_interruptible(
			va_dev->wait_runsteam,
			(ret = vastai_pci_send_msg_pid(
				 va_dev->pci_info, va_dev->die_index, core_id,
				 &cmd_desc, sizeof(cmd_desc), pid)) != -ENOMEM);
	}

#ifdef VATOOLS_PROFILER_ENABLE
	msg_profiler.time_of_fw_recv_msg = vastai_get_host_time_ns();
	vatools_profiler_msg_checkpoint(&msg_profiler);
#endif

	if (is_interrupt_come) {
		// VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id, "%s: recv interrupte %d\n",
		// 	       __func__, is_interrupt_come);
		ret = -EINTR;
		goto out_dec;
	}
	if (!ret)
		goto out;

	VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
		       "%s: send msg failed %d\n", __func__, ret);

out_dec:
	if (CMD_RUN_STREAM == cmd || CMD_RUN_MODEL == cmd) {
		if (_inc_or_dec_run_ref_num(va_dev, &dev_process->run_ref_num,
					    dev_process->pid, 0)) {
			ret = -EINVAL;
		}
	} else if (CMD_RUN_KERENL == cmd || CMD_CANCEL_KENREL == cmd) {
		if (_inc_or_dec_run_ref_num(va_dev, &dev_process->ker_ref_num,
					    dev_process->pid, 0)) {
			ret = -EINVAL;
		}
	}
out:
	return ret;
}
#elif CONFIG_VASTAI_SOC_HW_TYPE==2
int vaccrt_cmd_run(struct vastai_cdev *va_dev,
		   struct dev_process *p_dev_process, union vastai_cmd *run,
		   u32 cmd)
{
	int ret = 0;
	int is_interrupt_come = 0;
	struct buf_desc cmd_desc;
	struct dev_process *dev_process = NULL, *dev_process_temp = NULL;
	int index;
	pid_t pid = task_tgid_nr(current);
	unsigned char fn_mode = 0;
	unsigned char vdsp_cmd_index = 0;
	unsigned char cmcu_cmd_index = 0;

	if (!va_dev || !run) {
		ret = -EINVAL;
		goto out;
	}

	fn_mode = va_dev->pci_info->fn_mode;

	switch (fn_mode) {
	case ONLY_1_PF:
		switch (run->run_load_model.dev) {
			case 0:
				vdsp_cmd_index = ONLY_1PF_HOST_TO_VDSP0_CMD_BUF;
				break;
			case 1:
				vdsp_cmd_index = ONLY_1PF_HOST_TO_VDSP1_CMD_BUF;
				break;
			case 2:
				vdsp_cmd_index = ONLY_1PF_HOST_TO_ODSP0_CMD_BUF;
				break;
			case 3:
				vdsp_cmd_index = ONLY_1PF_HOST_TO_ODSP1_CMD_BUF;
				break;
			default:
				vdsp_cmd_index = ONLY_1PF_HOST_TO_VDSP0_CMD_BUF;
				break;
		}
		cmcu_cmd_index = ONLY_1PF_HOST_TO_CMCU_CMD_BUF;
		break;

	case ONLY_2_PF:
		vdsp_cmd_index = ONLY_2PF_HOST_TO_1ST_VDSP_CMD_BUF;
		cmcu_cmd_index = ONLY_2PF_HOST_TO_CMCU_CMD_BUF;
		break;

	case ONLY_4_PF:
	case PF_4_WITH_SRIOV:
		vdsp_cmd_index = COMMON_HOST_TO_VDSP_CMD_BUF;
		cmcu_cmd_index = COMMON_HOST_TO_CMCU_CMD_BUF;
		break;

	default:
		break;
	}

	switch (cmd) {
	case CMD_COPY_VDSP_OPERATOR:
	case CMD_LOAD_VDSP_OPERATOR:
		cmd_desc.data.cmd_model_desc.dev =
			0x0F << (run->run_load_model.dev + 8);
		index = vdsp_cmd_index;
		break;
	case CMD_COPY_ODSP_OPERATOR:
	case CMD_LOAD_ODSP_OPERATOR:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		index = cmcu_cmd_index;
		break;
	case CMD_RUN_STREAM:
		cmd_desc.data.cmd_model_desc.dev =
			0x01 << (run->run_load_model.dev + 8);
		index = vdsp_cmd_index;
		break;
	case CMD_RUN_MODEL:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		index = cmcu_cmd_index;
		break;
	case CMD_LOAD_MODEL:
		cmd_desc.data.cmd_model_desc.dev = 0x01
						   << run->run_load_model.dev;
		index = cmcu_cmd_index;
		// goto out;
		break;
	case CMD_DESTROY_MODEL:
		// pr_info("CMD_DESTROY_MODEL is not supported now!\n");
		index = cmcu_cmd_index;
		goto out;
	default:
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "[vaerr] cmd 0x%x is not supported!\n", cmd);
		ret = -EINVAL;
		goto out;
	}

	if (CMD_COPY_VDSP_OPERATOR == cmd || CMD_COPY_ODSP_OPERATOR == cmd) {
		cmd_desc.data.cmd_copy_operator_desc.pid =
			run->run_load_operator_sg100.pid;
		cmd_desc.data.cmd_copy_operator_desc.operator_id = 0;
		cmd_desc.data.cmd_copy_operator_desc.cmd = cmd;
		cmd_desc.data.cmd_copy_operator_desc.data_id = 0;
		cmd_desc.data.cmd_copy_operator_desc.odsp_core_flag = 0x3;
		cmd_desc.data.cmd_copy_operator_desc.operator_size =
			run->run_load_operator_sg100.operator_size;
		cmd_desc.data.cmd_copy_operator_desc.operator_addr =
			run->run_load_operator_sg100.operator_addr;
		cmd_desc.data.cmd_copy_operator_desc.src_offset =
			run->run_load_operator_sg100.src;
		cmd_desc.data.cmd_copy_operator_desc.dst_offset =
			run->run_load_operator_sg100.dst;
	} else {
		cmd_desc.data.cmd_model_desc.cmd = cmd;
		cmd_desc.data.cmd_model_desc.pid = run->run_load_model.pid;
		cmd_desc.data.cmd_model_desc.model_id =
			run->run_load_model.model_id;
		cmd_desc.data.cmd_model_desc.data_id =
			run->run_load_model.data_id;
		cmd_desc.data.cmd_model_desc.model_addr =
			run->run_load_model.model_addr;
		cmd_desc.data.cmd_model_desc.inout_addr =
			run->run_load_model.inout_addr;
	}

	if (CMD_RUN_STREAM == cmd || CMD_RUN_MODEL == cmd) {
		mutex_lock(&va_dev->dev_trans_ai->mutex);
		list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head,
				     node) {
			if (dev_process->pid == run->run_load_model.pid) {
				dev_process_temp = dev_process;
				break;
			}
		}
		mutex_unlock(&va_dev->dev_trans_ai->mutex);
		if (!dev_process_temp) {
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"[vaerr] %s: pid:%u failed to get process\n",
				__func__, run->run_load_model.pid);
			ret = -EINVAL;
			goto out;
		}
	}

	if (COMMON_HOST_TO_CMCU_CMD_BUF == index) {
		va_dev->pci_info->waiting_cmcu_comback++;
	}

	is_interrupt_come = wait_event_interruptible(
		va_dev->wait_runsteam,
		(ret = vastai_pci_send_msg_pid(
			 va_dev->pci_info, va_dev->die_index, index, &cmd_desc,
			 sizeof(cmd_desc), pid)) != -ENOMEM);
	if (is_interrupt_come) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "[vaerr] %s: recv interrupte %d\n", __func__,
			       is_interrupt_come);
		goto out;
	}
	if (ret) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "[vaerr] %s: send msg failed %d\n", __func__,
			       ret);
		goto out;
	}
	if (dev_process_temp) {
		if (unlikely(atomic_inc_return(&dev_process_temp->run_ref_num) >
			     VASTAI_MAX_OUT_COUNT))
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"[vaerr] %s: pid:%u failed to run_ref_num++\n",
				__func__, dev_process_temp->pid);
	}

out:
	return ret;
}
#else
#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
#endif

static struct dev_out_desc *vaccrt_get_out_desc(struct dev_process *dev_process,
						union vastai_cmd *get_desc)
{
	struct dev_out_desc *out_desc = NULL, *tmp_out_desc = NULL;

	mutex_lock(&dev_process->mutex);

	if (get_desc->get_desc.stream_id != 0) {
		list_for_each_entry (tmp_out_desc, &dev_process->head, node) {
			if (get_desc->get_desc.stream_id ==
			    (u32)tmp_out_desc->stream_id) {
				out_desc = tmp_out_desc;
				break;
			}
		}
	} else {
		out_desc = list_first_entry_or_null(&dev_process->head,
						    struct dev_out_desc, node);
	}

	if (out_desc)
		list_del(&out_desc->node);

	mutex_unlock(&dev_process->mutex);

	return out_desc;
}

static int vaccrt_get_out_desc_by_stream(struct dev_process *dev_process,
			      union vastai_cmd *get_desc,
			      stream_node_t *stream_node, struct dev_out_desc **p_out_desc)
{
	int ret = 0;
	struct dev_out_desc *out_desc = NULL, *tmp_out_desc = NULL;
	*p_out_desc = NULL;

	if (stream_node->state == stream_state_destroyed) {
		return 2;
	}

	mutex_lock(&stream_node->mutex_out_desc);

	if (stream_type_sync == stream_node->type) {
		list_for_each_entry (tmp_out_desc, &stream_node->head_out_desc,
				     node) {
			if (get_desc->get_desc.data_id ==
			    (u32)tmp_out_desc->data_id) {
				out_desc = tmp_out_desc;
				break;
			}
		}
	} else {
		out_desc = list_first_entry_or_null(&stream_node->head_out_desc,
						    struct dev_out_desc, node);
	}

	if (out_desc) {
		list_del(&out_desc->node);
		ret = 1;
		*p_out_desc = out_desc;
	} else {
		ret = 0;
	}

	mutex_unlock(&stream_node->mutex_out_desc);

	// ret = 0 no out_desc, will continue to wait until timeout
	// ret = 1 get out_desc, will break return
	// ret = 2 get destroyed, will break return

	return ret;
}

int vaccrt_cmd_get_desc(struct vastai_cdev *va_dev,
			struct dev_process *dev_process,
			union vastai_cmd *get_desc)
{
	int ret = 0, res = 0;
	struct dev_out_desc *out_desc = NULL;
	struct dev_process *dev_process_temp = dev_process;
	stream_node_t *stream_node = NULL, *stream_node_temp = NULL;
	struct dev_out_desc *out_desc_0 = NULL, *out_desc_temp = NULL;

	if (!get_desc->get_desc.pid) {
		ret = -EINVAL;
		goto out;
	}
	
	if (unlikely(dev_process_temp->proc_state)) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: pid:%u dev_process state is %d\n", __func__,
			       dev_process_temp->pid,
			       dev_process_temp->proc_state);
		ret = -EINVAL;
		goto out;
	}

	if (get_desc->get_desc.timeout == 0) {
		// old path timeout is 10ms default
		ret = wait_event_interruptible_timeout(
			dev_process_temp->wait,
			(out_desc = vaccrt_get_out_desc(dev_process_temp, get_desc)),
			HZ / 100);
	} else {
		// new path timeout_ms / wait forever
		mutex_lock(&dev_process_temp->stream_mutex);
		stream_node = NULL;
		list_for_each_entry (stream_node_temp, &dev_process_temp->stream_head,
					node) {
			if (stream_node_temp->stream_id == get_desc->get_desc.stream_id) {
				stream_node = stream_node_temp;
				break;
			}
		}
		if (stream_node == NULL) {
			mutex_unlock(&dev_process_temp->stream_mutex);
			ret = -EINVAL;
			goto out;
		}
		if (stream_node->state == stream_state_destroyed) {
			if ((stream_node->node).next != LIST_POISON1 || (stream_node->node).prev != LIST_POISON2) {
				list_del(&stream_node->node);
				if (unlikely(atomic_dec_if_positive( &dev_process_temp->stream_num) < 0)) {
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: stream_num-- invalid.\n",
						__func__);
				}
			}
			mutex_lock(&stream_node->mutex_out_desc);
			list_for_each_entry_safe (out_desc_0, out_desc_temp,
						&stream_node->head_out_desc, node) {
				list_del(&out_desc_0->node);
				kfree(out_desc_0);
			}
			mutex_unlock(&stream_node->mutex_out_desc);
			kfree(stream_node);
			stream_node = NULL;
			mutex_unlock(&dev_process_temp->stream_mutex);
			ret = -EINVAL;
			goto out;
		} else {
			stream_node->state = stream_state_get_out;
		}
		mutex_unlock(&dev_process_temp->stream_mutex);

		if (get_desc->get_desc.timeout == 0xFFFFFFFF) { // wait for ever
			ret = wait_event_interruptible(
				stream_node->wait,
				(res = vaccrt_get_out_desc_by_stream(
					 dev_process_temp, get_desc,
					 stream_node, &out_desc)));
		} else {	// wait timeout_ms
			long timeout_ms =
				get_desc->get_desc.timeout * HZ / 1000;
			ret = wait_event_interruptible_timeout(
				stream_node->wait,
				(res = vaccrt_get_out_desc_by_stream(
					 dev_process_temp, get_desc,
					 stream_node, &out_desc)),
				timeout_ms);
		}

		mutex_lock(&dev_process_temp->stream_mutex);
		if (stream_node->state == stream_state_destroyed) {
			if ((stream_node->node).next != LIST_POISON1 || (stream_node->node).prev != LIST_POISON2) {
				list_del(&stream_node->node);
				if (unlikely(atomic_dec_if_positive(&dev_process_temp->stream_num) < 0)) {
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: stream_num-- invalid.\n",
						__func__);
				}
			}
			mutex_lock(&stream_node->mutex_out_desc);
			list_for_each_entry_safe (out_desc_0, out_desc_temp,
						&stream_node->head_out_desc, node) {
				list_del(&out_desc_0->node);
				kfree(out_desc_0);
			}
			mutex_unlock(&stream_node->mutex_out_desc);
			kfree(stream_node);
			stream_node = NULL;
			mutex_unlock(&dev_process_temp->stream_mutex);
			if (out_desc) 
				kfree(out_desc);
			ret = -EINVAL;
			goto out;
		} else {
			stream_node->state = stream_state_idle;
			mutex_unlock(&dev_process_temp->stream_mutex);
		}
	}

	if (-ERESTARTSYS == ret) {
		// VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id, "%s: recv interrupte %d\n", __func__, ret);
		goto out;
	}

	if (out_desc) {
		if (out_desc->context_id >> 31) {
			if (unlikely(atomic_dec_if_positive(
					     &dev_process_temp->out_ref_num) <
				     0))
				VASTAI_PCI_ERR(
					va_dev->pci_info, va_dev->die_id,
					"%s: pid:%u failed to out_ref_num--\n",
					__func__, out_desc->pid);
		}
		get_desc->get_desc.dev = out_desc->dev;
		get_desc->get_desc.pid = out_desc->pid;
		get_desc->get_desc.stream_id = (u32)out_desc->stream_id;
		get_desc->get_desc.data_id = (u32)out_desc->data_id;
		get_desc->get_desc.stream_addr = (u32)out_desc->stream_addr;
		get_desc->get_desc.context_id = (u32)out_desc->context_id;
		get_desc->get_desc.error_code = (u32)out_desc->error_code;
		kfree(out_desc);
		ret = 0;
	} else
		ret = -EAGAIN;

out:
	return ret;
}

// struct dev_process *get_dev_process(struct vastai_cdev *va_dev, pid_t pid)
// {
// 	struct dev_process *dev_process = NULL;
// 	list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head, node) {
// 		if (dev_process->pid == pid) {
// 			return dev_process;
// 		}
// 	}
// 	return NULL;
// }

int vaccrt_add_dev_process(struct vastai_cdev *va_dev, struct dev_process **process)
{
	int ret = 0;
	int i = 0;
	pid_t pid = task_tgid_nr(current);
	struct dev_process *dev_process = NULL, *dev_process_temp = NULL;

	mutex_lock(&va_dev->dev_trans_ai->mutex);
	if (list_empty(&va_dev->dev_trans_ai->head)) {
		va_dev->mmap.state = mmap_idle;
	}
	list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head, node) {
		if (dev_process->pid == pid) {
			dev_process_temp = dev_process;
			break;
		}
	}

	if (unlikely(dev_process_temp)) {
		if (dev_process_temp->proc_state == 1) {
			// dev_process will be removed in delay_work, forbid to add
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u, state:%d has already in delay_work\n",
				__func__, pid, dev_process_temp->proc_state);
			dev_process_temp = NULL;
			ret = -EINVAL;
			goto out;
		}

		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
			       "%s: repeat add process, pid:%u, state:%d\n",
			       __func__, pid, dev_process_temp->proc_state);
		atomic_inc_return(&dev_process_temp->ref_num);
		goto out;
	}

	dev_process_temp = kzalloc(sizeof(struct dev_process), GFP_KERNEL);
	if (unlikely(!dev_process_temp)) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: pid:%u failed to kzalloc dev_process\n",
			       __func__, pid);
		ret = -ENOMEM;
		goto out;
	}

	dev_process_temp->vdsp_used_count = (uint32_t *)kzalloc(
		sizeof(int) * va_dev->soc.vdsp_num, GFP_KERNEL);
	if (unlikely(!dev_process_temp->vdsp_used_count)) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: pid:%u failed to kzalloc vdsp_used_count\n",
			       __func__, pid);
		ret = -ENOMEM;
		goto out;
	}

	dev_process_temp->ctxt = va_dev;
	dev_process_temp->pid = pid;
	dev_process_temp->vpid = task_tgid_vnr(current);
	dev_process_temp->ns = (u64)task_active_pid_ns(current);
	dev_process_temp->level = (u32)task_active_pid_ns(current)->level;
	atomic_set(&dev_process_temp->ref_num, 1);
	atomic_set(&dev_process_temp->run_ref_num, 0);
	atomic_set(&dev_process_temp->ker_ref_num, 0);
	atomic_set(&dev_process_temp->out_ref_num, 0);
	mutex_init(&dev_process_temp->mutex);
	INIT_LIST_HEAD(&dev_process_temp->head);
	init_waitqueue_head(&dev_process_temp->wait);

	atomic_set(&dev_process_temp->stream_num, 0);
	INIT_LIST_HEAD(&dev_process_temp->stream_head);
	mutex_init(&dev_process_temp->stream_mutex);

	INIT_DELAYED_WORK(&dev_process_temp->work, vaccrt_ai_del_work);

	// init mutex and hash_map for device_ddr_zone(stream, model, share)
	for (i = 0; i < zone_count; i++) {
		mutex_init(&dev_process_temp->device_ddr_proxy[i].mutex);
		hash_init(dev_process_temp->device_ddr_proxy[i].hash_map);
	}

	// init mutex and list_head for operator_node list_head in dev_process
	for (i = 0; i < operator_count; i++) {
		mutex_init(&dev_process_temp->mutex_operator_head[i]);
		INIT_LIST_HEAD(&dev_process_temp->operator_head[i]);
		atomic_set(&dev_process_temp->operator_ref_num[i], 0);
	}

	list_add_tail(&dev_process_temp->node, &va_dev->dev_trans_ai->head);
	atomic_inc(&va_dev->dev_trans_ai->dev_process_num);

out:
	mutex_unlock(&va_dev->dev_trans_ai->mutex);
	if (ret) {
		if (dev_process_temp) {
			if (dev_process_temp->vdsp_used_count) {
				kfree(dev_process_temp->vdsp_used_count);
			}
			kfree(dev_process_temp);
			dev_process_temp = NULL;
		}
	}
	*process = dev_process_temp;

	return ret;
}

void vaccrt_remove_dev_process(struct vastai_cdev *va_dev, struct dev_process *process)
{
	// int ret;
	struct dev_process *dev_process_temp = process;
	union vastai_cmd run_cmd = { 0 };

	mutex_lock(&va_dev->dev_trans_ai->mutex);
	// list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head, node) {
	// 	if (dev_process->pid == pid) {
	// 		dev_process_temp = dev_process;
	// 		break;
	// 	}
	// }

	// // TODO video delay add workqueue
	// if (unlikely(!dev_process_temp)) {
	// 	VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
	// 		       "%s: pid:%u failed to remove process\n",
	// 		       __func__, pid);
	// 	goto out;
	// }

	atomic_dec_if_positive(&dev_process_temp->ref_num);
	if(unlikely(atomic_read(&dev_process_temp->ref_num)))
		goto out;

	if (unlikely(atomic_read(&dev_process_temp->run_ref_num)) 
		|| unlikely(atomic_read(&dev_process_temp->ker_ref_num))) {
		run_cmd.cancel_kernel.pid = dev_process_temp->pid;
		dev_process_temp->proc_state = 1;
		vaccrt_cmd_run(va_dev, dev_process_temp, &run_cmd, CMD_CANCEL_KENREL);
		VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u dev_process run/ker_ref_num > 0\n",
				__func__, dev_process_temp->pid);
		
		if (unlikely(!queue_delayed_work(
			    va_dev->dev_trans_ai->workqueue,
			    &dev_process_temp->work,
			    120 * HZ))) { // debug info and release resource if join failed.
			VASTAI_PCI_INFO(
				va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u queue_delayed_work failed.\n",
				__func__, dev_process_temp->pid);
		} else
			goto out;
	}
	// free out_desc, op, shm, vdsp_used_count, stream for dev_process
	_dev_process_free_out_desc(va_dev, dev_process_temp);
	_dev_process_free_operator(va_dev, dev_process_temp);
	_dev_process_free_shm(va_dev, dev_process_temp);
	_dev_process_free_vdsp_used_count(va_dev, dev_process_temp);
	_dev_process_free_stream(va_dev, dev_process_temp);

	list_del(&dev_process_temp->node);
	kfree(dev_process_temp);
	if (unlikely(atomic_dec_if_positive(
			     &va_dev->dev_trans_ai->dev_process_num) < 0)) {
		VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
			       "%s: dev_process_num invalid.\n", __func__);
	}

out:
	if (list_empty(&va_dev->dev_trans_ai->head)) {
		va_dev->mmap.state = mmap_idle;
	}
	mutex_unlock(&va_dev->dev_trans_ai->mutex);

	// return ret;
}

// int vastai_release_dev_process(struct vastai_cdev *va_dev, pid_t pid)
// {
// 	int ret = 0;
// 	struct dev_process *dev_process = NULL;

// 	mutex_lock(&va_dev->dev_trans_ai->mutex);
// 	list_for_each_entry (dev_process, &va_dev->dev_trans_ai->head, node) {
// 		if (dev_process->pid == pid) {
// 			ret = 1;
// 			break;
// 		}
// 	}
// 	mutex_unlock(&va_dev->dev_trans_ai->mutex);

// 	return ret;
// }

#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_ai_data_movement_peers(struct vastai_cdev *va_dev,
				  union vastai_cmd *vastai_cmd)
{
	int ret = 0;
	dma_node_p2p_cmd_t dma_p2p_cmd;
	dma_p2p_cmd.die_index = va_dev->die_index;
	dma_p2p_cmd.local_to_remote = vastai_cmd->peer_2_peer.is_local_2_remote;
	dma_p2p_cmd.local_addr = vastai_cmd->peer_2_peer.local_address;
	dma_p2p_cmd.remote_bar_addr = vastai_cmd->peer_2_peer.remote_address;
	dma_p2p_cmd.size = vastai_cmd->peer_2_peer.len;
	ret = vastai_pci_dma_p2p(va_dev->pci_info, &dma_p2p_cmd);
	return ret;
}

int vaccrt_ai_data_movement(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd)
{
	u32 local_die_id =
		vastai_pci_get_die_id(va_dev->pci_info, va_dev->die_index);
	u32 remote_die_id = UINT_MAX;
	u64 remote_address = 0x0;
	u64 local_address = vastai_cmd->dev_2_dev.local_address;
	int ret;
	u32 len = vastai_cmd->dev_2_dev.len;
	int i;
	dma_node_p2p_cmd_t dma_p2p_cmd;

	for (i = 0; i < va_dev->pci_info->die_num_in_fn; i++) {
		if (vastai_cmd->dev_2_dev.remote_die ==
			vastai_get_vacc_id(va_dev->pci_info, va_dev->pci_info->dies[i].die_index))
			remote_die_id = vastai_pci_get_die_id(va_dev->pci_info, va_dev->pci_info->dies[i].die_index);
	}

	// VA16 (die0 & die1) (die2 & die3) in one pkg, but not in one fn(die_num_in_fn==1)
	if (va_dev->pci_info->die_num_in_fn == 1) {
		u8 die_id_in_fn = local_die_id;
		struct vastai_pci_info *peer_priv = vastai_get_peer_priv(va_dev->pci_info, &die_id_in_fn);
		if (peer_priv)
			remote_die_id = local_die_id + 1;
	}

	if (remote_die_id == UINT_MAX) {
		// VASTAI_PCI_INFO(va_dev->pci_info, vastai_pci_get_die_id(va_dev->pci_info, va_dev->die_index),
		// 	       "[vaerr] %s: can't found remote_die_seq_id:%d\n",
		// 	       __func__, vastai_cmd->dev_2_dev.remote_die);
		dma_p2p_cmd.die_index = va_dev->die_index;
		dma_p2p_cmd.local_to_remote = vastai_cmd->dev_2_dev.is_local_2_remote;
		dma_p2p_cmd.local_addr = vastai_cmd->dev_2_dev.local_address;
		dma_p2p_cmd.remote_bar_addr = vastai_cmd->dev_2_dev.remote_address;
		dma_p2p_cmd.size = vastai_cmd->dev_2_dev.len;
		ret = vastai_pci_dma_p2p(va_dev->pci_info, &dma_p2p_cmd);
		return ret;
	}

	// VASTAI_PCI_INFO(
	// 	va_dev->pci_info, va_dev->die_id,
	// 	"local_address 0x%llx, remote_die_index 0x%x, remote_address 0x%llx, len 0x%x\n",
	// 	(u64)vastai_cmd->dev_2_dev.local_address,
	// 	vastai_cmd->dev_2_dev.remote_die,
	// 	(u64)vastai_cmd->dev_2_dev.remote_address,
	// 	vastai_cmd->dev_2_dev.len);

	if (local_die_id + 1 > remote_die_id) {
		VASTAI_PCI_ERR(
			va_dev->pci_info, va_dev->die_id,
			"[vaerr] %s: die_id is error. local[%d] remote[%d]\n",
			__func__, local_die_id, remote_die_id);
		return -EIO;
	} else {
		remote_address =
			0x1000000000 * (remote_die_id - local_die_id - 1) +
			vastai_cmd->dev_2_dev.remote_address;
	}

	while (len) {
		u32 current_len =
			len <= VASTAI_MAX_DMA_BUF ? len : VASTAI_MAX_DMA_BUF;

		ret = vastai_pci_data_movement(
			va_dev->pci_info, va_dev->die_index, local_address,
			remote_address, current_len,
			vastai_cmd->dev_2_dev.is_local_2_remote);
		if (ret)
			return ret;
		remote_address += current_len;
		local_address += current_len;
		len -= current_len;
	}
	return ret;
}

int vaccrt_ai_data_movement_inner(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd, pid_t pid)
{
	return 0;
}
#else
int vaccrt_ai_data_movement_peers(struct vastai_cdev *va_dev,
				  union vastai_cmd *vastai_cmd)
{
	return 0;
}

int vaccrt_ai_data_movement(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd)
{
	return 0;
}

int vaccrt_ai_data_movement_inner(struct vastai_cdev *va_dev,
			    union vastai_cmd *vastai_cmd, pid_t pid)
{
	int ret = vastai_dev2dev_sdma_sync_pid(
				va_dev->pci_info,
				va_dev->die_index,
				vastai_cmd->ddr_2_ddr.src_addr,
				vastai_cmd->ddr_2_ddr.dst_addr,
				vastai_cmd->ddr_2_ddr.size,
				(int)pid);
	return ret;
}
#endif

#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_ai_callback_reg(void *pcie_dev, struct vastai_cdev *va_dev)
{
	int ret = 0;
	int vastai_sv_irq[] = AI_IRQ_NUM_ARRAY;
	u32 i = 0;

	for (i = 0; i < sizeof(vastai_sv_irq) / sizeof(vastai_sv_irq[0]); i++) {
		ret = vastai_irq_register((struct vastai_pci_info *)pcie_dev,
					  va_dev->die_index, vastai_sv_irq[i],
					  vaccrt_ai_trans_call, va_dev);
		if (ret)
			goto out;
	}

	// #define ODSP_2_HOST_INT0 CMCU_2_HOST_INT1
	if (va_dev->soc.vdsp_num > 4) {
		ret = vastai_irq_register((struct vastai_pci_info *)pcie_dev,
					  va_dev->die_index, CMCU_2_HOST_INT1,
					  vaccrt_ai_trans_call, va_dev);
		if (ret)
			goto out;
	}

out:
	return ret;
}
#endif

#if CONFIG_VASTAI_SOC_HW_TYPE==1
int vaccrt_ai_callback_unreg(void *pcie_dev, struct vastai_cdev *va_dev)
{
	int ret = 0;
	int vastai_sv_irq[] = AI_IRQ_NUM_ARRAY;
	u32 i = 0;

	for (i = 0; i < sizeof(vastai_sv_irq) / sizeof(vastai_sv_irq[0]); i++) {
		ret = vastai_irq_unregister((struct vastai_pci_info *)pcie_dev,
					    va_dev->die_index,
					    vastai_sv_irq[i]);
		if (ret)
			goto out;
	}

	// #define ODSP_2_HOST_INT0 CMCU_2_HOST_INT1
	if (va_dev->soc.vdsp_num > 4) {
		ret = vastai_irq_unregister((struct vastai_pci_info *)pcie_dev,
					    va_dev->die_index,
					    CMCU_2_HOST_INT1);
		if (ret)
			goto out;
	}

out:
	return ret;
}
#endif

int vaccrt_pci_transfer_init(struct vastai_cdev *va_dev)
{
	int ret;
	if (!va_dev) {
		return -EINVAL;
	}

	// ai dev send to host
	va_dev->dev_trans_ai = (struct dev_trans *)kzalloc(
		sizeof(struct dev_trans), GFP_KERNEL);
	if (!va_dev->dev_trans_ai) {
		VASTAI_PCI_ERR(
			va_dev->pci_info, va_dev->die_id,
			"[vaerr] %s: failed to kzalloc va_dev->dev_trans_ai\n",
			__func__);
		ret = -ENOMEM;
		goto out;
	}

	mutex_init(&va_dev->dev_trans_ai->mutex);
	INIT_LIST_HEAD(&va_dev->dev_trans_ai->head);
	atomic_set(&va_dev->dev_trans_ai->dev_process_num, 0);
	va_dev->dev_trans_ai->workqueue =
		alloc_ordered_workqueue("vastai_ai", WQ_HIGHPRI);
	if (!va_dev->dev_trans_ai->workqueue) {
		VASTAI_PCI_ERR(
			va_dev->pci_info, va_dev->die_id,
			"[vaerr] %s: failed to alloc va_dev->dev_trans_ai->workqueue\n",
			__func__);
		ret = -EAGAIN;
		goto out;
	}

	return 0;

out:
	if (va_dev->dev_trans_ai) {
		kfree(va_dev->dev_trans_ai);
	}
	VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
		       "[vaerr] %s: failed\n",
		       __func__);
	return ret;
}

void vaccrt_pci_transfer_exit(struct vastai_cdev *va_dev)
{
	if (!va_dev) {
		return;
	}

	if (va_dev->dev_trans_ai) {
		struct dev_process *dev_process = NULL, *dev_process_temp = NULL;
		// disable insert work_queue, flash work_queue
		mutex_lock(&va_dev->dev_trans_ai->mutex);
		list_for_each_entry_safe (dev_process, dev_process_temp,
					  &va_dev->dev_trans_ai->head, node) {
			if (dev_process->proc_state)
				cancel_delayed_work_sync(&dev_process->work);
		}
		mutex_unlock(&va_dev->dev_trans_ai->mutex);

		flush_workqueue(va_dev->dev_trans_ai->workqueue);
		destroy_workqueue(va_dev->dev_trans_ai->workqueue);

		mutex_lock(&va_dev->dev_trans_ai->mutex);
		list_for_each_entry_safe (dev_process, dev_process_temp,
					  &va_dev->dev_trans_ai->head, node) {
			// free out_desc, op, shm, vdsp_used_count, stream for dev_process
			_dev_process_free_out_desc(va_dev, dev_process);
			_dev_process_free_operator(va_dev, dev_process);
			_dev_process_free_shm(va_dev, dev_process);
			_dev_process_free_vdsp_used_count(va_dev, dev_process);
			_dev_process_free_stream(va_dev, dev_process);
			list_del(&dev_process->node);
			kfree(dev_process);
		}
		atomic_set(&va_dev->dev_trans_ai->dev_process_num, 0);
		mutex_unlock(&va_dev->dev_trans_ai->mutex);
		kfree(va_dev->dev_trans_ai);
	}

	VASTAI_PCI_INFO(va_dev->pci_info, va_dev->die_id, "%s: uninstall\n",
			__func__);
}

int vaccrt_die_info_get_head(struct vastai_cdev *vacc_dev, void *buffer)
{
	vacc_info_head_t *vacc_info_head = (vacc_info_head_t *)buffer;
	if (vacc_dev == NULL || buffer == NULL)
		return -1;
	vacc_info_head->ai_version = vacc_dev->ai_version;
	vacc_info_head->zone_count = vacc_dev->soc.zone_num;
	vacc_info_head->process_count =
		atomic_read(&vacc_dev->dev_trans_ai->dev_process_num);
	return 0;
}

int vaccrt_die_info_get_zone_ddr(struct vastai_cdev *vacc_dev, void *buffer)
{
	int i = 0;
	vacc_zone_usage_t *vacc_zone_usage = (vacc_zone_usage_t *)buffer;
	if (vacc_dev == NULL || buffer == NULL)
		return -1;
	for (i = 0; i < zone_count; i++) {
		vacc_zone_usage[i].total_size =
			vacc_dev->device_ddr_alloc[i]
				.shmre_alloc_head.total_size;
		vacc_zone_usage[i].free_size =
			vacc_dev->device_ddr_alloc[i].shmre_alloc_head.free_size;
	}
	return 0;
}

int vaccrt_die_info_get_process(struct vastai_cdev *vacc_dev, void *buffer,
				int max_count, int *count)
{
	int i = 0, j = 0;
	struct dev_process *dev_process = NULL;
	vacc_process_info_t *vacc_process_info = (vacc_process_info_t *)buffer;
	if (vacc_dev == NULL || buffer == NULL)
		return -1;
	*count = 0;
	mutex_lock(&vacc_dev->dev_trans_ai->mutex);
	list_for_each_entry (dev_process, &vacc_dev->dev_trans_ai->head, node) {
		vacc_process_info[i].pid = dev_process->pid;
		vacc_process_info[i].vpid = dev_process->vpid;
		vacc_process_info[i].level = dev_process->level;
		vacc_process_info[i].ns = dev_process->ns;
		for (j = 0; j < zone_count; j++) {
			vacc_process_info[i].zone_used[j] =
				dev_process->device_ddr_size_used[j];
		}
		i++;
		if (i >= max_count) {
			break;
		}
	}
	mutex_unlock(&vacc_dev->dev_trans_ai->mutex);
	*count = i;
	return 0;
}

int vaccrt_vacc_read_info(struct vastai_cdev *vacc_dev, char __user *buffer,
			  loff_t *len)
{
	int ret = 0;
	int length = 0;
	int process_count = 0, process_count_temp = 0;
	unsigned char *p = NULL, *pbuffer = NULL;

	if (*len < (sizeof(vacc_info_head_t) +
		    sizeof(vacc_zone_usage_t) * zone_count)) {
		return -EINVAL;
	}

	process_count = atomic_read(&vacc_dev->dev_trans_ai->dev_process_num);
	length = sizeof(vacc_info_head_t) +
		 sizeof(vacc_zone_usage_t) * zone_count +
		 sizeof(vacc_process_info_t) * process_count;

	pbuffer = kzalloc(length, GFP_KERNEL);
	p = pbuffer;
	if (!p) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: kzalloc failed.\n", __func__);
		ret = -ENOMEM;
		goto __out;
	}

	if (vaccrt_die_info_get_head(vacc_dev, p)) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: vaccrt_die_info_get_head failed.\n",
			       __func__);
		ret = -EFAULT;
		goto __out;
	}
	p += sizeof(vacc_info_head_t);

	if (vaccrt_die_info_get_zone_ddr(vacc_dev, p)) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: vaccrt_die_info_get_zone_ddr failed.\n",
			       __func__);
		ret = -EFAULT;
		goto __out;
	}
	p += sizeof(vacc_zone_usage_t) * zone_count;

	if (vaccrt_die_info_get_process(vacc_dev, p, process_count,
					&process_count_temp)) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: vaccrt_die_info_get_process failed.\n",
			       __func__);
		ret = -EFAULT;
		goto __out;
	}

	length = sizeof(vacc_info_head_t) +
		 sizeof(vacc_zone_usage_t) * zone_count +
		 sizeof(vacc_process_info_t) * process_count_temp;

	if (length < (*len)) {
		*len = length;
	}

	ret = vaccrt_ai_copy_to_user(buffer, pbuffer, *len);

__out:
	if (pbuffer)
		kfree(pbuffer);
	return ret;
}

#ifdef CONFIG_COMPAT
static int __vaccrt_ai_is_32_bit_thread(void)
{
	int is_32_bit = 0;
#if (defined(__aarch64__) || defined(__arm__))
	is_32_bit = test_thread_flag(TIF_32BIT);
#else
	is_32_bit = test_thread_flag(TIF_ADDR32);
#endif

	// VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "thread is %d bit\n", is_32_bit ? 32 : 64);
	return is_32_bit;
}
#endif

unsigned long vaccrt_ai_copy_to_user(void __user *to, const void *from, unsigned long n)
{
	unsigned long ret = 0;
	// VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s: to=%p from=%p len=%ld", __func__, to, from, n);
#ifdef CONFIG_COMPAT
	if (__vaccrt_ai_is_32_bit_thread()) {
		ret = copy_to_user(
			(void __user *)compat_ptr((compat_uptr_t)(((u64)to) & 0xffffffff)),
			from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
	} else
#endif
	{
		ret = copy_to_user(to, from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
	}
	return ret;
}

unsigned long vaccrt_ai_copy_from_user(void *to, const void __user *from, unsigned long n)
{
	unsigned long ret = 0;
	// VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s: to=%p from=%p len=%ld ", __func__, to, from, n);
#ifdef CONFIG_COMPAT
	if (__vaccrt_ai_is_32_bit_thread()) {
		ret = copy_from_user(
			to,
			(void __user *)compat_ptr((compat_uptr_t)(((u64)from) & 0xffffffff)),
			n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
	} else
#endif
	{
		ret = copy_from_user(to, from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
	}
	return ret;
}

int vaccrt_ai_create_stream(struct vastai_cdev *va_dev,
			    struct dev_process *dev_process,
			    union vastai_cmd *vastai_cmd)
{
	int ret = 0;
	u32 type = vastai_cmd->create_stream_cmd.type;
	u32 stream_id = vastai_cmd->create_stream_cmd.stream_id;
	stream_node_t *stream_node = NULL, *stream_node_temp = NULL;
	mutex_lock(&dev_process->stream_mutex);
	stream_node = NULL;
	list_for_each_entry (stream_node_temp, &dev_process->stream_head, node) {
		if (stream_node_temp->stream_id == stream_id) {
			stream_node = stream_node_temp;
			break;
		}
	}
	// will create a new stream_node whent stream is not exist
	if (stream_node == NULL) {
		if (unlikely(atomic_inc_return(&dev_process->stream_num) >
			     VASTAI_MAX_STREAM_COUNT)) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "%s: pid:%u failed to stream_num++\n",
				       __func__, dev_process->pid);
			ret = -ENOMEM;
			goto out;
		}

		stream_node = kzalloc(sizeof(stream_node_t), GFP_KERNEL);
		if (unlikely(!stream_node)) {
			VASTAI_PCI_ERR(
				va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u failed to kzalloc stream_node, stream_id = 0x%X\n",
				__func__, dev_process->pid, stream_id);
			ret = -ENOMEM;
			goto out;
		}
		init_waitqueue_head(&stream_node->wait);
		stream_node->stream_id = stream_id;
		stream_node->type = type;
		stream_node->state = stream_state_idle;
		mutex_init(&stream_node->mutex_out_desc);
		INIT_LIST_HEAD(&stream_node->head_out_desc);
		INIT_LIST_HEAD(&stream_node->node);
		list_add_tail(&stream_node->node, &dev_process->stream_head);
	} else {
		VASTAI_PCI_INFO(
				va_dev->pci_info, va_dev->die_id,
				"%s: pid:%u stream_id = 0x%X repeat create.\n",
				__func__, dev_process->pid, stream_id);
	}
out:
	mutex_unlock(&dev_process->stream_mutex);
	return ret;
}

int vaccrt_ai_destroy_stream(struct vastai_cdev *va_dev,
			     struct dev_process *dev_process,
			     union vastai_cmd *vastai_cmd)
{
	int ret = 0;
	stream_node_t *stream_node = NULL, *stream_node_temp = NULL;
	struct dev_out_desc *out_desc = NULL, *out_desc_temp = NULL;
	u32 stream_id = vastai_cmd->destroy_stream_cmd.stream_id;

	mutex_lock(&dev_process->stream_mutex);
	list_for_each_entry_safe (stream_node, stream_node_temp,
				  &dev_process->stream_head, node) {
		if (stream_id == stream_node->stream_id) {
			if (stream_node->state == stream_state_get_out) {
				list_del(&stream_node->node);
				if (unlikely(atomic_dec_if_positive(&dev_process->stream_num) < 0)) {
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: failed to stream_num--.\n",
						__func__);
				}
				stream_node->state = stream_state_destroyed;
				goto out;
			} else {
				list_del(&stream_node->node);
				if (unlikely(atomic_dec_if_positive(&dev_process->stream_num) < 0)) {
					VASTAI_PCI_ERR(
						va_dev->pci_info,
						va_dev->die_id,
						"%s: failed to stream_num--.\n",
						__func__);
				}
				mutex_lock(&stream_node->mutex_out_desc);
				list_for_each_entry_safe (out_desc, out_desc_temp,
							&stream_node->head_out_desc, node) {
					list_del(&out_desc->node);
					kfree(out_desc);
				}
				mutex_unlock(&stream_node->mutex_out_desc);
				kfree(stream_node);
				stream_node = NULL;
				goto out;
			}
		}
	}
	stream_node = NULL;
out:
	mutex_unlock(&dev_process->stream_mutex);

	if (stream_node) {
		wake_up_interruptible(&stream_node->wait);
	}

	return ret;
}