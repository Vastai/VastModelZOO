/*
 * vastai_ai - driver a Vastai ai device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2021/01/25
 */

#ifndef __VASTAI_AI_H__
#define __VASTAI_AI_H__

#include "vastai_pci.h"
#include <linux/cdev.h>
#include <linux/kernel.h>
#include "vastai_node_basic_dma.h"

#include <linux/version.h>
#include "shmrecord_alloc.h"

/* The ai driver version. Runtime use it to check the version
Given a version number MAJOR.MINOR.PATCH, increment the:
1. MAJOR version when you make incompatible API changes
2. MINOR version when you add functionality in a backwards compatible manner
3. PATCH version when you make backwards compatible bug fixes
Additional labels for pre-release and build metadata are available as extensions to the MAJOR.MINOR.PATCH format.
*/
#ifndef AI_DRIVER_VERSION
#define AI_DRIVER_VERSION 0x090201
#endif

#define VASTAI_ZONE_MAX_NUM 4

#define MD5_OPERATOR_ID_LEN 4 // 16 uint32_t 128bit

#define CONFIG_VASTAI_SOC_HW_TYPE 1

// device type of VASTAI
typedef enum {
	VASTAI_SV100, // SV100
	VASTAI_SV100_HV, //SV100 harvest
	VASTAI_SG100, // SG100
	VASTAI_DEV_COUNT
} vastai_dev_type_t;

// csram ddr zone type
typedef enum {
	zone_stream, // csram, stream_info
	zone_model, // ddr local share, model_info opcode_csr
	zone_vdsp_operator, // ddr VDSP0 Entry1, code
	zone_share, // ddr share weight, model input/output, video
	zone_odsp_operator, // ddr ODSP0 Entry1, code
	zone_cmcu_operator, // ddr CMCU Entry1, code
	zone_count,
} zone_type_t;

typedef enum {
	vdsp_operator,
	odsp_operator,
	cmcu_operator,
	operator_count,
} operator_type_t;

typedef enum {
	op_state_none,
	op_state_unknow,

	op_state_new_create,
	op_state_re_create,
	op_state_exist_create,
	op_state_attach_create,

	op_state_abs_delete,
	op_state_repeat_delete,
	op_state_reset_delete,
	op_state_detach_delete,

	op_state_count,
} operator_state_t;

struct addr_size {
	u64 base; // base address
	u64 size; // size(Bytes)
};

// structure of bar
struct __attribute__((packed)) vastai_bar {
	u32 id; // bar id
	u32 : 32;
	u64 ddr_base; // base address of ddr
	u64 base; // base address
	u64 size; // size(Bytes)
};

struct __attribute__((packed)) vastai_zone {
	u32 id;
	u32 zone_type;
	u32 alig_ddr_start;
	u32 entry;
	u32 bank_num : 8;
	u32 entry1;
	u32 : 24;
	struct addr_size bank[VASTAI_ZONE_MAX_NUM];
};

struct __attribute__((packed)) vastai_vdsp {
	/* data */
	u32 id; // vdsp id
	u32 : 32;
	u64 base; // base address
	u64 size; // size(Bytes)
};

struct __attribute__((packed)) vastai_odsp {
	/* data */
	u32 id; // odsp id
	u32 : 32;
	u64 base; // base address
	u64 size; // size(Bytes)
};

struct __attribute__((packed)) vastai_cmcu {
	/* data */
	u32 id; // cmcu id
	u32 : 32;
	u64 base; // base address
	u64 size; // size(Bytes)
};

struct __attribute__((packed)) vastai_wdbuf {
	u32 bank_num; // bank number
	u32 : 32;
	u64 bank_size; // bank size(Bytes)
	u64 base; // base address
	u64 size; // size(Bytes)
	// u64 total_size;        // wdbuf size(Bytes)
};

struct __attribute__((packed)) vastai_dlc {
	u32 id;
	u32 core_flag; // bit0 indicates whether this core is a large core
	u32 wdma_fw_entry;
	u32 : 32;
	u64 csr_base; // csr base address
	u64 csr_size; // csr size(Bytes)
	struct vastai_wdbuf wdbuf;
};

struct __attribute__((packed)) vastai_ssram {
	u32 id;
	u32 : 32;
	u64 base; // base address
	u64 size; // size(Bytes)
};

// structure of odma
struct __attribute__((packed)) vastai_odma {
	u32 id; // odma id
	u32 : 32;
	u64 base; // base address
	u64 size; // size(Bytes)
};

// soc equal to a soc in nature (total 100 bytes)
struct __attribute__((packed)) vastai_soc {
	u16 type; // vastai_dev_type_t
	u16 vacc_id; // vacc index, vacc0, vacc1
	u16 render_id; // render id
	u32 harvest_core_flag; // harvest core flag
	u8 enabled_core_num; // enabled core number
	u8 core_num; // total core number
	u8 bar_num; // bar number
	u8 zone_num; // zone number(csram, ddr)
	u8 vdsp_num; // vdsp core number
	u8 ssram_num; // ssram number
	u8 odma_num; // odma number
	u8 odma_snum; //odma src number
	u8 odma_bnum; //odma branch number
	u8 ctrans_bnum; // ctrans branch number
	u16 alig_ssram; // alignment of SRAM
	u16 alig_wdbuf_conv; // alignment of WDBUF
	u16 alig_wdbuf_fc_gemm; // alignment of WDBUF
	u32 wdma_bud; // alignment of WDMA 32M boundry (32M)
	u32 odma_bud; // alignment of ODMA 512M boundry (512M)
	u32 throttle_max_bound; //throttle max bound
	u32 capacity_ratio; // capacity ratio * CAPACITY_RATIO_BASE
	u32 capacity_base; // capacity ratio base
	u64 wdbuf_broadcast_base; // base address of wdbuf for odma
	u64 ddr_total_size; // total size of DDR
	u64 ddr_2_bit_ecc_start; //ddr_2_bit_ecc start
	u64 video_phys_addr; // physical address for video
	u64 video_soc_addr; // soc address for video
	u64 video_size; // size for video
	u16 die_id;
	u16 card_id;
	u64 bdf_info;
	u8 pkg_id;
	u8 die_id_in_card;
	u64 csram_phys_addr;
	u64 csram_size;
	u64 share_phys_addr;
	u64 share_size;
	u8 reserved[12]; // reserved field 8+8
};

struct __attribute__((packed)) bar_ddr_trans_info {
	u64 soc_ddr_address;
	u64 bar_address;
};

// struct process_node {
// 	struct list_head node; // node in process_head list
// 	pid_t pid;
// };

typedef enum {
	mmap_idle,
	mmap_initializing,
	mmap_initialized,
} mmap_init_t;

struct mmap_page {
	struct page *page;
	struct list_head node;
};

struct mmap_init {
	wait_queue_head_t wait;
	struct mutex mutex;
	pid_t pid;
	// 0 idle, 1 curren process init mmap
	// 2 has been initialized
	u32 state;
	struct list_head head; //mmap_page
	u64 addr;
	u32 size;
};

typedef struct __attribute__((packed)) _shmre_alloc_cmd_t {
	u32 shmre_index;
	u64 data;
	u64 size;
	u64 bound;
	u64 head;
} shmre_alloc_cmd_t;

typedef struct __attribute__((packed)) _shmre_free_cmd_t {
	u32 shmre_index;
	u64 data;
	u64 size;
} shmre_free_cmd_t;

typedef struct __attribute__((packed)) _vdsp_used_cmd_t {
	u32 vdsp_id;
} vdsp_used_cmd_t;

typedef struct __attribute__((packed)) _operator_register_cmd_t {
	u32 operator_type; // 0 odsp, 1 vdsp
	u32 id[MD5_OPERATOR_ID_LEN];
	u32 state;
	u64 operator_addr;
	u64 operator_size;
} operator_register_cmd_t;

typedef struct __attribute__((packed)) _operator_register_v2_cmd_t {
	u32 operator_type;
	u32 id[MD5_OPERATOR_ID_LEN];
	u32 state;
	u64 data_addr;
	u64 data_size;
	u64 code_addr;
	u64 code_size;
} operator_register_v2_cmd_t;

typedef struct __attribute__((packed)) _operator_load_cmd_t {
	u32 dev : 32;
	u32 pid : 32;
	u32 operator_type;
	u32 : 32;
	u32 operator_addr : 32;
	u32 operator_size : 32;
	u64 src_addr;
	u64 dst_addr;
	u32 id[MD5_OPERATOR_ID_LEN];
} operator_load_cmd_t;

typedef struct __attribute__((packed)) _operator_load_v2_cmd_t {
	u32 dev : 32;
	u32 pid : 32;
	u8 operator_type;
	u8 flag; // default = 0 use command buffer, = 1 use ring buffer
	u16 reserved;
	u32 op_code_addr;
	u32 op_code_size;
	u32 op_data_addr;
	u32 op_data_size;
	u64 src_code_addr;
	u64 dst_code_addr;
	u64 src_data_addr;
	u64 dst_data_addr;
	u32 id[MD5_OPERATOR_ID_LEN];
} operator_load_v2_cmd_t;

typedef struct __attribute__((packed)) _operator_unregister_cmd_t {
	u32 operator_type; // 0 odsp, 1 vdsp
	u32 id[MD5_OPERATOR_ID_LEN];
	u32 state;
} operator_unregister_cmd_t;

struct __attribute__((packed)) dmabuf_alloc_cmd {
	u32 size;
	int dma_buf_fd;
	u64 dma_addr_t;
};

struct __attribute__((packed)) dmabuf_start_cmd {
	u32 is_dev_to_host;
	u32 dma_buf_fd;
	u64 axi_addr;
	u32 size;
	u32 die_index;
};

#if CONFIG_VASTAI_SOC_HW_TYPE==2
typedef enum rdma_memory_type {
    rdmaDevMem  = 0,
    rdmaHostMem = 1
} rdma_mem_type_t;
#endif

struct __attribute__((packed)) vccl_dmabuf_alloc_cmd {
	u64 size;
	u64 dma_addr_t;
	int dma_buf_fd;
	rdma_mem_type_t mem_type;
};

struct __attribute__((packed)) vccl_rdma_hostbuf_cmd {
	int dmabuf_fd;
	u32 buf_num;
	void *buf_list;
};

typedef struct __attribute__((packed)) _vacc_info_head_t {
	u32 ai_version;
	u32 zone_count;
	u32 process_count;
} vacc_info_head_t;

typedef struct __attribute__((packed)) _vacc_zone_usage_t {
    u64 total_size;
    u64 free_size;
} vacc_zone_usage_t;

typedef struct __attribute__((packed)) _vacc_process_info_t {
    u32 pid;
	u32 vpid;
	u32 level;
	u64 ns;
	u64 zone_used[zone_count];
} vacc_process_info_t;

/* reset device*/
#define VACC_RESET_DEV _IO('V', 0x01)
/* run model*/
#define VACC_RUN_MODEL _IOW('V', 0x02, union vastai_cmd)
/* run stream*/
#define VACC_RUN_STREAM _IOW('V', 0x03, union vastai_cmd)
/* load model*/
#define VACC_LOAD_MODEL _IOW('V', 0x04, union vastai_cmd)
/* destroy model */
#define VACC_DESTROY_MODEL _IOW('V', 0x05, union vastai_cmd)
/* load vdsp operator */
#define VACC_LOAD_VDSP_OPERATOR _IOW('V', 0x06, union vastai_cmd)
/* load odsp operator */
#define VACC_LOAD_ODSP_OPERATOR _IOW('V', 0x07, union vastai_cmd)
/* get current process id for container in host */
#define VACC_GET_CURRENT_PID _IOR('V', 0x08, union vastai_cmd)
/* get process state */
#define VACC_GET_PROCESS _IOWR('V', 0x09, union vastai_cmd)
/* release process resource */
#define VACC_RELEASE_PROCESS _IOWR('V', 0x10, union vastai_cmd)
/* get out desc */
#define VACC_GET_OUT_DESC _IOWR('V', 0x11, union vastai_cmd)
/* read device odma info*/
#define VACC_ECC2BIT _IOWR('V', 0x12, bool)
/* move data device 2 device*/
#define VACC_CP_DIE2DIE _IOW('V', 0x13, union vastai_cmd)
/* read ai version */
#define VACC_RD_VERSION _IOR('V', 0x14, u32)
/* read fw status */
#define VACC_RD_FW_STATUS _IOR('V', 0x15, u32)
/* move data peer(card) 2 peer(card)*/
#define VACC_CP_PEER2PEER _IOW('V', 0x16, union vastai_cmd)
/* create a stream */
#define VACC_CREATE_STREAM _IOW('V', 0x17, union vastai_cmd)
/* destroy a stream */
#define VACC_DESTROY_STREAM _IOW('V', 0x18, union vastai_cmd)
/* run kernel */
#define VACC_RUN_KERNEL 	_IOW('V', 0x19, union vastai_cmd)
/* move data ddr2ddr in SG100  */
#define VACC_CP_DDR2DDR     _IOW('V', 0x1A, union vastai_cmd)

/* read device soc info*/
#define VACC_RD_SOC _IOR('V', 0x21, struct vastai_soc)
/* read device zone info*/
#define VACC_RD_ZONE _IOWR('V', 0x22, struct vastai_zone)
/* read device vdsp info*/
#define VACC_RD_VDSP _IOWR('V', 0x23, struct vastai_vdsp)
/* read device dlc info*/
#define VACC_RD_DLC _IOWR('V', 0x24, struct vastai_dlc)
/* read device ssram info*/
#define VACC_RD_SSRAM _IOWR('V', 0x25, struct vastai_ssram)
/* read device odma info*/
#define VACC_RD_ODAM _IOWR('V', 0x26, struct vastai_odma)
/* read device bar info*/
#define VACC_RD_BAR _IOWR('V', 0x28, struct vastai_bar)
/* read device odsp info*/
#define VACC_RD_ODSP _IOWR('V', 0x29, struct vastai_odsp)
/* ddr overflow*/
#define VACC_DDR_OVERFLOW _IO('V', 0x30)
/* get bar ddr info*/
#define VACC_DDR_TO_BAR _IOWR('V', 0x31, struct bar_ddr_trans_info)

/* init mmap */
#define VACC_MMAP_INIT _IOWR('V', 0x80, union vastai_cmd)

#define VACC_SHMRE_ALLOC _IOWR('V', 0x81, shmre_alloc_cmd_t)
#define VACC_SHMRE_FREE	 _IOWR('V', 0x82, shmre_free_cmd_t)
#define VACC_VDSP_GET	 _IOWR('V', 0x83, vdsp_used_cmd_t)
#define VACC_VDSP_PUT	 _IOWR('V', 0x84, vdsp_used_cmd_t)

#define VACC_REGISTER_OPERATOR	 _IOWR('V', 0x85, operator_register_cmd_t)
#define VACC_UNREGISTER_OPERATOR _IOWR('V', 0x86, operator_unregister_cmd_t)
#define VACC_LOAD_OPERATOR	 	 _IOWR('V', 0x87, operator_load_cmd_t)
#define VACC_REGISTER_OPERATOR_v2	 _IOWR('V', 0x88, operator_register_v2_cmd_t)
#define VACC_LOAD_OPERATOR_v2	 	 _IOWR('V', 0x89, operator_load_v2_cmd_t)

/* zero-copy by dma-buf */
#define VACC_DMA_BUF_ALLOC    _IOWR('V', 0xA0, struct dmabuf_alloc_cmd)
#define VACC_DMA_BUF_START    _IOWR('V', 0xA1, struct dmabuf_start_cmd)
#define VACC_DMA_BUF_TRANS    _IOWR('V', 0xA2, union vastai_cmd)

#define VACC_RDMA_DMABUF_FD   _IOWR('V', 0xB0, struct vccl_dmabuf_alloc_cmd)
#define VACC_VCCL_BUF_ALLOC   _IOWR('V', 0xB1, struct vccl_dmabuf_alloc_cmd)
#define VACC_RDMA_HOSTBUF_GET _IOWR('V', 0xB2, struct vccl_rdma_hostbuf_cmd)
#define VACC_DMA_BUF_ALLOC2   _IOWR('V', 0xB3, struct vccl_dmabuf_alloc_cmd)

#define VACC_DEVICE_NAME_LEN 32

struct vdsp_used_counter {
	struct mutex mutex;
	u32 vdsp_num;
	int *used_counts;
};

struct operator_manager {
	uint32_t operator_type;
    uint32_t zone_index;
	void* private_data;

	char name[32];

	struct mutex mutex;
	atomic_t operator_num;
	struct list_head head; // operator_node

	struct mutex mutex_ddr_head;
	struct list_head device_ddr_head;
	uint64_t device_ddr_size_used;

	struct list_head device_code_ddr_head;
	uint64_t device_code_ddr_size_used;
};

struct vastai_cdev {
	unsigned int dev_id; // device id
	unsigned int die_id; // die id (for multi-die in one device)
	unsigned int die_index; // die index(for multi-die in multi-device)
	struct vastai_pci_info *pci_info; // the parent pci device
	struct vastai_file_info file_info;
	struct fasync_struct *fasync;
	wait_queue_head_t wait_runsteam;
	struct mmap_init mmap;
	// int dev_type;
	u32 ai_version; // ai version
	u32 fw_status; // fw status, such as CORE_POINT_CMCU
	struct vastai_soc soc;
	struct vastai_zone *zone;
	struct vastai_dlc *dlc;
	struct vastai_ssram *ssram;
	struct vastai_bar *bars;
	struct vastai_odma *odmas;
	struct vastai_vdsp *vdsp;
	struct vastai_odsp *odsp;
	struct vastai_cmcu *cmcu;
	struct dev_trans *dev_trans_ai;
	struct list_head vacc_dev_node; // node in device list
	// struct mutex process_mutex;
	// struct list_head process_head; //process_node

	shmre_allocator_t device_ddr_alloc[zone_count];
	struct operator_manager operator_manager[operator_count];

	struct vdsp_used_counter vdsp_used_counter;
};

int vacc_init(void *pcie_dev, unsigned int die_index);
void vacc_exit(void *pcie_dev);
int vastai_pci_dma_p2p(struct vastai_pci_info *pci_info, dma_node_p2p_cmd_t *dma_p2p_cmd);
int vastai_pci_dma_start(struct vastai_pci_info *pci_info, dma_node_start_cmd_t *dma_start_cmd);
int vastai_pci_dma_trans(struct vastai_pci_info *pci_info, dma_node_trans_cmd_t *dma_trans_cmd);
int vastai_wait_ecc_2_bit(struct vastai_pci_info *pdev, union die_index_data die_index);
int vastai_get_render_id(struct vastai_pci_info *pdev, u32 die_index);

int vaccrt_die_info_get_head(struct vastai_cdev *vacc_dev, void *buffer);
int vaccrt_die_info_get_zone_ddr(struct vastai_cdev *vacc_dev, void *buffer);
int vaccrt_die_info_get_process(struct vastai_cdev *vacc_dev, void *buffer,
				int max_count, int *count);

#endif /* end of __VASTAI_AI_H__ */
