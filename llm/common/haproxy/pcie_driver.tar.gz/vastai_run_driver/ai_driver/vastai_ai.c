#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/poll.h>
#include <linux/printk.h>
#include <linux/slab.h>
// #include <linux/interrupt.h>
#include <linux/completion.h>
#include <linux/pid_namespace.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,11,0)
#include <linux/signal.h>
#else
#include <linux/sched/signal.h>
#endif
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/dma-buf.h>
#include <linux/pci.h>
#include "vastai_ai.h"
#include "vastai_common.h"
#include "shm_common.h"
#include "vastai_operator.h"

#if CONFIG_VASTAI_SOC_HW_TYPE==1
#include "vastai_export_api.h"
#include "ddr_partition_v05.h"
#include "fw_entry.h"
#elif CONFIG_VASTAI_SOC_HW_TYPE==2
#include "vastai_ai_info.h"
#include "ddr_partition.h"
#else
#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
#endif

#ifndef KB
#define KB 1024
#endif

#ifndef MB
#define MB (1024 * 1024)
#endif

#ifndef GB
#define GB (1024UL * 1024 * 1024)
#endif

#ifndef TB
#define TB (1024ULL * 1024 * 1024 * 1024)
#endif

#if KERNEL_VERSION(6, 8, 0) <= LINUX_VERSION_CODE
#define VACCRT_MAX_ORDER MAX_PAGE_ORDER
#else
#define VACCRT_MAX_ORDER MAX_ORDER
#endif

// (@kevinx)emulator size is small
#ifndef MMAP_SIZE
#ifdef CONFIG_VASTAI_AI_EMU
#define MMAP_SIZE (6 * MB)
#else
#define MMAP_SIZE (12 * MB)
#endif // #ifdef CONFIG_VASTAI_AI_EMU
#endif // #ifndef MMAP_SIZE

#if CONFIG_VASTAI_SOC_HW_TYPE==1
// base of zone_model
#ifndef MODEL_BASE
// #define MODEL_BASE MSG_TO_AI_CSR_BASE
// #define MODEL_BASE MSG_TO_ODSP
#define MODEL_BASE LOCAL_SHARE_BASE
#endif

// size of zone_model (13M >> 10M >> 29M >> 35M)
#ifndef MODEL_SIZE
// #define MODEL_SIZE (LOG_BUF_BASE - MSG_TO_AI_CSR_BASE)
#define MODEL_SIZE (LOG_BUF_BASE - LOCAL_SHARE_BASE)
#endif

// entry of zone_model
#ifndef MODEL_ENTRY
// #define MODEL_ENTRY 0x85600000
// #define MODEL_ENTRY 0x84600000
#define MODEL_ENTRY 0x84000000
#endif

// entry of zone_model
#ifndef MODEL_ENTRY1
// #define MODEL_ENTRY 0x85600000
// #define MODEL_ENTRY 0x84600000
#define MODEL_ENTRY1 0xA0000000
#endif

// base of zone_stream
#ifndef STREAM_BASE
#define STREAM_BASE MODULE_INFO_BASE
#endif

// size of zone_stream (610K)
#ifndef STREAM_SIZE
#define STREAM_SIZE (VDMCU_CSR_BASE - MODULE_INFO_BASE)
#endif

// entry of zone_stream
#ifndef STREAM_ENTRY
#define STREAM_ENTRY MODULE_INFO_BASE
#endif

// base of zone_operator_vdsp
#ifndef OPERATOR_VDSP_BASE
#define OPERATOR_VDSP_BASE 0x80B600000
#endif

// base of zone_operator_odsp
#ifndef OPERATOR_ODSP_BASE
#define OPERATOR_ODSP_BASE 0x802C00000
#endif

// base of zone_operator_cmcu
#ifndef OPERATOR_CMCU_BASE
#define OPERATOR_CMCU_BASE 0x800600000
#endif

// size of zone_operator_vdsp
#ifndef OPERATOR_VDSP_SIZE
#define OPERATOR_VDSP_SIZE 0x200000
#endif

// size of zone_operator_odsp
#ifndef OPERATOR_ODSP_SIZE
#define OPERATOR_ODSP_SIZE 0x400000
#endif

// size of zone_operator_cmcu
#ifndef OPERATOR_CMCU_SIZE
#define OPERATOR_CMCU_SIZE 0x200000
#endif

// offset of zone_operator_vdsp
#ifndef OPERATOR_VDSP_OFFSET
#define OPERATOR_VDSP_OFFSET (VDSP1_CODE_BASE - VDSP0_CODE_BASE)
#endif

// offset of zone_operator_odsp
#ifndef OPERATOR_ODSP_OFFSET
#define OPERATOR_ODSP_OFFSET (ODSP1_CODE_BASE - ODSP0_CODE_BASE)
#endif

// entry of zone_operator_vdsp
#ifndef OPERATOR_VDSP_ENTRY
#define OPERATOR_VDSP_ENTRY 0x80600000
#endif

// entry of zone_operator_odsp
#ifndef OPERATOR_ODSP_ENTRY
#define OPERATOR_ODSP_ENTRY 0x80400000
#endif

// entry of zone_operator_cmcu
#ifndef OPERATOR_CMCU_ENTRY
#define OPERATOR_CMCU_ENTRY 0x80200000
#endif

// base of SHARE_TO_HOST (0x814000000)
#ifndef VD_MMAP_BASE
#define VD_MMAP_BASE SHARE_TO_HOST_BASE
#endif

// size of SHARE_TO_HOST (32M)
#ifndef VD_MMAP_SIZE
#define VD_MMAP_SIZE (ENCODER_HEAP_BASE - SHARE_TO_HOST_BASE)
#endif

// base of size of share front (0x844000000)
#ifndef SHARE_FRONT_BASE
#define SHARE_FRONT_BASE DDR_DYNAMIC_ALLOC_FRONT_BASE
#endif

// size of share front
#ifndef SHARE_FRONT_SIZE
#define SHARE_FRONT_SIZE (DDR_BOOT_FW_BASE - DDR_DYNAMIC_ALLOC_FRONT_BASE)
#endif

// base of size of share inter (0x880100000)
#ifndef SHARE_INTER_BASE
#define SHARE_INTER_BASE DDR_DYNAMIC_ALLOC_INTER_BASE
#endif

// size of share inter
#ifndef SHARE_INTER_SIZE
#define SHARE_INTER_SIZE (DDR_RESET_VECTOR_BASE - DDR_DYNAMIC_ALLOC_INTER_BASE)
#endif

// base of size of share back (0x8C1000000)
#ifndef SHARE_BACK_BASE
#define SHARE_BACK_BASE DDR_DYNAMIC_ALLOC_BACK_BASE
#endif

// // size of share back
// #ifndef SHARE_BACK_SIZE
// #define SHARE_BACK_SIZE (0 * GB)
// #endif
#endif

#ifndef ODSP0_CODE_BASE
#define ODSP0_CODE_BASE	     (SV_DDR_BASE_ADDR + 0x02800000)
#endif

#ifndef ODSP1_CODE_BASE
#define ODSP1_CODE_BASE	     (SV_DDR_BASE_ADDR + 0x03000000)
#endif

// size of WDMA boundary
#ifndef WDMA_BOUND
#define WDMA_BOUND (32 * MB)
#endif

// size of ODMA boundary
#ifndef ODMA_BOUND
#define ODMA_BOUND (512 * MB)
#endif

// alignment of CSRAM start
#ifndef ALIG_CSRAM_START
#define ALIG_CSRAM_START (4)
#endif

// alignment of DDR start
#ifndef ALIG_DDR_START
#define ALIG_DDR_START (4 * KB)
#endif

// alignment of CSRAM operator start
#ifndef ALIG_OPERATOR_START
#define ALIG_OPERATOR_START (64 * KB)
#endif

#if CONFIG_VASTAI_SOC_HW_TYPE==2
#ifndef SHARE_BUFFER_SIZE
#define SHARE_BUFFER_SIZE (0x108c000000 - 0x1056000000)
#endif

#ifndef DDR_SHARE_BASE
#define DDR_SHARE_BASE (0x1040000000)
#endif

#ifndef MODEL_ENTRY_SG100
#define MODEL_ENTRY_SG100 0x50000000
#endif
#endif

// video phys addr mmpa to 4GB address_space 32bit
#define VIDEO_MMAP_SIZE_MAX		0x100000000

struct vastai_cdev_data {
	struct vastai_cdev *vacc_dev;
	struct dev_process *dev_process;
	// pid_t pid;
};

int __attribute__((weak)) vastai_wait_ecc_2_bit(struct vastai_pci_info *pdev,
						union die_index_data die_index)
{
	return 0;
}

int __attribute__((weak)) vastai_get_render_id(struct vastai_pci_info *pdev, u32 die_index)
{
	return 0;
}

void __attribute__((weak)) vastai_cmcu_call_back(void *arg)
{
}

static loff_t vaccrt_cdev_llseek(struct file *filp, loff_t offset, int orig)
{
	u32 i, j;
	// loff_t ret = 0;
	loff_t pos = 0;
	loff_t head = 0;
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	struct vastai_soc soc = vacc_dev->soc;
	struct vastai_zone *zone = vacc_dev->zone;

	switch (orig) {
	case 0: // head
		head = 0;
		break;

	case 1: // current
		head = filp->f_pos;
		break;

		// case 2://end
		// 	break;

	default:
		goto out;
		// break;
	}

	pos = head + offset;
	if (pos < 0) {
		goto out;
	} else if (pos == 0) {
		filp->f_pos = pos;
		return filp->f_pos;
	} else {
		for (i = 0; i < soc.zone_num; i++) {
			for (j = 0; j < zone->bank_num; j++) {
				if (pos >= zone->bank[j].base &&
				    pos < zone->bank[j].base +
						    zone->bank[j].size) {
					filp->f_pos = pos;
					return filp->f_pos;
				}
			}

			zone++;
		}
		for (i = 0; i < soc.vdsp_num; i++) {
			if (pos >= vacc_dev->vdsp[i].base &&
			    pos < vacc_dev->vdsp[i].base +
					    vacc_dev->vdsp[i].size) {
				filp->f_pos = pos;
				return filp->f_pos;
			}
		}
		for (i = 0; i < soc.core_num; i++) {
			if (pos >= vacc_dev->odsp[i].base &&
			    pos < vacc_dev->odsp[i].base +
					    vacc_dev->odsp[i].size) {
				filp->f_pos = pos;
				return filp->f_pos;
			}
		}
	}

out:
	return -EINVAL;
}

static ssize_t vaccrt_cdev_read(struct file *filp, char __user *buffer,
				size_t size, loff_t *ppos)
{
	int ret = 0;
	u32 i, j;
	loff_t pos = *ppos;
	loff_t lenth = size;
	struct queue_desc *queue_desc = NULL;
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	struct vastai_soc soc = vacc_dev->soc;
	struct vastai_zone *zone = vacc_dev->zone;

	if (0 == lenth) {
		ret = -EINVAL;
		goto out;
	}

	if (pos == 0) {
		ret = vaccrt_vacc_read_info(vacc_dev, buffer, &lenth);
		if (ret < 0)
			return ret;
		ret = lenth;
		return ret;
	}

	for (i = 0; i < soc.zone_num; i++) {
		for (j = 0; j < zone->bank_num; j++) {
			if (pos >= zone->bank[j].base &&
			    pos < zone->bank[j].base + zone->bank[j].size) {
				if (lenth > zone->bank[j].base +
						    zone->bank[j].size - pos)
					lenth = zone->bank[j].base +
						zone->bank[j].size - pos;
				if (zone_stream == i)
					goto csram;
				else
					goto ddr;
			}
		}

		zone++;
	}
	for (i = 0; i < soc.vdsp_num; i++) {
		if (pos >= vacc_dev->vdsp[i].base &&
		    pos < vacc_dev->vdsp[i].base + vacc_dev->vdsp[i].size) {
			if (lenth > vacc_dev->vdsp[i].base +
					    vacc_dev->vdsp[i].size - pos)
				lenth = vacc_dev->vdsp[i].base +
					vacc_dev->vdsp[i].size - pos;
			goto ddr;
		}
	}
	for (i = 0; i < soc.core_num; i++) {
		if (pos >= vacc_dev->odsp[i].base &&
		    pos < vacc_dev->odsp[i].base + vacc_dev->odsp[i].size) {
			if (lenth > vacc_dev->odsp[i].base +
					    vacc_dev->odsp[i].size - pos)
				lenth = vacc_dev->odsp[i].base +
					vacc_dev->odsp[i].size - pos;
			goto ddr;
		}
	}
	for (i = 0; i < soc.core_num; i++) {
		if (pos >= vacc_dev->dlc[i].csr_base &&
		    pos < vacc_dev->dlc[i].csr_base + vacc_dev->dlc[i].csr_size) {
			if (lenth > vacc_dev->dlc[i].csr_base +
					    vacc_dev->dlc[i].csr_size - pos)
				lenth = vacc_dev->dlc[i].csr_base +
					vacc_dev->dlc[i].csr_size - pos;
			// dlc csr
			goto ddr;
		}
	}
	for (i = 0; i < soc.odma_num; i++) {
		if (pos >= vacc_dev->odmas[i].base &&
		    pos < vacc_dev->odmas[i].base + vacc_dev->odmas[i].size) {
			if (lenth > vacc_dev->odmas[i].base +
					    vacc_dev->odmas[i].size - pos)
				lenth = vacc_dev->odmas[i].base +
					vacc_dev->odmas[i].size - pos;
			// odma csr
			goto ddr;
		}
	}
	ret = -EINVAL;
	goto out;

csram:
	ret = vaccrt_map_read(vacc_dev, buffer, lenth, pos);
	if (!ret) {
		*ppos += lenth;
		ret = lenth;
	}
	goto out;

ddr:
	queue_desc = (struct queue_desc *)kzalloc(sizeof(struct queue_desc),
						   GFP_KERNEL);
	if (!queue_desc) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: failed to kzalloc queue_desc\n",
			       __func__);
		ret = -ENOMEM;
		goto out;
	}

	queue_desc->pos = pos;
	queue_desc->lenth = lenth;
	queue_desc->buffer = (void *)buffer;

	// (ret < 0) --> error, (ret = length) --> ok
	ret = vaccrt_add_read_queue(vacc_dev, queue_desc);
	if (ret == lenth)
		*ppos += lenth;

	kfree(queue_desc);

out:
	return ret;
}

static ssize_t vaccrt_cdev_write(struct file *filp, const char __user *buffer,
				 size_t size, loff_t *ppos)
{
	int ret = 0;
	u32 i, j;
	loff_t pos = *ppos;
	loff_t lenth = size;
	struct queue_desc *queue_desc = NULL;
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	struct vastai_soc soc = vacc_dev->soc;
	struct vastai_zone *zone = vacc_dev->zone;

	if (0 == lenth) {
		ret = -EINVAL;
		goto out;
	}

	for (i = 0; i < soc.zone_num; i++) {
		for (j = 0; j < zone->bank_num; j++) {
			if (pos >= zone->bank[j].base &&
			    pos < zone->bank[j].base + zone->bank[j].size) {
				if (lenth > zone->bank[j].base +
						    zone->bank[j].size - pos)
					lenth = zone->bank[j].base +
						zone->bank[j].size - pos;
				if (zone_stream == i)
					goto csram;
				else
					goto ddr;
			}
		}

		zone++;
	}
	for (i = 0; i < soc.vdsp_num; i++) {
		if (pos >= vacc_dev->vdsp[i].base &&
		    pos < vacc_dev->vdsp[i].base + vacc_dev->vdsp[i].size) {
			if (lenth > vacc_dev->vdsp[i].base +
					    vacc_dev->vdsp[i].size - pos)
				lenth = vacc_dev->vdsp[i].base +
					vacc_dev->vdsp[i].size - pos;
			goto ddr;
		}
	}
	for (i = 0; i < soc.core_num; i++) {
		if (pos >= vacc_dev->odsp[i].base &&
		    pos < vacc_dev->odsp[i].base + vacc_dev->odsp[i].size) {
			if (lenth > vacc_dev->odsp[i].base +
					    vacc_dev->odsp[i].size - pos)
				lenth = vacc_dev->odsp[i].base +
					vacc_dev->odsp[i].size - pos;
			goto ddr;
		}
	}
	ret = -EINVAL;
	goto out;

csram:
	ret = vaccrt_map_write(vacc_dev, buffer, lenth, pos);
	if (!ret) {
		*ppos += lenth;
		ret = lenth;
	}
	goto out;

ddr:
	queue_desc = (struct queue_desc *)kzalloc(sizeof(struct queue_desc),
						   GFP_KERNEL);
	if (!queue_desc) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: failed to kzalloc queue_desc\n",
			       __func__);
		ret = -ENOMEM;
		goto out;
	}

	queue_desc->pos = pos;
	queue_desc->lenth = lenth;
	queue_desc->buffer = (void *)buffer;

	ret = vaccrt_add_write_queue(vacc_dev, queue_desc);

	if (ret == lenth)
		*ppos += lenth;

	kfree(queue_desc);

out:
	return ret;
}

static unsigned int vaccrt_cdev_poll(struct file *filp,
				     struct poll_table_struct *wait)
{
	return 0;
}

static inline int vaccrt_cmd_mmap_init(struct vastai_cdev *va_dev,
				       union vastai_cmd *mmap)
{
	int ret = 0;
	int is_init = 0;
	pid_t pid = task_tgid_nr(current);
	int try_count = 0;

	if (mmap_idle == mmap->mmap_init.state) {
	try_init:
		if (try_count > 10) {
			VASTAI_PCI_ERR(va_dev->pci_info, va_dev->die_id,
				       "wait_event try too much, give up.\n");
			ret = -ETIMEDOUT;
			goto out;
		}

		if (va_dev->mmap.state < mmap_initialized) {
			mutex_lock(&va_dev->mmap.mutex);
			if (mmap_idle == va_dev->mmap.state) {
				va_dev->mmap.state = mmap_initializing;
				va_dev->mmap.pid = pid;
				is_init = 1;
				// pr_debug("test module cdev mmap mmap_idle\n");
			}
			mutex_unlock(&va_dev->mmap.mutex);
			if (is_init || mmap_initialized == va_dev->mmap.state)
				goto out;

			ret = wait_event_interruptible_timeout(
				va_dev->mmap.wait,
				(va_dev->mmap.state != mmap_initializing),
				HZ / 10);

			if (ret >= 0) {
				ret = 0;
				try_count++;
				goto try_init;
			}
		}
	} else if (mmap_initialized == mmap->mmap_init.state) {
		if (va_dev->mmap.pid == pid) {
			mutex_lock(&va_dev->mmap.mutex);
			if (mmap_initializing == va_dev->mmap.state) {
				va_dev->mmap.state = mmap_initialized;
				wake_up_interruptible(&va_dev->mmap.wait);
			}
			else
				ret = -EINVAL;
			mutex_unlock(&va_dev->mmap.mutex);
			// pr_debug("test module cdev mmap mmap_initialized\n");
		} else
			ret = -EINVAL;
	} else
		ret = -EINVAL;

out:
	return ret;
}

typedef int (*set_desc_func)(struct vastai_dmadesc *, struct dma_buf *,
			     union vastai_cmd *, int, u32, u32,
			     struct vastai_pci_info *);

static long vaccrt_cdev_ioctl(struct file *filp, unsigned int cmd,
			      unsigned long arg)
{
	int ret;
	int id = 0;
	u64 addr = 0;
	u64 addr_min = 0;
	u64 addr_max = 0;
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	u32 buf_num = 0;
	#endif
	union vastai_cmd vastai_cmd;
	u8 buffer[256] = { 0 };
	// union vastai_cmd_e vastai_cmd_e;
	void __user *argp = (void __user *)arg;
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	struct dev_process *current_process = (struct dev_process *)vastai_cdev_data->dev_process;
	// zone_model is the first zone
	struct vastai_zone *zone = vacc_dev->zone;
	// struct process_node *process;
	struct dev_process *dev_process = NULL;
	// pid_t pid = task_tgid_nr(current);
	if (!current_process)
		return -EINVAL;

	switch (cmd) {
	case VACC_RESET_DEV: {
		// pr_info("test module cdev ioctl VACC_RESET_DEV:0x%x\n", VACC_RESET_DEV);
		/* code */
		break;
	}

	case VACC_LOAD_MODEL: {
		// pr_info("test module cdev ioctl VACC_LOAD_MODEL:0x%lx\n", VACC_LOAD_MODEL);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_load_model.model_addr;
		addr_min = zone[zone_model].entry;
		addr_max =
			zone[zone_model].entry + zone[zone_model].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			addr_min = zone[zone_model].entry1;
			addr_max = zone[zone_model].entry1 +
				   zone[zone_model].bank[1].size;
			if (addr < addr_min || addr >= addr_max) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] model_addr:0x%llx, [min_0:0x%llx, max_0:0x%llx], [min_1:0x%llx, max_1:0x%llx]\n",
					addr, (u64)zone[zone_model].entry,
					(u64)(zone[zone_model].entry +
					      zone[zone_model].bank[0].size),
					(u64)zone[zone_model].entry1,
					(u64)(zone[zone_model].entry1 +
					      zone[zone_model].bank[1].size));
				return -EINVAL;
			}
		}
		vastai_cmd.run_load_model.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_LOAD_MODEL);
		if (ret)
			return ret;
		break;
	}

	case VACC_DESTROY_MODEL: {
		// pr_info("test module cdev ioctl VACC_DESTROY_MODEL:0x%lx\n", VACC_DESTROY_MODEL);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_load_model.model_addr;
		addr_min = zone[zone_model].entry;
		addr_max =
			zone[zone_model].entry + zone[zone_model].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			addr_min = zone[zone_model].entry1;
			addr_max = zone[zone_model].entry1 +
				   zone[zone_model].bank[1].size;
			if (addr < addr_min || addr >= addr_max) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] model_addr:0x%llx, [min_0:0x%llx, max_0:0x%llx], [min_1:0x%llx, max_1:0x%llx]\n",
					addr, (u64)zone[zone_model].entry,
					(u64)(zone[zone_model].entry +
					      zone[zone_model].bank[0].size),
					(u64)zone[zone_model].entry1,
					(u64)(zone[zone_model].entry1 +
					      zone[zone_model].bank[1].size));
				return -EINVAL;
			}
		}
		vastai_cmd.run_load_model.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_DESTROY_MODEL);
		if (ret)
			return ret;
		break;
	}

	case VACC_RUN_MODEL: {
		// pr_info("test module cdev ioctl VACC_RUN_MODEL:0x%lx\n", VACC_RUN_MODEL);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_load_model.model_addr;
		addr_min = zone[zone_model].entry;
		addr_max =
			zone[zone_model].entry + zone[zone_model].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			addr_min = zone[zone_model].entry1;
			addr_max = zone[zone_model].entry1 +
				   zone[zone_model].bank[1].size;
			if (addr < addr_min || addr >= addr_max) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] model_addr:0x%llx, [min_0:0x%llx, max_0:0x%llx], [min_1:0x%llx, max_1:0x%llx]\n",
					addr, (u64)zone[zone_model].entry,
					(u64)(zone[zone_model].entry +
					      zone[zone_model].bank[0].size),
					(u64)zone[zone_model].entry1,
					(u64)(zone[zone_model].entry1 +
					      zone[zone_model].bank[1].size));
				return -EINVAL;
			}
		}
		vastai_cmd.run_load_model.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_RUN_MODEL);
		if (ret)
			return ret;
		break;
	}

	case VACC_RUN_KERNEL: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		vastai_cmd.run_kernel.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				     CMD_RUN_KERENL);
		if (ret)
			return ret;
		break;
	}

	case VACC_LOAD_VDSP_OPERATOR: {
		// pr_info("test module cdev ioctl VACC_LOAD_OPERATOR:0x%lx\n", VACC_LOAD_OPERATOR);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_load_operator.operator_addr;
		addr_min = zone[zone_vdsp_operator].entry;
		addr_max = zone[zone_vdsp_operator].entry +
			   zone[zone_vdsp_operator].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] operator_addr:0x%llx, min:0x%llx, max:0x%llx\n",
				addr, addr_min, addr_max);
			return -EINVAL;
		}
		vastai_cmd.run_load_operator.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_LOAD_VDSP_OPERATOR);
		if (ret)
			return ret;
		break;
	}

	case VACC_LOAD_ODSP_OPERATOR: {
		// pr_info("test module cdev ioctl VACC_LOAD_OPERATOR:0x%lx\n", VACC_LOAD_OPERATOR);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_load_operator.operator_addr;
		addr_min = zone[zone_odsp_operator].entry;
		addr_max = zone[zone_odsp_operator].entry +
			   zone[zone_odsp_operator].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] operator_addr:0x%llx, min:0x%llx, max:0x%llx\n",
				addr, addr_min, addr_max);
			return -EINVAL;
		}
		vastai_cmd.run_load_operator.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_LOAD_ODSP_OPERATOR);
		if (ret)
			return ret;
		break;
	}

	case VACC_LOAD_OPERATOR: {
		// pr_info("test module cdev ioctl VACC_LOAD_OPERATOR:0x%lx\n", VACC_LOAD_OPERATOR);
		operator_load_cmd_t operator_load_cmd;
		memset(&operator_load_cmd, 0, sizeof(operator_load_cmd_t));
		if (vaccrt_ai_copy_from_user(&operator_load_cmd, argp,
				   sizeof(operator_load_cmd_t)))
			return -EFAULT;

		ret = operator_load(vacc_dev, current_process,
					 (void *)&operator_load_cmd, 0);
		if (ret)
			return ret;
		break;
	}

	case VACC_LOAD_OPERATOR_v2: {
		// pr_info("test module cdev ioctl VACC_LOAD_OPERATOR:0x%lx\n", VACC_LOAD_OPERATOR);
		operator_load_v2_cmd_t operator_load_v2_cmd;
		memset(&operator_load_v2_cmd, 0, sizeof(operator_load_v2_cmd_t));
		if (vaccrt_ai_copy_from_user(&operator_load_v2_cmd, argp,
				   sizeof(operator_load_v2_cmd_t)))
			return -EFAULT;

		ret = operator_load(vacc_dev, current_process,
					 (void *)&operator_load_v2_cmd, 1);
		if (ret)
			return ret;
		break;
	}

	case VACC_RUN_STREAM: {
		// pr_info("test module cdev ioctl VACC_RUN_STREAM:0x%lx\n", VACC_RUN_STREAM);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		addr = vastai_cmd.run_stream.stream_addr;
		addr_min = zone[zone_stream].entry;
		addr_max = zone[zone_stream].entry +
			   zone[zone_stream].bank[0].size;
		if (addr < addr_min || addr >= addr_max) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] model_addr:0x%llx, min:0x%llx, max:0x%llx\n",
				addr, addr_min, addr_max);
			return -EINVAL;
		}
		vastai_cmd.run_stream.pid = current_process->pid;
		ret = vaccrt_cmd_run(vacc_dev, current_process, &vastai_cmd,
				      CMD_RUN_STREAM);
		if (ret)
			return ret;
		break;
	}

	case VACC_GET_OUT_DESC: {
		// pr_info("test module cdev ioctl VACC_GET_OUT_DESC:0x%lx\n", VACC_GET_OUT_DESC);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		vastai_cmd.get_desc.pid = current_process->pid;
		ret = vaccrt_cmd_get_desc(vacc_dev, current_process,
					  &vastai_cmd);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
	}

	case VACC_GET_CURRENT_PID: {
		// pr_info("test module cdev ioctl VACC_GET_CURRENT_PID:%ld\n", VACC_GET_CURRENT_PID);
		vastai_cmd.process.pid = current_process->pid;
		vastai_cmd.process.vpid = current_process->vpid;
		vastai_cmd.process.ns = current_process->ns;
		vastai_cmd.process.level = current_process->level;
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
	}

	case VACC_GET_PROCESS: {
		// pr_info("test ioctl VACC_GET_PROCESS:0x%lx\n", VACC_GET_PROCESS);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		// if (vastai_cmd.process.pid == pid)
		// 	return -EINVAL;

		vastai_cmd.process.state = 0;
		mutex_lock(&vacc_dev->dev_trans_ai->mutex);
		list_for_each_entry (dev_process, &vacc_dev->dev_trans_ai->head,
				     node) {
			if (dev_process->pid == vastai_cmd.process.pid && !dev_process->proc_state) {
				vastai_cmd.process.state = 1;
				break;
			}
		}
		mutex_unlock(&vacc_dev->dev_trans_ai->mutex);
		// mutex_lock(&vacc_dev->process_mutex);
		// list_for_each_entry (process, &vacc_dev->process_head, node) {
		// 	if (process->pid == vastai_cmd.process.pid) {
		// 		vastai_cmd.process.state = 1;
		// 		break;
		// 	}
		// }
		// mutex_unlock(&vacc_dev->process_mutex);
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}

	case VACC_RELEASE_PROCESS: {
		// pr_info("test ioctl VACC_RELEASE_PROCESS:0x%lx\n", VACC_RELEASE_PROCESS);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		if (vastai_cmd.process.pid == current_process->pid)
			return -EINVAL;

		vastai_cmd.process.state = 0;
		mutex_lock(&vacc_dev->dev_trans_ai->mutex);
		list_for_each_entry (dev_process, &vacc_dev->dev_trans_ai->head,
				     node) {
			if (dev_process->pid == vastai_cmd.process.pid) {
				vastai_cmd.process.state = 1;
				break;
			}
		}
		mutex_unlock(&vacc_dev->dev_trans_ai->mutex);
		// vastai_cmd.process.state = vastai_release_dev_process(
		// 	vacc_dev, vastai_cmd.process.pid);
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
	}

	case VACC_CP_DIE2DIE: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		if (vaccrt_ai_data_movement(vacc_dev, &vastai_cmd))
			return -EIO;
		break;
	}

	case VACC_CP_PEER2PEER: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		if (vaccrt_ai_data_movement_peers(vacc_dev, &vastai_cmd))
			return -EIO;
		break;
	}

	case VACC_CP_DDR2DDR: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		if (vaccrt_ai_data_movement_inner(vacc_dev, &vastai_cmd, current_process->pid))
			return -EIO;
		break;
	}

	case VACC_CREATE_STREAM: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		ret = vaccrt_ai_create_stream(vacc_dev, current_process, &vastai_cmd);
		return ret;
		break;
	}

	case VACC_DESTROY_STREAM: {
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		ret = vaccrt_ai_destroy_stream(vacc_dev, current_process, &vastai_cmd);
		return ret;
		break;
	}

	case VACC_DDR_OVERFLOW: {
		// pr_info("test ioctl VACC_DDR_OVERFLOW:0x%lx\n", VACC_DDR_OVERFLOW);
		// if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
		// 	return -EFAULT;
		VASTAI_PCI_INFO(vacc_dev->pci_info, vacc_dev->die_id,
				"%s: ddr memory size is not enough !!!\n",
				__func__);
		break;
	}

	case VACC_RD_VERSION: {
		if (vaccrt_ai_copy_to_user(argp, &(vacc_dev->ai_version), sizeof(u32)))
			return -EFAULT;
		break;
	}

	case VACC_RD_FW_STATUS: {
		if (vaccrt_ai_copy_to_user(argp, &(vacc_dev->fw_status), sizeof(u32)))
			return -EFAULT;
		break;
	}

	case VACC_RD_SOC: {
		// pr_info("test module cdev ioctl VACC_RD_SOC:%ld\n", VACC_RD_SOC);
		vacc_dev->soc.render_id = vastai_get_render_id(
			vacc_dev->pci_info, vacc_dev->die_index);
		if (vaccrt_ai_copy_to_user(argp, &vacc_dev->soc,
				 sizeof(struct vastai_soc)))
			return -EFAULT;
		//pr_info("render id %d\n", vacc_dev->soc.render_id);
		break;
	}

	case VACC_RD_ZONE: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_ZONE:%ld, zone_id:%d\n", VACC_RD_ZONE, id);

		if (id >= vacc_dev->soc.zone_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->zone + id,
				 sizeof(struct vastai_zone)))
			return -EFAULT;
		break;
	}

	case VACC_RD_DLC: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_DLC:%ld, dlc_id:%d\n", VACC_RD_DLC, id);

		if (id >= vacc_dev->soc.core_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->dlc + id,
				 sizeof(struct vastai_dlc)))
			return -EFAULT;
		break;
	}

	case VACC_RD_SSRAM: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_SSRAM:%ld, ssram_id:%d\n", VACC_RD_SSRAM, id);

		if (id >= vacc_dev->soc.ssram_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->ssram + id,
				 sizeof(struct vastai_ssram)))
			return -EFAULT;
		break;
	}

	case VACC_RD_BAR: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_BAR:%ld, bar_id:%d\n", VACC_RD_BAR, id);

		if (id >= vacc_dev->soc.bar_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->bars + id,
				 sizeof(struct vastai_bar)))
			return -EFAULT;
		break;
	}

	case VACC_RD_ODAM: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_ODAM:%ld, odma_id:%d\n", VACC_RD_ODAM, id);

		if (id >= vacc_dev->soc.odma_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->odmas + id,
				 sizeof(struct vastai_odma)))
			return -EFAULT;
		break;
	}

	case VACC_RD_VDSP: {
		get_user(id, (int *)argp);
		// pr_info("test module cdev ioctl VACC_RD_ODAM:%ld, odma_id:%d\n", VACC_RD_ODAM, id);

		if (id >= vacc_dev->soc.vdsp_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->vdsp + id,
				 sizeof(struct vastai_vdsp)))
			return -EFAULT;
		break;
	}

	case VACC_RD_ODSP: {
		get_user(id, (int *)argp);

		if (id >= vacc_dev->soc.core_num)
			return -EINVAL;

		if (vaccrt_ai_copy_to_user(argp, vacc_dev->odsp + id,
				 sizeof(struct vastai_odsp)))
			return -EFAULT;
		break;
	}

	case VACC_DDR_TO_BAR: {
		struct bar_ddr_trans_info trans_info;
		if (vaccrt_ai_copy_from_user(&trans_info, argp,
					     sizeof(struct bar_ddr_trans_info)))
			return -EFAULT;

		#if CONFIG_VASTAI_SOC_HW_TYPE==1
		ret = vastai_ddr_to_bar(vacc_dev->pci_info, vacc_dev->die_index,
					trans_info.soc_ddr_address,
					&trans_info.bar_address);
		#elif CONFIG_VASTAI_SOC_HW_TYPE==2
		ret = -EINVAL;
		#else
		#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
		#endif
		if (ret)
			return ret;

		if (vaccrt_ai_copy_to_user(argp, &trans_info,
					   sizeof(struct bar_ddr_trans_info)))
			return -EFAULT;
		break;
	}

	case VACC_ECC2BIT: {
		/* TODO: for now, this flag is always be false */
		bool is_power_on_info = 0;
		union die_index_data die_index;

		die_index.val = vacc_dev->die_index;
		/*
		   ret = 0 (get ecc error report)
		   ret = -512 (thread kill by "kill -9 or CTRL-c")
		*/
		ret = vastai_wait_ecc_2_bit(vacc_dev->pci_info, die_index);
		if (ret < 0) {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] %s wait ecc report out with exception %d",
				__func__, ret);
			return ret;
		}

		/* if we get complete we need do this：
			1. read ddr at device: 0x8_1520_0000 ~ 0x8_1530_0000 1Mbyte
			2. there is a fifo head at this buf head. refer: struct vastai_fifo
			3. we can get valid entry number from this format:
				valid_entry_count = (fifo->elem_count - ((int)fifo->wr - (int)fifo-rd)) % fifo->elem_count
		*/

		if (vaccrt_ai_copy_to_user(argp, (void *)(&is_power_on_info),
				 sizeof(is_power_on_info)))
			return -EFAULT;
		break;
	}

	case VACC_MMAP_INIT: {
		// pr_info("test module cdev ioctl VACC_MMAP_INIT:%ld\n", VACC_MMAP_INIT);
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		ret = vaccrt_cmd_mmap_init(vacc_dev, &vastai_cmd);
		if (ret)
			return ret;
		vastai_cmd.mmap_init.state = vacc_dev->mmap.state;
		vastai_cmd.mmap_init.addr = vacc_dev->mmap.addr;
		vastai_cmd.mmap_init.size = vacc_dev->mmap.size;
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
	}

	case VACC_SHMRE_ALLOC: {
		if (vaccrt_ai_copy_from_user(buffer, argp,
				   sizeof(shmre_alloc_cmd_t)))
			return -EFAULT;
		ret = vaccrt_shmre_alloc(vacc_dev,
					 vastai_cdev_data->dev_process,
					 (shmre_alloc_cmd_t *)buffer);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, buffer, sizeof(shmre_alloc_cmd_t)))
			return -EFAULT;
		break;
	}

	case VACC_SHMRE_FREE: {
		if (vaccrt_ai_copy_from_user(buffer, argp, sizeof(shmre_free_cmd_t)))
			return -EFAULT;
		ret = vaccrt_shmre_free(vacc_dev, vastai_cdev_data->dev_process,
					(shmre_free_cmd_t *)buffer);
		if (ret)
			return ret;
		break;
	}

	case VACC_VDSP_GET: {
		ret = vaccrt_vdsp_get(vacc_dev, vastai_cdev_data->dev_process,
				      (vdsp_used_cmd_t *)buffer);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, buffer, sizeof(vdsp_used_cmd_t)))
			return -EFAULT;
		break;
	}

	case VACC_VDSP_PUT: {
		if (vaccrt_ai_copy_from_user(buffer, argp, sizeof(vdsp_used_cmd_t)))
			return -EFAULT;
		ret = vaccrt_vdsp_put(vacc_dev, vastai_cdev_data->dev_process,
				      (vdsp_used_cmd_t *)buffer);
		if (ret)
			return ret;
		break;
	}

	case VACC_REGISTER_OPERATOR: {
		if (vaccrt_ai_copy_from_user(buffer, argp, sizeof(operator_register_cmd_t)))
			return -EFAULT;
		ret = operator_manager_register_op(vacc_dev, vastai_cdev_data->dev_process,
				      (void *)buffer, 0);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, buffer, sizeof(operator_register_cmd_t)))
			return -EFAULT;
		break;
	}

	case VACC_REGISTER_OPERATOR_v2: {
		if (vaccrt_ai_copy_from_user(buffer, argp, sizeof(operator_register_v2_cmd_t)))
			return -EFAULT;
		ret = operator_manager_register_op(vacc_dev, vastai_cdev_data->dev_process,
				      (void *)buffer, 1);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, buffer, sizeof(operator_register_v2_cmd_t)))
			return -EFAULT;
		break;
	}

	case VACC_UNREGISTER_OPERATOR: {
		if (vaccrt_ai_copy_from_user(buffer, argp, sizeof(operator_unregister_cmd_t)))
			return -EFAULT;
		ret = operator_manager_unregister_op(vacc_dev, vastai_cdev_data->dev_process,
				      (operator_unregister_cmd_t *)buffer);
		if (ret)
			return ret;
		if (vaccrt_ai_copy_to_user(argp, buffer, sizeof(operator_unregister_cmd_t)))
			return -EFAULT;
		break;
	}

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	case VACC_DMA_BUF_ALLOC: {
		struct dma_buf *dmabuf;

		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;

		if (iommu_is_enable(vacc_dev->pci_info))
			dmabuf = vastai_alloc_dma_buf_sg(
				vacc_dev->pci_info,
				vastai_cmd.dmabuf_alloc_cmd.size);
		else
			dmabuf = vastai_alloc_dma_buf(
				vacc_dev->pci_info,
				vastai_cmd.dmabuf_alloc_cmd.size);

		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			vastai_cmd.dmabuf_alloc_cmd.dma_buf_fd = fd;
		} else {
			return -ENOMEM;
		}

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}

	case VACC_DMA_BUF_START: {
		dma_node_start_cmd_t dma_start_cmd;
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		vastai_cmd.dmabuf_start_cmd.die_index = vacc_dev->die_index;

		/*dma_node_start_cmd_t and dmabuf_start_cmd is different struct, we should transfer it*/
		dma_start_cmd.is_dev_to_host = vastai_cmd.dmabuf_start_cmd.is_dev_to_host;
		dma_start_cmd.dma_buf_fd     = vastai_cmd.dmabuf_start_cmd.dma_buf_fd;
		dma_start_cmd.axi_addr       = vastai_cmd.dmabuf_start_cmd.axi_addr;
		dma_start_cmd.size           = vastai_cmd.dmabuf_start_cmd.size;
		dma_start_cmd.die_index      = vastai_cmd.dmabuf_start_cmd.die_index;

		ret = vastai_pci_dma_start(vacc_dev->pci_info, &dma_start_cmd);

		if (ret)
			return ret;

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
	}

	case VACC_DMA_BUF_TRANS: {
		dma_node_trans_cmd_t dma_trans_cmd;
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp, sizeof(union vastai_cmd)))
			return -EFAULT;
		vastai_cmd.dmabuf_trans_cmd.die_index = vacc_dev->die_index;

		/*dma_node_trans_cmd_t and dmabuf_trans_cmd is different struct, we should transfer it*/
		dma_trans_cmd.is_dev_to_host = vastai_cmd.dmabuf_trans_cmd.is_dev_to_host;
		dma_trans_cmd.vir_addr       = (u64)vastai_cmd.dmabuf_trans_cmd.vir_addr;
		dma_trans_cmd.axi_addr       = vastai_cmd.dmabuf_trans_cmd.axi_addr;
		dma_trans_cmd.length         = vastai_cmd.dmabuf_trans_cmd.length;
		dma_trans_cmd.die_index      = vastai_cmd.dmabuf_trans_cmd.die_index;
		dma_trans_cmd.pid            = vastai_cmd.dmabuf_trans_cmd.pid;

		ret = vastai_pci_dma_trans(vacc_dev->pci_info, &dma_trans_cmd);

		if (ret)
			return ret;

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd, sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}

#ifdef CONFIG_RDMA_DMABUF
	case VACC_RDMA_DMABUF_FD: {
		struct dma_buf *dmabuf;

		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp,
					     sizeof(union vastai_cmd)))
			return -EFAULT;

		dmabuf = vastai_rdma_dmabuf_export(
			vacc_dev->pci_info, vacc_dev->die_index,
			vastai_cmd.vccl_dmabuf_alloc_cmd.size,
			&vastai_cmd.vccl_dmabuf_alloc_cmd.dma_addr_t,
			vastai_cmd.vccl_dmabuf_alloc_cmd.mem_type);

		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			vastai_cmd.vccl_dmabuf_alloc_cmd.dma_buf_fd = fd;
		} else {
			return -ENOMEM;
		}

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd,
					   sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}
	case VACC_RDMA_HOSTBUF_GET:
		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp,
					     sizeof(union vastai_cmd)))
			return -EFAULT;
		ret = vastai_rdma_hostbuf_get(vastai_cmd.vccl_rdma_hostbuf_cmd.dmabuf_fd,
									&buf_num,
									vastai_cmd.vccl_rdma_hostbuf_cmd.buf_list);
		if(ret)
			return ret;
		vastai_cmd.vccl_rdma_hostbuf_cmd.buf_num = buf_num;
		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd,
					   sizeof(union vastai_cmd)))
			return -EFAULT;
		break;
#endif

	case VACC_VCCL_BUF_ALLOC: {
		struct dma_buf *dmabuf;

		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp,
					     sizeof(union vastai_cmd)))
			return -EFAULT;

		dmabuf = vastai_alloc_vccl_buf(
			vacc_dev->pci_info, vastai_cmd.vccl_dmabuf_alloc_cmd.size,
			&vastai_cmd.vccl_dmabuf_alloc_cmd.dma_addr_t);

		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			vastai_cmd.vccl_dmabuf_alloc_cmd.dma_buf_fd = fd;
		} else {
			return -ENOMEM;
		}

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd,
					   sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}

	case VACC_DMA_BUF_ALLOC2: {
		struct dma_buf *dmabuf;

		if (vaccrt_ai_copy_from_user(&vastai_cmd, argp,
					     sizeof(union vastai_cmd)))
			return -EFAULT;

		dmabuf = vastai_alloc_dma_buf_with_addr(
			vacc_dev->pci_info, vastai_cmd.vccl_dmabuf_alloc_cmd.size,
			&vastai_cmd.vccl_dmabuf_alloc_cmd.dma_addr_t);

		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			vastai_cmd.vccl_dmabuf_alloc_cmd.dma_buf_fd = fd;
		} else {
			return -ENOMEM;
		}

		if (vaccrt_ai_copy_to_user(argp, &vastai_cmd,
					   sizeof(union vastai_cmd)))
			return -EFAULT;

		break;
	}
#endif

	default:
		return -EINVAL;
		break;
	}

	return 0;
}

static void vaccrt_vma_open(struct vm_area_struct *vma)
{
}

static void vaccrt_vma_close(struct vm_area_struct *vma)
{
}

static struct vm_operations_struct vastai_mmap_ops = {
	.open = vaccrt_vma_open,
	.close = vaccrt_vma_close,
};

static int vaccrt_cdev_mmap(struct file *filp, struct vm_area_struct *vma)
{
	int ret = 0;
	struct mmap_page *mmap_page = NULL;
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;
	u64 video_phys_addr_origin = 0;

	// pr_debug("test module mmap vm_pgoff:0x%lx\n", vma->vm_pgoff);
	// pr_debug("test module mmap VD_RESERVE pfn:0x%lx\n", __phys_to_pfn(VD_MMAP_BASE - vacc_dev->bars[1].ddr_base + vacc_dev->bars[1].base));
	// pr_debug("test module mmap MMAP pfn:0x%lx\n", __phys_to_pfn(vacc_dev->mmap.addr));

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	video_phys_addr_origin = vacc_dev->bars[1].base + VD_MMAP_BASE -
			       vacc_dev->bars[1].ddr_base;
	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	video_phys_addr_origin =
		vacc_dev->pci_info->vastai_ai_info->decoder_buf_host_phy_addr;
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif

	// printk("%s: vacc%d vma->vm_pgoff = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, vma->vm_pgoff);
	// printk("%s: vacc%d __phys_to_pfn(vacc_dev->mmap.addr) = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, __phys_to_pfn(vacc_dev->mmap.addr));
	// printk("%s: vacc%d __phys_to_pfn(vacc_dev->soc.video_phys_addr) = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, __phys_to_pfn(vacc_dev->soc.video_phys_addr));
	// printk("%s: vacc%d __phys_to_pfn(vacc_dev->soc.csram_phys_addr) = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, __phys_to_pfn(vacc_dev->soc.csram_phys_addr));
	// printk("%s: vacc%d __phys_to_pfn(vacc_dev->soc.share_phys_addr) = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, __phys_to_pfn(vacc_dev->soc.share_phys_addr));
	// printk("%s: vacc%d __phys_to_pfn(vacc_dev->soc.share_phys_addr + vacc_dev->soc.share_size -1) = 0x%lX\n", __func__, vacc_dev->soc.vacc_id, __phys_to_pfn(vacc_dev->soc.share_phys_addr + vacc_dev->soc.share_size -1));

	if (vma->vm_pgoff == __phys_to_pfn(vacc_dev->mmap.addr)) {
		size_t offset = 0;
		if (vma->vm_end - vma->vm_start == vacc_dev->mmap.size) {
			list_for_each_entry (mmap_page, &vacc_dev->mmap.head,
					     node) {
				if (remap_pfn_range(
					    vma, vma->vm_start + offset,
					    page_to_pfn(mmap_page->page),
					    PAGE_SIZE * ((size_t)1
							 << (VACCRT_MAX_ORDER - 1)),
					    vma->vm_page_prot)) {
					ret = -EAGAIN;
					goto out;
				}
				offset += PAGE_SIZE *
					  ((size_t)1 << (VACCRT_MAX_ORDER - 1));
			}
			vma->vm_ops = &vastai_mmap_ops;
		} else
			ret = -EINVAL;
	} else if (vma->vm_pgoff ==
		   __phys_to_pfn(vacc_dev->soc.video_phys_addr)) {
		unsigned long size =
			vacc_dev->soc.video_size <=
					vma->vm_end - vma->vm_start ?
				vacc_dev->soc.video_size :
				vma->vm_end - vma->vm_start;
#if (defined(__aarch64__) || defined(__arm__))
		vma->vm_page_prot = phys_mem_access_prot(
			filp, __phys_to_pfn(video_phys_addr_origin), size,
			vma->vm_page_prot);
#endif
		if (remap_pfn_range(vma, vma->vm_start,
				    __phys_to_pfn(video_phys_addr_origin), size,
				    vma->vm_page_prot)) {
			ret = -EAGAIN;
			goto out;
		}
		vma->vm_ops = &vastai_mmap_ops;
	} else if (vma->vm_pgoff >=
			   __phys_to_pfn(vacc_dev->soc.csram_phys_addr) &&
		   vma->vm_pgoff <=
			   __phys_to_pfn(vacc_dev->soc.csram_phys_addr +
					 vacc_dev->soc.csram_size - 1)) {
		unsigned long size =
			vacc_dev->soc.csram_size <=
					vma->vm_end - vma->vm_start ?
				vacc_dev->soc.csram_size :
				vma->vm_end - vma->vm_start;
#if (defined(__aarch64__) || defined(__arm__))
		vma->vm_page_prot = phys_mem_access_prot(
			filp, __phys_to_pfn(vma->vm_pgoff), size,
			vma->vm_page_prot);
#endif
		if (remap_pfn_range(vma, vma->vm_start, vma->vm_pgoff, size,
				    vma->vm_page_prot)) {
			ret = -EAGAIN;
			goto out;
		}
		vma->vm_ops = &vastai_mmap_ops;
	} else if (vma->vm_pgoff >=
			   __phys_to_pfn(vacc_dev->soc.share_phys_addr) &&
		   vma->vm_pgoff <=
			   __phys_to_pfn(vacc_dev->soc.share_phys_addr +
					 vacc_dev->soc.share_size - 1)) {
		unsigned long size =
			vacc_dev->soc.share_size <=
					vma->vm_end - vma->vm_start ?
				vacc_dev->soc.share_size :
				vma->vm_end - vma->vm_start;
#if (defined(__aarch64__) || defined(__arm__))
		vma->vm_page_prot = phys_mem_access_prot(
			filp, vma->vm_pgoff, size, vma->vm_page_prot);
#endif
		if (remap_pfn_range(vma, vma->vm_start, vma->vm_pgoff, size,
				    vma->vm_page_prot)) {
			ret = -EAGAIN;
			goto out;
		}
		vma->vm_ops = &vastai_mmap_ops;
	} else
		ret = -EINVAL;

out:
	return ret;
}

static int vaccrt_cdev_fasync(int fd, struct file *filp, int mode)
{
	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;

	return fasync_helper(fd, filp, mode, &vacc_dev->fasync);
}

#if CONFIG_VASTAI_SOC_HW_TYPE==1
extern int vastai_add_file(struct vastai_pci_info *pci_info);
extern int vastai_del_file(struct vastai_pci_info *pci_info);
#endif

static int vaccrt_cdev_open(struct inode *inode, struct file *filp)
{
	int ret = 0;
	struct vastai_cdev *vacc_dev = NULL;
	struct vastai_file_info *file_info = NULL;
	struct vastai_cdev_data *vastai_cdev_data = NULL;
	// struct process_node *process = NULL;
	struct vastai_soc *soc = NULL;
	struct vastai_pci_info *priv = NULL;

	file_info = to_vastai_file_info(inode->i_cdev);
	vacc_dev = container_of(file_info, struct vastai_cdev, file_info);

	soc = (struct vastai_soc *)&(vacc_dev->soc);
	priv = vacc_dev->pci_info;
	if ((atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE)) {
		return -ENODEV;
	}

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	if (soc->type == VASTAI_SV100_HV) {
		soc->harvest_core_flag = vastai_get_dlc_cores_info(priv, vacc_dev->die_index);
	}
	#endif

	vastai_cdev_data = kzalloc(sizeof(struct vastai_cdev_data), GFP_KERNEL);
	vastai_cdev_data->vacc_dev = vacc_dev;
	// vastai_cdev_data->pid = pid;

	ret = vaccrt_add_dev_process(vacc_dev, &(vastai_cdev_data->dev_process));

	// if (ret == 0) {
	// 	vastai_cdev_data->dev_process = get_dev_process(vacc_dev, pid);
	// }
	filp->private_data = vastai_cdev_data;

	if (ret) {
		goto out;
	}

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	ret = vastai_add_file(priv);
	if(ret) {
		goto out;
	}
	#endif

	// if (ret)
	// 	goto out;

	// process = kzalloc(sizeof(struct process_node), GFP_KERNEL);
	// if (!process) {
	// 	ret = -ENOMEM;
	// 	goto out;
	// }
	// process->pid = pid;
	// mutex_lock(&vacc_dev->process_mutex);
	// list_add_tail(&process->node, &vacc_dev->process_head);
	// mutex_unlock(&vacc_dev->process_mutex);

	// pr_debug("test module cdev open\n");
out:
	if (ret) {
		// once ret is not zero, means xxx_open failed, xxx_release will not be called
		// so we need to kfree private_data to fix mem-leak
		if (filp->private_data) {
			kfree(filp->private_data);
			filp->private_data = NULL;
		}
	}
	return ret;
}

static int vaccrt_cdev_release(struct inode *inode, struct file *filp)
{
	// struct vastai_cdev *vacc_dev = NULL;
	// struct vastai_file_info *file_info = NULL;
	// struct process_node *process = NULL;
	// pid_t pid = task_tgid_nr(current);

	// file_info = to_vastai_file_info(inode->i_cdev);
	// vacc_dev = container_of(file_info, struct vastai_cdev, file_info);

	struct vastai_cdev_data *vastai_cdev_data = (struct vastai_cdev_data *)filp->private_data;
	struct vastai_cdev *vacc_dev = (struct vastai_cdev *)vastai_cdev_data->vacc_dev;

	if (vacc_dev->mmap.pid == vastai_cdev_data->dev_process->pid) {
		mutex_lock(&vacc_dev->mmap.mutex);
		if (mmap_initializing == vacc_dev->mmap.state) {
			vacc_dev->mmap.state = mmap_idle;
			wake_up_interruptible(&vacc_dev->mmap.wait);
		}
		mutex_unlock(&vacc_dev->mmap.mutex);
		// pr_debug("test module cdev mmap reset mmap_idle\n");
	}

	vaccrt_remove_dev_process(vacc_dev, vastai_cdev_data->dev_process);
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	vastai_del_file(vacc_dev->pci_info);
	#endif
	kfree(filp->private_data);

	// mutex_lock(&vacc_dev->process_mutex);
	// list_for_each_entry (process, &vacc_dev->process_head, node) {
	// 	if (process->pid == pid) {
	// 		list_del(&process->node);
	// 		kfree(process);
	// 		break;
	// 	}
	// }
	// mutex_unlock(&vacc_dev->process_mutex);

	// vastai_cdev_fasync(-1, filp, 0);

	// pr_debug("test module cdev release, pid %d\n", task_tgid_nr(current));
	return 0;
}

static const struct file_operations fop = {
	.owner = THIS_MODULE,
	.llseek = vaccrt_cdev_llseek,
	.read = vaccrt_cdev_read,
	.write = vaccrt_cdev_write,
	.poll = vaccrt_cdev_poll,
	.unlocked_ioctl = vaccrt_cdev_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = vaccrt_cdev_ioctl,
#endif
	.mmap = vaccrt_cdev_mmap,
	.open = vaccrt_cdev_open,
	.release = vaccrt_cdev_release,
	.fasync = vaccrt_cdev_fasync,
};

typedef struct _csr_config_t
{
	u64 oak_csr_base;	// SV100 0x700000, SG100 0x50000
	u64 oak_csr_offset; // SV100 0x100000, SG100 (32*KB)
	u64 oak_csr_size;	// SV100 0x100000, SG100 (32*KB)

	u64 oak_wdbuf_base;			   // SV100 0x40800000, SG100 0xC400000
	u64 oak_wdbuf_offset;		   // SV100 0x800000, SG100 4*MB
	u64 oak_wdbuf_size_bigcore;	   // SG100 4*MB, SG100 2*MB
	u64 oak_wdbuf_size_smallcore;  // SG100 2*MB, SG100 0*MB
	int oak_wdbuf_smallcore_begin; // -1 all is bigcore
	int _reserved;

	u64 ssram_base;	  // SV100 0x50000000, SG100 0xC000000
	u64 ssram_offset; // SV100 0x1000000, SG100 2MB
	u64 ssram_size;	  // SV100 5*MB, SG100 2MB

	u64 odma_csr_base;	 // SV100 0xF00000, SG100 0x48000
	u64 odma_csr_offset; // SV100 0x100000, SG100 16*KB
	u64 odma_csr_size;	 // SV100 1*MB, SG100 16*KB
} csr_config_t;

#if CONFIG_VASTAI_SOC_HW_TYPE==1
static csr_config_t csr_config_sv100 = {
	.oak_csr_base = 0x700000,
	.oak_csr_offset = 1 * MB,
	.oak_csr_size = 1 * MB,
	.oak_wdbuf_base = 0x40800000,
	.oak_wdbuf_offset = 8 * MB,
	.oak_wdbuf_size_bigcore = 4 * MB,
	.oak_wdbuf_size_smallcore = 2 * MB,
	.oak_wdbuf_smallcore_begin = 4,
	.ssram_base = 0x50000000,
	.ssram_offset = 16 * MB,
	.ssram_size = 5 * MB,
	.odma_csr_base = 0xF00000,
	.odma_csr_offset = 1 * MB,
	.odma_csr_size = 1 * MB,
};

static struct vastai_soc vastai_soc_sv100 = {
	.type = VASTAI_SV100,
	.enabled_core_num = 2,
	.harvest_core_flag = 0x03,
	.vacc_id = 0,
	.bar_num = 2,
	.zone_num = zone_count,
	.vdsp_num = 4,
	.core_num = 8,
	.ssram_num = 8,
	.odma_num = 2,
	.odma_snum = 8,
	.odma_bnum = 16,
	.ctrans_bnum = 16,
	.wdma_bud = WDMA_BOUND,
	.odma_bud = ODMA_BOUND,
	.throttle_max_bound = 90,
	.capacity_ratio = 115,
	.capacity_base = 100,
	.alig_ssram = 128,
	.alig_wdbuf_conv = 128,
	.alig_wdbuf_fc_gemm = 256,
	.wdbuf_broadcast_base = 0x40000000,
	.ddr_total_size = 0,
	.ddr_2_bit_ecc_start = 0x815200000,
};
#endif

#if CONFIG_VASTAI_SOC_HW_TYPE==2
static csr_config_t csr_config_sg100 = {
	.oak_csr_base = 0x50000,
	.oak_csr_offset = 32 * KB,
	.oak_csr_size = 32 * KB,
	.oak_wdbuf_base = 0xC400000,
	.oak_wdbuf_offset = 4 * MB,
	.oak_wdbuf_size_bigcore = 2 * MB,
	.oak_wdbuf_size_smallcore = 0 * MB,
	.oak_wdbuf_smallcore_begin = -1,
	.ssram_base = 0xC000000,
	.ssram_offset = 2 * MB,
	.ssram_size = 2 * MB,
	.odma_csr_base = 0x48000,
	.odma_csr_offset = 16 * KB,
	.odma_csr_size = 16 * KB,
};

static struct vastai_soc vastai_soc_sg100 = {
	.type = VASTAI_SG100,
	.enabled_core_num = 2,
	.harvest_core_flag = 0x03,
	.vacc_id = 0,
	.bar_num = 2,
	.zone_num = zone_count,
	.vdsp_num = 0,
	.core_num = 2,
	.ssram_num = 2,
	.odma_num = 1,
	.odma_snum = 8,
	.odma_bnum = 16,
	.ctrans_bnum = 16,
	.wdma_bud = WDMA_BOUND,
	.odma_bud = ODMA_BOUND,
	.throttle_max_bound = 90,
	.capacity_ratio = 115,
	.capacity_base = 100,
	.alig_ssram = 128,
	.alig_wdbuf_conv = 128,
	.alig_wdbuf_fc_gemm = 256,
	.wdbuf_broadcast_base = 0xCC00000,
	.ddr_total_size = 0,
	.ddr_2_bit_ecc_start = 0,
};
#endif

#if CONFIG_VASTAI_SOC_HW_TYPE==1
static int vacc_dev_zone_init(struct vastai_cdev *vacc_dev)
{
	int i = 0;
	uint64_t entry_addr = 0, base = 0, size = 0;
	struct vastai_zone *zone = NULL;
	struct vastai_soc *soc = (struct vastai_soc *)&(vacc_dev->soc);
	zone = (struct vastai_zone *)kzalloc(
		sizeof(struct vastai_zone) * soc->zone_num, GFP_KERNEL);
	if (!zone)
		return -1;
	vacc_dev->zone = zone;
	zone->id = zone_stream;
	zone->zone_type = zone_stream;
	zone->alig_ddr_start = ALIG_CSRAM_START;
	zone->entry = STREAM_ENTRY;
	zone->bank_num = 1;
	zone->bank[0].base = STREAM_BASE;
	zone->bank[0].size = STREAM_SIZE;
	zone++;
	zone->id = zone_model;
	zone->zone_type = zone_model;
	zone->alig_ddr_start = ALIG_DDR_START;
	zone->bank_num = vastai_get_model_mem_num(vacc_dev->pci_info);
	vastai_get_model_entry_addr(vacc_dev->pci_info, 0, &entry_addr);
	zone->entry = entry_addr;
	for (i = 0; i < zone->bank_num; i++) {
		vastai_get_model_mem_info(vacc_dev->pci_info, i,
					  &zone->bank[i].base,
					  &zone->bank[i].size);
	}
	zone++;
	zone->id = zone_vdsp_operator;
	zone->zone_type = zone_vdsp_operator;
	zone->alig_ddr_start = ALIG_OPERATOR_START;
	zone->entry = OPERATOR_VDSP_ENTRY;
	zone->bank_num = 1;
	zone->bank[0].base = OPERATOR_VDSP_BASE;
	zone->bank[0].size = OPERATOR_VDSP_SIZE;
	zone++;
	zone->id = zone_share;
	zone->zone_type = zone_share;
	zone->alig_ddr_start = ALIG_DDR_START;
	zone->entry = 0;
	zone->bank_num = vastai_get_share_mem_bank_num(vacc_dev->pci_info);
	for (i = 0; i < zone->bank_num; i++) {
		vastai_get_share_mem_bank_info(vacc_dev->pci_info, i,
					  &zone->bank[i].base,
					  &zone->bank[i].size);
	}
	zone++;
	zone->id = zone_odsp_operator;
	zone->zone_type = zone_odsp_operator;
	zone->alig_ddr_start = ALIG_OPERATOR_START;
	zone->entry = OPERATOR_ODSP_ENTRY;
	zone->bank_num = 1;
	base = 0; size = 0;
	if (vastai_get_odsp_op_info(vacc_dev->pci_info, 0, &base, &size)) {
		VASTAI_PCI_ERR(
			vacc_dev->pci_info, vacc_dev->die_id,
			"[vaerr] %s: ODSP0 vastai_get_odsp_op_info failed.\n", __func__);
		return -1;
	}
	zone->bank[0].base = base;
	zone->bank[0].size = size;
	zone++;
	zone->id = zone_cmcu_operator;
	zone->zone_type = zone_cmcu_operator;
	zone->alig_ddr_start = ALIG_OPERATOR_START;
	zone->entry = OPERATOR_CMCU_ENTRY;
	zone->bank_num = 1;
	zone->bank[0].base = OPERATOR_CMCU_BASE;
	zone->bank[0].size = OPERATOR_CMCU_SIZE;
	return 0;
}

static void get_dsp_count(struct vastai_sv100_die *die, int *vdsp_num, int *odsp_num)
{
	int i = 0;
	int vdsp_count = 0, odsp_count = 0;
	*vdsp_num = 0;
	*odsp_num = 0;

	for (i = CORE_POINT_VDSP0; i <= CORE_POINT_VDSP3; i++) {
		if (die->core[i].cores_info_ref->core_type == VDSP_TYPE) {
			vdsp_count++;
		} else if (die->core[i].cores_info_ref->core_type == ODSP_TYPE) {
			odsp_count++;
		}
	}

	for (i = CORE_POINT_ODSP0; i <= CORE_POINT_ODSP7; i++) {
		if (die->core[i].cores_info_ref->core_type == VDSP_TYPE) {
			vdsp_count++;
		} else if (die->core[i].cores_info_ref->core_type == ODSP_TYPE) {
			odsp_count++;
		}
	}

	*vdsp_num = vdsp_count;
	*odsp_num = odsp_count;
}

static void vdsp_init(struct vastai_cdev *vacc_dev, struct vastai_sv100_die *die, struct vastai_vdsp *vdsp)
{
	int i = 0;
	int j = 0;
	int id = 0;
	for (i = CORE_POINT_VDSP0; i <= CORE_POINT_VDSP3; i++) {
		if (die->core[i].cores_info_ref->core_type == VDSP_TYPE) {
			vdsp->id = id;
			vdsp->size = OPERATOR_VDSP_SIZE;
			vdsp->base =
				OPERATOR_VDSP_BASE + j * OPERATOR_VDSP_OFFSET;
			j++;
			id++;
			vdsp++;
		}
	}

	j = 0;
	for (i = CORE_POINT_ODSP0; i <= CORE_POINT_ODSP7; i++) {
		if (die->core[i].cores_info_ref->core_type == VDSP_TYPE) {
			vdsp->id = id;
			vdsp->size = OPERATOR_VDSP_SIZE;
			vdsp->base = OPERATOR_ODSP_BASE +
				     j * OPERATOR_ODSP_OFFSET +
				     (OPERATOR_ODSP_SIZE - OPERATOR_VDSP_SIZE);
			j++;
			id++;
			vdsp++;
		}
	}
}

static void odsp_init(struct vastai_cdev *vacc_dev, struct vastai_sv100_die *die, struct vastai_odsp *odsp)
{
	int i = 0;
	int j = 0;
	int id = 0;
	uint64_t base = 0, size = 0;
	struct vastai_pci_info *priv = vacc_dev->pci_info;
	// no consider vdsp as odsp case
	// for (i = CORE_POINT_VDSP0; i <= CORE_POINT_VDSP3; i++) {
	// 	if (die->core[i].event_type == ODSP_TYPE) {
	// 		vdsp->id = id;
	// 		vdsp->size = OPERATOR_VDSP_SIZE;
	// 		vdsp->base =
	// 			OPERATOR_VDSP_BASE + j * OPERATOR_VDSP_OFFSET;
	// 		j++;
	// 		id++;
	// 		odsp++;
	// 	}
	// }

	j = 0;
	for (i = CORE_POINT_ODSP0; i <= CORE_POINT_ODSP7; i++) {
		if (die->core[i].cores_info_ref->core_type == VDSP_TYPE) {
			base = 0; size = 0;
			if (vastai_get_odsp_op_info(priv, id, &base, &size)) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] %s: ODSP[%d] vastai_get_odsp_op_info failed.\n",
					__func__, i-CORE_POINT_ODSP0);
			}
			odsp->id = id;
			if (size < OPERATOR_VDSP_SIZE) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] %s: ODSP[%d] OPERATOR_ODSP_SIZE(0x%llX) < OPERATOR_VDSP_SIZE(0x%X)\n",
					__func__, i-CORE_POINT_ODSP0, size, OPERATOR_VDSP_SIZE);
				odsp->size = 0;
			} else {
				odsp->size = size - OPERATOR_VDSP_SIZE;
				if (odsp->size == 0) {
					VASTAI_PCI_INFO(
						vacc_dev->pci_info, vacc_dev->die_id,
						"[vainfo] %s: ODSP[%d] OPERATOR_ODSP_SIZE(0x%llX) == OPERATOR_VDSP_SIZE(0x%X), odsp_size == 0\n",
						__func__, i-CORE_POINT_ODSP0, size, OPERATOR_VDSP_SIZE);
				}
			}
			odsp->base = base;
			j++;
			id++;
			odsp++;
		} else if (die->core[i].cores_info_ref->core_type == ODSP_TYPE) {
			base = 0; size = 0;
			if (vastai_get_odsp_op_info(priv, id, &base, &size)) {
				VASTAI_PCI_ERR(
					vacc_dev->pci_info, vacc_dev->die_id,
					"[vaerr] %s: ODSP[%d] vastai_get_odsp_op_info failed.\n",
					__func__, i-CORE_POINT_ODSP0);
			}
			odsp->id = id;
			odsp->size = size;
			odsp->base = base;
			j++;
			id++;
			odsp++;
		} else {
			VASTAI_PCI_ERR(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] %s: ODSP[%d] config type %d not supported\n",
				__func__, i-CORE_POINT_ODSP0, die->core[i].cores_info_ref->core_type);
		}
	}
}

#elif CONFIG_VASTAI_SOC_HW_TYPE==2
static int vacc_dev_zone_init(struct vastai_cdev *vacc_dev, struct ai_info *aiinfo)
{
	struct vastai_zone *zone = NULL;
	int index = 0;
	struct vastai_soc *soc = (struct vastai_soc *)&(vacc_dev->soc);
	zone = (struct vastai_zone *)kzalloc(
		sizeof(struct vastai_zone) * soc->zone_num, GFP_KERNEL);
	if (!zone)
		return -1;
	vacc_dev->zone = zone;
	zone->id = zone_stream;
	zone->zone_type = zone_stream;
	zone->alig_ddr_start = ALIG_CSRAM_START;
	zone->entry = aiinfo->ai_csram_buf_base;
	zone->bank_num = 1;
	zone->bank[0].base = aiinfo->ai_csram_buf_base;
	zone->bank[0].size = aiinfo->ai_csram_buf_size;
	zone++;
	zone->id = zone_model;
	zone->zone_type = zone_model;
	zone->alig_ddr_start = ALIG_DDR_START;
	zone->entry = aiinfo->ai_cfg.mcu_addr;
	zone->bank_num = 1;
	zone->bank[0].base = aiinfo->ai_mod_buf_fn_addr;
	zone->bank[0].size = aiinfo->ai_mod_buf_size;
	zone++;
	zone->id = zone_vdsp_operator;
	zone->zone_type = zone_vdsp_operator;
	zone->alig_ddr_start = ALIG_OPERATOR_START;
	index = aiinfo->dsp_cfg.valid_1st_vdsp_entry;
	zone->entry = aiinfo->dsp_cfg.dsp_entry[index].dsp_addr;
	zone->bank_num = 1;
	zone->bank[0].base = aiinfo->dsp_cfg.dsp_entry[index].hi32_soc_addr;
	zone->bank[0].base = zone->bank[0].base << 32;
	zone->bank[0].base = zone->bank[0].base + aiinfo->dsp_cfg.dsp_entry[index].lo32_soc_addr;
	zone->bank[0].size = aiinfo->dsp_cfg.dsp_entry[index].size * 1024 * 1024;
	zone++;
	zone->id = zone_share;
	zone->zone_type = zone_share;
	zone->alig_ddr_start = ALIG_DDR_START;
	zone->entry = 0;
	zone->bank_num = 1;
	zone->bank[0].base = aiinfo->ai_dyn_buf_fn_addr;
	zone->bank[0].size = aiinfo->ai_dyn_buf_size;
	zone++;
	zone->id = zone_odsp_operator;
	zone->zone_type = zone_odsp_operator;
	zone->alig_ddr_start = ALIG_OPERATOR_START;
	index = aiinfo->dsp_cfg.valid_1st_odsp_entry;
	zone->entry = aiinfo->dsp_cfg.dsp_entry[index].dsp_addr;
	zone->bank_num = 1;
	zone->bank[0].base = aiinfo->dsp_cfg.dsp_entry[index].hi32_soc_addr;
	zone->bank[0].base = zone->bank[0].base << 32;
	zone->bank[0].base = zone->bank[0].base + aiinfo->dsp_cfg.dsp_entry[index].lo32_soc_addr;
	zone->bank[0].size = aiinfo->dsp_cfg.dsp_entry[index].size * 1024 * 1024;
	return 0;
}
#else
#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
#endif

static int vacc_dev_init(struct vastai_cdev *cdev)
{
	u32 i = 0;
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	u32 die_id = 0;
	u8 type = 0;
	u64 video_phys_addr_origin = 0;
	struct vastai_die_info *die_info = NULL;
	struct vastai_pkg_info *pkg_info = NULL;
	struct vastai_card_info *card_info = NULL;
	int vdsp_num = 0;
	int odsp_num = 0;
	#endif
	// u64 size_video = VIDEO_SIZE; // real video size
	// u64 size_max = 0; // size of video + share
	struct vastai_cdev *vacc_dev = cdev;
	struct vastai_soc *soc = (struct vastai_soc *)&(cdev->soc);
	// struct vastai_zone *zone = NULL;
	struct vastai_dlc *dlc = NULL;
	struct vastai_ssram *ssram = NULL;
	struct vastai_bar *bars = NULL;
	struct vastai_pci_info *priv = NULL;
	struct vastai_odma *odmas = NULL;
	struct vastai_vdsp *vdsp = NULL;
	struct vastai_odsp *odsp = NULL;
	struct vastai_cmcu *cmcu = NULL;
	#if CONFIG_VASTAI_SOC_HW_TYPE==2
	struct ai_info *aiinfo = NULL;
	int dsp_entry = 0;
	#endif

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	const csr_config_t *csr_config = &csr_config_sv100;
	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	const csr_config_t *csr_config = &csr_config_sg100;
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif

	priv = vacc_dev->pci_info;
	if (!priv)
		goto out;

	#if CONFIG_VASTAI_SOC_HW_TYPE==2
	aiinfo = priv->vastai_ai_info;
	if (NULL == aiinfo) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: ai info NOT initialized\n",
			       __func__);
		return -EINVAL;
	}

	if (0 == aiinfo->ai_dyn_buf_size) {
		aiinfo->ai_dyn_buf_size = SHARE_BUFFER_SIZE;
	}
	#endif

	vacc_dev->ai_version = AI_DRIVER_VERSION;
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	memcpy(soc, &vastai_soc_sv100, sizeof(struct vastai_soc));
	die_id = vastai_pci_get_die_id(priv, cdev->die_index);
	soc->harvest_core_flag = vastai_get_dlc_cores_info(priv, cdev->die_index);
	// harvest core info should be used after vastai_get_dlc_cores_info
	type = priv->dies[die_id].harvest_info.type;
	if (VASTAI_HARVEST_ALL_DLC_ENABLE == type) {
		soc->type = VASTAI_SV100;
		soc->enabled_core_num = 8;
	} else if (VASTAI_HARVEST_TYPE1 == type || VASTAI_HARVEST_TYPE2 == type) {
		soc->type = VASTAI_SV100_HV;
		soc->enabled_core_num = 4;
	} else {
		soc->type = VASTAI_DEV_COUNT; //invalid device type
		soc->enabled_core_num = 0;
	}
	soc->vacc_id = vastai_get_vacc_id(cdev->pci_info, cdev->die_index);
	soc->ddr_total_size = vastai_pci_info_get_ddr_attr(vacc_dev->pci_info);
	// init zone and bank
	if (vacc_dev_zone_init(vacc_dev) != 0) {
		goto out;
	}

	get_dsp_count(&priv->dies[die_id], &vdsp_num, &odsp_num);
	soc->vdsp_num = vdsp_num; // vdsp_num in soc

	// init vdsp
	vdsp = (struct vastai_vdsp *)kzalloc(
		sizeof(struct vastai_vdsp) * soc->vdsp_num, GFP_KERNEL);
	if (!vdsp)
		goto out;
	vacc_dev->vdsp = vdsp;
	vdsp_init(vacc_dev, &priv->dies[die_id], vdsp);

	// init odsp
	odsp = (struct vastai_odsp *)kzalloc(
		sizeof(struct vastai_odsp) * soc->core_num, GFP_KERNEL);
	if (!odsp)
		goto out;
	vacc_dev->odsp = odsp;
	odsp_init(vacc_dev, &priv->dies[die_id], odsp);

	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	memcpy(soc, &vastai_soc_sg100, sizeof(struct vastai_soc));
	soc->vdsp_num = aiinfo->dsp_cfg.valid_vdsp_entry_n;
	soc->ddr_total_size = aiinfo->fn_ddr_total_sz;
	if (vacc_dev_zone_init(vacc_dev, aiinfo) != 0) {
		goto out;
	}
	// init vdsp
	vdsp = (struct vastai_vdsp *)kzalloc(
		sizeof(struct vastai_vdsp) * soc->vdsp_num, GFP_KERNEL);
	if (!vdsp)
		goto out;
	vacc_dev->vdsp = vdsp;
	dsp_entry = aiinfo->dsp_cfg.valid_1st_vdsp_entry;
	for (i = 0; i < soc->vdsp_num; i++) {
		vdsp->id = i;
		vdsp->size = aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].size * 1024 * 1024;
		vdsp->base =
			(u64)((u64)aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].hi32_soc_addr
			      << 32) |
			aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].lo32_soc_addr;
		vdsp++;
	}

	// init odsp
	odsp = (struct vastai_odsp *)kzalloc(
		sizeof(struct vastai_odsp) * soc->core_num, GFP_KERNEL);
	if (!odsp)
		goto out;
	vacc_dev->odsp = odsp;
	dsp_entry = aiinfo->dsp_cfg.valid_1st_odsp_entry;
	for (i = 0; i < soc->core_num; i++) {
		if (i >= aiinfo->dsp_cfg.valid_odsp_entry_n) {
			VASTAI_PCI_INFO(
				vacc_dev->pci_info, vacc_dev->die_id,
				"[vaerr] %s: core_num(%d) mismatch with odsp_num(%d)",
				__func__, soc->core_num, aiinfo->dsp_cfg.valid_odsp_entry_n);
			break;
		}
		odsp->id = i;
		odsp->size = aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].size * 1024 * 1024;
		odsp->base =
			(u64)((u64)aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].hi32_soc_addr
			      << 32) |
			aiinfo->dsp_cfg.dsp_entry[i + dsp_entry].lo32_soc_addr;
		odsp++;
	}
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif

	// init cmcu
	cmcu = (struct vastai_cmcu *)kzalloc(sizeof(struct vastai_cmcu) * 1, GFP_KERNEL);
	if (!cmcu)
		goto out;
	vacc_dev->cmcu = cmcu;
	for (i = 0; i < 1; i++) {
		cmcu->id = i;
		cmcu->size = OPERATOR_ODSP_SIZE;
		cmcu->base = OPERATOR_CMCU_BASE;
		cmcu++;
	}

	// init dlc
	dlc = (struct vastai_dlc *)kzalloc(
		sizeof(struct vastai_dlc) * soc->core_num, GFP_KERNEL);
	if (!dlc)
		goto out;
	vacc_dev->dlc = dlc;
	for (i = 0; i < soc->core_num; i++) {
		dlc->id = i;
		dlc->wdma_fw_entry = 0x400;
		dlc->csr_base = csr_config->oak_csr_base + csr_config->oak_csr_offset * i;
		dlc->csr_size = csr_config->oak_csr_size;
		dlc->wdbuf.bank_size = 128 * KB;
		dlc->wdbuf.base = csr_config->oak_wdbuf_base + csr_config->oak_wdbuf_offset * i;
		if ((csr_config->oak_wdbuf_smallcore_begin != -1) && (i >= csr_config->oak_wdbuf_smallcore_begin)) {
			dlc->core_flag = 0; // small core
			dlc->wdbuf.bank_num = 16;
			dlc->wdbuf.size = csr_config->oak_wdbuf_size_smallcore;
		} else {
			#if CONFIG_VASTAI_SOC_HW_TYPE==2
			dlc->core_flag = 0;	// SG100 bad case
			#else
			dlc->core_flag = 1; // big core
			#endif
			dlc->wdbuf.bank_num = 32;
			dlc->wdbuf.size = csr_config->oak_wdbuf_size_bigcore;
		}
		dlc++;
	}

	// init ssram
	ssram = (struct vastai_ssram *)kzalloc(
		sizeof(struct vastai_ssram) * soc->ssram_num, GFP_KERNEL);
	if (!ssram)
		goto out;
	vacc_dev->ssram = ssram;
	for (i = 0; i < soc->ssram_num; i++) {
		ssram->id = i;
		ssram->base = csr_config->ssram_base + csr_config->ssram_offset * i;
		ssram->size = csr_config->ssram_size;
		ssram++;
	}

	// init bars
	bars = (struct vastai_bar *)kzalloc(
		sizeof(struct vastai_bar) * soc->bar_num, GFP_KERNEL);
	if (!bars)
		goto out;
	vacc_dev->bars = bars;
	// classified by die id
	bars[0].id = 0;
	bars[1].id = 1;

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	switch (vacc_dev->die_id) {
	case 0:
		// bars[0].ddr_base =
		// 	(u64)(VASTAI_PCIE_BAR0_BASE0_IN & 0xFFFFFFFFF);
		// bars[0].size = (u64)(priv->bar[0].mmio_len);
		// bars[0].base = (u64)(priv->bar[0].mmio_start);
		if (priv->bar[VASTAI_PCI_BAR2].minish_bar_size) {
			bars[1].ddr_base =
				(u64)(VASTAI_PCIE_BAR2_BASE0_IN & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[2].mmio_len);
			bars[1].base = (u64)(priv->bar[2].mmio_start);
		} else {
			// bars[0].ddr_base =
			// 	(u64)(priv->bar[0].at_addr & 0xFFFFFFFFF);
			// bars[0].size = (u64)(priv->bar[0].mmio_len);
			// bars[0].base = (u64)(priv->bar[0].mmio_start);
			bars[1].ddr_base =
				(u64)(priv->bar[2].at_addr & 0xFFFFFFFFF);
			// bars[1].size = (u64)(priv->bar[2].mmio_len);
			bars[1].size = (u64)(VD_MMAP_SIZE);
			bars[1].base = (u64)(priv->bar[2].mmio_start);
		}
		break;
	case 1:
		// bars[0].ddr_base =
		// 	(u64)(VASTAI_PCIE_BAR1_BASE0_IN & 0xFFFFFFFFF);
		// bars[0].size = (u64)(priv->bar[1].mmio_len / 4);
		// bars[0].base = (u64)(priv->bar[1].mmio_start +
		// 			 (vacc_dev->die_id - 1) * bars[0].size);
		if (priv->bar[VASTAI_PCI_BAR4].minish_bar_size) {
			bars[1].ddr_base =
				(u64)(VASTAI_PCIE_BAR4_BASE0_IN & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		} else {
			// bars[0].ddr_base =
			// 	(u64)(priv->bar[1].at_addr & 0xFFFFFFFFF);
			// bars[0].size = (u64)(priv->bar[1].mmio_len);
			// bars[0].base = (u64)(priv->bar[1].mmio_start;
			/*
			bars[1].ddr_base =
				(u64)(priv->bar[4].at_addr & 0xFFFFFFFFF);
			// bars[1].size = (u64)(priv->bar[4].mmio_len);
			bars[1].size = (u64)(VD_MMAP_SIZE);
			bars[1].base = (u64)(priv->bar[4].mmio_start);
			*/

			/* for 32G/128G  BAR4 */
			bars[1].ddr_base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].at_addr & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[VASTAI_PCI_BAR4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		}
		break;
	case 2:
		// bars[0].ddr_base =
		// 	(u64)(VASTAI_PCIE_BAR1_BASE1_IN & 0xFFFFFFFFF);
		// bars[0].size = (u64)(priv->bar[1].mmio_len / 4);
		// bars[0].base = (u64)(priv->bar[1].mmio_start +
		// 			 (vacc_dev->die_id - 1) * bars[0].size);
		if (priv->bar[VASTAI_PCI_BAR4].minish_bar_size) {
			bars[1].ddr_base =
				(u64)(VASTAI_PCIE_BAR4_BASE1_IN & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		} else {
			/* for 32G/128G  BAR4 */
			bars[1].ddr_base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].at_addr & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[VASTAI_PCI_BAR4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		}
		break;
	case 3:
		// bars[0].ddr_base =
		// 	(u64)(VASTAI_PCIE_BAR1_BASE2_IN & 0xFFFFFFFFF);
		// bars[0].size = (u64)(priv->bar[1].mmio_len / 4);
		// bars[0].base = (u64)(priv->bar[1].mmio_start +
		// 			 (vacc_dev->die_id - 1) * bars[0].size);
		if (priv->bar[VASTAI_PCI_BAR4].minish_bar_size) {
			bars[1].ddr_base =
				(u64)(VASTAI_PCIE_BAR4_BASE2_IN & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		} else {
			/* for 32G/128G  BAR4 */
			bars[1].ddr_base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].at_addr & 0xFFFFFFFFF);
			bars[1].size = (u64)(priv->bar[VASTAI_PCI_BAR4].mmio_len / 4);
			bars[1].base =
				(u64)(priv->bar[VASTAI_PCI_BAR4].mmio_start +
				      (vacc_dev->die_id - 1) * bars[1].size);
		}
		break;
	default:
		// return -EINVAL;
		break;
	}

	if (VD_MMAP_BASE < vacc_dev->bars[1].ddr_base ||
	    VD_MMAP_SIZE > vacc_dev->bars[1].size)
		goto out;

	vastai_ddr_to_bar(vacc_dev->pci_info, vacc_dev->die_index,
			  vacc_dev->zone[zone_stream].bank[0].base,
			  &soc->csram_phys_addr);
	soc->csram_size = vacc_dev->zone[zone_stream].bank[0].size;

	// printk("%s: vacc%d csram_phys_addr = 0x%llX, csram_soc_base=0x%llx, map_csram_size=0x%llx\n",
	//        __func__, soc->vacc_id, soc->csram_phys_addr,
	//        vacc_dev->zone[zone_stream].bank[0].base, soc->csram_size);

	vastai_ddr_to_bar(vacc_dev->pci_info, vacc_dev->die_index,
			  vacc_dev->zone[zone_share].bank[0].base,
			  &soc->share_phys_addr);
	soc->share_size = vacc_dev->zone[zone_share].bank[0].size;

	// printk("%s: vacc%d share_phys_addr = 0x%llX, share_soc_base=0x%llx, map_ddr_size=0x%llx\n",
	//        __func__, soc->vacc_id, soc->share_phys_addr,
	//        vacc_dev->zone[zone_share].bank[0].size, soc->share_size);

	video_phys_addr_origin = vacc_dev->bars[1].base + VD_MMAP_BASE -
				 vacc_dev->bars[1].ddr_base;
	soc->video_phys_addr = video_phys_addr_origin % VIDEO_MMAP_SIZE_MAX;
	soc->video_size = VD_MMAP_SIZE;
	soc->video_soc_addr = VD_MMAP_BASE;
	soc->die_id = die_id;
	card_info = vastai_get_card_info(priv);
	soc->card_id = card_info->card_id;
	soc->bdf_info = vastai_get_pci_bdf_info(priv);
	die_info = vastai_get_die_info(priv, die_id);
	if (die_info == NULL) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: vastai_get_die_info failed", __func__);
	} else {
		soc->die_id_in_card = die_info->die_id_in_card;
	}
	pkg_info = vastai_get_pkg_info(priv, die_id);
	if (pkg_info == NULL) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "[vaerr] %s: vastai_get_pkg_info failed", __func__);
	} else {
		soc->pkg_id = pkg_info->pkg_id;
	}
	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	soc->video_phys_addr =
		aiinfo->decoder_buf_host_phy_addr % VIDEO_MMAP_SIZE_MAX;
	soc->video_size = aiinfo->decoder_buf_size;
	soc->video_soc_addr = aiinfo->decoder_buf_fn_addr;
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif

	// init odmas
	odmas = (struct vastai_odma *)kzalloc(
		sizeof(struct vastai_odma) * soc->odma_num, GFP_KERNEL);
	if (!odmas)
		goto out;
	vacc_dev->odmas = odmas;
	for (i = 0; i < soc->odma_num; i++) {
		odmas->id = i;
		odmas->base = csr_config->odma_csr_base + csr_config->odma_csr_offset * i;
		odmas->size = csr_config->odma_csr_size;
		odmas++;
	}

	return 0;

out:
	kfree(vacc_dev->zone);
	kfree(vacc_dev->dlc);
	kfree(vacc_dev->ssram);
	kfree(vacc_dev->bars);
	kfree(vacc_dev->odmas);
	kfree(vacc_dev->vdsp);
	kfree(vacc_dev->odsp);
	kfree(vacc_dev->cmcu);
	return -ENOMEM;
}

int vacc_init(void *pcie_dev, unsigned int die_index)
{
	int ret = 0;
	int i = 0;
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	int vdsp_num = 0;
	int odsp_num = 0;
	#endif
	union die_index_data did = { .val = (u32)die_index };
	struct vastai_cdev *vacc_dev = NULL;
	struct vastai_pci_info *pci_info = NULL;
	size_t mmap_size = 0;
	struct mmap_page *mmap_page = NULL;
	struct mmap_page *mmap_page_temp = NULL;
	if (!pcie_dev) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "[vaerr] %s: pcie_dev is NULL\n", __func__);
		return -EINVAL;
	}

	/* allocate vastai_cdev device data */
	vacc_dev = kzalloc(sizeof(struct vastai_cdev), GFP_KERNEL);
	if (!vacc_dev) {
		VASTAI_PCI_ERR(
			NULL, DUMMY_DIE_ID,
			"[vaerr] %s: failed to kzalloc vastai_cdev device\n",
			__func__);
		return -ENOMEM;
	}

	pci_info = (struct vastai_pci_info *)pcie_dev;
	// vacc_dev->dev_id = pci_info->dev_id;
	#if CONFIG_VASTAI_SOC_HW_TYPE==2
	pci_info->vacc_dev = vacc_dev;
	#endif
	vacc_dev->pci_info = pci_info;
	vacc_dev->die_id = did.die_id;
	vacc_dev->dev_id = did.dev_id;
	vacc_dev->die_index = die_index;

	INIT_LIST_HEAD(&vacc_dev->mmap.head);

	ret = vaccrt_pci_transfer_init(vacc_dev);
	if (ret)
		goto out_free_dev;

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	ret = vastai_file_create(&vacc_dev->file_info, pcie_dev, &fop, "vacc%u",
				 did.seq_num);
	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	ret = vastai_file_create(&vacc_dev->file_info, pcie_dev, &fop, "vacc%u",
				 pci_info->dev_id);
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif
	if (ret) {
		goto out_free_dev;
	}

	// mutex_init(&vacc_dev->process_mutex);
	// INIT_LIST_HEAD(&vacc_dev->process_head);

	init_waitqueue_head(&vacc_dev->wait_runsteam);

	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	vastai_reset_handle_reg(vaccrt_ai_reset_handler);
	get_dsp_count(&pci_info->dies[vastai_pci_get_die_id(
			      pci_info, vacc_dev->die_index)],
		      &vdsp_num, &odsp_num);
	vacc_dev->soc.vdsp_num = vdsp_num; // vdsp_num in soc
	#endif
	ret = vaccrt_ai_callback_reg(pcie_dev, vacc_dev);
	if (ret)
		goto out_unreg_class;

	ret = vacc_dev_init(vacc_dev);
	if (ret)
		goto out_unreg_class;

	init_waitqueue_head(&vacc_dev->mmap.wait);
	mutex_init(&vacc_dev->mmap.mutex);
	mmap_size =
		ALIGN(MMAP_SIZE, PAGE_SIZE * ((size_t)1 << (VACCRT_MAX_ORDER - 1)));
	do {
		mmap_page = kzalloc(sizeof(struct mmap_page), GFP_KERNEL);
		if (!mmap_page)
			goto out_unreg_class;
		mmap_page->page =
			alloc_pages(GFP_KERNEL | __GFP_ZERO, (VACCRT_MAX_ORDER - 1));
		if (!mmap_page->page) {
			kfree(mmap_page);
			goto out_unreg_class;
		}
		list_add_tail(&mmap_page->node, &vacc_dev->mmap.head);
		mmap_size -= PAGE_SIZE * ((size_t)1 << (VACCRT_MAX_ORDER - 1));
	} while (mmap_size);
	mmap_page =
		list_first_entry(&vacc_dev->mmap.head, struct mmap_page, node);
	vacc_dev->mmap.addr = (u64)page_to_phys(mmap_page->page);
	vacc_dev->mmap.size =
		ALIGN(MMAP_SIZE, PAGE_SIZE * ((size_t)1 << (VACCRT_MAX_ORDER - 1)));

	vaccrt_shm_init(vacc_dev);

	for (i = 0; i < operator_count; i++)
		operator_manager_init(&vacc_dev->operator_manager[i],
				      vdsp_operator+i, (void *)vacc_dev);

	mutex_init(&vacc_dev->vdsp_used_counter.mutex);
	vacc_dev->vdsp_used_counter.vdsp_num = vacc_dev->soc.vdsp_num;
	vacc_dev->vdsp_used_counter.used_counts = (uint32_t *)kzalloc(
		sizeof(int) * vacc_dev->soc.vdsp_num, GFP_KERNEL);
	if (unlikely(!vacc_dev->vdsp_used_counter.used_counts)) {
		VASTAI_PCI_ERR(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: failed to kzalloc used_counts\n", __func__);
		goto out_free_dev;
	}

	// add to list
	INIT_LIST_HEAD(&vacc_dev->vacc_dev_node);
	list_add_tail(&vacc_dev->vacc_dev_node, &pci_info->vacc_dev_head);

	// pr_debug("test module install information:\n");
	// pr_debug("test module install VACC_RUN_MODEL:0x%x\n", VACC_RUN_MODEL);
	// pr_debug("test module install VACC_RUN_STREAM:0x%x\n", VACC_RUN_STREAM);
	// pr_debug("test module install VACC_LOAD_MODEL:0x%x\n", VACC_LOAD_MODEL);
	// pr_debug("test module install VACC_DESTROY_MODEL:0x%x\n", VACC_DESTROY_MODEL);
	// pr_debug("test module install VACC_LOAD_OPERATOR:0x%x\n", VACC_LOAD_OPERATOR);
	// pr_debug("test module install VACC_GET_CURRENT_PID:0x%x\n", VACC_GET_CURRENT_PID);
	// pr_debug("test module install VACC_GET_PROCESS:0x%x\n", VACC_GET_PROCESS);
	// pr_debug("test module install VACC_RELEASE_PROCESS:0x%x\n", VACC_RELEASE_PROCESS);
	// pr_debug("test module install VACC_GET_OUT_DESC:0x%x\n", VACC_GET_OUT_DESC);
	// pr_debug("test module install VACC_CP_DIE2DIE:0x%x\n", VACC_CP_DIE2DIE);
	// pr_debug("test module install VACC_ECC2BIT:0x%x\n", VACC_ECC2BIT);
	// pr_debug("test module install VACC_RD_VERSION:0x%x\n", VACC_RD_VERSION);
	// pr_debug("test module install VACC_RD_FW_STATUS:0x%x\n", VACC_RD_FW_STATUS);
	// pr_debug("test module install VACC_RD_SOC:0x%x\n", VACC_RD_SOC);
	// pr_debug("test module install VACC_RD_ZONE:0x%x\n", VACC_RD_ZONE);
	// pr_debug("test module install VACC_RD_VDSP:0x%x\n", VACC_RD_VDSP);
	// pr_debug("test module install VACC_RD_DLC:0x%x\n", VACC_RD_DLC);
	// pr_debug("test module install VACC_RD_SSRAM:0x%x\n", VACC_RD_SSRAM);
	// pr_debug("test module install VACC_RD_ODAM:0x%x\n", VACC_RD_ODAM);
	// pr_debug("test module install VACC_RD_BAR:0x%x\n", VACC_RD_BAR);
	// pr_debug("test module install VACC_DDR_OVERFLOW:0x%x\n", VACC_DDR_OVERFLOW);
	// pr_debug("test module install VACC_MMAP_INIT:0x%x\n", VACC_MMAP_INIT);
	#if CONFIG_VASTAI_SOC_HW_TYPE==1
	VASTAI_PCI_INFO(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: Ai Driver module [vacc%d] init success!\n", __func__, did.seq_num);
	#elif CONFIG_VASTAI_SOC_HW_TYPE==2
	VASTAI_PCI_INFO(vacc_dev->pci_info, vacc_dev->die_id,
			       "%s: Ai Driver module [vacc%d] init success!\n", __func__, pci_info->dev_id);
	#else
	#error UNKNOW CONFIG_VASTAI_SOC_HW_TYPE
	#endif
	return 0; // success

out_unreg_class:
	vastai_file_destroy(&vacc_dev->file_info);
out_free_dev:
	if (vacc_dev->vdsp_used_counter.used_counts) {
		kfree(vacc_dev->vdsp_used_counter.used_counts);
	}
	list_for_each_entry_safe (mmap_page, mmap_page_temp,
				  &vacc_dev->mmap.head, node) {
		list_del(&mmap_page->node);
		__free_pages(mmap_page->page, (VACCRT_MAX_ORDER - 1));
		kfree(mmap_page);
	}
	kfree(vacc_dev);
	VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
		       "[vaerr] %s: Ai Driver module init failed\n", __func__);
	return ret; // error
}

void vacc_exit(void *pcie_dev)
{
	int i = 0;
	struct vastai_cdev *vacc_dev = NULL;
	struct vastai_cdev *vacc_dev_temp = NULL;
	// struct process_node *process = NULL;
	// struct process_node *process_temp = NULL;
	struct mmap_page *mmap_page = NULL;
	struct mmap_page *mmap_page_temp = NULL;

	list_for_each_entry_safe (
		vacc_dev, vacc_dev_temp,
		&((struct vastai_pci_info *)pcie_dev)->vacc_dev_head,
		vacc_dev_node) {
		vaccrt_ai_callback_unreg(pcie_dev, vacc_dev);
		list_del(&vacc_dev->vacc_dev_node);
		vastai_file_destroy(&vacc_dev->file_info);
		// kfree(vacc_dev->soc);
		kfree(vacc_dev->zone);
		kfree(vacc_dev->dlc);
		kfree(vacc_dev->ssram);
		kfree(vacc_dev->bars);
		kfree(vacc_dev->odmas);
		kfree(vacc_dev->vdsp);
		kfree(vacc_dev->odsp);
		kfree(vacc_dev->cmcu);
		// mutex_lock(&vacc_dev->process_mutex);
		// list_for_each_entry_safe (process, process_temp,
		// 			  &vacc_dev->process_head, node) {
		// 	list_del(&process->node);
		// 	kfree(process);
		// }
		// mutex_unlock(&vacc_dev->process_mutex);
		list_for_each_entry_safe (mmap_page, mmap_page_temp,
					  &vacc_dev->mmap.head, node) {
			list_del(&mmap_page->node);
			__free_pages(mmap_page->page, (VACCRT_MAX_ORDER - 1));
			kfree(mmap_page);
		}
		vaccrt_pci_transfer_exit(vacc_dev);

		for (i = 0; i < operator_count; i++) {
			operator_manager_exit(&vacc_dev->operator_manager[i], 1);
		}

		for (i = 0; i < zone_count; i++) {
			vacc_dev->device_ddr_alloc[i].free_shm(
				&vacc_dev->device_ddr_alloc[i]);
		}

		kfree(vacc_dev->vdsp_used_counter.used_counts);
		kfree(vacc_dev);
	}
}

// module_init(vacc_init);
// module_exit(vacc_exit);

// MODULE_AUTHOR("Guoliang Li <guoliang.li@vastaitech.com>");
// MODULE_LICENSE("Dual BSD/GPL");
// MODULE_DESCRIPTION("vacc device driver");
