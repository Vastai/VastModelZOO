#ifndef __VASTAI_OPERATOR_H__
#define __VASTAI_OPERATOR_H__

#include <linux/kernel.h>
#include <linux/wait.h>
#include "vastai_ai.h"
#include "vastai_pci.h"
#include "vastai_pci_api.h"
#include "shmrecord_alloc.h"
#include "vastai_common.h"

#define OP_ID_BYTE_LEN 16

typedef enum {
	op_unload,
	op_loading,
	op_loaded,
} op_load_state_t;

struct ref_process {
	pid_t pid;
	struct list_head node;
};

struct ref_operator_node {
	uint32_t id[4];
	struct list_head node;
};

struct operator_node {
	uint32_t id[4];
	struct list_head node;

	wait_queue_head_t wait; // wait_process
	uint32_t load_state;

    uint64_t addr; // data_addr
	uint64_t size; // data_size
	uint64_t code_addr;
	uint64_t code_size;

	struct mutex mutex_ref_process;
	atomic_t process_ref_num;
	struct list_head ref_process_head;
};

int operator_manager_init(struct operator_manager *operator_manager,
			  operator_type_t operator_type, void *private_data);

void operator_manager_exit(struct operator_manager *operator_manager,
			   int force);

void operator_manager_detach_process(struct operator_manager *operator_manager,
				     pid_t pid);

void operator_print(struct vastai_cdev *vacc_dev);

void on_vdsp_reset_handle(struct vastai_cdev *vacc_dev, uint32_t core_bit);

void on_odsp_reset_handle(struct vastai_cdev *vacc_dev, uint32_t core_bit);

int operator_load(struct vastai_cdev *vacc_dev, struct dev_process *dev_process,
		  void *cmd_buffer, int version);

int operator_manager_register_op(struct vastai_cdev *vacc_dev,
				 struct dev_process *dev_process,
				 void *cmd_buffer, int version);

int operator_manager_unregister_op(
	struct vastai_cdev *vacc_dev, struct dev_process *dev_process,
	operator_unregister_cmd_t *operator_unregister_cmd);

#endif