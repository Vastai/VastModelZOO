/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

*1* Overview
This is the repository of PCIe driver code of Vastaitech.

*2* Subdirectory
The functions of each directory are as follows:
	.
	├── ai_driver
	├── boot
	├── debug
	├── dkms.conf
	├── ep_driver
	├── fw
	├── include
	├── logsys
	├── Makefile
	├── README.md
	├── tool
	└── video_driver
	    ├── common
	    ├── dec_drv
	    └── enc_drv

*3* Format Style
3.1 You can use the following cmd to uniform code format with linux style:
	find -name "*.[ch]" | xargs clang-format-10 -i

3.2 You can use the following cmd to convert dos format to unix format:
	sed -i 's/^M//g' filename
	(^M: Ctrl + v, Ctrl + M)

*4* Test CMD
You can use the following cmd to get supported cmd:
	echo "help" > /dev/kchar

*5* Make install package
You can run the following script to make rpm/deb package for CentOS/Ubuntu:
	tool/mk_package.sh

Usage: ./path/to/mk_package.sh [OPTION]
OPTION:
	-v specify the software version number(default version is 00.00.00.00)
	   for example, ./path/to/mk_package.sh -v 01.01.01.01

Depond on tools install:
	for Ubuntu:  sudo apt install dkms dpkg debhelper python2 python3
	for CentOS:  sudo yum install epel-release
	             sudo yum install dkms redhat-lsb-core rpm-build python2 python3
				 
