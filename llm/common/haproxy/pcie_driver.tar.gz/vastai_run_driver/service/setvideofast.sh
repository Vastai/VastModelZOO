#!/bin/bash

# 等待vastai_pci模块加载
while true; do
    if lsmod | grep -q vastai_pci; then
        echo "检测到vastai_pci模块已加载，开始设置..."
        break
    else
        echo "等待vastai_pci模块加载..."
        sleep 1
    fi
done

while true; do
    if [ -e "/dev/vatools" ]; then
        echo "检测到 /dev/vatools 设备节点，开始设置..."
        break
    else
        echo "等待 /dev/vatools 设备节点出现..."
        sleep 1
    fi
done

# 执行设置命令
sleep 2
vasmi setvideomulticore 1 -d all -i all -y