#!/bin/bash

# 存储内核版本的文件路径
STORAGE_FILE="/var/lib/va_run/.last_kernel_version"

# 初始化文件
if [ ! -f "${STORAGE_FILE}" ]; then
    uname -r > "${STORAGE_FILE}"
fi

# 循环检测版本变化
while true; do
    current_version=$(uname -r)
    previous_version=$(cat "${STORAGE_FILE}")

    if [ "${current_version}" != "${previous_version}" ]; then
        echo -e "\n检测到内核版本变更："
        echo "旧版本：${previous_version}"
        echo "新版本：${current_version}"
        echo "${current_version}" > "${STORAGE_FILE}"
        run_name=$(basename "$(ls /var/lib/va_run/va*.run)")
        arg_list=$(cat /var/lib/va_run/arg_list.txt)
        cd /var/lib/va_run/
        bash $run_name $arg_list
        # 可扩展
        exit 0
    fi

    sleep 60  # 每60秒检查一次
done
