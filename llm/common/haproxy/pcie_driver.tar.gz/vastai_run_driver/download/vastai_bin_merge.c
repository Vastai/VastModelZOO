#include <linux/firmware.h>
#include "vastai_pci.h"
#include "vastai_bin_merge.h"

const unsigned char vastai_common_boot_hex_buf[] = {
#include vastai_common_boot_hexcode
};
const unsigned char vastai_reset_vector_hex_buf[] = {
#include vastai_reset_vector_hexcode
};

int vastai_is_file_exist(char *path)
{
	struct file *file;

	file = filp_open(path, O_RDONLY, 0);

	if (file == ERR_PTR(-ENOENT)) {
		VASTAI_PCI_DBG(NULL, 0,
				"%s path[%s] not exist, try next priority\n",
				__func__, path);
		return 0;
	} else if(IS_ERR(file)) {
		VASTAI_PCI_INFO(NULL, 0,
				"%s path[%s] PTR_ERR[0x%lx]\n",
				__func__, path, PTR_ERR(file));
		return PTR_ERR(file);
	} else {
		VASTAI_PCI_DBG(NULL, 0,
				"%s path[%s] exist\n",
				__func__, path);
		filp_close(file, NULL);
		return 1;
	}
}

void vastai_set_sub_header(struct _sub_header *sh, int i, size_t fw_size)
{
	u32 list_type[]={0x290f0000,0x280f0000,0x27070000,0x26ff0000,0x25ff0000,0x24000000,0x23000000,0x22000000,0x21000000,0x20010000};
	u32 list_startAddr[]={0x0b000000,0x09000000,0x07800000,0x02800000,0x00800000,0x00400000,0x00000000,0xc0000000,0x80000000,0x40000000};
	u32 list_offset[]={0x00008000,0x00008000,0x00008000,0x00008000,0x00004000,0x0,0x0,0x0,0x0,0x0};

	sh->image_type.val = list_type[i];
	sh->image_addr   = list_startAddr[i];
	sh->image_length = vast_div_round_up(fw_size, 16) * 16;
	sh->offset_len   = list_offset[i];
}

int vastai_get_fw_data(struct vastai_pci_info *priv, u8 die_id,
				const struct firmware **fw_entry, char *fw_name)
{
	int request_ret = 0;
	char fw_path[100] = "vastai/sv100/"; /*TODO: fw_path[100] is not a good way*/

	strcat(fw_path, fw_name);
	//TODO : vastai_is_file_exist check
	request_ret = request_firmware(fw_entry, fw_path, &(priv->dev->dev));
	if (request_ret != 0) {
		VASTAI_PCI_INFO(priv, die_id,
				"%s ret[%d]: can't find fw/bl from path[/lib/firmware/%s], it will download fw/bl from ko file\n",
				__func__, request_ret, fw_path);
		if (*fw_entry)
			release_firmware(*fw_entry);
		return request_ret;
	}

	return request_ret;
}

int vastai_download_fw_bin(struct vastai_pci_info *priv, u8 die_id, int i,
					const u8 *fw_data, size_t fw_size, u64 *fw_addr)
{
	struct _sub_header sh = {0};
	u8 padding[16] = {0};
	int ret = 0;

	memset(padding, 0, sizeof(padding));
	vastai_set_sub_header(&sh, i, fw_size);

	ret = vastai_pci_download_fw(priv, die_id, (u8*)&sh,
					sizeof(sh), *fw_addr);
	if(ret) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download sh %d failed ret[%d]\n",
			__func__, i, ret);
		return ret;
	}
	*fw_addr = *fw_addr + sizeof(sh);

	ret = vastai_pci_download_fw(priv, die_id, fw_data,
					fw_size, *fw_addr);
	if(ret) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download fw %d failed ret[%d]\n",
			__func__, i, ret);
		return ret;
	}

	*fw_addr = *fw_addr + fw_size;

	if(fw_size%16) {
		ret = vastai_pci_download_fw(priv, die_id, padding,
						16-fw_size%16, *fw_addr);
		if(ret) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s download padding %d failed ret[%d]\n",
				__func__, i, ret);
			return ret;
		}

		*fw_addr = *fw_addr + (16 - fw_size%16);
	}

	return ret;
}

int vastai_download_all_fw_bin(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;
	struct _packet_header ph = {0};
	int i = 0;
	u64 fw_addr = VASTAI_FW_DL_ADDR + sizeof(ph);
	char fw_name[][10] = {"vdsp.bin", "vemcu.bin", "vdmcu.bin", "odsp.bin", "lmcu.bin", "cmcu.bin", "smcu.bin"};

	VASTAI_PCI_INFO(priv, die_id,
			"%s download from /lib/firmware/vastai/sv100/smcu.bin\n",
			__func__);
	for(i=0; i<sizeof(fw_name)/sizeof(fw_name[0]); i++) {
		const struct firmware *fw_entry = NULL;

		ret = vastai_get_fw_data(priv, die_id, &fw_entry,
					fw_name[i]);
		if(ret) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s %s not exist\n",
				__func__, fw_name[i]);
			continue;
		}

		vastai_download_fw_bin(priv, die_id, i, fw_entry->data, fw_entry->size, &fw_addr);
		if (fw_entry)
			release_firmware(fw_entry);
	}

	ret = vastai_download_fw_bin(priv, die_id, i++, vastai_common_boot_hex_buf,
					VASTAI_COMMON_BOOT_HEX_SIZE, &fw_addr);
	if(ret) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download %s failed\n",
			__func__, vastai_common_boot_hexcode);
		return ret;
	}

	ret = vastai_download_fw_bin(priv, die_id, i++, vastai_reset_vector_hex_buf,
					VASTAI_RESET_VECTOR_HEX_SIZE, &fw_addr);
	if(ret) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download %s failed\n",
			__func__, vastai_reset_vector_hexcode);
		return ret;
	}

	ph.image_type	= 0x20010000;
	ph.decrypt_addr = 0x40000000;
	ph.image_length = fw_addr -  VASTAI_FW_DL_ADDR;
	ph.signature_len = 0;

	ret = vastai_pci_download_fw(priv, die_id, (u8*)&ph,
					sizeof(ph), VASTAI_FW_DL_ADDR);
	if(ret) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download fw %d failed ret[%d]\n",
			__func__, i, ret);
		return ret;
	}

	return ret;
}

