#include <linux/firmware.h>
#include <linux/delay.h>
#include "vastai_pci.h"
#define CONFIG_VASTAI_DOWNLOAD_FW_FROM_HEX
#ifdef CONFIG_VASTAI_DOWNLOAD_FW_FROM_HEX
#include "vastai_fw_hex.h"
#endif
#include "vastai_state.h"
#include "vastai_pci_boot.h"
#include "vastai_bin_merge.h"
#include "vastai_dmi_table.h"
#include "vastai_pci_test.h"
#include "vastai_trans_layer.h"
#include "sg100_cmd.h"



//#include "vastai_bin_merge.h"

#define vastai_bl0_hexcode	"../fw/vastai_bl0.bin.hex"
#define vastai_sg100_bl0_hexcode	"../fw/sg100/vastai_bl0.bin.hex"
#define vastai_sg100_bl0_full_hexcode	"../fw/sg100/vastai_bl0_full.bin.hex"
#define vastai_sg100_bl0_base_hexcode	"../fw/sg100/vastai_bl0_base.bin.hex"
#define vastai_bl0_app_hexcode	"../fw/vastai_bl0_app.bin.hex"
#define vastai_bl1_hexcode	"../fw/vastai_bl1.bin.hex"
#define vastai_sg100_bl1_hexcode	"../fw/sg100/vastai_bl1.bin.hex"
#define vastai_fw_hexcode	"../fw/vastai_fw.bin.hex"
#define vastai_sg100_fw_hexcode	"../fw/sg100/vastai_fw.bin.hex"
#define vastai_fw_ddrbw_hexcode "../fw/vastai_fw_ddrbw.bin.hex"
#define vastai_bmcu_hexcode "../fw/vastai_bmcu.bin.hex"
#define vastai_sg100_bmcu_hexcode "../fw/sg100/vastai_bmcu.bin.hex"


const unsigned char vastai_bl0_hex_buf[] = {
#include vastai_bl0_hexcode
};
const unsigned char vastai_sg100_bl0_hex_buf[] = {
#include vastai_sg100_bl0_hexcode
};
const unsigned char vastai_sg100_bl0_full_hex_buf[] = {
#include vastai_sg100_bl0_full_hexcode
};
const unsigned char vastai_sg100_bl0_base_hex_buf[] = {
#include vastai_sg100_bl0_base_hexcode
};
const unsigned char vastai_bl0_app_hex_buf[] = {
#include vastai_bl0_app_hexcode
};
const unsigned char vastai_bl1_hex_buf[] = {
#include vastai_bl1_hexcode
};
const unsigned char vastai_sg100_bl1_hex_buf[] = {
#include vastai_sg100_bl1_hexcode
};
const unsigned char vastai_fw_hex_buf[] = {
#include vastai_fw_hexcode
};
const unsigned char vastai_sg100_fw_hex_buf[] = {
#include vastai_sg100_fw_hexcode
};
const unsigned char vastai_fw_ddrbw_hex_buf[] = {
#include vastai_fw_ddrbw_hexcode
};
const unsigned char vastai_bmcu_hex_buf[] = {
#include vastai_bmcu_hexcode
};

const unsigned char vastai_sg100_bmcu_hex_buf[] = {
#include vastai_sg100_bmcu_hexcode
};


u32 VASTAI_BL0_HEX_SIZE = sizeof(vastai_bl0_hex_buf);
u32 VASTAI_SG_BL0_HEX_SIZE = sizeof(vastai_sg100_bl0_hex_buf);
u32 VASTAI_SG_BL0_FULL_HEX_SIZE = sizeof(vastai_sg100_bl0_full_hex_buf);
u32 VASTAI_SG_BL0_BASE_HEX_SIZE = sizeof(vastai_sg100_bl0_base_hex_buf);
u32 VASTAI_BL0_APP_HEX_SIZE = sizeof(vastai_bl0_app_hex_buf);
u32 VASTAI_BMCU_HEX_TEST_SIZE = sizeof(vastai_bmcu_hex_buf);

int is_support_download_fw_with_service(struct vastai_pci_info *priv, u16 *bitmap_dl_support)
{
	*bitmap_dl_support = priv->bitmap_dl_support;

	return 0;
}


u64 vastai_get_bl0_read_base_addr(struct vastai_pci_info *priv)
{
	int max_retry_cnt = 3;

	while(0 == priv->bl0_read_addr && max_retry_cnt) {
		VASTAI_PCI_INFO(priv, 0, "bl0_read_addr not ready, pls wait\n");
		ssleep(1);
		max_retry_cnt--;
	}

	return priv->bl0_read_addr;
}

u64 vastai_get_bl0_read_size_addr(struct vastai_pci_info *priv)
{
	int max_retry_cnt = 3;

	while(0 == priv->bl0_read_addr && max_retry_cnt) {
		VASTAI_PCI_INFO(priv, 0, "bl0_read_addr not ready, pls wait\n");
		ssleep(1);
		max_retry_cnt--;
	}

	if(priv->bl0_read_addr == VASTAI_BL0_READ_BASE_ADDR)
		return VASTAI_BL0_READ_SIZE_ADDR;
	if(priv->bl0_read_addr == XSPI_READ_BASE)
		return XSPI_READ_BASE - 4;

	VASTAI_PCI_ERR(priv, 0, "unkonwn addr[0x%llx]\n", priv->bl0_read_addr);
	return 0;
}

u64 vastai_get_bl0_download_addr(struct vastai_pci_info *priv)
{
	int max_retry_cnt = 3;

	while(0 == priv->bl0_dl_addr && max_retry_cnt) {
		VASTAI_PCI_INFO(priv, 0, "bl0_dl_addr not ready, pls wait\n");
		ssleep(1);
		max_retry_cnt--;
	}

	return priv->bl0_dl_addr;
}

/**
 * @brief download fw. If path_name is given, will try to
 *      load fw from /lib/firmware first.
 *
 * @param pci_info: vastai sv100 pci base struct.
 * @param die_id: the destinat die id. not the die_index
 * @param path_name: fw path at /lib/firmware/. If not NULL, this is most priority.
 * @param data: fw.bin data.
 * @param size: fw.bin data's size.
 * @param fw_addr: fw destinat addr.
 * @return int: 0 is success. other is failed.
 */
int vastai_process_download_request(struct vastai_pci_info *pci_info,
						u8 die_id, u8 *path_name, const u8 *data,
						size_t size, u64 fw_addr)
{
	int request_ret = 0, ret = 0;
	const struct firmware *fw_entry = NULL;
	const u8 *__data = data;
	size_t __size = size;
	char full_path[100] = "/lib/firmware/"; /*TODO: full_path[100] is not a good way*/

	if(NULL != path_name)
		strcat(full_path, path_name);

	/* most priority */
	if (1 == vastai_is_file_exist(full_path) && path_name) {
		request_ret = request_firmware(&fw_entry, path_name, &(pci_info->dev->dev));
		if (request_ret != 0)
			VASTAI_PCI_INFO(pci_info, die_id,
					"%s ret[%d]: can't find fw/bl from path[/lib/firmware/%s], it will download fw/bl from ko file\n",
					__func__, request_ret, path_name);
	}

	/* get fw from /lib/firmarw success */
	if (!request_ret && fw_entry) {
		VASTAI_PCI_INFO(pci_info, die_id,
				"%s get fw/bl from path[/lib/firmware/%s] success, download fw/bl from this path\n",
				__func__, path_name);
		__data = fw_entry->data;
		__size = fw_entry->size;
	}

	/* Not get any fw */
	if (!__data) {
		VASTAI_PCI_ERR(pci_info, die_id,
				"%s get fw/bl failed! path_name %s, data_addr %p\n",
				__func__, path_name, data);
		return -ENOENT;
	}

	/* load fw */
	if(__data == data)
		VASTAI_PCI_INFO(pci_info, die_id,
					"%s [%s]download fw/bl from ko file\n",
					__func__, path_name);
	ret = vastai_pci_download_fw(pci_info, die_id, __data,
				     __size, fw_addr);
	/* we need free fw_entry */
	if (fw_entry)
		release_firmware(fw_entry);
	return ret;
}

int vastai_split_download_bl0(struct vastai_pci_info *priv, const u8 *data, size_t size, u8 partition)
{
	size_t bytes = 0;
	size_t offset = 0;
	struct pcie_transfer_cmd trans;
	int ret = 0;

	while (offset < size) {
		/* download xspi bin to ddr as wr_unit each time */
		bytes = MIN(size - offset, XSPI_RW_UNIT);
		ret = vastai_pci_download_fw(priv, 0, data+offset, bytes, XSPI_FW_DDR_DL_ADDR);
		if (ret < 0) {
			VASTAI_PCI_ERR(
					priv, DUMMY_DIE_ID,
					"%s (2/5) download xspi error, offset=0x%lx, size=%ld, ddr_addr=0x%lx\n",
					__func__, offset, bytes, XSPI_FW_DDR_DL_ADDR);
			return ret;
		}

		/* send flash xspi cmd to smcu */
		trans.w0.s_data0.optcode = SMCU_XSPI_FW_FLASH;
		trans.w0.s_data0.rev0 = partition;
		trans.w1.data1 = bytes;
		trans.w2.data2 = offset;
		trans.w3.data3 = size;

		ret = send_xspi_flash_cmd_sg100(priv, &trans);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				      "%s (2/5) write flash cmd err=%d\n",
				      __func__, ret);
			return ret;
		}

		/* prepare for the next flash */
		offset += bytes;
	}

	return ret;
}


int vastai_pci_flash_xspi_bin(struct vastai_pci_info *priv, u32 die_id,
			      u8 *path_name, const void *bin_buf,
			      size_t buf_size, u8 partition)
{
	int ret = 0;

	VASTAI_PCI_INFO(priv, die_id, "%s die%d (1/5) start.\n",
			__func__, die_id);

	if(vastai_get_board_type(priv) == SV100) {
		u64 bl0_dl_addr = vastai_get_bl0_download_addr(priv);
		/* download xspi code to csram or ddr. */
		ret = vastai_process_download_request(priv, die_id, path_name, bin_buf,
						      buf_size, bl0_dl_addr);
		if (ret < 0) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s die%d (2/5) download xspi error, size=%ld, addr=0x%llx\n",
				__func__, die_id, buf_size,
				bl0_dl_addr);
			return ret;
		}

		/* send flash xspi cmd to smcu */
		/* base and full is same in sv100 -----confirm with Apple.Li */
		if (VASTAI_PCI_FLASH_BASE == partition || VASTAI_PCI_FLASH_FULL == partition) {
			ret = send_xspi_flash_cmd(priv, die_id,
				     VASTAI_PCIE_SUB_FLASH_BASE_XSPI, BL0_BASE_TOTAL_SIZE);
		} else if (partition == VASTAI_PCI_FLASH_BL0) {
			ret = send_xspi_flash_cmd(priv, die_id,
				     VASTAI_PCIE_SUB_FLASH_XSPI, BL0_APP_TOTAL_SIZE);
		} else {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s (2/5) write flash unsupported cmd[%d]\n",
				       __func__, partition);
			return -1;
		}
		if (ret) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s die%d (2/5) write flash cmd err=%d\n",
				       __func__, die_id, ret);
			return ret;
		}
	}
	if(vastai_get_board_type(priv) == SG100) {
		const struct firmware *fw_entry = NULL;
		int request_ret = 0;
		const u8 *__data = bin_buf;
		size_t __size = buf_size;

		/* most priority */
		if (path_name) {
			request_ret = request_firmware(&fw_entry, path_name, &(priv->dev->dev));
			if (request_ret != 0)
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
						"%s ret[%d]: can't find fw/bl from path[/lib/firmware/%s], it will download fw/bl from ko file\n",
						__func__, request_ret, path_name);
		}
		/* get fw from /lib/firmarw success */
		if (!request_ret && fw_entry) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"%s get fw/bl from path[/lib/firmware/%s] success, to download fw/bl from this path\n",
					__func__, path_name);
			__data = fw_entry->data;
			__size = fw_entry->size;
		}
		/* Not get any fw */
		if (!__data) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s get fw/bl failed! path_name %s, data_addr %p\n",
				       __func__, path_name, __data);
			return -ENOENT;
		}

		ret = vastai_split_download_bl0(priv, __data, __size, partition);
		if (fw_entry)
			release_firmware(fw_entry);
	}

	VASTAI_PCI_INFO(priv, die_id, "%s die%d (2/5) write successfully.\n",
			__func__, die_id);

	dmi_set_device(priv);

	return ret;
}

#if 0
int vastai_pci_flash_xspi_bin_sg100(struct vastai_pci_info *priv, u8 *path_name, const void *bin_buf,
						size_t buf_size, u8 partition)
{
	int ret = 0;
	int request_ret = 0;
	const struct firmware *fw_entry = NULL;
	const u8 *__data = bin_buf;
	size_t __size = buf_size;
	u32 die_id = 0;

	VASTAI_PCI_INFO(priv, die_id, "%s die%d (1/5) start.\n",
			__func__, die_id);
	VASTAI_PCI_INFO(priv, die_id, "%s path_name=%s, partition=%d\n",
		      __func__, path_name, partition);

	/* most priority */
	if (path_name) {
		request_ret = request_firmware(&fw_entry, path_name, &(priv->dev->dev));
		if (request_ret != 0)
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"%s ret[%d]: can't find fw/bl from path[/lib/firmware/%s], it will download fw/bl from ko file\n",
					__func__, request_ret, path_name);
	}
	/* get fw from /lib/firmarw success */
	if (!request_ret && fw_entry) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s get fw/bl from path[/lib/firmware/%s] success, to download fw/bl from this path\n",
				__func__, path_name);
		__data = fw_entry->data;
		__size = fw_entry->size;
	}
	/* Not get any fw */
	if (!__data) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s get fw/bl failed! path_name %s, data_addr %p\n",
			       __func__, path_name, __data);
		return -ENOENT;
	}

	ret = vastai_split_download_bl0(priv, __data, __size, partition);
	if(ret)
		goto OUT;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s (2/5) write successfully.\n", __func__);

	dmi_set_device(priv);

OUT:
	/* we need free fw_entry */
	if (fw_entry)
		release_firmware(fw_entry);

	return ret;
}
#endif

int vastai_pci_flash_xspi(struct vastai_pci_info *priv, u32 die_id, char *path_name,
				const char *i_buf, size_t buf_size, u8 partition)
{
	int ret = 0;
	int i = 0;
	void *read_buf = NULL;

	ret = vastai_update_start(priv, die_id);
	if(ret) return ret;

	ret = vastai_pci_flash_xspi_bin(priv, die_id, path_name, i_buf,
					buf_size, partition);
	if (ret) {
		goto failed;
	}

	/* read xspi */
	read_buf = vmalloc(buf_size);
	if (read_buf == NULL) {
		VASTAI_PCI_ERR(priv, die_id,
			"%s: vmalloc mem failed!\n", __func__);
		goto failed;
	}
	ret = vastai_pci_read_xspi(priv, die_id, 0, read_buf,
					buf_size,
					partition, false);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s die%d (3/5) read xspi flash err=%d\n",
			       __func__, die_id, ret);
		goto vfreed;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s die%d (3/5) read successfully.\n",
			__func__, die_id);

	/* verify xspi */
	for (i = 0; i < buf_size; i++) {
		if (i_buf[i] !=
		    *((char *)(read_buf) + i)) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s die%d (4/5) verify xspi flash errpos=0x%x\n",
				__func__, die_id, i);
			goto vfreed;
		}
	}

	VASTAI_PCI_INFO(priv, die_id, "%s die%d (4/5) verify successfully.\n",
			__func__, die_id);

	/* update flag */
	ret = vastai_pci_update_flag_xspi(priv, die_id, partition);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s die%d (5/5) update flag xspi flash err=%d\n",
			       __func__, die_id, ret);
		goto vfreed;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s die%d (5/5) update flag successfully, finished!\n",
			__func__, die_id);
vfreed:
	vfree(read_buf);

failed:
	vastai_update_done(priv);
	return ret;
}

int vastai_pci_flash_bmcu(struct vastai_pci_info *priv, u32 die_id)
{
	int ret = 0;

	ret = vastai_pci_flash_bmcu_bin(priv, die_id, ADDR(priv, BMCU_PATH),
					ADDR(priv, bmcu_hex_buf), ADDR(priv, bmcu_size));
	if (ret) {
		return ret;
	}
#ifndef CONFIG_VASTAI_JENKINS_TEST
	if(vastai_get_board_type(priv) == SV100)
		vastai_pci_get_fw_ver(priv, 0x4, false);
	if(vastai_get_board_type(priv) == SG100)
		vastai_pci_get_fw_ver_sg(priv, 0x600);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "flash BMCU by pcie finished!\n");
#endif
	return ret;
}

int vastai_pci_download_fw(struct vastai_pci_info *priv,
				  unsigned int die_id,
				  const unsigned char *fw_hex_buf, size_t fw_hex_size,
				  u64 fw_addr)
{
	int ret;

	ret = vastai_pci_tl_write(priv, die_id, fw_addr, (void*)fw_hex_buf, fw_hex_size);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "%s write bl1/fw error\n",
			       __func__);
	}

	return ret;
}

int vastai_update_start(struct vastai_pci_info* priv, int die_id)
{
	int ret = VASTAI_STATE_TRANSIT_SUCCESS;
	int old;
	old = atomic_cmpxchg(&(priv->is_fw_updating), 0, 1);

	if (old != 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s: Can NOT update bmcu/bl0 when "
						"smcu is busy\n", __FUNCTION__);
		ret = -EBUSY;
	}
	return ret;
}

void vastai_update_done(struct vastai_pci_info* priv)
{
	atomic_cmpxchg(&(priv->is_fw_updating), 1, 0);
}

int vastai_get_download_addr(struct vastai_pci_info *priv)
{
	int max_retry_cnt = 3;

	while(0 == priv->bmcu_dl_addr) {
		if(0 == max_retry_cnt)
			break;
		VASTAI_PCI_INFO(priv, 0, "bmcu_dl_addr not ready, pls wait\n");
		ssleep(1);
		max_retry_cnt--;
	}

	return 0;
}

int vastai_pci_flash_bmcu_bin(struct vastai_pci_info *priv, u32 die_id,
			u8 *path_name, const void* bin_buf, size_t buf_size)
{
	int ret = 0;

	ret = vastai_update_start(priv, die_id);
	if(ret) return ret;

	VASTAI_PCI_INFO(priv, die_id, "%s die%d (1/3) start.\n", __func__, die_id);
	if(vastai_get_board_type(priv) == SV100)
		vastai_get_download_addr(priv);

	/* download bmcu code to csram. */
	ret = vastai_process_download_request(priv, die_id,
						path_name, bin_buf,
						buf_size, priv->bmcu_dl_addr);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id,
				 "%s die%d (2/3) download bmcu error, size=%ld, addr=0x%llx\n",
				 __func__, die_id,
				 buf_size,
				 priv->bmcu_dl_addr);
		vastai_update_done(priv);
		return ret;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s die%d (2/3) download bmcu successfully.\n", __func__, die_id);
#ifndef CONFIG_VASTAI_JENKINS_TEST
	if(vastai_get_board_type(priv) == SV100) {
		/* send upgrade cmd to smcu */
		ret = vastai_send_pcie_cmd(priv, vastai_pci_get_die_index(priv, die_id),
						VASTAI_PCIE_SUB_FLASH_BMCU, buf_size);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s send cmd fail!\n",
				__func__);
			vastai_update_done(priv);
			return ret;
		}
		ret = wait_for_completion_timeout(
				&(priv->bmcu_update_comp),
				msecs_to_jiffies(VASTAI_BMCU_UPDATE_MAX_WAIT_TIME));
		reinit_completion(&(priv->bmcu_update_comp));
		if (ret <= 0) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s die%d (3/3) bcmu update timeout:%d ms.\n",
				__func__, die_id,
				VASTAI_BMCU_UPDATE_MAX_WAIT_TIME);
			ret = -ETIMEDOUT;
		} else {
			ret = priv->bmcu_return_val;
			if (ret == 0) {
				VASTAI_PCI_INFO(
					priv, die_id,
					"%s die%d (3/3) update bmcu successfully.\n",
					__func__, die_id);
			} else {
				VASTAI_PCI_ERR(
					priv, die_id,
					"%s die%d (3/3) update bmcu failed 0x%x (0x10: trx err; 0x11: ver err; 0x12: sot err; 0x13: tx err; 0x14: eot err; 0x15: stat err; 0x16: tag err; 0x17: verlast err; 0x18: switch err; 0x30: noup err; 0x40: chksum err; 0x41: chktype err).\n",
					__func__, die_id, ret);
			}
		}
	}
	if(vastai_get_board_type(priv) == SG100) {
		struct pcie_transfer_cmd trans;
		/* send flash bmcu cmd to smcu */
		trans.w0.s_data0.optcode = SMCU_BMCU_FW_FLASH;
		trans.w1.data1 = buf_size;

		ret = vastai_pci_send_msg(priv, vastai_pci_get_die_index(priv, die_id), COMMON_HOST_TO_SMCU_CMD_BUF, &trans, 0);
		if (ret != 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s flash bmcu cmd err=%d\n", __func__, ret);
			vastai_update_done(priv);
			return ret;
		}
		ssleep(6);
	}
#endif
	vastai_update_done(priv);
	return ret;
}

int vastai_download_fw_packets(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;

	if(1 == vastai_is_file_exist("/lib/firmware/vastai/sv100/smcu.bin")) { /* sg100:TODO */
		ret = vastai_download_all_fw_bin(priv, die_id);
		if (ret < 0) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s vastai_download_all_fw_bin failed ret[%d]\n",
				__func__, ret);
		}
		return ret;
	}

	ret = vastai_process_download_request(priv, die_id,
						ADDR(priv, FW_PATH), priv->addr->fw_hex_buf,
						priv->addr->fw_size, ADDR(priv, DDR_BASE_ADDR) + ADDR(priv, VASTAI_FW_DL_OFFSET));
	if (ret < 0) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"%s download fw error, size=%ld, addr=%ld\n",
			__func__, priv->addr->fw_size,
			VASTAI_FW_DL_ADDR);
		return ret;
	}

	return ret;
}

void vastai_global_download_init(struct vastai_addr_info *vastai_global_addr_info)
{
	vastai_global_addr_info[SV100].bl1_hex_buf     = vastai_bl1_hex_buf;
	vastai_global_addr_info[SG100].bl1_hex_buf     = vastai_sg100_bl1_hex_buf;
	vastai_global_addr_info[SV100].bl1_size        = VASTAI_BL1_HEX_SIZE;
	vastai_global_addr_info[SG100].bl1_size        = VASTAI_SG_BL1_HEX_SIZE;
	vastai_global_addr_info[SV100].fw_hex_buf      = vastai_fw_hex_buf;
	vastai_global_addr_info[SG100].fw_hex_buf      = vastai_sg100_fw_hex_buf;
	vastai_global_addr_info[SV100].fw_size         = VASTAI_FW_HEX_SIZE;
	vastai_global_addr_info[SG100].fw_size         = VASTAI_SG_FW_HEX_SIZE;

	vastai_global_addr_info[SV100].bmcu_hex_buf    = vastai_bmcu_hex_buf;
	vastai_global_addr_info[SG100].bmcu_hex_buf    = vastai_sg100_bmcu_hex_buf;
	vastai_global_addr_info[SV100].bmcu_size       = VASTAI_BMCU_HEX_SIZE;
	vastai_global_addr_info[SG100].bmcu_size       = VASTAI_SG_BMCU_HEX_SIZE;
}



