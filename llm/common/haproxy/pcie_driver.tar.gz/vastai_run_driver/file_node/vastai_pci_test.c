/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/ctype.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/random.h>
#include <linux/dma-buf.h>

#include "vastai_pci.h"
#include "vastai_pci_api.h"
#include "vastai_pci_test.h"
#include "vastai_udma_test.h"
#include "vastai_udma_engine.h"
#include "vastai_dmabuf.h"
#include "vastai_fifo.h"
#include "vastai_pci_vf.h"
#include "vastai_state.h"
#include "vastai_utils.h"
#include "vastai_dmi_table.h"
#include "sg100_pcie_wrap.h"
#include "hw_config.h"
#include "sdma.h"
#include "smmu.h"
#include "sg100_cmd.h"
#include "va_vsync.h"
#include "va_dma_core.h"
#include "vastai_download_fw.h"
#include "vastai_fw_hex.h"
#include "vatool_addr_partition.h"

#ifdef CONFIG_VASTAI_RAS
#include "vastai_ras.h"
#endif

#ifdef CONFIG_VASTAI_KUNIT
#include "stub.h"
#endif

#ifdef EMULATOR_ENV
#include "vastai.h"
#endif
#define TCGETS	       0x5401
#define TCSETS	       0x5402
#define TCSETSW	       0x5403
#define TCSETSF	       0x5404
#define TIOCSERGSTRUCT 0x5458 /* For debugging only */
#define TIOCSERGETLSR  0x5459 /* Get line status register */
#define TIOCSERCONFIG  0x545
struct vastai_dma_buf dmb[4];
unsigned char* g_host_buf_va;
#define PCIE_PAYLOAD_MONITOR_EN 0
extern u32 test_PCIe_Perf;
extern u32 test_smcu_RW_Perf;

typedef union logsys_msg_info_s
{
	struct
	{
		u16 msg_level   : 3;
		u16 msg_type    : 3;
		u16 msg_len     : 10;
	};
	u16 n_val;
}logsys_msg_info_t;

typedef struct logsys_header_s
{
	u8 head_flag;
	u8 log_sn;
	logsys_msg_info_t msg_info;
	u32 timestamp;
} logsys_header_t;
#define MAX_REGION_NUM		256
struct vastai_inbound_atu_region_info{
	u32 region_num;
	u8  pf_num;
	u8  vf_num;
	//0:address match mode , 1:bar match mode
	u8  mode;
	u8  bar_num;
	u64 noc_base_addr;
	u64 host_base_addr;
	u64 host_limit_addr;
	u64 size;
};

struct inbound_atu_regs{
	u32 ctrl1_reg;
	u32 ctrl2_reg;
	u32 lo32_host_addr;
	u32 hi32_host_addr;
	u32 lo32_limit;
	u32 lo32_noc_addr;
	u32 hi32_noc_addr;
	u32 ctrl3_reg;
	u32 hi32_limit;
};

struct vastai_outbound_atu_region_info{
	u32 region_num;
	u64 noc_base_addr;
	u64 host_base_addr;
	u64 noc_limit_addr;
	u64 size;
};
struct outbound_atu_regs{
	u32 ctrl1_reg;
	u32 ctrl2_reg;
	u32 lo32_noc_addr;
	u32 hi32_noc_addr;
	u32 lo32_limit;
	u32 lo32_cpu_addr;
	u32 hi32_cpu_addr;
	u32 ctrl3_reg;
	u32 hi32_limit;
};

struct smmu_mpu_regs{
	u32 output_base;
	u32 output_size;
	u32 inputL_base;
	u32 inputH_base;
};

struct smmu_mpu_info{
	u64 output_base_ddr;
	u64 output_size_ddr;
	u64 input_base_ddr;
	u64 output_base_csram;
	u64 output_size_csram;
	u64 input_base_csram;
	u64 output_base_rgn2;
	u64 output_size_rgn2;
	u64 input_base_rgn2;
};

struct gfx_mpu_regs{
	u32 tgt0_output_base;
	u32 tgt0_output_size;
	u32 tgt0_inputL_base;
	u32 tgt0_inputH_base;

	u32 tgt1_output_base;
	u32 tgt1_output_size;
	u32 tgt1_inputL_base;
	u32 tgt1_inputH_base;

	u32 tgt2_output_base;
	u32 tgt2_output_size;
	u32 tgt2_inputL_base;
	u32 tgt2_inputH_base;
};

struct gfx_mpu_info{
	u64 output_base_tgt0;
	u64 output_size_tgt0;
	u64 input_base_tgt0;
	u64 output_base_tgt1;
	u64 output_size_tgt1;
	u64 input_base_tgt1;
	u64 output_base_tgt2;
	u64 output_size_tgt2;
	u64 input_base_tgt2;
};


u64 vatool_addressArray[vatool_address_count] = {
	SMU_PBOOT_ADDR,
	EFUSE_SRAM44_ADDR,
	EFUSE_SRAM5_ADDR,
	EFUSE_SRAM6_ADDR,
	EFUSE_SRAM37_ADDR,
	EFUSE_SRAM38_ADDR,
	ECC_1BIT_ERR_STORE_ADDR,
	ECC_2BIT_ERR_STORE_ADDR,
	DDR_CONTROL1_ADDR,
	DDR_CONTROL2_ADDR,
	DDR_CONTROL3_ADDR,
	DDR_CONTROL4_ADDR,
	VALID_ADDR,
	AIVI_DIS_ADDR,
	AIVID_FAIL_ADDR,
	SOC_REPAIR_ADDR,
	VID_REPAIR_ADDR,
	DLC0_REPAIR_ADDR,
	DLC1_REPAIR_ADDR,
	SMU_DONE_ADDR,
	PCIE_EP_LINK_ADDR,
	PCIE_EP_ERR0_ADDR,
	PCIE_EP_ERR1_ADDR,
	PCIE_RC_LINK_ADDR,
	PCIE_RC_ERR0_ADDR,
	PCIE_RC_ERR1_ADDR,
	APP_VER_ADDR,
	V2_VER_ADDR,
	DDR_MEM_CODE_ADDR,
	DDR_MEM_WRTEST_ADDR,
	DDR_MEM_MAX_ADDR,
	GPIO_TEST_ADDR,
	CSRAM_MEM_RESERVED_3K,
};

#ifdef CONFIG_VASTAI_JENKINS_TEST
extern int vastai_pci_test_dma_by_ddr_boundary_addr(struct vastai_pci_info *priv);
#endif

static struct vastai_pci_arg_t vastai_pci_args_default[VASTAI_PCI_ARG_MAX] = {
	{ VASTAI_PCI_ARG_ADDR, "addr", 0 },
	{ VASTAI_PCI_ARG_VAL, "val", 0 },
	{ VASTAI_PCI_ARG_LEN, "len", 4 },
	{ VASTAI_PCI_ARG_BAR, "bar", 0 },
	{ VASTAI_PCI_ARG_RUN, "run", 0 },
	{ VASTAI_PCI_ARG_OFFSET, "offset", 0 },
	{ VASTAI_PCI_ARG_VIR, "vir", 0 },
	{ VASTAI_PCI_ARG_REGION, "region", 0 },
	{ VASTAI_PCI_ARG_MODE, "mode", 0 },
	{ VASTAI_PCI_ARG_CASE, "case", 0 },
	{ VASTAI_PCI_ARG_USER_ADDR, "user_addr", 0 },
	{ VASTAI_PCI_ARG_DIE, "die", 0 },
	{ VASTAI_PCI_ARG_DIR, "dir", 0 },
	{ VASTAI_PCI_ARG_MASKBIT, "maskbit", 0 },
	{ VASTAI_PCI_ARG_MMU, "mmu", 0 },
	{ VASTAI_PCI_ARG_ADDR0, "addr0", 0 },
	{ VASTAI_PCI_ARG_ADDR1, "addr1", 0 },
	{ VASTAI_PCI_ARG_PID, "pid", 0 },
	{ VASTAI_PCI_ARG_PA_ADDR, "pa", 0 },
	{ VASTAI_PCI_ARG_VA_ADDR, "va", 0 },
	{ VASTAI_PCI_ARG_PF, "pf", 0},
	{ VASTAI_PCI_ARG_CHANNEL, "ch", 0},
	{ VASTAI_PCI_ARG_CORE_POINT, "core_point", 0},
	{ VASTAI_PCI_ARG_LOG_LEVEL, "log_level", 2},

};

static void vastai_pci_args_init(struct vastai_pci_arg_t *args)
{
	unsigned int i;

	for (i = 0; i < VASTAI_PCI_ARG_MAX; i++)
		*(args + i) = vastai_pci_args_default[i];
}

static inline unsigned long vastai_pci_args_value(struct vastai_pci_arg_t *args,
						  unsigned char index)
{
	unsigned char i;

	for (i = 0; i < VASTAI_PCI_ARG_MAX; i++) {
		if (index == args[i].id)
			return args[i].def;
	}

	return -1;
}

static int vastai_get_log(struct vastai_pci_info *priv, u64 addr, u32 len)
{
	int ret;
	uint32_t log_rp = 0;
	uint32_t log_cnt = 0;
	char print_log_buf[256];
	uint32_t print_log_len;
	logsys_header_t *log_header = NULL;
	uint32_t block_end_flag;
	char *log_buf;

	log_buf = kmalloc(len * 2, GFP_KERNEL);
	if (NULL == log_buf) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s kmalloc fail\n", __func__);
		return -1;
	}
#ifdef DIAG_TEST_MODE
	ret = vastai_pci_mem_read(priv, 0, addr, log_buf, len);
#else
	ret = vastai_read_by_smcu(priv, addr, len ,log_buf);
#endif
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "vastai_read_by_smcu fail\n");
		kfree(log_buf);
		return -1;
	}

	while(1)
	{
		log_header = (logsys_header_t *)(log_buf + log_rp);
		if (log_header->head_flag == '#') {
			print_log_len = sprintf(print_log_buf, "[%d][%d]", log_cnt, log_header->timestamp);
			log_cnt++;
			memcpy((void *)(print_log_buf + print_log_len), (void *)(log_buf + log_rp + 8), log_header->msg_info.msg_len);
			print_log_len += log_header->msg_info.msg_len;
			print_log_buf[print_log_len] = '\0';
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s", print_log_buf);
			log_rp = log_rp + 8 + ((log_header->msg_info.msg_len + 3) / 4) * 4;
			if (log_rp >= len)
				break;
		}
		else {
			block_end_flag = *(uint32_t *)(log_buf + log_rp);
			if (block_end_flag == 0x5A3B96D2) {
				log_rp = (log_rp / 0x1000 + 1) * 0x1000;
				if (log_rp >= len)
					break;
			}
			else
				break;
		}
	}
	kfree(log_buf);
	return 0;
}

static void bubble_sort_inbound(struct vastai_inbound_atu_region_info *arry, int len) {
	int i, j;
	struct vastai_inbound_atu_region_info temp;
	for (i = 0; i < len - 1; i++)
		for (j = 0; j < len - 1 - i; j++)
			if (arry[j].noc_base_addr > arry[j + 1].noc_base_addr) {
				//1:save arry[j] element to temp
				temp.region_num 	  = arry[j].region_num;
				temp.pf_num     	  = arry[j].pf_num;
				temp.vf_num           = arry[j].vf_num;
				temp.mode       	  = arry[j].mode;
				temp.bar_num          = arry[j].bar_num;
				temp.noc_base_addr    = arry[j].noc_base_addr;
				temp.host_base_addr   = arry[j].host_base_addr;
				temp.host_limit_addr  = arry[j].host_limit_addr;
				temp.size             = arry[j].size;

				//2:save arry[j+1] element to arry[j]
				arry[j].region_num 	     = arry[j+1].region_num;
				arry[j].pf_num     	     = arry[j+1].pf_num;
				arry[j].vf_num           = arry[j+1].vf_num;
				arry[j].mode       	     = arry[j+1].mode;
				arry[j].bar_num          = arry[j+1].bar_num;
				arry[j].noc_base_addr    = arry[j+1].noc_base_addr;
				arry[j].host_base_addr   = arry[j+1].host_base_addr;
				arry[j].host_limit_addr  = arry[j+1].host_limit_addr;
				arry[j].size             = arry[j+1].size;

				//3:save temp element to arry[j+1]
				arry[j+1].region_num 	   = temp.region_num;
				arry[j+1].pf_num     	   = temp.pf_num;
				arry[j+1].vf_num           = temp.vf_num;
				arry[j+1].mode       	   = temp.mode;
				arry[j+1].bar_num          = temp.bar_num;
				arry[j+1].noc_base_addr    = temp.noc_base_addr;
				arry[j+1].host_base_addr   = temp.host_base_addr;
				arry[j+1].host_limit_addr  = temp.host_limit_addr;
				arry[j+1].size             = temp.size;
			}
	return;
}

static void bubble_sort_outbound(struct vastai_outbound_atu_region_info *arry, int len) {
	int i, j;
	struct vastai_outbound_atu_region_info temp;
	for (i = 0; i < len - 1; i++)
		for (j = 0; j < len - 1 - i; j++)
			if (arry[j].noc_base_addr > arry[j + 1].noc_base_addr) {
				//1:save arry[j] element to temp
				temp.region_num 	     = arry[j].region_num;
				temp.noc_base_addr       = arry[j].noc_base_addr;
				temp.host_base_addr      = arry[j].host_base_addr;
				temp.noc_limit_addr      = arry[j].noc_limit_addr;
				temp.size                = arry[j].size;

				//2:save arry[j+1] element to arry[j]
				arry[j].region_num 	     = arry[j+1].region_num;
				arry[j].noc_base_addr    = arry[j+1].noc_base_addr;
				arry[j].host_base_addr   = arry[j+1].host_base_addr;
				arry[j].noc_limit_addr   = arry[j+1].noc_limit_addr;
				arry[j].size             = arry[j+1].size;

				//3:save temp element to arry[j+1]
				arry[j+1].region_num 	   = temp.region_num;
				arry[j+1].noc_base_addr    = temp.noc_base_addr;
				arry[j+1].host_base_addr   = temp.host_base_addr;
				arry[j+1].noc_limit_addr   = temp.noc_limit_addr;
				arry[j+1].size             = temp.size;
			}
	return;
}

static void dump_atu(struct vastai_pci_info *priv)
{
	int region_num;
	int reg_addr;
	int valid_atu_num=0;
	int ret;
	struct vastai_inbound_atu_region_info *valid_inbound_atu_info_array;
	struct vastai_outbound_atu_region_info *valid_outbound_atu_info_array;
	struct inbound_atu_regs temp_inbound_regs;
	struct outbound_atu_regs temp_outbound_regs;
	u64 temp_noc_base_addr;
	u64 temp_host_base_addr;
	u64 temp_host_limit_addr;
	u64 temp_noc_limit_addr;
	u64 temp_size;
	u8 mode;
	int i;

	valid_inbound_atu_info_array = kzalloc(sizeof(struct vastai_inbound_atu_region_info) * MAX_REGION_NUM, GFP_KERNEL);

	for(region_num = 0;region_num < MAX_REGION_NUM; region_num++) {
		reg_addr=0x02800000 + region_num * 2 * 0x100 + 0x100;
		//to do dump slave bar atu
		ret = vastai_read_by_smcu(priv,  reg_addr, sizeof(struct inbound_atu_regs) ,&temp_inbound_regs);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
				       __func__, region_num, sizeof(temp_inbound_regs), ret);
			continue;
		}

		temp_host_base_addr  = (u64) temp_inbound_regs.hi32_host_addr << 32 | temp_inbound_regs.lo32_host_addr;
		temp_noc_base_addr   = (u64) temp_inbound_regs.hi32_noc_addr << 32 | temp_inbound_regs.lo32_noc_addr;
		temp_host_limit_addr = (u64) temp_inbound_regs.hi32_limit << 32 | temp_inbound_regs.lo32_limit;

		if((0 == ((temp_inbound_regs.ctrl2_reg>>31)&0x1))) {
			continue;
		}

		temp_size = temp_host_limit_addr - temp_host_base_addr + 1;

		//0:address match mode  1:bar match mode
		mode = temp_inbound_regs.ctrl2_reg>>30 & 0x1;

		valid_inbound_atu_info_array[valid_atu_num].region_num			= region_num;
		valid_inbound_atu_info_array[valid_atu_num].mode				= mode;
		valid_inbound_atu_info_array[valid_atu_num].pf_num				= temp_inbound_regs.ctrl1_reg>>20 & 0xFF;
		valid_inbound_atu_info_array[valid_atu_num].noc_base_addr		= temp_noc_base_addr;
		//0:address match mode
		if(0 == mode) {
			valid_inbound_atu_info_array[valid_atu_num].host_base_addr	= temp_host_base_addr;
			valid_inbound_atu_info_array[valid_atu_num].host_limit_addr	= temp_host_limit_addr;
			valid_inbound_atu_info_array[valid_atu_num].size			= temp_size;
			valid_inbound_atu_info_array[valid_atu_num].bar_num			= 0xFF;
		} else {
			valid_inbound_atu_info_array[valid_atu_num].bar_num			= temp_inbound_regs.ctrl2_reg>>8  & 0x7;

		}

		//check vf enable
		if(1 == (temp_inbound_regs.ctrl2_reg>>20 &0x1)) {
			valid_inbound_atu_info_array[valid_atu_num].vf_num = temp_inbound_regs.ctrl3_reg&0x1F;
		} else {
			valid_inbound_atu_info_array[valid_atu_num].vf_num = 0xFF;
		}

		valid_atu_num++;

	}

	bubble_sort_inbound(valid_inbound_atu_info_array,valid_atu_num);
	VASTAI_PCI_INFO(priv, priv->pkg_id,"-----start to dump %d valid inbound atu info-----\n",valid_atu_num);
	for(i = 0;i < valid_atu_num; i++) {
		if(0==valid_inbound_atu_info_array[i].mode){
			VASTAI_PCI_INFO(priv, priv->pkg_id,"rgn[%03d] pf:%d vf:%02x noc[0x%010llx ~ 0x%010llx] map to host[%016llx ~ %016llx] size[0x%llx]\n",
								valid_inbound_atu_info_array[i].region_num,
								valid_inbound_atu_info_array[i].pf_num,
								valid_inbound_atu_info_array[i].vf_num,
								valid_inbound_atu_info_array[i].noc_base_addr,
								valid_inbound_atu_info_array[i].noc_base_addr+valid_inbound_atu_info_array[i].size-1,
								valid_inbound_atu_info_array[i].host_base_addr,
								valid_inbound_atu_info_array[i].host_limit_addr,
								valid_inbound_atu_info_array[i].size);
		} else if (1==valid_inbound_atu_info_array[i].mode){
			VASTAI_PCI_INFO(priv, priv->pkg_id,"rgn[%03d] pf:%d vf:%02x noc[0x%010llx] map to host bar[%x]\n",
								valid_inbound_atu_info_array[i].region_num,
								valid_inbound_atu_info_array[i].pf_num,
								valid_inbound_atu_info_array[i].vf_num,
								valid_inbound_atu_info_array[i].noc_base_addr,
								valid_inbound_atu_info_array[i].bar_num);
		}

	}

	kfree(valid_inbound_atu_info_array);
	//start dump outbound atu
	valid_atu_num = 0;
	valid_outbound_atu_info_array = kzalloc(sizeof(struct vastai_outbound_atu_region_info) * MAX_REGION_NUM, GFP_KERNEL);
	for(region_num = 0;region_num < MAX_REGION_NUM; region_num++) {
		reg_addr=0x02800000 + region_num * 2 * 0x100;
		//to do dump slave bar atu
		ret = vastai_read_by_smcu(priv,  reg_addr, sizeof(struct outbound_atu_regs) ,&temp_outbound_regs);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
				       __func__, region_num, sizeof(temp_outbound_regs), ret);
			continue;
		}

	if((0 == ((temp_outbound_regs.ctrl2_reg>>31)&0x1))) {
			continue;
		}

		temp_host_base_addr = (u64) temp_outbound_regs.hi32_cpu_addr << 32 | temp_outbound_regs.lo32_cpu_addr;
		temp_noc_base_addr = (u64) temp_outbound_regs.hi32_noc_addr << 32 | temp_outbound_regs.lo32_noc_addr;
		temp_noc_limit_addr = (u64) temp_outbound_regs.hi32_limit << 32 | temp_outbound_regs.lo32_limit;
		temp_size = temp_noc_limit_addr - temp_noc_base_addr + 1;
		valid_outbound_atu_info_array[valid_atu_num].region_num = region_num;
		valid_outbound_atu_info_array[valid_atu_num].host_base_addr = temp_host_base_addr;
		valid_outbound_atu_info_array[valid_atu_num].noc_base_addr = temp_noc_base_addr;
		valid_outbound_atu_info_array[valid_atu_num].noc_limit_addr = temp_noc_limit_addr;
		valid_outbound_atu_info_array[valid_atu_num].size = temp_size;
		valid_atu_num++;
	}

	bubble_sort_outbound(valid_outbound_atu_info_array,valid_atu_num);
	VASTAI_PCI_INFO(priv, priv->pkg_id,"-----start to dump %d valid outbound atu info-----\n",valid_atu_num);
	for(i = 0;i < valid_atu_num; i++) {
		VASTAI_PCI_INFO(priv, priv->pkg_id,"rgn[%03d] noc[0x%010llx ~ 0x%010llx] map to host[%016llx ~ %016llx] size[0x%llx]\n",
					valid_outbound_atu_info_array[i].region_num,
					valid_outbound_atu_info_array[i].noc_base_addr,
					valid_outbound_atu_info_array[i].noc_limit_addr ,
					valid_outbound_atu_info_array[i].host_base_addr,
					valid_outbound_atu_info_array[i].host_base_addr + valid_outbound_atu_info_array[i].size-1,
					valid_outbound_atu_info_array[i].size);
	}
	kfree(valid_outbound_atu_info_array);
	return;
}

static void smmu_mpu_cfg(struct vastai_pci_info *priv)
{
	u32 stream_id;
	u32 region_num;
	u32 smmu_mpu_reg_base = 0;
	struct smmu_mpu_info *smmu_mpu_info_array;
	struct smmu_mpu_regs temp_smmu_mpu_regs;
	int ret;
	smmu_mpu_info_array = kzalloc(sizeof(struct smmu_mpu_info) * 32, GFP_KERNEL);

	for(stream_id=0;stream_id<32;stream_id++){
		region_num = 0;
		smmu_mpu_reg_base = (0xB00000+0xC0500) + region_num*256*4+ stream_id*(4*4);
		ret = vastai_read_by_smcu(priv,  smmu_mpu_reg_base, sizeof(struct smmu_mpu_regs) ,&temp_smmu_mpu_regs);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
					       __func__, region_num, sizeof(temp_smmu_mpu_regs), ret);
				continue;
			}
		smmu_mpu_info_array[stream_id].input_base_ddr  = ((u64)temp_smmu_mpu_regs.inputH_base<<32|temp_smmu_mpu_regs.inputL_base)<<12;
		smmu_mpu_info_array[stream_id].output_base_ddr = (u64)temp_smmu_mpu_regs.output_base<<12;
		smmu_mpu_info_array[stream_id].output_size_ddr = (u64)temp_smmu_mpu_regs.output_size<<12;

		region_num = 1;
		smmu_mpu_reg_base = (0xB00000+0xC0500) + region_num*256*4+ stream_id*(4*4);
		ret = vastai_read_by_smcu(priv,  smmu_mpu_reg_base, sizeof(struct smmu_mpu_regs) ,&temp_smmu_mpu_regs);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
					       __func__, region_num, sizeof(temp_smmu_mpu_regs), ret);
				continue;
			}
		smmu_mpu_info_array[stream_id].input_base_csram  = ((u64)temp_smmu_mpu_regs.inputH_base<<32|temp_smmu_mpu_regs.inputL_base)<<12;
		smmu_mpu_info_array[stream_id].output_base_csram = (u64)temp_smmu_mpu_regs.output_base<<12;
		smmu_mpu_info_array[stream_id].output_size_csram = (u64)temp_smmu_mpu_regs.output_size<<12;

		region_num = 2;
		smmu_mpu_reg_base = (0xB00000+0xC0500) + region_num*256*4+ stream_id*(4*4);
		ret = vastai_read_by_smcu(priv,  smmu_mpu_reg_base, sizeof(struct smmu_mpu_regs) ,&temp_smmu_mpu_regs);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
					       __func__, region_num, sizeof(temp_smmu_mpu_regs), ret);
				continue;
			}
		smmu_mpu_info_array[stream_id].input_base_rgn2  = ((u64)temp_smmu_mpu_regs.inputH_base<<32|temp_smmu_mpu_regs.inputL_base)<<12;
		smmu_mpu_info_array[stream_id].output_base_rgn2 = (u64)temp_smmu_mpu_regs.output_base<<12;
		smmu_mpu_info_array[stream_id].output_size_rgn2 = (u64)temp_smmu_mpu_regs.output_size<<12;
	}
	VASTAI_PCI_INFO(priv, priv->pkg_id,"-----start to dump valid smmu mpu info-----\n");

	for(stream_id=0;stream_id<32;stream_id++){
		if((0==smmu_mpu_info_array[stream_id].input_base_ddr) && (0==smmu_mpu_info_array[stream_id].output_base_ddr)) {
			continue;
		}
		VASTAI_PCI_INFO(priv, priv->pkg_id,"stream_id[%02d] rgn0 fn_addr[0x%010llx ~ 0x%010llx] map to noc [0x%010llx ~ 0x%010llx] size=[0x%010llx=%06lldMB]\n",
						stream_id,smmu_mpu_info_array[stream_id].input_base_ddr,
						smmu_mpu_info_array[stream_id].input_base_ddr+smmu_mpu_info_array[stream_id].output_size_ddr-1,
						smmu_mpu_info_array[stream_id].output_base_ddr,
						smmu_mpu_info_array[stream_id].output_base_ddr+smmu_mpu_info_array[stream_id].output_size_ddr-1,
						smmu_mpu_info_array[stream_id].output_size_ddr,
						smmu_mpu_info_array[stream_id].output_size_ddr/1024/1024);
	}

	for(stream_id=0;stream_id<32;stream_id++) {
		if((0==smmu_mpu_info_array[stream_id].output_base_csram) && (0==smmu_mpu_info_array[stream_id].input_base_csram)) {
			continue;
		}
		VASTAI_PCI_INFO(priv, priv->pkg_id,"stream_id[%02d] rgn1 fn_addr[0x%010llx ~ 0x%010llx] map to noc [0x%010llx ~ 0x%010llx] size=[0x%010llx=%06lldKB]\n",
			stream_id,smmu_mpu_info_array[stream_id].input_base_csram,
			smmu_mpu_info_array[stream_id].input_base_csram+smmu_mpu_info_array[stream_id].output_size_csram-1,
			smmu_mpu_info_array[stream_id].output_base_csram,
			smmu_mpu_info_array[stream_id].output_base_csram+smmu_mpu_info_array[stream_id].output_size_csram-1,
			smmu_mpu_info_array[stream_id].output_size_csram,
			smmu_mpu_info_array[stream_id].output_size_csram/1024);
	}

	for(stream_id=0;stream_id<32;stream_id++) {
		if((0==smmu_mpu_info_array[stream_id].output_base_rgn2) && (0==smmu_mpu_info_array[stream_id].input_base_rgn2)) {
			continue;
		}
	VASTAI_PCI_INFO(priv, priv->pkg_id,"stream_id[%02d] rgn2 fn_addr[0x%010llx ~ 0x%010llx] map to noc [0x%010llx ~ 0x%10llx] size=[0x%010llx=%06lldMB]\n",
			stream_id,smmu_mpu_info_array[stream_id].input_base_rgn2,
			smmu_mpu_info_array[stream_id].input_base_rgn2+smmu_mpu_info_array[stream_id].output_size_rgn2-1,
			smmu_mpu_info_array[stream_id].output_base_rgn2,
			smmu_mpu_info_array[stream_id].output_base_rgn2+smmu_mpu_info_array[stream_id].output_size_rgn2-1,
			smmu_mpu_info_array[stream_id].output_size_rgn2,
			smmu_mpu_info_array[stream_id].output_size_rgn2/1024/1024);
	}

	kfree(smmu_mpu_info_array);
	return;
}

static void gfx_mpu_cfg(struct vastai_pci_info *priv)
{
	u32 osid = 0;
	u32 region_num = 0;
	u32 gfx_mpu_reg_base = 0;
	struct gfx_mpu_info *gfx_mpu_info_array;
	struct gfx_mpu_regs temp_gfx_mpu_regs;
	int ret;
	gfx_mpu_info_array = kzalloc(sizeof(struct gfx_mpu_info) * 32, GFP_KERNEL);
	for(osid = 0; osid < 32; osid++){
		gfx_mpu_reg_base = 0xaf8000 + osid/8 * 0x2000 + 0x300 + 4 + (osid%8*12*4);
		ret = vastai_read_by_smcu(priv,  gfx_mpu_reg_base, sizeof(struct gfx_mpu_regs) ,&temp_gfx_mpu_regs);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s region_num = 0x%x, len=%ld, error:%d\n",
				       __func__, region_num, sizeof(temp_gfx_mpu_regs), ret);
			continue;
		}

		gfx_mpu_info_array[osid].input_base_tgt0  = (u64)temp_gfx_mpu_regs.tgt0_inputH_base<<32|temp_gfx_mpu_regs.tgt0_inputL_base;
		gfx_mpu_info_array[osid].output_size_tgt0 = (u64)temp_gfx_mpu_regs.tgt0_output_size<<12;
		gfx_mpu_info_array[osid].output_base_tgt0 = (u64)temp_gfx_mpu_regs.tgt0_output_base<<12;

		gfx_mpu_info_array[osid].input_base_tgt1  = (u64)temp_gfx_mpu_regs.tgt1_inputH_base<<32|temp_gfx_mpu_regs.tgt1_inputL_base;
		gfx_mpu_info_array[osid].output_size_tgt1 = (u64)temp_gfx_mpu_regs.tgt1_output_size<<12;
		gfx_mpu_info_array[osid].output_base_tgt1 = (u64)temp_gfx_mpu_regs.tgt1_output_base<<12;

		gfx_mpu_info_array[osid].input_base_tgt2  = (u64)temp_gfx_mpu_regs.tgt2_inputH_base<<32|temp_gfx_mpu_regs.tgt2_inputL_base;
		gfx_mpu_info_array[osid].output_size_tgt2 = (u64)temp_gfx_mpu_regs.tgt2_output_size<<12;
		gfx_mpu_info_array[osid].output_base_tgt2 = (u64)temp_gfx_mpu_regs.tgt2_output_base<<12;
	}

	VASTAI_PCI_INFO(priv, priv->pkg_id,"-----start to dump valid gfx mpu info-----\n");
	for(osid = 0; osid < 32; osid++){
		if(0==gfx_mpu_info_array[osid].output_size_tgt0) {
			continue;
		}

		VASTAI_PCI_INFO(priv, priv->pkg_id,"[GPU%d] osid[%d] rgn[0] fn_addr[0x%010llx ~ 0x%010llx] map to noc[0x%010llx ~ 0x%010llx] size=[0x%010llx=%06lldMB]\n",
					osid/8, osid % 8,gfx_mpu_info_array[osid].input_base_tgt0,
					gfx_mpu_info_array[osid].input_base_tgt0+gfx_mpu_info_array[osid].output_size_tgt0-1,
					gfx_mpu_info_array[osid].output_base_tgt0,
					gfx_mpu_info_array[osid].output_base_tgt0+gfx_mpu_info_array[osid].output_size_tgt0-1,
					gfx_mpu_info_array[osid].output_size_tgt0,
					gfx_mpu_info_array[osid].output_size_tgt0/1024/1024);
	}

	for(osid = 0; osid < 32; osid++){
		if(0==gfx_mpu_info_array[osid].output_size_tgt1) {
			continue;
		}

		VASTAI_PCI_INFO(priv, priv->pkg_id,"[GPU%d] osid[%d] rgn[1] fn_addr[0x%010llx ~ 0x%010llx] map to noc[0x%010llx ~ 0x%010llx] size=[0x%010llx=%06lldMB]\n",
						osid/8, osid % 8,gfx_mpu_info_array[osid].input_base_tgt1,
						gfx_mpu_info_array[osid].input_base_tgt1+gfx_mpu_info_array[osid].output_size_tgt1-1,
						gfx_mpu_info_array[osid].output_base_tgt1,
						gfx_mpu_info_array[osid].output_base_tgt1+gfx_mpu_info_array[osid].output_size_tgt1-1,
						gfx_mpu_info_array[osid].output_size_tgt1,
						gfx_mpu_info_array[osid].output_size_tgt1/1024/1024);
	}

	for(osid = 0; osid < 32; osid++){
		if(0==gfx_mpu_info_array[osid].output_size_tgt2) {
			continue;
		}

		VASTAI_PCI_INFO(priv, priv->pkg_id,"[GPU%d] osid[%d] rgn[2] fn_addr[0x%010llx ~ 0x%010llx] map to noc[0x%010llx ~ 0x%010llx] size=[0x%010llx=%06lldMB]\n",
					osid/8, osid % 8,gfx_mpu_info_array[osid].input_base_tgt2,
					gfx_mpu_info_array[osid].input_base_tgt2+gfx_mpu_info_array[osid].output_size_tgt2-1,
					gfx_mpu_info_array[osid].output_base_tgt2,
					gfx_mpu_info_array[osid].output_base_tgt2+gfx_mpu_info_array[osid].output_size_tgt2-1,
					gfx_mpu_info_array[osid].output_size_tgt2,
					gfx_mpu_info_array[osid].output_size_tgt2/1024/1024);
	}

	kfree(gfx_mpu_info_array);
	return;
}

int vastai_pci_malloc_udma_buf(struct vastai_pci_info *pcie_dev,
			       struct vastai_dma_buf *dm, u32 len)
{
	int ret;

	if (dm->vir || dm->dma_bus_addr) {
		if (dm->size >= len) {
			VASTAI_PCI_INFO(pcie_dev, DUMMY_DIE_ID,
					"%s not malloc again! "
					"dm_dma_bus_addr:0x%lx\n",
					__func__, dm->dma_bus_addr);
			return 0;
		} else
			vastai_udma_free(pcie_dev, dm);
	}
	ret = vastai_udma_malloc(pcie_dev, dm, len);
	if (ret != 0)
		return ret;
	memset((unsigned char *)(dm->vir), VASTAI_UDMA_TEST_VAL, len);
	VASTAI_PCI_DBG(pcie_dev, DUMMY_DIE_ID, "%s dm_phy:0x%lx\n", __func__,
		       dm->dma_bus_addr);
	return 0;
}

void vastai_pci_set_udma_buf(struct vastai_dma_buf *dm, int val)
{
	if (!dm->vir || !dm->dma_bus_addr || !dm->size) {
		VASTAI_PCI_INFO(
			NULL, DUMMY_DIE_ID,
			"%s please malloc first! dm_dma_bus_addr:0x%lx\n",
			__func__, dm->dma_bus_addr);
		return;
	}
	memset((unsigned char *)(dm->vir), val, dm->size);
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "dma buf: ", DUMP_PREFIX_NONE, 32, 4,
			    (void *)(dm->vir),
			    ((dm->size > VASTAI_UDMA_TEST_LEN) ?
				     VASTAI_UDMA_TEST_LEN :
				     dm->size),
			    true);
}

void vastai_pci_print_udma_buf(struct vastai_dma_buf *dm)
{
	if (!dm->vir || !dm->dma_bus_addr || !dm->size) {
		VASTAI_PCI_INFO(
			NULL, DUMMY_DIE_ID,
			"%s please malloc first! dm_dma_bus_addr:0x%lx\n",
			__func__, dm->dma_bus_addr);
		return;
	}
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "dma buf: ", DUMP_PREFIX_NONE, 32, 4,
			    (void *)(dm->vir),
			    ((dm->size > VASTAI_UDMA_TEST_LEN) ?
				     VASTAI_UDMA_TEST_LEN :
				     dm->size),
			    true);
}

int vastai_pci_free_udma_buf(struct vastai_pci_info *pcie_dev,
			     struct vastai_dma_buf *dm)
{
	if (!dm->vir || !dm->dma_bus_addr || !dm->size) {
		VASTAI_PCI_INFO(
			pcie_dev, DUMMY_DIE_ID,
			"%s no malloc, no free! dm_dma_bus_addr:0x%lx\n",
			__func__, dm->dma_bus_addr);
		return 0;
	}
	return vastai_udma_free(pcie_dev, dm);
}

/* TC21: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer to SRAM, as inbound transfer
 * 		(from remote memory to local memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc21(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_IN, 0x1,
					0x840000000, dmb[0].dma_bus_addr);
	vastai_pci_free_udma_buf(priv, &dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC22: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from SRAM, as outbound transfer
 * 		(from local memory to remote memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc22(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_OUT,
					0x100, 0x840000000,
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC23: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer to SRAM, as inbound transfer
 * 		(from remote memory to local memory), specified length.
 * param in len The length of transfer in bytes.
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc23(struct vastai_pci_info *priv, u32 len)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], len);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_IN, len,
					VASTAI_CSRAM_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	return VASTAI_TEST_PASS;
}

/* TC24: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from SRAM, as outbound transfer
 * 		(from local memory to remote memory), specified length.
 * param in len The length of transfer in bytes.
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc24(struct vastai_pci_info *priv, u32 len)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], len);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_OUT, len,
					VASTAI_CSRAM_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC25: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer to DDR, as inbound transfer
 * 		(from remote memory to local memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc25(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_IN, 0x100,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	return VASTAI_TEST_PASS;
}

/* TC26: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from DDR, as outbound transfer
 * 		(from local memory to remote memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc26(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_OUT,
					0x100,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC27: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer to DDR, as inbound transfer
 * 		(from remote memory to local memory), 0x1000000 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc27(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_MALLOC_MAX);
	vastai_pci_malloc_udma_buf(priv, &dmb[1], VASTAI_UDMA_MALLOC_MAX);
	vastai_pci_malloc_udma_buf(priv, &dmb[2], VASTAI_UDMA_MALLOC_MAX);
	vastai_pci_malloc_udma_buf(priv, &dmb[3], VASTAI_UDMA_MALLOC_MAX);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_IN,
					VASTAI_UDMA_LENGTH_MAX,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE0),
					dmb[3].dma_bus_addr);
	return VASTAI_TEST_PASS;
}

/* TC28: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from DDR, as outbound transfer
 * 		(from local memory to remote memory), 0x1000000 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc28(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_LENGTH_MAX);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_OUT,
					VASTAI_UDMA_LENGTH_MAX,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC30: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from DDR, as ioutbound transfer
 * 		(from local memory to remote memory), specified length.
 * param in len The length of transfer in bytes.
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc30(struct vastai_pci_info *priv, u32 len)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], len);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE0, VASTAI_DIR_OUT, len,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE0),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC52: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from SRAM, as outbound transfer
 * 		(from local memory to remote memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc52(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE1, VASTAI_DIR_OUT,
					0x100, VASTAI_CSRAM_ADDR(VASTAI_DIE1),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC53: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer to DDR, as inbound transfer
 * 		(from remote memory to local memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc53(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE1, VASTAI_DIR_IN, 0x100,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE1),
					dmb[0].dma_bus_addr);
	return VASTAI_TEST_PASS;
}

/* TC54: udma test via pcie driver
 * keyword: udma, bulk
 * description: Perform a DMA bulk transfer from DDR, as outbound transfer
 * 		(from local memory to remote memory), 0x100 bytes length.
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc54(struct vastai_pci_info *priv)
{
	vastai_pci_malloc_udma_buf(priv, &dmb[0], VASTAI_UDMA_TEST_LEN);
	vastai_udma_start_bulk_transfer(priv, VASTAI_DIE1, VASTAI_DIR_OUT,
					0x100,
					VASTAI_DDR_SPACE_ADDR(VASTAI_DIE1),
					dmb[0].dma_bus_addr);
	vastai_pci_print_udma_buf(&dmb[0]);
	return VASTAI_TEST_PASS;
}

/* TC101: reset test via pcie driver
 * keyword: reset
 * description: Perform a reset
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc101(struct vastai_pci_info *priv)
{
	vastai_pci_reset_bus(priv);
	vastai_pci_tc22(priv);
	return VASTAI_TEST_PASS;
}

/* TC102: reset when UDMA transfer test via pcie driver
 * keyword: reset
 * description: Perform a reset
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
u8 vastai_test_udma_reset_flag;
static int vastai_pci_tc102(struct vastai_pci_info *priv)
{
	vastai_test_udma_reset_flag = 1;
	vastai_pci_tc22(priv);
	vastai_test_udma_reset_flag = 0;
	vastai_pci_tc22(priv);
	return VASTAI_TEST_PASS;
}

/* TC103: reset test via pcie driver
 * keyword: reset
 * description: Perform a reset
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
static int vastai_pci_tc103(struct vastai_pci_info *priv)
{
	vastai_pci_reset_bus(priv);
	vastai_pci_tc52(priv);
	return VASTAI_TEST_PASS;
}

/* TC104: reset when UDMA transfer test via pcie driver
 * keyword: reset
 * description: Perform a reset
 * param in NA
 * return VASTAI_TEST_PASS if the function completed successfully.
 * return VASTAI_TEST_FAILURE if the function performed error.
 */
u8 vastai_test_udma_reset_flag;
static int vastai_pci_tc104(struct vastai_pci_info *priv)
{
	vastai_test_udma_reset_flag = 1;
	vastai_pci_tc52(priv);
	vastai_test_udma_reset_flag = 0;
	vastai_pci_tc52(priv);
	return VASTAI_TEST_PASS;
}

/* Host to fw dma sync unit test with src is virtual buf */
static int vastai_pci_tc155(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[0].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */

	desc[0].dev_addr = 0x840000000;
	desc[0].is_src_dma_addr = 0;
	desc[0].is_src_not_user_mem = 1;
	desc[0].host_addr.vir_addr = vmalloc(0x100);
	desc[0].is_host_to_dev = 1;
	desc[0].dma_lenth = 0x100;
	memset(desc[0].host_addr.vir_addr, '1', 0x100);

	desc[1].dev_addr = 0x840000100;
	desc[1].is_src_dma_addr = 0;
	desc[1].is_src_not_user_mem = 1;
	desc[1].host_addr.vir_addr = vmalloc(0x100);
	desc[1].is_host_to_dev = 1;
	desc[1].dma_lenth = 0x100;
	memset(desc[1].host_addr.vir_addr, '2', 0x100);

	core_id.decode = 0x1;
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, 2, -1);
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "host buf: ", DUMP_PREFIX_NONE, 32, 4,
			    desc[0].host_addr.vir_addr, 0x100, true);
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "host buf: ", DUMP_PREFIX_NONE, 32, 4,
			    desc[1].host_addr.vir_addr, 0x100, true);

	vfree(desc[0].host_addr.vir_addr);
	vfree(desc[1].host_addr.vir_addr);
	return VASTAI_TEST_PASS;
}

/* Fw to Host dma sync unit test with src is virtual buf */
static int vastai_pci_tc156(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[0].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */

	desc[0].dev_addr = 0x840000000;
	desc[0].is_src_dma_addr = 0;
	desc[0].is_src_not_user_mem = 1;
	desc[0].host_addr.vir_addr = vmalloc(0x100);
	desc[0].is_host_to_dev = 0;
	desc[0].dma_lenth = 0x100;

	desc[1].dev_addr = 0x840000100;
	desc[1].is_src_dma_addr = 0;
	desc[1].is_src_not_user_mem = 1;
	desc[1].host_addr.vir_addr = vmalloc(0x100);
	desc[1].is_host_to_dev = 0;
	desc[1].dma_lenth = 0x100;

	core_id.decode = 0x1;
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, 2, -1);
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "host buf: ", DUMP_PREFIX_NONE, 32, 4,
			    desc[0].host_addr.vir_addr, 0x100, true);
	VASTAI_PCI_HEX_DUMP(KERN_INFO, "host buf: ", DUMP_PREFIX_NONE, 32, 4,
			    desc[1].host_addr.vir_addr, 0x100, true);
	vfree(desc[0].host_addr.vir_addr);
	vfree(desc[1].host_addr.vir_addr);
	return VASTAI_TEST_PASS;
}

/* Host to fw dma sync , long length */
/* test Die 0 */
static int vastai_pci_tc157(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[0].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */
	struct vastai_dma_buf dm[2];
	int i;
	u32 desc_cnt = (get_random_u32() % 2) + 1;
	u32 offset = 0;
	u32 is_host_to_dev = get_random_u32() % 2;

	for (i = 0; i < desc_cnt; i++) {
		u32 test_len = (get_random_u32() % 0x200000) + 900000;
		desc[i].dev_addr = ALIGN(0x840000000 + offset, 0x1000);
		desc[i].is_src_dma_addr = 1;
		desc[i].is_src_not_user_mem = 1;
		vastai_udma_malloc(priv, &dm[i], test_len);
		desc[i].host_addr.dma_addr = dm[i].dma_bus_addr;
		desc[i].host_addr.vir_addr = dm[i].vir;
		desc[i].is_host_to_dev = is_host_to_dev;
		desc[i].dma_lenth = test_len;
		memset(desc[i].host_addr.vir_addr, '2', test_len);
		offset += test_len;
	}

	core_id.decode = 0x1;
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, desc_cnt, -1);

	for (i = 0; i < desc_cnt; i++) {
		vastai_udma_free(priv, &dm[i]);
	}
	return VASTAI_TEST_PASS;
}

static int vastai_pci_tc158(struct vastai_pci_info *priv)
{
	union core_bitmap core_id = { .vdsp = BIT(0) };
	int i = 0;
	static int index = 0;

	for (i = 0; i < 10; i++) {
		u32 msg_buf = 0x80000000 + index;
		index += 1;
		vastai_pci_send_msg_sv(priv, 0, core_id, &msg_buf,
				    sizeof(msg_buf));
	}
	return 0;
}

/* test Die 1 */
static int vastai_pci_tc159(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[1].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */
	struct vastai_dma_buf dm[2];
	int i;
	u32 desc_cnt = (get_random_u32() % 2) + 1;
	u32 offset = 0;
	u32 is_host_to_dev = get_random_u32() % 2;

	for (i = 0; i < desc_cnt; i++) {
		u32 test_len = (get_random_u32() % 0x200000) + 900000;
		desc[i].dev_addr = ALIGN(0x840000000 + offset, 0x1000);
		desc[i].is_src_dma_addr = 1;
		desc[i].is_src_not_user_mem = 1;
		vastai_udma_malloc(priv, &dm[i], test_len);
		desc[i].host_addr.dma_addr = dm[i].dma_bus_addr;
		desc[i].host_addr.vir_addr = dm[i].vir;
		desc[i].is_host_to_dev = is_host_to_dev;
		desc[i].dma_lenth = test_len;
		memset(desc[i].host_addr.vir_addr, '2', test_len);
		offset += test_len;
	}

	core_id.decode = 0x1;
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, desc_cnt, -1);

	for (i = 0; i < desc_cnt; i++) {
		vastai_udma_free(priv, &dm[i]);
	}
	return VASTAI_TEST_PASS;
}

/*
   1. send buf to die0.
   2. move buf from die0 to die1
   3. recv buf from die1
   4. check buf
   */
static int vastai_pci_tc160(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[0].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */
	int i;

	desc[0].dev_addr = 0x840000000;
	desc[0].is_src_dma_addr = 0;
	desc[0].is_src_not_user_mem = 1;
	desc[0].host_addr.vir_addr = vmalloc(0x100);
	desc[0].is_host_to_dev = 1;
	desc[0].dma_lenth = 0x100;

	memset(desc[0].host_addr.vir_addr, 'a', 0x100);
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, 1, -1);

	vastai_pci_data_movement(priv, die_index, 0x840000000, 0x840000000,
				 0x100, 1);

	die_index = priv->dies[1].die_index;
	desc[1].dev_addr = 0x840000000;
	desc[1].is_src_dma_addr = 0;
	desc[1].is_src_not_user_mem = 1;
	desc[1].host_addr.vir_addr = vmalloc(0x100);
	desc[1].is_host_to_dev = 0;
	desc[1].dma_lenth = 0x100;

	vastai_pci_dma_transfer_sync(priv, die_index, core_id, &(desc[1]), 1, -1);

	for (i = 0; i < 0x100; i++) {
		if (((char *)desc[1].host_addr.vir_addr)[i] !=
		    ((char *)desc[0].host_addr.vir_addr)[i])
			printk("%s check error\n", __FUNCTION__);
	}

	return VASTAI_TEST_PASS;
}

/*
   1. send buf to die0.
   2. move buf from die1 to die0
   3. recv buf from die0
   4. check buf
   */
static int vastai_pci_tc161(struct vastai_pci_info *priv)
{
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[1].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */
	int i;

	desc[0].dev_addr = 0x840000000;
	desc[0].is_src_dma_addr = 0;
	desc[0].is_src_not_user_mem = 1;
	desc[0].host_addr.vir_addr = vmalloc(0x100);
	desc[0].is_host_to_dev = 1;
	desc[0].dma_lenth = 0x100;

	memset(desc[0].host_addr.vir_addr, 'a', 0x100);
	vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, 1, -1);

	die_index = priv->dies[0].die_index;
	vastai_pci_data_movement(priv, die_index, 0x840000000, 0x840000000,
				 0x100, 0);

	desc[1].dev_addr = 0x840000000;
	desc[1].is_src_dma_addr = 0;
	desc[1].is_src_not_user_mem = 1;
	desc[1].host_addr.vir_addr = vmalloc(0x100);
	desc[1].is_host_to_dev = 0;
	desc[1].dma_lenth = 0x100;

	vastai_pci_dma_transfer_sync(priv, die_index, core_id, &(desc[1]), 1, -1);

	for (i = 0; i < 0x100; i++) {
		if (((char *)desc[1].host_addr.vir_addr)[i] !=
		    ((char *)desc[0].host_addr.vir_addr)[i])
			printk("%s check error\n", __FUNCTION__);
	}

	return VASTAI_TEST_PASS;
}
int vastai_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
			 u32 core_bit_map, u64 info);
static int vastai_pci_tc162(struct vastai_pci_info *priv)
{
	int ret;
	/* cmcu */
	ret = vastai_send_ctrl_cmd(priv, 0, 0x1 << 12, 0);
	if (ret) {
		printk("ERROR: test failed, errno %d\n", ret);
	} else {
		printk("SUCCESS\n");
	}
	return 0;
}

static int vastai_pci_tc163(struct vastai_pci_info *priv)
{
	int ret;
	/* vdsps */
	ret = vastai_send_ctrl_cmd(priv, 0, 0xf << 8, 0);
	if (ret) {
		printk("ERROR: test failed, errno %d\n", ret);
	} else {
		printk("SUCCESS\n");
	}
	return 0;
}

static int vastai_pci_tc164(struct vastai_pci_info *priv)
{
	int ret;
	/* null */
	ret = vastai_send_ctrl_cmd(priv, 0, 0x0, 0);
	if (ret) {
		printk("ERROR: test failed, errno %d\n", ret);
	} else {
		printk("SUCCESS\n");
	}
	return 0;
}

static int vastai_pci_check_bar2(struct vastai_pci_info *priv)
{
	int ret = 0;
	/* null */
	if(priv->bar[VASTAI_PCI_BAR2].mmio_len==(32*1024*1024))  /*mini bar*/ {
		if(priv->bar[VASTAI_PCI_BAR2].at_addr == 0x814000000)
			return VASTAI_TEST_PASS;
		else {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					"mini bar check_bar2 test failed");
			return VASTAI_TEST_FAILURE;
		}
	}else if(priv->bar[VASTAI_PCI_BAR2].mmio_len==(32*1024UL*1024*1024))  /*big bar*/ {
		if(priv->bar[VASTAI_PCI_BAR2].at_addr == 0x800000000)
			return VASTAI_TEST_PASS;
		else {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					"big bar check_bar2 test failed");
			return VASTAI_TEST_FAILURE;
		}
	}

	return ret;
}

extern u32 VASTAI_BMCU_HEX_TEST_SIZE;
extern const unsigned char vastai_bmcu_hex_buf[];

static int vastai_pci_test_bmcu_download(struct vastai_pci_info *priv)
{
	int ret = 0;
	int die_id = 0;
	int i;
	void *bmcu_rdata,*bmcu_wdata;
	u32 size = VASTAI_BMCU_HEX_TEST_SIZE;
	bmcu_rdata = vmalloc(size);
	bmcu_wdata = vmalloc(size);
	memcpy(bmcu_wdata, vastai_bmcu_hex_buf, size);
	ret = vastai_pci_flash_bmcu(priv, die_id);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "flash_bmcu download failed\n");
		goto FREE;
	}

	ret = vastai_pci_tl_read(priv, die_id, priv->bmcu_dl_addr, bmcu_rdata, size);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "flash_bmcu tl_read failed\n");
		goto FREE;
	}
	for (i = 0; i < size; i++) {
		if (((char *)bmcu_wdata)[i] !=
		    ((char *)bmcu_rdata)[i]) {
		    VASTAI_PCI_ERR(priv, die_id, "test_failed\n");
			vfree(bmcu_wdata);
			vfree(bmcu_rdata);
			return -EIO;
		}
	}
FREE:
	vfree(bmcu_wdata);
	vfree(bmcu_rdata);
	return ret;
}

u32 ai_handle_mock[3][2];
u32 ai_handle_mock_idx = 0;


int g_reset_ai_handle_mock(u32 die_index, u32 core_bit,
						reset_event event)
{
	ai_handle_mock[0][ai_handle_mock_idx] = die_index;
	ai_handle_mock[1][ai_handle_mock_idx] = core_bit;
	ai_handle_mock[2][ai_handle_mock_idx] = event;
	ai_handle_mock_idx++;

	return 0;
}

extern vastai_reset_handle g_reset_ai_handle;

void vastai_pci_test_clear_excep_data(void)
{
	int i,j;

	for(i=0; i<3; i++)
		for(j=0; j<2; j++)
			ai_handle_mock[i][j] = 0;
	ai_handle_mock_idx = 0;
}

int vastai_pci_test_check_excep_data(int die_index, int core_idx)
{
	if((ai_handle_mock[0][RESET_START] == die_index) &&
	   (ai_handle_mock[1][RESET_START] == core_idx) &&
	   (ai_handle_mock[2][RESET_START] == RESET_START) &&
	   (ai_handle_mock[0][RESET_END]   == die_index) &&
	   (ai_handle_mock[1][RESET_END]   == core_idx) &&
	   (ai_handle_mock[2][RESET_END]   == RESET_END) &&
	   (ai_handle_mock_idx == 2))
		return 0;
	else {
		printk("ai_handle_mock[0][0] = 0x%x\n", ai_handle_mock[0][0]);
		printk("ai_handle_mock[1][0] = 0x%x\n", ai_handle_mock[1][0]);
		printk("ai_handle_mock[2][0] = 0x%x\n", ai_handle_mock[2][0]);
		printk("ai_handle_mock[0][1] = 0x%x\n", ai_handle_mock[0][1]);
		printk("ai_handle_mock[1][1] = 0x%x\n", ai_handle_mock[1][1]);
		printk("ai_handle_mock[2][1] = 0x%x\n", ai_handle_mock[2][1]);
		printk("ai_handle_mock_idx = 0x%x\n", ai_handle_mock_idx);
		return -1;
	}
}

int vastai_pci_check_exception(struct vastai_pci_info *priv)
{
	vastai_reset_handle g_reset_ai_handle_bkup = g_reset_ai_handle;
	int val = 0x80000001;
	int ret = 0;
	int cloop = 0;
	int die_id = 0;
	int core_idx[SV100_MAX_VDSP_NUM] = {CORE_POINT_VDSP0, CORE_POINT_VDSP1, CORE_POINT_VDSP2, CORE_POINT_VDSP3};

	for(die_id=0; die_id<priv->die_num_in_fn; die_id++)
		for(cloop=0; cloop<SV100_MAX_VDSP_NUM; cloop++) {
			vastai_pci_test_clear_excep_data();

			g_reset_ai_handle = g_reset_ai_handle_mock;

			ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id),
				priv->dies[die_id].core[core_idx[cloop]].cores_info_ref->interrupt_addr,
				&val, sizeof(val));
			if(ret)
				return ret;

			msleep(500);

			g_reset_ai_handle = g_reset_ai_handle_bkup;
			ret = vastai_pci_test_check_excep_data(vastai_pci_get_die_index(priv, die_id), core_idx[cloop]);
			if(ret)
				return ret;
		}

	return ret;
}
extern void vastai_pci_msg1_exception(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg);
int vastai_pci_check_ai_sys_exception(struct vastai_pci_info *priv)
{
	vastai_reset_handle g_reset_ai_handle_bkup = g_reset_ai_handle;
	struct smcu_to_host_msg1 msg;
	int die_id = 0;
	int ret = 0;

	msg.info[0] = CORE_2_CORE_RESET_AI_SYS_HANG_SUBCMD;

	for(die_id=0; die_id<priv->die_num_in_fn; die_id++) {
		vastai_pci_test_clear_excep_data();
		g_reset_ai_handle = g_reset_ai_handle_mock;

		vastai_pci_msg1_exception(&priv->dies[die_id], &msg);
		msleep(1500);
		g_reset_ai_handle = g_reset_ai_handle_bkup;
		ret = vastai_pci_test_check_excep_data(vastai_pci_get_die_index(priv, die_id), CORE_POINT_CMCU);
		if(ret)
			return ret;
	}

	return 0;
}

extern void vastai_pci_msg1_core_exception(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg);
extern vastai_reset_handle g_reset_video_handle;
int vastai_pci_check_vemcu_exception(struct vastai_pci_info *priv)
{
	int die_id = 0;
	int ret = 0;
	int cloop = 0;
	struct smcu_to_host_msg1 msg;
	vastai_reset_handle g_reset_ai_handle_bkup = g_reset_video_handle;

	for(die_id=0; die_id<priv->die_num_in_fn; die_id++) {
		for(cloop=0; cloop<SV100_MAX_VEMCU_NUM; cloop++) {
			vastai_pci_test_clear_excep_data();
			g_reset_video_handle = g_reset_ai_handle_mock;

			msg.info[0] = CORE_POINT_VEMCU0 + cloop;
			vastai_pci_msg1_core_exception(&priv->dies[die_id], &msg);

			msleep(300);
			g_reset_video_handle = g_reset_ai_handle_bkup;
			ret = vastai_pci_test_check_excep_data(vastai_pci_get_die_index(priv, die_id), msg.info[0]);
			if(ret)
				return ret;
		}
	}

	return 0;
}

int vastai_pci_check_vdmcu_exception(struct vastai_pci_info *priv)
{
	int die_id = 0;
	int ret = 0;
	int cloop = 0;
	struct smcu_to_host_msg1 msg;
	vastai_reset_handle g_reset_ai_handle_bkup = g_reset_video_handle;

	for(die_id=0; die_id<priv->die_num_in_fn; die_id++) {
		for(cloop=0; cloop<SV100_MAX_VDMCU_NUM; cloop++) {
			vastai_pci_test_clear_excep_data();
			g_reset_video_handle = g_reset_ai_handle_mock;

			msg.info[0] = CORE_POINT_VDMCU0 + cloop;
			vastai_pci_msg1_core_exception(&priv->dies[die_id], &msg);

			msleep(300);
			g_reset_video_handle = g_reset_ai_handle_bkup;
			ret = vastai_pci_test_check_excep_data(vastai_pci_get_die_index(priv, die_id), msg.info[0]);
			if(ret)
				return ret;
		}
	}

	return 0;
}

#define GEN4X16_VALUE 32
#define GEN4X8_VALUE 16
#define GEN4X4_VALUE 8
#define GEN3X16_VALUE 16
#define GEN3X8_VALUE 8

bool vastai_pci_compare_pcie_link_in_dies(struct vastai_pci_info *priv){
	u32 i;
	int die_pcie_nl_value[2];
	u32 die_pcie_link_value[2];
	die_pcie_nl_value[VASTAI_DIE0] = ((priv->dies[VASTAI_DIE0].pcie_nls[VASTAI_DIE0])<<8)+(priv->dies[VASTAI_DIE0].pcie_nlw[VASTAI_DIE0]);
	die_pcie_nl_value[VASTAI_DIE1] = ((priv->dies[VASTAI_DIE1].pcie_nls[VASTAI_DIE1])<<8)+(priv->dies[VASTAI_DIE1].pcie_nlw[VASTAI_DIE1]);

	for (i=0;i<2;i++) {
		switch (die_pcie_nl_value[i]) {
		case 0x0410:
			die_pcie_link_value[i] = GEN4X16_VALUE;
			break;
		case 0x0408:
			die_pcie_link_value[i] = GEN4X8_VALUE;
			break;
		case 0x0404:
			die_pcie_link_value[i] = GEN4X4_VALUE;
			break;
		case 0x0310:
			die_pcie_link_value[i] = GEN3X16_VALUE;
			break;
		case 0x0308:
			die_pcie_link_value[i] = GEN3X8_VALUE;
			break;
		default:
			die_pcie_link_value[i] = 0;
			break;
		}
	}

	if (die_pcie_link_value[VASTAI_DIE0] > die_pcie_link_value[VASTAI_DIE1]){
		return true;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"please make sure host<->die0'pcie_link greater than d2d\n");
	return false;
}

int vastai_pci_test_case(struct vastai_pci_info *priv,
				struct char_drv_info *dev, u32 case_no)
{
	int ret = 0;
	u32 len;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"******** VASTAI PCI TEST[%d] start ********\n",
			case_no);
	len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	switch (case_no) {
	case VASTAI_PCI_CHECK_BAR2_AFTER_PROBE:
		ret = vastai_pci_check_bar2(priv);
		break;
	case VASTAI_PCI_CHECK_BMCU_DOWNLOAD:
		ret = vastai_pci_test_bmcu_download(priv);
		break;
#ifdef CONFIG_VASTAI_JENKINS_TEST
	case VASTAI_PCI_CHECK_DMA_DDR_MAX_ADDR:
		ret = vastai_pci_test_dma_by_ddr_boundary_addr(priv);
		break;
#endif
	case VASTAI_PCI_CHECK_EXCEPTION:
		ret = vastai_pci_check_exception(priv);
		break;
	case VASTAI_PCI_CHECK_AI_SYS_EXCEPTION:
		ret = vastai_pci_check_ai_sys_exception(priv);
		break;
	case VASTAI_PCI_CHECK_VEMCU_EXCEPTION:
		ret = vastai_pci_check_vemcu_exception(priv);
		break;
	case VASTAI_PCI_CHECK_VDMCU_EXCEPTION:
		ret = vastai_pci_check_vdmcu_exception(priv);
		break;
	case 21:
		ret = vastai_pci_tc21(priv);
		break;
	case 22:
		ret = vastai_pci_tc22(priv);
		break;
	case 23:
		ret = vastai_pci_tc23(priv, len);
		break;
	case 24:
		ret = vastai_pci_tc24(priv, len);
		break;
	case 25:
		ret = vastai_pci_tc25(priv);
		break;
	case 26:
		ret = vastai_pci_tc26(priv);
		break;
	case 27:
		ret = vastai_pci_tc27(priv);
		break;
	case 28:
		ret = vastai_pci_tc28(priv);
		break;
	case 30:
		ret = vastai_pci_tc30(priv, len);
		break;
	case 52:
		ret = vastai_pci_tc52(priv);
		break;
	case 53:
		ret = vastai_pci_tc53(priv);
		break;
	case 54:
		ret = vastai_pci_tc54(priv);
		break;
	case 101:
		ret = vastai_pci_tc101(priv);
		break;
	case 102:
		ret = vastai_pci_tc102(priv);
		break;
	case 103:
		ret = vastai_pci_tc103(priv);
		break;
	case 104:
		ret = vastai_pci_tc104(priv);
		break;
	case 155:
		ret = vastai_pci_tc155(priv);
		break;
	case 156:
		ret = vastai_pci_tc156(priv);
		break;
	case 157:
		ret = vastai_pci_tc157(priv);
		break;
	case 158:
		ret = vastai_pci_tc158(priv);
		break;
	case 159:
		ret = vastai_pci_tc159(priv);
		break;
	case 160:
		ret = vastai_pci_tc160(priv);
		break;
	case 161:
		ret = vastai_pci_tc161(priv);
		break;
	case 162:
		ret = vastai_pci_tc162(priv);
		break;
	case 163:
		ret = vastai_pci_tc163(priv);
		break;
	case 164:
		ret = vastai_pci_tc164(priv);
		break;
	default:
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "Unsupported test "
			       "case_no = %d\n",
			       case_no);
		break;
	}
	if (ret == VASTAI_TEST_PASS)
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"******** VASTAI PCI TEST[%d] done "
				"********\n",
				case_no);
	else
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "******** VASTAI PCI TEST[%d] fail "
			       "ret = %d ********\n",
			       case_no, ret);
	return ret;
}

static int vastai_pci_cmdline_args(char *cmdline, char *cmd,
				   struct vastai_pci_arg_t *args, int argc)
{
	int status = 0, DONE, FOUND = 0;
	char *end, *argname, *cp;
	unsigned short base;
	unsigned long result, value, val, i, j;

	for (i = 0; i < argc; i++)
		args[i].def = VASTAI_VAL_DW_MASK;

	/* get cmd */
	while (*cmdline == ' ' || *cmdline == '\t')
		cmdline++;

	while (*cmdline != ' ' && *cmdline != '\t' && *cmdline != '\0') {
		*cmd = *cmdline;
		cmd++;
		cmdline++;
	}
	*cmd = '\0';
	if (*cmdline == '\0')
		goto WEDONE;

	*cmdline = '\0';
	cmdline++;
	while (*cmdline == ' ' || *cmdline == '\t')
		cmdline++;

	end = cmdline;
	while (*end == ' ' || *end == '\t')
		end++;

	/*
	 * Parse cmdline
	 */
	DONE = (*end == '\0') ? 1 : 0;
	while (!DONE) {
		/* get the register name */
		while (*end != '=' && *end != '\0')
			end++;
		if (*end == '\0') {
			status = 1;
			goto WEDONE;
		}
		*end = '\0';
		argname = cmdline;
		/* now get value to write to register */
		cmdline = ++end;
		/* if there's whitespace after the '=', exit with an error */
		if (*end == ' ' || *end == '\t' || *end == '\n') {
			status = 1;
			goto WEDONE;
		}
		while (*end != ' ' && *end != '\t' && *end != '\n' &&
		       *end != '\0')
			end++;
		if (*end == '\0')
			DONE = 1;
		else
			*end = '\0';

		if (!strcmp(argname, "file") || !strcmp(argname, "filec")) {
			val = 1;
		} else {
			/* get the base, convert value to base-10 if necessary
			 */
			val = 0;
			result = 0;
			cp = cmdline;
			if (cp[0] == '0' && (cp[1] == 'x' || cp[1] == 'X')) {
				base = 16;
				cp += 2;

			} else {
				base = 10;
			}
			while (isxdigit(*cp)) {
				value = isdigit(*cp) ?
						(*cp - '0') :
						((islower(*cp) ? toupper(*cp) :
								 *cp) -
						 'A' + 10);

				result = result * base + value;
				cp++;
			}

			val = result;
		}

		FOUND = 0;
		/*
		 * verify the register arg is valid, and if the value is not
		 * too big, write it to the corresponding location in arg_vals
		 */
		for (j = 0; j < argc && !FOUND; j++) {
			if (!strcmp(argname, args[j].name)) {
				args[j].def = val;
				FOUND = 1;
			}
		}
		if (!FOUND) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "arg %s err\n",
				       argname);
			status = 0;
			goto WEDONE;
		}

		/*
		 * point cmdline and end to next non-whitespace
		 * (next argument)
		 */
		cmdline = ++end;
		while (*cmdline == ' ' || *cmdline == '\t' || *cmdline == '\n')
			cmdline++;
		end = cmdline;
		/*
		 * if, after skipping whitespace, we hit end of line or EOF,
		 * we're done
		 */
		if (*end == '\0')
			DONE = 1;
	}

WEDONE:
	return status;
}

static int vastai_xspiflash_read(struct vastai_pci_info *priv, u32 die_id,
				unsigned long addr, struct char_drv_info *dev,
				bool print_flag)
{
	int ret = 0;
	int i = 0;
	unsigned char print_str[64];

	ret = vastai_pci_read_xspi(priv, die_id, addr, dev->dm->vir,
			dev->valid_data_length, VASTAI_PCI_FLASH_BL0, false);
	if (ret) {
		return ret;
	}

	if (print_flag == 1) {
		for (i = 0; i < dev->valid_data_length; i += 16) {
			sprintf(print_str,
				"%s [read] 0x%010llx: ", VASTAI_PCI_DEBUG_PREFIX,
				(addr + i + vastai_get_bl0_read_base_addr(priv)));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
					    DUMP_PREFIX_NONE, 16, 4,
					    dev->dm->vir + i, 16, true);
		}
	}
	return 0;
}

int vastai_pci_test_vftest(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_send_msg_to_peer_test(priv, val);

	return 0;
}

/* read configuration space */
int vastai_pci_test_rcfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr;
	int ret = 0;
	int i = 0;
	unsigned char print_str[64];

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s [read config] len=%d bytes\n", __func__,
			dev->valid_data_length);
	if (dev->valid_data_length)
		ret = vastai_pci_config_read(priv, addr, dev->dm->vir,
					     dev->valid_data_length);
	if (!ret) {
		for (i = 0; i < dev->valid_data_length; i += 16) {
			sprintf(print_str,
				"%s config "
				"space "
				"0x%03lx: ",
				VASTAI_PCI_DEBUG_PREFIX, (i + addr));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
					    DUMP_PREFIX_NONE, 16, 4,
					    dev->dm->vir + i, 16, true);
		}
	}

	return ret;
}

int vastai_pci_test_wcfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr, val;
	int ret = 0;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s [write config] addr=0x%lx, "
			"len=%d, val=0x%lx\n",
			__func__, addr, dev->valid_data_length, val);
	if (dev->valid_data_length)
		ret = vastai_pci_config_write(priv, addr, (char *)&val,
					      dev->valid_data_length);
	return ret;
}

/* read reg:
* cmd format e.g. "read addr=0x4a000000 len=100"
*/
int vastai_pci_test_read(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr;
	int ret = 0;
	unsigned char print_str[64];
	u32 i;
	int die_id = 0;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);

	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s read len uses default 4 bytes\n",
				__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		if (dev->valid_data_length == 0xffffffff){
				dev->valid_data_length = 4;
		}else{
				dev->valid_data_length = dev->dm->size;
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
						"%s read len overflow, "
						"change to %d bytes\n",
						__func__, dev->valid_data_length);
		}
	}

	if(vastai_get_board_type(priv)==SV100) {
		die_id = addr >> 36;
		addr = addr & 0xfffffffff;
		ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), addr,
					  dev->dm->vir, dev->valid_data_length);
	}

	if(vastai_get_board_type(priv)==SG100) {
		ret = vastai_pci_mem_read(priv, priv->dies[0].die_index, addr,
					  dev->dm->vir, dev->valid_data_length);
	}

	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s [read] 0x%lx, len=%d, error:%d\n",
			       __func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length,
			       ret);
	else {
		for (i = 0; i < dev->valid_data_length; i += 16) {
			sprintf(print_str, "%s [read] 0x%010lx: ",
				VASTAI_PCI_DEBUG_PREFIX, (addr + ((unsigned long)die_id<<36) + i));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
					    DUMP_PREFIX_NONE, 16, 4,
					    dev->dm->vir + i, 16, true);
		}
	}

	return ret;
}

int vastai_pci_test_read_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr;
	int ret = 0;
	int die_id = 0;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s read len uses default 4 bytes\n",
				__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s read len overflow, "
			       "change to %d bytes\n",
			       __func__, dev->valid_data_length);
	}
	die_id = addr >> 36;
	addr = addr & 0xfffffffff;
	ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), addr,
				  dev->dm->vir, dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s [read] 0x%lx, len=%d, error:%d\n",
			       __func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length,
			       ret);

	return ret;
}

int vastai_pci_get_link_stat(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int len;
	int i;

	len = strlen(VASTAI_GET_PCI_NAME(priv));
	memcpy(dev->dm->vir, VASTAI_GET_PCI_NAME(priv), len);
	memcpy(dev->dm->vir + len, (u32 *)&priv->dies[0].pcie_nlw[0], 8);
	len += 4;
	memcpy(dev->dm->vir + len, (u32 *)&priv->dies[0].pcie_nls[0], 8);
	len += 4;
	dev->valid_data_length = len;

	for (i = 0; i < priv->die_num_in_fn; i++) {
		VASTAI_PCI_INFO(priv, i, "dev%d-die%d(%d/%d) H2D GEN%dx%d, D2D GEN%dx%d, Pkg2Pkg GEN%dx%d\n",
			priv->dev_id, i, i+1, priv->die_num_in_fn,
			priv->dies[i].pcie_nls[0],
			priv->dies[i].pcie_nlw[0],
			priv->dies[i].pcie_nls[1],
			priv->dies[i].pcie_nlw[1],
			priv->dies[i].pcie_nls[2],
			priv->dies[i].pcie_nlw[2]);
	}


	return 0;
}

int vastai_pci_test_get_ddr_attr(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	VASTAI_PCI_INFO(priv,DUMMY_DIE_ID,"priv->ddr_max_addr[0x%llx],priv->ddr_min_addr[0x%llx]\n",priv->ddr_max_addr,priv->ddr_min_addr);

	return 0;
}
/* write reg:
* cmd format e.g. "write addr=0x4a000000 val=0x0 len=100"
*/
int vastai_pci_test_write(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr, val;
	u32 i;
	int ret = 0;
	int die_id = 0;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s write len uses default 4 bytes\n",
				__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s write len overflow, "
			       "change to %d bytes\n",
			       __func__, dev->valid_data_length);
	}
	for (i = 0; i < dev->valid_data_length; i += 4) {
		((char *)dev->dm->vir)[i] = val & 0xFF;
		if ((i + 1) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 1] = (val >> 8) & 0xFF;
		if ((i + 2) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 2] = (val >> 16) & 0xFF;
		if ((i + 3) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 3] = (val >> 24) & 0xFF;
	}

	die_id = addr >> 36;
	addr = addr & 0xfffffffff;
	ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id), addr,
				   dev->dm->vir,
				   dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s [write] 0x%lx, len=%d, error:%d\n",
			       __func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length,
			       ret);
	else
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s [write] addr=0x%lx, "
				"len=%d, val=0x%lx\n",
				__func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length,
				val);

	return ret;
}

int vastai_pci_test_write_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr;
	int ret = 0;
	int die_id = 0;

	unsigned long user_addr;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	user_addr = vastai_pci_args_value(dev->args,
					  VASTAI_PCI_ARG_USER_ADDR);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s write_buf len overflow, "
			       "change to %d bytes\n",
			       __func__, dev->valid_data_length);
	}

	ret = copy_from_user_compact(dev->dm->vir, (char __user *)user_addr,
			     dev->valid_data_length);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s copy_from_user is error\n",
			       __func__);
		return ret;
	}

	die_id = addr >> 36;
	addr = addr & 0xfffffffff;
	ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id), addr,
				   dev->dm->vir,
				   dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"%s [write_buf] 0x%lx, len=%d, error:%d\n",
			__func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length, ret);
	else
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "%s [write_buf] addr=0x%lx, "
			       "len=%d\n",
			       __func__, addr + ((unsigned long)die_id<<36), dev->valid_data_length);

	return ret;
}

int vastai_pci_test_getver(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_pci_show_fw_ver(priv, 0x3FF);

	return 0;
}

int vastai_pci_test_boot(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	return vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);
}

/* reset pcie bus */
int vastai_pci_test_hotreset(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;

	ret = vastai_pci_state_change(priv, VASTAI_NORMAL_STATE, VASTAI_RESET_STATE);
	if (ret)
		return ret;
	vastai_pci_reset_bus(priv);
	ret = vastai_pci_state_change(priv, VASTAI_RESET_STATE, VASTAI_NO_RUN_STATE);

	return ret;
}

/* reset and boot device */
int vastai_pci_test_hotreboot(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/* [mod] gang 2022-5-18
	 * Temp for diags driver:
	 * Some diags cases will hang smcu, then re-initial reset fail.
	 * We need to use hot-reset to reset device.
	 */
	int ret;

	ret = vastai_pci_state_change(priv, VASTAI_NORMAL_STATE, VASTAI_RESET_STATE);
	if (ret)
		return ret;
	vastai_pci_reset_bus(priv);
	ret = vastai_pci_state_change(priv, VASTAI_RESET_STATE, VASTAI_NO_RUN_STATE);
	if (ret)
		return ret;
	vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);

	return ret;
}

/* reset mcu and dsp */
int vastai_pci_test_reset(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/* send msg_irq trigger a re-initial reset. */
	return vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER);
}

/* reset and boot device, re-download ddr bandwidth fw */
int vastai_pci_test_reboot_ddrbw(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/* trigger a re-initial reset and reboot dev . */
	priv->ddr_bw_test = 1;
	vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER |
					  VASTAI_RESET_BOOT_DEV);
	priv->ddr_bw_test = 0;

	return 0;
}

/* reset and boot device */
int vastai_pci_test_reboot(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	/* trigger a re-initial reset and reboot dev . */
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if (val != VASTAI_VAL_DW_MASK && val != priv->vadev.dev_cap) {
		priv->vadev.dev_cap = val;
		vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
				     VASTAI_PCIE_SUB_POWERON, 0);
		msleep(100);
	}

	vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER |
					  VASTAI_RESET_BOOT_DEV);

	return 0;
}

/* power on video module */
int vastai_pci_test_poweron_video(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
					     VASTAI_PCIE_SUB_POWERON, 0);
	msleep(100);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"poweron video finished!\n");

	return 0;
}

int vastai_pci_test_poweroff_video(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
					     VASTAI_PCIE_SUB_POWEROFF, 0);
	msleep(100);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"poweron video finished!\n");

	return 0;
}

int vastai_pci_test_poweron(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
				     VASTAI_PCIE_SUB_POWERON, 0);
	msleep(100);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"poweron video finished!\n");

	return 0;
}

int vastai_pci_test_bmcu_upgrade(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/* 历史遗留代码，已经废弃不用的把fw放在smcu里的升级命令，对齐sg100，让它走新升级路线 */
	return vastai_pci_flash_bmcu(priv, 0);

}

int vastai_pci_test_bmcu_degrade(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret =  vastai_update_start(priv, 0);
	if(ret) return ret;

	vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
					     VASTAI_PCIE_SUB_BMCU_DEGRADE, 0);

	ret = wait_for_completion_timeout(
			&(priv->bmcu_update_comp),
			msecs_to_jiffies(VASTAI_BMCU_UPDATE_MAX_WAIT_TIME));
	reinit_completion(&(priv->bmcu_update_comp));
	if (ret <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"bcmu update timeout:%d ms\n", VASTAI_BMCU_UPDATE_MAX_WAIT_TIME);
		ret = -ETIMEDOUT;
	} else {
		ret = 0;
	}

	vastai_pci_get_fw_ver(priv, 0x4, false);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "degrade BMCU finished!\n");

	vastai_update_done(priv);

	return ret;
}

/* upgrade BMCU by pcie*/
int vastai_pci_test_flashbmcu(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	return vastai_pci_flash_bmcu(priv, 0);
}

/* select pcie generation between host and master die */
int vastai_pci_test_selgen(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_pci_generation_sel(priv, val);

	return 0;
}

/* select pcie generation between die0 and die1 */
int vastai_pci_test_seld0gen(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	return vastai_pci_generation_sel_slave_die(priv, val, VASTAI_DIE0);
}

/* select pcie generation between die1 and die2 */
int vastai_pci_test_seld1gen(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	return vastai_pci_generation_sel_slave_die(priv, val, VASTAI_DIE1);
}

/* select pcie generation between die2 and die3 */
int vastai_pci_test_seld2gen(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	return vastai_pci_generation_sel_slave_die(priv, val, VASTAI_DIE2);
}

int vastai_pci_test_getloglevel(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "current loglevel=[0x%x]\n",
			vastai_pci_log_level);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"(bits correspond to levels in turn: perf, "
			"data, debug, normal)\n");

	return 0;
}

/* set log level, "setloglevel val=xxx" */
int vastai_pci_test_setloglevel(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_pci_log_level = val;
	if (vastai_pci_log_level == 0)
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"current loglevel=[0x%x], printing is closed\n",
			vastai_pci_log_level);
	else
		VASTAI_PCI_INFO(
			priv, DUMMY_DIE_ID,
			"set level=0x%lx, current loglevel=[0x%x]\n",
			val, vastai_pci_log_level);

	return 0;
}

/* set log level, "setvdspdep val=xxx" */
int vastai_pci_test_setvdspdep(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	for (i = 0; i < priv->die_num_in_fn; i++) {
		vastai_pci_set_vdsp_depth(priv, i, val, 1);
	}

	return 0;
}

/* malloc a dma buf for testing */
int vastai_pci_test_mallocbuf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		dev->valid_data_length = VASTAI_UDMA_TEST_LEN;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s malloc default len=%d\n", __func__,
				dev->valid_data_length);
	}
	return vastai_pci_malloc_udma_buf(priv, &dmb[0],
				   dev->valid_data_length);
}

/* set a dma buf for testing */
int vastai_pci_test_setbuf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_pci_set_udma_buf(&dmb[0], val);

	return 0;
}

/* print a dma buf for testing */
int vastai_pci_test_printbuf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_pci_print_udma_buf(&dmb[0]);

	return 0;
}

/* free a dma buf for testing */
int vastai_pci_test_freebuf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	return vastai_pci_free_udma_buf(priv, &dmb[0]);
}

/* flash xspi bootcode, "flashxspi_app val=xxx" */
int vastai_pci_test_flashxspi_app(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;
	char *path_name;
	const char *buf;
	size_t buf_size;

	path_name = BL0_APP_PATH;
	buf = vastai_bl0_app_hex_buf;
	buf_size = VASTAI_BL0_APP_HEX_SIZE;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if ((val >= 0) && (val < priv->die_num_in_fn)) {
		vastai_pci_flash_xspi(priv, val, path_name, buf, buf_size, VASTAI_PCI_FLASH_BL0);
	} else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_pci_flash_xspi(priv, i, path_name, buf, buf_size, VASTAI_PCI_FLASH_BL0);
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);
	}
	vastai_pci_get_fw_ver(priv, 0xC00, false);

	return 0;
}

/* flash xspi bootcode, "flashxspi val=xxx" */
int vastai_pci_test_flashxspi(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;
	char *path_name;
	const char *buf;
	size_t buf_size;

	path_name = BL0_SV_PATH;
	buf = vastai_bl0_hex_buf;
	buf_size = VASTAI_BL0_HEX_SIZE;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if ((val >= 0) && (val < priv->die_num_in_fn)) {
		vastai_pci_flash_xspi(priv, val, path_name, buf, buf_size, VASTAI_PCI_FLASH_BASE);
	} else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_pci_flash_xspi(priv, i, path_name, buf, buf_size, VASTAI_PCI_FLASH_BASE);
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);
	}
	vastai_pci_get_fw_ver(priv, 0xC00, false);

	return 0;
}

/* set flash write protect enable */
int vastai_pci_test_wpen(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if ((val >= 0) && (val < priv->die_num_in_fn)) {
		vastai_pci_set_flash_wp(priv, val, dev, 1);
	} else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_pci_set_flash_wp(priv, i, dev, 1);
	} else
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);

	return 0;
}

/* set flash write protect disable */
int vastai_pci_test_wpdis(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if ((val >= 0) && (val < priv->die_num_in_fn)) {
		vastai_pci_set_flash_wp(priv, val, dev, 0);
	} else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_pci_set_flash_wp(priv, i, dev, 0);
	} else
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);

	return 0;
}

/* read xspi bootcode, "readxspi addr=xxx val=xxx len=xxx" */
int vastai_pci_test_readxspi(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr, val;
	u32 i = 0;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	dev->valid_data_length =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if ((val >= 0) && (val < priv->die_num_in_fn))
		vastai_xspiflash_read(priv, val, addr, dev, 1);
	else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_xspiflash_read(priv, i, addr, dev, 1);
	} else
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);

	return 0;
}

int vastai_pci_test_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	int ret;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	ret = vastai_pci_test_case(priv, dev, val);

	return ret;
}

int vastai_pci_test_cedar_sym(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	u32 i;
	unsigned int reg_val = 0;

	u64 zero = 0;
	dev->valid_data_length = 0;
	for (i = 0; i < priv->die_num_in_fn; i++) {
		ret = vastai_send_pcie_cmd(
			priv, priv->dies[i].die_index,
			VASTAI_PCIE_SUB_CEDAR_SYM_ALG, 0);
		do {
			vastai_pci_mem_read(priv,
					    priv->dies[i].die_index,
					    SLT_TEST_CEDAR_SYM_DONE,
					    &reg_val, 4);
		} while (reg_val != VASTAI_VAL_DW_MASK);
		vastai_pci_mem_read(priv, priv->dies[i].die_index,
				    SLT_TEST_CEDAR_SYM_RES, &reg_val,
				    4);
		if (0x0 == reg_val)
			VASTAI_PCI_INFO(priv, priv->dies[i].die_index,
					"cedar sym slt test pass!\n");
		else
			VASTAI_PCI_ERR(priv, priv->dies[i].die_index,
				       "cedar sym slt test fail!\n");
		memcpy((dev->dm->vir + 4 * i), &reg_val, 4);
		dev->valid_data_length += 4;
		vastai_pci_mem_write(priv, priv->dies[i].die_index,
				     SLT_TEST_CEDAR_SYM_RES, &zero,
				     sizeof(zero));
	}

	return ret;
}

int vastai_pci_test_cedar_asy(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	u32 i;
	unsigned int reg_val = 0;

	u64 zero = 0;
	dev->valid_data_length = 0;
	for (i = 0; i < priv->die_num_in_fn; i++) {
		ret = vastai_send_pcie_cmd(
			priv, priv->dies[i].die_index,
			VASTAI_PCIE_SUB_CEDAR_ASYM_ALG, 0);
		do {
			vastai_pci_mem_read(priv,
					    priv->dies[i].die_index,
					    SLT_TEST_CEDAR_ASY_DONE,
					    &reg_val, 4);
		} while (reg_val != 0xF);
		vastai_pci_mem_read(priv, priv->dies[i].die_index,
				    SLT_TEST_CEDAR_ASY_RES, &reg_val,
				    4);
		if (0x0 == reg_val)
			VASTAI_PCI_INFO(priv, priv->dies[i].die_index,
					"cedar asy slt test pass!\n");
		else
			VASTAI_PCI_ERR(priv, priv->dies[i].die_index,
				       "cedar asy slt test fail!\n");
		memcpy((dev->dm->vir + 4 * i), &reg_val, 4);
		dev->valid_data_length += 4;
		vastai_pci_mem_write(priv, priv->dies[i].die_index,
				     SLT_TEST_CEDAR_ASY_RES, &zero,
				     sizeof(zero));
	}

	return ret;
}

/* cedar svc for customer*/
int vastai_pci_test_cedar_svc(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned int reg_val = 0;

	u64 zero = 0;
	int die_id =
		vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	dev->valid_data_length = 0;
	vastai_pci_mem_write(priv, priv->dies[die_id].die_index,
			     CEDAR_SVC_STS_RES, &zero,
			     sizeof(zero)); //clear sts and done_flag
	ret = vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
				   VASTAI_PCIE_SUB_CEDAR_SVC, 0);
	VASTAI_PCI_INFO(priv, priv->dies[die_id].die_index,
			"cedar svc cmd send to smcu!\n");
	do {
		vastai_pci_mem_read(priv, priv->dies[die_id].die_index,
				    CEDAR_SVC_DONE_FLAG, &reg_val, 4);
	} while (reg_val != 0xFF);
	VASTAI_PCI_INFO(priv, priv->dies[die_id].die_index,
			"cedar svc cmd done!\n");
	vastai_pci_mem_read(priv, priv->dies[die_id].die_index,
			    CEDAR_SVC_STS_RES, &reg_val, 4);
	if (0x0 == reg_val)
		VASTAI_PCI_INFO(priv, priv->dies[die_id].die_index,
				"cedar svc pass!\n");
	else if (0xA5 == reg_val)
		VASTAI_PCI_ERR(priv, priv->dies[die_id].die_index,
			       "cedar svc no entry map!\n");
	else
		VASTAI_PCI_ERR(priv, priv->dies[die_id].die_index,
			       "cedar svc fail!\n");
	memcpy(dev->dm->vir, &reg_val, 4);
	dev->valid_data_length = 4;

	return ret;
}

/**
 * disable smcu heartbeat counter for testing heartbeat
 * 0 - hang timer counter of smcu
 * 1 - hang thread counter of smcu
 */
int vastai_pci_test_hang_smcu(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if (val == 0)
		vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
				     VASTAI_PCIE_SUB_HANG_SMCU, 0);
	else if (val == 1)
		vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
				     VASTAI_PCIE_SUB_HANG_SMCU_THREAD,
				     0);

	return 0;
}

int vastai_pci_test_toggle_dma_callback(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	int i = 0;
	u32 flage = 0;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if (val == 0) {
		flage = VASTAI_PCIE_SUB_CLOSE_DMA_CALLBACK;
	} else {
		flage = VASTAI_PCIE_SUB_OPEN_DMA_CALLBACK;
	}
	for (i = 0; i < priv->die_num_in_fn; i++) {
		vastai_send_pcie_cmd(priv, priv->dies[i].die_index,
				     flage, 0);
	}

	return 0;
}

int vastai_pci_test_iommu(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"iommu is %s\n", iommu_is_enable(priv) ? "enable" :"disable");

	return 0;
}

int vastai_pci_test_core_reset(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 core_id;
	u32 die_id = 0;

	core_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
				VASTAI_PCIE_SUB_CORE_RESET, core_id);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"reset core id %d\n", core_id);

	return 0;
}

int vastai_pci_get_core_log_level(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 reg_val;
	u32 i =0;
	u8 level =0;
	char *log_str[] = {
			"err",
			"warn",
			"info",
			"debug"
	};
	char *core_str[] = {
			"smcu",
			"cmcu",
			"lmcu",
			"odsp",
			"dmcu",
			"emcu",
			"vdsp",
	};

	vastai_pci_mem_read(priv,
		vastai_pci_get_die_index(priv,0),
		CORE_LOG_LEVEL,
		&reg_val, 4);

	for(i=0; i<7;i++)
	{
			level = (reg_val>>(i*4))&0xf;
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
							"%s log level :%s\n", core_str[i],log_str[level]);
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"change log level : set_core_log_level core_point=xx level=xx: \n\
			--POINT: smcu: 0x00000001 |cmcu: 0x00000002|lmcu: 0x000003fc |odsp: 0x0003fc00\
							|vdmcu: 0x001c0000 |vemcu: 0x01e00000 |vdsp:  0x1e000000\n\
			--LEVEL: [err : 0] [ warn: 1] [info: 2] [debug:3]\n");
	return 0;
}

int vastai_pci_set_core_log_level(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 core_point;
	u32 die_id = 0;
	u32 level;
	u32 send_val;

	core_point = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_CORE_POINT);
	level = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LOG_LEVEL);
	send_val = ((core_point&0x1fffffff)|((level&0x7)<<29) );
	vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
							VASTAI_PCIE_SUB_SET_LOG_LEVEL, send_val);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"set core_point= %x log level=%x\n",
							core_point,
							level);
	return 0;
}

int vastai_pci_read_addr(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 die_id = 0;
	u64 addr = 0;

	/*do not support DDR*/
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);

	vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
							VASTAI_PCIE_SUB_READ_ADDR, addr);

	return 0;
}

int vastai_pci_write_addr(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 die_id = 0;
	u64 addr = 0;
	u64 val = 0;

	/*do not support DDR*/
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);

	vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
							VASTAI_PCIE_SUB_WRITE_ADDR, addr + (val<<32));

	return 0;
}

int vastai_pci_test_exp_tri(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 core_id;
	u32 die_id = 0;
	core_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	printk("core_id:%x\n", core_id);
	return vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
				VASTAI_PCIE_SUB_TRI_EXP_TEST, core_id);

}

int vastai_pci_test_switchbbox(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	int ret;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	ret = vastai_bbox_set(priv, (u32)val);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"switchbbox:0x%x\n", (u32)val);

	return ret;
}

int vastai_pci_test_set_state(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"origin state:0x%x\n", (u32)atomic_read(&priv->pci_state));
	atomic_set(&(priv->pci_state), val);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"set_state:0x%x\n", (u32)val);

	return 0;
}

/* read harvest ai core */
int vastai_pci_test_read_harvest(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	u32 i;

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if ((val >= 0) && (val < priv->die_num_in_fn)) {
		/* send upgrade cmd to smcu */
		vastai_send_pcie_cmd(priv, val, VASTAI_PCIE_SUB_GET_DLC_CORE, 0);
	} else if (val == VASTAI_VAL_DW_MASK) {
		for (i = 0; i < priv->die_num_in_fn; i++)
			vastai_send_pcie_cmd(priv, i, VASTAI_PCIE_SUB_GET_DLC_CORE, 0);
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s input error val=0x%lx\n", __func__,
			       val);
	}

	return 0;
}


int vastai_pci_test_show_mempool(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_show_mempool_ex(priv);
	return 0;
}

int vastai_pci_test_re_mempool(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_reset_mempool_ex(priv);
	return 0;
}


int vastai_pci_test_get_max_smi(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long die_id;
	u32 max_smi_h, max_smi_l;

	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);
	ret = vastai_send_pcie_cmd(priv,
				vastai_pci_get_die_index(priv, (u32)die_id),
				VASTAI_PCIE_SUB_GET_MAX_SMI_CNT, 0);
	if (ret) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "send get_max_smi fail ret[%d]\n", ret);
		return ret;
	}

	msleep(1000);
	max_smi_h = priv->dies[die_id].max_smi_h;
	max_smi_l = priv->dies[die_id].max_smi_l;
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "max_smi_cnt[0x%x]\n", (max_smi_h<<16) + max_smi_l);

	return ret;
}

int vastai_pci_p2p(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	struct vastai_dmadesc desc[2];
	int die_index = priv->dies[0].die_index;
	union core_bitmap core_id = { .val = 0 }; /* no core need be tirgger */

	unsigned long addr;
	unsigned long user_addr;
	u32 len;
	u32 dir;
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	user_addr = vastai_pci_args_value(dev->args,
					  VASTAI_PCI_ARG_USER_ADDR);
	len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	dir = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);

	desc[0].dev_addr = addr;
	desc[0].host_addr.dma_addr = user_addr;
	desc[0].is_src_dma_addr = 1;
	desc[0].is_src_not_user_mem = 1;
	desc[0].is_host_to_dev = dir;
	desc[0].dma_lenth = len;

	ret = vastai_pci_dma_transfer_sync(priv, die_index, core_id, desc, 1, -1);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "vastai_pci_p2p err\n");
	}

	return ret;
}

#define DIV_ROUND(x, len)	(((x) + (len)-1) / (len))
#define ROUND_UP(x, align)	DIV_ROUND(x, align) * (align)

int vastai_pci_test_print_smcu_log(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	enum
	{
		LOGSYS_LEVEL_ERR = 0,
		LOGSYS_LEVEL_WARN,
		LOGSYS_LEVEL_INFO,
		LOGSYS_LEVEL_DEBUG,
		LOGSYS_LEVEL_MAX,
	};
	unsigned long die_id = 0;
	u32 line_len = 0;
	u8  logLvL[LOGSYS_LEVEL_MAX][16] = {" err  ", " warn ", " info ", " debug"};
	u8  logsn = 0;
	u32 *timeStamp = 0;
	struct vastai_outbound *pOb = NULL;
	u32 wp = 0;
	u32 rp = 0;
	u8* dma_log_vir = NULL;
	u32 len = 0;

	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);

	if(die_id >= VASTAI_SV100_MAX_DIE_NUM) {
		printk("out of range die_id[%ld]\n", die_id);
		return -1;
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"die_id[%lu]========print start======\n", die_id);

	dma_log_vir = (u8*)priv->dies[0].dma_log_vir + die_id *1024*1024;
	pOb = (struct vastai_outbound *)((u8*)priv->pci_link_stat.dma_vir + die_id*1024);
	wp = pOb->log_wp;
	rp = pOb->log_rp;

	while((rp&0xfffff)!=(wp&0xfffff)) {
		int loglevel_id = (*(dma_log_vir + rp + 2)) & 0xf;
		u32 len_hi = ((u32)*(dma_log_vir + (rp&0xfffff) + 3)) & 0xff;
		len = ((*(dma_log_vir + (rp&0xfffff) + 2)) >> 6) + (len_hi<<2) - 1;
		if(len + (rp%4096) > 4096 ) {
			rp = (rp/4096 + 1)*4096;
		}
		loglevel_id = (*(dma_log_vir + (rp&0xfffff) + 2)) & 0xf;
		logsn = (*(dma_log_vir + (rp&0xfffff) + 1));
		timeStamp = (u32*)(dma_log_vir + (rp&0xfffff)) + 1;
		printk("[%03u][%s] 0x%08x:%s\n", logsn, logLvL[loglevel_id], *timeStamp,
				dma_log_vir + (rp&0xfffff) + 8);
		line_len = strlen(dma_log_vir + (rp&0xfffff) + 8);
		rp = rp + 8 + ROUND_UP(line_len+1, 4);
		pOb->log_rp = rp;
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"die_id[%lu]========print end======\n", die_id);

	return 0;
}


int vastai_ddr_bw_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	int die_id =0;
	unsigned long dma_bus_addr = 0;
	u32 pcie_bw_test_len = 4*1024*1024;

	for (die_id = priv->die_num_in_fn-1; die_id >= 0; die_id--) {
		if (iommu_is_enable(priv)) {

			if (!priv->dies[die_id].test_dm_sg) {
				priv->dies[die_id].test_dm_sg = vastai_dma_buf_sg_get(priv,pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id].test_dm_sg->dma_bus_addr;
			}

		} else {

			if (!priv->dies[die_id].test_dm.vir){
				vastai_udma_malloc(priv, &(priv->dies[die_id].test_dm), pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id].test_dm.dma_bus_addr;
			}
		}

		if(!dma_bus_addr){
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"malloc dma buf failed");
			return -1;
		}

		ret = vastai_send_pcie_cmd(priv,
			vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_SEND_DMA_ADDR, dma_bus_addr);
		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s [send_dma_addr] , error:%d\n",
				__func__, ret);
			return ret;
		}

		ret = vastai_send_pcie_cmd(priv,
			vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_SET_DDR_BW_TEST, 0);
		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [ddr_bw] , error:%d\n",
			__func__, ret);
			return ret;
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"set_ddr_bandwidth_test die{%d]\n",die_id);
	}

	return ret;
}

int vastai_pcie_bw_test(struct char_drv_info *dev, struct vastai_pci_info *priv){
	unsigned long  dma_bus_addr = 0;
	int ret = 0;
	int die_id =0;
	u32 pcie_bw_test_len = 4*1024*1024;
	unsigned long channel_switch = 0;
	u32 dies_num = 1;
	u32 GEN4 = 4;

	if (priv->dies[VASTAI_DIE1].pcie_nlw[1] > 4) {
		channel_switch = 1;
	}

	if (priv->dies[VASTAI_DIE0].pcie_nls[0] == GEN4) {
		dies_num = priv->die_num_in_fn;
	}
	atomic_set(&(priv->pci_state), VASTAI_DEBUG_STATE);
	for (die_id = 0; die_id < dies_num; die_id++) {

		if (iommu_is_enable(priv)) {

			if (!priv->dies[die_id].test_dm_sg) {
				priv->dies[die_id].test_dm_sg = vastai_dma_buf_sg_get(priv,pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id].test_dm_sg->dma_bus_addr;
			}

		} else {

			if (!priv->dies[die_id].test_dm.vir){
				vastai_udma_malloc(priv, &(priv->dies[die_id].test_dm), pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id].test_dm.dma_bus_addr;
			}
		}

		if(!dma_bus_addr){
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"malloc dma buf failed");
			return -1;
		}

		ret = vastai_send_pcie_cmd(priv,
			vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_SEND_DMA_ADDR, dma_bus_addr);

		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s [send_dma_addr] , error:%d\n",
				__func__, ret);
			return ret;
		}

		if (channel_switch && (die_id == 1)) {
			ret = vastai_send_pcie_cmd(priv,
				vastai_pci_get_die_index(priv, die_id),
				VASTAI_PCIE_SUB_SET_PCIE_BW_TEST, channel_switch);
		}else {
			ret = vastai_send_pcie_cmd(priv,
				vastai_pci_get_die_index(priv, die_id),
				VASTAI_PCIE_SUB_SET_PCIE_BW_TEST, 0);
		}

		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s [pcie_bw] , error:%d\n",
				__func__, ret);
			return ret;
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"set_pcie_bandwidth_test,die_id[%d],dma_bus_addr=0x%lx, channel_switch[%ld]\n", die_id, dma_bus_addr, channel_switch);
	}
	return ret;

}


int vastai_stop_mult_bw_test(struct char_drv_info *dev, struct vastai_pci_info *priv){
	int ret = 0;
	int die_id =0;
	for (die_id = priv->die_num_in_fn-1; die_id >=0; die_id--){

		if (iommu_is_enable(priv)) {
			if (priv->dies[die_id].test_dm_sg) {
				vastai_dma_buf_sg_put(priv,priv->dies[die_id].test_dm_sg);
			}

		}else {
			if (priv->dies[die_id].test_dm.vir) {
				vastai_udma_free(priv, &(priv->dies[die_id].test_dm));
			}
		}

		ret = vastai_send_pcie_cmd(priv,
			vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_RESUME_BW_TEST, 0);

		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s [resume_bw] , error:%d\n",
				__func__, ret);
			return ret;
		}

		ret = vastai_send_pcie_cmd(priv,
			vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_STOP_BW_TEST, 0);

		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s [stop_bw] , error:%d\n",
				__func__, ret);
			return ret;
		}
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"set_stop_bandwidth_test\n");

	return ret;
}

int vastai_pci_test_show_hb(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int die_id = 0;
	u32 cnt = 0;
	u32 reg_num = 0;
	u8 print_str[400] = {0};

	for (die_id = priv->die_num_in_fn - 1; die_id >= 0; die_id--) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "die_id %d :\n", die_id);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "tail[%u] head[%u]\n",
		priv->heartbeat.dies[die_id].tail,
		priv->heartbeat.dies[die_id].head);
		for (cnt = 0; cnt < HEARTBEAT_MAX_CNT; cnt++) {
			memset(print_str, 0, sizeof(print_str));
			snprintf(print_str, sizeof(print_str), "%s \n", print_str);
			for (reg_num = 0; reg_num < ADDR(priv, HEARTBEAT_CNT_REG_NUM); reg_num++) {
				snprintf(print_str, sizeof(print_str), "%s 0x%08x", print_str, priv->heartbeat.dies[die_id].last_counts[cnt][reg_num]);
				if (0 == (reg_num + 1) % 10)
					snprintf(print_str, sizeof(print_str), "%s \n", print_str);
			}
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s\n", print_str);
		}
	}

	return 0;
}

extern u64 vatools_get_address_by_index(struct vastai_pci_info *priv,
	AddressEnum index);

u64 vatools_get_address_by_index(struct vastai_pci_info *priv, AddressEnum index){

	vatool_addressArray[ddr_mem_wrtest_addr] = priv->vatool_ddr_mem_wrtest_addr;
	vatool_addressArray[ddr_mem_max_addr] = priv->vatool_ddr_mem_wrtest_addr + priv->vatool_ddr_mem_wrtest_size;
	if (index < vatool_address_count) {
		return vatool_addressArray[index];
	} else {
		return 0;
	}

}

int  vastai_pci_test_get_vatools_addr_by_index(struct char_drv_info *dev, struct vastai_pci_info *priv){
	u32 index;
	u64 get_addr = 0x0;
	for (index = 0; index < vatool_address_count; index++) {
		get_addr = vatools_get_address_by_index(priv, index);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "index = %d, addr = 0x%llx\n", index, get_addr);
	}
	return 0;
}

int vastai_pci_test_cal_dmi_sha256(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_test_cal_dmi_sha256();

	return 0;
}
void vastai_get_interrupt_info(struct vastai_pci_info *priv, int die_id)
{
	int i;
	u32 reg_addr = SMCU_INT_INFO;
	int max_irq_num = 27;
	u32 irq_num[2];
//	printk("irq		in_irq		out_irq\n");
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"irq		in_irq		out_irq\n");

	for (i = 0; i < max_irq_num; i++) {
		vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), reg_addr + i*8,
						  irq_num, 8);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%d		%u		%u\n", i, irq_num[0], irq_num[1]);
	}
}
void vastai_get_smcu_main_loop_info(struct vastai_pci_info *priv, int die_id)
{
	u32 reg_addr = MAIN_WHILE_TIMER;
	u32 reg_val;

	vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), reg_addr, &reg_val, 4);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"max loop cost %u ticks \n", reg_val);
}
void vastai_get_smcu_heartbeat_info(struct vastai_pci_info *priv, int die_id)
{
	u32 reg_addr = HEART_BEAT_CNT;
	u32 reg_val[2];

	vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), reg_addr, reg_val, 8);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"heartbeat	loop:%u	interrupt:%u \n", reg_val[0], reg_val[1]);
}

int vastai_pci_smcu_status(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long die_id = 0;

	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);
	if(die_id >= VASTAI_SV100_MAX_DIE_NUM) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "out of range die_id[%ld]\n", die_id);
		return -1;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"\n smcu status info:");
	vastai_get_interrupt_info(priv, die_id);
	vastai_get_smcu_main_loop_info(priv, die_id);
	vastai_get_smcu_heartbeat_info(priv, die_id);

	return 0;
}

int vastai_pci_test_get_kchar_map(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	dump_pf_vf_map_kchar(priv);

	return 0;
}

int vastai_pci_bdf_info(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	vastai_pci_bdf_info_t bdf_info;
	bdf_info.whole = vastai_get_pci_bdf_info(priv);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
	        "bdf info 0x%llx(%04x:%02x:%02x.%01x)\n", bdf_info.whole,
	        bdf_info.domain_id, bdf_info.bus_id, bdf_info.dev_id, bdf_info.fn_id);
	return 0;
}

int vastai_pci_dev_count(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int count = vastai_get_pci_dev_count();
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
	        "dev count: %d\n", count);
	return 0;
}

extern struct mutex vastai_card_info_list_lock;
extern struct list_head vastai_card_info_list;
int vastai_pci_test_print_tree(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	struct vastai_card_info *card_loop = NULL;
	int card = 0;

	printk("global:");
	mutex_lock(&vastai_card_info_list_lock);
	list_for_each_entry(card_loop, &vastai_card_info_list, card_node) {
		struct vastai_pkg_info *pkg_loop = NULL;
		u8 *card_string = list_is_last(&card_loop->card_node, &vastai_card_info_list) ? " " : "│";
		u8 *curr_card_string = list_is_last(&card_loop->card_node, &vastai_card_info_list) ? "└──" : "├──";

		if(card_loop->board_type == SV100)
			printk("%s card%d SV100\n", curr_card_string, card++);
		if(card_loop->board_type == SG100)
			printk("%s card%d SG100\n", curr_card_string, card++);
		list_for_each_entry(pkg_loop, &card_loop->vastai_pkg_info_list, pkg_node) {
			struct vastai_die_info *die_loop = NULL;
			u8 *pkg_string = list_is_last(&pkg_loop->pkg_node, &card_loop->vastai_pkg_info_list) ? " " : "│";
			u8 *curr_pkg_string = list_is_last(&pkg_loop->pkg_node, &card_loop->vastai_pkg_info_list) ? "└──" : "├──";

			printk("%s   %s pkg%d\n", card_string, curr_pkg_string, pkg_loop->pkg_id);

			list_for_each_entry(die_loop, &pkg_loop->vastai_die_info_list, die_node) {
				struct fn_tree_node    *tree_node_loop = NULL;
				u8 *die_string = list_is_last(&die_loop->die_node, &pkg_loop->vastai_die_info_list) ? " " : "│";
				u8 *curr_die_string = list_is_last(&die_loop->die_node, &pkg_loop->vastai_die_info_list) ? "└──" : "├──";

				printk("%s   %s   %s die%d\n", card_string, pkg_string, curr_die_string, die_loop->die_id_in_card);

				list_for_each_entry(tree_node_loop, &die_loop->vastai_fn_info_list, parent_node) {
					struct vastai_pci_info *fn_loop = tree_node_loop->priv;
					u8 *curr_fn_string = list_is_last(&tree_node_loop->parent_node, &die_loop->vastai_fn_info_list) ? "└──" : "├──";

					printk("%s   %s   %s   %s fn%d\n", card_string, pkg_string, die_string, curr_fn_string, fn_loop->dev->devfn & 0x7);
				}
			}
		}
	}
	mutex_unlock(&vastai_card_info_list_lock);
	return 0;
}


int vastai_set_dma_irq_aggregation(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u32 nr, time_out;

	nr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	time_out= vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);

	vastai_pci_set_dma_irq_agg(priv, nr, time_out);

	return 0;
}

int vastai_pci_die2die_test(struct vastai_pci_info *pci_info, struct kchar_cmd *kcmd){
	int ret = 0;
	u32 local_die = kcmd->dma_die2die_cmd.local_die;
	u32 die_index = pci_info->dies[local_die].die_index;
	u32 len = kcmd->dma_die2die_cmd.len;
	u64 local_addr = kcmd->dma_die2die_cmd.local_address;
	u64 remote_addr = kcmd->dma_die2die_cmd.remote_address;
	u32 is_local_2_remote = kcmd->dma_die2die_cmd.is_local_2_remote;

	local_addr = kcmd->dma_die2die_cmd.local_address;
	remote_addr = kcmd->dma_die2die_cmd.remote_address;


	while (len) {
		u32 current_len =
			len <= VASTAI_MAX_DMA_BUF ? len : VASTAI_MAX_DMA_BUF;

		ret = vastai_pci_data_movement(
			pci_info, die_index, local_addr,
			remote_addr, current_len, is_local_2_remote);
		if (ret){
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,"vastai_pci_data_movement error\n");
			return ret;
		}
		remote_addr += current_len;
		local_addr += current_len;
		len -= current_len;
	}
	return ret;
}

#ifdef CONFIG_VASTAI_RAS
/*
 * die_ie: from 0 ~ 3
 * len:    num of ras events to be read
 *
 */
int vastai_pci_ras_file_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	loff_t fpos = 0;
	unsigned long die_id, num, addr;
	struct vastai_sv100_die* die;
	struct vastai_ras_err_info* ras_err;
	int size, flags;

	die_id = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);
	num = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	flags = 0xFFFFFFFF & vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_CASE);

	fpos = addr;

	if (num <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: ras len error: 0x%lx\n", __func__, num);
	}

	num = (num < MAX_RAS_RECORD) ? num : MAX_RAS_RECORD;
	size = sizeof(struct vastai_ras_err_info) * num;

	ras_err = kmalloc(size, GFP_KERNEL);
	if (!ras_err) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: ras array alloc failed\n", __func__);
	}

	die = &priv->dies[die_id];

	if (flags == VASTAI_RAS_GET_HIST) {
		ret = vastai_ras_read_raw_hist(die, ras_err, num, &fpos);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "sizeof(ras_err): %ld Read ret: (%d elem) fpos: 0x%llx\n",
						sizeof(struct vastai_ras_err_info), ret, fpos);
	} else if (flags == VASTAI_RAS_GET_INSMOD) {
		ret = vastai_ras_read_record_insmod(die, ras_err, num);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "sizeof(ras_err): %ld Read ret: (%d elem)\n",
						sizeof(struct vastai_ras_err_info), ret);
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: ras flags error: 0x%x\n", __func__, flags);
	}

	VASTAI_PCI_HEX_DUMP(KERN_INFO, "host buf: ", DUMP_PREFIX_NONE, 32, 4, ras_err, size, true);
	kfree(ras_err);

	return 0;
}

int vastai_pci_proc_ras_cmd(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	union ras_cmd_data cmd_data = {0};
	unsigned long die, mode, addr, len, value, tc;
	die = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_DIE);
	mode = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	tc = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_CASE);
	value = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);

	cmd_data.type = mode & 0xF;
	if (cmd_data.type == RAS_CMD_READ_XSPI) {
		cmd_data.rw.addr = addr & 0xFFFFFF;
		cmd_data.rw.len = len & 0xFFFFFF;
	} else if (cmd_data.type == RAS_CMD_SWITCH) {
		cmd_data.test.data = value;
	} else if (cmd_data.type == RAS_CMD_TEST) {
		cmd_data.test.component = (tc & 0xF0000) >> 16;
		cmd_data.test.sub_component = (tc & 0x0FF00) >> 8;
		cmd_data.test.reason = (tc & 0xFF);
		cmd_data.test.data = value;
	}

	if ((die >= 0) && (die < priv->die_num_in_fn)) {
		ret = vastai_pci_do_ras_cmd(dev, die, &cmd_data);
	} else if (die == VASTAI_VAL_DW_MASK) {
		for (die = 0; die < priv->die_num_in_fn; die++)
			ret = vastai_pci_do_ras_cmd(dev, die, &cmd_data);
	} else {
		 VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s input error die=0x%lx\n", __func__, die);
		 return -1;
	}

	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: test failed, errno %d\n", __func__, ret);
	} else {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s: test pass\n", __func__);
	}

	return 0;
}
#endif

int vastai_pci_devmem_info(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	int i;
	int num;
	num = vastai_get_share_mem_bank_num(priv);
	for (i = 0; i < num; i++) {
		u64 start, len;
		ret = vastai_get_share_mem_bank_info(priv, i, &start, &len);
		if (ret)
			return ret;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "share bank:%d, start:0x%llx, len:0x%llx\n",
						i, start, len);
	}
	num = vastai_get_model_mem_num(priv);
	for (i = 0; i < num; i++) {
		u64 start, len, offset, entry_addr;
		ret = vastai_get_model_mem_info(priv, i, &start, &len);
		ret |= vastai_get_model_mem_offset(priv, i, &offset);
		ret |= vastai_get_model_entry_addr(priv, i, &entry_addr);
		if (ret)
			return ret;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "model mem:%d, start:0x%llx, len:0x%llx, offset:%llx, entry_addr:%llx\n",
					i, start, len, offset, entry_addr);
	}
	for (i = 0; i < 8; i++) {
		u64 start, len;
		ret = vastai_get_odsp_op_info(priv, i, &start, &len);
		if (ret)
			return ret;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "odsp op mem:%d, start:0x%llx, len:0x%llx,\n",
						i, start, len);
	}

	return 0;
}
typedef int (*cmd_function_t) (struct char_drv_info*, struct vastai_pci_info*);

struct vastai_pci_test_info {
	char* cmd;
	cmd_function_t pFunc;
	//TODO: help cmd for the every cmd to point out how to use it
};


u64 tx_packet = 0;
u64 rx_packet = 0;
u64 tx_payload = 0;
u64 rx_payload = 0;

struct vastai_pci_test_info test_info[] = {
	{"vftest", vastai_pci_test_vftest},
	{"rcfg",   vastai_pci_test_rcfg},
	{"config",   vastai_pci_test_rcfg},
	{"wcfg",   vastai_pci_test_wcfg},
	{"wconfig",   vastai_pci_test_wcfg},
	{"read",   vastai_pci_test_read},
	{"read_buf",   vastai_pci_test_read_buf},
	{"write",   vastai_pci_test_write},
	{"write_buf",   vastai_pci_test_write_buf},
	{"getver",   vastai_pci_test_getver},
#ifdef CONFIG_VASTAI_PCI_BOOT
	{"boot",   vastai_pci_test_boot},
#endif
	{"hotreset",   vastai_pci_test_hotreset},
	{"hotreboot",   vastai_pci_test_hotreboot},
	{"reset",   vastai_pci_test_reset},
	{"reboot_ddrbw",   vastai_pci_test_reboot_ddrbw},
	{"reboot",   vastai_pci_test_reboot},
	{"poweron_video",   vastai_pci_test_poweron_video},
	{"poweroff_video",   vastai_pci_test_poweroff_video},
	{"poweron",   vastai_pci_test_poweron},
	{"bmcu_upgrade",   vastai_pci_test_bmcu_upgrade},
	{"bmcu_degrade",   vastai_pci_test_bmcu_degrade},
	{"flashbmcu",   vastai_pci_test_flashbmcu},
	{"selgen",   vastai_pci_test_selgen},
	{"seld0gen",   vastai_pci_test_seld0gen},
	{"seld1gen",   vastai_pci_test_seld1gen},
	{"seld2gen",   vastai_pci_test_seld2gen},
	{"getloglevel",   vastai_pci_test_getloglevel},
	{"setloglevel",   vastai_pci_test_setloglevel},
	{"setvdspdep",   vastai_pci_test_setvdspdep},
	{"mallocbuf",   vastai_pci_test_mallocbuf},
	{"setbuf",   vastai_pci_test_setbuf},
	{"printbuf",   vastai_pci_test_printbuf},
	{"freebuf",   vastai_pci_test_freebuf},
	{"flashxspi_app",   vastai_pci_test_flashxspi_app},
	{"flashxspi",   vastai_pci_test_flashxspi},
	{"wpen",   vastai_pci_test_wpen},
	{"wpdis",   vastai_pci_test_wpdis},
	{"readxspi",   vastai_pci_test_readxspi},
	{"test",   vastai_pci_test_test},
	{"cedar_sym",   vastai_pci_test_cedar_sym},
	{"cedar_asy",   vastai_pci_test_cedar_asy},
	{"hang_smcu",   vastai_pci_test_hang_smcu},
	{"toggle_dma_callback",   vastai_pci_test_toggle_dma_callback},
	{"iommu",   vastai_pci_test_iommu},
	{"core_reset",   vastai_pci_test_core_reset},
	{"exp_tri",   vastai_pci_test_exp_tri},
	{"switchbbox",   vastai_pci_test_switchbbox},
	{"set_state",   vastai_pci_test_set_state},
	{"harvest", vastai_pci_test_read_harvest},
#ifdef ENABLE_MEMPOOL_EX
	{"show_mempool",   vastai_pci_test_show_mempool},
	{"re_mempool",   vastai_pci_test_re_mempool},
#endif
	{"get_max_smi",  vastai_pci_test_get_max_smi},
	{"get_pcie_status",  vastai_pci_get_link_stat},
	{"set_p2p",  vastai_pci_p2p},
#ifdef CONFIG_VASTAI_SMCU_OB_LOG
	{"print_smcu_log", vastai_pci_test_print_smcu_log},
#endif
	{"ddr_bw", vastai_ddr_bw_test},
	{"pcie_bw", vastai_pcie_bw_test},
	{"stop_bw", vastai_stop_mult_bw_test},
	{"show_hb", vastai_pci_test_show_hb},
	{"dmi_hash", vastai_pci_test_cal_dmi_sha256},
	{"smcu_status", vastai_pci_smcu_status},
	{"get_ddr_attr", vastai_pci_test_get_ddr_attr},
	{"kchar_map",vastai_pci_test_get_kchar_map},
	{"bdf_info", vastai_pci_bdf_info},
	{"dev_count", vastai_pci_dev_count},
	{"print_tree_info", vastai_pci_test_print_tree},
	{"set_dma_agg", vastai_set_dma_irq_aggregation},
#ifdef CONFIG_VASTAI_RAS
	{"ras", vastai_pci_proc_ras_cmd},
	{"ras_read", vastai_pci_ras_file_test},
#endif
	{"get_core_loglevel",vastai_pci_get_core_log_level},
	{"set_core_loglevel",vastai_pci_set_core_log_level},
	{"read_addr", vastai_pci_read_addr},
	{"write_addr",vastai_pci_write_addr},
	{"devmeminfo",vastai_pci_devmem_info},
	{"get_vatools_addr",vastai_pci_test_get_vatools_addr_by_index},
};
extern void va_pcie_dma_tranfer_test(struct vastai_pci_info *priv,
		u8 is_mem_to_dev,
		u64 mem_offset,
		u64 dev_addr,
		u32 len,
		int val);
extern void sdma_reset(struct vastai_pci_info *priv);
extern void va_sdma_op_cp_test(struct vastai_pci_info *priv, u8 loc_dir, u8 mmu_en, u64 addr0, u64 addr1, u32 trans_len, u32 pid);
extern void va_sdma_op_fence_test(struct vastai_pci_info *priv, u8 dir, u8 mmu_en, u64 dev_addr, u32 trans_len, u32 desc_cnt, u64 wr_data);
extern void va_sdma_op_fill_test(struct vastai_pci_info *priv, u8 dir, u8 dst_mmu, u64 dst_addr, u32 trans_len, u64 trans_val);

int va_get_card_info(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	int tmp = 0, tmp2 = 0;
	u8 card_type = 0, ddr_sz = 0;
	u8 ddr_bar_sz = 0;
	char *pstr_ddr_sz = NULL, *pstr_card_type = NULL;

	ret = vastai_pci_mem_read(priv, 0, PWRAP_COMMON77_DDR_CARD, &tmp, 4);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s read PWRAP_COMMON77_DDR_CARD failed, ret:%d\n", __func__, ret);
		return ret;
	}

	ret = vastai_pci_mem_read(priv, 0, PWRAP_COMMON51_DDR_BAR_SZ, &tmp2, 4);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s read PWRAP_COMMON51_DDR_BAR_SZ failed, ret:%d\n", __func__, ret);
		return ret;
	}

	card_type  = (tmp >> BIT_WRAP_COMM77_CARD_TYPE) & 0x3;
	ddr_sz     = (tmp >> BIT_WRAP_COMM77_DDR_MODE)  & 0x3;
	ddr_bar_sz = tmp2 >> BIT_WRAP_COMM51_DDR_BAR_SZ & 0x7;

	if(card_type == 0)
		pstr_card_type = "EVB-DALIANG";
	else if(card_type == 1)
		pstr_card_type = "ANYI-VG1200";
	else
		pstr_card_type = "ZHAOGE-VG1000";

	// total ddr sz on board
	if(ddr_sz == 0) {
		pstr_ddr_sz = "32GB";
	}
	else if(ddr_sz == 1) {
		pstr_ddr_sz = "16GB";
	}
	else if(ddr_sz == 2) {
		pstr_ddr_sz = "8GB";
	}
	else {
		pstr_ddr_sz = "64GB";
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "Card info: %s, %s DDR. ddr_bar_sz_f:%d \n", pstr_card_type, pstr_ddr_sz, ddr_bar_sz);

	return ret;
}

int va_pci_test_modify_csr_bit(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	u32 mode = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	u32 mask_bit = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MASKBIT);
	u64 addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	ret = vastai_pci_modify_reg32(priv,addr,mask_bit,mode);
	if (ret < 0)
	   VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		      "%s [read] 0x%llx, len=%d, error:%d\n",
		      __func__, addr, dev->valid_data_length, ret);
	return ret;
}

int va_pci_test_smcu_modify_csr_bit(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0 ;
	u32 mode = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	u32 mask_bit = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MASKBIT);
	u64 addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	ret = vastai_smcu_modify_reg32(priv,addr,mask_bit,mode);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [read] 0x%llx, len=%d, error:%d\n",
			__func__, addr, dev->valid_data_length, ret);
	return ret;
}
int va_pci_test_rdcfg_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	unsigned long addr = 0;
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"%s read len uses default 4 bytes\n",
		__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, "
			"change to %d bytes\n",
		__func__, dev->valid_data_length);
	}
	ret = vastai_pci_config_read(priv, addr, dev->dm->vir,
		dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [read] 0x%lx, len=%d, error:%d\n",
		__func__, addr, dev->valid_data_length, ret);
	return ret;
}

int va_pci_test_wdcfg_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	unsigned long addr = 0;
	unsigned long user_addr;

	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	user_addr = vastai_pci_args_value(dev->args,VASTAI_PCI_ARG_USER_ADDR);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length > dev->dm->size) {
	   dev->valid_data_length = dev->dm->size;
	   VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		      "%s wrcfg_buf len overflow, "
		      "change to %d bytes\n",
		      __func__, dev->valid_data_length);
	}

	ret = copy_from_user_compact(dev->dm->vir, (char __user *)user_addr,
		      dev->valid_data_length);
	if (ret)
	   VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		      "%s vastai_pci_copy_from_user is error\n", __func__);

	ret = vastai_pci_config_write(priv, addr, (char *)dev->dm->vir,
			     dev->valid_data_length);
	if (ret < 0)
	   VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		      "%s [wrcfg_buf] 0x%lx, len=%d, error:%d\n",
		      __func__, addr, dev->valid_data_length, ret);

	return ret;
}

int va_pci_test_smcu_read_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	unsigned long addr = 0;
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s read len uses default 4 bytes\n",
		__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s read len overflow, "
		"change to %d bytes\n",
		__func__, dev->valid_data_length);
	}
	ret = vastai_read_by_smcu(priv, addr, dev->valid_data_length ,dev->dm->vir);;
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [smcu_read] 0x%lx, len=%d, error:%d\n",
		__func__, addr, dev->valid_data_length, ret);
	return ret;
}

int va_pci_test_smcu_write_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	unsigned long user_addr;
	unsigned long addr = 0;
	unsigned long val;
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	user_addr = vastai_pci_args_value(dev->args,VASTAI_PCI_ARG_USER_ADDR);
	dev->valid_data_length = 4;

	if (dev->valid_data_length > dev->dm->size) {
	dev->valid_data_length = dev->dm->size;
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
	"%s smcu_write_buf len overflow, "
	"change to %d bytes\n",
	__func__, dev->valid_data_length);
	}

	ret = copy_from_user_compact(dev->dm->vir, (char __user *)user_addr,
				dev->valid_data_length);
	if (ret)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s vastai_pci_copy_from_user is error\n", __func__);
	val = *(unsigned long*)dev->dm->vir;
	ret = vastai_write_4byte_by_smcu(priv, addr, val);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [smcu_write_buf] 0x%lx, len=%d, error:%d\n",
		__func__, addr, dev->valid_data_length, ret);

	return ret;
}

int va_pci_test_mmio_read_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long addr = 0;
	int bar_num=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_BAR);
	int offset=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s read len uses default 4 bytes\n",__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, ""change to %d bytes\n",
			__func__, dev->valid_data_length);
	}
	ret = vastai_pci_mmio_read(priv, bar_num, offset, dev->dm->vir, dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [mmio_read_buf] 0x%lx, len=%d, error:%d\n",
		__func__, addr, dev->valid_data_length, ret);

	return ret;
}
int va_pci_test_mmio_write_buf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long user_addr;
	unsigned long val;
	int bar_num=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_BAR);
	int offset=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	user_addr = vastai_pci_args_value(dev->args,VASTAI_PCI_ARG_USER_ADDR);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);

	ret = copy_from_user_compact(dev->dm->vir, (char __user *)user_addr,
			dev->valid_data_length);
	if (ret)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s vastai_pci_copy_from_user is error\n", __func__);

	val = *(unsigned long*)dev->dm->vir;
	ret = vastai_pci_mmio_write(priv, bar_num, offset , dev->dm->vir, dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [smcu_write_buf] 0x%lx, len=%d, error:%d\n",
		__func__, user_addr, dev->valid_data_length, ret);

	return ret;
}

int va_pci_test_get_log(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long addr = 0;
	unsigned long len;
	addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (len <= 0) {
		len = 4096;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"get_log read len uses default 0x%lx bytes\n", len);

	} else if (len > 0x100000) {
		len = 0x100000;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"get_log read len overflow, change to 0x%lx bytes\n", len);
	}
	ret = vastai_get_log(priv, addr, len);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [get_log] 0x%lx, len=%ld\n",
		__func__, addr, len);
	return ret;
}
int va_pci_test_get_fw_ver(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret = 0;
	if (priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		vastai_pci_show_fw_ver(priv, 0x7FFF);
		return ret;
	}else{
		return -1;
	}
}

int va_pci_test_boot(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/*nero todo:The sg100 is a little different from
	 the sv100 in terms of boot function testing*/
	return 0;
}

// FLR: initiate a PCIe function level reset
int va_pci_test_flr(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	return	vastai_pci_flr(priv);
}

int va_pci_test_get_log_level(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"current loglevel=[0x%x]\n",
		vastai_pci_log_level);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"(bits correspond to levels in turn: perf, "
		"data, debug, normal)\n");
	return 0;
}

int va_pci_test_set_log_level(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	vastai_pci_log_level = val;
	if (vastai_pci_log_level == 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"current loglevel=[0x%x], printing is closed\n",
			vastai_pci_log_level);
	else
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"set level=0x%lx, current loglevel=[0x%x]\n",
			val, vastai_pci_log_level);
	return 0;
}
int va_pci_test_set_test_perf(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long val;
	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if (0 == val) {
		test_PCIe_Perf = 0;
		test_smcu_RW_Perf = 0;
	} else {
		test_PCIe_Perf = 1;
		test_smcu_RW_Perf = 1;
	}
	return 0;
}
int va_pci_test_malloclma(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
#ifdef CONFIG_VASTAI_GFX
		/*nero todo :will add alloc_physmem_by_ddk/free_physmem_by_ddk in future*/
		u32 length_lma = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
		uint64_t physlma_addr = 0;
//		IMG_UINT64 physlma_addr = 0;
		if (length_lma <= 0) {
		    length_lma = VASTAI_UDMA_TEST_LEN;
		    VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			    "%s malloclma default len=%d\n", __func__,
			    length_lma);
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			    "%s malloclma len=%d\n", __func__,
			    length_lma);
//		physlma_addr = alloc_physmem_by_ddk(priv, length_lma);
		if (physlma_addr == 0)
		{
		    VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			    "%s malloclma failed len=%d\n", __func__,
			    length_lma);
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			    "%s malloclma addr = 0x%llx len=%d\n", __func__, physlma_addr, length_lma);
//		free_physmem_by_ddk(priv, physlma_addr);
#endif
	return 0;
}

/**
 * cmd format e.g. "dma_test addr=0x4a000000 len=100 val=0x55 offset=0x33 mode=0"
 * addr: dev_addr
 * len: dma transfer size
 * val: byte
 * offset: mem_addr offset based on 4K
 * mode: 0 - d2m; 1 - m2d
 */
int va_pci_test_dma_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long is_mem_to_dev = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	unsigned long mem_offset = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	unsigned long dev_addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	va_pcie_dma_tranfer_test(priv,
			is_mem_to_dev,
			mem_offset,
			dev_addr,
			len,
			val);
	return 0;
}

int va_test_sdma_reset(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	sdma_reset(priv);
	return 0;
}

int va_test_sdma_cp(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u8 dir = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);  // val
	u8 mmu = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MMU);
	u64 addr0 = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR0);
	u64 addr1 = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR1);
	u32 trans_len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	u32 pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
		"%s, dir=%d, mmu_en=%d, addr0:%#llx,addr1:%#llx, trans_len=%#x\n",
		__func__, dir, mmu, addr0, addr1, trans_len);

	va_sdma_op_cp_test(priv, dir, mmu, addr0, addr1, trans_len, pid);

	return 0;
}

int va_test_check_sdma(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	return check_cur_sdma(priv);
}

int va_test_sdma_fence(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long dir = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	unsigned long mmu = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MMU);
	unsigned long dev_addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long trans_len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long desc_cnt = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_CASE);
	unsigned long wr_data = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	va_sdma_op_fence_test(priv, dir, mmu, dev_addr, trans_len, desc_cnt, wr_data);
	return 0;
}

int va_test_sdma_fill(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long dir = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	unsigned long mmu = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MMU);
	unsigned long dst_addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long trans_len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long wr_data = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	va_sdma_op_fill_test(priv, dir, mmu, dst_addr, trans_len, wr_data);
	return 0;
}

int va_test_page_entry(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long dir = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	unsigned long pa = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PA_ADDR);
	unsigned long va = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VA_ADDR);
	unsigned long size = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	u64 start,end;

	ret = va_create_pid(priv, pid);
		start = ktime_get();
	ret = va_create_page_mapping(priv, pa, va, size, pid, (int)dir);
		end = ktime_get();

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
			"create_page time cnt:%06llu(us)\n", (end - start)/1000);
	return ret;
}

int va_test_free_page(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	u64 va = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VA_ADDR);
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	u32 size = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	u64 start,end;

	start = ktime_get();
	ret = va_free_page_maping(priv, va, size, pid);
	end = ktime_get();

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
		"free_page time cnt:%06llu(us)\n", (end - start)/1000);
	return ret;
}

int va_test_get_pa(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u64 va = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VA_ADDR);
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	u64 pa;

	pa = va_virt_to_phys(priv, va, pid);
	if (pa) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
			"The VA[0x%llx] mapping to PA[0x%llx]\n", va, pa);
	}
	return 0;
}

int va_test_get_va(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u64 pa = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PA_ADDR);
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	u64 va;

	va = va_phys_to_virt(priv, pa, pid);
	if (va) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
			"The PA[0x%llx] mapping to VA[0x%llx]\n", pa, va);
	}
	return 0;
}

int va_test_kill_pid(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	return va_kill_pid(priv, pid);
}

int va_test_walk_page(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	//walk_translation_info(priv, pid);
	walk_page_from_dev(priv, pid);
	return 0;
}


int va_test_get_page(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u64 va = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VA_ADDR);
	int pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	return get_page_entry_info(priv, va, pid);

}

int va_test_tlb_flush(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long pid = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PID);
	unsigned long va = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VA_ADDR);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	int ret = 0;
	/* TLB Flush */
	ret = smmu_fill_tlb_invalid_cmd_descriptor(priv, 0x30, pid, 1, va, len);
	if (ret)
	{
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "TLB Flush failed for va[%#lx]\n", va);
	}
	return ret;
}

/**
 * cmd format e.g. "gmcu_cmd mode=0x10 addr=0x920000 val=0x55 len=16"
 * val: sub_cmd
 */
int va_test_gmcu_cmd(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	struct pcie_transfer_cmd trans;
	unsigned long sub_cmd = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	unsigned long addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);

	trans.w0.s_data0.optcode = sub_cmd;
	trans.w0.s_data0.rev0 = len;
	trans.w0.s_data0.rev1 = 0;
	trans.w0.s_data0.rev2 = 0;
	trans.w1.data1 = addr;
	trans.w2.data2 = val;
	trans.w3.data3 = 0;

	if (SMCU_SWITCH_LOG_LEVEL == sub_cmd) {
		trans.w1.data1 = val;
	}

	if ( ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF, &trans, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF, &trans, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF, &trans, 0);
	}

	if (ret) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "push element fail\n");
	}
	return ret;
}

/**
 * cmd format e.g. "vsync_en val=60"
 * val: freq_hz
 */
int va_test_vsync_en(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	ret = va_vsync_timer_enable(priv, val);
	if (ret) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "vsync_en fail\n");
	}
	return ret;
}

/**
 * cmd format e.g. "vsync_dis val=60"
 * val: freq_hz
 */
int va_test_vsync_dis(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	ret = va_vsync_timer_disable(priv);
	if (ret) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "vsync_dis fail\n");
	}
	return ret;
}

int va_test_mmap(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	dump_bar_addr_map(priv);
	return 0;
}

/**
 * cmd format e.g. "hw_cfg" > /dev/kchar:\0
 * val: sub_cmd
 */
int va_test_hw_cfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	dump_current_fn_hw_cfg_info(priv);
	return 0;
}

int va_test_dump_atu(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	dump_atu(priv);
	return 0;
}
int va_test_mpu_cfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	unsigned long mode = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	if (0 == mode) {
		smmu_mpu_cfg(priv);
		gfx_mpu_cfg(priv);
	} else if (1 == mode) {
		smmu_mpu_cfg(priv);
	} else if (2 == mode) {
		gfx_mpu_cfg(priv);
	}
	return 0;
}

int va_test_kchar_map(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	dump_pf_vf_map_kchar(priv);
	return 0;
}

int va_test_ste_info(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;

	ret = device_smmu_ste_table_init(priv);
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"update ste info failed\n");
	}
	return 0;
}

int va_test_cmdq_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	ret = smmu_fill_cfg_invalid_cmd_descriptor(priv, 0x6, 0, 0);
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"cmdq test failed\n");
	}
	return ret;
}

int va_test_check_soc(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	/*nero todo :will add check_soc in future*/
//	check_soc(priv);
	return 0;
}

/**
* cmd format e.g. "smcu_cmd mode=0x10 addr=0x920000 val=0x55 len=16"
* mode: sub_cmd
*/
int va_test_smcu_cmd(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret;
	struct pcie_transfer_cmd trans;
	unsigned long sub_cmd = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_MODE);
	u64 addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	trans.w0.s_data0.optcode    = sub_cmd;
	if (SMCU_CONFIG_ENTRY == sub_cmd) {
		trans.w1.data1 = addr >> 32;
		trans.w2.data2 = addr & 0xFFFFFFFF;
		trans.w3.data3 = len;
	}
	else if (SMCU_SWITCH_LOG_LEVEL == sub_cmd) {
		trans.w1.data1 = val;
	}
	else {
		trans.w0.s_data0.rev0 = len;
		trans.w0.s_data0.rev1 = 0;
		trans.w0.s_data0.rev2 = 0;
		trans.w1.data1 = addr&0XFFFFFFFF;
		trans.w2.data2 = addr>>32;
		trans.w3.data3 = val;
	}

	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"smcu_cmd error\n");
	}
	return 0;
}
/**
* cmd format e.g. "mmio_read bar=0x2 offset=0x0 len=0x100"
* val: sub_cmd
*/
int va_test_mmio_read(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret=0;
	int i;
	int bar_num=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_BAR);
	int offset=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	int len=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned char print_str[64];
	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s read len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len> dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, "
			"change to %d bytes\n",
			__func__, len);
	}
	ret = vastai_pci_mmio_read(priv, bar_num, offset, dev->dm->vir, len);

	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [mmio_read] 0x%x, len=%d, error:%d\n",
			__func__, offset, len, ret);
	}
	else {
		for (i = 0; i < len; i += 16) {
			sprintf(print_str,
			"%s [mmio_read] 0x%010x: ",
			VASTAI_PCI_DEBUG_PREFIX, (offset + i));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
				DUMP_PREFIX_NONE, 16, 4,
				dev->dm->vir + i, 16, true);
		}
	}
	return ret;
}

int va_test_mmio_write(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret=0;
	int bar_num=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_BAR);
	int offset=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	int len=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	int val=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	int i;

	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"%s write len uses default 4 bytes\n",
		__func__);
		len = 4;
	} else if (len > dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s write len overflow, "
			"change to %d bytes\n",
		__func__, len);
	}
	for (i = 0; i < len; i += 4) {
		((char *)dev->dm->vir)[i] = val & 0xFF;
		if ((i + 1) == len)
			break;
		((char *)dev->dm->vir)[i + 1] = (val >> 8) & 0xFF;
		if ((i + 2) == len)
			break;
		((char *)dev->dm->vir)[i + 2] = (val >> 16) & 0xFF;
		if ((i + 3) == len)
			break;
		((char *)dev->dm->vir)[i + 3] = (val >> 24) & 0xFF;
	}
	ret = vastai_pci_mmio_write(priv, bar_num, offset , dev->dm->vir, len);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [mmio_write] 0x%x, len=%d, error:%d\n",
		__func__, offset, len, ret);
	else
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"%s [mmio_write] offset=0x%x, "
		"len=%d, val=0x%xbarx\n",
		__func__, offset, len, val);
	return ret;
}

int va_test_malloc(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	u64 host_buf_pa;
	int i;
	int len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	int val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	if(0 == len) {
		len = 0x100;
	}

	if(0 == val){
		val = 0x12345678;
	}
	g_host_buf_va = kzalloc(len, GFP_KERNEL);
	host_buf_pa = virt_to_phys(g_host_buf_va);
	VASTAI_PCI_INFO(priv, priv->pkg_id,"g_host_buf_va=0x%p host_buf_pa=%#llx\n", g_host_buf_va, host_buf_pa);
	for(i = 0;i < (len/4); i++){
		*(u32*)g_host_buf_va = 0x12345678;
		g_host_buf_va += 4;
	}
	return 0;
}
int va_test_free(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	kfree(g_host_buf_va);
	return 0;
}

/**
* cmd format e.g. "smcu_read addr=0x800000 len=0x4"
*/
int va_test_smcu_read(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret  = 0;
	int i;
	unsigned char print_str[64];
	u64 addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	int len  = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s read len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len> dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, "
			"change to %d bytes\n",
			__func__, len);
	}
	ret = vastai_read_by_smcu(priv, addr, len ,dev->dm->vir);

	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [smcu_read] 0x%llx, len=%d, error:%d\n",
			__func__, addr, len, ret);
	else {
		for (i = 0; i < len; i += 16) {
			sprintf(print_str,
			"%s [smcu_read] 0x%010llx: ",
			VASTAI_PCI_DEBUG_PREFIX, (addr + i));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
			DUMP_PREFIX_NONE, 16, 4,
			dev->dm->vir + i, 16, true);
		}
	}
	return 0;
}

int va_test_smcu_write(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret=0;
	u64 addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	ret = vastai_write_4byte_by_smcu(priv, addr, val);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [smcu_write] 0x%llx, error:%d\n",
			__func__, addr, ret);
	} else {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s [smcu_write] addr=0x%llx, "
			"val=0x%lx\n",
			__func__, addr,  val);
	}
	return 0;
}

/**
* cmd format e.g. "read_slave_cfg offset=0x0 len=0x100"
* val: sub_cmd
*/
int va_test_read_slave_cfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	int ret=0;
	int i ;
	unsigned char print_str[64];
	int offset=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	int len=vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s read len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len> dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, "
			"change to %d bytes\n",
			__func__, len);
	}
	ret = vastai_slave_config_read(priv, offset, dev->dm->vir, len);

	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [read_slave_cfg] 0x%x, len=%d, error:%d\n",
		__func__, offset, len, ret);
	else {
		for (i = 0; i < len; i += 16) {
			sprintf(print_str,
			"%s [read_slave_cfg] 0x%010x: ",
			VASTAI_PCI_DEBUG_PREFIX, (offset + i));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
				DUMP_PREFIX_NONE, 16, 4,
				dev->dm->vir + i, 16, true);
		}
	}

	return 0;
}

int va_test_fread(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	int ret = 0 ;
	unsigned char print_str[64];
	u64 fn_addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	int len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	u64 noc_addr = 0;
	int i;
	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s fread len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len> dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s fread len overflow, "
		"change to %d bytes\n",
		__func__, len);
	}

	ret = vastai_pci_mem_fread(priv, fn_addr, dev->dm->vir ,len);

	{
		u64 offset = 0;
		int bar_num = 0;
		int region_num  = 0;
		translate_fn_addr(priv, fn_addr , &bar_num, &offset, &region_num);
		if (priv->bar[bar_num].region_cnt > 0) {
			noc_addr = fn_addr - priv->bar[bar_num].regions[region_num].fn_base_addr + priv->bar[bar_num].regions[region_num].noc_addr;
		} else {
			noc_addr = fn_addr - priv->bar[bar_num].fn_base_addr + priv->bar[bar_num].noc_addr;
		}
		VASTAI_PCI_INFO(priv, priv->pkg_id,"[read]fn_addr=0x%llx noc_addr=0x%llx, bar[%d] offset[%#llx] region[%d] len=0x%d \n",
			fn_addr, noc_addr, bar_num, offset, region_num, len);
	}

	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [fread] 0x%llx, len=%d, error:%d\n",
		__func__, fn_addr, len, ret);
	else {
		for (i = 0; i < len; i += 16) {
			sprintf(print_str,
				"%s [fread] faddr:0x%010llx noc:0x%010llx: ",
				VASTAI_PCI_DEBUG_PREFIX, (fn_addr + i),( noc_addr + i));
				VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
				DUMP_PREFIX_NONE, 16, 4,
				dev->dm->vir + i, 16, true);
		}
	}
	return ret;
}

int va_test_fwrite(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	int ret=0;
	u64 fn_addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	int len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	int val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	int i;
	u64 offset = 0;
	int bar_num = 0;
	int region_num = 0;
	u64 noc_addr = 0;

	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s fwrite len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len > dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s fwrite len overflow, "
			"change to %d bytes\n",
			__func__, len);
	}
	for (i = 0; i < len; i += 4) {
		((char *)dev->dm->vir)[i] = val & 0xFF;
		if ((i + 1) == len)
			break;
		((char *)dev->dm->vir)[i + 1] = (val >> 8) & 0xFF;
		if ((i + 2) == len)
			break;
		((char *)dev->dm->vir)[i + 2] = (val >> 16) & 0xFF;
		if ((i + 3) == len)
			break;
		((char *)dev->dm->vir)[i + 3] = (val >> 24) & 0xFF;
	}
	ret = vastai_pci_mem_fwrite(priv, fn_addr, dev->dm->vir, len);
	//this is for debug

	if (priv->bar[bar_num].region_cnt > 0) {
		noc_addr = fn_addr - priv->bar[bar_num].regions[region_num].fn_base_addr + priv->bar[bar_num].regions[region_num].noc_addr;
	} else {
		noc_addr = fn_addr - priv->bar[bar_num].fn_base_addr + priv->bar[bar_num].noc_addr;
	}

	{
		VASTAI_PCI_INFO(priv, priv->pkg_id,"[read]fn_addr=0x%llx noc_addr=0x%llx, bar[%x] offset[%llx] region[%x] len=0x%d \n",
		fn_addr, noc_addr, bar_num, offset, region_num, len);
	}


	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [fwrite] 0x%llx, len=%d, error:%d\n",
			__func__, fn_addr, len, ret);
	else
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s [fwrite] fn_addr=0x%llx, "
			"len=%d, val=0x%xbarx\n",
			__func__, fn_addr, len, val);

	return ret;
}

int va_test_write_slave_cfg(struct char_drv_info *dev, struct vastai_pci_info *priv)
{

	int ret = 0;
	int i;
	int offset = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_OFFSET);
	int len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	int val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	if (len <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s write len uses default 4 bytes\n",
			__func__);
		len = 4;
	} else if (len > dev->dm->size) {
		len = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s write len overflow, "
			"change to %d bytes\n",
			__func__, len);
	}
	for (i = 0; i < len; i += 4) {
		((char *)dev->dm->vir)[i] = val & 0xFF;
		if ((i + 1) == len)
			break;
		((char *)dev->dm->vir)[i + 1] = (val >> 8) & 0xFF;
		if ((i + 2) == len)
			break;
		((char *)dev->dm->vir)[i + 2] = (val >> 16) & 0xFF;
		if ((i + 3) == len)
			break;
		((char *)dev->dm->vir)[i + 3] = (val >> 24) & 0xFF;
	}
	ret = vastai_slave_config_write(priv, offset , dev->dm->vir, len);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [write_slave_cfg] 0x%x, len=%d, error:%d\n",
			__func__, offset, len, ret);
	else
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s [write_slave_cfg] offset=0x%x, "
			"len=%d, val=0x%xbarx\n",
			__func__, offset, len, val);
	return ret;
}

/**
* cmd format e.g. "diag_read addr=0x800000 len=0x100"
* val: sub_cmd
*/
int va_test_diag_read(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr  = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	int ret,i;
	unsigned char print_str[64];
	if (addr>0 && addr<0x10000000) {
		addr += 0xFF0000000;
	}

	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s read len uses default 4 bytes\n",
			__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s read len overflow, "
			"change to %d bytes\n",
			__func__, dev->valid_data_length);
	}
	ret = vastai_pci_mem_read(priv, priv->dies[0].die_index, addr, dev->dm->vir, dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [read] 0x%lx, len=%d, error:%d\n",
			__func__, addr, dev->valid_data_length, ret);
	else {
		for (i = 0; i < dev->valid_data_length; i += 16) {
			sprintf(print_str,
				"%s [read] 0x%010lx: ",
				VASTAI_PCI_DEBUG_PREFIX, (addr + i));
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
					DUMP_PREFIX_NONE, 16, 4,
					dev->dm->vir + i, 16, true);
		}
	}
	return ret;
}
/* write reg:
* cmd format e.g. "diag_write addr=0x800000 val=0x0 len=100"
*/
int va_test_diag_write(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	int ret,i;
	unsigned long val;
	if (addr>0 && addr<0x10000000) {
		addr += 0xFF0000000;
	}

	val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	dev->valid_data_length = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	if (dev->valid_data_length <= 0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s write len uses default 4 bytes\n",
			__func__);
		dev->valid_data_length = 4;
	} else if (dev->valid_data_length > dev->dm->size) {
		dev->valid_data_length = dev->dm->size;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s write len overflow, "
			"change to %d bytes\n",
			__func__, dev->valid_data_length);
	}
	for (i = 0; i < dev->valid_data_length; i += 4) {
		((char *)dev->dm->vir)[i] = val & 0xFF;
		if ((i + 1) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 1] = (val >> 8) & 0xFF;
		if ((i + 2) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 2] = (val >> 16) & 0xFF;
		if ((i + 3) == dev->valid_data_length)
			break;
		((char *)dev->dm->vir)[i + 3] = (val >> 24) & 0xFF;
	}
	ret = vastai_pci_mem_write(priv, priv->dies[0].die_index, addr, dev->dm->vir, dev->valid_data_length);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s [write] 0x%lx, len=%d, error:%d\n",
		__func__, addr, dev->valid_data_length, ret);
	else
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		"%s [write] addr=0x%lx, "
		"len=%d, val=0x%lx\n",
		__func__, addr, dev->valid_data_length, val);
	return ret;
}
/**
 * cmd format e.g. "mem_test addr=0x4a000000 len=100 val=0x55"
 * write val, then read to compare
 */
int va_test_mem_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	unsigned long val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);
	char *w_buf;
	char *r_buf;
	int ret;
	int i;

	w_buf = kmalloc(len * 2, GFP_KERNEL);
	if (!w_buf) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s buf alloc fail, 0x%lx\n", __func__,
			len * 2);
		return -ENOMEM;
	}
	r_buf = w_buf + len;
	memset(w_buf, val, len);

	for (i = 0; i < len; i += 4) {
		vastai_pci_mem_write(priv, 0, addr + i, w_buf, 4);
		vastai_pci_mem_read(priv, 0, addr + i, r_buf, 4);
		if(memcmp(w_buf, r_buf, 4)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"mem_test don't pass, error_addr=%lx\n",
			addr + i);
		goto err_ret;
		}
	}

	ret = vastai_pci_mem_write(priv, 0, addr, w_buf, len);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [write] 0x%lx, len=%ld, error:%d\n",
			__func__, addr, len, ret);
		goto err_ret;
	}
	ret = vastai_pci_mem_read(priv, 0, addr, r_buf, len);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s [read] 0x%lx, len=%ld, error:%d\n",
			__func__, addr, len, ret);
		goto err_ret;
	}
	if(memcmp(w_buf, r_buf, len)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"mem_test don't pass\n");
		goto err_ret;
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "mem_test pass\n");

	return ret;
	err_ret:
		kfree(w_buf);
		return -EIO;

}

int va_test_dma_payload(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	va_dma_t *dma;
	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV |
		VA_DMA_ATTR_DIR_DEV_TO_MEM);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
	"dma paylaod: tx=0x%llxB/s, rx=0x%llxB/s\n",
	dma->monitor.tx_byte, dma->monitor.rx_byte);

	va_dma_free(priv, dma);
	return 0;
}

int va_test_xspi_base(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if (priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		char *path_name;
		const char *buf;
		size_t buf_size;

		path_name = BL0_BASE_SG_PATH;
		buf = vastai_sg100_bl0_base_hex_buf;
		buf_size = VASTAI_SG_BL0_BASE_HEX_SIZE;

		vastai_pci_flash_xspi(priv, 0, path_name, buf, buf_size, VASTAI_PCI_FLASH_BASE);
		vastai_pci_get_fw_ver_sg(priv, 0x1800);
	}

	return 0;
}

int va_test_xspi_bl0(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if (priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		char *path_name;
		const char *buf;
		size_t buf_size;

		path_name = BL0_SG_PATH;
		buf = vastai_sg100_bl0_hex_buf;
		buf_size = VASTAI_SG_BL0_HEX_SIZE;

		vastai_pci_flash_xspi(priv, 0, path_name, buf, buf_size, VASTAI_PCI_FLASH_BL0);
		vastai_pci_get_fw_ver_sg(priv, 0x1800);
	}

	return 0;
}

int va_test_xspi_vbios(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if(priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		/* vbios is empty ----- confirm with Zouyang*/
		vastai_pci_get_fw_ver_sg(priv, 0x1800);
	}

	return 0;
}

int va_test_xspi_full(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if (priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		char *path_name;
		const char *buf;
		size_t buf_size;

		path_name = BL0_FULL_SG_PATH;
		buf = vastai_sg100_bl0_full_hex_buf;
		buf_size = VASTAI_SG_BL0_FULL_HEX_SIZE;

		vastai_pci_flash_xspi(priv, 0, path_name, buf, buf_size, VASTAI_PCI_FLASH_FULL);
		vastai_pci_get_fw_ver_sg(priv, 0x1800);
	}

	return 0;
}

int va_test_bmcu_upgrade(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if (priv->priv_hw_cfg->sys_cfg.pkg_id == 0 &&
		priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		vastai_pci_flash_bmcu(priv, 0);
	}

	return 0;
}

int va_test_bmcu_degrade(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	if (priv->priv_hw_cfg->sys_cfg.pkg_id == 0 &&
		priv->priv_hw_cfg->sys_cfg.devfn == 0 && priv->is_pf) {
		/* TODO: switch bmcu */
		vastai_pci_get_fw_ver_sg(priv, 0x600);
	}

	return 0;
}

int va_pcie_bw_test(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	unsigned long  dma_bus_addr;
	int ret = 0;
	u32 pcie_bw_test_len = 4*1024*1024;
	struct pcie_transfer_cmd trans;
	struct vastai_dma_buf pcie_bw_buf;

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s begin\n", __func__);

	vastai_pci_malloc_udma_buf(priv, &pcie_bw_buf, pcie_bw_test_len);
	if(!pcie_bw_buf.vir){
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s:malloc dma buf fail\n", __func__);
		return -1;
	}
	dma_bus_addr = pcie_bw_buf.dma_bus_addr;

	trans.w0.s_data0.optcode = GMCU_OPEN_PCIE_BW_TEST;
	trans.w1.data1 = (u32)((dma_bus_addr >> 32) & 0xFFFFFFFF);
	trans.w2.data2 = (u32)(dma_bus_addr & 0xFFFFFFFF);
	trans.w3.data3 = pcie_bw_test_len;
	if (ONLY_1_PF == priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF,  &trans, 0);
	} else if (ONLY_2_PF == priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF,  &trans, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF,  &trans, 0);
	}
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s:push element fail\n", __func__);
		vastai_pci_free_udma_buf(priv, &pcie_bw_buf);
	}
	return ret;
}
int va_ddr_bw_test(struct char_drv_info *dev,struct vastai_pci_info *priv)
{
	int ret;
	struct pcie_transfer_cmd trans;

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s begin\n", __func__);

#if 0
	ret = vatools_api_setfreq(priv, PLL_BOTTOM_OCLK, 900000000);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s:set OCLK fail\n", __func__);
		return;
	}
#endif

	trans.w0.s_data0.optcode = GMCU_OPEN_DDR_BW_TEST;
	if (ONLY_1_PF == priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF,  &trans, 0);
	} else if (ONLY_2_PF == priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF,  &trans, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF,  &trans, 0);
	}
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s:push element fail\n", __func__);
	}
	return ret;
}

int va_test_set_cii(struct char_drv_info *dev,struct vastai_pci_info *priv)
{
	int ret;
	unsigned long addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long pf = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_PF);
	unsigned long ch = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_CHANNEL);

	ret = vastai_cii_set(priv, ch, addr, pf);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "vastai_cii_set fail\n");
	return ret;
}

int va_test_cedar(struct char_drv_info *dev,struct vastai_pci_info *priv)
{
	u64 hash[8] = {0};
	u64 addr0 = 0;
	int ret;
	struct vastai_cedar_img_info alg_info = {0};

	unsigned long addr = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR);
	unsigned long len = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_LEN);
	addr0 = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_ADDR0);

	alg_info.alg_type = SHA3_224_IMG_1088,
	alg_info.input_addr = (uint64_t)addr,
	alg_info.output_addr = (uint64_t)addr0,
	alg_info.blen = len;

	ret = vastai_dev_cedar_send_cmd(priv, &alg_info, 0, 0, hash);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "vastai_dev_cedar_send_cmd fail\n");
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "hash value: 0x%llx 0x%llx 0x%llx 0x%llx\r\n", hash[0], hash[1], hash[2], hash[3]);
	return ret;
}

int va_test_mcu_log(struct char_drv_info *dev, struct vastai_pci_info *priv)
{
	enum
	{
		LOGSYS_LEVEL_ERR = 0,
		LOGSYS_LEVEL_WARN,
		LOGSYS_LEVEL_INFO,
		LOGSYS_LEVEL_DEBUG,
		LOGSYS_LEVEL_MAX,
	};

	u8 *data = NULL;
	u32 wp = 0;
	u32 rp = 0;
	u8  logsn = 0;
	u32 line_len = 0;
	u8  logLvL[LOGSYS_LEVEL_MAX][16] = {" err  ", " warn ", " info ", " debug"};
	u32 *timeStamp = 0;
	u32 len = 0;
	/*
		val = 0 smcu
		val = 4 gmcu0
		val = 5 gmcu1
		val = 6 gmcu2
		val = 7 gmcu3
		val = 8/9/10/11 vemcu
		val = 16 pmcu

		TODO: there is sth unkonwn
	*/
	int val = vastai_pci_args_value(dev->args, VASTAI_PCI_ARG_VAL);

	vastai_pci_mem_read(priv, 0, 0x8E1400 + (val*0x10) + 0x8, &wp, sizeof(u32));
	vastai_pci_mem_read(priv, 0, 0x8E1400 + (val*0x10) + 0x8 + 0x4, &rp, sizeof(u32));
	data = kzalloc(1024*1024, GFP_KERNEL);
	vastai_pci_tl_read(priv, 0, 0x1032000000 + (val*1024*1024), data, 1024*1024);
	while(rp<wp) {
		int loglevel_id = (*(data + rp + 2)) & 0x3;
		u32 len_hi = ((u32)*(data + rp + 3)) & 0xff;
		len = ((*(data + rp + 2)) >> 6) + (len_hi<<2) - 1;
		if(len + (rp%4096) > 4096 ) {
			rp = (rp/4096 + 1)*4096;
		}
		logsn = (*(data + rp + 1));
		timeStamp = (u32*)(data + rp) + 1;
		printk("[%03u][%s] 0x%08x:%s\n", logsn, logLvL[loglevel_id], *timeStamp,
				data + rp + 8);
		line_len = strlen(data + rp + 8);
		rp = rp + 8 + ROUND_UP(line_len+1, 4);
		vastai_pci_mem_write(priv, 0, 0x8E1400 + 0x8 + 0x4, &rp, sizeof(u32));
	}
	kfree(data);

	return 0;
}

#if 1
struct vastai_pci_test_info test_info_sg[] = {
	{"card", va_get_card_info},
	{"rcfg", vastai_pci_test_rcfg},
	{"config", vastai_pci_test_rcfg},
	{"wcfg", vastai_pci_test_wcfg},
	{"wconfig", vastai_pci_test_wcfg},
	{"read", vastai_pci_test_read},
	{"read_buf", vastai_pci_test_read_buf},
	{"modify_csr_bit", va_pci_test_modify_csr_bit},
	{"smcu_modify_csr_bit", va_pci_test_smcu_modify_csr_bit},
	{"write", vastai_pci_test_write},
	{"write_buf", vastai_pci_test_write_buf},
	{"rdcfg_buf", va_pci_test_rdcfg_buf},
	{"wrcfg_buf", va_pci_test_wdcfg_buf},
	{"smcu_read_buf", va_pci_test_smcu_read_buf},
	{"smcu_write_buf", va_pci_test_smcu_write_buf},
	{"mmio_read_buf",va_pci_test_mmio_read_buf},
	{"mmio_write_buf",va_pci_test_mmio_write_buf},
	{"get_log",va_pci_test_get_log},
	{"getver",va_pci_test_get_fw_ver},
	{"boot",va_pci_test_boot},
	{"flr",va_pci_test_flr},
	{"hotrset",NULL},
	{"hotset",NULL},
	{"uncond_reset",NULL},
	{"reset",NULL},
	{"reboot",NULL},
	{"selgen",vastai_pci_test_selgen},
	{"getloglevel",va_pci_test_get_log_level},
	{"setloglevel",va_pci_test_set_log_level},
	{"set_test_perf",va_pci_test_set_test_perf},
	{"malloclma",va_pci_test_malloclma},
	/*nero todo : mallocbuf/setbuf/printbuf/freebuf should with specified addr 0/1 for SDMA testing in sg100,
	but there uses sv100's ,will change in future.2023.7*/
	{"mallocbuf",vastai_pci_test_mallocbuf},
	{"setbuf",vastai_pci_test_setbuf},
	{"printbuf",vastai_pci_test_printbuf},
	{"freebuf",vastai_pci_test_freebuf},
	{"test",vastai_pci_test_test},
	{"hang_smcu",vastai_pci_test_hang_smcu},
	{"toggle_dma_callback",vastai_pci_test_toggle_dma_callback},
	{"dma_test",va_pci_test_dma_test},
	{"sdma_rst",va_test_sdma_reset},
	{"sdma_cp",va_test_sdma_cp},
	{"check_sdma",va_test_check_sdma},
	{"sdma_fence",va_test_sdma_fence},
	{"sdma_fill",va_test_sdma_fill},
	{"page_entry",va_test_page_entry},
	{"free_page",va_test_free_page},
	{"get_pa",va_test_get_pa},
	{"get_va",va_test_get_va},
	{"kill_pid",va_test_kill_pid},
	{"walk_page",va_test_walk_page},
	{"get_page",va_test_get_page},
	{"tlb_flush",va_test_tlb_flush},
	{"gmcu_cmd",va_test_gmcu_cmd},
	{"vsync_en",va_test_vsync_en},
	{"vsync_dis",va_test_vsync_dis},
	{"memmap",va_test_mmap},
	{"hw_cfg",va_test_hw_cfg},
	{"dump_atu",va_test_dump_atu},
	{"mpu_cfg",va_test_mpu_cfg},
	{"kchar_map",va_test_kchar_map},
	{"ste_info",va_test_ste_info},
	{"cmdq_test",va_test_cmdq_test},
	{"check_soc",va_test_check_soc},
	{"smcu_cmd",va_test_smcu_cmd},
	{"mmio_read",va_test_mmio_read},
	{"mmio_write",va_test_mmio_write},
	{"malloc",va_test_malloc},
	{"free",va_test_free},
	{"smcu_read",va_test_smcu_read},
	{"smcu_write",va_test_smcu_write},
	{"read_slave_cfg",va_test_read_slave_cfg},
	{"fread",va_test_fread},
	{"fwrite",va_test_fwrite},
	{"write_slave_cfg",va_test_write_slave_cfg},
#ifdef DIAG_TEST_MODE
	{"diag_read",va_test_diag_read},
	{"diag_write",va_test_diag_write},
#endif
	{"mem_test",va_test_mem_test},
	{"dma_payload",va_test_dma_payload},
	/*nero todo : flash xspi and bmcu have different from sg100*/
	{"xspi_base",va_test_xspi_base},
	{"xspi_bl0",va_test_xspi_bl0},
	{"xspi_vbios",va_test_xspi_vbios},
	{"xspi_full",va_test_xspi_full},
	{"bmcu_upgrade",va_test_bmcu_upgrade},
	{"bmcu_degrade",va_test_bmcu_degrade},
	{"pcie_perf_begin",va_pcie_bw_test},
	{"ddr_perf_begin",va_ddr_bw_test},
	{"set_cii",va_test_set_cii},
	{"cedar",va_test_cedar},
	{"mcu_log",va_test_mcu_log},
	{"print_tree_info", vastai_pci_test_print_tree}
};
#endif

void vastai_global_echo_cmd_init(struct vastai_addr_info *addr_info)
{
	addr_info[SV100].cmd_size = sizeof(test_info)/sizeof(test_info[0]);
	addr_info[SG100].cmd_size = sizeof(test_info_sg)/sizeof(test_info_sg[0]);
	addr_info[SV100].test_info = test_info;
	addr_info[SG100].test_info = test_info_sg;
}

static int vastai_pci_proc_cmd(unsigned char *input, int input_len,
			       struct char_drv_info *dev)
{
	int ret, i;
	unsigned char cmd[64];
	struct vastai_pci_info *priv = dev->pcie_dev_info;

	ret = vastai_pci_cmdline_args(input, cmd, dev->args, VASTAI_PCI_ARG_MAX);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s cmdline_args err=%d\n",
			       __func__, ret);
		return -1;
	}
	/* NTD: printing help information */
	else if (!strncmp("help", cmd, strlen("help"))) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s cmd list:\n", __func__);
		for(i=0; i < priv->addr->cmd_size; i++) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s \n", priv->addr->test_info[i].cmd);
		}
	} else {
		for(i=0; i < priv->addr->cmd_size; i++) {
			if(!strcmp(priv->addr->test_info[i].cmd, cmd)) {
				ret = priv->addr->test_info[i].pFunc(dev, priv);
				break;
			}
		}

		/* unknown cmd */
		if(i == priv->addr->cmd_size)
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s unknown cmd %s\n",
					__func__, cmd);
	}

	/* return error code for user */
	return ret;
}
extern int vastai_add_file(struct vastai_pci_info *pci_info);
extern int vastai_del_file(struct vastai_pci_info *pci_info);

static int vastai_pci_char_open(struct inode *inode, struct file *filp)
{
	struct char_drv_info *dev;
	struct char_drv_info *
		anonymous_dev; /* we need a anonymous_dev for multi thread open kchar */
	struct vastai_file_info *file_info;
	int rc = 0;

	/* VASTAI_PCI_FUNC_ENTERY; */
	file_info = to_vastai_file_info(inode->i_cdev);
	dev = container_of(file_info, struct char_drv_info, file_info);
	if ((atomic_read(&dev->pcie_dev_info->pci_state) == VASTAI_HOTP_STATE)) {
		return -ENODEV;
	}
	anonymous_dev = kmalloc(sizeof(*dev), GFP_KERNEL);
	if (!anonymous_dev) {
		return -ENOMEM;
	}
	memcpy(anonymous_dev, dev, sizeof(*dev));
	anonymous_dev->valid_data_length = 0;
	if (iommu_is_enable(dev->pcie_dev_info)) {
		anonymous_dev->dm  = vastai_dma_buf_sg_get(
				dev->pcie_dev_info,
				SZ_4M);
	}
	else {
		anonymous_dev->dm  = vastai_mempool_get(
				anonymous_dev->pcie_dev_info,
				SZ_4M);
	}
	if (!anonymous_dev->dm) {
		VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
			       "malloc buf failed\n");
		return -ENOMEM;
	}

	vastai_pci_args_init(anonymous_dev->args);
	rc = vastai_add_file(anonymous_dev->pcie_dev_info);

	filp->private_data = anonymous_dev;

	return rc;
}

static ssize_t vastai_pci_char_read(struct file *filp, char __user *buffer,
				    size_t count, loff_t *offset)
{
	int ret;
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	char *read_buf = (char *)(dev->dm->vir) + *offset;

	VASTAI_PCI_FUNC_ENTERY;
	VASTAI_PCI_DBG(dev->pcie_dev_info, DUMMY_DIE_ID,
		       "%s count[%ld] offset[%lld] dev->l[%d]!\n", __FUNCTION__,
		       count, *offset, dev->valid_data_length);
	/* ***********************************
	 * arg check:
	 * 1. count != 0 && count <= remain_size (remain_size = dev->l - *offset)
	 * 2. dev->l < dm.size
	 * 3. remain_size >= 0
	 * ***********************************/
	if ((count == 0) || ((*offset) >= (dev->valid_data_length)) ||
	    (dev->valid_data_length > dev->dm->size)) {
		return 0;
	}
	if (count > (dev->valid_data_length - *offset)) {
		count = dev->valid_data_length - *offset;
	}
	ret = copy_to_user_compact((void *)buffer, read_buf, count);
	if (ret != 0) {
		VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
			       "%s copy_to_user get error!\n", __FUNCTION__);
		return -ret;
	}

	*offset += count;

	return count;
}

static int vastai_cmd_dma(struct file *filp, const char __user *buffer,
			  size_t count, loff_t *offset);
static int vastai_cmd_rc(struct file *filp, const char __user *buffer,
			 size_t count, loff_t *offset);
static int vastai_diag_get_die_info(struct file *filp,
				    const char __user *buffer, size_t count,
				    loff_t *offset);
static int vastai_send_smi(struct file *filp, const char __user *buffer,
			   size_t count, loff_t *offset);
static int vastai_get_fw_version(struct file *filp, const char __user *buffer,
				 size_t count, loff_t *offset);
static int vastai_power_off_soc(struct file *filp,
				const char __user *buffer,
				size_t count,
				loff_t *offset);
static int vastai_set_machine_state(struct file *filp,
				    const char __user *buffer,
				    size_t count,
				    loff_t *offset);
struct {
	char *cmd_name;
	char *usage;
	int (*cmd_fn)(struct file *filp, const char __user *buffer,
		      size_t count, loff_t *offset);
} cmd_table[] = {
	{ .cmd_name = "DMA", .cmd_fn = vastai_cmd_dma, .usage = NULL },
	{ .cmd_name = "RC", .cmd_fn = vastai_cmd_rc, .usage = NULL },
	{ .cmd_name = "get_die_info",
	  .cmd_fn = vastai_diag_get_die_info,
	  .usage = NULL },
	{ .cmd_name = "smi", .cmd_fn = vastai_send_smi, .usage = NULL },
	{ .cmd_name = "get_fw_version",
	  .cmd_fn = vastai_get_fw_version,
	  .usage = NULL },
	{ .cmd_name = "power off soc", .cmd_fn = vastai_power_off_soc,
	  .usage = NULL },
	{ .cmd_name = "set m_state", .cmd_fn = vastai_set_machine_state,
	  .usage = NULL },
};

static int vastai_set_machine_state(struct file *filp,
				    const char __user *buffer,
				    size_t count,
				    loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	int ret;
	int m_state;
	char temp_buf[64] = { 0 };

	ret = copy_from_user_compact(temp_buf, buffer, 32);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s copy from user error\n",
			       __func__);
		return -EINVAL;
	}
	sscanf(temp_buf, "set m_state %d", &m_state);
	atomic_set(&priv->pci_state, m_state);

	return 0;
}

static int vastai_power_off_soc(struct file *filp,
				const char __user *buffer,
				size_t count,
				loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	int ret;

	ret = vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
				VASTAI_PCIE_SUB_REQUEST_BMCU_POWEROFF,
				0);
	return ret;
}

/* TODO: use sys/bus/pci/ dir struction to characterize die information */
static int vastai_diag_get_die_info(struct file *filp,
				    const char __user *buffer, size_t count,
				    loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	int ret;
	int die_index[4] = { 0 };
	int die_num;
	int i = 0;

	ret = get_vastai_die_info(priv, die_index, &die_num);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s get_vastai_die_info error %d\n",
			       __FUNCTION__, ret);
		return ret;
	}

	((int *)dev->dm->vir)[0] = die_num;
	dev->valid_data_length += 4;
	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
		       "vastai device_id [%d] die_num[%d]\n", priv->dev_id,
		       die_num);
	for (i = 0; i < die_num; i++) {
		((int *)dev->dm->vir)[i + 1] = die_index[i];
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "[%02d] ", die_index[i]);
		dev->valid_data_length += 4;
	}

	return 0;
}

static int vastai_get_fw_version(struct file *filp, const char __user *buffer,
				 size_t count, loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;

	memcpy(dev->dm->vir, &priv->dies[0].fw_ver, sizeof(struct vastai_fw_version));
	dev->valid_data_length += sizeof(struct vastai_fw_version);
	return 0;
}

static int vastai_send_smi(struct file *filp, const char __user *buffer,
			   size_t count, loff_t *offset)
{
	struct pcie_transfer_info trans = { .type = VASTAI_SMI };
	int ret;
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	char temp_buf[64] = { 0 };
	int die_index;
	u32 die_id;
	u32 msgq_id;

	ret = copy_from_user_compact(temp_buf, buffer, 32);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s copy from user error\n",
			       __func__);
		return -EINVAL;
	}
	sscanf(temp_buf, "smi %d", &die_index);

	die_id = vastai_pci_get_die_id(priv, die_index);
	msgq_id = vastai_get_msgq_id(priv, MSGQ_CMD);
	ret = vastai_pci_vmsgq_wr(&(priv->dies[die_id].vmsgq[msgq_id]),
				 &trans, sizeof(trans));

	if (ret)
		return -EINVAL;
	return 0;
}

static size_t get_user_dma_desc_size(u32 desc_num)
{
	struct user_dma_desc temp;
	return sizeof(temp) + sizeof(temp.desc_tab[0]) * desc_num;
}

static int vastai_cmd_rc(struct file *filp, const char __user *buffer,
			 size_t count, loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	struct user_dma_desc *dma_desc = NULL;
	u32 desc_num = 1;
	int i;
	int ret;
	u64 desc_tab[64];
	int die_index;

	dma_desc = kzalloc(get_user_dma_desc_size(desc_num), GFP_KERNEL);

REFILL_DMA_DESC:
	if (!dma_desc) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s kmalloc failed size %ld\n", __FUNCTION__,
			       get_user_dma_desc_size(desc_num));
		return -ENOMEM;
	}

	ret = copy_from_user_compact(dma_desc, buffer,
			     get_user_dma_desc_size(desc_num));
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s copy from user error\n",
			       __func__);
		goto FREE_DMA_DESC;
	}

	if (strncmp(dma_desc->cmd_str, "RC ", sizeof(dma_desc->cmd_str))) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s get err cmd line %s\n",
			       __FUNCTION__, dma_desc->cmd_str);
		/* continue */
	}

	if (dma_desc->num != desc_num && desc_num == 1) {
		desc_num = dma_desc->num;
		if (desc_num == 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "desc_num less 1!\n");
			ret = -EINVAL;
			goto FREE_DMA_DESC;
		}
		kfree(dma_desc);
		dma_desc =
			kzalloc(get_user_dma_desc_size(desc_num), GFP_KERNEL);
		goto REFILL_DMA_DESC;
	}
	die_index = priv->dies[dma_desc->die_id].die_index;

	for (i = 0; i < desc_num; i++) {
		u8 ctr_byte = vastai_udma_ctr_byte(i, desc_num, dma_desc->mode);

		desc_tab[i] =
			vastai_udma_push_desc(priv, die_index, dma_desc->ch % 4,
					      dma_desc->desc_tab[i].dev_addr,
					      dma_desc->desc_tab[i].host_addr,
					      dma_desc->desc_tab[i].length,
					      ctr_byte);
	}
	vastai_udma_trigger(priv, die_index, dma_desc->ch,
			    dma_desc->is_host_to_dev, desc_tab, desc_num);
	ret = vastai_udma_polling_done(priv, die_index, dma_desc->ch, desc_tab,
				       desc_num);
FREE_DMA_DESC:
	kfree(dma_desc);
	return ret;
}

static int vastai_cmd_dma(struct file *filp, const char __user *buffer,
			  size_t count, loff_t *offset)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	struct user_dma_desc *dma_desc = NULL;
	u32 desc_num = 1;
	int i;
	int ret;
	u64 desc_tab[64];
	u64 dma_length = 0;
	int die_index;

	dma_desc = kzalloc(get_user_dma_desc_size(desc_num), GFP_KERNEL);

REFILL_DMA_DESC:
	if (!dma_desc) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s kmalloc failed size %ld\n", __FUNCTION__,
			       get_user_dma_desc_size(desc_num));
		return -ENOMEM;
	}

	ret = copy_from_user_compact(dma_desc, buffer,
			     get_user_dma_desc_size(desc_num));
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s copy from user error\n",
			       __func__);
		goto FREE_DMA_DESC;
	}

	if (strncmp(dma_desc->cmd_str, "DMA ", sizeof(dma_desc->cmd_str))) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s get err cmd line %s\n",
			       __FUNCTION__, dma_desc->cmd_str);
		/* continue */
	}

	if (dma_desc->num != desc_num && desc_num == 1) {
		desc_num = dma_desc->num;
		if (desc_num == 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "desc_num less 1!\n");
			ret = -EINVAL;
			goto FREE_DMA_DESC;
		}
		kfree(dma_desc);
		dma_desc =
			kzalloc(get_user_dma_desc_size(desc_num), GFP_KERNEL);
		goto REFILL_DMA_DESC;
	}
	die_index = priv->dies[dma_desc->die_id].die_index;

	for (i = 0; i < desc_num; i++) {
		u8 ctr_byte = vastai_udma_ctr_byte(i, desc_num, dma_desc->mode);
		bool is_post_write = ctr_byte & BIT(2);
		bool is_pre_fetch = ctr_byte & BIT(1);

		if (dma_length + dma_desc->desc_tab[i].length > dev->dm->size) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "transfer too long 0x%llx!\n",
				       dma_length);
			return -EINVAL;
		}

		if (dma_desc->is_host_to_dev && !is_post_write) {
			ret = copy_from_user_compact(
				dev->dm->vir + dma_length,
				(void *)dma_desc->desc_tab[i].host_addr,
				dma_desc->desc_tab[i].length);
			if (ret != 0) {
				VASTAI_PCI_ERR(
					priv, DUMMY_DIE_ID,
					"%s %d copy_from_user get error!\n",
					__FUNCTION__, __LINE__);
				return ret;
			}
		}
		desc_tab[i] = vastai_udma_push_desc(
			priv, die_index, dma_desc->ch,
			dma_desc->desc_tab[i].dev_addr,
			(dev->dm->dma_bus_addr + dma_length) |
				((dma_desc->die_id) ? 0xb000000000 : 0x0),
			dma_desc->desc_tab[i].length, ctr_byte);
		if (!(dma_desc->is_host_to_dev && is_post_write) &&
		    !(!(dma_desc->is_host_to_dev) && is_pre_fetch))
			dma_length += dma_desc->desc_tab[i].length;
	}
	vastai_udma_trigger(priv, die_index, dma_desc->ch,
			    dma_desc->is_host_to_dev, desc_tab, desc_num);
	ret = vastai_udma_polling_done(priv, die_index, dma_desc->ch, desc_tab,
				       desc_num);
	dev->valid_data_length = dma_length;
FREE_DMA_DESC:
	kfree(dma_desc);
	return ret;
}

static ssize_t vastai_pci_char_write(struct file *filp,
				     const char __user *buffer, size_t count,
				     loff_t *offset)
{
	int ret;
	unsigned char *input_kernel_buf;
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	int i;
	size_t real_count = min(count, (size_t)VASTAI_CMD_READ_LEN);

	/* VASTAI_PCI_FUNC_ENTERY; */
	if (count == 0)
		return count;

	if (!dev->dm->vir) {
		VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
			       "%s dev->replay is Empty!\n", __FUNCTION__);
		return count;
	}

	input_kernel_buf = kzalloc(VASTAI_CMD_READ_LEN, GFP_KERNEL);
	if (!input_kernel_buf) {
		return -ENOMEM;
	}
	ret = copy_from_user_compact(input_kernel_buf, (char __user *)buffer,
			     real_count);
	if (ret != 0) {
		VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
			       "%s copy_from_user get error!\n", __FUNCTION__);
		goto FREE_INPUT_BUF;
	}

	ret = -1;
	for (i = 0; i < ARRAY_SIZE(cmd_table); i++) {
		char *cmd = cmd_table[i].cmd_name;
		if (strncmp(cmd, input_kernel_buf, strlen(cmd)) == 0) {
			ret = cmd_table[i].cmd_fn(filp, buffer, count, offset);
			if (ret < 0) {
				VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
					       "get error code %d\n", ret);
				goto FREE_INPUT_BUF;
			}
		}
	}
	input_kernel_buf[real_count - 1] = 0; /* set \0 for string */

	if (ret != 0) { /* Is this cmd handle by cmd_table ? */
		VASTAI_PCI_DBG(dev->pcie_dev_info, DUMMY_DIE_ID, "write:%s\n",
			       input_kernel_buf);
		ret = vastai_pci_proc_cmd(input_kernel_buf, VASTAI_CMD_READ_LEN,
					  dev);
	}

FREE_INPUT_BUF:
	kfree(input_kernel_buf);

	if (ret != 0) {
		VASTAI_PCI_ERR(dev->pcie_dev_info, DUMMY_DIE_ID,
			       "%s we get error code %d!\n", __FUNCTION__, ret);
		return ret;
	}
	return count;
}

static long vastai_pci_char_ioctl(struct file *filp, unsigned int cmd,
				  unsigned long arg)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	struct vastai_pci_info *priv = dev->pcie_dev_info;
	struct kchar_cmd kcmd;
	int ret = 0;

	if ((atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE) &&
			(atomic_read(&priv->pci_state) != VASTAI_DEBUG_STATE))
		return -ENODEV;
	ret = copy_from_user_compact(&kcmd, (void *)arg, sizeof(kcmd));
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s copy_from_user is error\n", __func__);
		return -EIO;
	}

	switch (cmd) {

	case VASTAI_PCI_IOCTL_ALLOC: {
		struct dma_buf *dmabuf;

		if (iommu_is_enable(priv))
			dmabuf = vastai_alloc_dma_buf_sg(
					priv,
					kcmd.alloc_cmd.size);
		else
			dmabuf = vastai_alloc_dma_buf(
					priv,
					kcmd.alloc_cmd.size);
		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, 0);
			kcmd.alloc_cmd.dma_buf_fd = fd;
			kcmd.alloc_cmd.dma_addr_t = dm->dma_bus_addr;
		} else {
			kcmd.alloc_cmd.dma_buf_fd = -ENOMEM;
		}
		break;
	}

	case VASTAI_PCI_IOCTL_DMA_START: {
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		struct timespec tm_begin, tm_end;
#else
		u64 tm_begin, tm_end;
#endif
		unsigned long time_total_ns;

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		/* getnstimeofday function is removed from kernel5.6 */
		getnstimeofday(&tm_begin);
#else
		tm_begin = ktime_get_ns();
#endif
		ret = vastai_pci_dma_start(priv, &kcmd.dma_start_cmd);

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		getnstimeofday(&tm_end);
		time_total_ns =
			timespec_to_ns(&tm_end) - timespec_to_ns(&tm_begin);
#else
		tm_end = ktime_get_ns();
		time_total_ns = tm_end - tm_begin;
#endif

		if (time_total_ns > 30000 && 0) {
			struct vastai_fifo fifo;
			printk("%s die_index 0x%x time %ld\n", __FUNCTION__,
			       kcmd.dma_start_cmd.die_index, time_total_ns);

			vastai_pci_mem_read(priv, kcmd.dma_start_cmd.die_index,
					    0x8c14000, &fifo,
					    sizeof(struct vastai_fifo));

			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
				"0x8c14000", fifo.rd, fifo.wr, fifo.elem_count,
				fifo.elem_size);

			vastai_pci_mem_read(priv, kcmd.dma_start_cmd.die_index,
					    0x8c1e000, &fifo,
					    sizeof(struct vastai_fifo));

			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
				"0x8c1e000", fifo.rd, fifo.wr, fifo.elem_count,
				fifo.elem_size);
		}
		break;
	}
	case VASTAI_PCI_IOCTL_DMA_TRANS: {
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		struct timespec tm_begin, tm_end;
#else
		u64 tm_begin, tm_end;
#endif
		unsigned long time_total_ns;

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		/* getnstimeofday function is removed from kernel5.6 */
		getnstimeofday(&tm_begin);
#else
		tm_begin = ktime_get_ns();
#endif
		ret = vastai_pci_dma_trans(priv, &kcmd.dma_trans_cmd);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		getnstimeofday(&tm_end);
		time_total_ns =
			timespec_to_ns(&tm_end) - timespec_to_ns(&tm_begin);
#else
		tm_end = ktime_get_ns();
		time_total_ns = tm_end - tm_begin;
#endif

		if (time_total_ns > 30000 && 0) {
			struct vastai_fifo fifo;
			printk("%s die_index 0x%x time %ld\n", __FUNCTION__,
			       kcmd.dma_trans_cmd.die_index, time_total_ns);

			vastai_pci_mem_read(priv, kcmd.dma_trans_cmd.die_index,
					    0x8c14000, &fifo,
					    sizeof(struct vastai_fifo));

			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
				"0x8c14000", fifo.rd, fifo.wr, fifo.elem_count,
				fifo.elem_size);

			vastai_pci_mem_read(priv, kcmd.dma_trans_cmd.die_index,
					    0x8c1e000, &fifo,
					    sizeof(struct vastai_fifo));

			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
				"0x8c1e000", fifo.rd, fifo.wr, fifo.elem_count,
				fifo.elem_size);
		}
		break;
	}
	case VASTAI_PCI_IOCTL_DMA_TRANS_SG: {
		union core_bitmap core_id = { .val = 0 };
		struct vastai_channel_buf *channel_buf;
		int i;
		int channel_num = kcmd.dma_trans_sg_cmd.channel_num;
		channel_buf = kvmalloc(sizeof(struct vastai_channel_buf) *
					       channel_num,
				       GFP_KERNEL);
		if (!channel_buf) {
			return -ENOMEM;
		}
		memcpy(channel_buf,
			(void*)kcmd.dma_trans_sg_cmd.channel_buf,
			sizeof(struct vastai_channel_buf) * channel_num);

		for (i = 0; i < channel_num; i++) {
			VASTAI_PCI_DBG(
				priv, kcmd.dma_trans_sg_cmd.die_index,
				"channel[%d], w:%d, h:%d, dst_w_off:%d, dst_h_off:%d, src_w_off:%d, src_h_off:%d\n",
				i, channel_buf[i].width, channel_buf[i].high,
				channel_buf[i].dst_width_offset,
				channel_buf[i].dst_high_offset,
				channel_buf[i].src_width_offset,
				channel_buf[i].src_high_offset);
		}

		vastai_dma_video(priv, kcmd.dma_trans_sg_cmd.die_index, core_id,
				 channel_buf, channel_num,
				 kcmd.dma_trans_sg_cmd.axi_addr,
				 kcmd.dma_trans_sg_cmd.pid);

		kvfree(channel_buf);
		break;
	}
	case VASTAI_PCI_IOCTL_MEMSET: {
		u32 size = kcmd.dma_memset_cmd.length;
		struct device *dev = &(priv->dev->dev);
		dma_addr_t dma_bus_addr;
		u32 is_src_dma_addr = 1;
		u32 is_src_not_user_mem = 1;
		union core_bitmap core_id = { .val = 0 };
		struct vastai_dma_buf *dm = kmalloc(sizeof(struct vastai_dma_buf),  GFP_KERNEL);

		if(!dm){
			return -ENOMEM;
		}

		if(size < VASTAI_MAX_MEMSET_BUF){

			dm->vir = dma_alloc_coherent(dev, size, &dma_bus_addr,  GFP_KERNEL);
		}else{

			dm->vir = dma_alloc_coherent(dev, VASTAI_MAX_MEMSET_BUF, &dma_bus_addr,  GFP_KERNEL);
		}

		if(!dm->vir || !dma_bus_addr){
		 VASTAI_PCI_ERR(priv,DUMMY_DIE_ID,
			"%s: dma_alloc_coherent fail\n",__func__);
		 goto ERROR_FREE_DM;
		}

		memset(dm->vir, kcmd.dma_memset_cmd.val, size);

		ret = vastai_pci_dma_transfer_memset(
					priv,
					kcmd.dma_memset_cmd.die_index,
					core_id,
					dma_bus_addr,
					is_src_dma_addr,
					!kcmd.dma_memset_cmd.is_dev_to_host,
					is_src_not_user_mem,
					kcmd.dma_memset_cmd.axi_addr,
					kcmd.dma_memset_cmd.length);

		if(size < VASTAI_MAX_MEMSET_BUF){

			dma_free_coherent(dev, size, (void *)dm->vir, dma_bus_addr);

		}else{

			dma_free_coherent(dev, VASTAI_MAX_MEMSET_BUF, (void *)dm->vir, dma_bus_addr);
		}
		ERROR_FREE_DM:
		kvfree(dm);

		break;
    }
	case VASTAI_PCI_IOCTL_POLL_LOG: {
		/* trigger smcu to poll log buf */
		u32 flag = 0;
		int ret;
		u32 timeout_water = kcmd.log_poll_cmd.timeout_water != 0x0 ?
						kcmd.log_poll_cmd.timeout_water :
						500;
		u32 die_index = kcmd.log_poll_cmd.die_index;
		struct vastai_sv100_die *die = &(
			((struct vastai_pci_info *)priv)
				->dies[vastai_pci_get_die_id(priv, die_index)]);

		vastai_pci_mem_write(priv, die_index, LOG_MSG_FLAG, &flag,
				     sizeof(flag));
		/* wait complete */
		ret = wait_for_completion_interruptible_timeout(
			&(die->log_comp), HZ * timeout_water / 1000);
		if (ret == 0) {
			kcmd.log_poll_cmd.is_timeout = 1;
		}

		reinit_completion(&(die->log_comp));

		/* get log ring ctl */
		/* we need size == 0x1D0 buf */
		vastai_pci_mem_read(priv, kcmd.log_poll_cmd.die_index,
				    LOG_CTRL_INFO, dev->dm->vir, 0x1D0);
		ret = copy_to_user_compact(kcmd.log_poll_cmd.log_ring_ctl, dev->dm->vir,
				   0x1D0);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s copy_from_user is error\n",
				       __func__);
			return -EIO;
		}
		break;
	}
	case VASTAI_PCI_IOCTL_RENDER: {
		u32 die_index = kcmd.get_render_name.die_index;
		snprintf(kcmd.get_render_name.file_name,
			 sizeof(kcmd.get_render_name.file_name), "renderD%d",
			 priv->dies[vastai_pci_get_die_id(priv, die_index)]
				 .render_id);
		printk("%s\n", kcmd.get_render_name.file_name);
		break;
	}
	case VASTAI_PCI_IOCTL_PORT: {
		strcpy(kcmd.port_name, pci_name(priv->dev));
		printk("%s\n", kcmd.port_name);
		break;
	}
	case VASTAI_PCI_IOCTL_GET_PERFORMANCE: {
		u32 die_index = kcmd.get_die_performance.die_index;
		int i = 0;

		for(i=0; i<SV100_MAX_VDSP_NUM; i++) {
			kcmd.get_die_performance.pcie_tx_vdsp_count[i] =
				priv->dies[vastai_pci_get_die_id(priv, die_index)].core[i+CORE_POINT_VDSP0].pcie_tx_core_count;
			kcmd.get_die_performance.pcie_rx_vdsp_count[i] =
				priv->dies[vastai_pci_get_die_id(priv, die_index)].core[i+CORE_POINT_VDSP0].pcie_rx_core_count;
		}
		break;
	}
	case VASTAI_PCI_IOCTL_PCI_ID:
                kcmd.get_pci_id.pci_id = priv->dev->vendor | priv->dev->device << 16;
		break;
	case VASTAI_PCI_IOCTL_PCI_SUB_ID:
		kcmd.get_pci_sub_id.pci_sub_id = 0xFFFF;
		break;
	case VASTAI_PCI_IOCTL_MAJOR_MINOR:
		kcmd.get_major_minor.major_minor =
			vastai_file_get_major_minor(&dev->file_info);
		break;
	#ifdef CONFIG_VASTAI_JENKINS_TEST
	case VASTAI_PCI_IOCTL_DMA_TEST:{
			u32 test_size = kcmd.dma_start_cmd.size;
			u64 dev_addr = kcmd.dma_start_cmd.axi_addr;
			int ret ;
			ret = vastai_pci_tc165(priv, test_size, dev_addr);
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "tc165 error %d\n", ret);
				return -ret;
			}
			ret = vastai_pci_tc166(priv, test_size, dev_addr);
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "tc166 error %d\n", ret);
				return -ret;
			}
			break;
	}
	#endif
	case VASTAI_PCI_IOCTL_DIE2DIE_TEST:{
		int ret = 0;
		ret = vastai_pci_die2die_test(priv, &kcmd);
		if(ret){
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "die2die_test error \n");
		}
		break;
	}
	case TCGETS:
		return -ENOIOCTLCMD;

	case TCSETS:
		return -ENOIOCTLCMD;

	case TIOCSERGETLSR:
		return -ENOIOCTLCMD;

	case TIOCSERCONFIG:
		return -ENOIOCTLCMD;
	case VASTAI_PCI_IOCTL_BOARD_TYPE:
		kcmd.board_type.type = vastai_get_board_type(dev->pcie_dev_info);
		break;

	default:
		VASTAI_PCI_INFO(dev->pcie_dev_info, DUMMY_DIE_ID,
				"Unsupport cmd 0x%x\n", cmd);
		break;
	}

	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "ioctl error %d\n", ret);
		return ret;
	}

	ret = copy_to_user_compact((void *)arg, &kcmd, sizeof(kcmd));
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s copy_to_user is error\n",
			       __func__);
		return -EIO;
	}

	return 0;
}

static int vastai_pci_char_release(struct inode *inode, struct file *filp)
{
	struct char_drv_info *dev = (struct char_drv_info *)filp->private_data;
	int rc = 0;

	/* VASTAI_PCI_FUNC_ENTERY; */
	if (iommu_is_enable(dev->pcie_dev_info)) {
		vastai_dma_buf_sg_put(dev->pcie_dev_info, dev->dm);
	}
	else
		vastai_mempool_put(dev->pcie_dev_info, dev->dm);

	/* free anonymous_dev */
	rc = vastai_del_file(dev->pcie_dev_info);
	kfree(dev);

	return rc;
}

static const struct file_operations fop = {
	.owner = THIS_MODULE,
	.open = vastai_pci_char_open,
	.release = vastai_pci_char_release,
	.write = vastai_pci_char_write,
	.read = vastai_pci_char_read,
	.llseek = default_llseek,
	.unlocked_ioctl = vastai_pci_char_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = vastai_pci_char_ioctl,
#endif
};
struct class *myclass;

static int vastai_pci_ioctl_cmd_init(struct vastai_pci_info *bus)
{
	int ret;
	struct char_drv_info *drv;

	drv = kmalloc(sizeof(struct char_drv_info), GFP_KERNEL);
	if (!drv) {
		ret = -ENOMEM;
		return ret;
	}
	bus->p_char = drv;

	drv->pcie_dev_info = bus;
	ret = vastai_file_create(&drv->file_info, bus, &fop, "kchar:%d",
				 bus->dev_id);
	VASTAI_PCI_INFO(bus, DUMMY_DIE_ID,
			"init ioctl node /dev/kchar:%d ok.\n", bus->dev_id);

	return ret;
}

int vastai_pci_ioctl_cmd_deinit(struct vastai_pci_info *bus)
{
	struct char_drv_info *drv = bus->p_char;

	vastai_pci_free_udma_buf(bus, &dmb[0]);
	vastai_file_destroy(&drv->file_info);
	VASTAI_PCI_INFO(bus, DUMMY_DIE_ID,
			"deinit ioctl node /dev/kchar:%d ok.\n", bus->dev_id);
	kfree(drv);
	bus->p_char = NULL;

	return 0;
}


int vastai_version_file_init(struct vastai_pci_info *pci_info);
int vastai_ctl_file_init(struct vastai_pci_info *pci_info);

static void vastai_payload_work(struct work_struct *work)
{
	struct vastai_pci_info *priv = NULL;
	int ret;
	u32 buf[4] = {0};

	priv = container_of(work, struct vastai_pci_info, payload_work.work);
	ret = vastai_pci_mem_read(priv, 0, 0x9000028, buf, sizeof(buf));

	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: read payload reg failed, %d\n", __func__, ret);
		memset(buf, 0, sizeof(buf));
		return;
	}

	if (buf[0] < (rx_packet & 0xffffffff))
		rx_packet += 0x100000000;

	if (buf[1] < (rx_payload & 0xffffffff))
		rx_payload += 0x100000000;

	if (buf[2] < (tx_packet & 0xffffffff))
		tx_packet += 0x1000000001;

	if (buf[3] < (tx_payload & 0xffffffff))
		tx_payload += 0x100000000;

	rx_packet  = (rx_packet  & 0xffffffff00000000) + buf[0];
	rx_payload = (rx_payload & 0xffffffff00000000) + buf[1];
	tx_packet  = (tx_packet  & 0xffffffff00000000) + buf[2];
	tx_payload = (tx_payload & 0xffffffff00000000) + buf[3];

	schedule_delayed_work(&priv->payload_work, msecs_to_jiffies(1000)/* 10s */);
}

void vastai_set_payload_work(struct vastai_pci_info *bus)
{
#if PCIE_PAYLOAD_MONITOR_EN
	INIT_DELAYED_WORK(&bus->payload_work, vastai_payload_work);
	schedule_delayed_work(&bus->payload_work, msecs_to_jiffies(1000)/* 1s */);
#else
	(void)vastai_payload_work;
#endif
}

void vastai_cancel_payload_work(struct vastai_pci_info *bus)
{
#if PCIE_PAYLOAD_MONITOR_EN
	    cancel_delayed_work_sync(&bus->payload_work);
#endif
}
int vastai_pci_ioctl_init(struct vastai_pci_info *bus)
{
	if (vastai_get_board_type(bus) == SV100)
		vastai_version_file_init(bus);
	if (bus->addr->p_set_payload_work)
		bus->addr->p_set_payload_work(bus);
	vastai_ctl_file_init(bus);
	return vastai_pci_ioctl_cmd_init(bus);
}

void vastai_version_file_deinit(struct vastai_pci_info *pci_info);
void vastai_ctl_file_deinit(struct vastai_pci_info *pci_info);
int vastai_pci_ioctl_deinit(struct vastai_pci_info *bus)
{
	if (vastai_get_board_type(bus) == SV100)
		vastai_version_file_deinit(bus);
	if (bus->addr->p_cancel_payload_work)
		bus->addr->p_cancel_payload_work(bus);
	vastai_ctl_file_deinit(bus);
	return vastai_pci_ioctl_cmd_deinit(bus);
}

unsigned int major = 321;
unsigned int minor = 0;
extern struct list_head vastai_minor_list;

bool vastai_search_minor(u32* minor)
{
	struct vastai_minor_info* pMinor;

	if (list_empty(&vastai_minor_list))
		return false;

	list_for_each_entry(pMinor, &vastai_minor_list, dev_list) {
		list_del(&(pMinor->dev_list));
		break;
	}

	*minor = pMinor->minor;
	kfree(pMinor);
	return true;
}

unsigned int vastai_get_empty_minor(void)
{
	u32 tmpMinor = 0;

	if(vastai_search_minor(&tmpMinor))
		return tmpMinor;
	else
		return ++minor;
}

int vastai_file_create(struct vastai_file_info *file_info,
		       struct vastai_pci_info *pci_info,
		       const struct file_operations *fop, const char *fmt, ...)
{
	va_list vargs;
	int ret = 0;

	file_info->dev_num = MKDEV(major, vastai_get_empty_minor());
	file_info->priv = pci_info;
	ret = register_chrdev_region(file_info->dev_num, 1, "vastai");
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "register device num failed! alloc one [%d]\n",
			       file_info->dev_num);
		alloc_chrdev_region(&file_info->dev_num, 0, 1, "char");
	}

	file_info->dev.owner = THIS_MODULE;
	cdev_init(&file_info->dev, fop);
	ret = cdev_add(&file_info->dev, file_info->dev_num, 1);
	if (ret < 0) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "cdev_add failed %d\n",
			       ret);
		return ret;
	}

	va_start(vargs, fmt);
	vsnprintf(file_info->file_name, 32, fmt, vargs);
	va_end(vargs);
	file_info->device = device_create(myclass, NULL, file_info->dev_num,
					  file_info, file_info->file_name);

	if (!file_info->device) {
		ret = PTR_ERR(file_info->device);
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "device_create_vargs failed %d\n", ret);
		return ret;
	}
	return ret;
}

void vastai_file_destroy(struct vastai_file_info *file_info)
{
	struct vastai_minor_info* pMinor;

	if(vastai_get_pci_state(file_info->priv) == VASTAI_HOTP_STATE) {
		pMinor = kzalloc(sizeof(struct vastai_minor_info), GFP_KERNEL);
		if (!pMinor)
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
					"vastai_file_destroy kzalloc failed %d\n", MINOR(file_info->dev_num));

		pMinor->minor =  MINOR(file_info->dev_num);
		list_add_tail(&(pMinor->dev_list), &(vastai_minor_list));
	}

	if(vastai_get_pci_state(file_info->priv) == VASTAI_EXIT_STATE) {
		struct vastai_minor_info* pMinor;
		struct vastai_minor_info* pMinor_tmp;

		if (!list_empty(&vastai_minor_list)) {
			list_for_each_entry_safe(pMinor, pMinor_tmp, &vastai_minor_list, dev_list) {
				list_del(&(pMinor->dev_list));
				kfree(pMinor);
			}
		}
	}

	device_destroy(myclass, file_info->dev_num);
	cdev_del(&file_info->dev);
	unregister_chrdev_region(file_info->dev_num, 1);
}

dev_t vastai_file_get_major_minor(struct vastai_file_info *file_info)
{
	return file_info->dev_num;
}

#define DEVICE_NUMBER 1
#define DEVICE_SNAME "static_vastai_chardevice"
#define DEVICE_DNAME "dynamic_vastai_chardevice"
#define DEVICE_MINOR_NUMBER 0
#define DEVICE_CLASS_NAME "chrdev_class"
#define DEVICE_NODE_NAME "vastai_dev"

#if KERNEL_VERSION(6, 2, 0) > LINUX_VERSION_CODE
static char *set_devnode(struct device *dev, umode_t *mode)
{
	if (mode)
		*mode = 0666; // set /dev/mydevice right: 0666
	return NULL;
}
#else
static char *set_devnode(const struct device *dev, umode_t *mode)
{
	if (mode)
		*mode = 0666; // set /dev/mydevice right: 0666
	return NULL;
}
#endif

static int vastai_dev_char_open(struct inode *ind, struct file *fp)
{
	printk("demo open\n");
	return 0;
}

static ssize_t vastai_dev_char_read(struct file *filp, char __user *buffer,
				    size_t count, loff_t *offset)
{
	printk("vastai_dev_char_read:ok!\n");
	return 0;
}


static const struct file_operations fop_dev = {
	.owner = THIS_MODULE,
	.open = vastai_dev_char_open,
	.read = vastai_dev_char_read,
};
struct cdev char_dev;
struct class *vastai_class;
struct device *device;
dev_t dev_num;
static int dev_major_num,dev_minor_num;

int vastai_dev_node_init(void){
	int ret;
	dev_num = MKDEV(major, vastai_get_empty_minor());/*设置主从设备号*/
	ret = register_chrdev_region(dev_num, DEVICE_NUMBER, DEVICE_DNAME);
	if (ret < 0) {
		printk("vastai_dev:register_chrdev_region error!\n");
	}
	dev_major_num = MAJOR(dev_num);
	dev_minor_num = MINOR(dev_num);
	char_dev.owner = THIS_MODULE;
	cdev_init(&char_dev,&fop_dev);
	cdev_add(&char_dev,dev_num,DEVICE_NUMBER);
#if KERNEL_VERSION(6,4,0) > LINUX_VERSION_CODE
		vastai_class = class_create(THIS_MODULE,DEVICE_CLASS_NAME);
#else
		vastai_class = class_create(DEVICE_CLASS_NAME);
#endif
	vastai_class->devnode = set_devnode; /*设置节点权限*/
	device = device_create(vastai_class, NULL, dev_num, NULL,DEVICE_NODE_NAME);
	if (IS_ERR(device)) {
		printk("Failed to create vastai_dev device\n");
		return PTR_ERR(device);
	}
	printk("vastai_dev init ok!\n");
	return 0;
}

void vastai_dev_node_deinit(void){
	unregister_chrdev_region(MKDEV(dev_major_num,dev_minor_num),DEVICE_NUMBER);
	cdev_del(&char_dev);
	device_destroy(vastai_class,dev_num);
	class_destroy(vastai_class);
	printk("vastai_dev deinit ok!\n");
}
