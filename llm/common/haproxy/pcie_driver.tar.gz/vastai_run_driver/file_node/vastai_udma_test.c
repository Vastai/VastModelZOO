/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/delay.h>
#include "vastai_udma_test.h"
#include "vastai_udma_engine.h"
#include "vastai_fifo.h"

u8 vastai_udma_ctr_byte(int i, int sum, enum VASTAI_DMA_MODE mode)
{
	bool is_last = i == (sum - 1);
	u8 ret = 0;
	enum { normal = 0,
	       pre_fetch,
	       post_write,
	} desc_type = 0;

	switch (mode) {
	case VASTAI_DMA_MODE_BULK:
		desc_type = 0;
		break;
	case VASTAI_DMA_MODE_SCATTER:
		if (i == 0) {
			desc_type = pre_fetch;
		} else {
			desc_type = post_write;
		}
		break;
	case VASTAI_DMA_MODE_GATHER:
		if (is_last) {
			desc_type = post_write;
		} else {
			desc_type = pre_fetch;
		}
		break;
	}

	if (!is_last) {
		ret |= BIT(5);
	}
	if (desc_type == post_write) {
		ret |= BIT(2);
	} else if (desc_type == pre_fetch) {
		ret |= BIT(1);
	}
	if (is_last) {
		ret |= BIT(0);
	}
	return ret;
}

void vastai_udma_trigger(struct vastai_pci_info *priv, unsigned int die_index,
			 unsigned int dma_chn, unsigned int is_host_to_dev,
			 u64 *desc_tab, int num)
{
	u32 val = 0;
	u32 dma_base = dma_chn < 4 ? 0x9500000 : 0x9e00000;
	dma_chn = dma_chn < 4 ? dma_chn : dma_chn - 4;

	vastai_set_desc_link(priv, die_index, desc_tab, num);

	val = desc_tab[0] & 0xFFFFFFFF;
	vastai_pci_mem_write(priv, die_index, dma_base + dma_chn * 0x14 + 0x4,
			     &val, sizeof(u32));

	val = desc_tab[0] >> 32;
	vastai_pci_mem_write(priv, die_index, dma_base + dma_chn * 0x14 + 0x8,
			     &val, sizeof(u32));
	val = BIT(dma_chn) | BIT(dma_chn + 8);
	vastai_pci_mem_write(priv, die_index, dma_base + 0xa4, &val,
			     sizeof(u32));
	mb();
	val = 0x1; /* set go */
	if (!is_host_to_dev)
		val |= BIT(1);
	vastai_pci_mem_write(priv, die_index, dma_base + dma_chn * 0x14, &val,
			     sizeof(u32));
}

int vastai_udma_polling_done(struct vastai_pci_info *priv,
			     unsigned int die_index, unsigned int dma_chn,
			     u64 *desc_tab, int num)
{
	u32 done = 0;
	u32 err = 0;
	int patience = 50;

	do {
		int i;
		u32 status = 0;

		for (i = 0; i < num; i++) {
			vastai_pci_mem_read(priv, die_index,
					    desc_tab[i] + offsetof(PCIE_xd_desc,
								   status),
					    &status, sizeof(u32));
			if (status != 0x10000)
				break;
		}

		if (i == num) {
			done = 1;
			break;
		} else if (status != 0) {
			err = 1;
			break;
		}

		msleep(1);

	} while (!done && patience--);

	if (done && !err) {
		u64 fifo_addr =
			priv->dies[vastai_pci_get_die_id(priv, die_index)].udma_chn[dma_chn % 4].udma_config.dma_desc_fifo_addr;
		int i;

		for (i = 0; i < num; i++)
			vastai_fifo_pop_elem(priv, die_index, fifo_addr, NULL,
					     NULL, NORMAL_FIFO);

		VASTAI_PCI_DBG(priv, vastai_pci_get_die_id(priv, die_index),
			       "DMA chn %d DONE\n", dma_chn);
		return 0;
	} else {
		VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die_index),
			       "DMA chn %d timeout\n", dma_chn);
	}
	return err;
}

/*-----------------------------------------------------------------------------
 * Perform a DMA bulk transfer
 *-----------------------------------------------------------------------------
 */
int vastai_udma_start_bulk_transfer(struct vastai_pci_info *priv, u8 die_id,
				    uint32_t obDirection, uint32_t len,
				    uintptr_t localAddr, uintptr_t remoteAddr)
{
	u64 desc[1];
	int ret;
	u64 time_begin = 0,time_end = 0;
	desc[0] = vastai_udma_push_desc(priv, priv->dies[die_id].die_index, 0,
					localAddr, remoteAddr, len, 0x1);

	vastai_udma_trigger(priv, priv->dies[die_id].die_index, 0, !obDirection,
			    desc, 1);
	time_begin = vastai_get_host_time_ns();
	ret = vastai_udma_polling_done(priv, priv->dies[die_id].die_index, 0,
				       desc, 1);
	time_end = vastai_get_host_time_ns();
	VASTAI_PCI_INFO(priv, die_id, "dma poll cost time [%lld]ns",time_end-time_begin);
	return ret;
}
