1. read configuration space
eg.
	echo "config" > /dev/kchar:\id

2. read read_address read_len_bytes
(4 bytes acquiescently, max 4096 bytes)
eg.
	echo "read 0xf00000" > /dev/kchar:\id
	echo "read 0xf00000 100" > /dev/kchar:\id

3. write write_address write_value write_len_bytes
(4 bytes acquiescently, max 4096 bytes)
eg.
	echo "write 0xf00000 0x1234" > /dev/kchar:\id
	echo "write 0xf00000 0x1234 100" > /dev/kchar:\id
