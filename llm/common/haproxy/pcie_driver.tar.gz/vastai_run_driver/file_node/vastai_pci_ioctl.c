
#include <linux/ctype.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/dma-buf.h>
#include <linux/poll.h>

#include "vastai_pci.h"
#include "vastai_pci_test.h"
#include "vastai_enc.h"
#include "vastai_udma_engine.h"
#include "vastai_fifo.h"
#include "vatools.h"
#include "vastai_utils.h"

#define TCGETS	       0x5401
#define TCSETS	       0x5402
#define TCSETSW	       0x5403
#define TCSETSF	       0x5404
#define TIOCSERGSTRUCT 0x5458 /* For debugging only */
#define TIOCSERGETLSR  0x5459 /* Get line status register */
#define TIOCSERCONFIG  0x545

int vastai_add_file(struct vastai_pci_info *pci_info)
{
	unsigned long flags;
	struct pid_entry *pid_loop = NULL;
	struct pid_entry *pid_entry = NULL;
	struct pid *current_pid = get_pid(task_tgid(current));

	pid_entry = kzalloc(sizeof(*pid_entry), GFP_KERNEL);
	if (pid_entry == NULL) {
		VASTAI_PCI_INFO(pci_info, 0,
			"vastai_add_file kzmalloc failed!\n");
		return -ENOMEM;
	}

	pid_entry->refcount = 1;
	pid_entry->pid = get_pid(task_tgid(current));

	spin_lock_irqsave(&pci_info->file_lock, flags);
	list_for_each_entry(pid_loop, &pci_info->file_list, node) {
		if(pid_loop->pid == current_pid) {
			pid_loop->refcount++;
			spin_unlock_irqrestore(&pci_info->file_lock, flags);
			kfree(pid_entry);
			return 0;
		}
	}

	list_add(&pid_entry->node, &pci_info->file_list);
	spin_unlock_irqrestore(&pci_info->file_lock, flags);

	return 0;
}

int vastai_del_file(struct vastai_pci_info *pci_info)
{
	unsigned long flags;
	struct pid_entry *pid_loop  = NULL;
	struct pid *current_pid = get_pid(task_tgid(current));

	spin_lock_irqsave(&pci_info->file_lock, flags);
	list_for_each_entry(pid_loop, &pci_info->file_list, node) {
		if(pid_loop->pid == current_pid) {
			pid_loop->refcount--;
			if(0 == pid_loop->refcount) {
				list_del(&pid_loop->node);
			}
			spin_unlock_irqrestore(&pci_info->file_lock, flags);
			if(0 == pid_loop->refcount) {
				put_pid(pid_loop->pid);
				kfree(pid_loop); /*do not free in spin lock*/
			}
			return 0;
		}
	}
	spin_unlock_irqrestore(&pci_info->file_lock, flags);

	return 0;
}


static int ctl_open(struct inode *inode, struct file *filp)
{
	struct vastai_file_info *file_info;
	struct vastai_ctl_file *ctl_file;
	int rc = 0;

	file_info = to_vastai_file_info(inode->i_cdev);
	ctl_file = container_of(file_info, struct vastai_ctl_file, file_info);
	if ((atomic_read(&ctl_file->pci_info->pci_state) == VASTAI_HOTP_STATE)) {
		return -ENODEV;
	}
	rc = vastai_add_file(ctl_file->pci_info);
	if(rc != 0)
		return rc;

	filp->private_data = ctl_file;
	return rc;
}

static int ctl_release(struct inode *inode, struct file *filp)
{
	struct vastai_ctl_file *ctl_info = (struct vastai_ctl_file*)filp->private_data;

	return vastai_del_file(ctl_info->pci_info);
}

typedef int(*set_desc_func)(struct vastai_dmadesc*, struct dma_buf*,
				  struct kchar_cmd*,
				  int, u32, u32,
				  struct vastai_pci_info*);

typedef int(*set_desc_func_new)(struct vastai_dmadesc*,
					void*,
					u64*, u32,
					u64*);

int vastai_ioctl_dma_start_set_desc_new(struct vastai_dmadesc* desc,
							void *dma_node,
							u64 *dev_addr, u32 temp_size,
							u64 *host_addr)
{
	int ret = 0;
	dma_node_start_cmd_t *dma_start_cmd = (dma_node_start_cmd_t *)dma_node;

	desc->is_host_to_dev = !dma_start_cmd->is_dev_to_host;
	desc->is_src_not_user_mem = 1;
	desc->is_src_dma_addr = 1;
	desc->dev_addr = *dev_addr;
	desc->dma_lenth = temp_size;
	desc->host_addr.dma_addr = *host_addr;

	return ret;
}


int vastai_ioctl_dma_start_set_desc(struct vastai_dmadesc* desc, struct dma_buf *dmabuf,
						   struct kchar_cmd* kcmd,
						   int i, u32 done_size, u32 temp_size,
						   struct vastai_pci_info *pci_info)
{
	int ret = 0;
	union core_bitmap core_id = { .val = 0 };
	struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);

	desc->is_host_to_dev = !kcmd->dma_start_cmd.is_dev_to_host;
	desc->is_src_not_user_mem = 1;
	desc->is_src_dma_addr = 1;
	desc->dev_addr = kcmd->dma_start_cmd.axi_addr + done_size;
	desc->dma_lenth = temp_size;
	desc->host_addr.dma_addr = dm->dma_bus_addr;
	ret = vastai_pci_dma_transfer_sync(pci_info, kcmd->dma_start_cmd.die_index,
					   core_id, desc, 1, -1);

	return ret;
}

int vastai_ioctl_dma_trans_set_desc_new(struct vastai_dmadesc* desc,
					void *dma_node, u64 *dev_addr,
					u32 temp_size, u64 *host_addr)
{
	int ret = 0;
	dma_node_trans_cmd_t* dma_trans_cmd = (dma_node_trans_cmd_t*)dma_node;

	desc->is_host_to_dev = !dma_trans_cmd->is_dev_to_host;
	desc->is_src_not_user_mem = 0;
	desc->is_src_dma_addr = 0;
	desc->dev_addr = *dev_addr;
	desc->dma_lenth = temp_size;
	desc->host_addr.vir_addr = (void*)*host_addr;

	return ret;
}


int vastai_ioctl_dma_trans_set_desc(struct vastai_dmadesc* desc, struct dma_buf *dmabuf,
						   struct kchar_cmd* kcmd, int i, u32 done_size,
						   u32 temp_size, struct vastai_pci_info *pci_info)
{
	int ret = 0;

	desc[i].is_host_to_dev = !kcmd->dma_trans_cmd.is_dev_to_host;
	desc[i].is_src_not_user_mem = 0;
	desc[i].is_src_dma_addr = 0;
	desc[i].dev_addr = kcmd->dma_trans_cmd.axi_addr + done_size;
	desc[i].dma_lenth = temp_size;
	desc[i].host_addr.vir_addr = (void *)(kcmd->dma_trans_cmd.vir_addr + done_size);

	return ret;
}

typedef int(*get_dev_host_addr_func)(int, struct dma_buf*, u64*, u64*, void*,u32);

int vastai_dma_start_get_host_addr(int i, struct dma_buf *dmabuf, u64 *host_addr, u64 *dev_addr, void *dma_node, u32 done_size)
{
	struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);
	dma_node_start_cmd_t *dma_start_cmd = (dma_node_start_cmd_t *)dma_node;

	*host_addr = dm->dma_bus_addr;
	*dev_addr  = dma_start_cmd->axi_addr + done_size;

	return 0;
}

int vastai_dma_trans_get_host_addr(int i, struct dma_buf *dmabuf, u64 *host_addr, u64 *dev_addr, void *dma_node, u32 done_size)
{
	dma_node_trans_cmd_t* dma_trans_cmd = (dma_node_trans_cmd_t*)dma_node;

	*host_addr = (u64)(dma_trans_cmd->vir_addr) + done_size;
	*dev_addr  = dma_trans_cmd->axi_addr + done_size;

	return 0;
}


int vastai_common_cut_dma_buf_new(struct vastai_pci_info *pci_info, void *dma_node, u32 size,
					struct vastai_dmadesc* desc, struct dma_buf *dmabuf, get_dev_host_addr_func pGetDevHostAddr,
					set_desc_func_new pSetDescFunc)
{
	int ret = 0;
	u32 done_size = 0;
	u32 i = 0;
	u64 host_addr = 0;
	u64 dev_addr  = 0;

	while (done_size < size) {
		u32 temp_size = min(pci_info->max_dma_node_size, size - done_size);

		ret = pGetDevHostAddr(i, dmabuf, &host_addr, &dev_addr, dma_node, done_size);
		if (ret)
			return ret;

		ret = pSetDescFunc(&(desc[i]), dma_node, &dev_addr, temp_size, &host_addr);
		if (ret)
			return ret;

		i++;
		done_size += temp_size;
	}

	return ret;
}

int vastai_common_cut_dma_buf(u32 size, struct kchar_cmd* kcmd, struct vastai_dmadesc* desc,
					struct vastai_pci_info *pci_info, struct dma_buf *dmabuf,
					set_desc_func pSetDescFunc)
{
	int ret = 0;
	u32 done_size = 0;
	u32 i = 0;

	while (done_size < size) {
		u32 temp_size = (size - done_size) < pci_info->max_dma_node_size ?
				(size - done_size) : pci_info->max_dma_node_size;

		ret = pSetDescFunc(desc, dmabuf, kcmd, i, done_size, temp_size, pci_info);
		if (ret)
			return ret;

		i++;
		done_size += temp_size;
	}

	return ret;
}

typedef int(*set_p2p_desc_func)(struct vastai_dmadesc*,
				  struct kchar_cmd*,
				  int, u32, u32,
				  struct vastai_pci_info*);

int vastai_ioctl_p2p_start_set_desc(struct vastai_dmadesc* desc, struct dma_buf *dmabuf,
						   struct kchar_cmd* kcmd,
						   int i, u32 done_size, u32 temp_size,
						   struct vastai_pci_info *pci_info)
{
	int ret = 0;

	desc[i].dev_addr = kcmd->p2p_start_cmd.local_addr + done_size;
	desc[i].host_addr.dma_addr = kcmd->p2p_start_cmd.remote_addr + done_size;
	desc[i].is_src_dma_addr = 1;
	desc[i].is_src_not_user_mem = 1;
	desc[i].is_host_to_dev = !kcmd->p2p_start_cmd.local_to_remote;
	desc[i].dma_lenth = temp_size;


	return ret;
}


int vastai_common_cut_p2p_buf(u32 size, struct kchar_cmd* kcmd, struct vastai_dmadesc* desc,
					struct vastai_pci_info *pci_info,
					set_desc_func pSetDescFunc)
{
	int ret = 0;
	u32 done_size = 0;
	u32 i = 0;

	while (done_size < size) {
		u32 temp_size = (size - done_size) < VASTAI_MAX_DMA_BUF ?
				(size - done_size) : VASTAI_MAX_DMA_BUF;

		ret = pSetDescFunc(desc, NULL, kcmd, i, done_size, temp_size, pci_info);
		if (ret)
			return ret;

		i++;
		done_size += temp_size;
	}

	return ret;
}

int vastai_pci_dma_trans(struct vastai_pci_info *pci_info, dma_node_trans_cmd_t *dma_trans_cmd)
{
	int ret = 0;
	union core_bitmap core_id = { .val = 0 };
	u32 size = dma_trans_cmd->length;
	struct vastai_dmadesc *desc;
	u32 entry_count;

	if (((u64)dma_trans_cmd->vir_addr % PAGE_SIZE == 0) &&
			((iommu_is_enable(pci_info) ||
			vastai_pci_dma_uaddr_linklist_on(dma_trans_cmd->die_index)))) {
		ret =  vastai_pci_dma_transfer_by_uaddr_new(pci_info,
							core_id,
							dma_trans_cmd);
	} else {
		entry_count = vast_div_round_up(size, pci_info->max_dma_node_size);
		desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
				GFP_KERNEL);

		vastai_common_cut_dma_buf_new(pci_info,
						dma_trans_cmd,
						size,
						desc,
						NULL,
						vastai_dma_trans_get_host_addr,
						vastai_ioctl_dma_trans_set_desc_new);

		/* confirm with Jingming, we can use sdma here */
		ret = pci_info->addr->p_dma_transfer_sync(pci_info,
								dma_trans_cmd->die_index,
								core_id,
								desc,
								entry_count, dma_trans_cmd->pid);

		kvfree(desc);
	}

	return ret;
}

int vastai_dma_sg_start_get_host_addr(int i, struct dma_buf *dmabuf, u64 *host_addr, u64 *dev_addr, void *dma_node, u32 done_size)
{
	if(0 == i) {
		dma_node_start_cmd_t *dma_start_cmd = (dma_node_start_cmd_t *)dma_node;
		struct vastai_dma_buf *dm =
			get_vastai_dma_buf(dmabuf, 0);

		if (dma_start_cmd->size > dm->size)
			return -EINVAL;

		*host_addr = sg_dma_address(dm->sg_table.sgl);
		*dev_addr  = dma_start_cmd->axi_addr;
	}

	return 0;
}

int vastai_dma_sg_set_desc_start(struct vastai_dmadesc* desc,
					void *dma_node,
					u64 *dev_addr,
					u32 dma_len,
					u64 *host_addr)
{
	dma_node_start_cmd_t *dma_start_cmd = (dma_node_start_cmd_t *)dma_node;

	desc->is_host_to_dev	  = !dma_start_cmd->is_dev_to_host;
	desc->is_src_not_user_mem = 1;
	desc->is_src_dma_addr	  = 1;
	desc->dev_addr		  = *dev_addr;
	desc->dma_lenth 	  = dma_len;
	desc->host_addr.dma_addr  = *host_addr;

	*dev_addr  = *dev_addr + dma_len;
	*host_addr = *host_addr + dma_len;

	return 0;
}

int vastai_pci_dma_p2p(struct vastai_pci_info *pci_info, dma_node_p2p_cmd_t *dma_p2p_cmd)
{
	int ret = 0;
	union core_bitmap core_id = { .val = 0 };
	struct vastai_dmadesc *desc;
	struct kchar_cmd kcmd;
	u32 size = 0, entry_count;

	kcmd.p2p_start_cmd.die_index = dma_p2p_cmd->die_index;
	kcmd.p2p_start_cmd.local_addr = dma_p2p_cmd->local_addr;
	kcmd.p2p_start_cmd.local_to_remote = dma_p2p_cmd->local_to_remote;
	kcmd.p2p_start_cmd.remote_addr = dma_p2p_cmd->remote_bar_addr;
	kcmd.p2p_start_cmd.size = dma_p2p_cmd->size;
	size = kcmd.p2p_start_cmd.size;

	if (!size) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s size is %d\n", __func__, size);
		return -EINVAL;
	}
	entry_count = vast_div_round_up(size, VASTAI_MAX_DMA_BUF);
	if (!entry_count) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s entry_count is %d\n", __func__, entry_count);
		return -EINVAL;
	}
	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
			GFP_KERNEL);
	if (!desc) {
		return -ENOMEM;
	}

	vastai_common_cut_p2p_buf(size, &kcmd, desc, pci_info,
				  vastai_ioctl_p2p_start_set_desc);
	ret = vastai_pci_dma_transfer_sync(pci_info,
					   kcmd.dma_trans_cmd.die_index,
					   core_id, desc, entry_count, -1);
	kvfree(desc);

	return ret;
}

int vastai_pci_dma_start(struct vastai_pci_info *pci_info, dma_node_start_cmd_t *dma_start_cmd)
{
	int ret = 0;
	struct vastai_dmadesc *desc;
	struct dma_buf *dmabuf =
		dma_buf_get(dma_start_cmd->dma_buf_fd);
	union core_bitmap core_id = { .val = 0 };
	u32 entry_count = vast_div_round_up(dma_start_cmd->size, pci_info->max_dma_node_size);

	if (!entry_count) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s entry_count is %d\n", __func__, entry_count);
		return -EINVAL;
	}
	if (IS_ERR(dmabuf)) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s dma buf fd is invalid\n", __func__);
		return PTR_ERR(dmabuf);
	}

	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
				GFP_KERNEL);

	ret = vastai_common_cut_dma_buf_new(pci_info,
						dma_start_cmd,
						dma_start_cmd->size,
						desc,
						dmabuf,
						pci_info->pDmaStartGetDevHostAddr,
						pci_info->pDmaStartSetDescFunc);
	if(ret)
		goto dma_free;

	ret = vastai_pcie_dma_transfer_sync(pci_info, dma_start_cmd->die_index,
						core_id,
						desc, entry_count);

dma_free:
	kvfree(desc);
	dma_buf_put(dmabuf);

	return ret;
}

static long ctl_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct vastai_ctl_file *ctl_info =
		(struct vastai_ctl_file *)filp->private_data;
	struct vastai_pci_info *pci_info = ctl_info->pci_info;
	struct kchar_cmd kcmd;
	int ret = 0;

	if ((atomic_read(&pci_info->pci_state) != VASTAI_NORMAL_STATE) &&
			(atomic_read(&pci_info->pci_state) != VASTAI_DEBUG_STATE))
		return -ENODEV;

	ret = copy_from_user_compact(&kcmd, (void *)arg, sizeof(kcmd));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s copy_from_user is error\n", __func__);
		return -EIO;
	}

	switch (cmd) {

	case VASTAI_PCI_IOCTL_ALLOC: {
		struct dma_buf *dmabuf;
		if (iommu_is_enable(pci_info))
			dmabuf = vastai_alloc_dma_buf_sg(
					pci_info,
					kcmd.alloc_cmd.size);
		else
			dmabuf = vastai_alloc_dma_buf(
					pci_info,
					kcmd.alloc_cmd.size);
		if (dmabuf) {
			int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
			kcmd.alloc_cmd.dma_buf_fd = fd;
		} else {
			kcmd.alloc_cmd.dma_buf_fd = -ENOMEM;
		}
		break;
	}
	case VASTAI_PCI_IOCTL_DMA_START: {
		ret = vastai_pci_dma_start(pci_info, &kcmd.dma_start_cmd);
		break;
	}
	case VASTAI_PCI_IOCTL_DMA_TRANS: {
		ret = vastai_pci_dma_trans(pci_info, &kcmd.dma_trans_cmd);

		break;
	}
	case VASTAI_PCI_IOCTL_DMA_TRANS_SG: {
		union core_bitmap core_id = { .val = 0 };
		struct vastai_channel_buf *channel_buf;
		int i;
		int channel_num = kcmd.dma_trans_sg_cmd.channel_num;

		channel_buf =
			kvmalloc(sizeof(struct vastai_channel_buf) *
					channel_num,
				GFP_KERNEL);
		if (!channel_buf) {
			return -ENOMEM;
		}
		ret = video_copy_from_user(
			channel_buf, (void*)kcmd.dma_trans_sg_cmd.channel_buf,
			sizeof(struct vastai_channel_buf) * channel_num);
		if (ret) {
			kvfree(channel_buf);
			return -1;
		}

		for (i = 0; i < channel_num; i++) {
			VASTAI_PCI_DBG(
				pci_info, kcmd.dma_trans_sg_cmd.die_index,
				"channel[%d], w:%d, h:%d, dst_w_off:%d, dst_h_off:%d, src_w_off:%d, src_h_off:%d\n",
				i, channel_buf[i].width, channel_buf[i].high,
				channel_buf[i].dst_width_offset,
				channel_buf[i].dst_high_offset,
				channel_buf[i].src_width_offset,
				channel_buf[i].src_high_offset);
		}

		vastai_dma_video(pci_info, kcmd.dma_trans_sg_cmd.die_index,
				 core_id, channel_buf, channel_num,
				 kcmd.dma_trans_sg_cmd.axi_addr,
				 kcmd.dma_trans_sg_cmd.pid);

		kvfree(channel_buf);
		break;
	}
	case VASTAI_PCI_IOCTL_MEMSET: {
		if(vastai_get_board_type(pci_info) == SV100) {
			u32 size = kcmd.dma_memset_cmd.length;
			struct device *dev = &(pci_info->dev->dev);
			dma_addr_t dma_bus_addr;
			u32 is_src_dma_addr = 1;
			u32 is_src_not_user_mem = 1;
			union core_bitmap core_id = { .val = 0 };
			struct vastai_dma_buf *dm = kmalloc(sizeof(struct vastai_dma_buf),  GFP_KERNEL);

			if(!dm){
				return -ENOMEM;
			}

			if(size < VASTAI_MAX_MEMSET_BUF){

				dm->vir = dma_alloc_coherent(dev, size, &dma_bus_addr,  GFP_KERNEL);
			}else{

				dm->vir = dma_alloc_coherent(dev, VASTAI_MAX_MEMSET_BUF, &dma_bus_addr,  GFP_KERNEL);
			}

			if(!dm->vir || !dma_bus_addr){
				VASTAI_PCI_ERR(pci_info,DUMMY_DIE_ID,
					"%s: dma_alloc_coherent fail\n",__func__);
				goto ERROR_FREE_DM;
			}


			memset(dm->vir, kcmd.dma_memset_cmd.val, size);

			ret = vastai_pci_dma_transfer_memset(
						pci_info,
						kcmd.dma_memset_cmd.die_index,
						core_id,
						dma_bus_addr,
						is_src_dma_addr,
						!kcmd.dma_memset_cmd.is_dev_to_host,
						is_src_not_user_mem,
						kcmd.dma_memset_cmd.axi_addr,
						kcmd.dma_memset_cmd.length);

			if(size < VASTAI_MAX_MEMSET_BUF){

				dma_free_coherent(dev, size, (void *)dm->vir, dma_bus_addr);

			}else{

				dma_free_coherent(dev, VASTAI_MAX_MEMSET_BUF, (void *)dm->vir, dma_bus_addr);
			}
ERROR_FREE_DM:
			kvfree(dm);
		} else if(vastai_get_board_type(pci_info) == SG100) {
			struct dma_buf *dmabuf = dma_buf_get(kcmd.dma_memset_cmd_sg.fd);
			struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, 0);

			if(!dm){
				return -ENOMEM;
			}

			if(!dm->vir || !dm->dma_bus_addr){
				VASTAI_PCI_ERR(pci_info,DUMMY_DIE_ID,
					"%s: dma_alloc_coherent fail\n",__func__);
				goto ERROR_FREE_DM_SG;
			}

			memset(dm->vir, kcmd.dma_memset_cmd_sg.val, kcmd.dma_memset_cmd_sg.size);

			ERROR_FREE_DM_SG:
			dma_buf_put(dmabuf);
			break;
		}

		break;
	}
	case VASTAI_PCI_IOCTL_P2P_START: {
		union core_bitmap core_id = { .val = 0 };
		struct vastai_dmadesc *desc;
		u32 size = kcmd.p2p_start_cmd.size;
		u32 entry_count = vast_div_round_up(size, VASTAI_MAX_DMA_BUF);

		if (!entry_count) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
					"%s entry_count is %d\n", __func__, entry_count);
			return -EINVAL;
		}
		desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
				GFP_KERNEL);
		if (!desc)
			return -ENOMEM;

		vastai_common_cut_p2p_buf(size,
					&kcmd,
					desc,
					pci_info,
					vastai_ioctl_p2p_start_set_desc);
		ret = vastai_pci_dma_transfer_sync(pci_info,
						kcmd.dma_trans_cmd.die_index,
						core_id,
						desc,
						entry_count, -1);
		kvfree(desc);
		if (ret)
			return ret;
		break;
	}
	case VASTAI_PCI_IOCTL_GET_BAR: {
		u32 bar_id = kcmd.get_bar_info_cmd.bar_id;
		if (bar_id > 4 || bar_id == 3 ) {
			int ret = 0;

			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "invalid bar id:%d\n", bar_id);
			ret = -EINVAL;
			return ret;
		}
		kcmd.get_bar_info_cmd.bar_address = (u64)pci_info->bar[bar_id].mmio_start;
		kcmd.get_bar_info_cmd.bar_size = (u64)pci_info->bar[bar_id].mmio_len;
		break;

	}
	case VASTAI_PCI_IOCTL_RENDER: {
		u32 die_index = kcmd.get_render_name.die_index;
		snprintf(kcmd.get_render_name.file_name,
			 sizeof(kcmd.get_render_name.file_name), "renderD%d",
			 pci_info->dies[vastai_pci_get_die_id(pci_info,
							      die_index)]
				 .render_id);
		printk("%s\n", kcmd.get_render_name.file_name);
		break;
	}
	case VASTAI_PCI_IOCTL_PORT: {
		strcpy(kcmd.port_name, pci_name(pci_info->dev));
		printk("%s\n", kcmd.port_name);
		break;
	}
	case VASTAI_PCI_IOCTL_GET_PERFORMANCE: {
		u32 die_index = kcmd.get_die_performance.die_index;
		int i = 0;

		for(i=0; i<SV100_MAX_VDSP_NUM; i++) {
			kcmd.get_die_performance.pcie_tx_vdsp_count[i] =
				pci_info->dies[vastai_pci_get_die_id(pci_info, die_index)].core[i+CORE_POINT_VDSP0].pcie_tx_core_count;
			kcmd.get_die_performance.pcie_rx_vdsp_count[i] =
				pci_info->dies[vastai_pci_get_die_id(pci_info, die_index)].core[i+CORE_POINT_VDSP0].pcie_rx_core_count;
		}
		break;
	}
	case VASTAI_PCI_IOCTL_CEDAR_CMD: {
		unsigned int reg_val ;
		int output_hash_len, type;
		u64 zero = 0;
		u64 zero_hash[8] = {0};
		int die_id = kcmd.cedar_ioctl.die_id;
		u32 die_index = 0;
		int count = 0;
		struct vastai_sv100_die *die ;
		if( die_id < 0 || die_id > 4)
			return die_id;
		die = (struct vastai_sv100_die*)&(pci_info->dies[die_id]);
		die_index = pci_info->dies[die_id].die_index;  //die_id -> die_index
		type = kcmd.cedar_ioctl.cedar_info.alg_type;
		if (type <= 3)
			output_hash_len = 28;
		else if (type <= 7)
			output_hash_len = 32;
		else if (type <= 11)
			output_hash_len = 48;
		else if (type <= 15)
			output_hash_len = 64;
		else if (type <= 19)
			output_hash_len = 32;
		else if (type <= 23)
			output_hash_len = 28;

		mutex_lock(&die->cedar_lock);
		vastai_pci_mem_write(pci_info, pci_info->dies[die_id].die_index,
				CEDAR_SVC_DONE_FLAG, &zero,
				4); 				//clear sts and done_flag
		ret = vastai_fifo_push_elem(pci_info, die_index,
						    CEDAR_SVC_INFO, (void*)&kcmd.cedar_ioctl.cedar_info, NULL);
		if(ret){
		       	VASTAI_PCI_INFO(pci_info, pci_info->dies[die_id].die_index,
                                "vastai_fifo_push_elem error!\n");
			mutex_unlock(&die->cedar_lock);
				return -1;
		}
		ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[die_id].die_index,
					   VASTAI_PCIE_SUB_CEDAR_SVC, 0);
		if(ret){
			 VASTAI_PCI_INFO(pci_info, pci_info->dies[die_id].die_index,
        		"kernel send cmd fail!\n");
			mutex_unlock(&die->cedar_lock);
			return -2;
		}
		do {
			vastai_pci_mem_read(pci_info, pci_info->dies[die_id].die_index,
					    CEDAR_SVC_DONE_FLAG, &reg_val, sizeof(reg_val));
			count++;
		} while((reg_val != 0xFF)&&(count < 0xFFFF));
		if(count >= 0xFFFF)
		{
			mutex_unlock(&die->cedar_lock);
			return -ETIMEDOUT;
		}
		if(type <= 23){
			vastai_pci_mem_read(pci_info, pci_info->dies[die_id].die_index,
						CEDAR_SVC_HASH_RES, (void*)kcmd.cedar_ioctl.cedar_res_info.hash,
					       	output_hash_len);
			vastai_pci_mem_write(pci_info, pci_info->dies[die_id].die_index,
						CEDAR_SVC_HASH_RES, (void*)zero_hash, 4);
		}
		mutex_unlock(&die->cedar_lock);
		break;
	}
	case VASTAI_PCI_IOCTL_PCI_ID:
                kcmd.get_pci_id.pci_id = pci_info->dev->vendor | pci_info->dev->device << 16;
		break;
	case VASTAI_PCI_IOCTL_PCI_SUB_ID:
		kcmd.get_pci_sub_id.pci_sub_id = 0xFFFF;
		break;
	case VASTAI_PCI_IOCTL_MAJOR_MINOR:
		kcmd.get_major_minor.major_minor = vastai_file_get_major_minor(&ctl_info->file_info);
		break;
	case TCGETS:
		return -ENOIOCTLCMD;

	case TCSETS:
		return -ENOIOCTLCMD;

	case TIOCSERGETLSR:
		return -ENOIOCTLCMD;

	case TIOCSERCONFIG:
		return -ENOIOCTLCMD;

	case VASTAI_PCI_IOCTL_RESET_NOTIFY: {
		int die_id = kcmd.reset_mode.die_id;
		if(kcmd.reset_mode.mode == RESET_NOTIFY_STOP) {
			init_completion(&pci_info->dies[die_id].reset_comp);
			ret = wait_for_completion_interruptible(&pci_info->dies[die_id].reset_comp);
			if (ret) {
				VASTAI_PCI_ERR(pci_info,
					       die_id,
					       "%s wait_for_completion error %d\n",
					       __FUNCTION__, ret);
			}
		} else if (kcmd.reset_mode.mode == RESET_STOP_COMPLETION) {
			//clear CMCU fifo
			ring_buf_elem_t ring_buf_elem;

			vastai_clear_fifo(pci_info, pci_info->dies[die_id].die_index, CORE_POINT_CMCU);

			ring_buf_elem.whole = 0;
			ring_buf_elem.cmd = CORE_2_CORE_RESET_CMD;
			ring_buf_elem.use_ringbuf =
				VATOOLS_INTERRUPT_NOT_USE_RINGBUF;
			ring_buf_elem.seq_no = 0;
			ring_buf_elem.sub_cmd = CORE_2_CORE_RESET_AI_RESET_SUBCMD;

			vastai_send_pcie_cmd(pci_info, pci_info->dies[die_id].die_index,
					     VASTAI_PCIE_SUB_AI_SYS_RESET, ring_buf_elem.whole);
		} else if (kcmd.reset_mode.mode == RESET_AI_SYS_DONE) {
			init_completion(&pci_info->dies[die_id].ai_reset_done);
			ret = wait_for_completion_interruptible(&pci_info->dies[die_id].ai_reset_done);
			if (ret) {
				VASTAI_PCI_ERR(pci_info,
					       vastai_pci_get_die_id(pci_info, pci_info->dies[die_id].die_index),
					       "%s wait_for_ai_completion error %d\n",
					       __FUNCTION__, ret);
			}
		}
		break;
	}
	case VASTAI_PCI_IOCTL_BOARD_TYPE:
		kcmd.board_type.type = vastai_get_board_type(pci_info);
		break;
	case VASTAI_PCI_IOCTL_DMA_CLOSE: {
		struct dma_buf *dmabuf = dma_buf_get(kcmd.dma_memset_cmd_sg.fd);
		dma_buf_put(dmabuf);

		break;
	}
	case VASTAI_PCI_IOCTL_DMA_FILL: {
		union core_bitmap core_id = { .val = 0 };

		ret = vastai_sdma_fill_data(
				pci_info,
				kcmd.dma_fill_cmd.die_index,
				core_id,
				kcmd.dma_fill_cmd.axi_addr,
				kcmd.dma_fill_cmd.data,
				kcmd.dma_fill_cmd.length);
		break;
	}
	case VASTAI_PCI_IOCTL_DMA_D2D: {
		u32 length = kcmd.dma_d2d_cmd.length;
		u64 src_addr = kcmd.dma_d2d_cmd.src_addr;
		u64 dst_addr = kcmd.dma_d2d_cmd.dst_addr;
		int pid = kcmd.dma_d2d_cmd.pid;
		ret = vastai_dev2dev_sdma_sync_pid(
				pci_info,
				kcmd.dma_d2d_cmd.die_index,
				src_addr,
				dst_addr,
				length,
				pid);
		break;
	}
	default:
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
				"Unsupport cmd 0x%x\n", cmd);
		break;
	}
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "ioctl error %d\n", ret);
		return ret;
	}

	ret = copy_to_user_compact((void *)arg, &kcmd, sizeof(kcmd));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s copy_to_user is error\n", __func__);
		return -EIO;
	}

	return 0;
}

static const struct file_operations fop = {
	.owner = THIS_MODULE,
	.open = ctl_open,
	.release = ctl_release,
	.llseek = default_llseek,
	.unlocked_ioctl = ctl_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = ctl_ioctl,
#endif
};
int vastai_ctl_file_init(struct vastai_pci_info *pci_info)
{
	struct vastai_ctl_file *ctl_file =
		vmalloc(sizeof(struct vastai_ctl_file));
	int ret;

	if (ctl_file == NULL) {
		return -ENOMEM;
	}
	ret = vastai_file_create(&ctl_file->file_info, pci_info, &fop,
				 "vastai%d_ctl", pci_info->dev_id);

	pci_info->ctl_file = ctl_file;
	ctl_file->pci_info = pci_info;

	return ret;
}

void vastai_ctl_file_deinit(struct vastai_pci_info *pci_info)
{
	vastai_file_destroy(&pci_info->ctl_file->file_info);
	vfree(pci_info->ctl_file);
}
