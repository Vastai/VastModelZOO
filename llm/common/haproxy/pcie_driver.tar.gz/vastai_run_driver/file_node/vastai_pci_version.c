/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/ctype.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/dma-buf.h>
#include <linux/proc_fs.h>
#include <linux/version.h>

#include "vastai_pci.h"
#define TEMP_BUF_SIZE 4*1024

#define VASTAI_DEV_INFO_DIR     "vastai"
#define VASTAI_DEV_INFO_NAME    "vastai_device"


static int version_open(struct inode *inode, struct file *filp)
{
	struct vastai_file_info *file_info;
	struct vastai_version_file *version_file;

	file_info = to_vastai_file_info(inode->i_cdev);
	version_file =
		container_of(file_info, struct vastai_version_file, file_info);

	filp->private_data = version_file;
	return 0;
}

static int version_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static int __sprint(void *dst_buf, char *src_buf)
{
	if (strlen(src_buf) == 0)
		return 0;

	return sprintf(dst_buf, "[%s]\n", src_buf);
}
static int version_sprint(void *buf, struct vastai_pci_info *pci_info)
{
	int ret = 0;
	int i = 0;

	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.smcu_ver);
	ret += sprintf(buf + ret, "[%s] [active]\n",
		       pci_info->dies[0].fw_ver.bmcu_ver);
	ret += sprintf(buf + ret, "[%s] [backup]\n",
		       pci_info->dies[0].fw_ver.bmcu_backup_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.vdmcu_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.vemcu_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.vdsp_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.cmcu_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.lmcu_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.odsp_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.driver_ver);
	ret += __sprint(buf + ret, pci_info->dies[0].fw_ver.phy_ver);

	for (i = 0; i < pci_info->die_num_in_fn; i++) {
		struct vastai_fw_bmcu_xspi_version *bmcu_xspi_ver;
		bmcu_xspi_ver = (struct vastai_fw_bmcu_xspi_version *)
				pci_info->dies[i].fw_ver.bmcu_ver;

		ret += sprintf(buf + ret, "[die %d] [%s] [active]\n",
				i, bmcu_xspi_ver->xspi_sub_ver);

		bmcu_xspi_ver = (struct vastai_fw_bmcu_xspi_version *)
				pci_info->dies[i].fw_ver.bmcu_backup_ver;
		ret += sprintf(buf + ret, "[die %d] [%s] [backup]\n",
				i, bmcu_xspi_ver->xspi_sub_ver);
	}

	return ret;
}

static ssize_t version_read(struct file *filp, char __user *buffer,
			    size_t count, loff_t *offset)
{
	struct vastai_version_file *version_file = filp->private_data;
	struct vastai_pci_info *pci_info = version_file->pci_info;
	void *buf = vmalloc(TEMP_BUF_SIZE);
	int ret;

	if ((count < sizeof(pci_info->dies[0].fw_ver) * 2) || (*offset != 0)){
		vfree(buf);
		return 0;
	}

	ret = version_sprint(buf, pci_info);
	*offset += ret;

	if (copy_to_user(buffer, buf, ret)) {
		vfree(buf);
		return -EIO;
	}
	vfree(buf);
	return ret;
}

static const struct file_operations fop = {
	.owner = THIS_MODULE,
	.open = version_open,
	.release = version_release,
	.read = version_read,
};

int vastai_version_file_init(struct vastai_pci_info *pci_info)
{
	struct vastai_version_file *version_file =
		vmalloc(sizeof(struct vastai_version_file));
	int ret;

	if (version_file == NULL) {
		return -ENOMEM;
	}
	ret = vastai_file_create(&version_file->file_info, pci_info, &fop,
				 "vastai%d_version", pci_info->dev_id);

	pci_info->version_file = version_file;
	version_file->pci_info = pci_info;

	return ret;
}

void vastai_version_file_deinit(struct vastai_pci_info *pci_info)
{
	vastai_file_destroy(&pci_info->version_file->file_info);
	vfree(pci_info->version_file);
}

static int device_info_sprint(void *buf, struct vastai_pci_info *pci_info)
{
	int ret = 0;
	int i;

	ret += sprintf(buf + ret, "[device]\n");
	ret += sprintf(buf + ret, "dev_id = \"%d\"\n", pci_info->dev_id);
	ret += sprintf(buf + ret, "uuid = \"%s\"\n", pci_info->sn);
	ret += sprintf(buf + ret, "bus_id = \"%s\"\n", VASTAI_GET_PCI_NAME(pci_info));
	ret += sprintf(buf + ret, "card_type = \"%s\"\n", pci_info->card_type);
	ret += sprintf(buf + ret, "vatools_path = \"%s\"\n", "vatools");
	ret += sprintf(buf + ret, "kchar_path = \"kchar:%d\"\n", pci_info->dev_id);
	ret += sprintf(buf + ret, "version_path = \"vastai%d_version\"\n", pci_info->dev_id);
	ret += sprintf(buf + ret, "ctl_path = \"vastai%d_ctl\"\n",pci_info->dev_id);
	ret += sprintf(buf + ret, "\n");
	for (i= 0; i < pci_info->die_num_in_fn; i ++) {
		ret += sprintf(buf + ret, "[die.%d]\n", i);
		ret += sprintf(buf + ret, "die_id = \"%d\"\n", i);
		ret += sprintf(buf + ret, "vacc_path = \"vacc%d\"\n", vastai_get_vacc_id(pci_info, pci_info->dies[i].die_index));
		ret += sprintf(buf + ret, "render_path = \"dri/renderD%d\"\n",vastai_get_render_id(pci_info, pci_info->dies[i].die_index));
		ret += sprintf(buf + ret, "card_path = \"dri/card%d\"\n", vastai_get_card_id(pci_info, pci_info->dies[i].die_index));
		ret += sprintf(buf + ret, "video_path = \"vastai_video%d\"\n", vastai_get_seq_num(pci_info, i));
		ret += sprintf(buf + ret, "\n");
	}
	return ret;
}

static ssize_t device_info_proc_read(struct file *filp, char __user *buffer,
			    size_t count, loff_t *offset)
{
	struct vastai_version_file *version_file = filp->private_data;
	struct vastai_pci_info *pci_info = version_file->pci_info;
	void *buf = vmalloc(TEMP_BUF_SIZE);
	int ret;

	if (*offset != 0) {
		vfree(buf);
		return 0; // 读取结束
	}

	ret = device_info_sprint(buf, pci_info);
	*offset += ret;

	if (copy_to_user(buffer, buf, ret)) {
		vfree(buf);
		return -EIO;
	}
	vfree(buf);
	return ret;
}

static int device_info_proc_open(struct inode *inode, struct file *file)
{
	struct vastai_file_info *file_info;
	struct vastai_version_file *version_file;

	file_info = to_vastai_file_info(inode->i_cdev);
	version_file =
		container_of(file_info, struct vastai_version_file, file_info);

	file->private_data = version_file;
	return 0;

}
static int device_info_proc_release(struct inode *inode, struct file *filp)
{
	return 0;
}


static  struct file_operations device_info_ops = {
	.owner   = THIS_MODULE,
	.open    = device_info_proc_open,
	.release = device_info_proc_release,
	.read    = device_info_proc_read,
};

extern int vatools_get_spi_buf(u32 die_index, u32 unit, u64 address, u32 len,
			void *spi_buf);

extern int vastai_is_file_exist(char *path);
#define product_len            96
#define sn_offset                      60
#define card_type_offset       4
int vastai_device_info_init(struct vastai_pci_info *pci_info) {
	struct vastai_version_file *device_info_file =
		vmalloc(sizeof(struct vastai_version_file));
	void *buf = vzalloc(128);
	int ret;

	if (!buf) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "vmaloc failed\n");
		return -1;
	}


	sprintf(buf, "%s%d",VASTAI_DEV_INFO_NAME, pci_info->dev_id);
	if (device_info_file == NULL) {
		return -ENOMEM;
	}
	ret = vastai_file_create(&device_info_file->file_info, pci_info, &device_info_ops,
				 "vastai_device_info%d", pci_info->dev_id);

	pci_info->device_info_file = device_info_file;
	device_info_file->pci_info = pci_info;

#ifndef CONFIG_VASTAI_AI_EMU
	vatools_get_spi_buf(pci_info->dies[0].die_index, 4, 0, product_len, buf);
	if (((char*)buf)[0] == 'V' && ((char*)buf)[1] == '2') {
		memcpy(pci_info->sn, ((char*)buf + sn_offset), SN_LEN - 1);
		memcpy(pci_info->card_type, ((char*)buf + card_type_offset), TYPE_LEN -1);
	}
	else
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "product version is V1, no parse\n");
#endif

	vfree(buf);
	return ret;

}

void vastai_device_info_deinit(struct vastai_pci_info *pci_info) {
	vastai_file_destroy(&pci_info->device_info_file->file_info);
	vfree(pci_info->device_info_file);
}
