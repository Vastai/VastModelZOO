#include <linux/compat.h>
#include <linux/thread_info.h>
#include <linux/uaccess.h>
#ifdef CONFIG_VASTAI_KUNIT
#include "stub.h"
#endif

/**
 * 0: 64bit
 * 1: 32bit
*/
int context_is_32_bit(void)
{
	int is_32_bit = 0;
#if (defined(__aarch64__) || defined(__arm__))
	is_32_bit = test_thread_flag(TIF_32BIT);
#else
	is_32_bit = test_thread_flag(TIF_ADDR32);
#endif
	return is_32_bit;
}

unsigned long copy_to_user_compact(void __user *to, const void *from,
			      unsigned long n)
{
	unsigned long ret = 0;

#ifdef CONFIG_COMPAT
	if (context_is_32_bit()) {
		ret = copy_to_user(
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)to) & 0xffffffff)),
			from, n);

		return ret;
	} else
#endif
	{
		ret = copy_to_user(to, from, n);

		return ret;
	}
	return ret;
}

unsigned long copy_from_user_compact(void *to, const void __user *from,
				unsigned long n)
{
	unsigned long ret = 0;

#ifdef CONFIG_COMPAT
	if (context_is_32_bit()) {
		ret = copy_from_user(
			to,
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)from) & 0xffffffff)),
			n);

		return ret;
	} else
#endif
	{
		ret = copy_from_user(to, from, n);
		return ret;
	}

	return ret;
}

u32 vast_div_round_up(u64 numerator, u64 denominator)
{
	return (u32)(DIV_ROUND_UP(numerator, denominator));
}
