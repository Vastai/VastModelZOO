#include "vastai_pci.h"
#include "vastai_fifo.h"

static inline void vastai_fifo_print(struct vastai_pci_info *pci_info,
				     u32 die_id, struct vastai_fifo *fifo,
				     char *head)
{
	VASTAI_PCI_DBG(
		pci_info, die_id,
		"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n", head,
		fifo->rd, fifo->wr, fifo->elem_count, fifo->elem_size);
}

int vastai_fifo_push_elem_local_fifo(void *pci_info, int die_index, u64 elem_start_addr,
						struct vastai_fifo *fifo, void *elem)
{
	int ret = 0;
	u64 entry_addr = 0;

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(push) read fifo[0x%llx]:", (u64)fifo);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	if (vastai_fifo_is_full(fifo))
		return -ENOMEM;
	if (!vastai_is_fifo_valid(fifo))
		return -EFAULT;

	entry_addr = elem_start_addr + (fifo->elem_size * fifo->wr);
	ret = vastai_pci_mem_write(pci_info, die_index, entry_addr, elem,
				fifo->elem_size);
	if (ret)
		return -ret;

	fifo->wr = (fifo->wr + 1) % (fifo->elem_count);

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(push) write fifo[0x%llx]:", (u64)fifo);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	return 0;
}


/**
 * @brief : push a elem into device fifo.
 *
 * @param pci_info : pointer to the pcie device.
 * @param die_index : union die_index_data.
 * @param fifo_addr : device address of fifo.
 * @param elem : object which need push.
 * @param fifo : return val, for the fifo cache. If it be give, this function
 * 		 will be more quickly.
 *
 * @return int : success is zero. other is errno.
 */
int vastai_fifo_push_elem(void *pci_info, int die_index, u64 fifo_addr,
			  void *elem, struct vastai_fifo *fifo)
{
	int ret = 0;
	u64 entry_addr = 0;
	struct vastai_fifo _fifo = { 0 };

	/* user not need cache */
	if (!fifo)
		fifo = &_fifo;

	/* flash cache */
	if ((fifo == &_fifo)
	    || !vastai_is_fifo_valid(fifo)
	    || vastai_fifo_is_full(fifo)) {
		if (likely(fifo->elem_count != 0 && fifo->elem_size != 0)) {
			ret = vastai_pci_mem_read(pci_info, die_index, fifo_addr, fifo,
						  sizeof(struct vastai_fifo) - 8);
		} else {
			ret = vastai_pci_mem_read(pci_info, die_index, fifo_addr, fifo,
						  sizeof(struct vastai_fifo));
		}

		if (ret)
			return -ret;
		if (vastai_fifo_is_break(fifo)) {
			VASTAI_PCI_ERR(pci_info,  vastai_pci_get_die_id(pci_info, die_index),
				"(%s)rd:%x,wr:%x,count:%x,size:%x\n", __FUNCTION__,
				fifo->rd, fifo->wr, fifo->elem_count, fifo->elem_size);
			return -ENXIO;
		}
	}

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(push) read fifo[0x%llx]:", fifo_addr);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	if (vastai_fifo_is_full(fifo))
		return -ENOMEM;
	if (!vastai_is_fifo_valid(fifo))
		return -EFAULT;

	entry_addr = fifo_addr + vastai_fifo_wr_next(fifo);
	ret = vastai_pci_mem_write(pci_info, die_index, entry_addr, elem,
				   fifo->elem_size);
	if (ret)
		return -ret;

	ret = vastai_pci_mem_write(pci_info, die_index,
				   fifo_addr + offsetof(struct vastai_fifo, wr),
				   &(fifo->wr), sizeof(fifo->wr));
	if (ret)
		return -ret;

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(push) write fifo[0x%llx]:", fifo_addr);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	return 0;
}

int vastai_fifo_pop_elem_local_fifo(void *pci_info, int die_index, u64 elem_start_addr,
						struct vastai_fifo *fifo, void *elem)
{
	int ret = 0;
	u64 entry_addr = 0;

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(pop) read fifo[0x%llx]:", (u64)fifo);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	if (vastai_fifo_is_empty(fifo))
		return -ENOMEM;
	if (!vastai_is_fifo_valid(fifo))
		return -EFAULT;

	if (elem) {
		entry_addr = elem_start_addr + (fifo->elem_size * fifo->rd);
		ret = vastai_pci_mem_read(pci_info, die_index, entry_addr, elem,
					  fifo->elem_size);
		if (ret)
			return -ret;
	}

	fifo->rd = (fifo->rd + 1) % (fifo->elem_count);

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(pop) write fifo[0x%llx]:", (u64)fifo);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	return 0;
}


/**
 * @brief pop a elem from device fifo.
 *
 * @param pci_info : pointer to the pcie device
 * @param die_index : union die_index_data
 * @param fifo_addr : device address of fifo.
 * @param elem : return value, object which be poped.
 * @param fifo : return val, for the fifo cache. If it be give, this function
 * 		 will be more quickly.
 * @return int : success is zero. other is errno.
 */
int vastai_fifo_pop_elem(void *pci_info, int die_index, u64 fifo_addr,
			 void *elem, struct vastai_fifo *fifo, u8 fifo_type)
{
	int ret = 0;
	u64 entry_addr = 0;
	struct vastai_fifo _fifo = { 0 };

	/* user not need cache */
	if (!fifo)
		fifo = &_fifo;

	/* flash cache */
	if ((fifo == &_fifo)
	    || !vastai_is_fifo_valid(fifo)
	    || vastai_fifo_is_empty(fifo)) {

		if(likely(fifo_type == NORMAL_FIFO)) {
			if (likely(fifo->elem_count != 0 && fifo->elem_size != 0)) {
				ret = vastai_pci_mem_read(pci_info, die_index, fifo_addr, fifo,
							  sizeof(struct vastai_fifo) - 8);
			} else {
				ret = vastai_pci_mem_read(pci_info, die_index, fifo_addr, fifo,
							  sizeof(struct vastai_fifo));
			}
		}
		else
			ret = vastai_pci_mem_read_direct(pci_info, die_index, fifo_addr, fifo,
						  sizeof(struct vastai_fifo));
		if (ret)
			return -ret;
		if (vastai_fifo_is_break(fifo)) {
			VASTAI_PCI_ERR(pci_info,  vastai_pci_get_die_id(pci_info, die_index),
				"(%s)rd:%x,wr:%x,count:%x,size:%x, fifo_addr:0x%llx\n", __FUNCTION__,
				fifo->rd, fifo->wr, fifo->elem_count, fifo->elem_size, fifo_addr);
			return -ENXIO;
		}
	}

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(pop) read fifo[0x%llx]:", fifo_addr);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	if (vastai_fifo_is_empty(fifo))
		return -ENOMEM;
	if (!vastai_is_fifo_valid(fifo))
		return -EFAULT;

	entry_addr = fifo_addr + vastai_fifo_rd_next(fifo);

	if (elem) {
		if(fifo_type == NORMAL_FIFO)
			ret = vastai_pci_mem_read(pci_info, die_index, entry_addr, elem,
						  fifo->elem_size);
		else
			ret = vastai_pci_mem_read_direct(pci_info, die_index, entry_addr, elem,
						  fifo->elem_size);
		if (ret)
			return -ret;
	}

	if(fifo_type == NORMAL_FIFO)
		ret = vastai_pci_mem_write(pci_info, die_index,
					   fifo_addr + offsetof(struct vastai_fifo, rd),
					   &(fifo->rd), sizeof(fifo->rd));
	else
		ret = vastai_pci_mem_write_direct(pci_info, die_index,
					   fifo_addr + offsetof(struct vastai_fifo, rd),
					   &(fifo->rd), sizeof(fifo->rd));
	if (ret)
		return -ret;

	if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {
		char print_string[128];
		sprintf(print_string, "(pop) write fifo[0x%llx]:", fifo_addr);
		vastai_fifo_print(pci_info, die_index, fifo, print_string);
	}
	return 0;
}

