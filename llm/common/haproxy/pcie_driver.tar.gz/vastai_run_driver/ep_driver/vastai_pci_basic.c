/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/aer.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/version.h>
#include <linux/rtc.h>


#include <linux/timer.h>

#include "vastai_pci.h"
#include "vastai_pci_api.h"
#ifdef CONFIG_VASTAI_PCI_BOOT
#include "vastai_pci_boot.h"
#endif
#include "vastai_pci_test.h"
#include "vastai_udma_engine.h"
#include "vastai_version.h"
#include "vastai_msgq.h"

#ifdef CONFIG_VASTAI_AI
#include "vastai_ai.h"
#endif

#ifdef CONFIG_VASTAI_LOGSYS
#include "vastai_logsys.h"
#endif

#ifdef CONFIG_VASTAI_TOOLS_SUITE
#include "vatools_export.h"
#endif

#ifdef CONFIG_VASTAI_VIDEO
#include "vastai.h"
#include "vastai_enc.h"
#include "vastai_render.h"

#endif

#ifdef CONFIG_VASTAI_RAS
#include "vastai_ras.h"
#endif

#include <linux/fs.h>
#include <linux/uaccess.h>
#include "vastai_dmabuf.h"
#include "vastai_dmi_table.h"
#include "vastai_fifo.h"
#include "vastai_die.h"
#include "vastai_avfs.h"
#include "vastai_state.h"
#include "vatools.h"
#include "vastai_export_api.h"
#include "vastai_cmd.h"
#include "hw_config.h"
#include "vastai_ai_info.h"
#include "hw/va_hw_init.h"
#include "sg100_cmd.h"
#include "logsys.h"
#include "exception.h"
#include "sg100_pcie_wrap.h"
#include "vastai_fw_hex.h"
#include "vastai_download_fw.h"
#include "smmu.h"
#include "vastai_udma_engine.h"


#define FN_CSRAM_BASE_ADDR               0x800000
#define FN_GFX_CSR_BASE_ADDR             0xC00000
#define FN_SMU_CSR_BASE_ADDR             0x920000
#define FN_PCIE_WRAPER_BASE_ADDR         0x942000
#define FN_PCIE_WRAPER_BASE_LIMIT        0x944000
#define FN_DDR_BASE_ADDR                 0x1040000000ULL
//#define SG_DDR_BASE_ADDR                 0x1000000000ULL
#define CORE_LOG_BASE_ADDR				 0x812300000
#define CORE_LOG_SIZE				 	 0x100000

#define BAR2_CSRAM_01                    0
#define BAR2_SMU_CSR                     1
#define BAR2_GFX_CSR                     2
#define BAR2_CSRAM_02                    3

#define ACCESS_PCIE_WRAPER               0
#define ACCESS_CSRAM                     1
#define ACCESS_SMU_CSR                   2
#define ACCESS_GFX_CSR                   3
#define ACCESS_DDR                       4

#define PCIE_ACCESS_LOG                  0



#ifdef CONFIG_VASTAI_KUNIT
#include "stub.h"
#endif

#define VASTAI_PCIE_2_SMCU 0
#define VASTAI_PCIE_2_VDSP 1
#define VASTAI_PCIE_2_CMCU 1

#define VASTAI_HEARTBEAT_ENABLE 1

static bool msi_enabled = 1;

module_param(msi_enabled, bool, 0644);

bool uaddr_linklist_en = false;
module_param(uaddr_linklist_en, bool, 0644);
MODULE_PARM_DESC(uaddr_linklist_en, "Vastai user mem dma linklist enable, bool");


static int vf_num = 0;
module_param(vf_num, int, 0);


unsigned char vastai_pci_log_level =
	VASTAI_PCI_NORMAL_LEVEL | VASTAI_PCI_DATA_LEVEL | VASTAI_PCI_PERF_LEVEL;
module_param(vastai_pci_log_level, byte, 0644);
MODULE_PARM_DESC(vastai_pci_log_level,
		 "Vastai's log level, please select in 0xf/0xd/0x0 ");

bool vastai_pci_reset_out = 1;
module_param(vastai_pci_reset_out, bool, 0644);
MODULE_PARM_DESC(vastai_pci_reset_out, "Vastai Exit with reset, bool ");

static bool core_exception_en = 1;
module_param(core_exception_en, bool, 0644);
MODULE_PARM_DESC(core_exception_en , "Vastai core exeption enable ");

static bool exception_log_en = 1;
module_param(exception_log_en, bool, 0644);
MODULE_PARM_DESC(exception_log_en , "Vastai core exeption log in dmesg enable ");

static int exception_log_interval = 180;
module_param(exception_log_interval, int, 0644);

#ifdef CONFIG_VASTAI_DEBUG_BOOT_FAILED
static bool boot_failed_debug = 1;
#else
static bool boot_failed_debug = 0;
#endif
module_param(boot_failed_debug, bool, 0644);
MODULE_PARM_DESC(boot_failed_debug , "Vastai boot failed debug");

static bool set_bar_debug_en = 1;
module_param(set_bar_debug_en, bool, 0644);
MODULE_PARM_DESC(set_bar_debug_en , "Vastai set bar debug");

u32 cardtype = UINT_MAX;
module_param(cardtype, uint, 0644);
MODULE_PARM_DESC(cardtype , "Vastai card type");

bool onedie = 0;
module_param(onedie, bool, 0644);
MODULE_PARM_DESC(onedie , "Vastai force single die");

bool parallel_load = 0;
module_param(parallel_load, bool, 0644);
MODULE_PARM_DESC(parallel_load , "Vastai concurrent probe");

u32 bbox = UINT_MAX;
module_param(bbox, uint, 0644);
MODULE_PARM_DESC(bbox , "Vastai bboxtype");

bool corewq = 0;
module_param(corewq, bool, 0644);
MODULE_PARM_DESC(corewq , "Vastai core irq workqueue");

bool dpm = 0;
module_param(dpm, bool, 0644);
MODULE_PARM_DESC(dpm , "Vastai dpm enable/disable");


#ifdef CONFIG_VASTAI_KUNIT
struct list_head vastai_pci_info_list;
#else
struct list_head vastai_pci_info_list;
#endif
struct mutex vastai_pci_info_list_lock;
char g_devId = 0;


struct mutex vastai_print_fw_logs_lock;

struct list_head vastai_card_info_list;
struct mutex vastai_card_info_list_lock;

struct vastai_addr_info vastai_global_addr_info[TYPE_UNKNOWN];
struct mutex vastai_service_module_lock;


struct list_head vastai_minor_list;

struct mutex vastai_pci_modify_lock;
struct mutex vastai_smcu_modify_lock;
u32 test_smcu_RW_Perf = 0;
u32 test_PCIe_Perf = 0;

struct list_head vastai_tools_devs_list;
struct rw_semaphore tools_devs_rw_sem;

extern void vastai_set_payload_work(struct vastai_pci_info *bus);
extern void vastai_cancel_payload_work(struct vastai_pci_info *bus);


u32 ai_group[] = {HEARTBEAT_CMCU, HEARTBEAT_LMCU0, HEARTBEAT_LMCU1, HEARTBEAT_LMCU2,
		  HEARTBEAT_LMCU3, HEARTBEAT_LMCU4, HEARTBEAT_LMCU5, HEARTBEAT_LMCU6,
		  HEARTBEAT_LMCU7, HEARTBEAT_ODSP0, HEARTBEAT_ODSP1, HEARTBEAT_ODSP2,
		  HEARTBEAT_ODSP3, HEARTBEAT_ODSP4, HEARTBEAT_ODSP5, HEARTBEAT_ODSP6,
		  HEARTBEAT_ODSP7};

vastai_reset_handle g_reset_ai_handle = NULL;
vastai_reset_handle g_reset_video_handle = NULL;

bool drv_rm_flag = false;

u64 *bar_addr_info;

int vastai_get_upstream_pcie_bw(struct vastai_pci_info *priv, u32 die_id_in_fn, int type, u64 *upstream_count)
{
	int ret = 0;
	struct vastai_card_info* card_info = vastai_get_card_info(priv);

	switch(type) {
		case BW_H_WITH_D_TYPE:
			if(die_id_in_fn!=0)
				ret = -ENOMEM;
			else
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_UPSTREAM,
								upstream_count, sizeof(u64));
			break;
		case BW_D_WITH_D_TYPE:
			if(0==die_id_in_fn) {
				if(card_info->die_num_in_card>1)
					ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_UPSTREAM,
									upstream_count, sizeof(u64));
				else
					ret = -ENOMEM;
			} else if(1==die_id_in_fn || 3==die_id_in_fn) {
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_UPSTREAM,
								upstream_count, sizeof(u64));
			} else if(2==die_id_in_fn)
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_UPSTREAM,
									upstream_count, sizeof(u64));
			break;
		case BW_PKG_WITH_PKG_TYPE:
			if(1==die_id_in_fn) {
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_UPSTREAM,
									upstream_count, sizeof(u64));
			} else if(2==die_id_in_fn){
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_UPSTREAM,
									upstream_count, sizeof(u64));
			} else {
				ret = -ENOMEM;
			}
			break;
		default:
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					"%s unknown type[%d]!\n", __func__, type);
			ret = -ENOMEM;
			break;
	}

	return ret;
}

int vastai_get_downstream_pcie_bw(struct vastai_pci_info *priv, u32 die_id_in_fn, int type, u64 *downstream_count)
{
	int ret = 0;
	struct vastai_card_info* card_info = vastai_get_card_info(priv);

	switch(type) {
		case BW_H_WITH_D_TYPE:
			if(die_id_in_fn!=0)
				ret = -ENOMEM;
			else
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DOWNSTREAM,
								downstream_count, sizeof(u64));
			break;
		case BW_D_WITH_D_TYPE:
			if(0==die_id_in_fn) {
				if(card_info->die_num_in_card>1)
					ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_DOWNSTREAM,
									downstream_count, sizeof(u64));
				else
					ret = -ENOMEM;
			} else if(1==die_id_in_fn || 3==die_id_in_fn) {
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DOWNSTREAM,
								downstream_count, sizeof(u64));
			} else if(2==die_id_in_fn)
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_DOWNSTREAM,
									downstream_count, sizeof(u64));
			break;
		case BW_PKG_WITH_PKG_TYPE:
			if(1==die_id_in_fn) {
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DIE_DOWNSTREAM,
									downstream_count, sizeof(u64));
			} else if(2==die_id_in_fn){
				ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id_in_fn), PCIE_BANDWIDTH_DOWNSTREAM,
									downstream_count, sizeof(u64));
			} else {
				ret = -ENOMEM;
			}
			break;
		default:
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					"%s unknown type[%d]!\n", __func__, type);
			ret = -ENOMEM;
			break;
	}

	return ret;
}

void vastai_reset_handle_reg(vastai_reset_handle handle)
{
	g_reset_ai_handle = handle;
}

void vastai_video_reset_handle_reg(vastai_reset_handle handle)
{
	g_reset_video_handle = handle;
}

u32 ai_core_mask(void)
{
	int i = 0;
	u32 mask = 0;
	for(i = 0; i < ARRAY_SIZE(ai_group); i++) {
		mask |= (1 << ai_group[i]);
	}
	return mask;
}

bool vastai_is_find_pci_info(struct vastai_pci_info *pci_info)
{
	struct vastai_pci_info *ploop = NULL;

	mutex_lock(&vastai_pci_info_list_lock);
	list_for_each_entry(ploop, &vastai_pci_info_list, dev_list) {
		if(ploop == pci_info) {
			mutex_unlock(&vastai_pci_info_list_lock);
			return true;
		}
	}
	mutex_unlock(&vastai_pci_info_list_lock);

	return false;
}

int get_vastai_die_info(struct vastai_pci_info *priv, int die_index[],
			int *die_num)
{
	int i = 0;

	if (!die_index || !priv) {
		return -EINVAL;
	}
	for (i = 0; i < priv->die_num_in_fn; i++) {
		die_index[i] = priv->dies[i].die_index;
	}
	*die_num = priv->die_num_in_fn;
	return 0;
}

int vastai_pci_get_sriov_numvfs(char dev_id)
{
	int vf_num = 0;
	struct vastai_pci_info *pcie_dev = NULL;
	pcie_dev = get_vastai_pci_device_info(dev_id);
	if (pcie_dev == NULL) {
		VASTAI_PCI_ERR(pcie_dev, DUMMY_DIE_ID,
				"%s Get vastai_pci_info failed!\n", __func__);
		return 0;
	}
	if (!pcie_dev->is_physfn) {
		VASTAI_PCI_ERR(pcie_dev, DUMMY_DIE_ID,
				"%s Please go back to PF driver to query again!\n", __func__);
		return 0;
	}
	vf_num = pci_num_vf(pcie_dev->dev);
	VASTAI_PCI_DBG(pcie_dev, DUMMY_DIE_ID,
			"Get sriov_numvfs: %d\n", vf_num);
	return vf_num;
}

struct vastai_pci_info *get_vastai_pci_device_info(char dev_id)
{
	struct vastai_pci_info *pci_info = NULL;

	mutex_lock(&vastai_pci_info_list_lock);
	if (list_empty(&vastai_pci_info_list)) {
		mutex_unlock(&vastai_pci_info_list_lock);
		return NULL;
	}

	/* for now, we only get first entry */
	list_for_each_entry(pci_info, &vastai_pci_info_list, dev_list) {
		if (pci_info->dev_id == dev_id) {
			mutex_unlock(&vastai_pci_info_list_lock);
			return pci_info;
		}
	}
	mutex_unlock(&vastai_pci_info_list_lock);
	return NULL;
}

u64 vastai_get_host_time_ns(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,6,0)
	struct timespec time;
#else
	u64 time;
#endif
	u64 time_ns;


#if LINUX_VERSION_CODE < KERNEL_VERSION(5,6,0)
	/* getnstimeofday function is removed from kernel5.6 */
	getnstimeofday(&time);
#else
	time = ktime_get_real_ns();
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(5,6,0)
	time_ns = timespec_to_ns(&time);
#else
	time_ns = time;
#endif

	return time_ns;
}

int get_vastai_pci_device_number(void)
{
	struct list_head *ptr = NULL;
	int device_num = 0;

	mutex_lock(&vastai_pci_info_list_lock);
	if (list_empty(&vastai_pci_info_list)) {
		mutex_unlock(&vastai_pci_info_list_lock);
		return 0;
	}

	list_for_each(ptr, &vastai_pci_info_list) {
		device_num++;
	}
	mutex_unlock(&vastai_pci_info_list_lock);
	return device_num;
}

static unsigned char *vastai_pci_bar_vmem(struct vastai_pci_info *priv, int bar)
{
	if (!priv) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "vastai pcie_dev is NULL\n");
		return NULL;
	}

	return priv->bar[bar].vmem;
}

int vastai_pci_config_read(struct vastai_pci_info *priv, int offset, char *buf,
			   int len)
{
	int i = 0, ret = 0;

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s priv 0x%p or dev 0x%p is NULL\n", __func__,
			       priv, priv->dev);
		return -ENXIO;
	}
	for (i = 0; i < len; i++) {
		ret = pci_read_config_byte(priv->dev, i + offset, &(buf[i]));
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s err=%d\n",
				       __func__, ret);
			return -1;
		}
	}
	return 0;
}

int vastai_pci_config_write(struct vastai_pci_info *priv, int offset, char *buf,
			    int len)
{
	int i = 0, ret = 0;

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s priv 0x%p or dev 0x%p is NULL\n", __func__,
			       priv, priv->dev);
		return -ENXIO;
	}
	for (i = 0; i < len; i++) {
		ret = pci_write_config_byte(priv->dev, i + offset, buf[i]);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s err=%d\n",
				       __func__, ret);
			return -1;
		}
	}
	return 0;
}

void vastai_pci_init_bar_at(struct vastai_pci_info *priv, int bar)
{
	if (priv->is_virtfn)
		return vastai_pci_config_vf_bar_at(priv, bar);

	mutex_lock(&priv->set_bar_lock);
	switch (bar) {
	case VASTAI_PCI_BAR0:
		if (priv->bar[VASTAI_PCI_BAR0].mmio_len == (256 * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR0].at_addr =
				VASTAI_PCIE_BAR0_AXI_ADDR_256MB;
		else if (priv->bar[VASTAI_PCI_BAR0].mmio_len ==
			 (32 * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR0].at_addr =
				VASTAI_PCIE_BAR0_AXI_ADDR_32MB;
		else if (priv->bar[VASTAI_PCI_BAR0].mmio_len == (2 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR0].at_addr =
				VASTAI_PCIE_BAR0_AXI_ADDR_2MB;
			priv->bar[VASTAI_PCI_BAR0].minish_bar_size = 1;
		}
		else {
			priv->bar[VASTAI_PCI_BAR0].at_addr =
				VASTAI_PCIE_BAR0_AXI_ADDR_8MB;
			priv->bar[VASTAI_PCI_BAR0].minish_bar_size = 1;
		}
		break;
	case VASTAI_PCI_BAR1:
		if (priv->bar[VASTAI_PCI_BAR1].mmio_len == (32 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR1].at_addr =
				VASTAI_PCIE_BAR1_AXI_ADDR_32MB;
			priv->bar[VASTAI_PCI_BAR1].map_in_addr = VASTAI_PCIE_BAR1_BASEX_32M_IN;
			priv->bar[VASTAI_PCI_BAR1].map_out_addr = VASTAI_PCIE_BAR1_BASEX_32M_OUT;
			break;
		}
		else if (priv->bar[VASTAI_PCI_BAR1].mmio_len == (4 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR1].at_addr =
				VASTAI_PCIE_BAR1_AXI_ADDR_4MB;
			priv->bar[VASTAI_PCI_BAR1].minish_bar_size = 1;
		}
		else {
			priv->bar[VASTAI_PCI_BAR1].at_addr =
				VASTAI_PCIE_BAR1_AXI_ADDR_8MB;
			priv->bar[VASTAI_PCI_BAR1].minish_bar_size = 1;
		}
		priv->bar[VASTAI_PCI_BAR1].map_in_addr = VASTAI_PCIE_BAR1_BASEX_IN;
		priv->bar[VASTAI_PCI_BAR1].map_out_addr = VASTAI_PCIE_BAR1_BASEX_OUT;
		break;
	case VASTAI_PCI_BAR2:
		if (priv->bar[VASTAI_PCI_BAR2].mmio_len == (32 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR2].at_addr =
				VASTAI_PCIE_BAR2_AXI_ADDR_32MB_1;
			priv->bar[VASTAI_PCI_BAR2].minish_bar_size = 1;
		} else if(priv->bar[VASTAI_PCI_BAR2].mmio_len == (1024 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR2].at_addr =
				VASTAI_PCIE_BAR2_AXI_ADDR_1G;
		} else
			priv->bar[VASTAI_PCI_BAR2].at_addr =
				VASTAI_PCIE_BAR2_AXI_ADDR_32GB;
		break;
	case VASTAI_PCI_BAR4:
		if (priv->bar[VASTAI_PCI_BAR4].mmio_len == (128 * 1024 * 1024)) {
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				VASTAI_PCIE_BAR4_AXI_ADDR_128MB_1;
			priv->bar[VASTAI_PCI_BAR4].minish_bar_size = 1;
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (64 * 1024 * 1024 * 1024ULL)) {
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				0x2000000000UL;
			priv->bar[VASTAI_PCI_BAR4].map_in_addr = VASTAI_PCIE_BAR4_BASEX_32G_IN;
			priv->bar[VASTAI_PCI_BAR4].map_out_addr = 0x4000000000UL;
			break;
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (128 * 1024 * 1024 * 1024ULL)) {
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				0x2000000000UL;
			priv->bar[VASTAI_PCI_BAR4].map_in_addr = VASTAI_PCIE_BAR4_BASEX_32G_IN;
			priv->bar[VASTAI_PCI_BAR4].map_out_addr = 0x2000000000UL;
			break;
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (4 * 1024 * 1024 * 1024ULL)) {
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				VASTAI_PCIE_BAR4_AXI_ADDR_32GB;
			priv->bar[VASTAI_PCI_BAR4].map_in_addr = VASTAI_PCIE_BAR4_BASEX_32G_IN;
			priv->bar[VASTAI_PCI_BAR4].map_out_addr = 0x4000000000UL;
			break;
		} else {
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				VASTAI_PCIE_BAR4_AXI_ADDR_32GB;
			priv->bar[VASTAI_PCI_BAR4].map_in_addr = VASTAI_PCIE_BAR4_BASEX_32G_IN;
			priv->bar[VASTAI_PCI_BAR4].map_out_addr = VASTAI_PCIE_BAR4_BASEX_32G_OUT;
			break;
		}
		priv->bar[VASTAI_PCI_BAR4].map_in_addr = VASTAI_PCIE_BAR4_BASEX_IN;
		priv->bar[VASTAI_PCI_BAR4].map_out_addr = VASTAI_PCIE_BAR4_BASEX_OUT;
		break;
	default:
		break;
	}
	mutex_unlock(&priv->set_bar_lock);
}

void vastai_pci_init_bar_at_sg(struct vastai_pci_info *priv, int bar)
{
	if (priv->is_virtfn)
		return vastai_pci_config_vf_bar_at(priv, bar);

	switch (bar) {
	case VASTAI_PCI_BAR0:
		break;
	case VASTAI_PCI_BAR1:
		if (priv->bar[VASTAI_PCI_BAR1].mmio_len == (8 * 1024))
			priv->bar[VASTAI_PCI_BAR1].at_addr =
				PCIE_WRAPPER_ADDR;
		break;
	case VASTAI_PCI_BAR2:
		if (priv->bar[VASTAI_PCI_BAR2].mmio_len == (4 * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR2].at_addr =
				SG_CSRAM_BASE_ADDR;
		/* TODO */
		if (priv->bar[VASTAI_PCI_BAR2].mmio_len == (1 * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR2].at_addr =
				0x838000;
		break;
	case VASTAI_PCI_BAR4:
		if ((u64)priv->bar[VASTAI_PCI_BAR4].mmio_len == (2 * 1024UL * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				VASTAI_PCI_BAR4_ADDR_R;
		if ((u64)priv->bar[VASTAI_PCI_BAR4].mmio_len == (8 * 1024UL * 1024 * 1024))
			priv->bar[VASTAI_PCI_BAR4].at_addr =
				VASTAI_PCI_BAR4_ADDR_R;
		break;
	default:
		break;
	}
}


/* generate a die_index */
u32 vastai_pci_gen_die_index(void *pci_info, u32 die_id)
{
	union die_index_data die_index_temp = { 0 };

	die_index_temp.dev_id = ((struct vastai_pci_info *)pci_info)->dev_id;
	die_index_temp.die_id = die_id;
	die_index_temp.seq_num = vastai_get_seqnum(pci_info, die_id);

	return die_index_temp.val;
}

/* for va16 and va100 */
u32 vastai_pci_gen_die_index_parallel_die(struct vastai_pci_info *pci_info, u32 die_id)
{
	union die_index_data die_index_temp = { 0 };

	die_index_temp.dev_id = pci_info->dev_id;
	die_index_temp.die_id = die_id;
	die_index_temp.seq_num = pci_info->dev_id * pci_info->die_num_in_fn + die_id;

	return die_index_temp.val;
}

/* check a die_index */
u32 vastai_pci_get_die_index(void *pci_info, u32 die_id)
{
	struct vastai_pci_info *__pci_info = pci_info;

	if (die_id >= VASTAI_SV100_MAX_DIE_NUM)
		return UINT_MAX;

	if (atomic_read(&__pci_info->pci_state) != VASTAI_NORMAL_STATE
	    || !__pci_info->dies) {
		return vastai_pci_gen_die_index(pci_info, die_id);
	}

	return vastai_die_get_die_index(&(__pci_info->dies[die_id]));

}

#ifdef CONFIG_VASTAI_PCI_SET_BAR
static int vastai_pci_set_bar_at(struct vastai_pci_info *priv, int bar,
				 u64 addr, int die_index)
{
	int ret = 0;
	u64 reg_addr = 0;
	u32 val_l = addr & 0xFFFFFFFF, val_h = addr >> 32, cnt = 0;

	if (set_bar_debug_en)
		VASTAI_PCI_INFO(priv, 0, "set bar done\n");
	if (priv->bar[VASTAI_PCI_BAR0].minish_bar_size == 0) {
		/* set bar by host */
		reg_addr =
			VASTAI_PCI_CDN_FUNC0_BAR0_EP_INBOUND_ADDR_TRANS_REG0 +
			bar * 0x8;
		ret = vastai_pci_mem_write_direct(priv, die_index, reg_addr, &val_l,
					   4);
		ret |= vastai_pci_mem_write_direct(priv, die_index, reg_addr + 4,
					   &val_h, 4);
		while (1) {
			/* read check to ensure atu configuration is working. */
			vastai_pci_mem_read_direct(priv, die_index, reg_addr, &val_l,
					    4);
			vastai_pci_mem_read_direct(priv, die_index, reg_addr + 4,
					    &val_h, 4);
			if ((val_l == (addr & 0xFFFFFFFF)) &&
			    (val_h == (addr >> 32))) {
				priv->bar[bar].at_addr = addr;
				break;
			}
			mdelay(1);
			cnt++;
			if (cnt > 10) {
				ret = -EIO;
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					       "%s err=%d\n", __func__, ret);
				return ret;
			}
		}
	} else {
		if (in_irq()) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s in irq context, forbiden set bar, addr:%llx\n",
				__func__, addr);
			return -EPERM;
		}
		/* send set bar at cmd to smcu */
		ret = vastai_send_pcie_cmd_spe(priv, priv->dies[0].die_index,
					   VASTAI_PCIE_SUB_SET_BAR, addr);
		if (ret < 0)
			return ret;
		/* wait completion int from smcu */
		if (wait_for_completion_timeout(
			    &(priv->set_bar_done),
			    msecs_to_jiffies(
				    VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
			VASTAI_PCI_ERR(
				priv, die_index,
				"%s BAR(%d) at_addr=0x%lx to addr=0x%llx timeout!\n",
				__func__, bar, priv->bar[bar].at_addr, addr);
			return -ETIMEDOUT;
		}
		reinit_completion(&(priv->set_bar_done));
		priv->bar[bar].at_addr = addr;
	}

	return ret;
}

/* only bar2 need be reset, becase only bar2 will be skip */
void vastai_pci_reset_bar_at(struct vastai_pci_info *priv, int die_index)
{
	vastai_pci_set_bar_at(priv, VASTAI_PCI_BAR2,
				VASTAI_PCIE_BAR2_AXI_ADDR_32MB_2, die_index);
}

#endif

static int vastai_pci_select_bar(struct vastai_pci_info *priv, int die_id, u64 addr, int *bar, u64 *offset)
{
	if ((addr >= priv->bar[VASTAI_PCI_BAR0].at_addr) &&
	    (addr < priv->bar[VASTAI_PCI_BAR0].at_addr +
			    priv->bar[VASTAI_PCI_BAR0].mmio_len)) {
		*bar = VASTAI_PCI_BAR0;
	} else if ((addr >= priv->bar[VASTAI_PCI_BAR1].at_addr) &&
		   (addr < priv->bar[VASTAI_PCI_BAR1].at_addr +
				   priv->bar[VASTAI_PCI_BAR1].mmio_len)) {
		*bar = VASTAI_PCI_BAR1;
	} else if ((addr >= priv->bar[VASTAI_PCI_BAR4].at_addr) &&
		   (addr < priv->bar[VASTAI_PCI_BAR4].at_addr +
				   priv->bar[VASTAI_PCI_BAR4].mmio_len)) {
		*bar = VASTAI_PCI_BAR4;
	} else {
		/* using bar2 to switch bar dynamically  */
		return -1;
	}
	*offset = addr - priv->bar[*bar].at_addr;

	return 0;
}

static bool is_in_map_range(u64 addr, u64 start_addr, u64 size)
{
	if((addr >= start_addr) && (addr < (start_addr+size)))
		return true;
	else
		return false;
}

/*
	bar1:             map in addr                  :          map out addr

	die 1: 0x10_08B0_0000 ~ (0x10_08B0_0000 + 2M)  :  0x10_0A00_0000       ~ (0x10_0A00_0000 + 2M)
	die 2: 0x20_08B0_0000 ~ (0x20_08B0_0000 + 2M)  : (0x10_0A00_0000 + 2M) ~ (0x10_0A00_0000 + 4M)
	die 3: 0x30_08B0_0000 ~ (0x30_08B0_0000 + 2M)  : (0x10_0A00_0000 + 4M) ~ (0x10_0A00_0000 + 6M)

	bar4:             map in addr                  :          map out addr

	die 1: 0x18_1400_0000 ~ (0x18_1400_0000 + 32M) : 0x14_0000_0000         ~ (0x14_0000_0000 + 32M)
	die 2: 0x28_1400_0000 ~ (0x28_1400_0000 + 32M) : (0x14_0000_0000 + 32M) ~ (0x14_0000_0000 + 64M)
	die 3: 0x38_1400_0000 ~ (0x38_1400_0000 + 32M) : (0x14_0000_0000 + 64M) ~ (0x14_0000_0000 + 96M)
*/

static int vastai_pci_bar_trans_addr(struct vastai_pci_info *priv, int die_id, u32 bar_id,
						u64 *addr)
{
	u64 map_in_start_addr = priv->bar[bar_id].map_in_addr;
	u64 map_out_start_addr = priv->bar[bar_id].map_out_addr;
	u64 range_len = priv->bar[bar_id].mmio_len/VASTAI_DIE_MAX_NUM;
	u64 mapBaseAddr = 0;
	u64 offset = 0;

	if(bar_id == VASTAI_PCI_BAR1)
		range_len = priv->bar[bar_id].mmio_len/VASTAI_DIE_MAX_NUM;
	if(bar_id == VASTAI_PCI_BAR4)
		range_len = priv->bar[bar_id].mmio_len/priv->die_num_in_fn;
	if(is_in_map_range(*addr, map_in_start_addr, range_len)) {
		if(map_out_start_addr==VASTAI_PCIE_BAR4_BASEX_32G_OUT || map_out_start_addr==0x2000000000UL || map_out_start_addr==0x4000000000UL) {
			if((*addr & 0xfffffffff)==VASTAI_FW_DL_ADDR) {
				return 1;
			}
		}
		mapBaseAddr = map_out_start_addr + range_len * (die_id - 1);
		offset = *addr - map_in_start_addr;
		*addr = mapBaseAddr + offset;

		return 1;
	}

	return 0;
}

u64 vastai_pci_no_trans_addr(struct vastai_pci_info *priv, int die_id,
					u64 rel_addr, u64 abs_addr)
{
	return rel_addr;
}

u64 vastai_pci_cal_absolute_addr(struct vastai_pci_info *priv, int die_id,
					u64 rel_addr, u64 abs_addr)
{
	u64 addr = rel_addr;

	if(die_id == 0)
		return rel_addr;

	if(!vastai_pci_bar_trans_addr(priv, die_id, VASTAI_PCI_BAR1, &addr))
		vastai_pci_bar_trans_addr(priv, die_id, VASTAI_PCI_BAR4, &addr);

	if (rel_addr != addr)
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "%s: addr_in:0x%llx addr_out:0x%llx\n", __func__,
			       abs_addr, addr);
	else {
		return abs_addr;
	}

	return addr;
}

static int vastai_pci_bar_read(struct vastai_pci_info *priv, int bar,
			       u64 offset, void *buf, unsigned int len)
{
	volatile unsigned char *mem = vastai_pci_bar_vmem(priv, bar);
	unsigned int i = 0;

	if (unlikely(!mem)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s: bar%d vmem is NULL, return\n", __func__,
			       bar);
		return -ENXIO;
	}
	if (unlikely(!buf)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: buff is NULL, return\n",
			       __func__);
		return -ENOMEM;
	}
	mem += offset;

	/* Align any unaligned source IO */
	if (unlikely(3 & (unsigned long)mem)) {
		u32 temp_len = ((u64)mem) & 3;
		temp_len = min(len, (4-temp_len));
		memcpy_fromio(buf, mem, temp_len);
		i += temp_len;
	}

	/* rep copy */
	while ((len - i) >= 4) {
		*((unsigned int *)((u64)buf + i)) = readl(mem + i);
		i += sizeof(unsigned int);
	}

	/* Align any unaligned source IO len */
	if (unlikely(3 & (len - i))) {
		u32 temp_len = (len - i) & 3;
		memcpy_fromio(buf + i, mem + i, temp_len);
		i += temp_len;
	}

	BUG_ON((len - i) != 0);
	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
		       "%s(bar=%d, offset=0x%llx, val=0x%x)\n", __func__, bar,
		       offset, *((int *)buf));

	return 0;
}

int vastai_pci_mmio_read(struct vastai_pci_info *priv, int bar,
				 u64 offset, void *buf, unsigned int len)
{
	unsigned char *mem = NULL;
	unsigned int l = 0;
#ifdef VASTAI_MMIO_PERF_TEST
	unsigned long old_ts, now_ts;
	unsigned int info_len = len;
#endif
	mem = vastai_pci_bar_vmem(priv, bar);

	if (!mem) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			      "%s: bar%d vmem is NULL, return\n", __func__,
			      bar);
		return -ENXIO;
	}
	mem += offset;
#ifdef VASTAI_MMIO_PERF_TEST
	if (test_PCIe_Perf) {
		old_ts= ktime_get();
	}
#endif
	if (len < 4) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			      "%s: len < 4, return\n", __func__);
		return -EINVAL;
	} else {
		if ((long)mem & 0x3) {
			l = 0x4 - ((long)mem & 0x3);
			memcpy_fromio(buf, mem, l);
			buf += l;
			mem += l;
			len -= l;
		}
		while (len >= 4) {
			*((unsigned int *)buf) = readl(mem);
			mem += 4;
			buf += 4;
			len -= 4;
		}
		if (len)
			memcpy_fromio(buf, mem, len);
	}
#ifdef VASTAI_MMIO_PERF_TEST
	if (test_PCIe_Perf) {
		now_ts = ktime_get();
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[mmio-read]%d byte: %09lu(ns)=%06lu(us)\n", info_len, (now_ts-old_ts), (now_ts-old_ts)/1000);
	}
#endif
	return 0;
}

int vastai_pci_mmio_write(struct vastai_pci_info *priv, int bar,
			       u64 offset, void *buf,  unsigned int len)
{
	unsigned char *mem = NULL;
	unsigned int l = 0;
#ifdef VASTAI_MMIO_PERF_TEST
	unsigned long old_ts, now_ts;
	unsigned int info_len = len;
#endif
	mem = vastai_pci_bar_vmem(priv, bar);

	if (!mem) {
		 VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s: bar%d vmem is NULL, return\n", __func__,
			bar);
		return -ENXIO;
	}

	mem += offset;
#ifdef VASTAI_MMIO_PERF_TEST
	if(test_PCIe_Perf){
		old_ts= ktime_get();
	}
#endif
	if (len < 4) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		"%s: len < 4, return\n", __func__);
		return -EINVAL;
	} else {
	if ((long)mem & 0x3) {
		l = 0x4 - ((long)mem & 0x3);
		memcpy_toio(mem, buf, l);
		buf += l;
		mem += l;
		len -= l;
	}
	while (len >= 4) {
		writel(*((unsigned int *)buf), mem);
		buf += 4;
		mem += 4;
		len -= 4;
	}
	if (len) {
		memcpy_toio(mem, buf, len);
	}
 }

#ifdef VASTAI_MMIO_PERF_TEST
	if (test_PCIe_Perf) {
		now_ts= ktime_get();
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"[mmio-write]%d byte: %09lu(ns)=%06lu(us)\n", info_len ,(now_ts-old_ts),(now_ts-old_ts)/1000 );
	}
#endif
	return 0;
}

//mode:1 bit set 0:bit clear
int vastai_pci_modify_reg32(struct vastai_pci_info *priv,u64 addr,u32 mask_bit,u32 mode)
{
	int ret = 0;
	u32 tmp_val = 0;
	mutex_lock(&vastai_pci_modify_lock);

	ret = vastai_pci_mem_read(priv,0,addr,&tmp_val,4);
	tmp_val = (mode)?(tmp_val|(mask_bit)):(tmp_val&(~mask_bit));
	ret = vastai_pci_mem_write(priv,0,addr,&tmp_val,4);

	mutex_unlock(&vastai_pci_modify_lock);
	return ret;
}

 //mode:1 bit set 0:bit clear
int vastai_smcu_modify_reg32(struct vastai_pci_info *priv,u64 addr,u32 mask_bit,u32 mode)
{
	int ret = 0;
	u32 tmp_val = 0;
	mutex_lock(&vastai_smcu_modify_lock);

	ret = vastai_read_by_smcu(priv,addr,4,&tmp_val);
	tmp_val = (mode)?(tmp_val|(mask_bit)):(tmp_val&(~mask_bit));
	ret = vastai_write_4byte_by_smcu(priv,addr,tmp_val);

	mutex_unlock(&vastai_smcu_modify_lock);
	return ret;

}

int vastai_slave_config_read(struct vastai_pci_info *priv,
						 u64 offset, void *buf,  unsigned int len)
{
	int ret;
	u64 cfg_base = priv->bar[VASTAI_PCI_BAR2].mmio_len - 0x1000;
	if(MASTER_PKG == priv->pkg_id) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "this api only for access slave pkg config space\n");
		return -1;
	}
	ret = vastai_pci_mmio_read(priv,VASTAI_PCI_BAR2, cfg_base + offset,buf,len);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "access slave pkg config space error\n");
		return ret;
	}
	return 0 ;
}

int vastai_slave_config_write(struct vastai_pci_info *priv,
					u64 offset, void *buf,  unsigned int len)
{
	int ret;
	u64 cfg_base = priv->bar[VASTAI_PCI_BAR2].mmio_len - 0x1000;
	if(MASTER_PKG == priv->pkg_id) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "this api only for access slave pkg config space\n");
		return -1;
	}
	ret = vastai_pci_mmio_write(priv,VASTAI_PCI_BAR2, cfg_base + offset,buf,len);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "write slave pkg config space error\n");
		return ret;
	}
	return 0;
}


int vastai_pci_mem_fread(struct vastai_pci_info *priv,
							u64 fn_addr,
							void *buf,
							unsigned int len)
{
	int ret;
	u64 offset = 0;
	int bar_num = 0;
	int region_num = 0;

	ret = translate_fn_addr(priv,fn_addr, &bar_num, &offset, &region_num);
	if (ret) {
		return -1;
	}
	ret = vastai_pci_mmio_read(priv, bar_num, offset , buf, len);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, priv->pkg_id,"%s offset = 0x%llx, len=%d, error:%d\n",
				__func__, offset, len, ret);
		return ret;
	}
#if PCIE_ACCESS_LOG
	/*this is for debug */
	{
		u64 noc_addr  = 0;
		if (priv->bar[bar_num].region_cnt > 0) {
			noc_addr = fn_addr - priv->bar[bar_num].regions[region_num].fn_base_addr
							+ priv->bar[bar_num].regions[region_num].noc_addr;
		} else {
			noc_addr = fn_addr - priv->bar[bar_num].fn_base_addr + priv->bar[bar_num].noc_addr;
		}
		VASTAI_PCI_INFO(priv, priv->pkg_id,"[fread]fn_addr[0x%llx] noc_addr[0x%llx] bar[%x] offset[%llx] region[%x] len=0x%d val=%#x\n",
					fn_addr, noc_addr, bar_num, offset, region_num, len, *((int *)buf));
	}
#endif
	return ret;
}

int vastai_pci_mem_fwrite(struct vastai_pci_info *priv,
						u64 fn_addr,
						void *buf,
						unsigned int len)
{
	int ret;
	u64 offset = 0;
	int bar_num = 0;
	int region_num = 0;

	ret = translate_fn_addr(priv,fn_addr, &bar_num, &offset, &region_num);
	if (ret) {
		return -1;
	}
	ret = vastai_pci_mmio_write(priv, bar_num, offset , buf, len);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, priv->pkg_id,"%s offset = 0x%llx, len=%d, error:%d\n",
				__func__, offset, len, ret);
		return ret;
	}

#if PCIE_ACCESS_LOG
/*this is for debug */
{
	u64 noc_addr  = 0;
	if (priv->bar[bar_num].region_cnt > 0) {
		noc_addr	  = fn_addr - priv->bar[bar_num].regions[region_num].fn_base_addr
						+ priv->bar[bar_num].regions[region_num].noc_addr;
	} else {
		noc_addr	  = fn_addr - priv->bar[bar_num].fn_base_addr + priv->bar[bar_num].noc_addr;
	}

	VASTAI_PCI_INFO(priv, priv->pkg_id,"[fwrite]fn_addr[0x%llx] noc_addr[0x%llx] bar[%x] offset[%llx] region[%x] len=0x%d val=%#x\n",
				fn_addr, noc_addr, bar_num, offset, region_num, len,*((int *)buf));
}
#endif

	return ret;
}
int vastai_cii_set(struct vastai_pci_info *priv, u32 ch, u32 addr, u32 pf)
{
	int ret;
	struct pcie_transfer_cmd trans;

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s: ch[%d], addr[0x%x], pf[%d]\n", __func__, ch, addr, pf);

	if (ch > 8) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: channel must be 0~7\n", __func__);
		return -1;
	}

	if (addr & 0xFFFFF003) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: error addr[0x%x]\n", __func__, addr);
		return -1;
	}

	trans.w0.s_data0.optcode = SMCU_CII_SET;
	trans.w0.s_data0.rev0 = ch;
	trans.w0.s_data0.rev1 = pf;
	trans.w1.data1 = addr;
	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: push element fail\n", __func__);
		return -1;
	}

	return 0;
}

int translate_fn_addr(struct vastai_pci_info *priv,
							u64 fn_addr,
							int *bar,
							u64 *bar_offset,
							int *region_num)
{
	u64 csram_size	  = priv->priv_hw_cfg->header.csram_size;
	u64 csram_limit   = FN_CSRAM_BASE_ADDR + csram_size;

	u64 smu_csr_size  = priv->priv_hw_cfg->header.smu_csr_size;
	u64 smu_csr_limit = FN_SMU_CSR_BASE_ADDR + smu_csr_size;

	u64 gfx_csr_size  = priv->priv_hw_cfg->header.gfx_csr_size;
	u64 gfx_csr_limit = FN_GFX_CSR_BASE_ADDR + gfx_csr_size;

	u64 ddr_limit	  = 0;
	u64 ddr_base	  = FN_DDR_BASE_ADDR;

	ddr_limit	  = ddr_base + priv->bar[4].mmio_len;

	if ((priv->is_pf) && ((fn_addr >= FN_PCIE_WRAPER_BASE_ADDR) && (fn_addr < FN_PCIE_WRAPER_BASE_LIMIT))) {
		*bar		 = VASTAI_PCI_BAR1;
		*bar_offset  = fn_addr - FN_PCIE_WRAPER_BASE_ADDR;
	} else if((fn_addr >= FN_CSRAM_BASE_ADDR) && (fn_addr <= csram_limit)) {
		*bar		 = VASTAI_PCI_BAR2;
		*bar_offset  = fn_addr - FN_CSRAM_BASE_ADDR + priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].bar_offset;
		*region_num  = BAR2_CSRAM_01;

	} else if ((fn_addr >= FN_SMU_CSR_BASE_ADDR) && (fn_addr < smu_csr_limit)) {
		*bar		 = VASTAI_PCI_BAR2;
		*bar_offset  = fn_addr - FN_SMU_CSR_BASE_ADDR + priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].bar_offset;
		*region_num  = BAR2_SMU_CSR;

	} else if ((fn_addr >= FN_GFX_CSR_BASE_ADDR) && (fn_addr < gfx_csr_limit)) {
		*bar		 = VASTAI_PCI_BAR2;
		*bar_offset  = fn_addr - FN_GFX_CSR_BASE_ADDR + priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].bar_offset;
		*region_num  = BAR2_GFX_CSR;

	} else if (priv->is_pf && ( (fn_addr >= 0x8E0000) && (fn_addr < 0x8E8000))) {
		*bar		 = VASTAI_PCI_BAR2;
		*bar_offset  = fn_addr - 0x8E0000 + priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].bar_offset;
		*region_num  = BAR2_CSRAM_02;

	}
#ifdef DIAG_TEST_MODE
	/*this fn_addr is really noc addr */
	else if ((fn_addr >= priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr) &&
			 (fn_addr < (priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[0].region_size))) {
		*bar		 = VASTAI_PCI_BAR4;
		*bar_offset  = fn_addr - priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr;
		*region_num  = 0;
	} else if ((fn_addr >= priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr) &&
			 (fn_addr < (priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].region_size))) {
		*bar		 = VASTAI_PCI_BAR4;
		*bar_offset  = fn_addr - priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].bar_offset;
		*region_num  = 1;
	} else if (fn_addr >= (FN_DDR_BASE_ADDR - SPACE_SIZE_256M)) {
		/*start to swtich bar*/
		int ret;
		unsigned long flags;
		spin_lock_irqsave(&priv->swtich_atu_lock, flags);

		ret = swtich_atu(priv,fn_addr,bar,bar_offset,region_num);
		if (ret < 0) {
			spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
			return ret;
		}
		spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
	} else {
		VASTAI_PCI_ERR(priv, 0,"%s fn_addr = 0x%llx is invalid addr \n", __func__, fn_addr);
	}
#else
	else if ((fn_addr >= FN_DDR_BASE_ADDR) && (fn_addr < ddr_limit)) {
		*bar		 = VASTAI_PCI_BAR4;
		*bar_offset  = fn_addr - ddr_base;
	} else {
		VASTAI_PCI_ERR(priv, priv->pkg_id,"%s fn_addr = 0x%llx is invalid addr \n", __func__, fn_addr);
		return -1;
	}
#endif
	return 0;
}


int translate_noc_addr(struct vastai_pci_info *priv,
				int pkg_id, u64 noc_addr,
				int *bar, u64 *bar_offset)
{
	//u64 csram_base    = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].noc_addr;
	//u64 csram_size    = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].region_size;
	//u64 csram_limit   = csram_base + csram_size;

	u64 smu_csr_base  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].noc_addr;
	u64 smu_csr_size  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].region_size;
	u64 smu_csr_limit = smu_csr_base + smu_csr_size;

	u64 gfx_csr_base  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].noc_addr;
	u64 gfx_csr_size  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].region_size;
	u64 gfx_csr_limit = gfx_csr_base + gfx_csr_size;

	u64 ddr_limit	   = 0;
	u64 ddr_base	   = priv->bar[VASTAI_PCI_BAR4].noc_addr;

	ddr_limit	   = ddr_base + priv->bar[4].mmio_len;

	if( priv->is_pf && (noc_addr >= priv->bar[VASTAI_PCI_BAR1].at_addr) &&
		(noc_addr < (priv->bar[VASTAI_PCI_BAR1].at_addr + priv->bar[VASTAI_PCI_BAR1].mmio_len))) {
		*bar        = VASTAI_PCI_BAR1;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR1].at_addr;

		return 0;
	} else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR2].at_addr) &&
		(noc_addr < (priv->bar[VASTAI_PCI_BAR2].at_addr + priv->bar[VASTAI_PCI_BAR2].mmio_len))) {
		*bar        = VASTAI_PCI_BAR2;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR2].at_addr;
		return 0;
	} else if ((noc_addr >= smu_csr_base) && (noc_addr < smu_csr_limit)) {
		*bar        = VASTAI_PCI_BAR2;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].noc_addr
				 + priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].bar_offset;
		return 0;
	} else if ((noc_addr >= gfx_csr_base) && (noc_addr < gfx_csr_limit)) {
		*bar        = VASTAI_PCI_BAR2;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].noc_addr
				+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].bar_offset;
		return 0;
	} else if (priv->is_pf && (noc_addr >= 0x8E0000) && (noc_addr < 0x8E8000)) {
		//slave-pkg special csram noc addr
		*bar        = VASTAI_PCI_BAR2;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].noc_addr
				+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].bar_offset;
		return 0;
	}
#ifdef DIAG_TEST_MODE
	else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr) &&
	(noc_addr < (priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[0].region_size))) {
		*bar        = VASTAI_PCI_BAR4;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr;
	} else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr) &&
	(noc_addr < (priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].region_size))) {
		*bar        = VASTAI_PCI_BAR4;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].bar_offset;
	} else if (noc_addr >= (DDR_BASE_ADDR - SPACE_SIZE_256M)) {
		/*start to swtich bar*/
		int ret;
		unsigned long flags;
		int region_num;
		spin_lock_irqsave(&priv->swtich_atu_lock, flags);

		ret = swtich_atu(priv,noc_addr,bar,bar_offset,&region_num);
		if (ret < 0) {
			spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
			return ret;
		}
		spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
	} else {
		VASTAI_PCI_ERR(priv, pkg_id,"%s diag noc_addr = 0x%llx is invalid addr \n", __func__, noc_addr);
		return -1;
	}
#else
	else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR4].at_addr) &&
		(noc_addr < (priv->bar[VASTAI_PCI_BAR4].at_addr + priv->bar[VASTAI_PCI_BAR4].mmio_len))) {
		*bar        = VASTAI_PCI_BAR4;
		*bar_offset = noc_addr - priv->bar[VASTAI_PCI_BAR4].at_addr;
		return 0;
	} else {
		VASTAI_PCI_ERR(priv, pkg_id,"%s noc_addr = 0x%llx is invalid addr \n", __func__, noc_addr);
		return -1;
	}
#endif
	return 0;
}

int translate_noc_addr_origin(struct vastai_pci_info *priv,
						int pkg_id, u64 noc_addr,
						int *bar, u64 *bar_offset)
{
	u64 csram_base	  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].noc_addr;
	u64 csram_size	  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].region_size; //38000
	u64 csram_limit   = csram_base + csram_size;

	u64 smu_csr_base  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].noc_addr;
	u64 smu_csr_size  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].region_size;
	u64 smu_csr_limit = smu_csr_base + smu_csr_size;

	u64 gfx_csr_base  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].noc_addr;
	u64 gfx_csr_size  = priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].region_size;
	u64 gfx_csr_limit = gfx_csr_base + gfx_csr_size;

	u64 ddr_limit	  = 0;
	u64 ddr_base	  = priv->bar[VASTAI_PCI_BAR4].noc_addr;

	ddr_limit	  = ddr_base + priv->bar[4].mmio_len;

	if( priv->is_pf && (noc_addr >= 0x942000) && (noc_addr < 0x944000)) {
		*bar		 = VASTAI_PCI_BAR1;
		*bar_offset	 = noc_addr - priv->bar[VASTAI_PCI_BAR1].noc_addr;
		return 0;

	} else if ((noc_addr >= csram_base) && (noc_addr < csram_limit)) {
		*bar		  = VASTAI_PCI_BAR2;
		*bar_offset   = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].noc_addr
						+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].bar_offset;
		return 0;

	} else if ((noc_addr >= smu_csr_base) && (noc_addr < smu_csr_limit)) {
		*bar		  = VASTAI_PCI_BAR2;
		*bar_offset   = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].noc_addr
							+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].bar_offset;
		return 0;

	} else if ((noc_addr >= gfx_csr_base) && (noc_addr < gfx_csr_limit)) {
		*bar		  = VASTAI_PCI_BAR2;
		*bar_offset   = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].noc_addr
						+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].bar_offset;
		return 0;

	} else if (priv->is_pf && (noc_addr >= 0x8E0000) && (noc_addr < 0x8E8000)) {
		//slave-pkg special csram noc addr
		*bar		  = VASTAI_PCI_BAR2;
		*bar_offset   = noc_addr - priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].noc_addr
						+ priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].bar_offset;
		return 0;
	}
#ifdef DIAG_TEST_MODE
	else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr) &&
			 (noc_addr < (priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[0].region_size))) {
		*bar		 = VASTAI_PCI_BAR4;
		*bar_offset  = noc_addr - priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr;
	} else if ((noc_addr >= priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr) &&
			 (noc_addr < (priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].region_size))) {
		*bar		 = VASTAI_PCI_BAR4;
		*bar_offset  = noc_addr - priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr + priv->bar[VASTAI_PCI_BAR4].regions[1].bar_offset;
	} else if (noc_addr >= (DDR_BASE_ADDR - SPACE_SIZE_256M)) {
		/*start to swtich bar*/
		int ret;
		unsigned long flags;
		int region_num;
		spin_lock_irqsave(&priv->swtich_atu_lock, flags);

		ret = swtich_atu(priv,noc_addr,bar,bar_offset,&region_num);
		if (ret < 0) {
			spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
			return ret;
		}
		spin_unlock_irqrestore(&priv->swtich_atu_lock, flags);
	} else {
		VASTAI_PCI_ERR(priv, pkg_id,"%s diag noc_addr = 0x%llx is invalid addr \n", __func__, noc_addr);
		return -1;
	}
#else
	else if ((noc_addr >= ddr_base) && (noc_addr < ddr_limit)) {
		*bar		  = VASTAI_PCI_BAR4;
		*bar_offset   = noc_addr - priv->bar[VASTAI_PCI_BAR4].noc_addr;
		return 0;

	} else {
		VASTAI_PCI_ERR(priv, pkg_id,"%s noc_addr = 0x%llx is invalid addr \n", __func__, noc_addr);
		return -1;
	}
#endif

	return 0;
}


// Func: calculate the absolute virtual address of relative_addr, not the base.
void *vastai_pci_mmio_kva_get(struct vastai_pci_info *priv,
					u32 die_index,
					u64 relative_addr,
					u32 len)
{
	unsigned char *vaddr = NULL;
	int ret;
	u64 offset	   = 0;
	int bar	   = 0;

	ret   = translate_noc_addr_origin(priv, die_index, relative_addr, &bar, &offset);
	vaddr = offset + priv->bar[bar].vmem;

	return vaddr;
}

int vastai_read_by_smcu(struct vastai_pci_info *priv, u64 noc_addr, unsigned int len ,void *buf)
{
	int ret;
	struct pcie_transfer_cmd trans;
	if (noc_addr % 4 != 0){
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "the csr addr=0x%llx is not align 4 byte\n", noc_addr);
		return -1;
	}
	if (len % 4 !=0) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "read csr len=0x%x is not align 4 byte\n", len);
		return -1;
	}
	while(len > 0){
		trans.w0.s_data0.optcode	= HOST_READ_CSR_BY_SMCU;
		trans.w0.s_data0.rev0		= 4;
		trans.w0.s_data0.rev1		= 0;
		trans.w0.s_data0.rev2		= 0;
		trans.w1.data1				= noc_addr&0xFFFFFFFF;
		trans.w2.data2				= noc_addr>>32;
		trans.w3.data3				= 0;
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
		if (ret) {
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "push element fail\n");
		}

		/* wait completion int from smcu */
		if (wait_for_completion_timeout(
				&(priv->read_csr_by_smcu_done),
				msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"smcu read noc_addr%llx failed\n",noc_addr);
			return -ETIMEDOUT;
		}
		reinit_completion(&(priv->read_csr_by_smcu_done));
		*((unsigned int *)buf) = priv->read_csr_value_by_smcu;
		len	 -= 4;
		noc_addr += 4;
		buf	 += 4;
	}

	return 0;
}
/* for dus test,need to remove */
EXPORT_SYMBOL(vastai_read_by_smcu);
int vastai_write_4byte_by_smcu(struct vastai_pci_info *priv, u64 noc_addr, u32 val)
{
	int ret;
	struct pcie_transfer_cmd trans;
	unsigned long old_ts = 0, now_ts = 0;
	unsigned int info_len = 4;
	if (noc_addr % 4 != 0){
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "the csr addr %#llx is not align 4 byte\n",noc_addr);
		return -1;
	}
	if(test_smcu_RW_Perf){
		old_ts= ktime_get();
	}
	trans.w0.s_data0.optcode	= HOST_WRITE_CSR_BY_SMCU;
	trans.w0.s_data0.rev0		= 0;
	trans.w0.s_data0.rev1		= 0;
	trans.w0.s_data0.rev2		= 0;
	trans.w1.data1				= noc_addr & 0xFFFFFFFF;
	trans.w2.data2				= noc_addr >> 32;
	trans.w3.data3				= val;
	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
	if (ret) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "push element fail\n");
	}

	/* wait completion int from smcu */
	if (wait_for_completion_timeout(
			&(priv->write_csr_by_smcu_done),
			msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"smcu write noc_addr%#llx failed\n", noc_addr);
		return -ETIMEDOUT;
	}
	reinit_completion(&(priv->write_csr_by_smcu_done));
	if(test_smcu_RW_Perf){
		now_ts= ktime_get();
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"[smcu-write]%d byte: %09lu(ns)=%06lu(us)\n", info_len ,(now_ts-old_ts),(now_ts-old_ts)/1000 );
	}

	return 0;
}
/* for dus test,need to remove */
EXPORT_SYMBOL(vastai_write_4byte_by_smcu);

// func: dump the map of all kchar:xx ~ BDF on current PC
void dump_pf_vf_map_kchar(struct vastai_pci_info *priv)
{
	struct vastai_pci_info *vptr = NULL;
	int i = 0;
	board_type_e board_type = vastai_get_board_type(priv);
	//    VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s: vastai_pci_info_list=0x%p", __func__, &vastai_pci_info_list);

	if (list_empty(&(vastai_pci_info_list))) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "vastai_pci_info_list:0x%p is an empty list now", &vastai_pci_info_list);
	} else {
		list_for_each_entry(vptr, &(vastai_pci_info_list), dev_list) {
			if(vptr){
				if(vptr->dev == NULL || vptr->dev->bus == NULL) {
					VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "vptr->dev=%p, NULL ptr found.\n", vptr->dev);
					continue;
				}
				if (board_type == SV100) {
					VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "sv100[%d] kchar_map: devfn:%d ~ kchar:%d ~ %s\n", i, vptr->dev->devfn, vptr->dev_id, pci_name(vptr->dev));
				}else if (board_type == SG100) {
					VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "sg100[%d] kchar_map: devfn:%d ~ kchar:%d ~ %s\n", i, vptr->dev->devfn, vptr->dev_id, pci_name(vptr->dev));
				}else {
					VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "no support board_type[%d]\n", board_type);
				}
			} else
				VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "LinkList: elem vptr:0x%p, NULL\n", vptr);
		}
	}

}


int init_vastai_pci_mem(struct vastai_pci_info *priv)
{
	unsigned long target_addr_64b = 0;
	u64 csram_size    = priv->priv_hw_cfg->header.csram_size;
	u64 smu_csr_size  = priv->priv_hw_cfg->header.smu_csr_size;
	u64 gfx_csr_size  = priv->priv_hw_cfg->header.gfx_csr_size;

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s priv 0x%p or dev 0x%p is NULL\n", __func__,
				priv, priv->dev);
		return -ENXIO;
	}

	priv->bar[VASTAI_PCI_BAR1].noc_addr	 = PCIE_WRAPPER_ADDR;
	priv->bar[VASTAI_PCI_BAR1].fn_base_addr = PCIE_WRAPPER_ADDR;

	target_addr_64b = priv->priv_hw_cfg->header.csram_base;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].noc_addr	 = target_addr_64b;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].region_size	 = csram_size;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].bar_offset	 = 0;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_01].fn_base_addr   = FN_CSRAM_BASE_ADDR;

	target_addr_64b = priv->priv_hw_cfg->header.smu_csr_base;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].noc_addr	 = target_addr_64b;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].region_size	 = smu_csr_size;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].bar_offset	 = csram_size;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_SMU_CSR].fn_base_addr	 = FN_SMU_CSR_BASE_ADDR;

	target_addr_64b = priv->priv_hw_cfg->header.gfx_csr_base;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].noc_addr	 = target_addr_64b;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].region_size	 = gfx_csr_size;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].bar_offset	 = csram_size + smu_csr_size;
	priv->bar[VASTAI_PCI_BAR2].regions[BAR2_GFX_CSR].fn_base_addr	 = FN_GFX_CSR_BASE_ADDR;
	priv->bar[VASTAI_PCI_BAR2].region_cnt				 = BAR2_GFX_CSR+1;

	if (priv->is_pf) {
		target_addr_64b = 0x8E0000;
		priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].noc_addr	 = target_addr_64b;
		priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].region_size	 = smu_csr_size;
		priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].bar_offset	 = csram_size + smu_csr_size + gfx_csr_size;
		priv->bar[VASTAI_PCI_BAR2].regions[BAR2_CSRAM_02].fn_base_addr   = 0x8E0000;
		priv->bar[VASTAI_PCI_BAR2].region_cnt++;
	}

#ifdef DIAG_TEST_MODE
	if (priv->is_pf) {
		priv->bar[VASTAI_PCI_BAR4].noc_addr = (u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base<<32)|priv->priv_hw_cfg->header.lo32_ddr_base;
		target_addr_64b = priv->bar[VASTAI_PCI_BAR4].noc_addr;
		priv->bar[VASTAI_PCI_BAR4].regions[0].noc_addr 	 = target_addr_64b;
		priv->bar[VASTAI_PCI_BAR4].regions[0].region_size	 = priv->bar[VASTAI_PCI_BAR4].mmio_len;
		priv->bar[VASTAI_PCI_BAR4].regions[0].bar_offset	 = 0;
		priv->bar[VASTAI_PCI_BAR4].regions[0].fn_base_addr  = FN_DDR_BASE_ADDR;
		priv->bar[VASTAI_PCI_BAR4].region_cnt++;

		target_addr_64b = 0;
		priv->bar[VASTAI_PCI_BAR4].regions[1].noc_addr 	 = 0;
		priv->bar[VASTAI_PCI_BAR4].regions[1].region_size	 = 0;
		priv->bar[VASTAI_PCI_BAR4].regions[1].bar_offset	 = 0;
		priv->bar[VASTAI_PCI_BAR4].regions[1].fn_base_addr  = 0;
		priv->bar[VASTAI_PCI_BAR4].region_cnt++;
	}
#else
	priv->bar[VASTAI_PCI_BAR4].noc_addr	 = (u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base<<32)|priv->priv_hw_cfg->header.lo32_ddr_base;
	priv->bar[VASTAI_PCI_BAR4].fn_base_addr = FN_DDR_BASE_ADDR;
#endif
	return 0;
}


int vastai_pci_bar_write(struct vastai_pci_info *priv, int bar,
				u64 offset, const void *buf, unsigned int len)
{
	unsigned char *mem = vastai_pci_bar_vmem(priv, bar);
	unsigned int i = 0;

	if (unlikely(!mem)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s: bar%d vmem is NULL, return\n", __func__,
			       bar);
		return -ENXIO;
	}
	if (unlikely(!buf)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: buff is NULL, return\n",
			       __func__);
		return -ENOMEM;
	}
	mem += offset;

	/* Align any unaligned source IO */
	if (unlikely(3 & (unsigned long)mem)) {
		u32 temp_len = ((u64)mem) & 3;
		temp_len = min(len, (4-temp_len));
		memcpy_toio(mem, buf, temp_len);
		i += temp_len;
	}

	/* rep copy */
	while ((len - i) >= 4) {
		writel(*((unsigned int *)((u64)buf + i)), (mem + i));
		i += sizeof(unsigned int);
	}

	/* Align any unaligned source IO len */
	if (unlikely(3 & (len - i))) {
		u32 temp_len = (len - i) & 3;
		memcpy_toio(mem + i, buf + i, temp_len);
		i += temp_len;
	}

	BUG_ON((len - i) != 0);
	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
		       "%s(bar=%d, offset=0x%llx, val=0x%x)\n", __func__, bar,
		       offset, *((int *)buf));

	return 0;
}

int vastai_ddr_to_bar(struct vastai_pci_info *priv, int die_index, u64 ddr_addr, u64 *bar_addr)
{
	int ret = 0;
	int bar = 0;
	u64 offset = 0;
	int die_id =
		(die_index != -1) ? vastai_pci_get_die_id(priv, die_index) : 0;
	unsigned long long die_offset = die_id * VASTAI_DIE1_BASE;

	u64 absolute_addr = die_offset | ddr_addr;

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, die_id,
				   "%s priv 0x%p or dev 0x%p is NULL\n", __func__,
				   priv, priv->dev);
		return -ENXIO;
	}
	absolute_addr =
		vastai_pci_cal_absolute_addr(priv, die_id, ddr_addr, absolute_addr);

	ret = vastai_pci_select_bar(priv, die_id, absolute_addr, &bar, &offset);
	if (ret) {
		bar = VASTAI_PCI_BAR2;
		offset = absolute_addr - priv->bar[bar].at_addr;
	}

	if (absolute_addr < priv->bar[bar].at_addr ||
		absolute_addr >= (priv->bar[bar].at_addr + priv->bar[bar].mmio_len)) {
		return -EINVAL;
	}

	*bar_addr = priv->bar[bar].mmio_start + offset;

	return 0;
}

int vastai_pci_move_bar_window(struct vastai_pci_info *priv, int die_index, int bar, u64 absolute_addr)
{
	int ret = 0;
	u64 addr = 0;

	addr = absolute_addr / priv->bar[bar].mmio_len *
	       priv->bar[bar].mmio_len;
	if (addr != priv->bar[bar].at_addr) {
#ifdef CONFIG_VASTAI_PCI_SET_BAR
#ifdef CONFIG_SRIOV_ENABLE
		if (priv->is_virtfn) {
			VASTAI_PCI_ERR(
			       priv, die_index,
			       "%s [dangerous] 0x%llx, set BAR(%d) at_addr=0x%lx to addr=0x%llx!\n",
			       __func__, absolute_addr, bar,
			       priv->bar[bar].at_addr, addr);
			dump_stack();
			return -1;
		}
#endif
		ret = vastai_pci_set_bar_at(priv, bar, addr,
					    priv->dies[0].die_index);
		if (ret < 0) {
			return ret;
		}
		VASTAI_PCI_DBG(
			priv, die_index,
			"%s [dangerous] 0x%llx, set BAR(%d) at_addr=0x%lx to addr=0x%llx!\n",
			__func__, absolute_addr, bar,
			priv->bar[bar].at_addr, addr);
#else
		VASTAI_PCI_ERR(
			priv, die_index,
			"%s [dangerous] 0x%llx, set BAR(%d) at_addr=0x%lx to addr=0x%llx!\n",
			__func__, absolute_addr, bar,
			priv->bar[bar].at_addr, addr);
		dump_stack();
		return -1;
#endif
	}

	return ret;
}

int vastai_pci_mem_bar2_read(struct vastai_pci_info *priv, int die_index, u64 absolute_addr,
				 void *buf, unsigned int len)
{
	int ret = 0;
	u64 base_addr = 0;
	u64 offset = 0;

	mutex_lock(&priv->set_bar_lock);
	while(len) {
		u32 tmp_len;
		ret = vastai_pci_move_bar_window(priv, die_index, VASTAI_PCI_BAR2, absolute_addr);
		if(ret < 0) {
			goto OUT;
		}

		base_addr = priv->bar[VASTAI_PCI_BAR2].at_addr;
		offset = absolute_addr - base_addr;
		tmp_len = ((offset + len) > priv->bar[VASTAI_PCI_BAR2].mmio_len) ?
				(priv->bar[VASTAI_PCI_BAR2].mmio_len - offset) : len;
		ret = vastai_pci_bar_read(priv, VASTAI_PCI_BAR2, offset, buf, tmp_len);
		if (ret)
			break;
		len -= tmp_len;
		if (len) {
			buf += tmp_len;
			absolute_addr += tmp_len;
		}
	}
OUT:
	mutex_unlock(&priv->set_bar_lock);

	return ret;
}

/* if die_index == -1, function will default use die_id == 0 */
int vastai_pci_mem_read_direct(struct vastai_pci_info *priv, int die_index,
			u64 relative_addr, void *buf, unsigned int len)
{
	int die_id =
		(die_index != -1) ? vastai_pci_get_die_id(priv, die_index) : 0;
	unsigned long long die_offset = die_id * VASTAI_DIE1_BASE;
	int ret = 0, bar = 0;
	u64 offset = 0;
	u64 absolute_addr = die_offset | relative_addr;

	if (die_id < 0) {
		return die_id;
	}

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s priv 0x%p or dev 0x%p is NULL\n", __func__,
			       priv, priv->dev);
		return -ENXIO;
	}

	absolute_addr = priv->p_trans_addr(priv, die_id, relative_addr, absolute_addr);
	ret = priv->p_select_bar(priv, die_id, absolute_addr, &bar, &offset);
	if(ret) {
		/*set bar*/
		if(vastai_get_board_type(priv) == SV100)
			ret = vastai_pci_mem_bar2_read(priv, die_index, absolute_addr, buf, len);
		if(vastai_get_board_type(priv) == SG100) {
			/* TODO */
			return -1;
		}
	} else {
		u32 tmp_len = 0;

		tmp_len = ((offset + len) > priv->bar[bar].mmio_len) ?
				(priv->bar[bar].mmio_len - offset) : len;
		ret = vastai_pci_bar_read(priv, bar, offset, buf, tmp_len);
		if(ret)
			return ret;

		len -= tmp_len;
		if (len) {
			ret = vastai_pci_mem_read_direct(priv, die_index, relative_addr+tmp_len,
							 buf+tmp_len, len);
		}
	}

	VASTAI_PCI_DBG(priv, die_id,
		       "%s: bar=%d, offset=0x%llx, len=0x%x\n",
		       __func__, bar, offset, len);

	return ret;
}

int vastai_pci_mem_read(struct vastai_pci_info *priv, int die_index,
			u64 relative_addr, void *buf, unsigned int len)
{
	u32 pci_state = atomic_read(&priv->pci_state);

	if (unlikely(pci_state == VASTAI_RESET_STATE || pci_state == VASTAI_NO_RUN_STATE || pci_state == VASTAI_BOOT_STATE
		|| VASTAI_HOTP_STATE == pci_state ||  VASTAI_ERROR_STATE == pci_state)) {
		/* VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die_index),
			       "%s state[%u]\n", __func__,
			       pci_state); */
		return -EBUSY;
	}

	return vastai_pci_mem_read_direct(priv, die_index, relative_addr, buf, len);
}

int vastai_pci_get_die_id(struct vastai_pci_info *pcie_dev, u32 die_index)
{
	return ((union die_index_data)die_index).die_id;
}

int vastai_pci_mem_bar2_write(struct vastai_pci_info *priv, int die_index, u64 absolute_addr,
				const void *buf, unsigned int len)
{
	int ret = 0;
	u64 base_addr = 0;
	u64 offset = 0;

	mutex_lock(&priv->set_bar_lock);
	while(len) {
		u32 tmp_len;
		ret = vastai_pci_move_bar_window(priv, die_index, VASTAI_PCI_BAR2, absolute_addr);
		if(ret < 0) {
			goto OUT;
		}

		base_addr = priv->bar[VASTAI_PCI_BAR2].at_addr;
		offset = absolute_addr - base_addr;
		tmp_len = ((offset + len) > priv->bar[VASTAI_PCI_BAR2].mmio_len) ?
				(priv->bar[VASTAI_PCI_BAR2].mmio_len - offset) : len;
		ret = vastai_pci_bar_write(priv, VASTAI_PCI_BAR2, offset, buf, tmp_len);
		if (ret)
			break;
		len -= tmp_len;
		if (len) {
			buf += tmp_len;
			absolute_addr += tmp_len;
		}
	}
OUT:
	mutex_unlock(&priv->set_bar_lock);

	return ret;
}

/* if die_index == -1, function will default use die_id == 0 */
int vastai_pci_mem_write_direct(struct vastai_pci_info *priv, int die_index,
			 u64 relative_addr, const void *buf, unsigned int len)
{
	int die_id =
		(die_index != -1) ? vastai_pci_get_die_id(priv, die_index) : 0;
	unsigned long long die_offset = die_id * VASTAI_DIE1_BASE;
	int ret = 0, bar = 0;
	u64 offset = 0;
	u64 absolute_addr = die_offset | relative_addr;

	if (die_id < 0) {
		return die_id;
	}

	if ((!priv) || (!priv->dev)) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s priv 0x%p or dev 0x%p is NULL\n", __func__,
			       priv, priv->dev);
		return -ENXIO;
	}
	absolute_addr = priv->p_trans_addr(priv, die_id, relative_addr, absolute_addr);
	ret = priv->p_select_bar(priv, die_id, absolute_addr, &bar, &offset);
	if(ret) {
		/*set bar*/
		if(vastai_get_board_type(priv) == SV100)
			ret = vastai_pci_mem_bar2_write(priv, die_index, absolute_addr, buf, len);
		if(vastai_get_board_type(priv) == SG100) {
			/* TODO */
			return -1;
		}
	} else {
		u32 tmp_len = 0;

		tmp_len = ((offset + len) > priv->bar[bar].mmio_len) ?
				(priv->bar[bar].mmio_len - offset) : len;
		ret = vastai_pci_bar_write(priv, bar, offset, buf, tmp_len);

		len -= tmp_len;
		if (len) {
			ret = vastai_pci_mem_write_direct(priv, die_index, relative_addr+tmp_len,
							 buf+tmp_len, len);
		}
	}

	VASTAI_PCI_DBG(priv, die_id,
		       "%s: bar=%d, offset=0x%llx, len=0x%x\n",
		       __func__, bar, offset, len);

	return ret;
}

int vastai_pci_mem_write(struct vastai_pci_info *priv, int die_index,
			 u64 relative_addr, const void *buf, unsigned int len)
{
	u32 pci_state = atomic_read(&priv->pci_state);

	if (unlikely(pci_state == VASTAI_RESET_STATE || pci_state == VASTAI_NO_RUN_STATE || pci_state == VASTAI_BOOT_STATE
		|| VASTAI_HOTP_STATE == pci_state ||  VASTAI_ERROR_STATE == pci_state)) {
		/* VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die_index),
			       "%s state[%u]\n", __func__,
			       pci_state); */
		return -EBUSY;
	}

	return vastai_pci_mem_write_direct(priv, die_index, relative_addr, buf, len);

}

int vastai_dev_cedar_send_cmd(void *pci_info, void *cedar_info, int dev_id, int die_id, void *hash_output)
{
	unsigned int reg_val;
	int output_hash_len, type;
	int ret = 0;
	int count = 0;
	u64 zero = 0;
	u64 done_flag_addr = 0;
	u64 hash_res_addr = 0;
	u64 zero_hash[8] = {0};
	struct pcie_transfer_cmd trans = {0};
	struct vastai_pci_info *priv = (struct vastai_pci_info *)pci_info;
	struct vastai_cedar_img_info *op = (struct vastai_cedar_img_info *)cedar_info;

	if( die_id < 0 || die_id > 1)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s invalid die id %d\n", __func__, die_id);
		return die_id;
	}
	type = op->alg_type;
	if (type <= 3)
		output_hash_len = 28;
	else if (type <= 7)
		output_hash_len = 32;
	else if (type <= 11)
		output_hash_len = 48;
	else if (type <= 15)
		output_hash_len = 64;
	else if (type <= 19)
		output_hash_len = 32;
	else if (type <= 23)
		output_hash_len = 28;

	mutex_lock(&priv->cedar_lock);

	done_flag_addr = CEDAR_SVC_DONE_FLAG; /* Used to store done flag*/
	hash_res_addr	= CEDAR_SVC_HASH_RES; /* Used to store hash result*/
	vastai_pci_mem_write(priv, dev_id, done_flag_addr, &zero, 4);/* clear sts and done_flag */
	vastai_pci_mem_write(priv, dev_id, hash_res_addr, (void*)zero_hash, 4);

	trans.w0.s_data0.optcode = SMCU_CEDAR_CMD_REQ;
	trans.w1.data1 = CEDAR_SVC_INFO; /*base*/
	trans.w2.data2 = sizeof(struct vastai_cedar_img_info); /*length*/

	vastai_pci_mem_write(priv, dev_id, CEDAR_SVC_INFO, (void*)op, sizeof(struct vastai_cedar_img_info));

	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF, &trans, 0);
	if (ret != 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s write cedar cmd err=%d\n", __func__, ret);
		return ret;
	}
	do {
		vastai_pci_mem_read(priv, dev_id, done_flag_addr, &reg_val, sizeof(reg_val));
		count++;
	} while((reg_val != 0xFF)&&(count < 0xFFFFFFFF));
	if(count >= 0xFFFF)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s read done flag timeout\n", __func__);
		mutex_unlock(&priv->cedar_lock);
		return -ETIMEDOUT;
	}
	if(type <= 23){
		vastai_pci_mem_read(priv, dev_id, hash_res_addr, (void*)hash_output, output_hash_len);
		//vastai_pci_mem_write(priv, dev_id, hash_res_addr, (void*)zero_hash, 4);
	}
	mutex_unlock(&priv->cedar_lock);

	return 0;
}
EXPORT_SYMBOL(vastai_dev_cedar_send_cmd);

static int vastai_pci_is_32_bit_thread(void)
{
	int is_32_bit = 0;
#if (defined(__aarch64__) || defined(__arm__))
	is_32_bit = test_thread_flag(TIF_32BIT);
#else
	is_32_bit = test_thread_flag(TIF_ADDR32);
#endif

	return is_32_bit;
}

unsigned long vastai_pci_copy_to_user(void __user *to, const void *from, unsigned long n)
{
	unsigned long ret = 0;
#ifdef CONFIG_COMPAT
	if (vastai_pci_is_32_bit_thread()) {
		ret = copy_to_user(
			(void __user *)compat_ptr((compat_uptr_t)(((u64)to) & 0xffffffff)),
			from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
		return ret;
	} else
#endif
	{
		ret = copy_to_user(to, from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
		return ret;
	}
	return 0;
}

unsigned long vastai_pci_copy_from_user(void *to, const void __user *from, unsigned long n)
{
	unsigned long ret = 0;
#ifdef CONFIG_COMPAT
	if (vastai_pci_is_32_bit_thread()) {
		ret = copy_from_user(
			to,
			(void __user *)compat_ptr((compat_uptr_t)(((u64)from) & 0xffffffff)),
			n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
		return ret;
	} else
#endif
	{
		ret = copy_from_user(to, from, n);
		if (ret) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				__func__, to, from, n, ret);
		}
		return ret;
	}
	return 0;
}

int vastai_pci_generation_sel(struct vastai_pci_info *priv, u8 gen)
{
	u64 reg_addr = 0;
	u32 reg_val = 0;
	u8 lnksta = 0, lnkcap = 0, lnkcnt = 0;
	unsigned int die_index = priv->dies[0].die_index;
	int ret = 0;

	if ((gen < VASTAI_PCI_GEN1) || (gen > VASTAI_PCI_GEN4)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s cann't switch Host/Die0 to GEN%d\n",
			       __func__, gen);
		return -EINVAL;
	}

	/* try to change generation up to 10 times */
	while (lnkcnt < 10) {
		/* configurate target link speed (LnkCtl2) */
		ret = pci_read_config_dword(
			priv->dev, PCIE_LINK_CONTROL_STATUS_REG2_OFFSET,
			&reg_val);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s Host/Die0 err=%d\n", __func__, ret);
			return -1;
		}
		reg_val = (reg_val & 0xFFFFFFF0) | gen;
		ret = pci_write_config_dword(
			priv->dev, PCIE_LINK_CONTROL_STATUS_REG2_OFFSET,
			reg_val);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s Host/Die0 err=%d\n", __func__, ret);
			return -1;
		}

		/* get negotiated link speed */
		ret = pci_read_config_dword(priv->dev,
					    PCIE_LINK_CONTROL_STATUS_REG_OFFSET,
					    &reg_val);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s err=%d\n",
				       __func__, ret);
			return -1;
		}
		lnksta = (reg_val & 0x000F0000) >> 16;
		if (gen == lnksta) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"%s Host/Die0 lnksta=GEN%d.\n",
					__func__, gen);
			return 0;
		}

		/* configurate pcie_generation_sel(bit18:17) to GEN4 */
		reg_addr = VASTAI_PCI_CONFIGURATION_IO_0;
		ret = vastai_pci_mem_read(priv, die_index, reg_addr, &reg_val,
					  4);
		if (ret < 0) {
			return -EIO;
		}
		lnkcap = ((reg_val & 0x00060000) >> 17) + 1;
		if (gen > lnkcap) {
			reg_val = (reg_val & 0xFFF9FFFF) | (3 << 17);
			vastai_pci_mem_write(priv, die_index, reg_addr,
					     &reg_val, 4);
			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"configurate Host/Die0 pcie_generation_sel to GEN4\n");
		}

		/* trigger link retraining */
		reg_addr = VASTAI_PCI_CDN_LINKWIDTH_CONTROL_REG;
		while (1) {
			ret = vastai_pci_mem_read(priv, die_index, reg_addr,
						  &reg_val, 4);
			if (ret < 0) {
				return -EIO;
			}
			/* sw must wait for retrain link bit to be clear before
			 * setting it again. */
			if ((reg_val & 0x80000000) == 0)
				break;
		}
		reg_val &= 0xFCFFFFFF;
		reg_val |= ((gen - 1) << 24) | (1u << 31);
		vastai_pci_mem_write(priv, die_index, reg_addr, &reg_val, 4);
		mdelay(3);
		lnkcnt++;
	}
	return 0;
}

int vastai_pci_generation_sel_slave_die(struct vastai_pci_info *priv, u8 gen,
					u32 die_id)
{
	u64 reg_addr = 0;
	u32 reg_val = 0, next_die_id = die_id + 1;
	u8 lnksta = 0, lnkcap = 0, lnkcnt = 0;
	int ret = 0;

	if ((gen < VASTAI_PCI_GEN1) || (gen > VASTAI_PCI_GEN4)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s cann't switch Die%d/Die%d to GEN%d\n",
			       __func__, die_id, next_die_id, gen);
		return -EINVAL;
	}

	/* try to change generation up to 10 times */
	while (lnkcnt < 10) {
		/* get negotiated link speed */
		reg_addr = VASTAI_PCI_LINK_CONTROL_STATUS_REG;
		ret = vastai_pci_mem_read(priv,
					  priv->dies[next_die_id].die_index,
					  reg_addr, &reg_val, 4);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s Die%d/Die%d err=%d\n", __func__,
				       die_id, next_die_id, ret);
			return -1;
		}
		lnksta = (reg_val & 0x000F0000) >> 16;
		if (gen == lnksta) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"%s Die%d/Die%d lnksta=GEN%d.\n",
					__func__, die_id, next_die_id, gen);
			return 0;
		}

		/* configurate pcie_generation_sel(bit18:17) to GEN4 */
		reg_addr = VASTAI_PCI_CONFIGURATION_IO_0;
		ret = vastai_pci_mem_read(priv,
					  priv->dies[next_die_id].die_index,
					  reg_addr, &reg_val, 4);
		if (ret < 0) {
			return -EIO;
		}
		lnkcap = ((reg_val & 0x00060000) >> 17) + 1;
		if (gen > lnkcap) {
			reg_val = (reg_val & 0xFFF9FFFF) | (3 << 17);
			vastai_pci_mem_write(priv,
					     priv->dies[next_die_id].die_index,
					     reg_addr, &reg_val, 4);
			VASTAI_PCI_DBG(
				priv, DUMMY_DIE_ID,
				"configurate Die%d/Die%d pcie_generation_sel to GEN4\n",
				die_id, next_die_id);
		}

		/* configurate target link speed (LnkCtl2) */
		reg_addr = VASTAI_PCI_LINK_CONTROL_STATUS_REG2;
		ret = vastai_pci_mem_read(priv,
					  priv->dies[next_die_id].die_index,
					  reg_addr, &reg_val, 4);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s Die%d/Die%d err=%d\n", __func__,
				       die_id, next_die_id, ret);
			return -1;
		}
		reg_val = (reg_val & 0xFFFFFFF0) | gen;
		vastai_pci_mem_write(priv, priv->dies[next_die_id].die_index,
				     reg_addr, &reg_val, 4);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s Die%d/Die%d err=%d\n", __func__,
				       die_id, next_die_id, ret);
			return -1;
		}

		/* trigger link retraining */
		reg_addr = VASTAI_PCI_CDN_LINKWIDTH_CONTROL_REG;
		while (1) {
			ret = vastai_pci_mem_read(
				priv, priv->dies[next_die_id].die_index,
				reg_addr, &reg_val, 4);
			if (ret < 0) {
				return -EIO;
			}
			/* sw must wait for retrain link bit to be clear before
			 * setting it again. */
			if ((reg_val & 0x80000000) == 0)
				break;
		}
		reg_val &= 0xFCFFFFFF;
		reg_val |= ((gen - 1) << 24) | (1u << 31);
		vastai_pci_mem_write(priv, priv->dies[next_die_id].die_index,
				     reg_addr, &reg_val, 4);

		lnkcnt++;
	}
	return 0;
}

void vastai_pop_core(void *p_irq_idx)
{
	u32 irq_idx = *(u32*)p_irq_idx;
	struct vastai_core *core = container_of((p_irq_idx-irq_idx*sizeof(u32)), struct vastai_core, irq_idx);
	unsigned long flags = 0;
	u32 ivt_index = core->cores_info_ref->die_irq[irq_idx];
	struct vastai_sv100_die *die = core->die;
	vastai_intr_handle handle;
	void *pd;
	void *out = (void*)(&(die->ivt[ivt_index].out));

	if (core_exception_en) {
		if(core->is_exception)
			return;
	}

	handle = die->ivt[ivt_index].intr_handle;
	pd = die->ivt[ivt_index].private_data;

	spin_lock_irqsave(&(core->rd_ring_buf_lock), flags);
	while (!vastai_fifo_pop_elem(die->pci_info, die->die_index, core->cores_info_ref->pop_fifo_addr[irq_idx],
				     out, core->pop_cache[irq_idx], NORMAL_FIFO)) {
		core->pcie_rx_core_count += 1;
		if (handle) {
			handle(die->pci_info, die->die_index, ivt_index, pd, out);
		}
	}
	spin_unlock_irqrestore(&(core->rd_ring_buf_lock), flags);

	return;
}

void vastai_pop_all_odsp(void *p_irq_idx)
{
	u32 irq_idx = *(u32*)p_irq_idx;
	struct vastai_core *core = container_of((p_irq_idx-irq_idx*sizeof(u32)), struct vastai_core, irq_idx);
	unsigned long flags = 0;
	u32 ivt_index = core->cores_info_ref->die_irq[irq_idx];
	struct vastai_sv100_die *die = core->die;
	vastai_intr_handle handle;
	void *pd;
	struct out_desc out;
	int i = 0;

	if (core_exception_en) {
		/* odsp exception is same with ai-sys exception */
		if(die->core[CORE_POINT_CMCU].is_exception)
			return;
	}

	handle = die->ivt[ivt_index].intr_handle;
	pd = die->ivt[ivt_index].private_data;

	for(i=CORE_POINT_ODSP0; i<=CORE_POINT_ODSP7; i++) {
		core = &die->core[i];
		spin_lock_irqsave(&(core->rd_ring_buf_lock), flags);
		while (!vastai_fifo_pop_elem(die->pci_info, die->die_index, core->cores_info_ref->pop_fifo_addr[irq_idx],
					     &out, NULL, NORMAL_FIFO)) {
			core->pcie_rx_core_count += 1;
			if (handle) {
				handle(die->pci_info, die->die_index, ivt_index, pd, &out);
			}
		}
		spin_unlock_irqrestore(&(core->rd_ring_buf_lock), flags);
	}

	return;
}


static int vastai_pci_legacy_irq(int irq, void *arg)
{
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "legacy irq called %d\n", irq);

	// legacy_irq_handle(irq);

	return IRQ_HANDLED;
}

int va_register_pcie_interrupt(struct vastai_pci_info *priv,
				  u32 interrupt_id,
				  void (*handler_function)(void *),
				  void *arg)
{
	//unsigned long flags;

	if (!handler_function) {
		VASTAI_PCI_ERR(priv, 0,
				"%s: handler_function is null\n", __func__);
		return -EINVAL;
	}

	if (interrupt_id >= ADDR(priv, VASTAI_PCIE_MSIX_NUM)) {
		VASTAI_PCI_ERR(priv, 0,
				"%s: interrupt_id is invalid, %d\n",
				__func__, interrupt_id);
		return -EINVAL;
	}

	// TODO
	//spin_lock_irqsave(, flags);

	if (priv->irq_handles[interrupt_id].handler_function) {
		VASTAI_PCI_DBG(priv, 0,
			"%s: handler_function has beed registered, %p\n",
			__func__,
			priv->irq_handles[interrupt_id].handler_function);
		return 0;
	}
	priv->irq_handles[interrupt_id].arg = arg;
	priv->irq_handles[interrupt_id].handler_function = handler_function;
	// TODO
	//spin_unlock_irqrestore(, flags);

	return 0;
}

int va_unregister_pcie_interrupt(struct vastai_pci_info *priv,
				 u32 interrupt_id)
{
	if (interrupt_id >= VASTAI_PCIE_MSIX_SG100_NUM) {
		VASTAI_PCI_ERR(priv, 0,
				"%s: interrupt_id is invalid, %d\n",
				__func__, interrupt_id);
		return -EINVAL;
	}

	priv->irq_handles[interrupt_id].handler_function = NULL;
	priv->irq_handles[interrupt_id].arg = NULL;

	return 0;
}

extern void smcu_and_cmcu_msix_callback(void *arg);

void vastai_dma_done(void *data)
{
	struct vastai_sv100_die *dies = data;

	queue_work(dies->udma_wq, &dies->dma_done);
	return;
}

void vastai_complete_atu(void *priv)
{
	/* sometimes slave die can't access fifo elem */
	complete(&((struct vastai_pci_info *)priv)->switch_atu_comp);
	return;
}

static int vastai_pci_msi_irq(int irq, void *arg)
{
	struct msix_entry *msix = arg;
	struct vastai_pci_info *priv;
	struct vastai_interrupt_handle *irq_handle;

	if (!msix) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			"irq handle arg is NULL. irq %d\n", irq);
		return IRQ_HANDLED;
	}
	irq = msix->entry;

	priv = container_of(msix, typeof(*priv), msix[msix->entry]);
	if (!priv) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			"irq handle pcie_info is NULL. irq %d arg %p msix %p\n",
			irq, arg, msix);
		return IRQ_HANDLED;
	}

	if (atomic_read(&(priv->pci_state)) == VASTAI_EXIT_STATE)
		if(SMCU_2_HOST_INT1 != irq%(VASTAI_PCIE_MSIX_SV100_NUM/VASTAI_SV100_MAX_DIE_NUM)) /* this irq is for spe fifo*/
			return IRQ_HANDLED;

	irq_handle = &priv->irq_handles[irq];
	if (irq_handle->handler_function) {
		irq_handle->handler_function(irq_handle->arg);
		return IRQ_HANDLED;
	}

	return IRQ_HANDLED;
}

static int vastai_pci_disable_irq(struct vastai_pci_info *priv)
{
	int i = 0;

	if (priv->irq_type == VASTAI_MSIX_IRQ) {
		for (i = 0; i < priv->irq_num; i++) {
			disable_irq(priv->msix[i].vector);
			free_irq(priv->msix[i].vector, (void *)&(priv->msix[i]));
			VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
				       "%s disable_irq(%d) ok\n", __func__,
				       priv->msix[i].vector);
		}
		pci_disable_msix(priv->dev);
	}

	if (priv->irq_type == VASTAI_MSI_IRQ) {
		for (i = 0; i < priv->irq_num; i++) {
			if (priv->irq) {
				disable_irq(priv->irq + i);
				if (!free_irq(priv->irq + i, (void *)&(priv->msix[i])))
					return -1;
			}
		}

		pci_disable_msi(priv->dev);
	}

	return 0;
}

int vastai_irq_register(struct vastai_pci_info *pcie_dev, int die_index,
			int irq, /* reference vastai_sv100_reg.h +272 */
			vastai_intr_handle handle,
			void *private_data) /* for user keep self data */
{
	int die_id = vastai_pci_get_die_id(pcie_dev, die_index);

	if (die_id < 0) {
		return -ENODEV;
	}
	pcie_dev->dies[die_id].ivt[irq].intr_handle = handle;
	pcie_dev->dies[die_id].ivt[irq].private_data = private_data;
	return 0;
}

int vastai_irq_unregister(struct vastai_pci_info *pcie_dev, int die_index,
			  int irq) /* reference vastai_sv100_reg.h +272 */
{
	int die_id = vastai_pci_get_die_id(pcie_dev, die_index);

	if (die_id < 0) {
		return -ENODEV;
	}
	pcie_dev->dies[die_id].ivt[irq].intr_handle = NULL;
	pcie_dev->dies[die_id].ivt[irq].private_data = NULL;
	return 0;
}

bool isCoreReseting(struct vastai_pci_info *priv, u32 die_id, int core_index)
{
	/*cmcu*/
	if(core_index == 0) {
		if(priv->vadev.dev_cap != VASTAI_HW_TYPE_VIDEO_ONLY)
			if(priv->dies[die_id].heartbeat_mask & (1<<HEARTBEAT_CMCU))
				return true;
	} else if (core_index>=8 && core_index<=11) { /*vdsp*/
		if(priv->dies[die_id].heartbeat_mask & (1<<(HEARTBEAT_VDSP0 + core_index - 8)))
			return true;
	}

	return false;
}
int vastai_pci_flr(struct vastai_pci_info *priv)
{
	int ret = 0;

	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s\n", __func__);

#if KERNEL_VERSION(4, 20, 0) <= LINUX_VERSION_CODE
	priv->dev->imm_ready = 0;

	pci_save_state(priv->dev);
	pci_cfg_access_lock(priv->dev);

	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s() to save state, then to do flr\n", __func__);
	ret = pcie_flr(priv->dev);
	if(ret < 0) {
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "pcie_flr fail, ret=%d", ret);
	}

	pci_cfg_access_unlock(priv->dev);

	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s() to pci_restore_state\n", __func__);
	pci_restore_state(priv->dev);
#else
	// TBD, need detect whether the dev support FLR.
	pcie_flr(priv->dev);
#endif

	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s() End of pci_restore_state\n", __func__);

	return ret;
}

int vastai_trans_core_idx(int core_index)
{
	switch(core_index) {
		case 0:
			return CORE_POINT_CMCU;
		case 8:
		case 12:
			return CORE_POINT_VDSP0;
		case 9:
		case 13:
			return CORE_POINT_VDSP1;
		case 10:
		case 14:
			return CORE_POINT_VDSP2;
		case 11:
		case 15:
			return CORE_POINT_VDSP3;
		case 20:
			return CORE_POINT_ODSP0;
		case 21:
			return CORE_POINT_ODSP1;
		case 22:
			return CORE_POINT_ODSP2;
		case 23:
			return CORE_POINT_ODSP3;
		case 24:
			return CORE_POINT_VDMCU0;
		case 25:
			return CORE_POINT_VDMCU1;
		case 26:
			return CORE_POINT_VDMCU2;
		case 28:
			return CORE_POINT_ODSP4;
		case 29:
			return CORE_POINT_ODSP5;
		case 30:
			return CORE_POINT_ODSP6;
		case 31:
			return CORE_POINT_ODSP7;
		default:
			return -1;
			break;
	}

	return -1;
}

int vastai_trans_core_fifo_index(int core_index)
{
	switch(core_index) {
		case 0:
		case 8:
		case 9:
		case 10:
		case 11:
		case 24:
		case 25:
		case 26:
		case 20:
		case 21:
		case 22:
		case 23:
		case 28:
		case 29:
		case 30:
		case 31:
			return 0;
		case 12:
		case 13:
		case 14:
		case 15:
			return 1;
		default:
			return -1;
			break;
	}

	return -1;
}
/*==================== DMA transfer && MSG api ====================*/
/* Don't call this function at irq, This only use spin_lock */
int vastai_pci_send_msg_pid(void *pcie_dev, int die_index,
			union core_bitmap core_id, void *msg_buf, u32 msg_len, pid_t pid)
{
	u32 temp_core_bitmap = core_id.val;
	int ret = 0;
	struct vastai_pci_info *priv = pcie_dev;
	u32 die_id = vastai_pci_get_die_id(pcie_dev, die_index);
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	VASTAI_PCI_DBG(pcie_dev, die_id,
		       "%s: die=%d, core_id=0x%x, msg_buf=0x%p, len=0x%x\n",
		       __func__, die_index, core_id.val, msg_buf, msg_len);

	while (temp_core_bitmap) {
		int core_index = ffs(temp_core_bitmap) - 1;
		int core_idx   = vastai_trans_core_idx(core_index);
		u64 int_addr = 0;
		u32 is_use_ring_buf = 0;
		u64 msg_addr;
		u32 msg_addr_dev;
		int fifo_index = vastai_trans_core_fifo_index(core_index);

		if(core_idx == -1) {
			VASTAI_PCI_ERR(
				pcie_dev,
				die_id,
				"invalid core_idx\n");
			return -1;
		}
		int_addr = die->core[core_idx].cores_info_ref->interrupt_addr;
		is_use_ring_buf = die->core[core_idx].cores_info_ref->is_use_ring_buf;
		if (fifo_index == -1) {
			VASTAI_PCI_ERR(
				pcie_dev,
				die_id,
				"invalid core_index:%x\n", core_index);
			return -1;
		}
		msg_addr = die->core[core_idx].cores_info_ref->push_fifo_addr[fifo_index];
		msg_addr_dev = 0x80000000 | msg_addr;
		temp_core_bitmap &= ~(BIT(core_index));

		if (!int_addr || !msg_addr) {
			VASTAI_PCI_ERR(
				pcie_dev,
				die_id,
				"send_msg with err addr. core_id[0x%x] intr[0x%llx] msg[0x%llx]\n",
				core_id.val, int_addr, msg_addr);
			continue;
		}

		if (is_use_ring_buf) {
			if(isCoreReseting(pcie_dev, die_id, core_index)) {
				ret = -ENOMEM;
				break;
			}
			/* msg is a ring buf. There is fifo info at ring head. */

			spin_lock(&(die->core[core_idx].wr_ring_buf_lock));

			ret = vastai_fifo_push_elem(pcie_dev, die_index,
						    msg_addr, msg_buf,
						    die->core[core_idx].push_cache[fifo_index]);

			/* get performance info */
			if (!ret)
				die->core[core_idx].pcie_tx_core_count += 1;

			spin_unlock(&(die->core[core_idx].wr_ring_buf_lock));
		} else {
			ret = vastai_pci_mem_write(pcie_dev, die_index,
						   msg_addr, msg_buf, msg_len);
		}

		if (ret == -ENOMEM) {
			break;
		} else if (ret) {
			VASTAI_PCI_ERR(pcie_dev,
				       die_id,
				       "write msg error %d\n", ret);
			break;
		}

		ret = vastai_pci_mem_write(pcie_dev, die_index, int_addr,
					   &msg_addr_dev, 4);
		if (ret) {
			VASTAI_PCI_ERR(pcie_dev,
				       die_id,
				       "write int error %d\n", ret);
			break;
		}
	}

	return ret;
}

int vastai_pci_send_cmdbuf_pid(void *pcie_dev, int die_index,
			u32 buf_index, void *msg_buf, u32 msg_len, pid_t pid)
{
	int ret = 0;
	struct vastai_pci_info *priv = pcie_dev;
	u32 die_id = vastai_pci_get_die_id(pcie_dev, die_index);
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	u32 core_idx = CORE_POINT_CMCU;
	u64 msg_addr;
	u32 msg_addr_dev;

	VASTAI_PCI_DBG(pcie_dev, die_id,
		       "%s: die=%d, buf_index=0x%x, msg_buf=0x%p, len=0x%x\n",
		       __func__, die_index, buf_index, msg_buf, msg_len);

	msg_addr = MSG_PCIE_TO_CMDBUF + (buf_index*VASTAI_CMD_BUF_LEN);
	msg_addr_dev = 0x80000000 | msg_addr;

	if(isCoreReseting(pcie_dev, die_id, core_idx)) {
		ret = -ENOMEM;
		goto out;
	}
	/* msg is a ring buf. There is fifo info at ring head. */

	spin_lock(&(die->core[core_idx].wr_ring_buf_lock));
	ret = vastai_fifo_push_elem(pcie_dev, die_index,
				    msg_addr, msg_buf, NULL);

	/* get performance info */
	die->core[core_idx].pcie_tx_core_count += 1;
	spin_unlock(&(die->core[core_idx].wr_ring_buf_lock));

	if (ret == -ENOMEM) {
		goto out;
	} else if (ret) {
		VASTAI_PCI_ERR(pcie_dev,
			       die_id,
			       "write msg error %d\n", ret);
		goto out;
	}
#if 0
	ret = vastai_pci_mem_write(pcie_dev, die_index, int_addr,
				   &msg_addr_dev, 4);
	if (ret)
		VASTAI_PCI_ERR(pcie_dev,
			       die_id,
			       "write int error %d\n", ret);
#endif
out:
	return ret;
}

int vastai_pci_send_msg_sv(void *pcie_dev, int die_index,
			union core_bitmap core_id, void *msg_buf, u32 msg_len)
{
	return vastai_pci_send_msg_pid(pcie_dev, die_index,
				core_id, msg_buf, msg_len, -1);

}

int vastai_pci_reset_bus(struct vastai_pci_info *priv)
{
	int ret = 0;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "start to reset pcie bus.\n");
#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	vastai_enable_pcie_link_monitor(priv, false);
#endif

	ret = pci_probe_reset_bus(priv->dev->bus);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "pci_probe_reset_bus fail, ret=%d", ret);
		return ret;
	}
	priv->dev->state_saved = true;
#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 0)
	pci_reset_bridge_secondary_bus(priv->dev->bus->self);
#else
	ret = pci_bridge_secondary_bus_reset(priv->dev->bus->self);
#endif
#elif KERNEL_VERSION(4, 19, 0) <= LINUX_VERSION_CODE
	ret = pci_bridge_secondary_bus_reset(priv->dev->bus->self);
#else
	pci_reset_bridge_secondary_bus(priv->dev->bus->self);
#endif
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "pci_reset_bus fail, ret=%d",
			       ret);
		return ret;
	}
#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	if(atomic_read(&(priv->pci_link_stat.is_reseting))) {
		priv->dev->saved_config_space[8] = 0;
		priv->dev->saved_config_space[9] = 0;
	}
#endif
	pci_restore_state(priv->dev);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "reset pcie bus finish.\n");

	return ret;
}

void vastai_pci_set_vdsp_depth(struct vastai_pci_info *priv, u32 die_id,
			       u32 elem_count, u32 flag)
{
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	int die_index = die->die_index;
	struct vastai_fifo fifo = { 0 };

	if (elem_count > VASTAI_PCIE_2_VDSP_MSG_DEPTH) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s elem_cout %d overflow, set to %ld\n",
			       __func__, elem_count,
			       VASTAI_PCIE_2_VDSP_MSG_DEPTH);
		elem_count = VASTAI_PCIE_2_VDSP_MSG_DEPTH;
	}
	spin_lock(&(die->core[CORE_POINT_VDSP0].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP1].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP2].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP3].wr_ring_buf_lock));
	fifo.elem_count = elem_count;
	fifo.elem_size = sizeof(union buf_data);
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP0, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP1, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP2, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP3, &fifo,
			     sizeof(fifo));
	if (flag) {
		VASTAI_PCI_INFO(
			priv, die_index,
			"init vdsp fifo: rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
			fifo.rd, fifo.wr, fifo.elem_count, fifo.elem_size);
	}
	spin_unlock(&(die->core[CORE_POINT_VDSP0].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP1].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP2].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP3].wr_ring_buf_lock));
}

void vastai_pci_set_vdsp_2st_depth(struct vastai_pci_info *priv, u32 die_id,
			       u32 elem_count, u32 flag)
{
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	int die_index = die->die_index;
	struct vastai_fifo fifo = { 0 };

	if (elem_count > VASTAI_PCIE_2_VDSP_2ST_MSG_DEPTH) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s elem_cout %d overflow, set to %ld\n",
			       __func__, elem_count,
			       VASTAI_PCIE_2_VDSP_2ST_MSG_DEPTH);
		elem_count = VASTAI_PCIE_2_VDSP_2ST_MSG_DEPTH;
	}
	spin_lock(&(die->core[CORE_POINT_VDSP0].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP1].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP2].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_VDSP3].wr_ring_buf_lock));
	fifo.elem_count = elem_count;
	fifo.elem_size = sizeof(union buf_data);
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP0_1, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP1_1, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP2_1, &fifo,
			     sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_PCIE_TO_VDSP3_1, &fifo,
			     sizeof(fifo));
	if (flag) {
		VASTAI_PCI_INFO(
			priv, die_index,
			"init vdsp fifo: rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
			fifo.rd, fifo.wr, fifo.elem_count, fifo.elem_size);
	}
	spin_unlock(&(die->core[CORE_POINT_VDSP0].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP1].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP2].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_VDSP3].wr_ring_buf_lock));
}

void vastai_pci_set_odsp_depth(struct vastai_pci_info *priv, u32 die_id,
					 u32 elem_count)
{
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	int die_index = die->die_index;
	struct vastai_fifo fifo = { 0 };

	if (elem_count > VASTAI_PCIE_2_ODSP_MSG_DEPTH) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s elem_cout %d overflow, set to %ld\n",
			       __func__, elem_count,
			       VASTAI_PCIE_2_ODSP_MSG_DEPTH);
		elem_count = VASTAI_PCIE_2_ODSP_MSG_DEPTH;
	}
	spin_lock(&(die->core[CORE_POINT_ODSP0].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP1].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP2].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP3].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP4].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP5].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP6].wr_ring_buf_lock));
	spin_lock(&(die->core[CORE_POINT_ODSP7].wr_ring_buf_lock));
	fifo.elem_count = elem_count;
	fifo.elem_size = sizeof(union buf_data);
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP0, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP1, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP2, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP3, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP4, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP5, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP6, &fifo,
					sizeof(fifo));
	vastai_pci_mem_write_direct(priv, die_index, MSG_CMCU_TO_ODSP7, &fifo,
					sizeof(fifo));
	spin_unlock(&(die->core[CORE_POINT_ODSP0].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP1].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP2].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP3].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP4].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP5].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP6].wr_ring_buf_lock));
	spin_unlock(&(die->core[CORE_POINT_ODSP7].wr_ring_buf_lock));
}
void vastai_pci_set_cmcu_depth(struct vastai_pci_info *priv, u32 die_id, u32 elem_count)
{
	struct vastai_sv100_die *die = &(priv->dies[die_id]);
	int die_index = die->die_index;
	struct vastai_fifo fifo = {0};

	if (elem_count > VASTAI_PCIE_2_CMCU_MSG_DEPTH) {
		VASTAI_PCI_ERR(priv, die_id,
				"%s elem_cout %d overflow, set to %ld\n",
				__func__, elem_count, VASTAI_PCIE_2_CMCU_MSG_DEPTH);
		elem_count = VASTAI_PCIE_2_CMCU_MSG_DEPTH;
	}
	spin_lock(&(die->core[CORE_POINT_CMCU].wr_ring_buf_lock));
	fifo.elem_count = elem_count;
	fifo.elem_size = sizeof(union buf_data);
	vastai_pci_mem_write_direct(priv,
			     die_index,
			     MSG_PCIE_TO_CMCU,
			     &fifo,
			     sizeof(fifo));
	VASTAI_PCI_DBG(priv, die_index,
		       "init cmcu fifo: rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x]\n",
		       fifo.rd, fifo.wr, fifo.elem_count, fifo.elem_size);
	spin_unlock(&(die->core[CORE_POINT_CMCU].wr_ring_buf_lock));
}

/* Each function has its own vmsgq 0/1, but they
 * may share and compete the same physical msgq.
 */
int vastai_get_msgq_id(struct vastai_pci_info *priv, int type)
{
	int msgq_id = -1;
	if (type == MSGQ_DMA) {
		msgq_id = MSGQ_ID_0;
	} else if (type == MSGQ_CMD) {
		msgq_id = MSGQ_ID_1;
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s wrong msgq cmd_type=%d",
					   __func__, type);
	}
	return msgq_id;
}

int vastai_send_pcie_cmd(struct vastai_pci_info *priv, u32 die_index,
			 u32 sub_cmd, u64 paras)
{
	struct pcie_transfer_info trans = {
		.type = VASTAI_PCIE,
		.pcie_config_addr = sub_cmd,
		.data_struct_addr = paras,
	};
	int ret = 0;
	u32 die_id = vastai_pci_get_die_id(priv, die_index);
	u32 msgq_id;

	msgq_id = vastai_get_msgq_id(priv, MSGQ_CMD);
	ret = vastai_pci_vmsgq_wr(&(priv->dies[die_id].vmsgq[msgq_id]),
				 &trans, sizeof(trans));

	if (ret) {
		VASTAI_PCI_ERR(priv, die_index, "%s sub_cmd[%d] error, ret=%d",
			       __func__, sub_cmd, ret);
		return -EINVAL;
	}

	return 0;
}

int vastai_send_pcie_cmd_spe(struct vastai_pci_info *priv, u32 die_index,
					u32 sub_cmd, u64 paras)
{
	struct pcie_transfer_info trans = {
		.type = VASTAI_PCIE,
		.pcie_config_addr = sub_cmd,
		.data_struct_addr = paras,
	};
	int ret = 0;
	u32 die_id = vastai_pci_get_die_id(priv, die_index);
	u32 msgq_id;

	msgq_id = vastai_get_msgq_id(priv, MSGQ_CMD);
	ret = vastai_pci_vmsgq_wr_spe(&(priv->dies[die_id].vmsgq[msgq_id]),
				 &trans, sizeof(trans));

	if (ret) {
		VASTAI_PCI_ERR(priv, die_index, "%s sub_cmd[%d] error, ret=%d",
			       __func__, sub_cmd, ret);
		return -EINVAL;
	}

	return 0;
}

/**
 * @brief send a ctrl cmd to smcu by msgqueue1, smcu will retransmit interrupt to
 * 	other mcu / vdsp.
 *
 * @param pci_info: vastai sv100 pci base struct.
 * @param die_index: the destination die.
 * @param core_bit_map: this is a __BIT_MAP__ smcu will trigger it one by one.
 * @param info: private data. low 8bit is invalied. (for seq_id)
 * @return int: zero is success.
 */
int vastai_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
			 u32 core_bit_map, u64 info)
{
	struct pcie_transfer_info trans = {
		.type = VASTAI_PCIE_CTRL_QUEUE,
		.pcie_config_addr = core_bit_map,
		.data_struct_addr = info,
	};
	int ret = 0;
	u32 msgq_id;
	u32 die_id = vastai_pci_get_die_id(pci_info, die_index);
	struct ctrl_cmd_list *cmd_list = &pci_info->dies[die_id].ctrl_cmd_list;
	u8 seq_id = atomic_inc_return(&cmd_list->ctrl_seq_id) & 0xFF;
	struct ctrl_cmd_entry *cmd_entry =
		vmalloc(sizeof(struct ctrl_cmd_entry));
	unsigned long irq_flag;

	if (!cmd_entry) {
		return -ENOMEM;
	}
	cmd_entry->seq_id = seq_id;
	INIT_LIST_HEAD(&cmd_entry->list);
	init_completion(&cmd_entry->msg_comp);
	cmd_entry->completion_info.smcu_to_host.val = 0;

	spin_lock_irqsave(&cmd_list->ctrl_cmd_list_lock, irq_flag);
	/* we expect the response (completion) to be orderly from fw,
	so used list_add_tail and not performance tuning */
	list_add_tail(&cmd_entry->list, &cmd_list->ctrl_cmd_head.list);
	spin_unlock_irqrestore(&cmd_list->ctrl_cmd_list_lock, irq_flag);

	trans.data_struct_addr &= ~(0xFF);
	trans.data_struct_addr |= (seq_id & (0xFF));

	msgq_id = vastai_get_msgq_id(pci_info, MSGQ_CMD);
	ret = vastai_pci_vmsgq_wr(&(pci_info->dies[die_id].vmsgq[msgq_id]), &trans,
				 sizeof(trans));
	if (ret) {
		goto FREE_CMD_ENTRY;
	}

	ret = wait_for_completion_interruptible_timeout(&cmd_entry->msg_comp,
							1000);
	if (ret == 0) {
		ret = -ETIMEDOUT;
	}

	if (ret > 0) {
		ret = cmd_entry->completion_info.ret_st.ret_val;
	}

FREE_CMD_ENTRY:
	spin_lock_irqsave(&cmd_list->ctrl_cmd_list_lock, irq_flag);
	list_del(&cmd_entry->list);
	spin_unlock_irqrestore(&cmd_list->ctrl_cmd_list_lock, irq_flag);
	vfree(cmd_entry);
	return ret;
}

/**
 * @brief recv a ctrl cmd completion from smcu, checkout ctrl cmd list, and call
 * 	completion done for it.
 *
 * @param pci_info: vastai sv100 pci base struct.
 * @param die_index: the destination die.
 * @param msg: smcu to host msg. will cpy for user thread.
 */
void vastai_ctrl_cmd_compeletion(struct vastai_pci_info *pci_info,
				 u32 die_index, struct smcu_to_host_msg1 *msg)
{
	unsigned long irq_flag;
	u32 die_id = vastai_pci_get_die_id(pci_info, die_index);
	struct ctrl_cmd_list *cmd_list = &pci_info->dies[die_id].ctrl_cmd_list;
	union completion_info_st *info_st = (union completion_info_st *)msg;
	struct ctrl_cmd_entry *entry = NULL;
	struct ctrl_cmd_entry *tmp;
	int cmd_list_len = 0;

	spin_lock_irqsave(&cmd_list->ctrl_cmd_list_lock, irq_flag);
	list_for_each_entry (tmp, &cmd_list->ctrl_cmd_head.list, list) {
		if (tmp->seq_id == info_st->ret_st.seq_id) {
			entry = tmp;
			break;
		}
		cmd_list_len++;
	}
	spin_unlock_irqrestore(&cmd_list->ctrl_cmd_list_lock, irq_flag);

	if (entry) {
		memcpy(&entry->completion_info, msg, sizeof(*msg));
		complete(&entry->msg_comp);
	}

	if (cmd_list_len > 10) {
		VASTAI_PCI_DBG(
			pci_info, die_id,
			"%s: check performance! dies->cmd_list is too long[%d].\n",
			__func__, cmd_list_len);
	}
}

bool is_AI_sys_core(int core)
{
	int i;
	for(i=0; i<sizeof(ai_group)/sizeof(ai_group[0]); i++)
	{
		if(ai_group[i] == core)
			return true;
	}

	return false;
}

static void vastai_heartbeat_work(struct work_struct *work)
{
	struct heartbeat_monitor *heartbeat = NULL;
	struct vastai_pci_info *priv = NULL;
	u32 cur_count[SV_HEARTBEAT_CNT_REG_NUM] = { 0 };
	u32 *last_count = NULL;
	u32 tmp_count = 0;
	int ret = 0, die_index = 0, die_id = 0, core_id = 0;

	priv = container_of(work, struct vastai_pci_info,
			    heartbeat.heartbeat_work.work);
	heartbeat = &priv->heartbeat;

	for (die_id = 0; die_id < priv->die_num_in_fn; die_id++) {
		u32 head = heartbeat->dies[die_id].head;
		die_index = priv->dies[die_id].die_index;
		last_count = heartbeat->dies[die_id].last_counts[head];

		ret = vastai_pci_mem_read(priv, die_index, HEART_BEAT_CNT,
					  cur_count, sizeof(cur_count));

		if (ret && (VASTAI_NORMAL_STATE == vastai_get_pci_state(priv))) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s: read heartbeat reg error, %d\n",
				       __func__, ret);
			//TODO: this moment peci error, how to reset dev
			break;
		}

		for (core_id = 0; core_id < ADDR(priv, HEARTBEAT_CNT_REG_NUM); core_id++) {
			if (priv->dies[die_id].heartbeat_mask & BIT_MASK(core_id)) {
				continue;
			}

			VASTAI_PCI_DBG(
				priv, die_id,
				"%s: core[%d] heartbeat cnt, last=%u cur=%u\n",
				__func__, core_id, last_count[core_id],
				cur_count[core_id]);

			if (cur_count[core_id] != last_count[core_id]) {
				continue;
			}

			/* heartbeat counter don't change, read again */
			ret = vastai_pci_mem_read(priv, die_index,
						  HEART_BEAT_CNT +
							  core_id * sizeof(u32),
						  &tmp_count, sizeof(u32));
			if (ret && (VASTAI_NORMAL_STATE == vastai_get_pci_state(priv))) {
				VASTAI_PCI_ERR(
					priv, die_id,
					"%s: read heartbeat reg error, %d\n",
					__func__, ret);
				//TODO: this moment peci error, how to reset dev
				break;
			}
			if (tmp_count != last_count[core_id]) {
				continue;
			}

			VASTAI_PCI_DBG(priv, die_id,
					"%s: core[%d] heartbeat stopped!!!!!\n",
					__func__, core_id);
			continue; //do not reset

			/* core is hanged, set status of die and core */
			set_bit(die_id, &heartbeat->dies_status);
			set_bit(core_id, &heartbeat->dies[die_id].cores_status);
		}

		heartbeat->dies[die_id].head++;
		if(heartbeat->dies[die_id].head >= HEARTBEAT_MAX_CNT)
			heartbeat->dies[die_id].head = 0;
		if(heartbeat->dies[die_id].head == heartbeat->dies[die_id].tail)
			heartbeat->dies[die_id].tail++;
		if(heartbeat->dies[die_id].tail >= HEARTBEAT_MAX_CNT)
			heartbeat->dies[die_id].tail = 0;
		memcpy(heartbeat->dies[die_id].last_counts[heartbeat->dies[die_id].head], cur_count,
		       sizeof(heartbeat->dies[die_id].last_counts[0]));
	}

	if (!(heartbeat->dies_status))
		goto next;

	/* TODO: dump */

	/**
	 * reset all dies, if one or all of dies hang
	 * TODO: multi dies case
	 */
	if (heartbeat->dies[0].cores_status & BIT_MASK(HEARTBEAT_SMCU)) {
		/* smcu hang: fw will tigger wdg, host wait romcode */
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s: smcu hang(dev_wdg_reset and reboot)\n",
				__func__);
		ret = vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: smcu hang, reset error, %d\n",
				       __func__, ret);
			goto stop;
		}
	} else {
		/**
		 * smcu no hang: host send msg irq to triger fw wdg
		 * and wait romcode
		 */
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s: other cores hang(msg_reset and reboot)\n",
				__func__);
		ret = vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER |
							VASTAI_RESET_BOOT_DEV);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: smcu not hang, reset error, %d\n",
				       __func__, ret);
			goto stop;
		}
	}

	heartbeat->dies_status = 0;
	for (die_id = 0; die_id < priv->die_num_in_fn; die_id++) {
		heartbeat->dies[die_id].cores_status = 0;
		memset(heartbeat->dies[die_id].last_counts, 0,
		       sizeof(heartbeat->dies[die_id].last_counts));
	}

	// vastai_pci_resource_recycling(work);
next:
	schedule_delayed_work(&heartbeat->heartbeat_work,
			      heartbeat->timeout_threshold);
	return;

stop:
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
		       "heartbeat_work stop, dies_status=%lx\n",
		       heartbeat->dies_status);
	for (die_id = 0; die_id < priv->die_num_in_fn; die_id++) {
		VASTAI_PCI_ERR(priv, die_id, "cores_heartbeat_status=%lx\n",
			       heartbeat->dies[die_id].cores_status);
	}
}

int vastai_read_heartbeat(struct vastai_pci_info *priv, u32 die_id,
					u32 last_sec, u32 *hb_count)
{
	int ret = 0;
	int cnt = (last_sec/3 > HEARTBEAT_MAX_CNT) ? HEARTBEAT_MAX_CNT : last_sec/3;
	int head = priv->heartbeat.dies[die_id].head;
	int tail = priv->heartbeat.dies[die_id].tail;

	if(!hb_count) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"hb_count is NULL\n");
		return -EINVAL;
	}
	if(0 == cnt) {
		ret = vastai_pci_mem_read(priv, priv->dies[die_id].die_index, HEART_BEAT_CNT,
					  hb_count, sizeof(u32)*ADDR(priv, HEARTBEAT_CNT_REG_NUM));
		return ret;
	}

	while(cnt && (head!=tail)) {
		cnt--;
		head--;
		if(head<0)
			head = HEARTBEAT_MAX_CNT-1;
	}

	memcpy(hb_count, priv->heartbeat.dies[die_id].last_counts[head],
		ADDR(priv, HEARTBEAT_CNT_REG_NUM)*sizeof(u32));

	return ret;
}

#if 0
static int vastai_dev_reset_irq_handler(void *pci_dev, u32 die_index, int irq,
					void *ctxt, void *out)
{
	struct vastai_pci_info *priv = pci_dev;
	u32 die_irq = irq % VASTAI_PCIE_MSIX_NUM_PER_DIE;
	u32 die_id = irq / VASTAI_PCIE_MSIX_NUM_PER_DIE;

	if (die_irq == SMCU_2_HOST_INT0) {
		/* dma done: wait romcode done */
		VASTAI_PCI_ERR(priv, die_id,
			       "%s: TODO irq[%d]\n", __func__, die_irq);
	} else if (die_irq == SMCU_2_HOST_INT1) {
		/* dma no done: pcie hot reset */
		VASTAI_PCI_ERR(priv, die_id,
			       "%s: TODO irq[%d]\n", __func__, die_irq);
	} else {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s: irq[%d] is invalid\n", __func__, die_irq);
	}

	return 0;
}
#endif

#define BOOT_PF_ID 0  // 1/3/2

static bool is_enable_heartbeat_monitor(struct vastai_pci_info *priv)
{
#if VASTAI_HEARTBEAT_ENABLE
	if (priv->is_physfn && (SV100 == vastai_get_board_type(priv))) {
		return true;
	}

	if ((SG100 == vastai_get_board_type(priv)) &&
		BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.pfn &&
		priv->is_pf &&
		(priv->priv_hw_cfg->sys_cfg.pkg_id == 0)) {
		return true;
	}
#endif
	return false;
}

static void vastai_heartbeat_monitor_init(struct vastai_pci_info *priv)
{
	struct heartbeat_monitor *heartbeat = &priv->heartbeat;

	if (!is_enable_heartbeat_monitor(priv)) {
		return;
	}

	heartbeat->timeout_threshold = msecs_to_jiffies(3000); /* 3s */

	INIT_DELAYED_WORK(&heartbeat->heartbeat_work, vastai_heartbeat_work);
	schedule_delayed_work(&heartbeat->heartbeat_work,
				heartbeat->timeout_threshold);

	return;
}

static void vastai_heartbeart_monitor_deinit(struct vastai_pci_info *priv)
{
	int dev_reset_irqs[] = { SMCU_2_HOST_INT0, SMCU_2_HOST_INT1 };
	int ret = 0, i = 0, index = 0;

	cancel_delayed_work_sync(&priv->heartbeat.heartbeat_work);

	for (i = 0; i < priv->die_num_in_fn; i++) {
		for (index = 0; index < ARRAY_SIZE(dev_reset_irqs); index++) {
			ret = vastai_irq_unregister(priv,
						    priv->dies[i].die_index,
						    dev_reset_irqs[index]);
			if (ret)
				VASTAI_PCI_ERR(priv, i,
					       "%s: irq[%d] unregister error\n",
					       __func__, dev_reset_irqs[index]);
		}
	}
}

int vastai_bbox_init(struct vastai_pci_info *priv)
{

	spin_lock_init(&(priv->bbox_info.bbox_lock));
	memset(&(priv->bbox_info.val), 0, sizeof(priv->bbox_info.val));

	return 0;
}


int vastai_bbox_set(struct vastai_pci_info *priv, u32 bbox)
{
	unsigned long flags;
	int ret = 0;
	int die_id;

	spin_lock_irqsave(&priv->bbox_info.bbox_lock, flags);
	priv->bbox_info.val = bbox;
	for (die_id = 0; die_id < priv->die_num_in_fn; die_id++) {
		ret |= vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
					     VASTAI_PCIE_SUB_SET_BBOX, (u64)bbox);
	}
	spin_unlock_irqrestore(&priv->bbox_info.bbox_lock, flags);

	return ret;
}

u32 vastai_bbox_get(struct vastai_pci_info *priv)
{
	return priv->bbox_info.val;
}

static char *filter_card_type[] = {"VA1A-32G", "VA1V-32G", "VA1-32G"};
static bool card_type_ddr_check(struct vastai_pci_info *priv)
{
	int i;
	int num =  sizeof(filter_card_type) / sizeof(filter_card_type[0]);
	void *buf = vzalloc(128);
	char card_type[TYPE_LEN];

#ifndef CONFIG_VASTAI_AI_EMU
	memset(card_type, '\0', TYPE_LEN);
	vatools_get_spi_buf(priv->dies[0].die_index, 4, 0, product_len, buf);
	if (((char*)buf)[0] == 'V' && ((char*)buf)[1] == '2')
		memcpy(card_type, ((char*)buf + card_type_offset), TYPE_LEN -1);
	else
		return false;

	for (i = 0; i < num; i++)
		if (!strcmp(card_type, filter_card_type[i]))
			return true;
#endif
	vfree(buf);
	return false;
}
static void vastai_pci_get_ddr_attr(struct vastai_pci_info *priv)
{
	unsigned int die_index = priv->dies[0].die_index;
	u64 reg_addr = VASTAI_MCU_DSP_STATUS_REG;
	union mcu_dsp_status reg = { 0 };
	u32 density_single;

	vastai_pci_mem_read(priv, die_index, reg_addr, &(reg.val), 4);
#ifdef CONFIG_VASTAI_AI_EMU
	/* fictitious ddr on emulation */
	priv->ddr_attr = 0x200000000;
#else
#if 0
	if (reg.bit.ddr_attr == 0) {
		/* ddr dram density: 2GB, mc_num: 2, total density: 4GB */
		priv->ddr_attr = 0x100000000;
	} else if (reg.bit.ddr_attr == 1) {
		/* ddr dram density: 2GB, mc_num: 4, total density: 8GB */
		priv->ddr_attr = 0x200000000;
	} else if (reg.bit.ddr_attr == 2) {
		/* ddr dram density: 4GB, mc_num: 2, total density: 8GB */
		priv->ddr_attr = 0x200000000;
	} else if (reg.bit.ddr_attr == 3) {
		/* ddr dram density: 4GB, mc_num: 4, total density: 16GB */
		priv->ddr_attr = 0x400000000;
	} else {
		/* ddr dram density: 2GB, mc_num: 2, total density: 4GB */
		priv->ddr_attr = 0x100000000;
	}
#else
	density_single = reg.bit.ddr_attr&0x6;
       if(0 == density_single) {
                /* ddr dram density: 2GB */
               priv->ddr_attr = 0x100000000;

       } else if(2 == density_single) {
                /* ddr dram density: 4GB */
                priv->ddr_attr = 0x200000000;
       } else if(4 == density_single) {
        /* ddr dram density: 8GB */
                priv->ddr_attr = 0x400000000;
       } else {
               /* reserved for future */
                priv->ddr_attr = 0x100000000;
                 VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s - Unknow DDR density val=0x%x\n",
                        __func__,
                        reg.bit.ddr_attr);
       }

       if (reg.bit.ddr_attr&0x1){
                priv->ddr_attr =  priv->ddr_attr <<1; /* mc_num ==4 */
       }
	if ((reg.val&0x1) == 0){
               priv->ddr_attr = priv->ddr_attr - (priv->ddr_attr>>3); //ECC is enable,valid density is 7/8*Total
               VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "[warn] DDR inline ECC is enable, valid density is 7/8 nominal density.\n");
       }

#endif
#endif

	priv->ddr_min_addr = ADDR(priv, DDR_BASE_ADDR);
	priv->ddr_max_addr = ADDR(priv, DDR_BASE_ADDR) + priv->ddr_attr;
	/* 1 MB is reserved for buffering because the video ENC may have DDR access overbounds. */

	if (card_type_ddr_check(priv))
		priv->ddr_attr = SIZE_16G > priv->ddr_attr ?
			priv->ddr_attr: SIZE_16G;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s=0x%llx (%lldGB), val=0x%x\n",
			__func__, priv->ddr_attr,
			(priv->ddr_attr / 1024 / 1024 / 1024),
			reg.bit.ddr_attr);
}

void vastai_pci_init_all_die(struct vastai_pci_info *priv)
{
	int i = 0;

	for (i = 0; i < priv->die_num_in_fn; i++) {
		struct vastai_sv100_die *die = &(priv->dies[i]);

		vastai_die_init(die, priv, i);
	}
}

union core_bitmap core_point_to_core_bitmap(u8 core_point_num)
{
	union core_bitmap _core_bitmap;

	_core_bitmap.val = 0;
	if(core_point_num == CORE_POINT_CMCU)
		_core_bitmap.cmcu = 1;
	else if ((core_point_num >= CORE_POINT_VDSP0) && (core_point_num <= CORE_POINT_VDSP3))
		_core_bitmap.vdsp = 1<<(core_point_num-CORE_POINT_VDSP0);
	else if ((core_point_num >= CORE_POINT_VEMCU0) && (core_point_num <= CORE_POINT_VEMCU3))
		_core_bitmap.encode = 1<<(core_point_num-CORE_POINT_VEMCU0);
	else if ((core_point_num >= CORE_POINT_VDMCU0) && (core_point_num <= CORE_POINT_VDMCU2))
		_core_bitmap.decode = 1<<(core_point_num-CORE_POINT_VDMCU0);

	return _core_bitmap;
}

void vastai_clear_fifo(void *pci_info, int die_index, int core_idx)
{
	struct vastai_fifo fifo;
	struct vastai_pci_info *priv = pci_info;
	struct vastai_sv100_die *die = &(priv->dies[vastai_pci_get_die_id(priv, die_index)]);

	u64 msg_addr;
	int i = 0;

	u32 is_use_ring_buf = die->core[core_idx].cores_info_ref->is_use_ring_buf;

	while (is_use_ring_buf && ((msg_addr = die->core[core_idx].cores_info_ref->push_fifo_addr[i]) != -1)) {
		spin_lock(&(die->core[core_idx].wr_ring_buf_lock));
		if (die->core[core_idx].pop_cache[i])
			memset(die->core[core_idx].pop_cache[i], 0, sizeof(struct vastai_fifo));
		if (die->core[core_idx].push_cache[i])
			memset(die->core[core_idx].push_cache[i], 0, sizeof(struct vastai_fifo));
		vastai_pci_mem_read(pci_info, die_index, msg_addr, &fifo, sizeof(struct vastai_fifo));
		fifo.wr = fifo.rd = 0;
		vastai_pci_mem_write(pci_info, die_index, msg_addr + offsetof(struct vastai_fifo, rd),
				     &(fifo.rd), 2*sizeof(fifo.wr));

		spin_unlock(&(die->core[core_idx].wr_ring_buf_lock));
		if (++i == 2)
			return;
	}

	return;
}


void event_notify_proc(u32 die_index, u32 core_bit, u32 event)
{
#ifdef CONFIG_VASTAI_TOOLS_SUITE
	vatools_device_event_callback(die_index, core_bit, event);
#endif
	if (g_reset_ai_handle) {
		g_reset_ai_handle(die_index, core_bit, event);
	}

	if (g_reset_video_handle) {
		g_reset_video_handle(die_index, core_bit, event);
	}
}

struct exception_msg {
	struct list_head node;
	u32 core_bit;
	u32 event_type;
};

void event_notify(struct vastai_pci_info *priv,
		u32 die_index, u32 core_bit, u32 event)
{
	u32 die_id = vastai_pci_get_die_id(priv, die_index);

	priv->dies[die_id].core_bit = core_bit;
	priv->dies[die_id].event_type = event;

	schedule_work(&priv->dies[die_id].exception_work_new);

	return;
}
#define DIV_ROUND(x, len)	   (((x) + (len)-1) / (len))
#define ROUND_UP(x, align)	   DIV_ROUND(x, align) * (align)
#define GET_CORE_LOG_ADDR(core_point) (CORE_LOG_BASE_ADDR + (core_point - CORE_POINT_SMCU) * CORE_LOG_SIZE)
struct core_log_ctrl_buf {
	u8 core[CORE_TOTAL_NUM];
};

static const char* vastai_exception_get_core_name(u32 core_point)
{
	if (core_point == CORE_POINT_SMCU) {
		return "smcu";
	} else if (core_point == CORE_POINT_CMCU) {
		return "cmcu";
	} else if (core_point >= CORE_POINT_LMCU0 && core_point <= CORE_POINT_LMCU7) {
		return "lmcu";
	} else if (core_point >= CORE_POINT_ODSP0 && core_point <= CORE_POINT_ODSP7) {
		return "odsp";
	} else if (core_point >= CORE_POINT_VDMCU0 && core_point <= CORE_POINT_VDMCU2) {
		return "vdmcu";
	} else if (core_point >= CORE_POINT_VEMCU0 && core_point <= CORE_POINT_VEMCU3) {
		return "vemcu";
	} else if (core_point >= CORE_POINT_VDSP0 && core_point <= CORE_POINT_VDSP3) {
		return "vdsp";
	} else {
		return "failed";
	}
}

// print core log
u8 vastai_print_core_log(struct vastai_pci_info *priv, u8 die_id, u8 *log_buffer, u8 core_point)
{
	enum
	{
		LOGSYS_LEVEL_ERR = 0,
		LOGSYS_LEVEL_WARN,
		LOGSYS_LEVEL_INFO,
		LOGSYS_LEVEL_DEBUG,
		LOGSYS_LEVEL_MAX,
	};
	u8  logLvL[LOGSYS_LEVEL_MAX][16] = {" err  ", " warn ", " info ", " debug "};
	u8  logsn = 0;
	u32 *timeStamp = 0;
	u32 len = 0;
	u32 wp = 0;
	u32 rp = 0;
	u64 wp_addr = 0x8cf30a0 + 16*(core_point) + 8;
	u64 rp_addr = 0x8cf30a0 + 16*(core_point) + 8 + 4;
	u32 log_info_addr = 0x8cf30a0 + 16*CORE_TOTAL_NUM ;
	struct core_log_ctrl_buf log_ctrl;
	u32 max_loop;
	u32 line_min_size = 12;
	u32 size_mask;
	u8 new_core_point = core_point;
	u8 log_end;

	vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id),
		log_info_addr, &log_ctrl, sizeof(struct core_log_ctrl_buf));
	if (log_ctrl.core[core_point] & BIT(1))
		size_mask = 0x7FFFF;
	else
		size_mask = 0xFFFFF;
	max_loop = size_mask / line_min_size;

	vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), wp_addr, &wp, 4);
	vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), rp_addr, &rp, 4);
	if (priv->dies[die_id].core[core_point].log_last_rp != rp)
		priv->dies[die_id].core[core_point].log_last_rp = rp;
	else
		rp = priv->dies[die_id].core[core_point].log_cache_rp;

	// if core is cmcu, need to analyze logs.
	if (core_point == CORE_POINT_CMCU) {
		// save old val
		u32 rp_tmp = rp;
		u32 max_loop_tmp = max_loop;
		while ((rp&size_mask)!=(wp&size_mask)) {
			int loglevel_id = (*(log_buffer + (rp&size_mask) + 2)) & 0xf;
			u32 len_hi = ((u32)*(log_buffer + (rp&size_mask) + 3)) & 0xff;
			u32 str_len = 0;
			u32 str_limit = 512;
			len = ((*(log_buffer + (rp&size_mask) + 2)) >> 6) + (len_hi<<2) - 1;
			if(len + (rp%4096) > 4096 ) {
				rp = (rp/4096 + 1)*4096;
			}

			len_hi = ((u32)*(log_buffer + (rp&size_mask) + 3)) & 0xff;
			len = ((*(log_buffer + (rp&size_mask) + 2)) >> 6) + (len_hi<<2) - 1;
			loglevel_id = (*(log_buffer + (rp&size_mask) + 2)) & 0xf;
			logsn = (*(log_buffer + (rp&size_mask) + 1));
			timeStamp = (u32*)(log_buffer + (rp&size_mask)) + 1;

			// until find out next log_head
			str_len = len;
			while (*(log_buffer + (rp&size_mask) + 8 + str_len) != '#') {
				str_len++;
				// if can't find '#'
				str_limit--;
				if (str_limit == 0)
					break;
			}

			// '#' or 512 bytes
			log_end = *(log_buffer + (rp&size_mask) + 8 + str_len);
			*(log_buffer + (rp&size_mask) + 8 + str_len) = '\0';

			// if lmcu/odsp exception
			if (strstr((log_buffer + (rp&size_mask) + 8), "trigger exception")) {
				char *core_str = NULL;
				core_str = strstr((log_buffer + (rp&size_mask) + 8), "odsp");
				if (core_str != NULL) {
					new_core_point = *(core_str + 5) - '0' + CORE_POINT_ODSP0;
					if (new_core_point >= CORE_POINT_ODSP0 && new_core_point <= CORE_POINT_ODSP7) {
						*(log_buffer + (rp&size_mask) + 8 + len) = log_end;
						break;
					} else {
						new_core_point = CORE_POINT_CMCU;
					}
				}

				core_str = strstr((log_buffer + (rp&size_mask) + 8), "lmcu");
				if (core_str != NULL) {
					new_core_point = *(core_str + 5) - '0' + CORE_POINT_LMCU0;
					if (new_core_point >= CORE_POINT_LMCU0 && new_core_point <= CORE_POINT_LMCU7) {
						*(log_buffer + (rp&size_mask) + 8 + len) = log_end;
						break;
					} else {
						new_core_point = CORE_POINT_CMCU;
					}
				}
			}
			*(log_buffer + (rp&size_mask) + 8 + str_len) = log_end;

			rp = rp + 8 + ROUND_UP(len+1, 4);
			if (max_loop-- == 0 )
				break;
		}
		len = 0;
		logsn = 0;
		timeStamp = 0;
		rp = rp_tmp;
		max_loop = max_loop_tmp;
	}

	// print logs.
	while ((rp&size_mask)!=(wp&size_mask)) {
		int loglevel_id = (*(log_buffer + (rp&size_mask) + 2)) & 0xf;
		u32 len_hi = ((u32)*(log_buffer + (rp&size_mask) + 3)) & 0xff;
		u32 str_len = 0;
		u32 str_limit = 512;
		len = ((*(log_buffer + (rp&size_mask) + 2)) >> 6) + (len_hi<<2) - 1;
		if(len + (rp%4096) > 4096 ) {
			rp = (rp/4096 + 1)*4096;
		}

		len_hi = ((u32)*(log_buffer + (rp&size_mask) + 3)) & 0xff;
		len = ((*(log_buffer + (rp&size_mask) + 2)) >> 6) + (len_hi<<2) - 1;
		loglevel_id = (*(log_buffer + (rp&size_mask) + 2)) & 0xf;
		logsn = (*(log_buffer + (rp&size_mask) + 1));
		timeStamp = (u32*)(log_buffer + (rp&size_mask)) + 1;

		// until find out next log_head
		str_len = len;
		while (*(log_buffer + (rp&size_mask) + 8 + str_len) != '#') {
			str_len++;
			// if can't find '#'
			str_limit--;
			if (str_limit == 0)
				break;
		}

		// '#'
		log_end = *(log_buffer + (rp&size_mask) + 8 + str_len);
		*(log_buffer + (rp&size_mask) + 8 + str_len) = '\0';
		printk("[%03u][%s] 0x%08x:%s\n", logsn, logLvL[loglevel_id], *timeStamp,
				log_buffer + (rp&size_mask) + 8);
		*(log_buffer + (rp&size_mask) + 8 + str_len) = log_end;

		rp = rp + 8 + ROUND_UP(len+1, 4);
		if (max_loop-- == 0 )
			break;
	}
	priv->dies[die_id].core[core_point].log_cache_rp = rp;

	return new_core_point;
}

int vastai_get_core_log(struct vastai_pci_info *priv, u32 die_id, u8 core_point, loff_t dev_addr)
{
	struct vastai_dmadesc desc;
	union core_bitmap core_id = {.val = 0}; /* no core need be tirgger */
	void *vir_addr_malloc = 0;
	void *vir_addr_4K = 0;
	size_t size = 1024*1024;
	int ret = 0;
	u8 new_core_point = core_point;

	vir_addr_malloc = vmalloc(size);
	if(!vir_addr_malloc) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s: failed to vmalloc\n",
			       __func__);
		return -ENOMEM;
	}

	if(die_id >= VASTAI_SV100_MAX_DIE_NUM) {
		printk("out of range die_id[%d]\n", die_id);
		return -1;
	}

	vir_addr_4K = (void*)PAGE_ALIGN((u64)vir_addr_malloc);

	desc.is_src_dma_addr		= 0;
	desc.is_host_to_dev		= 0;	// read
	desc.is_src_not_user_mem	= 1;
	desc.host_addr.dma_addr 	= 0;
	desc.host_addr.vir_addr 	= vir_addr_4K;
	desc.dev_addr			= dev_addr;
	desc.dma_lenth			= size;

	VASTAI_PCI_DBG(priv, die_id, "read use dma!\n");
	ret = vastai_pci_dma_transfer_sync_pid(priv, vastai_pci_get_die_index(priv, die_id), core_id, &desc, 1, -1);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "%s: dma transfer fail, ret = %d\n", __func__, ret);
	}

	new_core_point = vastai_print_core_log(priv, die_id, vir_addr_4K, core_point);
	vfree(vir_addr_malloc);

	if (new_core_point != core_point)
		ret = new_core_point;

	return ret;
}

// print cmcu lmcu odsp vdsp
u8 vastai_get_ai_logs(struct vastai_pci_info *priv, u32 die_id)
{
	loff_t dev_addr;
	u8 core_point;

	// print cmcu logs
	core_point = CORE_POINT_CMCU;
	dev_addr = GET_CORE_LOG_ADDR(core_point);
	VASTAI_PCI_INFO(priv, die_id, "=========================== CMCU LOGS ===========================\n\n");
	core_point = vastai_get_core_log(priv, die_id, core_point, dev_addr);

	if (core_point != CORE_POINT_CMCU) {
		if (core_point >= CORE_POINT_LMCU0 && core_point <= CORE_POINT_LMCU7) {
			VASTAI_PCI_INFO(priv, die_id, "=========================== LMCU%d LOGS ===========================\n\n", core_point - CORE_POINT_LMCU0);
			dev_addr = GET_CORE_LOG_ADDR(core_point);
			vastai_get_core_log(priv, die_id, core_point, dev_addr);
		}
		if (core_point >= CORE_POINT_ODSP0 && core_point <= CORE_POINT_ODSP7) {
	 		VASTAI_PCI_INFO(priv, die_id, "=========================== ODSP%d LOGS ===========================\n\n", core_point - CORE_POINT_ODSP0);
			dev_addr = GET_CORE_LOG_ADDR(core_point);
			vastai_get_core_log(priv, die_id, core_point, dev_addr);
		}
	}
	return core_point;
}

static ktime_t first_cmcu_exception_time = 0;

void exception_proc_work(struct work_struct *work)
{
	struct vastai_core *core =
		container_of(work, struct vastai_core , exception_work);
	struct vastai_sv100_die *dies = core->die;
	struct vastai_pci_info *priv = dies->pci_info;
	u32 die_id = vastai_pci_get_die_id(priv, dies->die_index);
	struct vastai_card_info* card_info;

	if(core->is_exception) {
		mutex_lock(&vastai_print_fw_logs_lock);
		event_notify_proc(dies->die_index, core->core_bit, RESET_START);

		// skip cmcu timeout logs
		if (first_cmcu_exception_time != 0) {
			ktime_t current_time = 0;
			current_time = ktime_get();

			if ((current_time - first_cmcu_exception_time) / 1000000000 > exception_log_interval) {
				first_cmcu_exception_time = 0;
			} else {
				mutex_unlock(&vastai_print_fw_logs_lock);
				goto out;
			}
		}

		VASTAI_PCI_INFO(priv, die_id, "receive core exception index:%s\n", core->cores_info_ref->core_name);

		if(exception_log_en) {
			u8 core_point;
			loff_t dev_addr;
			struct vastai_die_info *die_info = vastai_get_die_info(dies->pci_info, die_id);

			VASTAI_PCI_INFO(priv, die_id, "=========================== print fwlogs start ===========================\n");
			// print smcu logs
			VASTAI_PCI_INFO(priv, die_id, "=========================== SMCU LOGS ===========================\n\n");

			// get smcu logs
			core_point = CORE_POINT_SMCU;
			dev_addr = GET_CORE_LOG_ADDR(core_point);
			vastai_get_core_log(priv, die_id, core_point, dev_addr);

			if (core->core_bit == CORE_POINT_CMCU) {
				if (first_cmcu_exception_time == 0) {
					first_cmcu_exception_time = ktime_get();
				}
				// cmcu/lmcu/odsp exception -> cmcu+lmcu+odsp+vdsp logs
				core_point = vastai_get_ai_logs(priv, die_id);
			} else if (core->core_bit >= CORE_POINT_VDSP0 && core->core_bit <= CORE_POINT_VDSP3) {
				// vdsp exception
				core_point = CORE_POINT_VDSP0;
				dev_addr = GET_CORE_LOG_ADDR(core_point);
				for (; core_point <= CORE_POINT_VDSP3; core_point++) {
					VASTAI_PCI_INFO(priv, die_id, "=========================== VDSP%d LOGS ===========================\n\n",
							core_point - CORE_POINT_VDSP0);
					vastai_get_core_log(priv, die_id, core_point, dev_addr);
					dev_addr += CORE_LOG_SIZE;
				}
			} else if (core->core_bit >= CORE_POINT_VDMCU0 && core->core_bit <= CORE_POINT_VDMCU2) {
				// vdmcu exception
				core_point = CORE_POINT_VDMCU0;
				dev_addr = GET_CORE_LOG_ADDR(core_point);
				for (; core_point <= CORE_POINT_VDMCU2; core_point++) {
					VASTAI_PCI_INFO(priv, die_id, "=========================== VDMCU%d LOGS ===========================\n\n",
							core_point - CORE_POINT_VDMCU0);
					vastai_get_core_log(priv, die_id, core_point, dev_addr);
					dev_addr += CORE_LOG_SIZE;
				}
			} else if (core->core_bit >= CORE_POINT_VEMCU0 && core->core_bit <= CORE_POINT_VEMCU3) {
				// vemcu exception
				core_point = CORE_POINT_VEMCU0;
				dev_addr = GET_CORE_LOG_ADDR(core_point);
				for (; core_point <= CORE_POINT_VEMCU3; core_point++) {
					VASTAI_PCI_INFO(priv, die_id, "=========================== VEMCU%d LOGS ===========================\n\n",
							core_point - CORE_POINT_VEMCU0);
					vastai_get_core_log(priv, die_id, core_point, dev_addr);
					dev_addr += CORE_LOG_SIZE;
				}
			} else {
				VASTAI_PCI_ERR(priv, die_id, "failed : core_id is %d\n", core->core_bit);
			}

			card_info = vastai_get_card_info(priv);

			// print exception info
			if (core->core_bit == CORE_POINT_CMCU) {
				if (core_point >= CORE_POINT_LMCU0 && core_point <= CORE_POINT_LMCU7) {
					VASTAI_PCI_INFO(priv, die_id, "========== exception: card_id[%d]die_id_in_card[%u]err_core[%s-%s%d] ==========\n",
						card_info->card_id, die_info->die_id_in_card, vastai_exception_get_core_name(core->core_bit),
						vastai_exception_get_core_name(core_point), core_point - CORE_POINT_LMCU0);
				}else if (core_point >= CORE_POINT_ODSP0 && core_point <= CORE_POINT_ODSP7) {
					VASTAI_PCI_INFO(priv, die_id, "========== exception: card_id[%d]die_id_in_card[%u]err_core[%s-%s%d] ==========\n",
						card_info->card_id, die_info->die_id_in_card, vastai_exception_get_core_name(core->core_bit),
						vastai_exception_get_core_name(core_point), core_point - CORE_POINT_ODSP0);
				} else {
					VASTAI_PCI_INFO(priv, die_id, "========== exception: card_id[%d]die_id_in_card[%u]err_core[%s] ==========\n",
						card_info->card_id, die_info->die_id_in_card, vastai_exception_get_core_name(core->core_bit));
				}
			} else {
				VASTAI_PCI_INFO(priv, die_id, "========== exception: card_id[%d]die_id_in_card[%u]err_core[%s] ==========\n",
					card_info->card_id, die_info->die_id_in_card, vastai_exception_get_core_name(core->core_bit));
			}

			VASTAI_PCI_INFO(priv, die_id, "=========================== print fwlogs end ===========================\n");
		}

		mutex_unlock(&vastai_print_fw_logs_lock);

out:
		if (core_exception_en) {
			vastai_clear_fifo(priv, dies->die_index, core->core_bit);
			vastai_send_pcie_cmd(priv, dies->die_index,
					VASTAI_PCIE_SUB_CORE_RESET, core->core_bit);
		}
		core->is_exception = false;
	}

}

void exception_proc_work_new(struct work_struct *work)
{
	struct vastai_sv100_die *dies =
		container_of(work, struct vastai_sv100_die , exception_work_new);

	event_notify_proc(dies->die_index, dies->core_bit, dies->event_type);
}

void exception_proc_work_new_per_core(struct work_struct *work)
{
	struct vastai_core *core =
		container_of(work, struct vastai_core , exception_work_new);

	event_notify_proc(core->die->die_index, core->core_bit, core->event_type);

	return;
}

void vastai_exception_init(struct vastai_pci_info *priv)
{
	int i;

	for (i = 0; i < priv->die_num_in_fn; i++) {
		priv->dies[i].heartbeat_mask = 0xC0000000;
		if(priv->vadev.dev_cap == VASTAI_HW_TYPE_VIDEO_ONLY) {
			int ai_loop;
			for(ai_loop = 0; ai_loop < sizeof(ai_group)/sizeof(ai_group[0]); ai_loop++)
				priv->dies[i].heartbeat_mask |= (1<<ai_group[ai_loop]);
		}
		if(priv->vadev.dev_cap == VASTAI_HW_TYPE_DEFAULT ||
			priv->vadev.dev_cap == VASTAI_HW_TYPE_AI_ONLY) {
			int video_loop;
			for(video_loop = HEARTBEAT_VDMCU0; video_loop <= HEARTBEAT_VEMCU3; video_loop++)
				priv->dies[i].heartbeat_mask |= (1<<video_loop);
		}

		INIT_WORK(&priv->dies[i].exception_work_new, exception_proc_work_new);
	}
}

void vastai_clear_exception_status(struct vastai_pci_info *priv)
{
	int i;

	for (i = 0; i < priv->die_num_in_fn; i++) {
		priv->dies[i].heartbeat_mask = 0xC0000000;
		if(priv->vadev.dev_cap == VASTAI_HW_TYPE_VIDEO_ONLY) {
			int ai_loop;
			for(ai_loop = 0; ai_loop < sizeof(ai_group)/sizeof(ai_group[0]); ai_loop++)
				priv->dies[i].heartbeat_mask |= (1<<ai_group[ai_loop]);
		}
		if(priv->vadev.dev_cap == VASTAI_HW_TYPE_DEFAULT ||
			priv->vadev.dev_cap == VASTAI_HW_TYPE_AI_ONLY) {
			int video_loop;
			for(video_loop = HEARTBEAT_VDMCU0; video_loop <= HEARTBEAT_VEMCU3; video_loop++)
				priv->dies[i].heartbeat_mask |= (1<<video_loop);
		}
	}
}

int vastai_wait_ecc_2_bit(struct vastai_pci_info *pdev,
			  union die_index_data die_index)
{
	struct vastai_sv100_die *die;
	int ret;

	if (!pdev || (pdev->die_num_in_fn <= die_index.die_id)) {
		return -EINVAL;
	}

	die = &(pdev->dies[die_index.die_id]);

	ret = wait_for_completion_interruptible(&(die->ecc_2bit_err));
	reinit_completion(&(die->ecc_2bit_err));

	return ret;
}

int vastai_get_render_id(struct vastai_pci_info *pdev, u32 die_index)
{
	union die_index_data die_index_u = { .val = die_index };

	u32 die_id = die_index_u.die_id;

	return pdev->dies[die_id].render_id;
}

int vastai_get_card_id(struct vastai_pci_info *pdev, u32 die_index)
{
	union die_index_data die_index_u = { .val = die_index };

	u32 die_id = die_index_u.die_id;

	return pdev->dies[die_id].card_id;
}

int vastai_get_vacc_id(struct vastai_pci_info *pdev, u32 die_index)
{
	union die_index_data die_index_u = { .val = die_index };

	return die_index_u.seq_num;
}

int vastai_get_seq_num(struct vastai_pci_info *pdev, u32 die_id)
{
	union die_index_data die_index_u;

	die_index_u.val = pdev->dies[die_id].die_index;

	return die_index_u.seq_num;
}

u64 vastai_get_pci_bdf_info(struct vastai_pci_info *pdev)
{
	struct pci_dev *dev;
	vastai_pci_bdf_info_t bdf_info;

	dev = pdev->dev;
	bdf_info.whole = 0;
	bdf_info.domain_id = pci_domain_nr(dev->bus);
	bdf_info.bus_id = dev->bus->number;
	bdf_info.dev_id = dev->devfn >> 3;
	bdf_info.fn_id = dev->devfn & 0x7;

	return bdf_info.whole;
}

int vastai_get_pci_dev_count()
{
	int count = 0;
	struct vastai_pci_info *pdev = NULL;

	list_for_each_entry(pdev, &vastai_pci_info_list, dev_list) {
		count++;
	}
	return count;
}

/* 1. if vastai_pci_info_list is empty, return 0;
   2. if vastai_pci_info_list contain pdev, return all pre-entry die_num's sum.
   3. if vastai_pci_info_list is no empty, and not contain pdev, return all entry die_num's sum
   **BE CAREFULL!** If we probe with work queue, this function will be a bug.
   */

void vastai_arrange_seq_list(struct vastai_seq_list *seq_list, int num)
{
	int i = 0;
	int j = 0;
	struct vastai_seq_list seq_tmp = {0};

	for(i=0; i<num-1; i++) {
		for(j=i+1; j<num; j++) {
			if(seq_list[i].seqId > seq_list[j].seqId) {
				seq_tmp     = seq_list[i];
				seq_list[i] = seq_list[j];
				seq_list[j] = seq_tmp;
			}
		}
	}
}

int vastai_get_seqnum(struct vastai_pci_info *pdev, unsigned int die_id)
{
	struct vastai_pci_info *pos;
	struct vastai_seq_list seq_list[64];
	int max_num = 0;
	int j = 0;
	u8 base = 0;

	if (pdev == NULL || die_id >= pdev->die_num_in_fn) {
		VASTAI_PCI_ERR(pdev, die_id,
				"%s err!\n", __func__);
		return -EINVAL;
	}

	mutex_lock(&vastai_pci_info_list_lock);
	list_for_each_entry (pos, &vastai_pci_info_list, dev_list) {
		if (vastai_get_card_info(pos) != vastai_get_card_info(pdev)) {
			if(vastai_get_board_type(pos) == SV100)
				seq_list[max_num].seq_size = pos->die_num_in_fn;
			if(vastai_get_board_type(pos) == SG100)
				seq_list[max_num].seq_size = 1;
			seq_list[max_num].seqId    = vastai_get_seq_num(pos, 0);
			max_num++;
		} else {
			break;
		}
	}
	mutex_unlock(&vastai_pci_info_list_lock);

	vastai_arrange_seq_list(seq_list, max_num);

	for(j=0; j<max_num; j++) {
		if((base + pdev->die_num_in_fn) > seq_list[j].seqId) {
			base = seq_list[j].seqId + seq_list[j].seq_size;
		} else {
			break;
		}
	}

	if(vastai_get_card_info(pdev) == NULL)
		return base + die_id;
	if(pdev->die_num_in_fn == vastai_get_card_info(pdev)->die_num_in_card)
		return base + die_id;
	else
		return base + vastai_get_die_info(pdev, die_id)->die_id_in_card;
}

static int vastai_pci_get_dlc_cores_info( struct vastai_pci_info *pcie_info , u32 die_index){
	int ret;
	/* send get dlc cores info at cmd to smcu */
	u32 die_id = vastai_pci_get_die_id(pcie_info , die_index);
	mutex_lock(&(pcie_info->dies[die_id].get_dlc_mutex));
	ret = vastai_send_pcie_cmd(pcie_info, die_index,
		VASTAI_PCIE_SUB_GET_DLC_CORE, 0);
	if (ret < 0){
		VASTAI_PCI_ERR(pcie_info, DUMMY_DIE_ID,
			"%s send cmd fail!\n",
			__func__);
		mutex_unlock(&(pcie_info->dies[die_id].get_dlc_mutex));
		return ret;
	}

	/* wait completion int from smcu */
	if (wait_for_completion_timeout(
		&(pcie_info->dies[die_id].get_dlc_core_done),
		msecs_to_jiffies(
		VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {

		VASTAI_PCI_ERR(pcie_info, DUMMY_DIE_ID,
			"%s timeout!\n",
			__func__);
		pcie_info->dies[die_id].harvest_info.type =
			VASTAI_HARVEST_ALL_DLC_AND_ODSP_DISABLED;
		mutex_unlock(&(pcie_info->dies[die_id].get_dlc_mutex));
		return -ETIMEDOUT;
	}
	reinit_completion(&(pcie_info->dies[die_id].get_dlc_core_done));
	mutex_unlock(&(pcie_info->dies[die_id].get_dlc_mutex));

	return ret;
}

static u32 vastai_get_harvest_core_flag(u16 dlc_core){

	u32 harvest_core_flag;
	u32 offset_big_core_bit = 0;
	u32 offset_small_core_bit = 0;

	offset_small_core_bit = (0x01 << ((dlc_core>>9)&0x7)) | (0x01<< ((dlc_core>>6)&0x7));
	offset_big_core_bit = (0x00010000  << ((dlc_core>>3)&0x7)) | (0x00010000  << ((dlc_core)&0x7));
	harvest_core_flag =  offset_big_core_bit + offset_small_core_bit;
	return harvest_core_flag;

}

u32 vastai_get_dlc_cores_info_sg(struct vastai_pci_info *pcie_info, u32 die_index)
{
	/* TODO */
	return 0xffffffff;
}

u32 vastai_get_dlc_cores_info(struct vastai_pci_info *pcie_info, u32 die_index){

	int ret;
	u8 type;
	u16 dlc_core;
	u32 harvest_core_flag = 0;
	u32 die_id;

	if(vastai_get_board_type(pcie_info) == SV100) {
		/*send get dlc cores info at cmd to smcu */
		die_id = vastai_pci_get_die_id(pcie_info , die_index);
		ret = vastai_pci_get_dlc_cores_info(pcie_info, die_index);
		if( ret < 0 ){
			goto DEFAULT;
		}

		type = pcie_info->dies[die_id].harvest_info.type;
		dlc_core = pcie_info->dies[die_id].harvest_info.dlc_cores;

		if (type != VASTAI_HARVEST_TYPE1 && type != VASTAI_HARVEST_TYPE2) {
			if (!pcie_info->dies[die_id].get_dlc_info_cnt) {
				VASTAI_PCI_INFO(pcie_info, DUMMY_DIE_ID,
					"%s it is not harvest type\n",__func__);
				pcie_info->dies[die_id].get_dlc_info_cnt++;
			}else {
				VASTAI_PCI_DBG(pcie_info, DUMMY_DIE_ID,
					"%s it is not harvest type\n",__func__);
			}

	DEFAULT:
			harvest_core_flag = 0x00FF00FF;
			return harvest_core_flag;
		}

		harvest_core_flag = vastai_get_harvest_core_flag(dlc_core);
		pcie_info->dies[die_id].get_dlc_info_cnt++;
	} else if(vastai_get_board_type(pcie_info) == SG100)
		harvest_core_flag = 0xffffffff;
	return harvest_core_flag;
}


/*
 * if we pcie goto error, timer will stop.
 */
static void vastai_pci_timer(struct timer_list *timer)
{
	struct vastai_pci_info *priv = from_timer(priv, timer, pci_timer);
	int i;
	int ret = 0;

	/* timer should be trigger in next 10s */
	timer->expires = jiffies + 10 * HZ;

	if (atomic_read(&(priv->pci_state)) != VASTAI_NORMAL_STATE) {
		/* trigger timer */
		add_timer(timer);
		return;
	}

	/* TODO: refactor this into die */
	for (i = 0; i < priv->die_num_in_fn; i++) {
		ret = vastai_send_pcie_cmd(priv, priv->dies[i].die_index,
					VASTAI_PCIE_SUB_TIME_SYNC,
					vastai_get_host_time_ns()/1000000);
		if (ret) {
#if 0
			atomic_set(&(priv->pci_state), VASTAI_ERROR_STATE);
#else
			// vastai_pci_state_sync_error(priv);
#endif
			break;
		}
	}

	/* trigger timer */
	add_timer(timer);
}

void vastai_pci_timer_init(struct vastai_pci_info *pci_info)
{
	timer_setup(&(pci_info->pci_timer), vastai_pci_timer, 0);
	vastai_pci_timer(&(pci_info->pci_timer));
}

void vastai_pci_set_dma_irq_agg(
				struct vastai_pci_info *priv,
				u32 agg_num,
				u32 agg_time_ms)
{
	int i;
	int ret = 0;
	u64 val = agg_time_ms;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "set dma irq aggregation, num:%u, time_out:%u", agg_num, agg_time_ms);
	val = val<<32 | agg_num;
	for (i = 0; i < priv->die_num_in_fn; i++) {
		ret = vastai_send_pcie_cmd(priv, priv->dies[i].die_index,
					VASTAI_PCIE_SUB_SET_DMA_AGGREGATION,
					val);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s set_dma_irq_aggregation, error %d\n",
			       __func__, ret);
			break;
		}
	}
}

static int vastai_pci_legacy_irq_init(struct vastai_pci_info *priv, struct pci_dev *pdev)
{
	int ret = 0;
	int i = 0;
	const char *pname;
	priv->irq = pdev->irq;

	pname = devm_kasprintf(&(priv->dev->dev), GFP_KERNEL,
			       VASTAI_PCI_DRIVER_PREFIX ":%s %d",
			       VASTAI_GET_PCI_NAME(priv), priv->irq);
	/* legacy irq will not init msix array
	 * Manual initalization */
	priv->msix[0].entry = 0;
	priv->msix[0].vector = 0;
	ret = request_irq(
		priv->irq, (irq_handler_t)(&vastai_pci_legacy_irq),
		IRQF_NO_SUSPEND | IRQF_NO_THREAD | IRQF_PERCPU, pname,
		(void *)&(priv->msix[i]));
	if (ret)
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s request_irq(%d), error %d\n",
			       __func__, priv->irq, ret);
	else
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "%s request_irq(%d) ok\n", __func__,
			       priv->irq);

	return ret;
}

static int vastai_pci_msi_irq_init(struct vastai_pci_info *priv, struct pci_dev *pdev)
{
	int ret = 0;
	int i = 0;
	priv->irq_num = pci_msi_vec_count(pdev);
	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
		       "pci_msi_vec_count irq_num=%d\n",
		       priv->irq_num);

	ret = pci_alloc_irq_vectors(pdev, 1, priv->irq_num,
				    PCI_IRQ_MSI);
	if (ret > 0) {
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "pci_enable_msi_range ret=%d\n", ret);
		priv->irq_num = ret;
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "pci_enable_msi_range err=%d\n", ret);
		priv->irq_type = VASTAI_INVALID_IRQ;
	}
	priv->irq = pdev->irq;

	for (i = 0; i < priv->irq_num; i++) {
		const char *pname =
			devm_kasprintf(&(priv->dev->dev), GFP_KERNEL,
				       VASTAI_PCI_DRIVER_PREFIX
				       ":%s %d",
				       VASTAI_GET_PCI_NAME(priv), i);
		/* msi irq will not init msix array
		 * Manual initalization */
		priv->msix[i].entry = i;
		priv->msix[i].vector = priv->irq + i;
		ret = request_irq(priv->irq + i,
				  (irq_handler_t)(&vastai_pci_msi_irq),
				  IRQF_SHARED, pname, (void *)&(priv->msix[i]));
		// IRQF_SHARED is better replaced by 0
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s request_irq(%d), error %d\n",
				       __func__, priv->irq + i, ret);
			break;
		}
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "%s request_irq(%d) ok\n", __func__,
			       priv->irq + i);
	}
	// if (i == priv->irq_num)
	//	priv->irq_en = 1;

	return ret;
}

bool vastai_pci_is_mix_card(struct vastai_pci_info *pci_info)
{
	u16 subsystem_id;

	pci_read_config_word(pci_info->dev, PCI_SUBSYSTEM_ID, &subsystem_id);

	if ((subsystem_id == VASTAI_CARD_VA16) ||
			(subsystem_id == VASTAI_CARD_VAM))
		return true;

	return false;
}

static int vastai_pci_msix_irq_init(struct vastai_pci_info *priv, struct pci_dev *pdev)
{
	int ret = 0;
	int i = 0;

	if (vastai_pci_is_mix_card(priv))
		priv->irq_num = VASTAI_MIX_CARD_IRQ_NR;
	else
		priv->irq_num = pci_msix_vec_count(pdev);

	for (i = 0; i < priv->irq_num; i++) {
		priv->msix[i].entry = i;
		priv->msix[i].vector = 0;
	}

	priv->irq_num = pci_enable_msix_range(pdev, priv->msix, 1,
					      priv->irq_num);
	if (priv->irq_num > 0) {
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "pci_enable_msix_range %d ok\n",
			       priv->irq_num);
	} else {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "pci_enable_msix_range %d err\n",
			       priv->irq_num);
		priv->irq_type = VASTAI_INVALID_IRQ;
		ret = priv->irq_num;
	}
	priv->irq = priv->msix[0].vector;

	for (i = 0; i < priv->irq_num; i++) {
		const char *pname =
			devm_kasprintf(&(priv->dev->dev), GFP_KERNEL,
				       VASTAI_PCI_DRIVER_PREFIX
				       ":%s %d",
				       VASTAI_GET_PCI_NAME(priv), i);
		ret = request_irq(priv->msix[i].vector,
				  (irq_handler_t)(&vastai_pci_msi_irq),
				  IRQF_SHARED, pname, (void *)&(priv->msix[i]));
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s request_irq(%d), error %d\n",
				       __func__, priv->msix[i].vector,
				       ret);
			priv->irq_num = i;
			vastai_pci_disable_irq(priv);
			return ret;
		}

		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			       "%s request_irq(%d) ok\n", __func__,
			       priv->msix[i].vector);
	}

	return ret;
}

static int vastai_pci_irq_init(struct vastai_pci_info *priv, struct pci_dev *pdev)
{
	int ret = 0;

	priv->irq_type = VASTAI_MSIX_IRQ;
	priv->irq = pdev->irq;

	if (priv->irq_type == VASTAI_LEGACY_IRQ) {
		ret = vastai_pci_legacy_irq_init(priv, pdev);
	}

	if (priv->irq_type == VASTAI_MSI_IRQ) {
		ret = vastai_pci_msi_irq_init(priv, pdev);
	}

	if (priv->irq_type == VASTAI_MSIX_IRQ) {
		ret = vastai_pci_msix_irq_init(priv, pdev);
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"irq_type %d, dev->irq %d(+%d)\n",
			priv->irq_type,
			priv->irq, priv->irq_num);

	return ret;
}

void vastai_check_common_include(struct vastai_pci_info *pci_info)
{
	char *find_ci_hash = 0;
	find_ci_hash = strstr(pci_info->dies[0].fw_ver.smcu_ver, "common_include: ");
	if(find_ci_hash == NULL) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "old fw, do not have common include hash id\n");
		return;
	}
	find_ci_hash += strlen("common_include: ");

	if(strcmp(find_ci_hash, VASTAI_PCI_COMMON_INCLUDE_COMMIT_HASH))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[vawarn] FW common [%s] and driver common [%s] mismatch\n",
			find_ci_hash, VASTAI_PCI_COMMON_INCLUDE_COMMIT_HASH);
	else
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "Fw common [%s] match\n",
				VASTAI_PCI_COMMON_INCLUDE_COMMIT_HASH);
}

bool vastai_find_dev_id(char devId)
{
	struct vastai_pci_info *ploop = NULL;

	list_for_each_entry(ploop, &vastai_pci_info_list, dev_list) {
		if(ploop->dev_id == devId) {
			return true;
		}
	}

	return false;
}

static void update_bar_info(struct vastai_pci_info *priv)
{
	u8 config_bar4_5_sz = priv->priv_hw_cfg->sys_cfg.bar4_5_cfg_size;

	switch (config_bar4_5_sz) {
		case HWCFG_BAR4_5_NORMAL:
			break;
		case HWCFG_BAR4_5_2GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = BAR_SIZE_2G;
			break;
		case HWCFG_BAR4_5_4GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = LARGE_BAR_4GB_DDR_SIZE;
			break;
		case HWCFG_BAR4_5_8GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = LARGE_BAR_8GB_DDR_SIZE;
			break;
		case HWCFG_BAR4_5_16GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = LARGE_BAR_16GB_DDR_SIZE;
			break;
		case HWCFG_BAR4_5_32GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = LARGE_BAR_32GB_DDR_SIZE;
			break;
		case HWCFG_BAR4_5_64GB:
			priv->bar[VASTAI_PCI_BAR4].mmio_len = LARGE_BAR_64GB_DDR_SIZE;
			break;

		default:
			break;
	}

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[BAR4]current pf ddr size = 0x%llx(%lldMB)\n",
									priv->bar[VASTAI_PCI_BAR4].mmio_len,
									priv->bar[VASTAI_PCI_BAR4].mmio_len/1024/1024);
	return;
}

void dump_bar_addr_map(struct vastai_pci_info *priv)
{
	struct pci_dev *pdev = priv->dev;
	int i = 0, r = 0;
	u64 region_offset = 0;
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "S<==================memmap fn:%d===================>S\n", pdev->devfn);

	for (i = 0; i < VASTAI_PCI_BAR_NUM; i++) {
		int flag = pci_resource_flags(pdev, i);
		if (!(flag & IORESOURCE_MEM))
			continue;

		if(i == VASTAI_PCI_BAR0){
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)  pa:0x%lx~0x%lx, va:0x%lx\n", i,
						(unsigned long)priv->bar[i].mmio_start,
						(unsigned long)priv->bar[i].mmio_end,
						(unsigned long)priv->bar[i].vmem);

			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d) noc:bar0 is not mapping, len:0x%lx(%ldK), \n", i,
						(unsigned long)priv->bar[i].mmio_len,
						(unsigned long)priv->bar[i].mmio_len / 1024);
		}

		if(i == VASTAI_PCI_BAR1){
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)  pa:0x%lx~0x%lx, va:0x%lx\n", i,
						(unsigned long)priv->bar[i].mmio_start,
						(unsigned long)priv->bar[i].mmio_end,
						(unsigned long)priv->bar[i].vmem);

			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d) noc:0x%llx~0x%llx len:0x%lx(%ldK), \n", i,
						priv->bar[i].noc_addr,
						priv->bar[i].noc_addr + priv->bar[i].mmio_len - 1,
						(unsigned long)priv->bar[i].mmio_len,
						(unsigned long)priv->bar[i].mmio_len /1024);
		}

		if(i == VASTAI_PCI_BAR2){
			for(r = 0; r < priv->bar[VASTAI_PCI_BAR2].region_cnt; r++) {
				region_offset = priv->bar[i].regions[r].bar_offset;
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)-R%d  pa:0x%llx~0x%llx, va:0x%llx)\n", i, r,
						(unsigned long)priv->bar[i].mmio_start + region_offset,
						(unsigned long)priv->bar[i].mmio_start + region_offset + priv->bar[i].regions[r].region_size - 1,
						(unsigned long)priv->bar[i].vmem + region_offset);

				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)-R%d noc:0x%llx~0x%llx, len:0x%llx(%lldK), \n", i, r,
						priv->bar[i].regions[r].noc_addr,
						priv->bar[i].regions[r].noc_addr + priv->bar[i].regions[r].region_size - 1,
						priv->bar[i].regions[r].region_size,
						priv->bar[i].regions[r].region_size / 1024);
			}
		}

		if(i == VASTAI_PCI_BAR4){
			if(priv->bar[VASTAI_PCI_BAR4].region_cnt > 0) {
				for(r = 0; r < priv->bar[VASTAI_PCI_BAR4].region_cnt; r++) {
					region_offset = priv->bar[i].regions[r].bar_offset;
					if(priv->bar[i].regions[r].region_size){
						VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)-R%d  pa:0x%llx~0x%llx, va:0x%llx)\n", i, r,
									(unsigned long)priv->bar[i].mmio_start + region_offset,
									(unsigned long)priv->bar[i].mmio_start + region_offset + priv->bar[i].regions[r].region_size - 1,
									(unsigned long)priv->bar[i].vmem + region_offset);

						VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)-R%d noc:0x%llx~0x%llx, len:0x%llx(%lldM), \n", i, r,
										priv->bar[i].regions[r].noc_addr,
										priv->bar[i].regions[r].noc_addr + priv->bar[i].regions[r].region_size - 1,
										priv->bar[i].regions[r].region_size,
										priv->bar[i].regions[r].region_size /1024/1024);
					}
				}
		} else {
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d)  pa:0x%lx~0x%lx, va:0x%lx\n", i,
							(unsigned long)priv->bar[i].mmio_start,
							(unsigned long)priv->bar[i].mmio_end,
							(unsigned long)priv->bar[i].vmem);
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"BAR(%d) noc:0x%llx~0x%llx len:0x%lx(%ldM), \n", i,
							priv->bar[i].noc_addr,
							priv->bar[i].noc_addr + priv->bar[i].mmio_len - 1,
							(unsigned long)priv->bar[i].mmio_len,
							(unsigned long)priv->bar[i].mmio_len /1024/1024);
			}
		}
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "E<==================memmap fn:%d===================>E\n", pdev->devfn);
}

int vastai_config_initial_bars(struct vastai_pci_info *priv)
{
	struct pci_dev *pdev = priv->dev;
	int ret = 0, i = 0;
	size_t read_len = 0;
	char unit = 0;

	for (i = 0; i < VASTAI_PCI_BAR_NUM; i++) {
		int flag = pci_resource_flags(pdev, i);
		if (!(flag & IORESOURCE_MEM))
			continue;

		priv->bar[i].mmio_start = pci_resource_start(pdev, i);
		priv->bar[i].mmio_end = pci_resource_end(pdev, i);
		priv->bar[i].mmio_flags = pci_resource_flags(pdev, i);
		priv->bar[i].mmio_len = pci_resource_len(pdev, i);
		priv->bar[i].mem =
			ioremap(priv->bar[i].mmio_start, priv->bar[i].mmio_len);
		priv->bar[i].vmem = priv->bar[i].mem;
		if (priv->bar[i].vmem == NULL) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s:cannot remap bar%d mmio, aborting\n",
				       pci_name(pdev), i);
			return -EIO;
		}
		if(vastai_get_board_type(priv) == SV100)
			vastai_pci_init_bar_at(priv, i);
		if(vastai_get_board_type(priv) == SG100)
			vastai_pci_init_bar_at_sg(priv, i);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"BAR(%d) mmio: 0x%016lx ~ 0x%016lx\n", i,
				(unsigned long)priv->bar[i].mmio_start,
				(unsigned long)priv->bar[i].mmio_end);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"BAR(%d) vmem: 0x%016lx ~ 0x%016lx\n", i,
				(unsigned long)priv->bar[i].vmem,
				(unsigned long)priv->bar[i].vmem +
					(unsigned long)priv->bar[i].mmio_len -
					1);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"BAR(%d)  axi: 0x%016lx ~ 0x%016llx\n", i,
				priv->bar[i].at_addr,
				priv->bar[i].at_addr + priv->bar[i].mmio_len -
					1);
		if((unsigned long)priv->bar[i].mmio_len < (1024*1024)) {
			unit = 'K';
			read_len = priv->bar[i].mmio_len / 1024;
		} else if((unsigned long)priv->bar[i].mmio_len < (1024*1024*1024)) {
			unit = 'M';
			read_len = priv->bar[i].mmio_len / 1024 / 1024;
		} else {
			unit = 'G';
			read_len = priv->bar[i].mmio_len / 1024 / 1024 /1024;
		}
		VASTAI_PCI_INFO(
			priv, DUMMY_DIE_ID, "BAR(%d) size: 0x%016lx ~ %17ld%c\n",
			i, (unsigned long)priv->bar[i].mmio_len,
			(unsigned long)read_len, unit);
		priv->bar_num += 1;
	}

	if (priv->bar_num < 4) {
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"%s bar_num[%d] is less than 4. Pls check bar configuration.\n",
			__FUNCTION__, priv->bar_num);
		ret = -EIO;
	}

	return ret;
}

int vastai_init_boot(struct vastai_pci_info *priv)
{
	int ret = 0;

	if(vastai_get_board_type(priv) == SV100) {
		if (priv->is_virtfn) {
			ret = vastai_pci_vf_init(priv);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s:cannot do vf init %d\n",
							pci_name(priv->dev), ret);
				return ret;
			}
			ret = vastai_get_system_hw_config(&(priv->dies[0]));
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: vf get hw config failed %d\n",
							pci_name(priv->dev), ret);
				return ret;
			}
		} else {
			ret = vastai_pci_boot(priv);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s:cannot do fw boot %d\n",
					       pci_name(priv->dev), ret);
				return ret;
			}
		}
	} else if(vastai_get_board_type(priv) == SG100) {
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
				"pci_dev:devfn=%d, cfg_size=%#x, pcie_cap=%#x, msi_cap=%#x, msi_en=%d, msix_cap=%#x, msix_en=%d\n",
				priv->dev->devfn, priv->dev->cfg_size, priv->dev->pcie_cap, priv->dev->msi_cap, priv->dev->msi_enabled, priv->dev->msix_cap, priv->dev->msix_enabled);

		if (priv->dev->devfn == BOOT_PF_ID && priv->is_pf) {
			ret = vastai_pci_boot(priv);
			if (ret < 0) {
				return ret;
			}
		} else
			vastai_pci_state_boot_done(priv);
		/* TODO */
		priv->boot_stage = 6;
	}

	return ret;
}

struct vastai_stage_mapping boot_process[] = {
						{VASTAI_SMCU_BOOT_STAGE_BL1_READY, vastai_poll_stage_bl1_ready,   vastai_polling_smcu_failed_proc},
						{VASTAI_SMCU_BOOT_STAGE_FW_READY,  vastai_poll_stage_fw_ready_sv, vastai_polling_smcu_failed_proc},
						{VASTAI_SMCU_BOOT_STAGE_DIE_DONE,  vastai_poll_stage_die_done,    vastai_polling_smcu_failed_proc},
						{VASTAI_SMCU_BOOT_STAGE_BOOT_DONE, vastai_poll_stage_boot_done,   vastai_polling_smcu_failed_proc},
						{VASTAI_SMCU_STAGE_END,            NULL}
					     };

struct vastai_stage_mapping boot_process_sg[] = {
							{VASTAI_SMCU_BOOT_STAGE_BL1_READY,  vastai_poll_stage_bl1_ready,   NULL},
							{VASTAI_SMCU_BOOT_STAGE_FW_READY,   vastai_poll_stage_fw_ready_sg, NULL},
							{VASTAI_SMCU_BOOT_STAGE_FW_BOOT_UP, vastai_poll_stage_boot_up,     NULL},
							{VASTAI_SMCU_STAGE_END,             NULL}
						};

int vastai_pci_probe_sg_pre_check(struct pci_dev *pdev, const struct pci_device_id *id)
{
#ifndef VASTAI_VF_TILE_MODE_SUPPORT
	if (pdev->is_virtfn) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s is_virtfn=%d, No support\n", __func__, pdev->is_virtfn);
		return -ENXIO;
	}
#endif

#ifndef VASTAI_MULTI_PF_SUPPORT
	if (pdev->devfn != BOOT_PF_ID) {
		/* We only claim function 0 */
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s devfn=%d, No support for multiple PF & VF.\n", __func__, pdev->devfn);
		return -EPERM;
	}
#endif

	return 0;
}

int vastai_pci_probe_sv_pre_check(struct pci_dev *pdev, const struct pci_device_id *id)
{
	/*
	 * We only install vf driver in vm.
	 * Remove this condition if you want to install vf driver in host
	 */
	if ((id->device == 0x101) && pdev->is_virtfn) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s id->device[0x101] and vf\n", __func__);
		return -ENXIO;
	}

	return 0;
}


static board_type_e get_board_type(const struct pci_device_id *id)
{
	if (SV100_BOARD_DEVICE_ID == (id->device & BOARD_DEVICE_ID_MASK) ||
		PCI_ALIBABA_FPGA_DEVICE_ID == (id->device))
		return SV100;
	else if (SG100_BOARD_DEVICE_ID == (id->device & BOARD_DEVICE_ID_MASK))
		return SG100;

	VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			"unknow device[0x%x]\n", id->device);
	return TYPE_UNKNOWN;
}

void vastai_probe_entery_print(struct pci_dev *pdev, const struct pci_device_id *id)
{
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "******************%s devfn=%d*********************\n", __func__, pdev->devfn);
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "pci_dev=0x%p, deviceID=%#x, at romcode stage.\n", pdev, id->device);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "Domain=%#x, bus=%#x, name=%s, primary=%d, official name:%s\n", pci_domain_nr(pdev->bus), pdev->bus->number, pdev->bus->name, pdev->bus->primary, pci_name(pdev));
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "vastai_pci_info_list=0x%p\n", &vastai_pci_info_list);
}
extern void vastai_pci_probe_bh(struct work_struct *work);
void vastai_sv_probe_init_mem(struct vastai_pci_info *priv)
{
	int i=0;

	spin_lock_init(&priv->msgq_1_lock);
	init_completion(&priv->set_bar_done);

	init_completion(&priv->activate_vf_done);
	init_completion(&priv->deactivate_vf_done);
	spin_lock_init(&priv->file_lock);
	INIT_LIST_HEAD(&priv->file_list);
	init_completion(&priv->bmcu_update_comp);
	INIT_WORK(&priv->boot_work, vastai_pci_probe_bh);

	for (i = 0; i < ARRAY_SIZE(priv->dies); i++) {
		init_completion(&(priv->dies[i].log_comp));
		init_completion(&(priv->dies[i].ecc_2bit_err));
		init_completion(&(priv->dies[i].rw_xspi));
		init_completion(&(priv->dies[i].smi_ack[0]));
		init_completion(&(priv->dies[i].smi_ack[1]));
		init_completion(&(priv->dies[i].core_time_sync_ack));
		init_completion(&(priv->dies[i].wait_dn_ack));
		init_completion(&(priv->tools_info.log_comp));
	}
	INIT_LIST_HEAD(&(priv->vacc_dev_head));
	INIT_LIST_HEAD(&(priv->fn_node_list));
}

void vastai_sg_probe_init_mem(struct vastai_pci_info *priv)
{
	mutex_init(&priv->trans_mutex);
	mutex_init(&priv->mmio_read_mutex);
	mutex_init(&priv->mmio_write_mutex);
	spin_lock_init(&priv->mmio_read_spin_lock);
	spin_lock_init(&priv->mmio_write_spin_lock);
	mutex_init(&vastai_pci_modify_lock);
	spin_lock_init(&priv->trans_lock);
	spin_lock_init(&priv->swtich_atu_lock);
	spin_lock_init(&priv->ring_buf_lock);
	init_completion(&priv->swtich_atu_done);
	init_completion(&priv->read_csr_by_smcu_done);
	init_completion(&priv->write_csr_by_smcu_done);
	init_completion(&priv->rw_xspi);
	init_completion(&priv->pcie_monitor_done);
	init_completion(&priv->ddr_monitor_done);
	init_completion(&priv->send_reinit_rst_done);
	INIT_LIST_HEAD(&(priv->vacc_dev_head));
	INIT_LIST_HEAD(&priv->file_list);
	INIT_LIST_HEAD(&(priv->fn_node_list));
#if 1
#ifdef CONFIG_VASTAI_TOOLS_SUITE
	init_completion(&(priv->tools_info.smi_ack[0]));
	init_completion(&(priv->tools_info.smi_ack[1]));
	init_completion(&(priv->tools_info.core_time_sync_ack));
	init_completion(&(priv->tools_info.log_comp));
	mutex_init(&(priv->tools_info.tools_dev_mutex));
	mutex_init(&(priv->tools_info.tools_die_mutex));
#endif
#endif
}

int vastai_pci_alloc_ob_addr(struct vastai_pci_info *priv)
{
	int die_id = 0;
	struct vastai_outbound *pOb = NULL;

	priv->pci_link_stat.dma_vir = dma_alloc_coherent(&(priv->dev->dev), VASTAI_OB_HB_SIZE,
							(dma_addr_t *)(&priv->pci_link_stat.dma_bus_addr),
							GFP_DMA32 | GFP_KERNEL);
	if (!(priv->pci_link_stat.dma_vir)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "vastai outbound alloc err\n");
		return -ENOMEM;
	}
	memset(priv->pci_link_stat.dma_vir, 0, VASTAI_OB_HB_SIZE);
	for(die_id=0; die_id<VASTAI_SV100_MAX_DIE_NUM; die_id++) {
		priv->dies[die_id].pci_link_stat.dma_vir = (u8*)priv->pci_link_stat.dma_vir +
							VASTAI_OB_HB_SIZE/VASTAI_SV100_MAX_DIE_NUM*die_id;
		pOb = (struct vastai_outbound *)((u8*)priv->pci_link_stat.dma_vir + die_id*1024);
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"(%s) pci monitor addr:%llx\n", __FUNCTION__, (u64)priv->pci_link_stat.dma_bus_addr);

	return 0;
}

void vastai_pci_free_ob_addr(struct vastai_pci_info *priv)
{
	dma_free_coherent(&(priv->dev->dev),
		VASTAI_OB_HB_SIZE, (void *)(priv->pci_link_stat.dma_vir), priv->pci_link_stat.dma_bus_addr);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"(%s) pci monitor addr is free \n", __FUNCTION__);
}

/*numa info description:
 * non-numa mode: numa mode:-1, node_cpus:null
 * numa mode: numa mode:0/1/.., node_cpus: [32-63,96-127]
 */
int vastai_pci_numa_cpu_info(struct vastai_pci_info *pci_info, char *numa_cpu_info_item, int len)
{
	int	numa_node;
	const struct cpumask *node_cpumask;

	numa_node = dev_to_node(&pci_info->dev->dev);
	node_cpumask = cpumask_of_node(numa_node);
	snprintf(numa_cpu_info_item, len, "pci_name:[%s]*numa_node:[%d]*node_cpus:[%*pbl];",
		    pci_name(pci_info->dev), numa_node, cpumask_pr_args(node_cpumask));

	return 0;
}

int vastai_pci_numa_cpu_info_all(char *buf, int len)
{
	struct vastai_pci_info *pci_info = NULL;
	char numa_cpu_info_item[128] = {0};
	u32 total_len = 0;
	u32 item_len = 0;

	mutex_lock(&vastai_pci_info_list_lock);
	if (list_empty(&vastai_pci_info_list)) {
		mutex_unlock(&vastai_pci_info_list_lock);
		return -1;
	}

	list_for_each_entry(pci_info, &vastai_pci_info_list, dev_list) {
		vastai_pci_numa_cpu_info(pci_info, numa_cpu_info_item, sizeof(numa_cpu_info_item));
		total_len = strlen(buf);
		item_len = strlen(numa_cpu_info_item);
		if (total_len + item_len > len) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "numa_cpu_info buffer space not enough!\n");
			mutex_unlock(&vastai_pci_info_list_lock);
			return -2;
		}
		strcat(buf, numa_cpu_info_item);
	}
	mutex_unlock(&vastai_pci_info_list_lock);
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "pci_numa_cpu:%s\n", buf);

	return 0;
}

bool is_find_card_info(u8 *sn)
{
	struct vastai_card_info *ploop = NULL;
	bool isfind = false;

	mutex_lock(&vastai_card_info_list_lock);
	list_for_each_entry(ploop, &vastai_card_info_list, card_node) {
		if(!strcmp(sn, ploop->sn_info)) {
			isfind = true;
			break;
		}
	}
	mutex_unlock(&vastai_card_info_list_lock);

	return isfind;
}

int vastai_create_card_info_tree(struct vastai_pci_info *priv, struct vastai_card_info **card_info, struct sv100_system_cfg *sys_config)
{
	u8 *sn = sys_config->mb_sn;
	struct pci_dev *pdev = priv->dev;
	struct vastai_card_info *card_loop = NULL;
	u8 card_id = 0;

	if(is_find_card_info(sn))
		return 0;

	*card_info = kzalloc(sizeof(struct vastai_card_info), GFP_KERNEL);
	if (!(*card_info))
		return -ENOMEM;

	//card_info->bdf_info.fn_id     = pdev->devfn & 0x7;
	(*card_info)->bdf_info.dev_id    = pdev->devfn >> 3;
	(*card_info)->bdf_info.bus_id    = pdev->bus->number;
	(*card_info)->bdf_info.domain_id = pci_domain_nr(pdev->bus);

	memcpy((*card_info)->sn_info, sn, SN_LEN - 1);
	(*card_info)->sn_info[SN_LEN-1] = 0;
	(*card_info)->board_type = priv->board_type;
	INIT_LIST_HEAD(&((*card_info)->vastai_pkg_info_list));

	mutex_lock(&vastai_card_info_list_lock);
	list_for_each_entry(card_loop, &vastai_card_info_list, card_node) {
		card_id++;
	}
	list_add_tail(&((*card_info)->card_node), &(vastai_card_info_list));
	(*card_info)->card_id = card_id;
	(*card_info)->fn_num  = (sys_config->bitmap.die_num_in_card)/(sys_config->die_num_in_fn);
	mutex_unlock(&vastai_card_info_list_lock);

	return 0;
}

int vastai_delete_card_info_tree(struct vastai_pci_info *priv)
{
	struct vastai_card_info *card_info = vastai_get_card_info(priv);
	struct vastai_pkg_info *pkg_loop = NULL;
	struct vastai_pkg_info *pkg_tmp  = NULL;

	mutex_lock(&vastai_card_info_list_lock);

	/* TODO: should check multi fn, now is sv100*/
	list_for_each_entry_safe(pkg_loop, pkg_tmp, &card_info->vastai_pkg_info_list, pkg_node) {
		struct vastai_die_info *die_loop = NULL;
		struct vastai_die_info *die_tmp  = NULL;

		list_for_each_entry_safe(die_loop, die_tmp, &pkg_loop->vastai_die_info_list, die_node) {
			struct fn_tree_node *fn_node = NULL;
			struct fn_tree_node *fn_node_tmp = NULL;

			list_for_each_entry_safe(fn_node, fn_node_tmp, &die_loop->vastai_fn_info_list, parent_node) {
				if((fn_node->priv) == priv) {
					list_del(&(fn_node->parent_node));
					list_del(&(fn_node->internal_node));
					kfree(fn_node);
				}
			}
			if(list_empty(&die_loop->vastai_fn_info_list)) {
				list_del(&(die_loop->die_node));
				kfree(die_loop);
			}
		}
		if(list_empty(&pkg_loop->vastai_die_info_list)) {
			list_del(&(pkg_loop->pkg_node));
			kfree(pkg_loop);
		}
	}
	if(list_empty(&card_info->vastai_pkg_info_list)) {
		list_del(&(card_info->card_node));
		kfree(card_info);
	}

	mutex_unlock(&vastai_card_info_list_lock);

	return 0;
}

// 把vastai_pci_info当成fn加入
extern bool is_find_die_info(u8 pkg_id, u8 die_id_in_card, struct vastai_die_info **die_info, u8 *sn);
extern bool is_find_fn_info(struct vastai_die_info *die_info, struct vastai_pci_info *priv);
extern int vastai_create_die_info_tree(u8 pkg_id, u8 die_id_in_card, struct vastai_die_info **die_info, u8 *sn);

int vastai_create_fn_info_tree(struct vastai_pci_info *priv, u8 *sn, u8 pkg_id, u8 die_id_in_card)
{
	int ret = 0;
	struct vastai_die_info  *die_info  = NULL;
	struct fn_tree_node *fn_node = NULL;
	unsigned long flags = 0;

	mutex_lock(&vastai_card_info_list_lock);
	if(is_find_die_info(pkg_id, die_id_in_card, &die_info, sn)) {
		if(!die_info) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s die_info is NULL.\n",
				__func__);

			mutex_unlock(&vastai_card_info_list_lock);
			return -ENOMEM;
		}

		if(is_find_fn_info(die_info, priv)) {
			mutex_unlock(&vastai_card_info_list_lock);
			return ret;
		}
	} else {
		ret = vastai_create_die_info_tree(pkg_id, die_id_in_card, &die_info, sn);
		if(ret) {
			mutex_unlock(&vastai_card_info_list_lock);
			return ret;
		}
	}

	fn_node = kzalloc(sizeof(struct fn_tree_node), GFP_KERNEL);
	if(!fn_node) {
		VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s fn_node is NULL.\n",
				__func__);
		return -1;
	}
	list_add_tail(&(fn_node->internal_node), &(priv->fn_node_list));
	fn_node->die_info = die_info;
	fn_node->priv     = priv;
	spin_lock_irqsave(&die_info->fn_info_list_lock, flags);
	list_add_tail(&(fn_node->parent_node),   &(die_info->vastai_fn_info_list));
	spin_unlock_irqrestore(&die_info->fn_info_list_lock, flags);

	mutex_unlock(&vastai_card_info_list_lock);

	return ret;
}

static void vastai_vm_check(struct vastai_pci_info *priv)
{
	u32 reg_val[2], reg_addr;
	int ret;

	priv->is_in_vm = true;

	reg_addr = VASTAI_PCIE_EP_CDN_CONFIG_BAR0;
	ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, 0),
					  reg_addr, reg_val, 8);
	if (priv->bar[0].mmio_start == reg_val[0] &&
		priv->bar[1].mmio_start == reg_val[1])
		priv->is_in_vm = false;
	if (priv->is_in_vm)
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"This is in vm\n");
	return;
}

static void vastai_flr_check(struct vastai_pci_info *priv)
{
	u32 reg_val, reg_addr;
	int ret;

	priv->flr_is_en = false;
	reg_addr = VASTAI_PCIE_EP_CDN_PCI_DEVCAP;
	ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, 0),
					  reg_addr, &reg_val, 8);
	if (reg_val & VASTAI_PCI_EXP_DEVCAP_FLR) {
		priv->flr_is_en = true;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"flr is enable\n");
	}
	return;
}

static void vastai_bbox_uer_cfg(struct vastai_pci_info *priv)
{
	int ret;

	if (bbox != UINT_MAX) {
		ret = vastai_bbox_set(priv, bbox);
		if (ret)
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"set bbox:%x failed, %d\n", bbox, ret);
		else
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"set bbox:%x\n", bbox);
	}
}

struct die_bar_info {
	u32 die_id;
	u32 csram_bar_addr;
	u64 ddr_bar_addr;
};
static void update_die_bar_info(struct vastai_pci_info *priv)
{
	struct vastai_pci_info *pdev;
	struct die_bar_info bar_info;
	int i;
	u64 bar_addr;
	int ret;
	union die_index_data die_idex;

	for (i = 0; i < priv->die_num_in_fn; i++) {
		die_idex.val = priv->dies[i].die_index;
		bar_info.die_id = die_idex.seq_num;
		ret = vastai_ddr_to_bar(priv, priv->dies[i].die_index, CSRAM_BASE_ADDR, &bar_addr);
		if (ret)
			return;
		bar_info.csram_bar_addr = (u32)bar_addr;

		ret = vastai_ddr_to_bar(priv, priv->dies[i].die_index, SV_DDR_BASE_ADDR, &bar_addr);
		if (ret)
			return;
		bar_info.ddr_bar_addr = bar_addr;

		memcpy((void *)((u8 *)bar_addr_info + bar_info.die_id * sizeof(struct die_bar_info)),
				(void *)&bar_info, sizeof(struct die_bar_info));
	}

	down_write(&tools_devs_rw_sem);

	list_for_each_entry(pdev, &vastai_tools_devs_list, tools_dev_list) {
		for (i = 0; i < pdev->die_num_in_fn; i++)
			vastai_pci_mem_write(pdev, vastai_pci_get_die_index(pdev, i),
						  SV100_BAR_INFO, (void *)bar_addr_info,
						  sizeof(struct die_bar_info) * VASTAI_MAX_DIE_NUM_IN_HOST);
	}
	up_write(&tools_devs_rw_sem);
}

void vastai_pci_probe_bh(struct work_struct *work)
{
	int ret = 0;
	int i = 0;
	struct vastai_pci_info *priv = container_of(work, struct vastai_pci_info , boot_work);
	struct pci_dev *pdev = priv->dev;

	struct vastai_pci_info *pos = NULL;
	struct vastai_pci_info *pos_tmp = NULL;
	struct list_head *pos_node = &vastai_tools_devs_list;

#ifdef CONFIG_VASTAI_PCI_BOOT
	ret = vastai_init_boot(priv);
	if(ret)
		goto ERROR_BOOT_FAIL;
#endif
	vastai_pci_ioctl_init(priv);
	ret = vastai_dmabuf_init(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "Failed to init vastai dmabuf. errno %d\n", ret);

		goto ERROR_DMABUF_INIT;
	}
#ifdef ENABLE_MEMPOOL_EX
	ret = vastai_mempool_ex_init(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "Failed to init mempool. errno %d\n", ret);
		goto ERROR_DEINIT_DMABUF;
	}
#endif
	if(vastai_get_board_type(priv) == SV100) {
		struct vastai_card_info *card_info = NULL;

		vastai_vm_check(priv);
		vastai_flr_check(priv);
		vastai_bbox_uer_cfg(priv);
		/* get ddr attributes from die0 */
		vastai_pci_get_ddr_attr(priv);

		card_info = vastai_get_card_info(priv);
		memset(card_info->inventory, 0, 4096);
		ret = vastai_pci_tl_read(priv, 0, VASTAI_MB_INVENTORY_ADDR, card_info->inventory, 4096);
		if (ret) {
			VASTAI_PCI_ERR(priv, VASTAI_DIE0,
				       "%s get mb inventory info err\n",
				       __func__);
#ifdef ENABLE_MEMPOOL_EX
			goto ERROR_DEINIT_MEMPOOL_EX;
#else
			goto ERROR_DEINIT_DMABUF;
#endif
		}
		for (i = 0; i < priv->die_num_in_fn; i++) {
			memset(priv->dies[i].inventory, 0, 4096);
			ret = vastai_pci_tl_read(priv, i, VASTAI_PKG_INVENTORY_ADDR, priv->dies[i].inventory, 4096);
			if (ret) {
				VASTAI_PCI_ERR(priv, i,
					       "%s get die inventory info err\n",
					       __func__);
#ifdef ENABLE_MEMPOOL_EX
				goto ERROR_DEINIT_MEMPOOL_EX;
#else
				goto ERROR_DEINIT_DMABUF;
#endif
			}
		}

		/* get fw version */
	//	vastai_pci_get_fw_ver(priv, 0xFFF);
		vastai_check_common_include(priv);

		ret = dmi_set_device(priv);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s:flash dmi is fail %d\n",
				       pci_name(pdev), ret);
		}

		if(priv->is_physfn) vastai_pci_timer_init(priv);

		vastai_bbox_init(priv);

#ifdef CONFIG_VASTAI_RAS
		vastai_ras_init(priv);
#endif
	} else if(vastai_get_board_type(priv) == SG100) {
		ret = get_hw_config(priv);

		if (!ret) {
			priv->pkg_id = priv->priv_hw_cfg->sys_cfg.pkg_id;
			priv->fn_mode = priv->priv_hw_cfg->sys_cfg.fn_mode;
			ret = vastai_pci_get_pf_num_per_card(priv);
			vastai_pci_get_die_index(priv, 0);
		} else {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"get_hw_config failed, %d\n", ret);
		}
		priv->p_select_bar = translate_noc_addr_origin;

#if CONFIG_D2H_BY_GART_OR_ATU
		priv->hasInitGfxMemAlloc = false;
#endif
		update_bar_info(priv);

		init_vastai_pci_mem(priv);

		ret = va_hw_init(priv);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"va_hw_init failed, %d\n", ret);
		}

		if (BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.pfn && priv->is_pf) {
			ret = logsys_init(priv);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "logsys_init fail ret[%d]\n", ret);
			}
			vastai_version_file_init(priv);
		}


#ifdef CONFIG_PVP_HASH_CMP_EN
		mutex_init(&priv->cedar_lock);
#endif
		init_all_ring_buf(priv);
		smcu_to_host_msix_init(priv);
	}

	priv->addr->p_excetion_init(priv);

	mutex_lock(&vastai_service_module_lock);
	if(vastai_get_board_type(priv) == SG100)
		init_ai_info(priv);

	/* *********************************
	 * if ai and video register error,
	 * Pcie driver should not return error,
	 * print a msg is enough for debug
	 * *********************************/
#ifdef CONFIG_VASTAI_AI
	for (i = 0; i < priv->die_num_in_fn; i++) {
		if(priv->addr->p_vacc_init) {
			ret = priv->addr->p_vacc_init(priv, priv->dies[i].die_index);
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					       "%s:cannot do vacc_init %d\n",
					       pci_name(pdev), ret);
			}
		}
	}
#endif
#ifdef CONFIG_VASTAI_VIDEO
	INIT_LIST_HEAD(&priv->render_head);
	for (i = 0; i < priv->die_num_in_fn; i++) {
		if(priv->addr->p_video_init) {
			ret = priv->addr->p_video_init(priv, priv->dies[i].die_index,
				  &(priv->dies[i].render_id));
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					       "%s:cannot do vastai_video_init %d\n",
					       pci_name(pdev), ret);
			}
		}
	}

#endif

	if(vastai_get_board_type(priv) == SG100) {
		device_smmu_ste_table_init(priv);

		if ((pdev->devfn == BOOT_PF_ID) && (BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.pfn) && priv->is_pf) {
			ret = vastai_pci_poll_smcu_stage(priv, VASTAI_DIE0, VASTAI_SMCU_BOOT_STAGE_ALLCORE_READY);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, VASTAI_DIE0, "%s poll smcu stage[%d] error\n", __func__, VASTAI_SMCU_BOOT_STAGE_ALLCORE_READY);
			}

			vastai_pci_set_host_stage(priv, VASTAI_DIE0, VASTAI_HOST_BOOT_STAGE_READY_SG);
		}

		if (BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.pfn && priv->is_pf) {
			/* get fw version */
			if (priv->priv_hw_cfg->sys_cfg.pkg_id == 0)
				vastai_pci_get_fw_ver_sg(priv, 0x7FFF);
			else
				vastai_pci_get_fw_ver_sg(priv, 0x1800);
		}
		if ((pdev->devfn == BOOT_PF_ID) && (BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.pfn) && priv->is_pf)
		{
			ret = va_create_pid(priv, 128);
			if (ret) {
				VASTAI_PCI_ERR(priv, 0,"va_create_pid create failed\n");
			}
		}
		if(priv->is_pf) {
			// Needs put it at the end of the probe
			va_get_card_info(NULL, priv);
		}
	}

#ifdef CONFIG_VASTAI_LOGSYS
	/* logsys probe init */
	ret = vastai_logsys_probe_init(priv);
	if (ret != 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "vastai_logsys_probe_init fail ret[%d]\n", ret);
	}
#endif

	/**
	 * heartbeat monitor init, init at the end
	 */
	vastai_heartbeat_monitor_init(priv);

	if(vastai_get_board_type(priv) == SV100) {
		ret = vastai_device_info_init(priv);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s:cannot do evice_info_init %d\n", pci_name(pdev), ret);
		}
	}
	mutex_unlock(&vastai_service_module_lock);

#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	if (priv->is_physfn) vastai_pci_link_monitor_init(priv);
#else
	(void)vastai_pci_link_monitor_init;
#endif

	if (priv->is_physfn && vf_num > 0) {
		if (pdev->driver->sriov_configure)
			pdev->driver->sriov_configure(pdev, vf_num);
	}

	priv->probe_done = true;
	VASTAI_PCI_FUNC_EXIT;
	//VASTAI_PCI_FUNC_EXIT;
	down_write(&tools_devs_rw_sem);

	list_for_each_entry_safe (pos, pos_tmp,
				&vastai_tools_devs_list, tools_dev_list) {
		if (priv->dev_id < pos->dev_id) {
			pos_node = &pos->tools_dev_list;
			break;
		}
		// last
		if (list_is_last(&(pos->tools_dev_list), &vastai_tools_devs_list)) {
			pos_node = &vastai_tools_devs_list;
		}
	}
	list_add_tail(&(priv->tools_dev_list), pos_node);

	up_write(&tools_devs_rw_sem);

	update_die_bar_info(priv);

	vastai_get_share_mem_bank_info(priv, 0, &(priv->vatool_ddr_mem_wrtest_addr), &(priv->vatool_ddr_mem_wrtest_size));

	/* *********************************
	 * if vatools register error,
	 * Pcie driver should not return error,
	 * print a msg is enough for debug
	 * *********************************/
#ifdef CONFIG_VASTAI_TOOLS_SUITE
	if(priv->addr->p_tools_init) {
		ret = priv->addr->p_tools_init(priv);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s:cannot do tools_init %d\n", pci_name(pdev),
				       ret);
		}
	}
#endif
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s done!\n", __func__);

	return;

#ifdef ENABLE_MEMPOOL_EX
ERROR_DEINIT_MEMPOOL_EX:
	ret = vastai_mempool_ex_deinit(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "Failed to init mempool. errno %d\n", ret);
	}
#endif

ERROR_DEINIT_DMABUF:
	vastai_dmabuf_deinit(priv);
ERROR_DMABUF_INIT:
	vastai_pci_ioctl_deinit(priv);
	if (priv->is_physfn)
		cancel_delayed_work_sync(&priv->bmcu_timeout_work);
ERROR_BOOT_FAIL:
	if (boot_failed_debug) {
		priv->boot_failed_flag = true;
		vastai_pci_ioctl_init(priv);
		vastai_pci_state_debug(priv);
		return;
	}

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
	pci_disable_pcie_error_reporting(pdev);
#endif
	mutex_lock(&vastai_pci_info_list_lock);
	list_del(&(priv->dev_list));
	mutex_unlock(&vastai_pci_info_list_lock);

	vastai_pci_state_power_off(priv);

	vastai_pci_disable_irq(priv);
	pci_release_regions(pdev);
	pci_disable_device(pdev);
	pci_set_drvdata(pdev, NULL);
	kfree(priv);

	return;
}

static int vastai_pci_probe(struct pci_dev *pdev,
			    const struct pci_device_id *id)
{
	struct vastai_pci_info *priv = NULL;
	int ret = 0;
	board_type_e board_type = get_board_type(id);

	VASTAI_PCI_FUNC_ENTERY;

	if(board_type == TYPE_UNKNOWN)
		return -EPERM;

	if(vastai_global_addr_info[board_type].p_probe_pre_check) {
		ret = vastai_global_addr_info[board_type].p_probe_pre_check(pdev, id);
		if(ret)
			return ret;
	}
	if(vastai_global_addr_info[board_type].p_probe_entery_print)
		vastai_global_addr_info[board_type].p_probe_entery_print(pdev, id);

#ifdef CONFIG_VASTAI_PCI_FORCE_SINGLE_DIE
	if(pdev->devfn >=4 && board_type == SG100) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"This is force single die, return 0\n");
		return 0;
	}
	onedie = true;
#endif
	priv = kzalloc(sizeof(struct vastai_pci_info), GFP_KERNEL);
	if (!priv)
		return -ENOMEM;

	if (onedie)
		priv->force_single_die = true;

	vastai_pci_state_reset_done(priv);
	priv->board_type = board_type;

	priv->addr = &vastai_global_addr_info[board_type];
	priv->addr->p_probe_init_mem(priv);
	priv->p_select_bar = vastai_global_addr_info[board_type].p_select_bar;
	priv->p_trans_addr = vastai_global_addr_info[board_type].p_trans_addr;

	if (id->device == 0x100) {
		priv->is_physfn = 1;
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"This is a PF Device, device id:0x%x\n",
				id->device);
	} else if (id->device == 0x101) {
		priv->is_virtfn = 1;
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"This is a VF Device, device id: 0x%x\n",
				id->device);
	} else if (id->vendor == PCI_VENDOR_ID_ALIBABA) {
		priv->is_physfn = 1;
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"This is a PF Device, device id:0x%x\n",
				id->device);
	} else if (id->device == PF_DEVICE_ID || id->device == GFX_PF_DEVICE_ID || id->device == AUD_PF_DEVICE_ID) {
		priv->is_pf = 1;
	} else if (id->device == VF_DEVICE_ID || id->device == VF_DEVICE_ID2) {
		priv->is_vf = 1;
	} else {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				"This is a Invalid Device, device id: 0x%x\n",
				id->device);
		kfree(priv);
		return -ENXIO;
	}
	mutex_init(&priv->set_bar_lock);

	mutex_lock(&vastai_pci_info_list_lock);

	priv->dev_id = g_devId;
	mutex_unlock(&vastai_pci_info_list_lock);
	g_devId++;

	/* we assume only one die in this device first, and get the real die num at boot */
	priv->die_num_in_fn = 1; /* this member will modify at vastai_pci_boot */

	priv->dev = pdev;
	pci_set_drvdata(pdev, priv);
	/*disable ats capbility*
	*kernel 4.14 not support untrusted property*
	*grub add "intel_iommu=strict" can disable ats*/
	// pdev->untrusted = 1;

	if (pci_enable_device(pdev) < 0) {
		ret = -EIO;
		goto ERROR_FREE_PRIV;
	}

	if(priv->addr->p_alloc_ob_addr) {
		ret = priv->addr->p_alloc_ob_addr(priv);
		if(ret)
			goto ERROR_FREE_PRIV;
	}

	priv->irq_num = ADDR(priv, VASTAI_PCIE_MSIX_NUM);

	ret = vastai_config_initial_bars(priv);
	if(ret)
		goto ERROR_DISABLE_PCIE;

	/*
	 * Enabling the device will enable any BARs,
	 * device memory is now accessible.
	 */
	if (pci_request_regions(pdev, "vastai_pci_basic") < 0) {
		ret = -1;
		goto ERROR_DISABLE_PCIE;
	}

	ret = vastai_pci_irq_init(priv, pdev);
	if(ret) {
		goto ERROR_RELEASE_REGIONS;
	}

#ifdef CONFIG_VASTAI_QUIRKS
	ret = vastai_qurik_init(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "Failed to init vastai qurik %d\n", ret);
		goto ERROR_DISALE_IRQ;
	}
#endif

	mutex_lock(&vastai_pci_info_list_lock);
	list_add_tail(&(priv->dev_list), &(vastai_pci_info_list));
	mutex_unlock(&vastai_pci_info_list_lock);
#if 0
	/* change to GEN4 */
	ret = vastai_pci_generation_sel(priv, VASTAI_PCI_GEN4);
	if (ret < 0) {
		goto ERROR_RELEASE_REGIONS;
	}
#endif
	/* Enable AER */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
	/* Enable AER */
	pci_enable_pcie_error_reporting(pdev);
#endif
	/* Enable bus mastering (we don't use it though) */
	pci_set_master(pdev);
	if(vastai_get_board_type(priv) == SG100) {
		// Set MRRS
		pcie_set_readrq(pdev, 128);
	}

	/* we create kchar before boot fw,
	 * since we want to keep a debug window to see register that boot is not solid.
	 * For same purpose, we will not destroy pcie_info, after we boot failed
	 */
//	vastai_pci_ioctl_init(priv); // NTD

	if(vastai_get_board_type(priv) == SV100) {
#ifdef CONFIG_VASTAI_HW_TYPE
		priv->vadev.dev_cap = CONFIG_VASTAI_HW_TYPE;
#else
		priv->vadev.dev_cap = VASTAI_HW_TYPE_DEFAULT;
#endif
		pci_save_state(priv->dev);
		if (corewq) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			       "enable core irq workqueue\n");
			priv->ai_video_workqueue_enable = 1;
		}

	}
	if(parallel_load)
		schedule_work(&priv->boot_work);
	else
		vastai_pci_probe_bh(&priv->boot_work);

	return ret;

ERROR_DISALE_IRQ:
	vastai_pci_disable_irq(priv);
ERROR_RELEASE_REGIONS:
	pci_release_regions(pdev);
ERROR_DISABLE_PCIE:
	pci_disable_device(pdev);
ERROR_FREE_PRIV:
	pci_set_drvdata(pdev, NULL);
	kfree(priv);
	return ret;
}

#define KILL_TIMEOUT		8  /* time until process gets killed */
int vastai_open_files(struct vastai_pci_info *priv)
{
	int rc;
	unsigned long flags;
	struct pid_entry *pid_entry = NULL;

	spin_lock_irqsave(&priv->file_lock, flags);
	rc = list_empty(&priv->file_list);
	if(!rc)
		list_for_each_entry(pid_entry, &priv->file_list, node) {
			struct task_struct *task = pid_task(pid_entry->pid, PIDTYPE_PID);

			if(task)
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "ongoing [%s]\n", task->comm);
		}
	spin_unlock_irqrestore(&priv->file_lock, flags);
	return !rc;
}

void vastai_remove_hotplug_handle(struct vastai_pci_info *priv)
{
	unsigned int files = 0;
	unsigned long flags;
	int i = 0;
	int max_loop = 10;
	struct pid_entry *pid_entry = NULL;

	spin_lock_irqsave(&priv->file_lock, flags);
	list_for_each_entry(pid_entry, &priv->file_list, node) {
		kill_pid(pid_entry->pid, SIGKILL, 1);
		files++;
	}
	spin_unlock_irqrestore(&priv->file_lock, flags);

	if (files) {
		/* Give kill_timout more seconds to end processes */
		for (i = 0; (i < KILL_TIMEOUT) &&
			     vastai_open_files(priv); i++) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "  %d sec ...\n", i);

			cond_resched();
			msleep(1000);
		}
	}

	while((0 < module_refcount(THIS_MODULE)) && max_loop)
	{
		max_loop--;
		msleep(100);
#if 0 // #ifdef CONFIG_VASTAI_TOOLS_SUITE
		// tools clearup begin
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
				"vatools clear device begin\n");
		// die
		/* tools die mutex */
		for (i = 0; i < priv->die_num; i++) {
			VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
					"vatools clear die=%d begin\n",	i);
			if (mutex_is_locked(&priv->dies[i].tools_die_mutex)) {
				mutex_unlock(&priv->dies[i].tools_die_mutex);
			}

			priv->dies[i].smi_ack_msg[0] = 0;
			priv->dies[i].smi_ack_msg[1] = 0;
			complete(&priv->dies[i].smi_ack[0]);
			complete(&priv->dies[i].smi_ack[1]);
			complete(&priv->dies[i].core_time_sync_ack);
			VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
					"vatools clear die=%d end\n", i);
		}
		// device
		/* tools device mutex */
		if (mutex_is_locked(&priv->tools_dev_mutex)) {
			mutex_unlock(&priv->tools_dev_mutex);
		}
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
				"vatools clear device end\n");
		// tools clearup end
#endif
	}
	if(!max_loop)
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "hp timeout refcnt[0x%x]\n", module_refcount(THIS_MODULE));
}

static int vastai_pci_mmio_do_reinit_rst(struct vastai_pci_info *priv, bool is_conditon)
{
	int ret = 0;
	u32 val = 0;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "re_initial reset SoC from MMIO by Drv.\n");

	val = is_conditon ? (1 << 0) : (1 << 2);

	ret = vastai_pci_mem_write(priv, 0, PCIE_WRAPPER_REINIT_RST_HOST, &val, 4);
	if (ret < 0) {
		vastai_pci_state_sync_error(priv);
		VASTAI_PCI_ERR(priv, 0, "%s [write] %#x, len=4, error:%d\n", __func__, PCIE_WRAPPER_REINIT_RST_HOST, ret);
		return ret;
	}

	return ret;
}

static void vastai_pci_remove(struct pci_dev *pdev)
{
	struct vastai_pci_info *priv = pci_get_drvdata(pdev);
	int i = 0;
	int retry_cnt = 4;

	VASTAI_PCI_FUNC_ENTERY;

	if(priv==NULL) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"priv has already be free\n");
		return;
	}

	if(parallel_load)
		while(!priv->probe_done) {
			mdelay(1000);
			retry_cnt--;
			if(retry_cnt==0)
				break;
		}

#ifdef CONFIG_VASTAI_PCI_FORCE_SINGLE_DIE
	if(pdev->devfn >=4 && (0x200 == (pdev->device & 0xf00))) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"This is force single die, ignore devfn[0x%x]\n", pdev->devfn);
		return;
	}
#endif

	if (boot_failed_debug && priv->boot_failed_flag) {
		goto ERROR_BOOT_FAIL;
	}

#ifdef CONFIG_VASTAI_TOOLS_SUITE
	if(priv->addr->p_tools_exit)
		priv->addr->p_tools_exit(priv);
#endif
	down_write(&tools_devs_rw_sem);
	list_del(&(priv->tools_dev_list));
	up_write(&tools_devs_rw_sem);

	if (priv->is_physfn && pci_num_vf(pdev) > 0) {
		if (pdev->driver->sriov_configure)
			pdev->driver->sriov_configure(pdev, 0);
	}

	if(pci_device_is_present(pdev))
		atomic_set(&(priv->pci_state), VASTAI_EXIT_STATE);
	else {
		//should remove /dev/kchar* first
		atomic_set(&(priv->pci_state), VASTAI_HOTP_STATE);
	}
	if (!priv) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s priv is NULL\n",
			       __func__);
		return;
	}

	if (priv->is_physfn)
	{
		cancel_delayed_work_sync(&priv->bmcu_timeout_work);
		del_timer_sync(&(priv->pci_timer));

#if 0
		if (pdev->devfn != 0)
			return;
#endif
	}
#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	if (priv->is_physfn) vastai_pci_link_monitor_uninit(priv);
#else
	(void)vastai_pci_link_monitor_uninit;
#endif
	if (priv->addr->p_free_ob_addr)
		priv->addr->p_free_ob_addr(priv);
#if VASTAI_HEARTBEAT_ENABLE
	if (priv->is_physfn) vastai_heartbeart_monitor_deinit(priv);
#else
	(void)vastai_heartbeart_monitor_deinit;
#endif
	if(vastai_get_board_type(priv) == SV100) {
		vastai_remove_hotplug_handle(priv);
		vastai_device_info_deinit(priv);
#ifdef CONFIG_VASTAI_RAS
		vastai_ras_deinit(priv);
#endif
	}
#ifdef CONFIG_VASTAI_LOGSYS
	vastai_logsys_remove_deinit(priv);
#endif

#ifdef CONFIG_VASTAI_AI
	if(priv->addr->p_vacc_exit)
		priv->addr->p_vacc_exit(priv);

#endif

#ifdef CONFIG_VASTAI_VIDEO
	if(priv->addr->p_video_exit)
			priv->addr->p_video_exit(priv);
#endif
	if(vastai_get_board_type(priv) == SG100) {
		if (BOOT_PF_ID == priv->priv_hw_cfg->sys_cfg.devfn && priv->is_pf) {
			logsys_deinit(priv);
			vastai_version_file_deinit(priv);
		}
	}

#if 0
	if (pdev->irq)
		free_irq(pdev->irq, pdev);

	if (msi_enabled)
		pci_disable_msi(pdev);
#endif

	vastai_pci_disable_irq(priv);
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
	pci_disable_pcie_error_reporting(pdev);
#endif

	/* vm trigger hotreset after exit when flr disable, which may cause *
	 * pcie abnormal.So not reset card to handle hotreset. *
	 * If BL0 handle hotreset future, follow codes can be deleted*/
	if (vastai_pci_reset_out && priv->is_in_vm) {
		if (!priv->flr_is_en)
			vastai_pci_reset_out = 0;
	}
	/* Not care this cmd is success or failed.
	 * Only check it when next insmod */
	if(pci_device_is_present(pdev)) {
		if (vastai_pci_reset_out && priv->is_physfn)
			vastai_device_send_reset(priv);
		/* There was originally a 5-second delay here,
		but when some servers shut down,
		clock changes may cause the delay time to be too long.
		Delay by 5 seconds to move to vastai_init.*/
	}
ERROR_BOOT_FAIL:
	vastai_pci_ioctl_deinit(priv);

	if(vastai_get_board_type(priv) == SG100) {
		va_hw_deinit(priv);
		free_ai_info(priv);
		if (BOOT_PF_ID == pdev->devfn && priv->is_pf) {
			vastai_pci_mmio_do_reinit_rst(priv, TRUE);
		}
	}

	vastai_dmabuf_deinit(priv);
#ifdef ENABLE_MEMPOOL_EX
	vastai_mempool_ex_deinit(priv);
#endif
	if(vastai_get_board_type(priv) == SV100) {
		for (i = 0; i < priv->die_num_in_fn; i++) {
			vastai_pci_deinit_smcu_log(priv, i);
			vastai_die_deinit(&(priv->dies[i]));
		}
	}
	pci_release_regions(pdev);
	pci_disable_device(pdev);

	for (i = 0; i < VASTAI_PCI_BAR_NUM; i++) {
		int flag = pci_resource_flags(pdev, i);
		if (!(flag & IORESOURCE_MEM))
			continue;
		if (priv->bar[i].vmem != NULL) {
			if(VASTAI_HOTP_STATE != atomic_read(&priv->pci_state))
				iounmap(priv->bar[i].vmem);
		}
	}

	vastai_delete_card_info_tree(priv);
	mutex_lock(&vastai_pci_info_list_lock);
	list_del(&(priv->dev_list));
	mutex_unlock(&vastai_pci_info_list_lock);

	kfree(priv);
	//VASTAI_PCI_FUNC_EXIT;
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s done!\n", __func__);
}

#if 0
static void vastai_pci_shutdown(struct pci_dev *pdev)
{
	VASTAI_PCI_FUNC_ENTERY;

	pci_disable_device(pdev);

	pci_set_power_state(pdev, pci_choose_state(pdev, PMSG_SUSPEND));
	VASTAI_PCI_FUNC_EXIT;
}
#endif

#if KERNEL_VERSION(5, 9, 0) <= LINUX_VERSION_CODE
/* 2020-08-07 18:48:15 -0700
 * Merge tag 'pci-v5.9-changes' of
 * git://git.kernel.org/pub/scm/linux/kernel/git/helgaas/pci
 */
static pci_ers_result_t
vastai_pci_io_error_detected(struct pci_dev *pdev, pci_channel_state_t state)
#else
static pci_ers_result_t
vastai_pci_io_error_detected(struct pci_dev *pdev, enum pci_channel_state state)
#endif
{
	switch (state) {
	case pci_channel_io_normal:
		dev_info(&pdev->dev, "Can recover vastai basic device\n");
		return PCI_ERS_RESULT_CAN_RECOVER;
	case pci_channel_io_frozen:
		pci_disable_device(pdev);
		dev_info(&pdev->dev, "Request reset for vastai basic device\n");
		return PCI_ERS_RESULT_NEED_RESET;
	case pci_channel_io_perm_failure:
		dev_err(&pdev->dev, "%s: pci_channel_io_perm_failure.\n",
			__func__);
		return PCI_ERS_RESULT_DISCONNECT;
	}

	/* Request a slot reset. */
	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t vastai_pci_io_slot_reset(struct pci_dev *pdev)
{
	pdev->error_state = pci_channel_io_normal;

#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	return PCI_ERS_RESULT_RECOVERED;
#endif
	pci_restore_state(pdev);
	if (pci_enable_device(pdev)) {
		printk("can't enable device\n");
		dev_info(&pdev->dev, "Cannot re-enable vastai basic "
				     "device after reset.\n");
		return PCI_ERS_RESULT_DISCONNECT;
	}
	pci_set_master(pdev);
#ifdef CONFIG_PCIEAER
#if defined(RHEL_RELEASE_VERSION) /* centos and red-hat */
#if RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(8, 1)
	//pci_aer_clear_nonfatal_status(pdev);
#else
	//pci_cleanup_aer_uncorrect_error_status(pdev);
#endif
#elif defined CONFIG_SUSE_KERNEL
        pci_aer_clear_nonfatal_status(pdev);
#else /* ubuntu and other */
#if (KERNEL_VERSION(5, 7, 0) <= LINUX_VERSION_CODE)
	pci_aer_clear_nonfatal_status(pdev);
#else
	pci_cleanup_aer_uncorrect_error_status(pdev);
#endif
#endif
#endif
	return PCI_ERS_RESULT_RECOVERED;
}

static void vastai_pci_io_resume(struct pci_dev *pdev)
{
	dev_info(&pdev->dev, "resuming vastai basic device\n");
}

static const struct pci_error_handlers vastai_pci_err_handler = {
	.error_detected = vastai_pci_io_error_detected,
	.slot_reset = vastai_pci_io_slot_reset,
	.resume = vastai_pci_io_resume,
};

static int vastai_pci_sriov_configure(struct pci_dev *pdev, int num_vfs)
{
	int err = 0;
	struct vastai_pci_info *pci_info = pci_get_drvdata(pdev);

	if (!pci_info || !pci_info->is_physfn)
		return -ENODEV;

	if (num_vfs <= 0) {
		pci_disable_sriov(pdev);
		err = vastai_pci_vf_deactivate(pci_info);
		return err;
	}

	if (num_vfs > pci_info->die_num_in_fn) {
		VASTAI_PCI_INFO(pci_info, VASTAI_DIE0,
			"Try to enable %d VFs, but %d actually\n", num_vfs, pci_info->die_num_in_fn);
		num_vfs = pci_info->die_num_in_fn;
	}

	err = pci_enable_sriov(pdev, num_vfs);
	if (err != 0) {
		VASTAI_PCI_ERR(pci_info, VASTAI_DIE0,
			"Enable %d VFs failed: %d\n", num_vfs, err);
		return err;
	}

	err = vastai_pci_vf_activate(pci_info, num_vfs);
	if (err != 0)
		return err;

	return num_vfs;
}

board_type_e  vastai_get_board_type(struct vastai_pci_info *priv)
{
	return priv->board_type;
}

u32 vastai_get_speed_cap(struct vastai_pci_info *priv)
{
	return priv->dies[0].pcie_mls;
}

u32 vastai_get_width_cap(struct vastai_pci_info *priv)
{
	return priv->dies[0].pcie_mlw;
}

u32 vastai_get_speed_sta(struct vastai_pci_info *priv)
{
	return priv->dies[0].pcie_nls[0];
}

u32 vastai_get_width_sta(struct vastai_pci_info *priv)
{
	return priv->dies[0].pcie_nlw[0];
}


struct vastai_card_info *vastai_get_card_info(struct vastai_pci_info *priv)
{
	struct fn_tree_node *tree_node = NULL;

	if(list_empty(&priv->fn_node_list))
		return NULL;
	else
		tree_node = list_first_entry(&priv->fn_node_list, struct fn_tree_node, internal_node);

	return tree_node->die_info->pkg_info->card_info;
}

struct vastai_die_info *vastai_get_die_info(struct vastai_pci_info *priv, u8 die_id_in_fn)
{
	struct fn_tree_node *tree_node = NULL;
	u8 loop_die_id = 0;

	list_for_each_entry(tree_node, &priv->fn_node_list, internal_node) {
		if(loop_die_id == die_id_in_fn)
			return tree_node->die_info;
		loop_die_id++;
	}

	return NULL;
}

struct vastai_pkg_info *vastai_get_pkg_info(struct vastai_pci_info *priv, u8 die_id_in_fn)
{
	struct vastai_die_info *die_info = vastai_get_die_info(priv, die_id_in_fn);

	if(die_info)
		return die_info->pkg_info;

	VASTAI_PCI_ERR(priv,
		       die_id_in_fn,
		       "%s no find die_info\n",
		       __FUNCTION__);
	return NULL;
}

struct vastai_pkg_info *vastai_get_peer_pkg_info(struct vastai_pkg_info *pkg_info)
{
	struct vastai_card_info *card_info = pkg_info->card_info;
	struct vastai_pkg_info *pkg_loop = NULL;

	list_for_each_entry(pkg_loop, &card_info->vastai_pkg_info_list, pkg_node) {
		if(pkg_loop != pkg_info)
			return pkg_loop;
	}

	return NULL;
}

struct vastai_pci_info *vastai_get_peer_priv(struct vastai_pci_info *priv, u8 *die_id_in_fn)
{
	struct vastai_pkg_info *pkg_info = vastai_get_pkg_info(priv, *die_id_in_fn);
	struct vastai_die_info *origin_die_info = vastai_get_die_info(priv, *die_id_in_fn);
	struct vastai_die_info *die_loop = NULL;
	struct fn_tree_node *fn_node = NULL;
	unsigned long flags;
	int find = 0;

	if(pkg_info) {
		spin_lock_irqsave(&pkg_info->die_info_list_lock, flags);
		list_for_each_entry(die_loop, &pkg_info->vastai_die_info_list, die_node) {
			if(origin_die_info!=die_loop) {
				find = 1;
				break;
			}
		}
		spin_unlock_irqrestore(&pkg_info->die_info_list_lock, flags);

		if(find) {
			spin_lock_irqsave(&die_loop->fn_info_list_lock, flags);
			list_for_each_entry(fn_node, &die_loop->vastai_fn_info_list, parent_node) {
				if(fn_node->priv == priv) {
					*die_id_in_fn = die_loop->die_id_in_card;
					spin_unlock_irqrestore(&die_loop->fn_info_list_lock, flags);
					return priv;
				} else {
					spin_unlock_irqrestore(&die_loop->fn_info_list_lock, flags);
					return fn_node->priv;
				}
			}
			spin_unlock_irqrestore(&die_loop->fn_info_list_lock, flags);
		} else
			VASTAI_PCI_DBG(priv,
				       *die_id_in_fn,
				       "%s no find die_loop\n",
				       __FUNCTION__);
	}

	return NULL;
}

bool vastai_is_super_pf(struct vastai_pci_info *priv)
{
	return priv->is_super_pf;
}

int vastai_is_slave_die(struct vastai_pci_info *priv, u8 die_id_in_fn, bool *slave_en)
{
	int rc = 0;
	struct vastai_die_info *die_info = vastai_get_die_info(priv, die_id_in_fn);

	if(die_info)
		*slave_en = (die_info->die_id_in_card)%2;
	else {
		VASTAI_PCI_ERR(priv,
			       die_id_in_fn,
			       "%s no find die_info\n",
			       __FUNCTION__);
		rc = -ENOMEM;
	}

	return rc;
}


bool is_vastai_probe_done(struct vastai_pci_info *priv)
{
	return priv->probe_done;
}

int vastai_get_transcoding_type(struct vastai_pci_info *priv, u32 *type)
{
	int ret = 0;
	int master_die_index = vastai_pci_get_die_index(priv, 0);

	if(vastai_get_board_type(priv) == SV100) {
		if (priv->is_virtfn) {
			*type = VASTAI_PCIE_NONE_TRANSCODING;
			return 0;
		}
		init_completion(&priv->tc_type_comp);
		ret = vastai_send_smcu_cmd(priv, master_die_index,
					VASTAI_SMCU_SUB_QUERY_TC_TYPE, 0);
		ret = wait_for_completion_interruptible(&priv->tc_type_comp);
		if (ret) {
			VASTAI_PCI_ERR(priv,
				       0,
				       "%s wait_for_completion error %d\n",
				       __FUNCTION__, ret);
		}

		*type = priv->tc_type;
	} else if (vastai_get_board_type(priv) == SG100)
		ret = -1;

	return ret;
}

u32 vastai_get_vdsp_cnt(struct vastai_pci_info *priv, int die_id, u32 vdsp, int dir)
{
	u32 core_idx;

	if(priv == NULL)
		return -1;
	if(vdsp > 12)
		return -1;
	if((dir != 0) && (dir != 1))
		return -1;

	if (vdsp >= 0 && vdsp < 4)
		core_idx = vdsp + CORE_POINT_VDSP0;
	else
		core_idx = vdsp - 4 + CORE_POINT_ODSP0;

	if(dir == 0)
		return priv->dies[die_id].core[core_idx].pcie_tx_core_count;
	else
		return priv->dies[die_id].core[core_idx].pcie_rx_core_count;
}
int vastai_get_share_mem_bank_num(struct vastai_pci_info *priv)
{
	return 1;
}
int vastai_get_share_mem_bank_info(struct vastai_pci_info *priv,
					int bank_idx, u64  *start, u64 *len)
{
	u64 end;
	u64 real_used_end;

	if (bank_idx != 0) {
		VASTAI_PCI_ERR(priv,
			       0,
			       "%s invalid bank index:%d\n",
			       __FUNCTION__, bank_idx);
		return -EINVAL;
	}
	vastai_pci_mem_read(priv, 0, DYN_MEM_ALLOC_L, start, sizeof(u64));
	vastai_pci_mem_read(priv, 0, DYN_MEM_ALLOC_END_L, &end, sizeof(u64));

	real_used_end = ADDR(priv, DDR_BASE_ADDR) + priv->ddr_attr;

	if ((*start > end) || (*start > real_used_end))
		return -EINVAL;
	end = (end > real_used_end) ? real_used_end : end;
	*len = end - *start;

	return 0;
}

int vastai_get_model_mem_num(struct vastai_pci_info *priv)
{
	return 1;
}
int vastai_get_model_mem_info(struct vastai_pci_info *priv,
					int model_idx, u64  *start, u64 *len)
{
	u64 mem_bound = 0;

	if (model_idx != 0) {
		VASTAI_PCI_ERR(priv,
			       0,
			       "%s invalid bank index:%d\n",
			       __FUNCTION__, model_idx);
		return -EINVAL;
	}
	vastai_pci_mem_read(priv, 0, CORE_ENTRY_SOC_BASE_L, start, sizeof(u64));
	vastai_pci_mem_read(priv, 0, DDR_DENSITY_OUTBOUND_ADDR, &mem_bound, 4);
	mem_bound *= 1024*1024;
	*len = mem_bound - DSP_HEAP_SIZE - *start;

	return 0;
}

int vastai_get_model_mem_offset		(struct vastai_pci_info *priv, int model_idx, u64 *offset)
{
	u64 start;
	u64 mem_bound = 0;
	u32 model_heap_size = 0;
	if (model_idx != 0) {
		VASTAI_PCI_ERR(priv,
			       0,
			       "%s invalid model index:%d\n",
			       __FUNCTION__, model_idx);
		return -EINVAL;
	}
	vastai_pci_mem_read(priv, 0, CORE_ENTRY_SOC_BASE_L, &start, sizeof(u64));
	vastai_pci_mem_read(priv, 0, DDR_DENSITY_OUTBOUND_ADDR, &mem_bound, 4);
	vastai_pci_mem_read(priv, 0, MODEL_INFO_AND_HEAP_TOTAL_SIZE, &model_heap_size, 4);
	mem_bound *= 1024*1024;
	*offset = start - (mem_bound - model_heap_size);

	return 0;
}

int vastai_get_model_entry_addr		(struct vastai_pci_info *priv, int model_idx,	u64  *start)
{
	u64 addr, len;
	int ret = 0;

	ret = vastai_get_model_mem_info(priv, model_idx, &addr, &len);
	if (ret)
		return ret;

	*start = 0xC0000000;

	return ret;
}

int vastai_get_odsp_op_info(struct vastai_pci_info *priv, int odsp_idx,
						u64  *start, u64 *len)
{
	u64 end;
	u32 odsp_zone_size = 16*1024*1024;
	u32 odsp_fw_size = 2*1024*1024;
	u32 odsp_op_size = odsp_zone_size - odsp_fw_size;
	u8 odsp_num = 8;

	if (odsp_idx > odsp_num) {
		VASTAI_PCI_ERR(priv,
			       0,
			       "%s invalid odsp_idx index:%d\n",
			       __FUNCTION__, odsp_idx);
		return -EINVAL;
	}
	vastai_pci_mem_read(priv, 0, CORE_ENTRY_SOC_BASE_L, &end, sizeof(u64));
	*start = end - ((odsp_num - odsp_idx)*odsp_zone_size) + odsp_fw_size;
	*len = odsp_op_size;

	return 0;
}

static const struct pci_device_id vastai_pci_ids[] = {
#ifdef CONFIG_VASTAI_SV100_ENABLE
	{ PCI_VDEVICE(VASTAI, SV100_PF_DEVICE_ID), 0 },
	{ PCI_VDEVICE(VASTAI, SV100_VF_DEVICE_ID), 0 },
	{ PCI_VDEVICE(DAOCLOUD, SV100_PF_DEVICE_ID), 0 },
	{ PCI_VDEVICE(DAOCLOUD, SV100_VF_DEVICE_ID), 0 },
#endif
#ifdef CONFIG_VASTAI_SG100_ENABLE
	{ PCI_VDEVICE(VASTAI, PF_DEVICE_ID), 0},
	{ PCI_VDEVICE(VASTAI, VF_DEVICE_ID), 0},
	{ PCI_VDEVICE(VASTAI, VF_DEVICE_ID2), 0},
	{ PCI_VDEVICE(VASTAI, GFX_PF_DEVICE_ID), 0},
	{ PCI_VDEVICE(VASTAI, AUD_PF_DEVICE_ID), 0},
#endif
#ifdef CONFIG_VASTAI_QUIRKS
	{ PCI_DEVICE(PCI_VENDOR_ID_ALIBABA, 0x0100), 0},
	{ PCI_DEVICE(PCI_VENDOR_ID_ALIBABA, PCI_ALIBABA_FPGA_DEVICE_ID), 0},
#endif
	{ /* terminate list */ }
};

static struct pci_driver vastai_pci_driver = {
	.name = VASTAI_PCI_DRIVER_PREFIX,
	.id_table = vastai_pci_ids,
	.probe = vastai_pci_probe,
	.remove = vastai_pci_remove,
	.shutdown = vastai_pci_remove,
	.sriov_configure = vastai_pci_sriov_configure,
	.err_handler = &vastai_pci_err_handler
};

extern struct class *myclass;
#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(9, 3)
static char *devnode(struct device *dev, umode_t *mode)
#else
static char *devnode(const struct device *dev, umode_t *mode)
#endif
#elif KERNEL_VERSION(6, 2, 0) > LINUX_VERSION_CODE
static char *devnode(struct device *dev, umode_t *mode)
#else
static char *devnode(const struct device *dev, umode_t *mode)
#endif
{
	struct vastai_file_info *file_info = dev_get_drvdata(dev);

	if (mode)
		*mode = VASTAI_FILE_MODE;
	return kstrdup(file_info->file_name, GFP_KERNEL);
}

extern struct vastai_pci_test_info *test_info;

static void vastai_global_macro_init(struct vastai_addr_info *vastai_global_addr_info)
{
	vastai_global_addr_info[SV100].VASTAI_SMCU_BOOT_STAGE_REG = VASTAI_SV_SMCU_BOOT_STAGE_REG;
	vastai_global_addr_info[SG100].VASTAI_SMCU_BOOT_STAGE_REG = VASTAI_SG_SMCU_BOOT_STAGE_REG;
	vastai_global_addr_info[SV100].VASTAI_HOST_BOOT_STAGE_REG = VASTAI_SV_HOST_BOOT_STAGE_REG;
	vastai_global_addr_info[SG100].VASTAI_HOST_BOOT_STAGE_REG = VASTAI_SG_HOST_BOOT_STAGE_REG;
	vastai_global_addr_info[SV100].VASTAI_BL1_DL_ADDR         = VASTAI_SV_BL1_DL_ADDR;
	vastai_global_addr_info[SG100].VASTAI_BL1_DL_ADDR         = VASTAI_SG_BL1_DL_ADDR;
	vastai_global_addr_info[SV100].BL1_PATH                   = BL1_SV_PATH;
	vastai_global_addr_info[SG100].BL1_PATH                   = BL1_SG_PATH;
	vastai_global_addr_info[SV100].BMCU_PATH                   = BMCU_SV_PATH;
	vastai_global_addr_info[SG100].BMCU_PATH                   = BMCU_SG_PATH;
	vastai_global_addr_info[SV100].FW_PATH                    = FW_SV_PATH;
	vastai_global_addr_info[SG100].FW_PATH                    = FW_SG_PATH;
	vastai_global_addr_info[SV100].DDR_BASE_ADDR              = SV_DDR_BASE_ADDR;
	vastai_global_addr_info[SG100].DDR_BASE_ADDR              = SG_DDR_BASE_ADDR;
	vastai_global_addr_info[SV100].VASTAI_FW_DL_OFFSET        = VASTAI_SV_FW_DL_OFFSET;
	vastai_global_addr_info[SG100].VASTAI_FW_DL_OFFSET        = VASTAI_SG_FW_DL_OFFSET;
	vastai_global_addr_info[SV100].VASTAI_PCIE_MSIX_NUM       = VASTAI_PCIE_MSIX_SV100_NUM;
	vastai_global_addr_info[SG100].VASTAI_PCIE_MSIX_NUM       = VASTAI_PCIE_MSIX_SG100_NUM;
	vastai_global_addr_info[SV100].VSERSION_INFO_BASE         = SV_VSERSION_INFO_BASE;
	vastai_global_addr_info[SG100].VSERSION_INFO_BASE         = SG_VSERSION_INFO_BASE;
	vastai_global_addr_info[SV100].HEARTBEAT_CNT_REG_NUM      = SV_HEARTBEAT_CNT_REG_NUM;
	vastai_global_addr_info[SG100].HEARTBEAT_CNT_REG_NUM      = SG_HEARTBEAT_CNT_REG_NUM;


	vastai_global_addr_info[SV100].INFO_LOG_ADDR      = DEFAULT_CARD_TYPE+4;
	vastai_global_addr_info[SG100].INFO_LOG_ADDR      = VASTAI_SG_HOST_BOOT_STAGE_REG;//reserved

}

static void vastai_init_addr(void)
{
	vastai_global_macro_init(vastai_global_addr_info);
	vastai_global_download_init(vastai_global_addr_info);
	vastai_global_die_init(vastai_global_addr_info);
	vastai_global_echo_cmd_init(vastai_global_addr_info);
	vastai_global_dma_init(vastai_global_addr_info);

	vastai_global_addr_info[SV100].p_trans_addr = vastai_pci_cal_absolute_addr;
	vastai_global_addr_info[SG100].p_trans_addr = vastai_pci_no_trans_addr;
	vastai_global_addr_info[SV100].p_select_bar = vastai_pci_select_bar;
	vastai_global_addr_info[SG100].p_select_bar = translate_noc_addr;
	vastai_global_addr_info[SV100].p_probe_pre_check = vastai_pci_probe_sv_pre_check;
	vastai_global_addr_info[SG100].p_probe_pre_check = vastai_pci_probe_sg_pre_check;
	vastai_global_addr_info[SV100].p_probe_entery_print = NULL;
	vastai_global_addr_info[SG100].p_probe_entery_print = vastai_probe_entery_print;
	vastai_global_addr_info[SV100].p_probe_init_mem = vastai_sv_probe_init_mem;
	vastai_global_addr_info[SG100].p_probe_init_mem = vastai_sg_probe_init_mem;
	vastai_global_addr_info[SV100].boot_process = boot_process;
	vastai_global_addr_info[SG100].boot_process = boot_process_sg;
	vastai_global_addr_info[SV100].boot_size    = sizeof(boot_process) / sizeof(boot_process[0]);
	vastai_global_addr_info[SG100].boot_size    = sizeof(boot_process_sg) / sizeof(boot_process_sg[0]);
	vastai_global_addr_info[SV100].p_alloc_ob_addr = vastai_pci_alloc_ob_addr;
	vastai_global_addr_info[SG100].p_alloc_ob_addr = NULL;
	vastai_global_addr_info[SV100].p_excetion_init = vastai_exception_init;
	vastai_global_addr_info[SG100].p_excetion_init = vastai_exception_init_sg;
	vastai_global_addr_info[SV100].p_set_payload_work = NULL;
	vastai_global_addr_info[SG100].p_set_payload_work = vastai_set_payload_work;
	vastai_global_addr_info[SV100].p_cancel_payload_work = NULL;
	vastai_global_addr_info[SG100].p_cancel_payload_work = vastai_cancel_payload_work;
	vastai_global_addr_info[SV100].p_free_ob_addr = vastai_pci_free_ob_addr;
	vastai_global_addr_info[SG100].p_free_ob_addr = NULL;

	vastai_global_addr_info[SV100].p_vacc_init = vacc_init;
	vastai_global_addr_info[SG100].p_vacc_init = NULL;

	vastai_global_addr_info[SV100].p_vacc_exit = vacc_exit;
	vastai_global_addr_info[SG100].p_vacc_exit = NULL;

	vastai_global_addr_info[SV100].p_video_init = vastai_video_init;
	vastai_global_addr_info[SG100].p_video_init = NULL;

	vastai_global_addr_info[SV100].p_video_exit = vastai_render_file_deinit;
	vastai_global_addr_info[SG100].p_video_exit = NULL;

	vastai_global_addr_info[SV100].p_tools_init = tools_init;
	vastai_global_addr_info[SG100].p_tools_init = NULL;

	vastai_global_addr_info[SV100].p_tools_exit = tools_exit;
	vastai_global_addr_info[SG100].p_tools_exit = NULL;
}

static bool vastai_is_all_mix_card(void)
{
    struct pci_dev *dev = NULL;
	u16 subsystem_id;

	const struct pci_device_id vastai_mix_ids[] = {
		{ PCI_VDEVICE(VASTAI, SV100_PF_DEVICE_ID), 0},
		{ /* terminate list */ }
	};

    while ((dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, dev)) != NULL) {
        if (pci_match_id(vastai_mix_ids, dev)) {
			pci_read_config_word(dev, PCI_SUBSYSTEM_ID, &subsystem_id);
			if ((subsystem_id != VASTAI_CARD_VA16) && (subsystem_id != VASTAI_CARD_VAM))
				return false;
        }
    }

    return true;
}

static int vastai_pre_chk_dev_nr(void)
{
    struct pci_dev *dev = NULL;
	int dev_nr = 0;

    while ((dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, dev)) != NULL) {
        if (pci_match_id(vastai_pci_ids, dev)) {
			dev_nr++;
        }
    }

    return dev_nr;
}

static int vastai_get_list_node_cnt(struct list_head *head)
{
	int count = 0;
	struct list_head *pos;

	list_for_each(pos, head) {
		count++;
	}
	return count;
}

static int vastai_get_dev_probed_cnt(void)
{
	int count = 0;
	down_read(&tools_devs_rw_sem);
	count = vastai_get_list_node_cnt(&vastai_tools_devs_list);
	up_read(&tools_devs_rw_sem);

	return count;
}
static int __init vastai_init(void)
{
	int rc = 0;
	if ((parallel_load == 0) && vastai_is_all_mix_card()) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "detect mix card, use parallel load\n");
		parallel_load = 1;
	}
	bar_addr_info = kzalloc(sizeof(struct die_bar_info) * VASTAI_MAX_DIE_NUM_IN_HOST,
			GFP_KERNEL);
	if (!bar_addr_info)
		return -ENOMEM;

	dmi_info_init();
	vastai_init_addr();
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s\n",
			VASTAI_PCI_DRIVER_COPYRIGHT);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[driver ver]: %s\n",
			VASTAI_PCI_DRIVER_VERSION);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[branchinfo]: %s\n",
			VASTAI_PCI_GIT_BRANCH_NAME);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[commithash]: %s\n",
			VASTAI_PCI_GIT_COMMIT_HASH);
	// VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
	// 		"[commit msg]: %s\n", VASTAI_PCI_GIT_COMMIT_MSG);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[pack  time]: %s\n",
			VASTAI_PCI_MKPACKAGE_TIME);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[build time]: %s %s\n", __DATE__,
			__TIME__);

	VASTAI_PCI_FUNC_ENTERY;
#if KERNEL_VERSION(6,4,0) > LINUX_VERSION_CODE
		myclass = class_create(THIS_MODULE, "char_class");
#else
		myclass = class_create("char_class");
#endif
	myclass->devnode = devnode;

	INIT_LIST_HEAD(&vastai_pci_info_list);
	INIT_LIST_HEAD(&vastai_card_info_list);
	mutex_init(&vastai_pci_info_list_lock);
	mutex_init(&vastai_service_module_lock);
	mutex_init(&vastai_card_info_list_lock);
	mutex_init(&vastai_print_fw_logs_lock);
	INIT_LIST_HEAD(&vastai_minor_list);
	INIT_LIST_HEAD(&vastai_tools_devs_list);
	init_rwsem(&tools_devs_rw_sem);
	ssleep(VASTAI_WAITING_RESET);
	rc=vastai_dev_node_init();
	if(rc)
		return rc;

	rc = pci_register_driver(&vastai_pci_driver);
	if (rc)
		return rc;
	if (parallel_load) {
		int chk_nr = 0;
		int dev_nr = vastai_pre_chk_dev_nr();
		while (vastai_get_dev_probed_cnt() != dev_nr) {
			if (chk_nr++ == 600) {
				VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
					"some card may boot failed! need:%d, real:%d\n",
						dev_nr, vastai_get_dev_probed_cnt());
				break;
			}
			msleep(100);
		}
	}
	//VASTAI_PCI_FUNC_EXIT;
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s done!\n", __func__);

	return 0;
}

static void tools_real_deinit(void)
{
	if (atomic_read(&tools_online_flag) == 1) {
		vatools_driver_exit(NULL);
		atomic_set(&tools_online_flag, 0);
	}
}

extern struct core_info_entry *cores_info;
static void __exit vastai_exit(void)
{
	struct vastai_pci_info *pci_info = NULL;
	VASTAI_PCI_FUNC_ENTERY;

	mutex_lock(&vastai_pci_info_list_lock);
	if (!list_empty(&vastai_pci_info_list)) {
		/* for now, we only get first entry */
		list_for_each_entry(pci_info, &vastai_pci_info_list, dev_list) {
			atomic_set(&(pci_info->pci_state), VASTAI_EXIT_STATE);
		}
	}
	mutex_unlock(&vastai_pci_info_list_lock);

	drv_rm_flag = true;
	pci_unregister_driver(&vastai_pci_driver);
	if(cores_info)
		kfree(cores_info);
	vastai_dev_node_deinit();
	class_destroy(myclass);
	tools_real_deinit();
	//VASTAI_PCI_FUNC_EXIT;
	kfree(bar_addr_info);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s done!\n", __func__);
}

#ifndef CONFIG_VASTAI_KUNIT
module_init(vastai_init);
module_exit(vastai_exit);

MODULE_LICENSE("GPL");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 4, 0)
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
#endif
MODULE_AUTHOR("Gang Wang <gang.wang@vastaitech.com>");
MODULE_DEVICE_TABLE(pci, vastai_pci_ids);
#endif
