#include <linux/aer.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/version.h>
#include <linux/rtc.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include "vastai_pci.h"
#include "vastai_pci_api.h"
#include "vastai_dmabuf.h"
#include "vastai_dmi_table.h"
#include "vastai_fifo.h"
#include "vastai_die.h"
#include "vastai_avfs.h"
#include "vastai_state.h"
#include "vatools.h"

char* state_name(int state)
{
	switch(state)
	{
		case    VASTAI_NO_RUN_STATE   : return "NO_RUN_STATE";
		case	VASTAI_NORMAL_STATE   : return "NORMAL_STATE";
		case	VASTAI_UPDATE_STATE   : return "UPDATE_STATE";
		case	VASTAI_BOOT_STATE     : return "BOOT_STATE";
		case	VASTAI_EXIT_STATE     : return "EXIT_STATE";
		case	VASTAI_ERROR_STATE    : return "ERROR_STATE";
		case	VASTAI_RESET_STATE    : return "RESET_STATE";
		case	VASTAI_DEBUG_STATE    : return "DEBUG_STATE";
		default: break;
	}

	return "unknown state.";
}

int vastai_pci_state_boot_start(struct vastai_pci_info* priv) {
	int ret = VASTAI_STATE_TRANSIT_SUCCESS;
	int old;
	old = atomic_cmpxchg(&priv->pci_state, VASTAI_NO_RUN_STATE,
						 VASTAI_BOOT_STATE);
	if (old != VASTAI_NO_RUN_STATE) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s: boot device must from NO_RUN_STATE. %d\n",
			__FUNCTION__, old);
		ret = -EIO;
	}
	return ret;
}

void vastai_pci_state_boot_done(struct vastai_pci_info* priv) {
	atomic_set(&(priv->pci_state), VASTAI_NORMAL_STATE);
}

void vastai_pci_state_reset_start(struct vastai_pci_info* priv) {
	atomic_set(&priv->pci_state, VASTAI_RESET_STATE);
}

void vastai_pci_state_reset_done(struct vastai_pci_info* priv) {
	atomic_set(&priv->pci_state, VASTAI_NO_RUN_STATE);
}

int vastai_pci_state_update_start(struct vastai_pci_info* priv, int die_id) {
	int ret = VASTAI_STATE_TRANSIT_SUCCESS;
	int old;
	old = atomic_cmpxchg(&priv->pci_state, VASTAI_NORMAL_STATE,
						 VASTAI_UPDATE_STATE);
	if (old != VASTAI_NORMAL_STATE) {
		VASTAI_PCI_ERR(priv, die_id, "%s: Can NOT update bmcu when "
					   "smcu is error %d\n", __FUNCTION__, ret);
		ret = -EBUSY;
	}
	return ret;
}

void vastai_pci_state_update_done(struct vastai_pci_info* priv, int die_id) {
	u32 old;
	old = atomic_cmpxchg(&(priv->pci_state), VASTAI_UPDATE_STATE,
						 VASTAI_NORMAL_STATE);
	if (old != VASTAI_UPDATE_STATE) {
		VASTAI_PCI_INFO(priv, die_id, "pcie state error: %d: update bmcu "
						"completion back, but state is not update state\n", old);
	}
}

void vastai_pci_state_power_off(struct vastai_pci_info* priv) {
	atomic_set(&priv->pci_state, VASTAI_EXIT_STATE);
}

void vastai_pci_state_sync_error(struct vastai_pci_info* priv) {
	atomic_set(&(priv->pci_state), VASTAI_ERROR_STATE);
}

void vastai_pci_state_debug(struct vastai_pci_info* priv) {
	atomic_set(&priv->pci_state, VASTAI_DEBUG_STATE);
}

inline int vastai_get_pci_state(struct vastai_pci_info* priv) {
	return atomic_read(&(priv->pci_state));
}
int vastai_pci_state_change(struct vastai_pci_info* priv, u8 cur_state, u8 next_state) {
	int ret = VASTAI_STATE_TRANSIT_SUCCESS;
	int old;
	old = atomic_cmpxchg(&priv->pci_state, cur_state, next_state);
	if (old != cur_state) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"device state is %s, but not %s, can't change to %s\n",
			state_name(old), state_name(cur_state), state_name(next_state));
		ret = -EIO;
	}
	return ret;
}
