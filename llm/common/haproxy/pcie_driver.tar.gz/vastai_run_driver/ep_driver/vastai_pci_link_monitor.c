#include <linux/aer.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/version.h>
#include <linux/rtc.h>
#include <linux/timer.h>
//#include <linux/fs.h>
//#include <linux/uaccess.h>

#include "vastai_pci.h"
#ifdef CONFIG_VASTAI_PCI_BOOT
#include "vastai_pci_boot.h"
#endif
#include "vastai_state.h"

#define RETRY_RESET_TIME 6
#define HEARTBEAT_CKECK_TIME_MS 2000

char* reset_type_name(u32 reset_type)
{
	switch(reset_type)
	{
		case    0   : return "warm reset";
		case	1   : return "hot reset";
		case	3   : return "reinitail reset";
		default: break;
	}

	return "unknown reset type.";
}

static void vatsai_pci_clear_aer_error(struct vastai_pci_info *priv, bool is_rc)
{
#ifdef CONFIG_PCIEAER
	int pos;
	u32 status;
	struct pci_dev *dev;

	if (is_rc)
		dev = priv->dev->bus->self;
	else
		dev = priv->dev;

	if (!dev)
		return;
	pos = dev->aer_cap;
	if (!pos)
		return;

	pci_read_config_dword(dev, pos + PCI_ERR_UNCOR_STATUS, &status);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
		       "%s PCI_ERR_UNCOR_STATUS =%x\n", is_rc?"RC":"EP", status);
	if (status)
		pci_write_config_dword(dev, pos + PCI_ERR_UNCOR_STATUS, status);
#endif
	return;
}
static void vatsai_pci_clear_rc_aer_error(struct vastai_pci_info *priv)
{
	vatsai_pci_clear_aer_error(priv, true);
}
static void vatsai_pci_clear_ep_aer_error(struct vastai_pci_info *priv)
{
	vatsai_pci_clear_aer_error(priv, false);
}
u32 vatsai_pci_reset_type(struct vastai_pci_info *priv)
{
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	u32 reg_val = 0;
	u32 reset_type;

	vastai_pci_mem_read_direct(priv, VASTAI_DIE0, reg_addr, &reg_val, 4);
	if (reg_val != 0xffffffff)
		reset_type = (reg_val >> 22) & 3;
	else
		reset_type = reg_val;
	return reset_type;
}
static u32 vatsai_pci_get_die_stage_reg(struct vastai_pci_info *priv, u32 die_id)
{
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	u32 reg_val = 0;

	vastai_pci_mem_read_direct(priv, die_id, reg_addr, &reg_val, 4);

	return reg_val;
}

static u32 vatsai_pci_get_die_stage(struct vastai_pci_info *priv, u32 die_id)
{
	return ((vatsai_pci_get_die_stage_reg(priv, die_id) >> 24) & 7);
}

void vastai_pci_reset_work(struct work_struct *work)
{
	int ret;
	u32 reset_type;
	int retry_times = RETRY_RESET_TIME;
	struct pci_link_monitor *pci_link = container_of(work, struct pci_link_monitor, work);
	struct vastai_pci_info *priv =
				container_of(pci_link, struct vastai_pci_info, pci_link_stat);
	struct pci_dev *pdev = priv->dev;
	int die_id = 0;

	ret = vastai_pci_state_change(priv, VASTAI_NORMAL_STATE, VASTAI_RESET_STATE);
	if (ret)
		return;

	vastai_remove_hotplug_handle(priv);
RETRY:
	atomic_set(&(priv->pci_link_stat.is_reseting), 1);
	priv->pci_link_stat.pid = current->pid;
	ret = vastai_pci_reset_bus(priv);
	if (ret)
		goto END;
	ret = vastai_pci_state_change(priv, VASTAI_RESET_STATE, VASTAI_NO_RUN_STATE);
	if (ret)
		goto END;
	msleep(100);
	reset_type = vatsai_pci_reset_type(priv);
	if (reset_type == 0xffffffff) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device reset error, need power cycle!\n");
		return;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"boot_stage_reg:0x%x,reset_type:%s\n",
			vatsai_pci_get_die_stage_reg(priv, VASTAI_DIE0), reset_type_name(reset_type));
	if(reset_type != 1)
		priv->not_hotreset = 1;
	else
		priv->not_hotreset = 0;

	ret = vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);
	if (ret) {
		if (vatsai_pci_get_die_stage(priv, VASTAI_DIE0) != VASTAI_SMCU_BOOT_STAGE_BOOT_DONE && !priv->not_hotreset) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device boot error, need power cycle!\n");
			goto FAILED;
		}
		if (!retry_times--) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "exceed max reset times, need power cycle!\n");
			goto FAILED;
		}
		vastai_pci_state_reset_start(priv);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "retry reset, current is %d times.\n", RETRY_RESET_TIME - retry_times);
		goto RETRY;
	}
	if (reset_type == 3 || priv->not_hotreset) {
		vastai_pci_state_reset_start(priv);
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"this reset type is %s, need hot reset again\n", reset_type_name(reset_type));
		goto RETRY;
	}
	if (pci_enable_device(pdev)) {
		printk("can't enable device\n");
		dev_info(&pdev->dev, "Cannot re-enable vastai basic "
				     "device after reset.\n");
	}
	pci_set_master(pdev);
	vatsai_pci_clear_ep_aer_error(priv);
	vatsai_pci_clear_rc_aer_error(priv);
	priv->pci_link_stat.cnt = 0xffffffff;
	for(die_id=0; die_id<VASTAI_SV100_MAX_DIE_NUM; die_id++)
		priv->dies[die_id].pci_link_stat.cnt = 0xffffffff;
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "device reset ok\n");
END:
	atomic_set(&(priv->pci_link_stat.is_reseting), 0);
	priv->pci_link_stat.pid = 0;
	return;
FAILED:
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"die0 stage val:%x\n", vatsai_pci_get_die_stage_reg(priv, VASTAI_DIE0));
	priv->pci_link_stat.reset_count--;
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device reset failed\n");
	return;
}

void vastai_pci_reinit_reset_work(struct work_struct *work)
{
	int ret;
	u32 reset_type;
	struct pci_link_monitor *pci_link = container_of(work, struct pci_link_monitor, work);
	struct vastai_pci_info *priv =
				container_of(pci_link, struct vastai_pci_info, pci_link_stat);

	ret = vastai_pci_state_change(priv, VASTAI_NORMAL_STATE, VASTAI_RESET_STATE);
	if (ret)
		return;

	vastai_remove_hotplug_handle(priv);

	atomic_set(&(priv->pci_link_stat.is_reseting), 1);
	priv->pci_link_stat.pid = current->pid;

	msleep(VASTAI_WAITING_RESET);

	ret = vastai_pci_state_change(priv, VASTAI_RESET_STATE, VASTAI_NO_RUN_STATE);
	if (ret)
		goto END;
	msleep(100);
	reset_type = vatsai_pci_reset_type(priv);
	if (reset_type == 0xffffffff) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device reset error, need power cycle!\n");
		return;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"boot_stage_reg:0x%x,reset_type:%s\n",
			vatsai_pci_get_die_stage_reg(priv, VASTAI_DIE0), reset_type_name(reset_type));

	ret = vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);
	if (ret) {
		if (vatsai_pci_get_die_stage(priv, VASTAI_DIE0) != VASTAI_SMCU_BOOT_STAGE_BOOT_DONE) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device boot error, need power cycle!\n");
			goto FAILED;
		}
	}
	priv->pci_link_stat.cnt = 0xffffffff;
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "device reset ok\n");
END:
	atomic_set(&(priv->pci_link_stat.is_reseting), 0);
	priv->pci_link_stat.pid = 0;
	return;
FAILED:
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"die0 stage val:%x\n", vatsai_pci_get_die_stage_reg(priv, VASTAI_DIE0));
	priv->pci_link_stat.reset_count--;
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "device reset failed\n");
	return;
}

static u32 get_cur_hb(struct vastai_pci_info *priv, u32 die_id)
{
	struct vastai_outbound *pOb =
		(struct vastai_outbound *)priv->dies[die_id].pci_link_stat.dma_vir;
	return  pOb->hb_cnt;
}

static void update_cur_hb(struct vastai_pci_info *priv, u32 die_id, u32 hb_cnt)
{
	struct vastai_outbound *pOb =
		(struct vastai_outbound *)priv->dies[die_id].pci_link_stat.dma_vir;

	pOb->hb_cnt = hb_cnt;

	return;
}
static u32 get_saved_hb(struct vastai_pci_info *priv, u32 die_id)
{
	return  priv->dies[die_id].pci_link_stat.cnt;
}

static void update_saved_hb(struct vastai_pci_info *priv, u32 die_id, u32 hb_cnt)
{
	priv->dies[die_id].pci_link_stat.cnt = hb_cnt;
}

static void pci_link_monitor_proc(struct vastai_pci_info *priv, u32 die_id, u32 hb_cnt)
{
	if (die_id == 1) {
		VASTAI_PCI_INFO(priv, die_id,
				"heartbeat busy hb_cnt[0x%x]\n", hb_cnt);
		return;
	}

	if (priv->pci_link_stat.bypass) {
		VASTAI_PCI_ERR(priv, die_id,
				"heartbeat check error, stop device access\n");
		vastai_pci_state_sync_error(priv);
		return;
	}

	if (priv->pci_link_stat.reset_count == 0) {
		VASTAI_PCI_INFO(priv, die_id,
				"beyond max reset count\n");
		return;
	}

	VASTAI_PCI_INFO(priv, die_id, "trigger reset \n");
	queue_work(priv->pci_link_stat.wq, &priv->pci_link_stat.work);

	return;
}
static void vastai_pci_link_monitor_timer(struct timer_list *timer)
{
	struct pci_link_monitor *pci_link = from_timer(pci_link, timer, timer);
	struct vastai_pci_info *priv = container_of(pci_link, struct vastai_pci_info, pci_link_stat);
	int die_id = 0;
	u32 hb_cnt;

	timer->expires = jiffies + msecs_to_jiffies(HEARTBEAT_CKECK_TIME_MS);

	if (atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE)
		return;

	for(die_id=0; die_id<priv->die_num_in_fn; die_id++) {
		hb_cnt = get_cur_hb(priv, die_id);
		if (get_saved_hb(priv, die_id) == hb_cnt) {
			pci_link_monitor_proc(priv, die_id, hb_cnt);
		} else {
			update_saved_hb(priv, die_id, hb_cnt);
		}
	}
	/* trigger timer */
	add_timer(timer);
	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID,
			"heartbeat:%d\n", hb_cnt);
}
static void vastai_enable_aer_surpdn_abort(struct vastai_pci_info *pci_info, bool enable)
{
	u32 err_sev;
	int pos;
	struct pci_dev *pdev = pci_info->dev->bus->self;

	if (!pdev)
		return;

	pos = pci_find_ext_capability(pdev, PCI_EXT_CAP_ID_ERR);
	if (!pos)
		return;

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, &err_sev);
	if (enable)
		err_sev &= ~PCI_ERR_UNC_SURPDN;
	else
		err_sev |= PCI_ERR_UNC_SURPDN;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, err_sev);

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, &err_sev);
	if (!enable)
		err_sev &= ~PCI_ERR_UNC_SURPDN;
	else
		err_sev |= PCI_ERR_UNC_SURPDN;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, err_sev);

}

static void vastai_enable_aer_comp_time(struct vastai_pci_info *pci_info, bool enable)
{
	u32 err_sev;
	int pos;
	struct pci_dev *pdev = pci_info->dev->bus->self;

	if (!pdev)
		return;

	pos = pci_find_ext_capability(pdev, PCI_EXT_CAP_ID_ERR);
	if (!pos)
		return;

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, &err_sev);
	if (enable)
		err_sev &= ~PCI_ERR_UNC_COMP_TIME;
	else
		err_sev |= PCI_ERR_UNC_COMP_TIME;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, err_sev);

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, &err_sev);
	if (!enable)
		err_sev &= ~PCI_ERR_UNC_COMP_TIME;
	else
		err_sev |= PCI_ERR_UNC_COMP_TIME;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, err_sev);
}
static void vastai_enable_aer_malf_tlp(struct vastai_pci_info *pci_info, bool enable)
{
	u32 err_sev;
	int pos;
	struct pci_dev *pdev = pci_info->dev->bus->self;

	if (!pdev)
		return;

	pos = pci_find_ext_capability(pdev, PCI_EXT_CAP_ID_ERR);
	if (!pos)
		return;

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, &err_sev);
	if (enable)
		err_sev &= ~PCI_ERR_UNC_MALF_TLP;
	else
		err_sev |= PCI_ERR_UNC_MALF_TLP;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_MASK, err_sev);

	pci_read_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, &err_sev);
	if (!enable)
		err_sev &= ~PCI_ERR_UNC_MALF_TLP;
	else
		err_sev |= PCI_ERR_UNC_MALF_TLP;
	pci_write_config_dword(pdev, pos + PCI_ERR_UNCOR_SEVER, err_sev);
}

static void vastai_enable_hb(struct vastai_pci_info *pci_info, u32 die_id)
{
	int ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[die_id].die_index,
					VASTAI_PCIE_SUB_ENABLE_HB,
					pci_info->pci_link_stat.dma_bus_addr);
	if (ret)
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			"%s,vastai_send_pcie_cmd error:%d\n", __FUNCTION__, ret);
	return;

}
static void vastai_disable_hb(struct vastai_pci_info *pci_info, u32 die_id)
{
	int ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[die_id].die_index,
					VASTAI_PCIE_SUB_DISABLE_HB, 0);
	if (ret)
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			"%s,vastai_send_pcie_cmd error:%d\n", __FUNCTION__, ret);

	return;

}
void vastai_enable_pcie_link_monitor(struct vastai_pci_info *pci_info, bool enable)
{
	int die_id = 0;

	if(pci_info->pci_link_stat.bypass)
		return;

	if (enable) {
		pci_info->pci_link_stat.cnt = 0xffffffff;
		for(die_id = 0; die_id < VASTAI_SV100_MAX_DIE_NUM; die_id++) {
			update_cur_hb(pci_info, die_id, 0);
			update_saved_hb(pci_info, die_id, 0xffffffff);
		}
		for(die_id = 0; die_id < pci_info->die_num_in_fn; die_id++) {
			vastai_enable_hb(pci_info, die_id);
		}
		vastai_pci_link_monitor_timer(&(pci_info->pci_link_stat.timer));
	}
	else {
		del_timer_sync(&(pci_info->pci_link_stat.timer));
	}
}

void vastai_pci_link_monitor_init(struct vastai_pci_info *pci_info)
{
	int die_id = 0;

	for(die_id = 0; die_id < pci_info->die_num_in_fn; die_id++) {
		vastai_enable_hb(pci_info, die_id);
		update_saved_hb(pci_info, die_id, 0xffffffff);
	}

	timer_setup(&(pci_info->pci_link_stat.timer), vastai_pci_link_monitor_timer, 0);
	vastai_pci_link_monitor_timer(&(pci_info->pci_link_stat.timer));

	pci_info->pci_link_stat.bypass = false;
	vastai_enable_aer_surpdn_abort(pci_info, false);
	vastai_enable_aer_comp_time(pci_info, false);
	vastai_enable_aer_malf_tlp(pci_info, false);
	pci_info->pci_link_stat.reset_count = 1;
	pci_info->pci_link_stat.wq = alloc_workqueue("vastai_hb_wq",
			WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (pci_info->is_in_vm)
		INIT_WORK(&pci_info->pci_link_stat.work, vastai_pci_reinit_reset_work);
	else
		INIT_WORK(&pci_info->pci_link_stat.work, vastai_pci_reset_work);

	atomic_set(&(pci_info->pci_link_stat.is_reseting), 0);
	memcpy(pci_info->pci_link_stat.saved_config_space, pci_info->dev->saved_config_space,
		sizeof(pci_info->pci_link_stat.saved_config_space));
}
void vastai_pci_link_monitor_uninit(struct vastai_pci_info *pci_info)
{
	int die_id;

	for(die_id = 0; die_id < pci_info->die_num_in_fn; die_id++) {
		vastai_disable_hb(pci_info, die_id);
	}
	del_timer_sync(&(pci_info->pci_link_stat.timer));

	if (pci_info->pci_link_stat.bypass)
		return;

	vastai_enable_aer_surpdn_abort(pci_info, true);
	vastai_enable_aer_comp_time(pci_info, true);
	vastai_enable_aer_malf_tlp(pci_info, true);

	flush_work(&pci_info->pci_link_stat.work);
	destroy_workqueue(pci_info->pci_link_stat.wq);
}
