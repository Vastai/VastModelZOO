#include <linux/delay.h>
#include "vastai_avfs.h"
#include "vastai_pci.h"
#define CSRAM_AVFS (CSRAM_BASE_ADDR + 0x000F3360)
#define CSRAM_AVFS_LEN (24)

static void avfg_read_die_avfs(struct vastai_pci_info *pci_info, int die_index,
			void *buf, size_t size)
{
	int ret;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);

	if (size < CSRAM_AVFS_LEN) 
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed, buf too less.\n",
				__FUNCTION__);

	ret = vastai_pci_mem_read_direct(pci_info, die_index, CSRAM_AVFS, buf,
				CSRAM_AVFS_LEN);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed %d.\n",
				__FUNCTION__, ret);
		memset(buf, 0, size);
	}
}

/* TODO: pls move to a independent file with other cmd */
int vastai_send_smcu_cmd(struct vastai_pci_info *pci_info, int die_index,
				u32 sub_cmd, u64 paras)
{
	struct pcie_transfer_info trans = {
		.type = VASTAI_SMCU_CMD,
		.pcie_config_addr = sub_cmd,
		.data_struct_addr = paras,
	};
	int ret = 0;
	u32 die_id = vastai_pci_get_die_id(pci_info, die_index);

	u32 msgq_id = vastai_get_msgq_id(pci_info, MSGQ_CMD);
	ret = vastai_pci_vmsgq_wr_spe(&(pci_info->dies[die_id].vmsgq[msgq_id]),
				 &trans, sizeof(trans));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_index, "%s sub_cmd[%d] error, ret=%d",
			       __func__, sub_cmd, ret);
		return -EINVAL;
	}

	return 0;

}

/* write die1's avfs to die0's csram.
 * "Where to write die2/die3's avfs config? pls ask yu.zhang
 */
static int avfg_write_die_avfs(struct vastai_pci_info *pci_info, int die_index,
			void *buf, size_t size)
{
	int ret;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);


	ret = vastai_pci_mem_write_direct(pci_info, die_index, CSRAM_AVFS,
				buf, size);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s write avfs cfg failed %d.\n",
				__FUNCTION__, ret);
		return ret;
	}

	return ret;
}

int avfg_set_die_avfs(struct vastai_pci_info *pci_info,unsigned char die_m)
{
	char buf[CSRAM_AVFS_LEN];
	int die_index = vastai_pci_get_die_index(pci_info, die_m+1);
	int ret;
	int master_die_index = vastai_pci_get_die_index(pci_info, die_m);

	avfg_read_die_avfs(pci_info, die_index, buf, sizeof(buf));
	ret = avfg_write_die_avfs(pci_info, master_die_index, buf, sizeof(buf));
	if (ret)
		return ret;

	ret = vastai_send_smcu_cmd(pci_info, master_die_index,
			VASTAI_SMCU_SUB_SET_AVFS, 0);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, 0, "%s send avfs cmd failed %d.\n",
				__FUNCTION__, ret);
		return ret;
	}
	msleep(10);
	return 0;
}
