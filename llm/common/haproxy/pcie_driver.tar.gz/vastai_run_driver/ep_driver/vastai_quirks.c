#include <linux/pci.h>
#include <linux/delay.h>
#include "vastai_pci.h"
#include "vastai_dmabuf.h"

#define limit_len 8*1024*1024
#define limit_start 0x10000000
#define limit_end (limit_start + limit_len)
#define FPGA_STATUS_CHECK
int vastai_qurik_fpga_link_status (struct vastai_pci_info *priv)
{
	struct pci_dev *pdev;
	int bar_index;
	resource_size_t mmio_start;
	resource_size_t mmio_len;
	volatile unsigned char *mem_bar;
#ifdef FPGA_STATUS_CHECK
	int max_retry_times = 100;
#endif

	pdev = pci_get_slot(priv->dev->bus, 0);

	if (pci_enable_device(pdev) < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"enable device:%s failed\n", pci_name(pdev));
		return -EIO;;
	}

	bar_index = 0;
	mmio_start = pci_resource_start(pdev, bar_index);
	mmio_len = pci_resource_len(pdev, bar_index);
	mem_bar = ioremap(mmio_start, mmio_len);
	if (mem_bar == NULL) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s:cannot remap bar%d mmio, aborting\n",
		pci_name(pdev), bar_index);
		return -EIO;
	}
#ifdef FPGA_STATUS_CHECK
	while(readl(mem_bar + 0x401000) != 1) {
		msleep(100);
		if (max_retry_times-- == 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
                               "check fpga link timeout\n");
			iounmap(mem_bar);
			return -1;
		}
	}
	while(readl(mem_bar + 0x190000) != 1) {
		msleep(100);
		if (max_retry_times-- == 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
                               "check fpga enumerate timeout\n");
			iounmap(mem_bar);
			return -1;
		}
	}
#endif
	return 0;
}
int vastai_qurik_init(struct vastai_pci_info *priv)
{
	int i;
	u32 reg_val;
	u8 entry_index = 0;
	u64 memBaseAddr = 0;
	u64 memBaseSize = 0;
	struct pci_dev *pdev;
	resource_size_t mmio_start;
	resource_size_t mmio_len;
	int bar_index;
	volatile unsigned char *mem_bar = (void *)priv->bar[VASTAI_PCI_BAR4].vmem;
	volatile unsigned char *mem_bar4 = (void *)priv->bar[VASTAI_PCI_BAR4].vmem;
#ifdef FPGA_STATUS_CHECK
	int max_retry_times = 100;
#endif

	if (priv->dev->vendor != PCI_VENDOR_ID_ALIBABA)
		return 0;
	if (priv->dev->devfn == 0) //hengyang fpga has 4 PF
		return 0;
	if (vastai_qurik_fpga_link_status(priv))
		return -1;

	priv->ai_video_workqueue_enable = true;
	/* read msi-x */
	reg_val = readl(mem_bar + 0x50000);
	mem_bar = (void *)priv->bar[VASTAI_PCI_BAR0].vmem;
	/* check fpga link status*/
#ifdef FPGA_STATUS_CHECK
	do {
		writel(reg_val , mem_bar + 0x4FF800);
		if (reg_val == readl(mem_bar + 0x4FF800))
			break;
		msleep(100);
		if (max_retry_times-- == 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					"check fpga link timeout\n");
			return -1;
		}
	} while (1);
#endif
	/* write msi-x */
	for(i = 0; i < 32; i++) {
		reg_val = readl(mem_bar4 + 0x50000 + i*0x10);
		writel(reg_val, mem_bar + 0x4FF800 + i*0x10);
		reg_val = readl(mem_bar4 + 0x50000 + i*0x10 + 0x4);
		writel(reg_val, mem_bar + 0x4FF800 + i*0x10 + 0x4);
		reg_val = readl(mem_bar4 + 0x50000 + i*0x10 + 0x8);
		writel(reg_val, mem_bar + 0x4FF800 + i*0x10 + 0x8);
		reg_val = readl(mem_bar4 + 0x50000 + i*0x10 + 0xC);
		writel(reg_val, mem_bar + 0x4FF800 + i*0x10 + 0xC);
	}
	/* config cpm addr windows */
	pdev = pci_get_slot(priv->dev->bus, 0);
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"PFO name:%s\n", pci_name(pdev));
	if (pci_enable_device(pdev) < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "enable device:%s failed\n", pci_name(pdev));
		return -EIO;;
	}

	bar_index = 2;
	mmio_start = pci_resource_start(pdev, bar_index);
	mmio_len = pci_resource_len(pdev, bar_index);
	mem_bar = ioremap(mmio_start, mmio_len);
	if (mem_bar == NULL) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s:cannot remap bar%d mmio, aborting\n",
			       pci_name(pdev), bar_index);
		return -EIO;
	}

	entry_index = 0;
	memBaseAddr = 0xF0000000;
	memBaseSize = 0x10000000; //256M
	writel((memBaseAddr&(~(memBaseSize-1))), (mem_bar + 0xE20000) + 0x2420 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2428 + (entry_index * 0x20));
	writel(0x2, (mem_bar + 0xE20000) + 0x242C + (entry_index * 0x20));
	writel(0xC8000000 + (memBaseSize / 4096), (mem_bar + 0xE20000) + 0x2430 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2434 + (entry_index * 0x20));

	entry_index = 1;
	memBaseAddr = 0;
	memBaseSize = 0x200000000; //8G
	writel((memBaseAddr&(~(memBaseSize-1))), (mem_bar + 0xE20000) + 0x2420 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2428 + (entry_index * 0x20));
	writel(0x2, (mem_bar + 0xE20000) + 0x242C + (entry_index * 0x20));
	writel(0xC8000000 + (memBaseSize / 4096), (mem_bar + 0xE20000) + 0x2430 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2434 + (entry_index * 0x20));

	entry_index = 2;
	memBaseAddr = 0;
	memBaseSize = 0x2000000000; //128G
	writel((memBaseAddr&(~(memBaseSize-1))), (mem_bar + 0xE20000) + 0x2420 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel((memBaseAddr&(~(memBaseSize-1)))>>32, (mem_bar + 0xE20000) + 0x2424 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2428 + (entry_index * 0x20));
	writel(0x2, (mem_bar + 0xE20000) + 0x242C + (entry_index * 0x20));
	writel(0xC8000000 + (memBaseSize / 4096), (mem_bar + 0xE20000) + 0x2430 + (entry_index * 0x20));
	writel(0x0, (mem_bar + 0xE20000) + 0x2434 + (entry_index * 0x20));

	iounmap(mem_bar);

	return 0;
}
