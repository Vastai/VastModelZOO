#ifndef __PCIE_2_DMA_HOST_H__
#define __PCIE_2_DMA_HOST_H__

#ifdef CONFIG_VASTAI_SYNOPSIS_PCIE_DMA_HOST
int va_pcie2_dma_host_init(struct vastai_pci_info *priv);
#else
#define va_pcie2_dma_host_init(priv) (0)
#endif

#endif
