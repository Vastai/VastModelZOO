#include "vastai_pci.h"
#include "../va_irq.h"
#include "hw_config.h"
#include "vastai_pcie_public.h"
#include "hw_queue.h"
#include "vastai_pci.h"
#include "vastai_cmd.h"
#include <linux/stddef.h>
#include <linux/string.h>
#include "vastai_ai_info.h"


void init_ai_info(struct vastai_pci_info *priv)
{
    struct  ring_buf_entry *hw_entry;	
    struct  ai_info      *ai_entry;
    int i;

    u64 ddr_size = (u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_size<<32)|
                            priv->priv_hw_cfg->header.lo32_ddr_size;

    u8 config_bar4_5_sz = priv->priv_hw_cfg->sys_cfg.bar4_5_cfg_size;

	hw_entry = find_hw_cfg_acord_name(priv,COMMON_AI_PIPE_LINE_INFO_NAME);
    if( NULL == hw_entry ) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "COMMON_AI_PIPE_LINE_INFO_NAME buf init fail\n");
        return;
	} 
    
    ai_entry = kzalloc(sizeof(struct ai_info), GFP_KERNEL);
    ai_entry->ai_csram_buf_base         = hw_entry->ring_buf_base;
    ai_entry->ai_csram_buf_size         = hw_entry->ring_buf_size;
    ai_entry->fn_ddr_total_sz           = ddr_size;
    ai_entry->ddr_total_sz              = (u64)priv->priv_hw_cfg->sys_cfg.sum_ddr_sz*1024*1024*1024;
    if(priv->is_pf) {
        ai_entry->decoder_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_AI_DECODER_OFFSET;
        ai_entry->decoder_buf_host_phy_addr = priv->bar[VASTAI_PCI_BAR4].mmio_start+PF_AI_DECODER_OFFSET;
        ai_entry->decoder_buf_size          = AI_DECODER_SIZE_16M;

        ai_entry->ai_mod_buf_fn_addr        = VA_DDR_BASE_ADDR+PF_AI_MODULE_OFFSET;
        ai_entry->ai_mod_buf_host_phy_addr  = priv->bar[VASTAI_PCI_BAR4].mmio_start+PF_AI_MODULE_OFFSET;
        ai_entry->ai_mod_buf_size           = AI_MODULE_SIZE_16M;

        switch (config_bar4_5_sz) {
            case HWCFG_BAR4_5_NORMAL:
            case HWCFG_BAR4_5_2GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_DYNAMIC_BUF_OFFSET;
                ai_entry->ai_dyn_buf_size          = ddr_size - BAR_SIZE_2G;
                break;
            case HWCFG_BAR4_5_4GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_USED_SIZE;
                ai_entry->ai_dyn_buf_size          = LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE;
                break;
            case HWCFG_BAR4_5_8GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_USED_SIZE;
                ai_entry->ai_dyn_buf_size          = LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE;
                break;
            case HWCFG_BAR4_5_16GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_USED_SIZE;
                ai_entry->ai_dyn_buf_size          = LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE;
                break;
            case HWCFG_BAR4_5_32GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_USED_SIZE;
                ai_entry->ai_dyn_buf_size          = LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE;
                break;
            case HWCFG_BAR4_5_64GB:
                ai_entry->ai_dyn_buf_fn_addr       = VA_DDR_BASE_ADDR+PF_USED_SIZE;
                ai_entry->ai_dyn_buf_size          = LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE;
                break;
            
            default:
                break;
        }

	} else if(priv->is_vf) {
        ai_entry->decoder_buf_fn_addr       = VA_DDR_BASE_ADDR+VF_AI_DECODER_OFFSET;
        ai_entry->decoder_buf_host_phy_addr = priv->bar[VASTAI_PCI_BAR4].mmio_start+VF_AI_DECODER_OFFSET;
        ai_entry->decoder_buf_size          = AI_DECODER_SIZE_16M;

        ai_entry->ai_mod_buf_fn_addr        = VA_DDR_BASE_ADDR+VF_AI_MODULE_OFFSET;
        ai_entry->ai_mod_buf_host_phy_addr  = priv->bar[VASTAI_PCI_BAR4].mmio_start+VF_AI_MODULE_OFFSET;
        ai_entry->ai_mod_buf_size           = AI_MODULE_SIZE_16M;
        ai_entry->ai_dyn_buf_fn_addr        = VA_DDR_BASE_ADDR+VF_DYNAMIC_BUF_OFFSET;
        ai_entry->ai_dyn_buf_size           = ddr_size-VF_DDR_MMIO_SIZE;
	}

    VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[runtime] ai_dynamic_buf_fn_addr = 0x%llx \n",ai_entry->ai_dyn_buf_fn_addr);
    VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[runtime] ai_dynamic_buf_size    = 0x%llx(%lldMB) \n",ai_entry->ai_dyn_buf_size,
                                                            ai_entry->ai_dyn_buf_size/1024/1024);

    memcpy(&ai_entry->vdsp_cfg, &priv->priv_hw_cfg->vdsp_cfg, sizeof(struct  dsp_cfg));

    VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[runtime] vdsp_num   =%d\n",ai_entry->vdsp_cfg.vdsp_num);
    VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[runtime] vdsp_entry =%d\n",ai_entry->vdsp_cfg.valid_entry_num);

    for(i=0;i<ai_entry->vdsp_cfg.valid_entry_num;i++) {
        VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "[runtime] vdsp_entry[%d]  dsp_addr[0x%08x] noc_addr[0x%010llx] size[0x%08x]\n",
                                            i, ai_entry->vdsp_cfg.vdsp_entry[i].dsp_addr,
                                                    (u64)((u64)ai_entry->vdsp_cfg.vdsp_entry[i].hi32_soc_addr<<32)|
                                                    ai_entry->vdsp_cfg.vdsp_entry[i].lo32_soc_addr,
                                                    ai_entry->vdsp_cfg.vdsp_entry[i].size);
    }

    priv->vastai_ai_info = ai_entry;
    
    return;
}

void free_ai_info(struct vastai_pci_info *priv)
{
    if(priv->vastai_ai_info != NULL){
        kfree(priv->vastai_ai_info);
    }
    return;
}
