#ifndef __VA_HW_INIT_H__
#define __VA_HW_INIT_H__

struct va_dev_owner {
	u32 magic;
	u32 mode;
	u32 fn;
};

#define VA_DEV_OWNER(_mode, _fn) {	\
	.magic = 0x12345678,		\
	.mode = _mode,			\
	.fn   = _fn,			\
}

int va_hw_init(struct vastai_pci_info *priv);
int va_hw_deinit(struct vastai_pci_info *priv);

#endif
