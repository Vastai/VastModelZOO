#ifndef __VA_DMA_CORE_H__
#define __VA_DMA_CORE_H__

#include <linux/dmaengine.h>
#include <linux/kref.h>

#include "vastai_pci.h"

#define PCIE_2_DMA_PERF_MONITOR_EN 1

struct va_dma_desc_elem {
	struct list_head node;
	u64 cpu_addr;
	u64 dev_addr;
	u32 size;
	/* opcode in sdma, 0: copy, 1: fence, 2: fill*/
	u32 desc_type;
	struct vastai_dma_buf *buf;
};

struct va_dma_descriptor {
	struct list_head elem_head;
	enum dma_transfer_direction direction;
	void (*callback)(void *param);
	void *callback_param;
	/* private data for compatible with different chip series */
	void *priv;
	u32 elem_num;
	u8 pid;
	/* task priority, 0:high level,use sdma0; 1:low level,use sdma1 */
	u8 priority; 
	u8 dest_mmu;
	u8 src_mmu;
	/* The sdma descriptor storage location. 0:csram, 1:ddr*/
	u8 desc_loc;
	/* just used for slave die. 0:slave to host 1:slave to master */
	u8 d2d;
	/* when sync_tail=1, gmcu will not trigger msix to host after sdma done */
	u32 sync_tail;
	/* dma performance monitor */
	u32 total_len;
	u64 desc_addr;  /* just used when desc_loc = 1 */
	ktime_t trigger_time;
	ktime_t done_time;
};

struct va_dma_ops {
	int (*submit)(void *, struct va_dma_descriptor *);
	int (*deinit)(void *);
	int (*stop)(void *);
};

struct va_dma_monitor {
	u64 tx_byte;
	u64 rx_byte;
};

/**
 * dma attr
 */
#define VA_DMA_ATTR_DIR_MEM_TO_DEV	(1 << 0)
#define VA_DMA_ATTR_DIR_DEV_TO_MEM	(1 << 1)
#define VA_DMA_ATTR_SUPPORT_SHARED	(1 << 2)
#define VA_DMA_ATTR_SUPPORT_ASYNC	(1 << 3)

/**
 * dma flag .eg
 */
//#define VA_DMA_FLAG_USE_GFX		(1 << 0)
//#define VA_DMA_FLAG_USE_TOOL		(1 << 0)

#define VA_DMA_NAME_LEN_MAX 32
typedef struct va_dma {
	char name[VA_DMA_NAME_LEN_MAX];
	u32 attr;
	//u32 flag;
	struct kref ref_cnt;
	struct list_head node;
	struct va_dma_ops *ops;
	void *priv; /*dma_device */
        void *pci_info; /*pci info*/

	struct va_dma_monitor monitor;
} va_dma_t;

int add_elem_to_dma_desc(struct va_dma_descriptor *desc, u32 len, u64 mem, u64 dev);
struct va_dma_descriptor *va_dma_prep_slave_sg(va_dma_t *dma,
				struct scatterlist *sgl,
				unsigned int sg_len,
				u64 dev_addr,
				enum dma_transfer_direction direction);
struct va_dma_descriptor *va_dma_prep_desc_array(va_dma_t *dma,
				u64 *mem_addr, u64 *dev_addr, u32 *size,
				u32 elem_nums,
				enum dma_transfer_direction direction);
void va_dma_descriptor_free(struct va_dma_descriptor *desc);
int va_dma_desc_submit(va_dma_t *dma, struct va_dma_descriptor *desc);

va_dma_t *va_dma_alloc(struct vastai_pci_info *priv, u32 flags, u32 attr);

int va_dma_free(struct vastai_pci_info *priv, va_dma_t *dma);
int va_dma_add(struct vastai_pci_info *priv, va_dma_t *dma);

int va_dma_release_all(struct vastai_pci_info *priv);
int va_dma_core_init(struct vastai_pci_info *priv);
#endif
