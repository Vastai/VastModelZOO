/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/04
 * Author: adan.xue
 */

#include "vastai_pci.h"
#include "va_dma_core.h"
#include "pcie_2_dma.h"

#if 0
static void dma_transfer_test_callback(void *param)
{
	struct completion *completion = param;

	if (completion)
		complete(completion);
	return;
}
#endif

#define VA_PCIE_DMA_TEST_SELFCHECK_EN 0
void va_pcie_dma_tranfer_test(struct vastai_pci_info *priv,
			     u8 is_mem_to_dev,
			     u64 mem_offset,
			     u64 dev_addr,
			     u32 len,
			     int val);

void va_pcie_dma_tranfer_test(struct vastai_pci_info *priv,
			     u8 is_mem_to_dev,
			     u64 mem_offset,
			     u64 dev_addr,
			     u32 len,
			     int val)
{
	struct va_dma_descriptor desc;
	struct va_dma_desc_elem elem;
	void *dma_buf_va;
	dma_addr_t dma_buf_pa;
	int ret;
#if VA_PCIE_DMA_TEST_SELFCHECK_EN
	int i;
#endif

#if 0
	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return;
	}

	//init_completion(&completion);
#endif

	desc.direction = is_mem_to_dev ? DMA_MEM_TO_DEV : DMA_DEV_TO_MEM;
	INIT_LIST_HEAD(&desc.elem_head);
	desc.elem_num = 1;
	//desc.callback = dma_transfer_test_callback;
	//desc.callback_param = &completion;

	dma_buf_va = dma_alloc_coherent(&priv->dev->dev,
				len + mem_offset,
				&dma_buf_pa,
				GFP_DMA32 | GFP_KERNEL);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"%s: va=0x%p pa=0x%llx\n", __func__, dma_buf_va, dma_buf_pa);
	if (dma_buf_va == 0) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				"%s: dma buf alloc failed, %llu\n",
				__func__, len + mem_offset);
		goto dma_free;
	}
    
    memset(dma_buf_va + mem_offset, val, len);

#if VA_PCIE_DMA_TEST_SELFCHECK_EN
	if (is_mem_to_dev) {
		memset(dma_buf_va + mem_offset, 0, len);
		vastai_pci_mem_write(priv, 0, dev_addr, dma_buf_va + mem_offset, len);
		memset(dma_buf_va + mem_offset, val, len);
	} else {
		memset(dma_buf_va + mem_offset, val, len);
		vastai_pci_mem_write(priv, 0, dev_addr, dma_buf_va + mem_offset, len);
		memset(dma_buf_va + mem_offset, 0, len);
	}
#endif

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
			"once_dma_transfer: mem=0x%llx, dev=0x%llx, len=0x%x, dir=%s\n",
			dma_buf_pa + mem_offset, dev_addr, len,
			is_mem_to_dev ? "m2d" : "d2m");

	elem.size = len;
	elem.cpu_addr = dma_buf_pa + mem_offset;
	elem.dev_addr = dev_addr;
	list_add_tail(&(elem.node), &(desc.elem_head));

	//ret = va_dma_desc_submit(dma, &desc);
	ret = pcie2_dma_desc_submit_raw(priv, &desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: push_dma_desc error %d\n", __func__, ret);
		goto error_ret;
	}
#if 0
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s() To wait DMA transfer completion status\n", __func__);
    
	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: wait completion error %d\n", __func__, ret);
		goto error_ret;
	}
 #endif   
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s() DMA transfer completion Done!!\n", __func__);

#if VA_PCIE_DMA_TEST_SELFCHECK_EN
	if (is_mem_to_dev) {
		ret = vastai_pci_mem_read(priv, 0, dev_addr, dma_buf_va, len);
		if (ret) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				       "read dev_addr fail! dev_addr=0x%llx, len=0x%x\n",
				       dev_addr, len);
			goto error_ret;
		} else {
			for (i = 0; i < len; i++) {
				if (((char *)dma_buf_va)[i] == val)
					continue;
				VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				       "dma transfer fail! dev_addr=0x%llx, val=0x%x\n",
				       dev_addr + i, ((char *)dma_buf_va)[i]);
				goto error_ret;
			}
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
					"dma transfer data match!\n");
		}
	}
	else {
		for (i = 0; i < len; i++) {
			if (((char *)dma_buf_va)[i + mem_offset] == val)
				continue;
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				"dma transfer fail! mem_addr=0x%llx, val=0x%x\n",
				dev_addr + i + mem_offset, ((char *)dma_buf_va)[i + mem_offset]);
			goto error_ret;
		}
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				"dma transfer data match!\n");
	}
#endif

error_ret:
	dma_free_coherent(&priv->dev->dev, len + mem_offset,
			  dma_buf_va, dma_buf_pa);
dma_free:
	//va_dma_free(priv, dma);

	return;
}

