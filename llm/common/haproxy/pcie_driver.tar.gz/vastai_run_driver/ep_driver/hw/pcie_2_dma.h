#ifndef __PCIE_2_DMA_H__
#define __PCIE_2_DMA_H__

#include "va_hw_init.h"
#include "va_irq.h"
#include "../../include/common/sg100/msgq_struct_share.h"
#include "va_dma_core.h"

struct pcie2_dma_ch_cfg {
	char *name;

	u8 dir;
	u64 desc_msgq_reg;
	u64 desc_msgq_buf;
	u32 desc_msgq_buf_size;
	u16 pf_depth;
};

struct pcie2_dma_cfg {
	struct va_dev_owner owner;

	char *name;
	u8 device_id;
	enum host_irq_num irq_num;
	struct pcie2_dma_ch_cfg wr_cfg;
	struct pcie2_dma_ch_cfg rd_cfg;
};

#define PCIE2_DMA_CFG_ITEM(__name,			\
			   __dir,			\
			   __desc_msgq_reg,		\
			   __desc_msgq_buf,		\
			   __desc_msgq_buf_size,	\
			   __pf_depth)	\
{	\
	.name = __name,					\
	.dir = __dir,					\
	.desc_msgq_reg = __desc_msgq_reg,		\
	.desc_msgq_buf = __desc_msgq_buf,		\
	.desc_msgq_buf_size = __desc_msgq_buf_size,	\
	.pf_depth = __pf_depth,				\
}

int va_pcie2_dma_init(struct vastai_pci_info *priv, struct pcie2_dma_cfg *cfg);
int pcie2_dma_raw_init(struct vastai_pci_info *priv, struct pcie2_dma_cfg *cfg);
int pcie2_dma_desc_submit_raw(struct vastai_pci_info *priv, struct va_dma_descriptor *desc);

#endif
