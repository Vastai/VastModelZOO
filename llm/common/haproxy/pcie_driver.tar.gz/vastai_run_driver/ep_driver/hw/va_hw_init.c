/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/04/18
 * Author: adan.xue
 */

#include "vastai_pci.h"
#include "va_hw_config.h"
#include "va_dma_core.h"
#include "va_irq.h"
#include "pcie_2_dma_host.h"
#include "sdma.h"
#include "hw_config.h"
#include "pcie_2_dma.h"
#include "vastai_ai_info.h"

#define hw_init_dbg(fmt, args...) do {	\
	VASTAI_PCI_DBG(NULL,0xff, fmt, ##args);	\
} while(0);

#define hw_init_err(fmt, args...) do {	\
	VASTAI_PCI_ERR(NULL,0xff, fmt, ##args);	\
} while(0);

#define hw_init_info(fmt, args...) do {	\
	VASTAI_PCI_INFO(NULL,0xff, fmt, ##args);	\
} while(0);

#if PCIE2_DMA_ENABLE || PCIE2_DMA_RAW_ENABLE
static bool device_own_check(struct vastai_pci_info *priv,
			     struct va_dev_owner *owner)
{
	if (owner->magic != 0x12345678) {
		hw_init_err("va_dev_owner don't init\n");
		return false;
	}

	if (priv->dev->devfn != owner->fn)
		return false;

	return true;
}
#endif

static inline int init_dma_cfg(struct vastai_pci_info *priv, struct pcie2_dma_cfg *cfg)
{
	struct ring_buf_entry *wr_entry;
	struct ring_buf_entry *rd_entry;
	wr_entry = find_hw_cfg_acord_name(priv,COMMON_PCIE_DMA_WRITE_NAME);
	if(NULL==wr_entry){
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "init_dma_cfg fail\n");
		return -EINVAL;
	}
	cfg->wr_cfg.desc_msgq_reg 		= wr_entry->msgq_ctrl_reg_base;
	cfg->wr_cfg.desc_msgq_buf 		= wr_entry->ring_buf_base;
	cfg->wr_cfg.desc_msgq_buf_size  = wr_entry->ring_buf_size;

	rd_entry = find_hw_cfg_acord_name(priv,COMMON_PCIE_DMA_READ_NAME);
	if(NULL==rd_entry){
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "init_dma_cfg fail\n");
		return -EINVAL;
	}	
	cfg->rd_cfg.desc_msgq_reg 		= rd_entry->msgq_ctrl_reg_base;
	cfg->rd_cfg.desc_msgq_buf 		= rd_entry->ring_buf_base;
	cfg->rd_cfg.desc_msgq_buf_size  = rd_entry->ring_buf_size; 

	return 0;
}

static void init_gpu_cfg(struct vastai_pci_info *priv,struct va_gfx_cfg *cfg)
{
	u8 config_bar4_5_sz = priv->priv_hw_cfg->sys_cfg.bar4_5_cfg_size;
	cfg->regs.bar_num 		  = 2;
	cfg->regs.bar_offset 	  = priv->priv_hw_cfg->header.csram_size+priv->priv_hw_cfg->header.smu_csr_size;
	cfg->regs.dev_paddr 	  = priv->priv_hw_cfg->header.gfx_csr_base;
	cfg->regs.size 			  = priv->priv_hw_cfg->header.gfx_csr_size;
	cfg->gfx_heap.bar_num 	  = SG100_DDR_GFX_BAR;
	cfg->disp_heap.bar_num 	  = SG100_DDR_GFX_BAR;

	if((priv->priv_hw_cfg->sys_cfg.pfn==0) && priv->is_pf){
		cfg->display_reg.bar_num    = VASTAI_PCI_BAR2;
		if( ONLY_1_PF ==priv->priv_hw_cfg->sys_cfg.fn_mode){
			cfg->display_reg.bar_offset = cfg->regs.bar_offset + priv->priv_hw_cfg->header.gfx_csr_size;
		} else {
			cfg->display_reg.bar_offset = cfg->regs.bar_offset + priv->priv_hw_cfg->header.gfx_csr_size + BAR2_SMCU_CSRAM_32KB;
		}
		cfg->display_reg.dev_paddr  = DISPLAY_NOC_ADDR;
		cfg->display_reg.size       = SG100_DISPLAY_CSR_SZ_1MB;

		cfg->dsu_reg.bar_num        = VASTAI_PCI_BAR2;
		cfg->dsu_reg.bar_offset     = cfg->display_reg.bar_offset + SG100_DISPLAY_CSR_SZ_1MB;
		cfg->dsu_reg.dev_paddr      = DSU_NOC_ADDR;
		cfg->dsu_reg.size           = SG100_DSU_CSR_SZ_128KB;

		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]display regs bar_off = 0x%llx\n",cfg->display_reg.bar_offset);
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]dsu regs bar_off     = 0x%llx\n",cfg->dsu_reg.bar_offset);	
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]display regs PA      = 0x%llx\n",priv->bar[VASTAI_PCI_BAR2].mmio_start + cfg->display_reg.bar_offset);
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]dsu   regs   PA      = 0x%llx\n",priv->bar[VASTAI_PCI_BAR2].mmio_start + cfg->dsu_reg.bar_offset);
	}
	

	switch (config_bar4_5_sz) {
		case HWCFG_BAR4_5_NORMAL:
			if(priv->is_pf){
				cfg->gfx_heap.bar_offset  = SG100_GFX_HEAP_BAR_OFFSET;
				cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE+SG100_GFX_HEAP_DEV_OFFSET;
				cfg->gfx_heap.size 		  = SG100_GFX_HEAP_SIZE;
				
				cfg->disp_heap.bar_offset = SG100_DISP_HEAP_BAR_OFFSET;
				cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE+ SG100_DISP_HEAP_DEV_OFFSET;
				cfg->disp_heap.size 	  = SG100_DISP_HEAP_SIZE;
			} else if (priv->is_vf) {
				cfg->gfx_heap.bar_offset  = VF_GFX_HEAP_BAR_OFFSET;
				cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE+VF_GFX_HEAP_DEV_OFFSET;
				cfg->gfx_heap.size 		  = VF_GFX_HEAP_SIZE;

				cfg->disp_heap.bar_offset = VF_DISP_HEAP_BAR_OFFSET;
				cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE+ VF_DISP_HEAP_DEV_OFFSET;
				cfg->disp_heap.size 	  = VF_DISP_HEAP_SIZE;
			}
			break;


		case HWCFG_BAR4_5_2GB:
			cfg->gfx_heap.bar_offset  = SG100_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE+SG100_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = SG100_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = SG100_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE+ SG100_DISP_HEAP_DEV_OFFSET;
			cfg->disp_heap.size 	  = SG100_DISP_HEAP_SIZE;
			break;


		case HWCFG_BAR4_5_4GB:
			cfg->gfx_heap.bar_offset  = LARGE_BAR_4GB_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE + LARGE_BAR_4GB_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = LARGE_BAR_4GB_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = LARGE_BAR_4GB_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE + LARGE_BAR_4GB_DISP_HEAP_DEV_OFFSET;
#ifdef DIAG_TEST_DDK
			cfg->disp_heap.size 	  = LARGE_BAR_4GB_DISP_HEAP_SIZE - DEV_DDR_SIZE_256MB;
#else
			cfg->disp_heap.size 	  = LARGE_BAR_4GB_DISP_HEAP_SIZE;
#endif
			break;


		case HWCFG_BAR4_5_8GB:
			cfg->gfx_heap.bar_offset  = LARGE_BAR_8GB_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE + LARGE_BAR_8GB_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = LARGE_BAR_8GB_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = LARGE_BAR_8GB_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE + LARGE_BAR_8GB_DISP_HEAP_DEV_OFFSET;
#ifdef DIAG_TEST_DDK
			cfg->disp_heap.size 	  = LARGE_BAR_8GB_DISP_HEAP_SIZE - DEV_DDR_SIZE_256MB;
#else
			cfg->disp_heap.size 	  = LARGE_BAR_8GB_DISP_HEAP_SIZE;
#endif
			break;

		case HWCFG_BAR4_5_16GB:
			cfg->gfx_heap.bar_offset  = LARGE_BAR_16GB_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE + LARGE_BAR_16GB_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = LARGE_BAR_16GB_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = LARGE_BAR_16GB_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE + LARGE_BAR_16GB_DISP_HEAP_DEV_OFFSET;
#ifdef DIAG_TEST_DDK
			cfg->disp_heap.size 	  = LARGE_BAR_16GB_DISP_HEAP_SIZE - DEV_DDR_SIZE_256MB;
#else
			cfg->disp_heap.size 	  = LARGE_BAR_16GB_DISP_HEAP_SIZE;
#endif
			break;

		case HWCFG_BAR4_5_32GB:
			cfg->gfx_heap.bar_offset  = LARGE_BAR_32GB_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE + LARGE_BAR_32GB_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = LARGE_BAR_32GB_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = LARGE_BAR_32GB_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE + LARGE_BAR_32GB_DISP_HEAP_DEV_OFFSET;
#ifdef DIAG_TEST_DDK
			cfg->disp_heap.size 	  = LARGE_BAR_32GB_DISP_HEAP_SIZE - DEV_DDR_SIZE_256MB;
#else
			cfg->disp_heap.size 	  = LARGE_BAR_32GB_DISP_HEAP_SIZE;
#endif
			break;
		case HWCFG_BAR4_5_64GB:
			cfg->gfx_heap.bar_offset  = LARGE_BAR_64GB_GFX_HEAP_BAR_OFFSET;
			cfg->gfx_heap.dev_paddr   = SG100_DDR_GFX0_BASE + LARGE_BAR_64GB_GFX_HEAP_DEV_OFFSET;
			cfg->gfx_heap.size 		  = LARGE_BAR_32GB_GFX_HEAP_SIZE;

			cfg->disp_heap.bar_offset = LARGE_BAR_64GB_DISP_HEAP_BAR_OFFSET;
			cfg->disp_heap.dev_paddr  = SG100_DDR_GFX0_BASE + LARGE_BAR_64GB_DISP_HEAP_DEV_OFFSET;
#ifdef DIAG_TEST_DDK
			cfg->disp_heap.size 	  = LARGE_BAR_64GB_DISP_HEAP_SIZE - DEV_DDR_SIZE_256MB;
#else
			cfg->disp_heap.size 	  = LARGE_BAR_64GB_DISP_HEAP_SIZE;
#endif
			break;
		
		default:
			break;
	}
	
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]gfx heap bar offset  = 0x%llx\n",cfg->gfx_heap.bar_offset);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]gfx heap dev_paddr   = 0x%llx\n",cfg->gfx_heap.dev_paddr);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]gfx heap size        = 0x%llx(%lldMB)\n",
									cfg->gfx_heap.size,cfg->gfx_heap.size/1024/1024);
	
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]display bar offset   = 0x%llx\n",cfg->disp_heap.bar_offset);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]display dev_paddr    = 0x%llx\n",cfg->disp_heap.dev_paddr);
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,"[GPU]display heap size    = 0x%llx(%lldMB)\n",
									cfg->disp_heap.size,cfg->disp_heap.size/1024/1024);

	


	return;
}

int va_hw_init(struct vastai_pci_info *priv)
{

	int ret = 0;

	// core layer init
	if (va_dma_core_init(priv))
		return -EPERM;

	// hw device init

    VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s \n", __func__);

#if PCIE2_DMA_ENABLE || PCIE2_DMA_RAW_ENABLE
	int i;

      for (i = 0; i < ARRAY_SIZE(pcie2_dma_cfgs); i++) {
		if (device_own_check(priv, &pcie2_dma_cfgs[i].owner)) {
			ret = init_dma_cfg(priv,&pcie2_dma_cfgs[i]);
			if(ret){
				return -EIO;
			}
#if PCIE2_DMA_RAW_ENABLE
            if (i == 4 || i == 0)
			{
				ret = pcie2_dma_raw_init(priv, &pcie2_dma_cfgs[i]);
			}
#else
			ret = va_pcie2_dma_init(priv, &pcie2_dma_cfgs[i]);
#endif
			if (ret) {
				return -EIO;
			}
		}
	}
#else
	ret = vastai_sdma_init(priv);
	if (ret) {
		return -EIO;
	}
#endif
	

	//TODO: move config to hw_config.h
	if (va_pcie2_dma_host_init(priv)) {
		return -EIO;
	}
    
	if (va_host_irq_init(priv)) {
		return -EIO;
	}

	ret = vastai_smmu_init(priv);
	if (ret) {
		return -EIO;
	}

#if VA_GFX_ENABLE
#if 0
	for (i = 0; i < ARRAY_SIZE(gfx_cfgs); i++) {
		if (device_own_check(priv, &gfx_cfgs[i].owner)) {
			ret = va_pcie_ddk_init(priv, &gfx_cfgs[i]);
			if (ret) {
				return -EIO;
			}
		}
    }
#endif
    init_gpu_cfg(priv, &gfx_cfg);
	ret = va_pcie_ddk_init(priv, &gfx_cfg);
	if (ret) {
		return -EIO;
	}
#endif

	return 0;
}

int va_hw_deinit(struct vastai_pci_info *priv)
{
	int ret = 0;

#if VA_GFX_ENABLE
	ret |= va_pcie_ddk_deinit(priv);
#endif
	ret |= va_dma_release_all(priv);
	ret |= va_host_irq_deinit(priv);
	return ret;
}

