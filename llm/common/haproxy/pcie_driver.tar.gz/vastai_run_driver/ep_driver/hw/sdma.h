#ifndef __SDMA_H__
#define __SDMA_H__

#include <linux/kfifo.h>
#include "va_hw_init.h"
#include "va_irq.h"
#include "msgq_struct_share.h"
#include "hw_queue.h"

#define SDMA_CH0 0
#define SDMA_CH1 1
#define HIGH_LEVEL_TASK 0
#define LOW_LEVEL_TASK	1
#define VASTAI_DMA_CREDIT_LIMIT_SG	128


enum SDMA_OP_CODE{
    SDMA_OP_CODE_COPY  = 0,
    SDMA_OP_CODE_FENCE = 1,
    SDMA_OP_CODE_FILL  = 2,
    SDMA_OP_CODE_MAX,
};


// 32Bytes
struct sdma_ll_copy_desc_element{
	u32 next_p_low;
    u32 next_p_upp_8b : 8;
    u32 op            : 8;
    u32 ll_last       : 1;
    u32 int_en        : 1;
	u32 reserved1     : 2;
	u32 src_hst       : 1;      // 1: PCIe, 0: NOC
	u32 dst_hst       : 1;      // 1: PCIe, 0: NOC
    u32 src_mmu       : 1;      // 1: bypass mmu, 0: no bypass
    u32 dst_mmu       : 1;      // 1: bypass mmu, 0: no bypass
    u32 dscp_cnt      : 1;      // enable descriptor counter for finished descriptor of each chl
	u32 dscp_clr      : 1;
	u32 reserved2     : 6;
    u32 reserved3;
    u32 trans_length;
    u32 src_addr_low;
    u32 src_addr_upp;
    u32 dst_addr_low;
    u32 dst_addr_upp;
};

// 32Bytes
struct sdma_ll_write_desc_element{
	u32 next_p_low;
    u32 next_p_upp_8b : 8;
    u32 op            : 8;
    u32 ll_last       : 1;
    u32 int_en        : 1;
	u32 reserved1     : 2;
	u32 reserved2     : 1;
	u32 dst_hst       : 1;      // 1: PCIe, 0: NOC
    u32 reserved3     : 1;
    u32 dst_mmu       : 1;      // 1: bypass mmu, 0: no bypass
    u32 dscp_cnt      : 1;
	u32 dscp_clr      : 1;
	u32 reserved4     : 6;
    u32 reserved5;
    u32 trans_length;
    u32 write_data_low;
    u32 write_data_upp;
    u32 dst_addr_low;
    u32 dst_addr_upp;
};

// 32Bytes
struct sdma_ll_info_element{
	u32 ctrl;                    //reserved1;
	u32 sync_tail	  : 1;       // if sync_tail=1, gmcu will don't trigger msix to host after sdma done
	u32 d2d			  : 1;
	u32 stop_chl	  : 1;
	u32 reserved2     : 29;
    u32 ll_addr_low;
    u32 ll_addr_high;
    u32 ll_size;                // desc number in the linklist
    u32 pid;
    u32 loc;
    u32 reserved7;
};

union sdma_ll_desc_element {
	struct sdma_ll_write_desc_element sll_wr_desc;
	struct sdma_ll_copy_desc_element  sll_cp_desc;
};

struct vastai_sdma_ch_cfg {
	u64 msgq_reg;
	u64 msgq_buf;
	u32 msgq_buf_size;
};

#define VASTAI_SDMA_CH_CFG_ITEM(__name,			\
			   __dir,			\
			   __desc_msgq_reg,		\
			   __desc_msgq_buf,		\
			   __desc_msgq_buf_size)	\
{	\
	.name = __name,					\
	.dir = __dir,					\
	.desc_msgq_reg = __desc_msgq_reg,		\
	.desc_msgq_buf = __desc_msgq_buf,		\
	.desc_msgq_buf_size = __desc_msgq_buf_size,	\
}

#define HOST_DMA_FIFO_DEPTH (1024 * 2)
struct vastai_sdma_channel {
	char name[32];
	struct mutex lock;
	struct hw_msgq desc_msgq;
	struct hw_msgq info_msgq;
	union sdma_ll_desc_element *last_desc_msg;
	union sdma_ll_desc_element *first_desc_msg;
	struct sdma_ll_info_element *last_info_msg;
	struct sdma_ll_info_element *first_info_msg;
	DECLARE_KFIFO(info_fifo, struct va_dma_descriptor *, HOST_DMA_FIFO_DEPTH);
	struct vastai_sdma_ch_cfg desc_cfg;
	struct vastai_sdma_ch_cfg info_cfg;
};

struct vastai_sdma_device {
	char name[32];
	u8 id;
	struct vastai_sdma_channel ch0;
	struct vastai_sdma_channel ch1;
};


int vastai_sdma_init(struct vastai_pci_info *priv);
int sdma_debug(struct vastai_pci_info *priv, int chl_idx);
int check_cur_sdma(struct vastai_pci_info *priv);
void sdma_reset(struct vastai_pci_info *priv);
#endif
