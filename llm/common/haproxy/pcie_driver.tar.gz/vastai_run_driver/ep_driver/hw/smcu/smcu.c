#include "vastai_pci.h"
#include "../va_irq.h"
#include "hw_config.h"
#include "vastai_pcie_public.h"
#include "hw_queue.h"
#include "vastai_pci.h"
#include "vastai_cmd.h"
#include "../smmu.h"
#include "vastai_fifo.h"
#include "sg100_cmd.h"
#include "../vsync/va_vsync.h"
#include "vastai_common.h"
#include "exception.h"

static void mpu_handler(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info)
{
    u64 out_of_bound_addr = (u64)((u64)msix_info->w2.data2<<32)|msix_info->w1.data1;
    u8  read_or_write     = msix_info->w0.s_data0.rev2;
    switch (msix_info->w0.s_data0.rev0){
        case SMMU_MPU_OUT_OF_BOUND:{
            u8 stream_id = msix_info->w0.s_data0.rev1;
            read_or_write = msix_info->w3.s_data3.rev0;
            if(MPU_READ == read_or_write){
                VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[smmu_mpu]the stream_id[%d] read addr[0x%llx] happen out of bound \n",
                           stream_id,out_of_bound_addr);
            } else if(MPU_WRITE == read_or_write) {
                VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[smmu_mpu]the stream_id[%d] write addr[0x%llx] happen out of bound \n",
                           stream_id,out_of_bound_addr);
            }           
            break;
        }
            
        case GFX_MPU_OUT_OF_BOUND:{
            u8 gpuid = msix_info->w0.s_data0.rev1;
            u8 osid  = msix_info->w0.s_data0.rev2;
            read_or_write = msix_info->w3.s_data3.rev0;
            if(MPU_READ == read_or_write){
                 VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[gfx_mpu]the gpu[%d] osid[%d] read addr[0x%llx] happen out of bound \n",
                           gpuid, osid, out_of_bound_addr);
            } else if(MPU_WRITE == read_or_write) {
                 VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[gfx_mpu]the gpu[%d] osid[%d] write addr[0x%llx] happen out of bound \n",
                           gpuid, osid, out_of_bound_addr);
            }           
            break;
        }
            
        case ENCODER_MPU_OUT_OF_BOUND:{
            u8 encoder_num = msix_info->w0.s_data0.rev1;
            if(MPU_READ == read_or_write){
                 VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[encoder_mpu%d]read addr[0x%llx] happen out of bound \n",
                           encoder_num, out_of_bound_addr);
            } else if(MPU_WRITE == read_or_write) {
                 VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[encoder_mpu%d]write addr[0x%llx] happen out of bound \n",
                           encoder_num, out_of_bound_addr);
            }            
            break;
        }
            
        case DECODER_MPU_OUT_OF_BOUND:{
            u8 decoder_num = msix_info->w0.s_data0.rev1;
            if(MPU_READ == read_or_write){
                VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[decoder_mpu%d]read addr[0x%llx] happen out of bound \n",
                           decoder_num, out_of_bound_addr);
            } else if(MPU_WRITE == read_or_write) {
                VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "[decoder_mpu%d]write addr[0x%llx] happen out of bound \n",
                           decoder_num, out_of_bound_addr);
            }            
            break;
        }
                
        default:
            break;
    }
    return;
}

static int smcu_msix_handler(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info)
{
	switch (msix_info->w0.s_data0.optcode){
		case SWITCH_ATU_DONE:
			complete(&priv->swtich_atu_done);
			break;

		case SMCU_RET_VALUE:{
			complete(&priv->read_csr_by_smcu_done);
			priv->read_csr_value_by_smcu = msix_info->w1.data1;
			break;
		}

		case SMCU_WRITE_VALUE_DONE:{
			complete(&priv->write_csr_by_smcu_done);
			break;
		}

		case SMCU_VSYNC_TIMER_INT:{
			va_vsync_timer_callback(priv, msix_info->w1.data1);
			break;
		}

#ifdef CONFIG_VASTAI_TOOLS_SUITE
		case SMCU_SMI_CMD_ACK:{
			u32 smi_msg = msix_info->w1.data1;
			u8 bc = (smi_msg >> 8) & 0xFF;
			VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "recv SMCU_SMI_CMD_ACK block_id=%d", bc);

			if (bc >= 2) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "[ERROR] SMI block count > 2 ");
				priv->tools_info.smi_ack_msg[0] = 0;
				priv->tools_info.smi_ack_msg[1] = 0;
				complete(&priv->tools_info.smi_ack[0]);
				complete(&priv->tools_info.smi_ack[1]);
			}else{
			priv->tools_info.smi_ack_msg[bc] = smi_msg;
				complete(&priv->tools_info.smi_ack[bc]);
			}
			break;
		}
#endif

		case SMCU_MONITOR_PCIE_PERF_ACK:{
			complete(&priv->pcie_monitor_done);
			break;
		}

		case SMCU_MONITOR_DDR_PERF_ACK:{
			complete(&priv->ddr_monitor_done);
			break;
		}

		case SMCU_XSPI_RW_ACK:{
			priv->rw_xspi_msg = msix_info->w2.data2;
			complete(&priv->rw_xspi);
			break;
		}

#ifdef CONFIG_VASTAI_TOOLS_SUITE
		case SMCU_TO_HOST_LOG_READ:{
			complete(&(priv->tools_info.log_comp));
			break;
		}
#endif

        case SMCU_CMD_REINIT_RST_PKG_ACK:{
            complete(&priv->send_reinit_rst_done);
            break;
        }

        case SMCU_TO_HOST_MPU_OUT_OF_BOUND:{
            mpu_handler(priv,msix_info);
            break;
        }

        case VASTAI_PCIE_MSG1_VIDEO_EXCEPTION:{
            vastai_pci_video_exception(priv,msix_info);
            break;
        }

        case VASTAI_PCIE_MSG1_CORE_EXCEPTION:{
            vastai_pci_vemcu_exception(priv,msix_info);
            break;
        }

        case VASTAI_PCIE_MSG1_CORE_RESET_ACK:{
            vastai_pci_vemcu_reset_ack(priv,msix_info);
            break;
        }

        case FREQ_REDUCE_BY_TEMP:{
            VASTAI_PCI_INFO(priv, priv->pkg_id,
                            "[vawarn] Frequency reduced to  %d%% due to over-temperature!\n",
                            msix_info->w1.s_data1.rev0);
            break;
        }
        case FREQ_REDUCE_BY_VOLT:{
            VASTAI_PCI_INFO(priv, priv->pkg_id,
                            "[vawarn] Frequency reduced to  %d%% due to over-current!",
                            msix_info->w1.s_data1.rev0);
            break;
        }
        case FREQ_RECOVER_NORMAL_BY_TEMP:
        {
            VASTAI_PCI_INFO(priv, priv->pkg_id,
                            "[vawarn] Frequency increased to  %d%% as temperature returned to normal.\n",
                            msix_info->w1.s_data1.rev0);
            break;
        }
        case FREQ_RECOVER_NORMAL_BY_VOLT:
        {
            VASTAI_PCI_INFO(priv, priv->pkg_id,
                            "[vawarn] Frequency increased to  %d%% as current returned to normal.\n",
                            msix_info->w1.s_data1.rev0);
            break;
        }
        case FREQ_POWER_DOEN_REQ:{
            /* set smcu machine state for each die */
            VASTAI_PCI_ERR(priv, priv->pkg_id,
                           "bmcu power down alert occurs, ret=%d.\n",
                           msix_info->w1.s_data1.rev0);
            break;
        }

        /*
                VASTAI_PCI_ERR(priv, pkg_id,"%s offset = 0x%llx, len=%ld, error:%d\n",
                __func__, offset, len, ret);*/
        default:
            break;
    }

	if(msix_info->w0.s_data0.optcode <= 0x24)
	{
    	va_get_smmu_err(priv, msix_info);
    }
    return 0;
}


void smcu_and_cmcu_msix_callback(void *arg)
{
	int ret;
	struct vastai_pci_info *priv = (struct vastai_pci_info *) arg;
	struct pcie_transfer_cmd trans;

	while (1) {
        if( ONLY_1_PF == priv->fn_mode)	{
            ret = vastai_pci_receive_msg(priv,0,ONLY_1PF_SMCU_TO_HOST_INFO_BUF,&trans);
        } else if (ONLY_2_PF == priv->fn_mode) {
            ret = vastai_pci_receive_msg(priv,0,ONLY_2PF_SMCU_TO_HOST_INFO_BUF,&trans);
        } else {
            ret = vastai_pci_receive_msg(priv,0,COMMON_SMCU_TO_HOST_INFO_BUF,&trans);
        }

        if (ret){
            break;
        }
        
        ret = smcu_msix_handler(priv,&trans);
        if (ret) {
             VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "smcu_msix_handler failed\n");
        }
		
	}

#ifdef CONFIG_VASTAI_AI
    if(priv->waiting_cmcu_comback){
        vastai_cmcu_call_back(priv);
    }
#endif    
    return;

}

int smcu_to_host_msix_init(struct vastai_pci_info *priv)
{
    int ret;
    
    ret = va_register_pcie_interrupt(priv, COMMON_MSIX_SMCU_AND_CMCU_VECTOR,
                     smcu_and_cmcu_msix_callback,
                     priv);
    if (ret) {
        VASTAI_PCI_ERR(priv, 0,
                "%s: va_register_pcie_interrupt() fail!, %d\n",
                __func__, ret);
        ret = -EIO;

    }

    return ret;
}
