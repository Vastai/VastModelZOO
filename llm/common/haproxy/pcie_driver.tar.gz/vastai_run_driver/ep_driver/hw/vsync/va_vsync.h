#ifndef __VA_VSYNC_H__
#define __VA_VSYNC_H__

#include "vastai_pci.h"

void va_vsync_timer_callback(struct vastai_pci_info *priv, u32 timer_tick);
int va_vsync_timer_enable(struct vastai_pci_info *priv, u32 freq_hz);
int va_vsync_timer_disable(struct vastai_pci_info *priv);

#endif /* __VA_VSYNC_H__ */
