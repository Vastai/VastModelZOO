#include "va_vsync.h"
#include "sg100_cmd.h"

void va_vsync_timer_callback(struct vastai_pci_info *priv, u32 timer_tick)
{
	return;
}

int va_vsync_timer_enable(struct vastai_pci_info *priv, u32 freq_hz)
{
	int ret = 0;
	struct pcie_transfer_cmd trans;

	if (freq_hz > 1000)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s:error freq_hz %u\n", __func__, freq_hz);
		return -EINVAL;
	}
	
	trans.w0.s_data0.optcode	= SMCU_VSYNC_TIMER_EN;
	trans.w1.data1				= freq_hz;
	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
	if(ret != 0){
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s:failed\n", __func__);
		return -ENODEV;
	}

	return 0;
}

int va_vsync_timer_disable(struct vastai_pci_info *priv)
{
	int ret = 0;
	struct pcie_transfer_cmd trans;
	
	trans.w0.s_data0.optcode = SMCU_VSYNC_TIMER_DIS;

	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
	if(ret != 0){
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"%s:failed\n", __func__);
		return -ENODEV;
	}

	return 0;
}

