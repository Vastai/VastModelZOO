#include "vastai_pci.h"
#include "../va_irq.h"
#include "hw_config.h"
#include "vastai_pcie_public.h"
#include "hw_queue.h"
#include "vastai_pci.h"
#include "vastai_cmd.h"
#include "../smmu.h"
#include "vastai_fifo.h"
#include "sg100_cmd.h"
#include "../vsync/va_vsync.h"
#include "vastai_common.h"
#include "exception.h"

static bool core_exception_en = 1;

char* core_name(struct vastai_pci_info *priv,u8 core_id)
{
	switch(core_id) {
		case SG_CORE_POINT_SMCU:
			return "[SMCU]";

		case SG_CORE_POINT_PMCU:
			return "[CMCU]";

		case SG_CORE_POINT_GMCU0:
			if(PF_4_VF_28 == priv->fn_mode){
				return "[GMCU0]";
			} else {
				return "[VDMCU0]";
			} 		 
		case SG_CORE_POINT_GMCU1:
			return "[GMCU1]";

		case SG_CORE_POINT_GMCU2:
			if(PF_4_VF_28 == priv->fn_mode){
				return "[GMCU2]";
			} else {
				return "[VDMCU1]";
			}  
		case SG_CORE_POINT_GMCU3:
			return "[GMCU3]";

		case SG_CORE_POINT_VDSP0:
			return "[VDSP0]";

		case SG_CORE_POINT_VDSP1:
			return "[VDSP1]";

		case SG_CORE_POINT_CMCU:
			return "[CMCU]";

		case SG_CORE_POINT_OMCU0:
			return "[OMCU0]";

		case SG_CORE_POINT_OMCU1:
			return "[OMCU1]";

		case SG_CORE_POINT_ODSP0:
			return "[ODSP0]";

		case SG_CORE_POINT_ODSP1:
			return "[ODSP1]";

		case SG_CORE_POINT_VEMCU0:
			return "[VEMCU0]";

		case SG_CORE_POINT_VEMCU1:
			return "[VEMCU1]";

		case SG_CORE_POINT_VEMCU2:
			return "[VEMCU2]";

		case SG_CORE_POINT_VEMCU3:
			return "[VEMCU3]";
			
		default:
		return "unknown";
	}
}

void vastai_pci_vemcu_exception(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info)
{    
    u8 core_id;
    //event_notify(die->die_index, msg->info[0], RESET_START);
    core_id = msix_info->w0.s_data0.rev0;
    //w0.s_data0.rev0 is core id, defined hw config.h
    priv->core_status_bitmap |= 1 << msix_info->w0.s_data0.rev0;
    VASTAI_PCI_ERR(priv, priv->pkg_id,"[VASTAI-RAS]%s happen exception, will reset\n",core_name(priv,core_id));
    schedule_work(&priv->exception_work);
}

void vastai_pci_vemcu_reset_ack(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info)
{
    u8 core_id;
    u8  reset_ret;
    priv->core_status_bitmap &= ~(1 << msix_info->w0.s_data0.rev0);
    core_id   = msix_info->w0.s_data0.rev0;
    reset_ret = msix_info->w0.s_data0.rev1;
    //priv->heartbeat_mask &= ~(1 << core_point_to_heartbeat(msg->info[0]));

    //event_notify(die->die_index, msg->info[0], RESET_END);
    if(0 == reset_ret){
        VASTAI_PCI_INFO(priv, priv->pkg_id,"[VASTAI-RAS]receive core reset ack core:%s, success\n",core_name(priv,core_id));
    } else {
        VASTAI_PCI_INFO(priv, priv->pkg_id,"[VASTAI-RAS]receive core reset ack core:%s, fail\n",core_name(priv,core_id));
    }
    return;    
}

void vastai_pci_video_exception(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info)
{
    //info[0]:core_id, info[1]:exception num
    u8  core_id;
    u8  exception_num;
    core_id       = msix_info->w0.s_data0.rev0;
    exception_num = msix_info->w0.s_data0.rev1;
    //event_notify(die->die_index, msg->info[0], msg->info[1]);
    VASTAI_PCI_ERR(priv, priv->pkg_id,
        "[VASTAI-RAS]%s happen exception, exp_num:%x\n",core_name(priv,core_id), exception_num);
}


static void exception_proc_work(struct work_struct *work)
{
	struct vastai_pci_info *priv = container_of(work, struct vastai_pci_info , exception_work);
	u32    core_num = 0;

	//TODO: lock/unlock
	while (priv->core_status_bitmap) {
		core_num = ffs(priv->core_status_bitmap)-1;		
		if (core_exception_en) {
            int ret;
			//vastai_clear_fifo(priv, priv->pkg_id, core_id);
            struct pcie_transfer_cmd trans;
            trans.w0.s_data0.optcode = SG100_VASTAI_PCIE_SUB_CORE_RESET;
            trans.w0.s_data0.rev0 = 0;
            trans.w0.s_data0.rev1 = 0;
            trans.w0.s_data0.rev2 = 0;
            trans.w1.data1        = core_num;
            ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);
            if (ret) {
                VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "push reset cmd fail\n");
            }
		}
		priv->core_status_bitmap &= ~(1 << core_num);
	}

}

void vastai_exception_init_sg(struct vastai_pci_info *priv)
{
	INIT_WORK(&priv->exception_work, exception_proc_work);
	return;
}
