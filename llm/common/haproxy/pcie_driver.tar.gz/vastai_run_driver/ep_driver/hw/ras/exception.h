#ifndef __EXCEPTION_H__
#define __EXCEPTION_H__
/* define core num */
#define SG_CORE_POINT_SMCU				(0)		/* 0x942058 */
#define SG_CORE_POINT_PMCU				(1)		/* 0x94205C */
#define SG_CORE_POINT_CMCU			(2)		/* 0x942060 */
#define SG_CORE_POINT_OMCU0			(3)		/* 0x942064 */
#define SG_CORE_POINT_OMCU1			(4)		/* 0x942068 */
#define SG_CORE_POINT_GMCU0			(5)		/* 0x94206C */
#define SG_CORE_POINT_GMCU1			(6)		/* 0x942070 */
#define SG_CORE_POINT_GMCU2			(7)		/* 0x942074 */
#define SG_CORE_POINT_GMCU3			(8)		/* 0x942078 */
#define SG_CORE_POINT_VEMCU0			(9)		/* 0x94207C */
#define SG_CORE_POINT_VEMCU1			(10)		/* 0x942080 */
#define SG_CORE_POINT_VEMCU2			(11)		/* 0x942084 */
#define SG_CORE_POINT_VEMCU3			(12)		/* 0x942088 */
#define SG_CORE_POINT_ODSP0			(13)		/* 0x94208C */
#define SG_CORE_POINT_ODSP1			(14)		/* 0x942090 */
#define SG_CORE_POINT_VDSP0			(15)		/* 0x942094 */
#define SG_CORE_POINT_VDSP1			(16)		/* 0x942098 */
#define SG_CORE_POINT_VDMCU0			(CORE_POINT_GMCU0)      /* GMCU0/2 will be used as VDMCU0/1 */
#define SG_CORE_POINT_VDMCU1			(CORE_POINT_GMCU2)
#define SG_CORE_TOTAL_NUM			(17)

void vastai_pci_vemcu_reset_ack(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info);
void vastai_pci_vemcu_exception(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info);
void vastai_pci_video_exception(struct vastai_pci_info *priv, struct pcie_transfer_cmd *msix_info);
void vastai_exception_init_sg(struct vastai_pci_info *priv);
#endif