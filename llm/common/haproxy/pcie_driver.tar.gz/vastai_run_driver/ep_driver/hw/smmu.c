/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/07/16
 * Author: jmshi
 */

#include "vastai_pci.h"
#include "smmu.h"
#include "va_dma_core.h"
#include "sg100_gmcu.h"
#include "hw_queue.h"
#include "vastai_pcie_public.h"
#include "vastai_cmd.h"
#include "hw_config.h"
#include "vastai_udma_engine.h"
#ifdef CONFIG_VASTAI_GFX
#include "../../gfx/gfx_mm.h"
#endif

int level0_cnt = 0;
int level1_cnt = 0;
int level2_cnt = 0;
int level3_cnt = 0;

#if 0
static unsigned char *va_smmu_pci_bar_vmem(struct vastai_pci_info *priv, int bar)
{
	if (!priv) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "vastai pcie_dev is NULL\n");
		return NULL;
	}

	return priv->bar[bar].vmem;
}
#endif

static void smmu_read_page_entry(struct vastai_pci_info *priv, u64 page_off, u64 *page)
{
	*page = *(u64 *)((page_off - priv->bar[VASTAI_PCI_BAR4].noc_addr) + priv->bar[VASTAI_PCI_BAR4].vmem);

	return;
}

static void smmu_write_page_entry(struct vastai_pci_info *priv, u64 page_off, u64 *page)
{
	u64 *page_addr;

	page_addr = (u64 *)((page_off - priv->bar[VASTAI_PCI_BAR4].noc_addr) + priv->bar[VASTAI_PCI_BAR4].vmem);
	*page_addr = *page;

	return;
}

static inline int va_smmu_insert_cmd(int optcode, struct vastai_pci_info *priv)
{
	int ret = 0;

	return ret;
}

int smmu_fill_prefetch_cmd_descriptor(struct vastai_pci_info *priv, int optcode, int stream_id, int substream_id, int size, int stride, u64 address)
{
	u8 command[16];
	int addr_high, addr_low;
	int ret;
	struct pcie_transfer_cmd *cmd;

	if (!(optcode == 0x1 || optcode == 0x2))
	{
		VASTAI_PCI_ERR(priv, 0,
				"Invalid prefetch cmd!\n");
	}

	address = address >> 12;
	addr_high = (u32)((u64)address >> 32) & 0xFFFFF;
	addr_low  = (u32)((u64)address & 0xFFFFFFFF);

	command[0]  = (u8)optcode;
	command[1]	= (u8)(((substream_id & 0xF) << 4) | 0x8);
	command[2]  = (u8)(((substream_id >> 4) & 0xFF));
	command[3]  = (u8)(((substream_id >> 12) & 0xFF));

	command[4]  = (u8)( stream_id 	   & 0xFF);
	command[5]  = (u8)((stream_id >> 8)  & 0xFF);
	command[6]  = (u8)((stream_id >> 16) & 0xFF);
	command[7]  = (u8)((stream_id >> 24) & 0xFF);

	if (optcode == 0x2)
	{
		command[8]  = (u8)((size & 0x1f) || stride & 0x7);
		command[9]  = (u8)((addr_high & 0xf) << 4) || ((stride >> 3) & 0x3);
		command[10] = (u8)((addr_high >> 4) & 0xFF);
		command[11] = (u8)((addr_high >> 12) & 0xFF);
		command[12] = (u8)((addr_low)       & 0xFF);
		command[13] = (u8)((addr_low >> 8)  & 0xFF);
		command[14] = (u8)((addr_low >> 16) & 0xFF);
		command[15] = (u8)((addr_low >> 24) & 0xFF);
	}
	else
	{
		command[8]  = 0;
		command[9]  = 0;
		command[10] = 0;
		command[11] = 0;
		command[12] = 0;
		command[13] = 0;
		command[14] = 0;
		command[15] = 0;
	}

	cmd = (struct pcie_transfer_cmd *)command;
	if ( ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF,  cmd, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF,  cmd, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF,  cmd, 0);
	}

	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"h2d_cmd_test error\n");
	}

	return 0;

//	return smmu_add_command(command);
}

int smmu_fill_cfg_invalid_cmd_descriptor(struct vastai_pci_info *priv, int optcode, int substream_id, int leaf)
{
	u8 command[16];
	int ret;
	struct pcie_transfer_cmd *cmd;

	if (!(optcode == 0x3 || optcode == 0x4 || optcode == 0x5 || optcode == 0x6))
	{
		VASTAI_PCI_ERR(priv, 0,
				"Invalid cfg cmd!\n");
	}

	command[0]  = (u8)optcode;
	if (0x5 == optcode)
	{
		command[1]	= (u8)(((substream_id & 0xF) << 4) | 0x8);
		command[2]  = (u8)(((substream_id >> 4) & 0xFF));
		command[3]  = (u8)(((substream_id >> 12) & 0xFF));
	}
	else
	{
		command[1]  = 0;
		command[2]  = 0;
		command[3]  = 0;
	}


	/* get  streamid from fw */
	command[4] = 0;
	command[5] = 0;
	command[6] = 0;
	command[7] = 0;


	if (0x4 == optcode)
	{
		command[8]  = 31;
	}
	else if (0x6 == optcode)
	{
		command[8]  = 0;
	}
	else
	{
		command[8]  = leaf;
	}

	command[9]  = 0;
	command[10] = 0;
	command[11] = 0;
	command[12] = 0;
	command[13] = 0;
	command[14] = 0;
	command[15] = 0;

	cmd = (struct pcie_transfer_cmd *)command;
	if ( ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF, cmd, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	}
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"h2d_cmd_test error\n");
	}


	return 0;
//	return smmu_add_command(command);
}

int smmu_fill_tlb_invalid_cmd_descriptor(struct vastai_pci_info *priv, int optcode, int asid, int leaf, u64 address, u32 range)
{
	u8 command[16];
	int addr_high, addr_low;
	int ret;
	struct pcie_transfer_cmd *cmd;
	int num = 0, scale=0, tg=1, ttl=3;

	if (!(optcode == 0x10 || optcode == 0x11 || optcode == 0x12 || optcode == 0x13 || optcode == 0x30))
	{
		VASTAI_PCI_ERR(priv, 0,
				"Invalid cfg cmd!\n");

	}

	if (0x12 == optcode)
	{
		scale = ffs(range >> 12) - 1;
		num = range/(1<<(scale + VA_PTE_SHIFT)) - 1;
		tg = 1; // 4k page_siez
		ttl = 3;
		VASTAI_PCI_INFO(priv, 0,
				"va:%#llx, range:%#x, scale:%d, num:%d\n", address, range, scale, num);
	}

	addr_high = (u32)((u64)address >> 32) & 0xFFFFFFFF;
	addr_low  = (u32)((u64)address & 0xFFFFFFFF) >> 12;

	command[0]  = (u8)optcode;

	if (0x12 == optcode)
	{
		command[1]  = (u8)((num & 0xf) << 4);
		command[2]  = (u8)((num >> 4) | ((scale & 0xf) << 4));
		command[3]  = (u8)(scale >> 4);
	}
	else
	{
		command[1]  = 0;
		command[2]  = 0;
		command[3]  = 0;
	}

	command[4]  = 0;
	command[5]  = 0;

	if (0x11 == optcode || 0x12 == optcode)
	{
		command[6]	= (u8)(asid         & 0xFF);
		command[7]	= (u8)((asid >> 24) & 0xFF);
	}
	else
	{
		command[6]  = 0;
		command[7]  = 0;
	}

	if (0x12 == optcode || 0x13 == optcode)
	{
		command[8]  = leaf;
		command[9]  = (u8)((addr_low & 0xF) << 4 | (tg << 2) | ttl);
#if 0
		command[10] = (u8)((addr_high >> 4)  & 0xFF);
		command[11] = (u8)((addr_high >> 12) & 0xFF);
		command[12] = (u8)((addr_low)       & 0xFF);
		command[13] = (u8)((addr_low >> 8)  & 0xFF);
		command[14] = (u8)((addr_low >> 16) & 0xFF);
		command[15] = (u8)((addr_low >> 24) & 0xFF);
#endif
		command[10] = (u8)((addr_low >> 4)  & 0xFF);
		command[11] = (u8)((addr_low >> 12) & 0xFF);
		command[12] = (u8)((addr_high)       & 0xFF);
		command[13] = (u8)((addr_high >> 8)  & 0xFF);
		command[14] = (u8)((addr_high >> 16) & 0xFF);
		command[15] = (u8)((addr_high >> 24) & 0xFF);
	}
	else
	{
		command[8]  = 0;
		command[9]  = 0;
		command[10] = 0;
		command[11] = 0;
		command[12] = 0;
		command[13] = 0;
		command[14] = 0;
		command[15] = 0;
	}

	cmd = (struct pcie_transfer_cmd *)command;
	if (ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF, cmd, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	}

	if(ret!=0) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"h2d_cmd_test error\n");
	}


	return 0;

//	return smmu_add_command(command);
}

void smmu_fill_tlb_invalid_cmd_descriptor_port(void *devInfo, u64 address, u32 range)
{
#if 0
       struct vastai_pci_info *priv =(struct vastai_pci_info *)devInfo;
       mutex_lock(&priv->vastai_smmu_info->pid_lock);
       smmu_fill_tlb_invalid_cmd_descriptor(priv, 0x30, 0, 1, address, range);
       mutex_unlock(&priv->vastai_smmu_info->pid_lock);
#endif
}

EXPORT_SYMBOL(smmu_fill_tlb_invalid_cmd_descriptor_port);

int smmu_fill_resum_cmd_descriptor(struct vastai_pci_info *priv, int stream_id, int stag, int action)
{
	u8 command[16];
	int ret;
	struct pcie_transfer_cmd *cmd;

	command[0]	= (u8)0x44;

	command[1]  = ((u8)((action & 0x3) << 4));;
	command[2]	= 0;
	command[3]	= 0;

	command[4]  = (u8)( stream_id 	   & 0xFF);
	command[5]  = (u8)((stream_id >> 8)  & 0xFF);
	command[6]  = (u8)((stream_id >> 16) & 0xFF);
	command[7]  = (u8)((stream_id >> 24) & 0xFF);

	command[8]  = (u8)( stag	& 0xFF);
	command[9]  = (u8)((stag	>> 8)  & 0xFF);

	command[10] = 0;
	command[11] = 0;
	command[12] = 0;
	command[13] = 0;
	command[14] = 0;
	command[15] = 0;

	cmd = (struct pcie_transfer_cmd *)command;
	if (ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF, cmd, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	}
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"h2d_cmd_test error\n");
	}


	return 0;

//	return smmu_add_command(command);
}


int smmu_fill_sync_cmd_descriptor(struct vastai_pci_info *priv)
{
#if 0
	u8 command[16];
	int addr_high, addr_low;
	int ret;
	struct pcie_transfer_cmd *cmd;
	int cs = 0x1, msh = 0, msi_attr=0, msi_data;
	u64 msi_addr = 0x8f9800;
//	u64 msi_addr = 0;
	int pf = priv->priv_hw_cfg->sys_cfg.pfn , vf_active = priv->priv_hw_cfg->sys_cfg.vf_active, vf = priv->priv_hw_cfg->sys_cfg.vfn, vector = 15;

	msi_data = (pf << 24) | (vf_active ? (1 << 15 | vf << 16) : 0) | vector;
//	msi_data = 0;
	addr_high = (u32)((u64)msi_addr >> 32) & 0xFFFFF;
	addr_low  = (u32)((u64)msi_addr & 0xFFFFFFFC);

	command[0] = (u8)0x46;

	command[1] = (u8)((cs & 0x3) << 4);
	command[2] = (u8)((msh & 0x3) << 6);
	command[3] = (u8)(msi_attr & 0xF);

	command[4] = (u8)( msi_data 	& 0xFF);
	command[5] = (u8)((msi_data >> 8)	& 0xFF);
	command[6] = (u8)((msi_data >> 16) & 0xFF);
	command[7] = (u8)((msi_data >> 24) & 0xFF);

	command[8]	= (u8)(addr_low & 0xFF);
	command[9]	= (u8)((addr_low >> 8)	& 0xFF);
	command[10] = (u8)((addr_low >> 16) & 0xFF);
	command[11] = (u8)((addr_low >> 24) & 0xFF);
	command[12] = (u8)(addr_high  & 0xFF);
	command[13] = (u8)((addr_high >> 8) & 0xFF);
	command[14] = (u8)((addr_high >> 16) & 0xF);
	command[15] = 0;

	cmd = (struct pcie_transfer_cmd *)command;
	if (ONLY_1_PF==priv->fn_mode) {
		ret = vastai_pci_send_msg(priv, 0, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF, cmd, 0);
	} else if (ONLY_2_PF==priv->fn_mode){
		ret = vastai_pci_send_msg(priv, 0, ONLY_2PF_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	} else {
		ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_GMCU_CMD_BUF, cmd, 0);
	}
	if(ret!=0){
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,"h2d_cmd_test error\n");
	}
#endif
	u32 msi_data, data, msi_addr;
	int pf = priv->priv_hw_cfg->sys_cfg.pfn;
	int vf_active = priv->priv_hw_cfg->sys_cfg.vf_active;
	int vf = priv->priv_hw_cfg->sys_cfg.vfn, vector = 15;
#ifdef VASTAI_PERFORMANCE_TEST
	static unsigned long max_time = 0;
	static unsigned long times = 0;
	unsigned long start, end;
#endif

	msi_data = (pf << 24) | (vf_active ? (1 << 15 | vf << 16) : 0) | vector;

	switch(pf)
	{
		case 0: msi_addr = 0x8e0000;break;
		case 1: msi_addr = 0x8e0010;break;
		case 2: msi_addr = 0x8e0020;break;
		case 3: msi_addr = 0x8e0030;break;
		default: msi_addr = 0x8e0000;break;
	}

	priv->vastai_smmu_info->sync_cnt++;

#ifdef VASTAI_PERFORMANCE_TEST
	printk("%s start(%06d)\n", __func__, priv->vastai_smmu_info->sync_cnt);
	start = ktime_get();
#endif
	do
	{
		vastai_pci_mem_read(priv, 0, msi_addr, &data, 4);
	}while(msi_data!=data);

#ifdef VASTAI_PERFORMANCE_TEST
	end = ktime_get();

	max_time = (max_time > (end - start)) ? max_time : (end - start);
	times++;
	if(times % 100 == 0)
	{
		printk("%s max_sync=%06lu", __func__, max_time / 1000);
	}
	printk("%s sync time=%06lu us, end(%06d)", __func__, (end - start)/1000, priv->vastai_smmu_info->sync_cnt);
	//priv->vastai_smmu_info->cmd_sync_done_u32 = 0;
#endif
	data = 0;
	vastai_pci_mem_write(priv, 0, msi_addr, &data, 4);

	return 0;
}

static u64 alloc_mem_from_ddk(struct vastai_pci_info *priv, int size, int level)
{
	u64 alloc_addr = 0;

#ifdef CONFIG_DDK_ALLOC_MEM
	u64 ddk_addr = priv->alloc_physmem_by_ddk(size);
	alloc_addr = ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base  32) | priv->priv_hw_cfg->header.lo32_ddr_base) +
						ddk_addr - 0x1040000000;
#else

	if (size != PAGE_MAX_INDEX * PAGE_ENTRY_SIZE)
		return 0;

#if CONFIG_D2H_BY_GART_OR_ATU
	if(priv->hasInitGfxMemAlloc)
	{
		u64 ddk_addr = priv->AllocMemFromGfxHeap(priv->heapPtr, size);
		u64 data = 0;
		int i = 0;
		u64 *page_addr;

		alloc_addr = ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base << 32) | priv->priv_hw_cfg->header.lo32_ddr_base) +
							ddk_addr - 0x1040000000ULL;

		while(i < PAGE_MAX_INDEX)
		{
			page_addr = (u64 *)((alloc_addr + (i * PAGE_ENTRY_SIZE) - priv->bar[VASTAI_PCI_BAR4].noc_addr) + priv->bar[VASTAI_PCI_BAR4].vmem);
			*page_addr = data;
			i++;
		}
	}
	else
#endif
	{
		switch (level)
		{
			case LEVEL0: {
				alloc_addr = 0x1040000000 + level0_cnt * size;
				if(alloc_addr > 0x1040010000)
				{
					alloc_addr = 0x104000000;
					level0_cnt = 0;
				}
				level0_cnt++;
				break;
				}
			case LEVEL1: {
				alloc_addr = 0x1040010000 + level1_cnt * size;
				if(alloc_addr > 0x1040020000)
				{
					alloc_addr = 0x1040010000;
					level1_cnt = 0;
				}
				level1_cnt++;
				break;
				}
			case LEVEL2: {
				alloc_addr = 0x1040020000 + level2_cnt * size;
				if(alloc_addr > 0x1040030000)
				{
					alloc_addr = 0x1040020000;
					level2_cnt = 0;
				}
				level2_cnt++;
				break;
				}
			case LEVEL3: {
				alloc_addr = 0x1040030000 + level3_cnt * size;
				if(alloc_addr > 0x1040040000)
				{
					alloc_addr = 0x1040030000;
					level3_cnt = 0;
				}
				level3_cnt++;
				break;
				}
			default:
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
						"Unsupport level 0x%x\n", level);
			break;
		}
	}
#endif

	return alloc_addr;
}

static void free_mem_from_ddk(struct vastai_pci_info *priv, u64 phy)
{
#ifdef CONFIG_DDK_ALLOC_MEM
	u64 ddk_addr;

	ddk_addr = phy - ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base << 32) | priv->priv_hw_cfg->header.lo32_ddr_base)
						 + 0x1040000000;
	priv->free_physmem_by_ddk(ddk_addr);
#else

	if (phy > 0x1040000000 && phy < 0x1040040000)
	{
		phy = 0;
		phy = phy;
		return;
	}

#if CONFIG_D2H_BY_GART_OR_ATU
	if (priv->hasInitGfxMemAlloc)
	{
		u64 ddk_addr;
		ddk_addr = phy - ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base << 32) | priv->priv_hw_cfg->header.lo32_ddr_base)
							+ 0x1040000000;
		priv->FreeMemToGfxHeap(priv->heapPtr, ddk_addr);
	}
	else
#endif
	{
		phy = 0;
		phy = phy;
	}
#endif
	return;
}

static int get_pid_info(struct vastai_pci_info *priv, int pid, struct vastai_pid_pt_entry_info **pid_info)
{
	int ret = 0;
	struct vastai_pid_pt_entry_info *cur_pid;

	int cur_pid_num = priv->vastai_smmu_info->pid_cnt;

	if (!cur_pid_num)
	{
		ret = VASTAI_EMPTY;
		return ret;
	}

	list_for_each_entry (cur_pid, &priv->vastai_smmu_info->pid_head, node) {
		if (cur_pid->pid == pid) {
			*pid_info = cur_pid;
			ret = VASTAI_MATCH;
			return ret;
		}
	}

	ret = VASTAI_NULL;
	return ret;
}

static int va_is_already_map(u64 va, struct va_translation_info *cur_tl)
{
	/*0: don't map 1: already map*/
	return ((va >= cur_tl->va) && (va <= (cur_tl->va + cur_tl->size - 1))
				&& (ENTRY_MAGIC_NUM == cur_tl->magic_number));
}

static int pa_is_already_map(u64 pa, struct va_translation_info *cur_tl)
{
	/*0: don't map 1: already map*/
	return ((pa >= cur_tl->pa) && (pa <= (cur_tl->pa + cur_tl->size - 1))
				&& (ENTRY_MAGIC_NUM == cur_tl->magic_number));
}

static int check_page_is_mapped(struct vastai_pci_info *priv, u64 va, struct vastai_pid_pt_entry_info *pid_info, struct va_translation_info **tl_info)
{
	int ret = 0;
	struct va_translation_info *cur_tl;
	int cur_tl_num = pid_info->tl_info_cnt;

	if (!cur_tl_num)
	{
		//VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "entry list empty! #######\n");
		return ret;
	}

	list_for_each_entry (cur_tl, &pid_info->entry_head, node) {
		if (va_is_already_map(va, cur_tl))
		{
			*tl_info = cur_tl;
			return 1;
		}
	}

	return ret;
}

u64 va_virt_to_phys(struct vastai_pci_info *priv, u64 va, int pid)
{
	int ret = 0;
	struct va_translation_info *cur_tl;
	struct vastai_pid_pt_entry_info *pt_info;
	int cur_tl_num = 0;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return 0;
	}

	cur_tl_num = pt_info->tl_info_cnt;

	if (!cur_tl_num)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "entry list empty! #######\n");
		return 0;
	}

	list_for_each_entry (cur_tl, &pt_info->entry_head, node) {
		if (va_is_already_map(va, cur_tl))
		{
			return (va - cur_tl->va + cur_tl->pa);
		}
	}

	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "don't have matched entry\n");
	return 0;

}

u64 va_phys_to_virt(struct vastai_pci_info *priv, u64 pa, int pid)
{
	int ret = 0;
	struct va_translation_info *cur_tl;
	struct vastai_pid_pt_entry_info *pt_info;
	int cur_tl_num = 0;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return 0;
	}

	cur_tl_num = pt_info->tl_info_cnt;

	if (!cur_tl_num)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "entry list empty! #######\n");
		return 0;
	}

	list_for_each_entry (cur_tl, &pt_info->entry_head, node) {
		if (pa_is_already_map(pa, cur_tl))
		{
			return (pa - cur_tl->pa + cur_tl->va);
		}
	}

	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "don't have matched entry\n");
	return 0;

}

int get_page_entry_info(struct vastai_pci_info *priv, u64 va, int pid)
{
	int ret = 0;
	struct vastai_pid_pt_entry_info *pt_info;
	u64 page;
	u64 pgd_base, addr;
	u64 entry_off;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return ret;
	}

	if ((va >> 48) & VA_TYPE_CHECK)
	{
		pgd_base = pt_info->ttb1_pgd_base;
	}
	else
	{
		pgd_base = pt_info->ttb0_pgd_base;
	}

	entry_off = pgd_base + va_pgd_index(va) * PAGE_ENTRY_SIZE;
//	ret = vastai_read_by_smcu(priv, entry_off, PAGE_ENTRY_SIZE, &page);
	ret = vastai_pci_mem_read(priv, 0, entry_off, &page, PAGE_ENTRY_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pgd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "PGD Entry 0x%llx:[0x%llx]\n", entry_off, page);

	addr = page & PAGE_ADDR_MASK;
	entry_off = addr + va_pud_index(va) * PAGE_ENTRY_SIZE;
//	ret = vastai_read_by_smcu(priv, entry_off, PAGE_ENTRY_SIZE, &page);
	ret = vastai_pci_mem_read(priv, 0, entry_off, &page, PAGE_ENTRY_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pud entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "PUD Entry 0x%llx:[0x%llx]\n", entry_off, page);

	addr = page & PAGE_ADDR_MASK;
	entry_off = addr + va_pmd_index(va) * PAGE_ENTRY_SIZE;
//	ret = vastai_read_by_smcu(priv, entry_off, PAGE_ENTRY_SIZE, &page);
	ret = vastai_pci_mem_read(priv, 0, entry_off, &page, PAGE_ENTRY_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "PMD Entry 0x%llx:[0x%llx]\n", entry_off, page);

	addr = page & PAGE_ADDR_MASK;
	entry_off = addr + va_pte_index(va) * PAGE_ENTRY_SIZE;
//	ret = vastai_read_by_smcu(priv, entry_off, PAGE_ENTRY_SIZE, &page);
	ret = vastai_pci_mem_read(priv, 0, entry_off, &page, PAGE_ENTRY_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pte entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "PTE Entry 0x%llx:[0x%llx]\n", entry_off, page);

	return ret;
}

void walk_translation_info(struct vastai_pci_info *priv, int pid)
{
	int i = 0, ret = 0;
	struct va_translation_info *cur_tl;
	struct vastai_pid_pt_entry_info *pt_info;
	int cur_tl_num = 0;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return;
	}

	cur_tl_num = pt_info->tl_info_cnt;

	if (!cur_tl_num)
	{
		ret = 1;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "entry list empty! #######\n");
		return;
	}

	list_for_each_entry (cur_tl, &pt_info->entry_head, node) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "Entry[%4d] va:0x%016llx, pa:0x%016llx, maping_count:%2d\n", i, cur_tl->va, cur_tl->pa, cur_tl->map_cnt);
		get_page_entry_info(priv, cur_tl->va, pid);
		i++;
	}

	return;
}

static int page_entry_valid_check(struct vastai_pci_info *priv, void *entry)
{
	PAGE_INFO *page = (PAGE_INFO *)entry;

	/* page entry valid return 0, otherwise return 1*/
	return ((page->attr0 != 0x0) || (page->attr1 != 0x0) || (page->attr2 != 0x0) || (page->attr3 != 0x0) ||
		(page->attr4 != 0x3));//|| (page->outaddr_47_32 != (u32)(priv->vastai_smmu_info->cd_base >> 32)));
}

static u64 get_next_level_entry_phys(struct vastai_pci_info *priv, void *entry)
{
	PAGE_INFO *page = (PAGE_INFO *)entry;
	u64 hi_addr, lo_addr;

	if (page_entry_valid_check(priv, entry))
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Invalid page entry!\n");
		return 0;
	}

	hi_addr = (u64)page->outaddr_47_32 << 32;
	lo_addr = (u64)page->outaddr_31_12 << 12;

	return hi_addr | lo_addr;
}

static u64 translate_idx_to_va(int pgd_idx, int pud_idx, int pmd_idx, int pte_idx)
{
	return ((u64)pgd_idx << VA_PGD_SHIFT) | ((u64)pud_idx << VA_PUD_SHIFT) | ((u64)pmd_idx << VA_PMD_SHIFT) |  ((u64)pte_idx << VA_PTE_SHIFT);
}

void walk_page_from_dev(struct vastai_pci_info *priv, int pid)
{
	int ret = 0;
	int pgd_idx = 0;
	u64 pgd_base, va_base;
	struct vastai_pid_pt_entry_info *pt_info;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, 0, "Can't find PID(%d) info\n", pid);
		return;
	}

	mutex_lock(&pt_info->entry_lock);
	pgd_base = pt_info->ttb0_pgd_base;
	/* gpu addr*/
	va_base = 0x0;
free_page:
	while(pgd_idx < PAGE_MAX_INDEX)
	{
		u64 pgd, pgd_off;

		pgd_off = pgd_base + pgd_idx * PAGE_ENTRY_SIZE;
		smmu_read_page_entry(priv, pgd_off, &pgd);

		//if pgd is valid, goto free pud
		if (!page_entry_valid_check(priv, &pgd))
		{
			int pud_idx = 0;
			while(pud_idx < PAGE_MAX_INDEX)
			{
				u64 pud, pud_off, pud_base = get_next_level_entry_phys(priv, &pgd);
				pud_off = pud_base + pud_idx * PAGE_ENTRY_SIZE;
				smmu_read_page_entry(priv, pud_off, &pud);

				//if pud is valid, goto free pmd
				if (!page_entry_valid_check(priv, &pud))
				{
					int pmd_idx = 0;
					while(pmd_idx < PAGE_MAX_INDEX)
					{
						u64 pmd, pmd_off, pmd_base = get_next_level_entry_phys(priv, &pud);
						pmd_off = pmd_base + pmd_idx * PAGE_ENTRY_SIZE;
						smmu_read_page_entry(priv, pmd_off, &pmd);

						//if pmd is valid, free pmd
						if (!page_entry_valid_check(priv, &pmd))
						{
							int pte_idx = 0;
							while(pte_idx < PAGE_MAX_INDEX)
							{
								u64 pte, pte_off, pte_base = get_next_level_entry_phys(priv, &pmd);
								pte_off = pte_base + pte_idx * PAGE_ENTRY_SIZE;
								smmu_read_page_entry(priv, pte_off, &pte);

								//if pmd is valid, free pmd
								if ((pte & PTE_VALIDE_CHECK) == PTE_VALIDE_CHECK)
								{
									VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "[walk_page]va:0x%016llx, pa:0x%016llx!\n",
											va_base + translate_idx_to_va(pgd_idx, pud_idx, pmd_idx, pte_idx), pte & PAGE_ADDR_MASK);
								}
								pte_idx++;
							}
						}
						pmd_idx++;
					}
				}
				pud_idx++;
			}
		}
		pgd_idx++;
	}

	if (pgd_base != pt_info->ttb1_pgd_base)
	{
		pgd_idx = 0;
		/* cpu addr */
		va_base = 0xFFFF000000000000;
		pgd_base = pt_info->ttb1_pgd_base;
		goto free_page;
	}
	mutex_unlock(&pt_info->entry_lock);

	return;
}

#if 0
static int add_page_info(struct vastai_pci_info *priv, u64 va, u64 pa, u32 page_count, struct vastai_pid_pt_entry_info *pt_info, int s_bit)
{
	int ret = 0;
	int i;
	struct va_translation_info *tl_info;

	for (i = 0; i < page_count; i++)
	{
		tl_info = kzalloc(sizeof(struct va_translation_info), GFP_KERNEL);
		if (!tl_info) {
			VASTAI_PCI_ERR(priv, 0,
					"tl_info kmalloc fail, %d\n", i);
			ret = 1;
			return ret;
		}

		tl_info->pa = pa;
		tl_info->va = va;
		tl_info->size = VASTAI_PAGE_SIZE;
		tl_info->s_bit = s_bit;
		tl_info->magic_number = ENTRY_MAGIC_NUM;
		tl_info->map_cnt = 1;

		list_add(&(tl_info->node) , &(pt_info->entry_head));
		pt_info->tl_info_cnt += 1;

		tl_info = NULL;
		pa += VASTAI_PAGE_SIZE;
		va += VASTAI_PAGE_SIZE;
	}


#if 0
	for (i = 0; i < page_count; i++)
	{
		tl_info->pa = pa;
		tl_info->va = va;
		tl_info->size = VASTAI_PAGE_SIZE;
		tl_info->s_bit = s_bit;
		tl_info->magic_number = ENTRY_MAGIC_NUM;
		tl_info->map_cnt = 1;
		list_add(&(tl_info->node) , &(pt_info->entry_head));
		pt_info->tl_info_cnt += 1;
		tl_info++;
		pa += VASTAI_PAGE_SIZE;
		va += VASTAI_PAGE_SIZE;
	}
#endif

	return ret;
}
#endif

static int init_pte(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pmd *pmdp,
								u64 addr, u64 end, u64 pa, int s_bit)
{
	pte ptep;
	pte new_ptep;
	u64 pte_phys, pte_idx;
	int pa_low, pa_high;
	int ret = 0;
	u64 pte_off;

#if 0
	ptep = kzalloc(PAGE_MAX_INDEX * sizeof(*ptep), GFP_KERNEL);
	if (!ptep) {
		VASTAI_PCI_ERR(priv, 0,
				"pte kmalloc fail\n");
		ret = -ENOMEM;
		return ret;
	}

	new_ptep = kzalloc(PAGE_MAX_INDEX * sizeof(*ptep), GFP_KERNEL);
		if (!new_ptep) {
			VASTAI_PCI_ERR(priv, 0,
					"pte kmalloc fail\n");
			ret = -ENOMEM;
			return ret;
		}
#endif

	pte_phys = get_next_level_entry_phys(priv, pmdp);
	if(!pte_phys)
	{
		ret = -EPERM;
		//goto err;
		return ret;
	}

	do {

		pte_idx = va_pte_index(addr);

		pa_high = (int)(((u64)(pa) >> 32) & 0xFFFFFFFF);
		pa_low  = (int)((u64)(pa) & 0xFFFFFFFF);

		ptep.attr0 = 0;
		ptep.attr1 = s_bit;
		ptep.attr2 = 0;
		ptep.outaddr_47_32 = pa_high & 0xFFFF;
		ptep.outaddr_31_12 = pa_low >> 12;
		ptep.attr3 = 0x11f;
		ptep.attr4 = 3;

		pte_off = pte_phys + (va_pte_index(addr) * PAGE_ENTRY_SIZE);
		VASTAI_PCI_DBG(priv, 0,"create pte(%#llx) in %#llx\n", addr, pte_off);

		smmu_write_page_entry(priv, pte_off, (u64 *)&ptep);
		smmu_read_page_entry(priv, pte_off, (u64 *)&new_ptep);
#if 0
		ret = vastai_pci_mem_write(priv, 0, pte_off, ptep, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s write pte rntry information to dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto err;
		}

		ret = vastai_pci_mem_read(priv, 0, pte_off, new_ptep, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pmd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto err;
		}
#endif

		if (ptep.outaddr_31_12 != new_ptep.outaddr_31_12)
		{
			VASTAI_PCI_ERR(priv, 0,
					"init pte failed, read & write don't match\n");
			ret = INIT_PTE_FAIL;
			//goto err;
			return ret;
		}

		//mutex_lock(&pt_info->entry_lock);
//		add_page_info(priv, addr, pa, 1, pt_info, s_bit);
		//mutex_unlock(&pt_info->entry_lock);

		pa += VASTAI_PAGE_SIZE;
	} while (addr += VASTAI_PAGE_SIZE, addr < end);

//err:
//	kfree(ptep);
//	kfree(new_ptep);
	return ret;
}

static int alloc_init_cont_pte(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pud *pudp,
										pmd *pmdp, u64 addr, u64 end, u64 pa, int s_bit)
{
	u64 next;
	u64 pte_phys, pmd_off;
	int ret = 0;
	pmd new_pmdp;

	if (page_entry_valid_check(priv, pmdp)) {
		u64 pmd_phys;
		pte_phys = alloc_mem_from_ddk(priv, PAGE_ENTRY_SIZE * PAGE_MAX_INDEX, LEVEL3);


		pmdp->attr0 = 0;
		pmdp->attr1 = 0;
		pmdp->attr2 = 0;
		pmdp->outaddr_47_32 = (u32)(((u64)(pte_phys) >> 32)) & 0xFFFF;
		pmdp->outaddr_31_12 = (u32)((u64)(pte_phys) & 0xFFFFFFFF) >> 12;
		pmdp->attr3 = 0;
		pmdp->attr4 = 3;

		pmd_phys = get_next_level_entry_phys(priv, pudp);
		if(!pmd_phys)
		{
			ret = INIT_PTE_FAIL;
			goto err;
		}
		pmd_off = pmd_phys + PAGE_ENTRY_SIZE * va_pmd_index(addr);
		//VASTAI_PCI_INFO(priv, 0, " malloc from ddk get pte_phys0x%llx\n", pte_phys);
#if 0
		ret = vastai_pci_mem_write(priv, 0, pmd_off, pmdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s write pmd entry information to dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto err;
		}
#endif
		smmu_write_page_entry(priv, pmd_off, (u64 *)pmdp);
#if 0

		new_pmdp = kzalloc(PAGE_MAX_INDEX * sizeof(*pmdp), GFP_KERNEL);
		if (!new_pmdp) {
			VASTAI_PCI_ERR(priv, 0,
					"pte kmalloc fail\n");
			ret = -ENOMEM;
			goto err;
		}


		ret = vastai_pci_mem_read(priv, 0, pmd_off, new_pmdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pmd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto err_free;
		}
#endif
		smmu_read_page_entry(priv, pmd_off, (u64 *)&new_pmdp);
		if (pmdp->outaddr_31_12 != new_pmdp.outaddr_31_12)
		{
			VASTAI_PCI_ERR(priv, 0,
					"init pmd failed, read & write don't match\n");
			ret = INIT_PTE_FAIL;
			goto err;
		}

	}

	do {
		next = va_pte_addr_end(addr, end);
		ret = init_pte(priv, pt_info, pmdp, addr, next, pa, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s init pte failed! %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto err;
		}

		pa += next - addr;
	} while (addr = next, addr < end);

	return ret;

err:
	free_mem_from_ddk(priv, pte_phys);
	return ret;
}

static int init_pmd(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pud *pudp, u64 addr,
								u64 end, u64 pa, int s_bit)
{
	u64 next, pmd_phys, pmd_idx;
	pmd pmdp;
	int ret = 0;
	pmd old_pmd;

	pmd_phys = get_next_level_entry_phys(priv, pudp);
	if(!pmd_phys)
	{
		ret = INIT_PMD_FAIL;
		//goto err;
		return ret;
	}

	do {
		pmd_idx = va_pmd_index(addr);

		smmu_read_page_entry(priv, pmd_phys + pmd_idx *  PAGE_ENTRY_SIZE, (u64 *)&pmdp);
		old_pmd = pmdp;

		next = va_pmd_addr_end(addr, end);
		ret = alloc_init_cont_pte(priv, pt_info, pudp, &pmdp, addr, next, pa, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s init pte failed! %d\n",
					__func__, ret);
			ret = INIT_PMD_FAIL;
			//goto err;
			return ret;
		}

		if ((old_pmd.attr4 != 0) &&
				((old_pmd.outaddr_31_12 != pmdp.outaddr_31_12) || (old_pmd.outaddr_47_32 != pmdp.outaddr_47_32)))
		{
			VASTAI_PCI_ERR(priv, 0,
				"current pud entry(%d) have already init!\n", (u32)va_pmd_index(addr));
			//goto err;
			return ret;
		}

		pa += next - addr;
	} while (addr = next, addr < end);

//err:
//	kfree(pmdp);
	//need to free alloc_init_cont_pte();
	return ret;
}

static int alloc_init_cont_pmd(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pgd *pgdp,
											pud *pudp, u64 addr, u64 end, u64 pa, int s_bit)
{
	u64 next;
	u64 pmd_phys;
	int ret = 0;
	pud new_pudp;

	if (page_entry_valid_check(priv, pudp)) {
		u64 pud_off;
		u64 pud_phys;
		pmd_phys = alloc_mem_from_ddk(priv, PAGE_ENTRY_SIZE * PAGE_MAX_INDEX, LEVEL2);

		pudp->attr0 = 0;
		pudp->attr1 = 0;
		pudp->attr2 = 0;
		pudp->outaddr_47_32 = (u32)(((u64)(pmd_phys) >> 32)) & 0xFFFF;
		pudp->outaddr_31_12 = (u32)((u64)(pmd_phys) & 0xFFFFFFFF) >> 12;
		pudp->attr3 = 0;
		pudp->attr4 = 3;

		pud_phys = get_next_level_entry_phys(priv, pgdp);
		if(!pud_phys)
		{
			ret = INIT_PUD_FAIL;
			goto err;
		}
		pud_off =pud_phys + PAGE_ENTRY_SIZE * va_pud_index(addr);

		smmu_write_page_entry(priv, pud_off, (u64 *)pudp);

		smmu_read_page_entry(priv, pud_off, (u64 *)&new_pudp);
		if (pudp->outaddr_31_12 != new_pudp.outaddr_31_12)
		{
			VASTAI_PCI_ERR(priv, 0,
					"init pud failed, read & write don't match\n");
			ret = INIT_PUD_FAIL;
			goto err;
		}

//		kfree(new_pudp);
	}

	do {
		next = va_pmd_addr_end(addr, end);
		ret = init_pmd(priv, pt_info, pudp, addr, next, pa, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s init pmd failed! %d\n",
					__func__, ret);
			ret = INIT_PMD_FAIL;
			goto err;
		}

		pa += next - addr;
	} while (addr = next, addr < end);

	return ret;

//err_free:
//	kfree(new_pudp);
err:
	free_mem_from_ddk(priv, pmd_phys);
	return ret;
}

static int alloc_init_pud(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pgd *pgdp,
									u64 addr, u64 end, u64 pa, u64 pgd_base, int s_bit)
{
	int ret = 0;
	u64 next, pud_idx;
	pud pudp;
	u64 pud_phys;
	pud old_pud;
	pgd new_pgdp;

#if 0
	pudp = kzalloc(sizeof(*pudp), GFP_KERNEL);
	if (!pudp) {
		VASTAI_PCI_ERR(priv, 0,
				"pud kmalloc fail\n");
		ret = INIT_PUD_FAIL;
		return ret;
	}
#endif

	if (page_entry_valid_check(priv, pgdp))
	{

		u64 pgd_off;
		pud_phys = alloc_mem_from_ddk(priv, PAGE_ENTRY_SIZE * PAGE_MAX_INDEX, LEVEL1); //alloc 4k pud entry

		pgdp->attr0 = 0;
		pgdp->attr1 = 0;
		pgdp->attr2 = 0;
		pgdp->outaddr_47_32 = ((u32)(((u64)(pud_phys >> 32)) & 0xFFFFFFFF) & 0xFFFF);
		pgdp->outaddr_31_12 = (u32)((u64)(pud_phys) & 0xFFFFFFFF) >> 12;
		pgdp->attr3 = 0;
		pgdp->attr4 = 3;

		pgd_off = pgd_base + (PAGE_ENTRY_SIZE * va_pgd_index(addr));
#if 0
		//VASTAI_PCI_INFO(priv, 0, " malloc from ddk get pud_phys0x%llx\n", pud_phys);
		ret = vastai_pci_mem_write(priv, 0, pgd_off, pgdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s write pgd entry information to dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PUD_FAIL;
			goto err;
		}
#endif

		smmu_write_page_entry(priv, pgd_off, (u64 *)pgdp);

#if 0

		new_pgdp = kzalloc(PAGE_MAX_INDEX * sizeof(*pgdp), GFP_KERNEL);
		if (!new_pgdp) {
			VASTAI_PCI_ERR(priv, 0,
					"pte kmalloc fail\n");
			ret = -ENOMEM;
			goto err;
		}

		ret = vastai_pci_mem_read(priv, 0, pgd_off, new_pgdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pmd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PTE_FAIL;
			goto free_err;
		}
#endif

		smmu_read_page_entry(priv, pgd_off, (u64 *)&new_pgdp);

		if (pgdp->outaddr_31_12 != new_pgdp.outaddr_31_12)
		{
			VASTAI_PCI_ERR(priv, 0,
					"init pgd failed, read & write don't match\n");
			ret = INIT_PTE_FAIL;
			goto err;
		}

//		kfree(new_pgdp);
	}

	pud_phys = get_next_level_entry_phys(priv, pgdp);
	do {
		pud_idx = va_pud_index(addr);

#if 0
		ret = vastai_pci_mem_read(priv, 0, pud_phys + pud_idx * PAGE_ENTRY_SIZE, pudp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pud entry information from dev fail!, %d\n",
					__func__, ret);
			ret = INIT_PUD_FAIL;
			goto free_err;
		}
#endif

		smmu_read_page_entry(priv, pud_phys + pud_idx * PAGE_ENTRY_SIZE, (u64 *)&pudp);

		old_pud = pudp;

		next = va_pud_addr_end(addr, end);
		ret = alloc_init_cont_pmd(priv, pt_info, pgdp, &pudp, addr, next, pa, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s alloc init pmd fail!\n",__func__);
			ret = INIT_PUD_FAIL;
			goto err;
		}
		if ((old_pud.attr4 == 0x3) &&
				((old_pud.outaddr_31_12 != pudp.outaddr_31_12) || (old_pud.outaddr_47_32 != pudp.outaddr_47_32)))
		{
			VASTAI_PCI_ERR(priv, 0,
				"current pud entry(%d) have already init!\n", (int)va_pud_index(addr));
			ret = INIT_PUD_FAIL;
			goto err;
		}

		pa += next - addr;
	} while (addr = next, addr < end);

//	kfree(pudp);
	return ret;

//free_err:
//	kfree(pudp);
//	kfree(new_pgdp);
err:
	free_mem_from_ddk(priv, pud_phys);
	return ret;
}

static int init_smmu_page_entry(struct vastai_pci_info *priv, u64 pa, u64 va, u64 pgd_base,
				int page_number, struct vastai_pid_pt_entry_info *pt_info, int s_bit)
{
	u32 ret = 0;
	u64 addr, end, next, pgd_idx;
	u32 length;
	pgd pgdp;

	pa &= VA_PTE_MASK;
	addr = va & VA_PTE_MASK;
	length = page_number * VASTAI_PAGE_SIZE;
	end = addr + length;
#if 0
	pgdp = kzalloc(sizeof(*pgdp), GFP_KERNEL);
	if (!pgdp) {
		VASTAI_PCI_ERR(priv, 0,
				"pgd kmalloc fail\n");
		goto err_free;
	}
#endif
	do {

		pgd_idx = va_pgd_index(addr);
#if 0
		ret = vastai_pci_mem_read(priv, 0, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, pgdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pgd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = -EPERM;
			goto err_free;
		}
#endif
		smmu_read_page_entry(priv, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, (u64 *)&pgdp);
		next = va_pgd_addr_end(addr, end);
		ret = alloc_init_pud(priv, pt_info, &pgdp, addr, next, pa, pgd_base, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s alloc init pud fail!",__func__);
			ret = INIT_PGD_FAIL;
			//goto err_free;
			return ret;
		}
		pa += next - addr;

		addr = next;
	} while (addr != end);

	VASTAI_PCI_DBG(priv, 0, "page entry (0x%llx)[%lld]-[%lld]-[%lld]-[%lld] to (0x%llx)[%lld]-[%lld]-[%lld]-[%lld] have been create\n",
					va, va_pgd_index(va), va_pud_index(va), va_pmd_index(va), va_pte_index(va),
					end, va_pgd_index(end), va_pud_index(end), va_pmd_index(end), va_pte_index(end));

//err_free:
//	kfree(pgdp);
	return ret;
}

int va_create_page_mapping(struct vastai_pci_info *priv, u64 pa,
									u64 va, int size, int pid, int s_bit)
{
	u32 i, ret = 0;
	u64 addr, pgd_base;
//	u64 addr, pgd_base, tl_va, tl_pa, tl_pg_cnt;
	u32 length, page_cnt;
	struct vastai_pid_pt_entry_info *pt_info;
	//struct va_translation_info *tl_info;

	//VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "[B]Translation info: va:0x%llx, pa:0x%llx, size:0x%x\n",
	//														va, pa, size);

	pa &= VA_PTE_MASK;
	addr = va & VA_PTE_MASK;
	length = VA_PAGE_ALIGN(size + (va & ~VASTAI_PAGE_MASK));
	page_cnt = length >> VA_PTE_SHIFT;

	if (!length)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "the length is at least 4k\n");
		return -ENOMEM;
	}

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return ret;
	}
	ret = 0;

	if ((addr >> 48) & VA_TYPE_CHECK)
	{
		pgd_base = pt_info->ttb1_pgd_base;
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "Pid(%d) create CPUVA entry,va[0x%llx] to pa[0x%llx], length[0x%x]\n", pid, addr, pa, length);
	}
	else
	{
		pgd_base = pt_info->ttb0_pgd_base;
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "Pid(%d) create GPUVA entry,va[0x%llx] to pa[0x%llx], length[0x%x]\n", pid, addr, pa, length);
	}

#if 0

	//mutex_lock(&pt_info->entry_lock);
	tl_va = addr;
	tl_pa = pa;
	tl_pg_cnt = 0;
	for (i = 0; i < page_cnt; i++)
	{
		if(check_page_is_mapped(priv, addr, pt_info, &tl_info))
		{
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "the entry 0x%llx is already exit in entry[0x%llx], Just count+1\n", addr, tl_info->va);
			tl_info->map_cnt += 1;
			if(tl_pg_cnt)
			{
				ret = init_smmu_page_entry(priv, tl_pa, tl_va, pgd_base, tl_pg_cnt, pt_info, s_bit);
				if (ret)
				{
					VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Create page entry failed\n");
					return ret;
				}
				//add_page_info(priv, tl_va, tl_pa, tl_pg_cnt, pt_info, s_bit);
			}
			addr += VASTAI_PAGE_SIZE;
			pa += VASTAI_PAGE_SIZE;
			tl_va = addr;
			tl_pa = pa;
			tl_pg_cnt = 0;
			continue;
		}
		tl_pg_cnt++;
		addr += VASTAI_PAGE_SIZE;
		pa += VASTAI_PAGE_SIZE;
	}

	if(tl_pg_cnt)
	{
		ret = init_smmu_page_entry(priv, tl_pa, tl_va, pgd_base, tl_pg_cnt, pt_info, s_bit);
		if (ret)
		{
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Create page entry failed\n");
			return ret;
		}
		//add_page_info(priv, tl_va, tl_pa, tl_pg_cnt, pt_info, s_bit);
	}
	//mutex_unlock(&pt_info->entry_lock);
#else

	mutex_lock(&pt_info->entry_lock);

	for (i = 0; i < page_cnt; i++)
	{
		ret = init_smmu_page_entry(priv, pa, addr, pgd_base, 1, pt_info, s_bit);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s() create page mapping failed!%d", __func__, ret);
			mutex_unlock(&pt_info->entry_lock);
			return ret;
		}
		addr += VASTAI_PAGE_SIZE;
		pa += VASTAI_PAGE_SIZE;
	}
	mutex_unlock(&pt_info->entry_lock);
#endif

	return ret;
}
int va_create_page_mapping_port(void *priv, u64 pa, u64 va, int size, int pid, int s_bit)
{
	return va_create_page_mapping((struct vastai_pci_info *)priv, pa, va, size, pid, s_bit);
}
EXPORT_SYMBOL(va_create_page_mapping_port);

int va_create_pid(struct vastai_pci_info *priv, int pid)
{
	int ret = 0;
	u64 ttb0_pgd_base;
	u64 ttb1_pgd_base;
	struct cd_s_info *cd_info;
	int ttbtr0_high, ttbtr0_low, ttbtr1_high, ttbtr1_low;
	struct vastai_pid_pt_entry_info *pt_info;
	struct vastai_pid_pt_entry_info *pt_check;
	struct smmu_info *va_smmu_info;
	u64 cd_off;
	struct cd_s_info *new_cd_info;

	va_smmu_info = priv->vastai_smmu_info;
	cd_off= va_smmu_info->cd_base + (pid * CD_SIZE);

	ret = get_pid_info(priv, pid, &pt_check);
	if(VASTAI_MATCH == ret)
	{
		VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "PID(%d) is already init, break\n", pid);
		return 0;
	}

	pt_info = kzalloc(sizeof(struct vastai_pid_pt_entry_info), GFP_KERNEL);
	if (NULL == pt_info)
	{
		ret = -ENOMEM;
		return ret;
	}

	cd_info = kzalloc(sizeof(struct cd_s_info), GFP_KERNEL);
	if (NULL == cd_info) {
		VASTAI_PCI_ERR(priv, 0,
				"cd_info kmalloc fail\n");
		kfree(pt_info);
		ret = -ENOMEM;
		return ret;
	}
	new_cd_info = kzalloc(sizeof(struct cd_s_info), GFP_KERNEL);
	if (NULL == new_cd_info) {
		VASTAI_PCI_ERR(priv, 0,
				"cd_info kmalloc fail\n");
		kfree(pt_info);
		kfree(cd_info);
		ret = -ENOMEM;
		return ret;
	}

	ttb0_pgd_base = alloc_mem_from_ddk(priv, 0x1000, LEVEL0);
	ttb1_pgd_base = alloc_mem_from_ddk(priv, 0x1000, LEVEL0);
	pt_info->ttb1_pgd_base = ttb1_pgd_base;
	pt_info->ttb0_pgd_base = ttb0_pgd_base;
	pt_info->pid = pid;
	pt_info->magic_number = PID_MAGIC_NUM;
	pt_info->tl_info_cnt = 0;

	ttbtr0_high = (((u32)((u64)(pt_info->ttb0_pgd_base) >> 32)) & 0xFFFFF);
	ttbtr0_low = ((u32)((u64)(pt_info->ttb0_pgd_base) & 0xFFFFFFFF)) >> 4;
	ttbtr1_high = (((u32)((u64)(pt_info->ttb1_pgd_base) >> 32)) & 0xFFFFF);
	ttbtr1_low = ((u32)((u64)(pt_info->ttb1_pgd_base) & 0xFFFFFFFF)) >> 4;

	VASTAI_PCI_DBG(priv, 0, "Init pid(%d) cd_off:0x%llx, ttb0_addr:0x%llx, ttb1_addr:0x%llx\n",
				pid, cd_off, pt_info->ttb0_pgd_base, pt_info->ttb1_pgd_base);

	cd_info->w0.T0SZ  =  16;
	cd_info->w0.TG0   =  0;
	cd_info->w0.T1SZ  =  16;
	cd_info->w0.TG1   =  2;
	cd_info->w0.valid =  1;
	cd_info->w0.EPD1  =  0;

	cd_info->w1.IPS   =  5;
	cd_info->w1.AFFD  =  1;
	cd_info->w1.AA64  =  1;
	cd_info->w1.R     =  1;
	cd_info->w1.A     =  1;
	cd_info->w1.ASET  =  1;
	cd_info->w1.ASID  =  pt_info->pid;

	cd_info->w2.HAD0        =  1;
	cd_info->w2.TTB0_low    =  ttbtr0_low;

	cd_info->w3.TTB0_high   =  ttbtr0_high;
	cd_info->w3.HWU59       =  1;
	cd_info->w3.HWU60       =  1;
	cd_info->w3.HWU61       =  1;
	cd_info->w3.HWU62       =  1;

	cd_info->w4.TTB1_low    =  ttbtr1_low;
	cd_info->w5.TTB1_high   =  ttbtr1_high;

	ret = vastai_pci_mem_write(priv, 0, cd_off, cd_info, CD_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,
				"%s write smmu ste information to dev fail!, %d\n",
				__func__, ret);
		ret = -EPERM;
		goto err;
	}

	ret = vastai_pci_mem_read(priv, 0, cd_off, new_cd_info, CD_SIZE);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,
				"%s read pmd entry information from dev fail!, %d\n",
				__func__, ret);
		ret = INIT_PTE_FAIL;
		goto err;
	}

	if (cd_info->w2.TTB0_low != new_cd_info->w2.TTB0_low)
	{
	//	VASTAI_PCI_ERR(priv, 0,
	//			"init cd failed, read & write don't match, 0x%x, 0x%x\n", cd_info->w2.TTB0_low, new_cd_info->w2.TTB0_low);
		ret = INIT_PTE_FAIL;
		goto err;
	}

	mutex_lock(&va_smmu_info->pid_lock);
	list_add(&(pt_info->node) , &(va_smmu_info->pid_head));
	va_smmu_info->pid_cnt += 1;
	mutex_unlock(&va_smmu_info->pid_lock);

	kfree(cd_info);

	// init entry list for current pid
	INIT_LIST_HEAD(&(pt_info->entry_head));
	// init entry lock for current pid
	mutex_init(&pt_info->entry_lock);
	return ret;

err:
	free_mem_from_ddk(priv, ttb0_pgd_base);
	free_mem_from_ddk(priv, ttb1_pgd_base);
	kfree(cd_info);
	kfree(pt_info);
	kfree(new_cd_info);
	return ret;
}
int va_create_pid_port(struct vastai_pci_info *priv, int pid)
{
	return va_create_pid((struct vastai_pci_info *)priv, pid);
}
EXPORT_SYMBOL(va_create_pid_port);

#if 0
static int remove_page_info(struct vastai_pci_info *priv, u64 va, struct vastai_pid_pt_entry_info *pid_info)
{
	int ret = 0;
	struct va_translation_info *cur_tl;
	int cur_tl_num = pid_info->tl_info_cnt;

	if (!cur_tl_num)
	{
		ret = 1;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "entry list empty! #######\n");
		return ret;
	}

	list_for_each_entry (cur_tl, &pid_info->entry_head, node) {
		if (va_is_already_map(va, cur_tl))
		{
			list_del(&(cur_tl->node));
			kfree(cur_tl);
			//VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "free entry ok!\n");
			pid_info->tl_info_cnt -= 1;
			return ret;
		}
	}


	ret = 1;
	VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "don't have matched entry, 0x%llx\n", va);

	return ret;
}

static int remove_page_info_repeatedly(struct vastai_pci_info *priv, u64 addr, u32 page_number, struct vastai_pid_pt_entry_info *pid_info)
{
	int i=0;
	int ret=0;
	u64 va = addr;
	for (i = 0; i < page_number; i++)
	{
		remove_page_info(priv, va, pid_info);
		va += VASTAI_PAGE_SIZE;
	}

	return ret;
}
#endif

#if 0
static inline int remove_pid_info(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info)
{
	int ret = 0;

	mutex_lock(&priv->vastai_smmu_info->pid_lock);
	list_del(&(pt_info->node));
	priv->vastai_smmu_info->pid_cnt -= 1;
	mutex_unlock(&priv->vastai_smmu_info->pid_lock);

	kfree(pt_info);

	return ret;
}

static int compare_entry_index(struct vastai_pci_info *priv, u64 addr, struct va_translation_info *tl_info, u64 ENTRY_MASK)
{

	//VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "srv_va:0x%llx, dst_va:0x%llx, entry_mask:0x%llx\n", addr, tl_info->va, ENTRY_MASK);
	if (((tl_info->va & ENTRY_MASK) == (addr & ENTRY_MASK))
			|| (((tl_info->va + tl_info->size) & ENTRY_MASK) == (addr & ENTRY_MASK)))
	{
		return 1;
	}

	return 0;
}

static int check_cur_entry_is_stil_used(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, u64 addr, u64 ENTRY_MASK)
{
	int ret = 0;
	struct va_translation_info *cur_tl;
	int total_tl_num = pt_info->tl_info_cnt;

	if (!total_tl_num)
	{
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "entry list empty\n");
		return ret;
	}

	list_for_each_entry (cur_tl, &pt_info->entry_head, node){
		if (!((cur_tl->va <= addr) && ((cur_tl->va + cur_tl->size - 1) >= addr)))
		{
			if (compare_entry_index(priv, addr, cur_tl, ENTRY_MASK))
			{
				//VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "The current entry is still used by entry[0x%llx]\n", cur_tl->va);
				ret = 1;
				return ret;
			}
		}
	}

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s(), total %d of the entries don't matched with the VA[0x%llx]\n", __func__, total_tl_num, addr);
	return ret;
}
#endif

static int free_pte_entry(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pmd *pmdp, u64 addr, u64 end)
{
	u64 pte_phys, pte_idx;
	int ret = 0;
	u64 pte_off;
	pte ptep;

	pte_phys = get_next_level_entry_phys(priv, pmdp);
	if(!pte_phys)
	{
		ret = -EPERM;
		return ret;
	}

	ptep.attr4 = 0;
	ptep.attr3 = 0;
	ptep.outaddr_31_12 = 0;
	ptep.outaddr_47_32 = 0;
	ptep.attr2 = 0;
	ptep.attr1 = 0;
	ptep.attr0 = 0;

	//VASTAI_PCI_ERR(priv, 0, "start to free addr(0x%llx) to end(0x%llx)!\n", addr, end);
	do {
		pte_idx = va_pte_index(addr);
		pte_off = pte_phys + (va_pte_index(addr) * PAGE_ENTRY_SIZE);

		#if 0
		ret = vastai_pci_mem_write(priv, 0, pte_off, &ptep, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s write pte rntry information to dev fail!, %d\n",
					__func__, ret);
			ret = -EPERM;
			return ret;
		}
		#endif

		smmu_write_page_entry(priv, pte_off, (u64 *)&ptep);
#if 0
		ret = remove_page_info(priv, addr, pt_info);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s remove page entry[0x%llx] failed!, %d\n",
					__func__, addr, ret);
			ret = FREE_PTE_FAIL;
			return ret;
		}
#endif
		} while (addr += VASTAI_PAGE_SIZE, addr < end);

	return ret;
}

static int free_pmd_entry(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pud *pudp, u64 addr, u64 end)
{
	u64 next, pmd_phys, pmd_idx;
	pmd pmdp;
	int ret = 0;

	pmd_phys = get_next_level_entry_phys(priv, pudp);
	if(!pmd_phys)
	{
		ret = -EPERM;
		return ret;
	}

#if 0
	pmdp = kzalloc(sizeof(*pmdp), GFP_KERNEL);
	if (!pmdp) {
		VASTAI_PCI_ERR(priv, 0,
				"pmd kmalloc fail\n");
		ret = -ENOMEM;
		return ret;
	}
#endif

	do {
		next = va_pmd_addr_end(addr, end);
		pmd_idx = va_pmd_index(addr);

#if 0
		ret = vastai_pci_mem_read(priv, 0, pmd_phys + pmd_idx *  PAGE_ENTRY_SIZE, pmdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pmd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = -EPERM;
			goto err_free;
		}
#endif
		smmu_read_page_entry(priv, pmd_phys + pmd_idx *  PAGE_ENTRY_SIZE, (u64 *)&pmdp);

		ret = free_pte_entry(priv, pt_info, &pmdp, addr, next);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s free pte failed! %d\n",
					__func__, ret);
			ret = FREE_PMD_FAIL;
			//goto err_free;
			return ret;
		}

#if 0
		if (!check_cur_entry_is_stil_used(priv, pt_info, addr, PMD_ENTRY_MASK))
		{
			pte_phys = get_next_level_entry_phys(priv, &pmdp);
			if(!pte_phys)
			{
				ret = FREE_PMD_FAIL;
				//goto err_free;
				return ret;
			}
			free_mem_from_ddk(priv, pte_phys);

			VASTAI_PCI_DBG(priv, 0, "pmd index [%lld]-[%lld]-[%lld] have been cleared, pte phys(0x%llx) have been freed\n",
					va_pgd_index(addr), va_pud_index(addr), va_pmd_index(addr), pte_phys);
			pmdp.attr4 = 0;
			pmdp.outaddr_31_12 = 0;
			pmdp.outaddr_47_32 = 0;

#if 0
			ret = vastai_pci_mem_write(priv, 0, pmd_phys + pmd_idx *  PAGE_ENTRY_SIZE, pmdp, PAGE_ENTRY_SIZE);
			if (ret) {
				VASTAI_PCI_ERR(priv, 0,
						"%s Invalidate pmd entry fail!, %d\n",
						__func__, ret);
				ret = -EPERM;
				goto err_free;
			}
#endif
			smmu_write_page_entry(priv, pmd_phys + pmd_idx *  PAGE_ENTRY_SIZE, (u64 *)&pmdp);
		}
#endif
	} while (addr = next, addr < end);

//err_free:
//	kfree(pmdp);
	return ret;

}

static int free_pud_entry(struct vastai_pci_info *priv, struct vastai_pid_pt_entry_info *pt_info, pgd *pgdp, u64 addr, u64 end)
{
	int ret = 0;
	u64 next, pud_idx;
	pud pudp;
	u64 pud_phys;

#if 0
	pudp = kzalloc(sizeof(*pudp), GFP_KERNEL);
	if (!pudp) {
		VASTAI_PCI_ERR(priv, 0,
				"pud kmalloc fail\n");
		ret = -ENOMEM;
		return ret;
	}
#endif

	pud_phys = get_next_level_entry_phys(priv, pgdp);
	do {
		next = va_pud_addr_end(addr, end);
		pud_idx = va_pud_index(addr);

#if 0
		ret = vastai_pci_mem_read(priv, 0, pud_phys + pud_idx * PAGE_ENTRY_SIZE, pudp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pud entry information from dev fail!, %d\n",
					__func__, ret);
			ret = -EPERM;
			goto err_free;
		}
#endif
		smmu_read_page_entry(priv, pud_phys + pud_idx * PAGE_ENTRY_SIZE, (u64 *)&pudp);

		ret = free_pmd_entry(priv, pt_info, &pudp, addr, end);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s free pmd fail!\n",__func__);
			ret = FREE_PUD_FAIL;
			//goto err_free;
			return ret;
		}

#if 0
		if (!check_cur_entry_is_stil_used(priv, pt_info, addr, PUD_ENTRY_MASK))
		{
			pmd_phys = get_next_level_entry_phys(priv, &pudp);
			if(!pmd_phys)
			{
				ret = FREE_PUD_FAIL;
				return ret;
				//goto err_free;
			}
			free_mem_from_ddk(priv, pmd_phys);

			VASTAI_PCI_DBG(priv, 0, "pud index [%lld]-[%lld] have been cleared, pmd phys(0x%llx) have been freed\n",
					va_pgd_index(addr), va_pud_index(addr), pmd_phys);

			pudp.attr4 = 0;
			pudp.outaddr_31_12 = 0;
			pudp.outaddr_47_32 = 0;
#if 0
			ret = vastai_pci_mem_write(priv, 0, pud_phys + pud_idx *  PAGE_ENTRY_SIZE, pudp, PAGE_ENTRY_SIZE);
			if (ret) {
				VASTAI_PCI_ERR(priv, 0,
						"%s Invalidate pmd entry fail!, %d\n",
						__func__, ret);
				ret = -EPERM;
				goto err_free;
			}
#endif
			smmu_write_page_entry(priv, pud_phys + pud_idx *  PAGE_ENTRY_SIZE, (u64 *)&pudp);
		}
#endif
	} while (addr = next, addr < end);

	//kfree(pudp);
//	return ret;

//err_free:
	//kfree(pudp);
	return ret;
}

static int free_smmu_page_entry(struct vastai_pci_info *priv, u64 va, u64 pgd_base,
				u32 page_number, struct vastai_pid_pt_entry_info *pt_info)
{
	u32 ret = 0;
	u64 addr, length, end, next, pgd_idx;
	pgd pgdp;

#if 0
	pgdp = kzalloc(sizeof(*pgdp), GFP_KERNEL);
	if (!pgdp) {
		VASTAI_PCI_ERR(priv, 0,
				"pgd kmalloc fail\n");
		return -ENOMEM;
	}
#endif

	addr = va & VA_PTE_MASK;
	length = page_number * VASTAI_PAGE_SIZE;
	end = addr + length;

	do {
		next = va_pgd_addr_end(addr, end);

		pgd_idx = va_pgd_index(addr);
#if 0
		ret = vastai_pci_mem_read(priv, 0, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, pgdp, PAGE_ENTRY_SIZE);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s read pgd entry information from dev fail!, %d\n",
					__func__, ret);
			ret = -EPERM;
			goto err_free;
		}
#endif
		smmu_read_page_entry(priv, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, (u64 *)&pgdp);

		ret = free_pud_entry(priv, pt_info, &pgdp, addr, end);
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s free pud fail!",__func__);
			ret = FREE_PGD_FAIL;
			//goto err_free;
			return ret;
		}
#if 0
		if (!check_cur_entry_is_stil_used(priv, pt_info, addr, PGD_ENTRY_MASK))
		{
			pud_phys = get_next_level_entry_phys(priv, &pgdp);
			if(!pud_phys)
			{
				ret = FREE_PGD_FAIL;
				//goto err_free;
				return ret;

			}
			free_mem_from_ddk(priv, pud_phys);

			VASTAI_PCI_DBG(priv, 0, "pgd index [%lld] have been cleared, pud phys(0x%llx)have been freed\n",
					va_pgd_index(addr), pud_phys);

			pgdp.attr4 = 0;
			pgdp.outaddr_31_12 = 0;
			pgdp.outaddr_47_32 = 0;
#if 0
			ret = vastai_pci_mem_write(priv, 0, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, pgdp, PAGE_ENTRY_SIZE);
			if (ret) {
				VASTAI_PCI_ERR(priv, 0,
						"%s Invalidate pmd entry fail!, %d\n",
						__func__, ret);
				ret = -EPERM;
				goto err_free;
			}
#endif
			smmu_write_page_entry(priv, pgd_base + pgd_idx * PAGE_ENTRY_SIZE, (u64 *)&pgdp);
		}
#endif
		addr = next;
	} while (addr < end);

	VASTAI_PCI_DBG(priv, 0, "page entry [%lld]-[%lld]-[%lld]-[%lld] to [%lld]-[%lld]-[%lld]-[%lld] have been cleared\n",
				va_pgd_index(va), va_pud_index(va), va_pmd_index(va), va_pte_index(va),
				va_pgd_index(end), va_pud_index(end), va_pmd_index(end), va_pte_index(end));

//err_free:
//	kfree(pgdp);
	return ret;
}

int va_free_page_maping(struct vastai_pci_info *priv, u64 va, u32 size, int pid)
{
	u32 page_cnt, i, length, ret = 0;
	u64 addr, end, pgd_base;
	struct vastai_pid_pt_entry_info *pt_info;
//	struct va_translation_info *tl_info;

	//VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "[B] Free Translation info: va:0x%llx, size:0x%x\n",
	//														va, size);

	addr = va & VA_PTE_MASK;
	length = VA_PAGE_ALIGN(size + (va & ~VASTAI_PAGE_MASK));
	end = addr + length;
	page_cnt = length >> VA_PTE_SHIFT;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", pid);
		return ret;
	}

	if ((va >> 48) & VA_TYPE_CHECK)
	{
		pgd_base = pt_info->ttb1_pgd_base;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "free CPUVA entry va[0x%llx], length:0x%x\n", va, length);
	}
	else
	{
		pgd_base = pt_info->ttb0_pgd_base;
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "free GPUVA entry va[0x%llx], length:0x%x\n", va, length);
	}

#if 0
	mutex_lock(&pt_info->entry_lock);

	free_va = addr;
	free_pg_cnt = 0;
	for (i = 0; i < page_cnt; i++)
	{
		if (!check_page_is_mapped(priv, addr, pt_info, &tl_info))
		{
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "the entry 0x%llx don't exit\n", addr);

			if (free_pg_cnt)
			{
				ret = free_smmu_page_entry(priv, free_va, pgd_base, free_pg_cnt, pt_info);
				if(ret)
				{
					VASTAI_PCI_ERR(priv, 0,"Clear Page entry failed!\n");
				}
#if 0
				ret = remove_page_info_repeatedly(priv, free_va, free_pg_cnt, pt_info);
				if(ret)
				{
					VASTAI_PCI_ERR(priv, 0,"%s remove pid[%d] entry[0x%llx] fail!\n",
									__func__, pid, va);
					ret = -EPERM;
					return ret;
				}
#endif
			}
			addr += VASTAI_PAGE_SIZE;
			free_va = addr;
			free_pg_cnt = 0;
			continue;
		}

		free_pg_cnt++;
		addr += VASTAI_PAGE_SIZE;
	}

	if(free_pg_cnt)
	{
		ret = free_smmu_page_entry(priv, free_va, pgd_base, free_pg_cnt, pt_info);
		if(ret)
		{
			VASTAI_PCI_ERR(priv, 0,"Clear Page entry failed!\n");
		}
#if 0
		ret = remove_page_info_repeatedly(priv, free_va, free_pg_cnt, pt_info);
		if(ret)
		{
			VASTAI_PCI_ERR(priv, 0,"%s remove pid[%d] entry[0x%llx] fail!\n",
							__func__, pid, va);
			ret = -EPERM;
			return ret;
		}
#endif
	}
	mutex_unlock(&pt_info->entry_lock);
#endif

	mutex_lock(&pt_info->entry_lock);
	for (i = 0; i < page_cnt; i++)
	{
		ret = free_smmu_page_entry(priv, addr, pgd_base, 1, pt_info);
		if(ret)
		{
			VASTAI_PCI_ERR(priv, 0,"free Page entry[0x%llx] failed!\n", addr);
			mutex_unlock(&pt_info->entry_lock);
			return ret;
		}
	}
	mutex_unlock(&pt_info->entry_lock);


	mutex_lock(&priv->vastai_smmu_info->pid_lock);
	ret = smmu_fill_tlb_invalid_cmd_descriptor(priv, 0x12, pid, 0, addr, length);
	if (ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "TLB Flush va(0x%llx)failed!\n", addr);
		return ret;
	}
	smmu_fill_sync_cmd_descriptor(priv);
	mutex_unlock(&priv->vastai_smmu_info->pid_lock);

#if 0
	for (i = 0; i < page_cnt; i++)
	{
		ret = check_page_is_mapped(priv, addr, pt_info, &tl_info);
		if (!ret)
		{
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "the entry 0x%llx don't exit\n", addr);
			ret = 1;
			return ret;
		}

#if 0
		tl_info->map_cnt -= 1;
		if(0 == tl_info->map_cnt)
		{
#endif


		free_smmu_page_entry(priv, addr, pgd_base, 1, pt_info);
		ret = remove_page_info(priv, addr, pt_info);
		if(ret)
		{
			VASTAI_PCI_ERR(priv, 0,"%s remove pid[%d] entry[0x%llx] fail!\n",
							__func__, pid, va);
			ret = -EPERM;
			return ret;
		}
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "remove page entry(0x%llx) success\n", addr);
#if 0
		}
		else
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "page entry(0x%llx) just count -1\n", addr);
#endif
		addr += VASTAI_PAGE_SIZE;
	}
#endif
	return ret;
}

int va_free_page_maping_port(void *priv, u64 va, u32 size, int pid)
{
	return va_free_page_maping((struct vastai_pci_info *)priv, va, size, pid);
}
EXPORT_SYMBOL(va_free_page_maping_port);

int va_kill_pid(struct vastai_pci_info *priv, int pid)
{
	int ret = 0;
	int pgd_idx = 0;
	u64 pgd_base;
	struct vastai_pid_pt_entry_info *pt_info;

	ret = get_pid_info(priv, pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, 0, "Can't find PID(%d) info\n", pid);
		return ret;
	}

	mutex_lock(&priv->vastai_smmu_info->pid_lock);

	pgd_base = pt_info->ttb0_pgd_base;

free_page:
	while(pgd_idx < PAGE_MAX_INDEX)
	{
		u64 pgd, pgd_off;

		pgd_off = pgd_base + pgd_idx * PAGE_ENTRY_SIZE;
		smmu_read_page_entry(priv, pgd_off, &pgd);

		//if pgd is valid, goto free pud
		if (!page_entry_valid_check(priv, &pgd))
		{
			int pud_idx = 0;
			while(pud_idx < PAGE_MAX_INDEX)
			{
				u64 pud, pud_off, pud_base = get_next_level_entry_phys(priv, &pgd);
				pud_off = pud_base + pud_idx * PAGE_ENTRY_SIZE;
				smmu_read_page_entry(priv, pud_off, &pud);

				//if pud is valid, goto free pmd
				if (!page_entry_valid_check(priv, &pud))
				{
					int pmd_idx = 0;
					while(pud_idx < PAGE_MAX_INDEX)
					{
						u64 pmd, pmd_off, pmd_base = get_next_level_entry_phys(priv, &pud);
						pmd_off = pmd_base + pmd_idx * PAGE_ENTRY_SIZE;
						smmu_read_page_entry(priv, pud_off, &pmd);

						//if pmd is valid, free pmd
						if (!page_entry_valid_check(priv, &pmd))
						{
							free_mem_from_ddk(priv, get_next_level_entry_phys(priv, &pmd));
						}
						pmd_idx++;
					}

					free_mem_from_ddk(priv, get_next_level_entry_phys(priv, &pud));
				}
				pud_idx++;
			}

			free_mem_from_ddk(priv, get_next_level_entry_phys(priv, &pgd));
		}

		pgd_idx++;
	}
	free_mem_from_ddk(priv, pt_info->ttb0_pgd_base);

	if (pgd_base != pt_info->ttb1_pgd_base)
	{
		pgd_idx = 0;
		pgd_base = pt_info->ttb1_pgd_base;
		goto free_page;
	}

	/* TLB Flush all entry */
	ret = smmu_fill_tlb_invalid_cmd_descriptor(priv, 0x30, pid, 0, 0, 0);
	if (ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "TLB Flush all entry of pid(%d) failed!\n", pid);
		return ret;
	}

	/* Flush cfg entry */
	ret = smmu_fill_cfg_invalid_cmd_descriptor(priv, 0x5, pid, 0);
	if (ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Invalidate CD entry of pid(%d) failed!\n", pid);
		return ret;
	}

	list_del(&(pt_info->node));
	//mutex_destroy(&pt_info->entry_lock);
	kfree(pt_info);
	priv->vastai_smmu_info->pid_cnt -= 1;
	mutex_unlock(&priv->vastai_smmu_info->pid_lock);

	VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "Killed pid(%d) success!\n", pid);

	return ret;
}

int va_kill_pid_port(void *priv, int pid)
{
	return va_kill_pid(priv, pid);
}
EXPORT_SYMBOL(va_kill_pid_port);

int device_smmu_ste_table_init(struct vastai_pci_info *priv)
{
	int ret;
	struct pcie_transfer_cmd trans;

	if (!priv->vastai_smmu_info)
		return -EINVAL;

	trans.w0.s_data0.optcode = 0x5A;
	trans.w0.s_data0.rev0 = 0;
	trans.w0.s_data0.rev1 = 0;
	trans.w0.s_data0.rev2 = 0;
	trans.w1.data1 = 0;
	trans.w2.data2 = ((int)((priv->vastai_smmu_info->cd_base) & 0xFFFFFFFF)) >> 6;
	trans.w3.data3 = (((int)((priv->vastai_smmu_info->cd_base) >> 32)) & 0xFFFFF);

	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF,  &trans, 0);

	if(ret!=0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,"send smmu cmd error ret[%d]\n", ret);
	}

	return ret;
}

void va_get_smmu_err(struct vastai_pci_info *priv, struct pcie_transfer_cmd *event_err)
{
	u32 va_low,va_high, ret;
	u64 va;
	struct va_smmu_err_info *err_info = priv->vastai_smmu_info->err_info;
	struct vastai_pid_pt_entry_info *pt_info;
	struct va_translation_info *tl_info;

	VASTAI_PCI_ERR(NULL, 0,"get smmu err\n");
	err_info->err_code = event_err->w0.s_data0.optcode;
	err_info->vmid     = event_err->w1.data1;
	err_info->pid      = event_err->w0.data0 >> 12;
	va_low   = event_err->w2.data2;
	va_high  = event_err->w3.data3;
	va = (u64)(((u64)va_high << 32) | va_low);
	err_info->va = va;

	VASTAI_PCI_ERR(NULL, 0, "err_code[0x%x], sid[0x%x],ssid[0x%x],va[0x%llx]\n",
				err_info->err_code, err_info->vmid, err_info->pid, va);

	ret = get_pid_info(priv, err_info->pid, &pt_info);
	if(VASTAI_MATCH != ret)
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Can't find PID(%d) info\n", err_info->pid);
		return;
	}

	if(check_page_is_mapped(priv, va & VA_PTE_MASK, pt_info, &tl_info))
		get_page_entry_info(priv, va, err_info->pid);

	VASTAI_PCI_ERR(NULL, 0, "######The current page information is as follows\n");
	walk_translation_info(priv, err_info->pid);
}

static int va_get_smmu_info(struct vastai_pci_info *priv, struct smmu_info *vastai_smmu_info)
{
	vastai_smmu_info->cd_base = ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base << 32) | priv->priv_hw_cfg->header.lo32_ddr_base) + CD_OFFSET;
	vastai_smmu_info->ste_base = STE_BASE_ADDR;
	vastai_smmu_info->pid_cnt  = 0;

	VASTAI_PCI_INFO(priv, 0, "cd_base:0x%llx, pte_base:0x%llx\n", vastai_smmu_info->cd_base, vastai_smmu_info->ste_base);

	return 0;
}

static void smmu_cmd_sync_done_callback(void *arg)
{
	// nothing to do
	return;
}

#if 0
static void smmu_sync_work_handle(struct kthread_work *work)
{
	struct vastai_pci_info *priv =
		container_of(work, struct vastai_pci_info, smmu_sync_kwork);

	smmu_fill_sync_cmd_descriptor(priv);
}

static void smmu_sync_kthread_queue(struct vastai_pci_info *priv)
{
	//struct sched_param param = { .sched_priority = MAX_RT_PRIO - 10 };

	kthread_init_worker(&priv->smmu_sync_kworker);
	priv->smmu_sync_kworker_task = kthread_run(kthread_worker_fn,
						&priv->smmu_sync_kworker, "smmu sync kthread worker");
	if (IS_ERR(priv->smmu_sync_kworker_task)) {
		printk("failed to create smmu sync task\n");
		return;
	}
	kthread_init_work(&priv->smmu_sync_kwork, smmu_sync_work_handle);

	//sched_setscheduler(priv->smmu_sync_kworker_task, SCHED_FIFO, &param);
}
#endif


int vastai_smmu_init(struct vastai_pci_info *priv)
{
	int ret;
//	void *reg_ker_va;
//	void *buf_ker_va;
	struct smmu_info *va_smmu_info;
	struct va_smmu_err_info *va_err_info;

	if (!priv)
		return -EINVAL;

	va_smmu_info = kzalloc(sizeof(*va_smmu_info), GFP_KERNEL);
	if (!va_smmu_info) {
		VASTAI_PCI_ERR(priv, 0,
				"vastai_smmu_info kmalloc fail\n");
		return -ENOMEM;
	}

	va_err_info = kzalloc(sizeof(*va_err_info), GFP_KERNEL);
	if (!va_err_info) {
		VASTAI_PCI_ERR(priv, 0,
				"vastai_smmu_err_info kmalloc fail\n");
		return -ENOMEM;
	}

	ret = va_get_smmu_info(priv, va_smmu_info);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,
				"%s get smmu information fail!, %d\n",
				__func__, ret);
		ret = -EPERM;
		goto err_free;
	}
	init_completion(&va_smmu_info->cmd_sync_done);

	va_smmu_info->sync_cnt = 0;
	INIT_LIST_HEAD(&(va_smmu_info->pid_head));
	va_smmu_info->err_info = va_err_info;
	mutex_init(&va_smmu_info->pid_lock);
	priv->vastai_smmu_info = va_smmu_info;

	ret = va_register_pcie_interrupt(priv, COMMON_MSIX_SMMU_ERR_VECTOR,
			 smmu_cmd_sync_done_callback,
			 &(priv->vastai_smmu_info->cmd_sync_done));

	return 0;

err_free:
	kfree(va_smmu_info);
	return ret;
}
