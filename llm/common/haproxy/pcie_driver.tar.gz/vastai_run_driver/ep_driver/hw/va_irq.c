/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/31
 * Author: adan.xue
 */

#include "vastai_pci.h"
#include "va_irq.h"
#include "sg100_gmcu.h"
#include "hw_config.h"
#include "hw_queue.h"
#include "vastai_pcie_public.h"

int va_host_irq_register(struct vastai_pci_info *priv,
			 enum host_irq_num num,
			 va_host_irq_callback_t callback,
			 void *arg)
{
	if ((num >= HOST_IRQ_MAX) || !priv)
		return -EINVAL;

	if (priv->host_irqs[num])
		return -EPERM;

	priv->host_irqs[num] = kzalloc(sizeof(*(priv->host_irqs[num])), GFP_KERNEL);
	if (!priv->host_irqs[num])
		return -ENOMEM;

	priv->host_irqs[num]->callback = callback;
	priv->host_irqs[num]->arg = arg;

	return 0;
}

int va_host_irq_unregister(struct vastai_pci_info *priv,
			   enum host_irq_num num)
{
	if ((num >= HOST_IRQ_MAX) || !priv)
		return -EINVAL;

	if (!priv->host_irqs[num])
		return -EPERM;

	kfree(priv->host_irqs[num]);
	priv->host_irqs[num] = NULL;

	return 0;
}

static void host_irq_pcie2_dma0_callback(void *arg)
{
	int ret;
	struct vastai_pci_info *priv;
	struct hw_msgq *to_host_msgq = arg;
	struct host_irq_msg irq_msg;
	int num;

	priv = to_host_msgq->priv;
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "priv->dev->devfn=%d\n",priv->dev->devfn);
	while (1) {
		ret = msgq_out(to_host_msgq, &irq_msg, 1);
		if (ret != 1) {
			break;
		}
		num = irq_msg.irq_num;
		VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "irq_msg.sdma_num=%d\n",irq_msg.irq_num);
		BUG_ON(num >= HOST_IRQ_MAX);
		BUG_ON(priv->host_irqs[num] == NULL);

		if (priv->host_irqs[num]->callback)
			priv->host_irqs[num]->callback(priv->host_irqs[num]->arg,
						       &irq_msg);
	}
}

// TODO: unregister interrupt
int va_host_irq_deinit(struct vastai_pci_info *priv)
{
	kfree(priv->to_host_msgq);
	return 0;
}

int va_host_irq_init(struct vastai_pci_info *priv)
{
	int ret;
	struct hw_msgq *to_host_msgq;
	void *reg_ker_va;
	void *buf_ker_va;
	struct ring_buf_entry *ring_buf_entry;
	if( ONLY_1_PF == priv->fn_mode) {
		ring_buf_entry = find_hw_cfg_acord_name(priv,ONLY_1_PF_GMCU1_WR_MSIX_INFO_HOST_RD_NAME);
	} else if (ONLY_2_PF == priv->fn_mode){
		ring_buf_entry = find_hw_cfg_acord_name(priv,ONLY_2_PF_GMCU_WR_MSIX_INFO_HOST_RD_NAME);
	} else {
		ring_buf_entry = find_hw_cfg_acord_name(priv,COMMON_GMCU_WR_MSIX_INFO_HOST_RD_NAME);
	}
	
	if(NULL==ring_buf_entry){
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "va_host_irq_init fail\n");
		return -EINVAL;
	}

	if (!priv)
		return -EINVAL;

	to_host_msgq = kzalloc(sizeof(*to_host_msgq), GFP_KERNEL);
	if (!to_host_msgq) {
		VASTAI_PCI_ERR(priv, 0,
				"to_host_msgq kmalloc fail\n");
		return -ENOMEM;
	}

	reg_ker_va = vastai_pci_mmio_kva_get(priv, 0,
			ring_buf_entry->msgq_ctrl_reg_base, 1);
	if (!reg_ker_va) {
		VASTAI_PCI_ERR(priv, 0,
			"host irq msgq reg addr(%x) is invalid\n",
			ring_buf_entry->msgq_ctrl_reg_base);
		ret = -ENXIO;
		goto err_free;
	}
	buf_ker_va = vastai_pci_mmio_kva_get(priv, 0,
			ring_buf_entry->ring_buf_base, 1);
	if (!buf_ker_va) {
		VASTAI_PCI_ERR(priv, 0,
			"host irq msgq buf addr(%x) is invalid\n",
			ring_buf_entry->ring_buf_base);
		ret = -ENXIO;
		goto err_free;
	}

	ret = hw_msgq_init(to_host_msgq, ring_buf_entry->name,
			(uint64_t)reg_ker_va,
			(uint64_t)buf_ker_va,
			ring_buf_entry->ring_buf_size,
			sizeof(struct host_irq_msg),
			priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,
				"%s dma_to host msgq fail!, %d\n",
				__func__, ret);
		ret = -EPERM;
		goto err_free;
	}

	ret = va_register_pcie_interrupt(priv, COMMON_MSIX_GMCU_VECTOR,
					 host_irq_pcie2_dma0_callback,
					 to_host_msgq);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,
				"%s: va_register_pcie_interrupt() fail!, %d\n",
				__func__, ret);
		ret = -EIO;
		goto err_free;
	}

	priv->to_host_msgq = to_host_msgq;
	return 0;

err_free:
	kfree(to_host_msgq);
	return ret;
}
