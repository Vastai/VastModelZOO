#ifndef __PCIE_2_REG_H__
#define __PCIE_2_REG_H__

#include "../../include/common/sg100/sg100_pcie.h"
#include "../../include/common/sg100/sg100_gmcu.h"
/**
 * the BAR0 of PF0 -> target0 -> pcie control register(ATU and DMA)
 */
#define PCIE2_PF0_BAR0_BASE  0 // (0x8000000000)
#define PCIE2_DMA_REG_BASE   (PCIE2_PF0_BAR0_BASE + 0x2000)
#define PCIE2_DMA_REG_WR_CH(num) (PCIE2_DMA_REG_BASE + num * 0x2000)
#define PCIE2_DMA_REG_RD_CH(num) (PCIE2_DMA_REG_BASE + num * 0x2000 + 0x1000)

#define PCIE2_ATU_REG_BASE   (PCIE2_PF0_BAR0_BASE + 0x10000)
#define PCIE2_ATU_REG_OUTBOUND(num) (PCIE2_ATU_REG_BASE + (num) * 0x200)
#define PCIE2_ATU_REG_INBOUND(num)  (PCIE2_ATU_REG_BASE + (num) * 0x200 + 0x100)

#endif
