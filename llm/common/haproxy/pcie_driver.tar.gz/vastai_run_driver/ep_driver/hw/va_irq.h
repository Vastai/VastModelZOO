#ifndef __VA_IRQ_H__
#define __VA_IRQ_H__

#include "../../include/common/sg100/msgq_struct_share.h"

int va_host_irq_register(struct vastai_pci_info *priv,
			 enum host_irq_num num,
			 va_host_irq_callback_t callback,
			 void *arg);
int va_host_irq_unregister(struct vastai_pci_info *priv,
			   enum host_irq_num num);

int va_host_irq_init(struct vastai_pci_info *priv);
int va_host_irq_deinit(struct vastai_pci_info *priv);
#endif
