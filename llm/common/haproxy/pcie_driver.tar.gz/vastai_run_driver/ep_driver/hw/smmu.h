#ifndef __VA_SMMU_H__
#define __VA_SMMU_H__

#include "../../include/common/sg100/msgq_struct_share.h"
#include "va_hw_init.h"

#if 0
#define BITS_PER_LONG	32
#define BITS_PER_LONG_LONG	64

#define GENMASK(h, l) \
	(((~0UL) - (1UL << (l)) + 1) & (~0UL >> (BITS_PER_LONG - 1 - (h))))

#define GENMASK_ULL(h, l) \
	(((~0ULL) - (1ULL << (l)) + 1) & \
	 (~0ULL >> (BITS_PER_LONG_LONG - 1 - (h))))
#endif
//#define ALIGN(x, a)	(((x) + ((a) - 1)) & ~((a) - 1))


#define LEVEL0 0
#define LEVEL1 1
#define LEVEL2 2
#define LEVEL3 3

#define INIT_PTE_FAIL -1
#define INIT_PMD_FAIL -2
#define INIT_PUD_FAIL -3
#define INIT_PGD_FAIL -4
#define FREE_PTE_FAIL -5
#define FREE_PMD_FAIL -6
#define FREE_PUD_FAIL -7
#define FREE_PGD_FAIL -8




#define PID_MAGIC_NUM	0x1CBA88C7
#define ENTRY_MAGIC_NUM	0xF3C8710A

#define VASTAI_EMPTY	0x0
#define VASTAI_MATCH	0x1
#define VASTAI_NULL		0x2

/* maping taile */
#define START_MAP		0x10
#define END_MAP			0x01
#define START_END_MAP	0x11
#define NO_MAP			0x00

#define UNVALID_ENRTY	0x0
#define VA_TYPE_CHECK	0xFFFF

#define PMD_ENTRY_MASK	0xFFFFFFFFFFE00000
#define PUD_ENTRY_MASK	0xFFFFFFFFC0000000
#define PGD_ENTRY_MASK	0xFFFFFF8000000000
#define PAGE_ADDR_MASK  0xFFFFFFFFF000
#define PTE_VALIDE_CHECK 0x7F

/* SMMU Configuration info */
#define CMDQ_BASE_ADDR		0x8D3000   /* 16B aligned*/
#define CMDQ_LOG2SIZE   	0xA
#define EVENTQ_BASE_ADDR	0x8D3800   /* 32B aligned*/
#define EVENTQ_LOG2SIZE		0xA
#define ENT_DWORD			2
#define COMMAND_SIZE		16

/* just for test */
#define STE_BASE_ADDR 		0x8E0000
#define STE_SIZE  			64
#define CD_OFFSET			0x8000000
#define CD_NUMBER			(6 * 1024)
#define CD_SIZE				64

/* 4K Page size , just for test */
#define VASTAI_PAGE_SIZE	0x1000
#define VASTAI_PAGE_MASK	(~(VASTAI_PAGE_SIZE-1))
#define PGD_BASE			0x1049000000
#define PUD_BASE			0x1049010000
#define PMD_BASE			0x1049020000
#define PTE_BASE			0x1049030000
#define PAGE_MAX_INDEX		512
#define PAGE_ENTRY_SIZE		8

/* 4k Page size */
#define VA_PGD_SHIFT			39
#define VA_PUD_SHIFT			30
#define VA_PMD_SHIFT			21
#define VA_PTE_SHIFT			12

#define VA_PGD_SIZE			(1ULL << VA_PGD_SHIFT)
#define VA_PGD_MASK			(~(VA_PGD_SIZE - 1))
#define va_pgd_index(addr)		(((addr) >> VA_PGD_SHIFT) & (PAGE_MAX_INDEX - 1))

#define VA_PUD_SIZE			(1ULL << VA_PUD_SHIFT)
#define VA_PUD_MASK			(~(VA_PUD_SIZE - 1))
#define va_pud_index(addr)		(((addr) >> VA_PUD_SHIFT) & (PAGE_MAX_INDEX - 1))

#define VA_PMD_SIZE			(1ULL << VA_PMD_SHIFT)
#define VA_PMD_MASK			(~(VA_PMD_SIZE - 1))
#define va_pmd_index(addr)		(((addr) >> VA_PMD_SHIFT) & (PAGE_MAX_INDEX - 1))

#define VA_PTE_SIZE			(1ULL << VA_PTE_SHIFT)
#define VA_PTE_MASK			(~(VA_PTE_SIZE - 1))
#define va_pte_index(addr)		(((addr) >> VA_PTE_SHIFT) & (PAGE_MAX_INDEX - 1))
#define VA_PAGE_ALIGN(addr)	ALIGN(addr, VASTAI_PAGE_SIZE)

#define va_pgd_addr_end(addr, end)						\
({	unsigned long __boundary = ((addr) + VA_PGD_SIZE) & VA_PGD_MASK;	\
	(__boundary - 1 < (end) - 1)? __boundary: (end);		\
})

#define va_pud_addr_end(addr, end)						\
({	unsigned long __boundary = ((addr) + VA_PUD_SIZE) & VA_PUD_MASK;	\
	(__boundary - 1 < (end) - 1)? __boundary: (end);		\
})

#define va_pmd_addr_end(addr, end)						\
({	unsigned long __boundary = ((addr) + VA_PMD_SIZE) & VA_PMD_MASK;	\
	(__boundary - 1 < (end) - 1)? __boundary: (end);		\
})

#define va_pte_addr_end(addr, end)						\
({	unsigned long __boundary = ((addr) + VA_PTE_SIZE) & VA_PTE_MASK;	\
	(__boundary - 1 < (end) - 1) ? __boundary : (end);			\
})

#if 0
#define pgd_offset_raw(pgd, addr)	((pgd) + pgd_index(addr))
#define pud_offset_raw(pud, addr)	((pud) + pud_index(addr))
#define pmd_offset_raw(pmd, addr)	((pmd) + pmd_index(addr))
#define pte_offset_raw(pte, addr)	((pte) + pte_index(addr))
#endif

#if 0
struct vastai_smmu_msgq_cfg {
	char *name;
	u64 desc_msgq_reg;
	u64 desc_msgq_buf;
	u32 desc_msgq_buf_size;
};

struct vastai_smmu_entry_cfg {
	char *name;
	u64 cd_base;
	u64 pgd_base;
	u64 pud_base;
	u64 pmd_base;
	u64 pte_base;
};

struct vastai_smmu_cfg {
	struct va_dev_owner owner;
	char *name;
	u8 device_id;
	u8 stream_id;
	u8 sub_streamid;
	u8 vmid;
	u8 asid;
	struct vastai_smmu_msgq_cfg smmu_msgq_cfg;
	struct vastai_smmu_entry_cfg smmu_entry_cfg;
};

#define VASTAI_SMMU_MSGQ_CFG_ITEM(__name,			\
			   __desc_msgq_reg,		\
			   __desc_msgq_buf,		\
			   __desc_msgq_buf_size)	\
{	\
	.name = __name,					\
	.desc_msgq_reg = __desc_msgq_reg,		\
	.desc_msgq_buf = __desc_msgq_buf,		\
	.desc_msgq_buf_size = __desc_msgq_buf_size,	\
}

#define VASTAI_SMMU_ENTRY_CFG_ITEM(__name,			\
			   __cd_base,		\
			   __pgd_base,		\
			   __pud_base,		\
			   __pmd_base,		\
			   __pte_base)	\
{	\
	.name = __name,					\
	.cd_base = __cd_base,		\
	.pgd_base = __pgd_base,		\
	.pud_base = __pud_base,	\
	.pmd_base = __pmd_base, \
	.pte_base = __pte_base, \
}
#endif

typedef struct page_info
{
	unsigned int attr4 : 2;
	unsigned int attr3 : 10;
	unsigned int outaddr_31_12 : 20;
	unsigned int outaddr_47_32 : 16;
	unsigned int attr2 : 11;
	unsigned int attr1 : 1;
	unsigned int attr0 : 4;
} PAGE_INFO;

typedef PAGE_INFO pte;
typedef PAGE_INFO pmd;
typedef PAGE_INFO pud;
typedef PAGE_INFO pgd;

struct va_translation_info{
	struct list_head node;
	u64 va;
	u64 pa;
	int size;
	int magic_number;
	int map_cnt;
	int s_bit;
};

struct vastai_pid_pt_entry_info{
	struct list_head node;
	struct list_head entry_head;
	int magic_number;
	int pid;
	int tl_info_cnt;
	struct mutex entry_lock;
	u64 ttb0_pgd_base;
	u64 ttb1_pgd_base;
};

struct va_smmu_err_info{
	int err_code;
	int vmid;
	int pid;
	u64 va;
};

typedef struct smmu_info
{
	struct list_head pid_head;
	unsigned long long cd_base;
	unsigned long long ste_base;
	int pid_cnt;
	struct completion cmd_sync_done;
	struct mutex pid_lock;
	struct va_smmu_err_info *err_info;
	int sync_cnt;
}SMMU_INFO;

struct __attribute__((packed)) smmu_cmd_info {
	/* refer to VASTAI_TRANSFER_TYPE
	 * type: 0:ai model; 1:video
	 */
	u32 type : 8;
	u32 len : 8;
	u32 reserved_01 : 8;
	/* transfer number */
	u32 reserved_02 : 8;
	u32 stream_id;
	u32 low_addr;
	u32 high_addr;
};

struct smmu_cmdq_dsc
{
	unsigned int optcode	: 8;
	unsigned int stride		: 5;
	unsigned int size		: 5;
	unsigned int leaf		: 1;
	unsigned int action		: 2;
	unsigned int msi_attr	: 4;
	unsigned int msh		: 2;
	unsigned int cs			: 2;
	unsigned int reserved	: 3;
	union _cmd_format
	{
		struct _cmd1
		{
			unsigned int stream_id			: 16;
			unsigned int substream_id_stag	: 16;
		}cmd1;
		struct _cmd2
		{
			unsigned int asid	: 16;
			unsigned int vmid	: 16;
		}cmd2;
		unsigned int msi_data;
	}cmd_format;
	unsigned int	low_addr;
	unsigned int	high_addr;
};

struct arm_smmu_queue
{
	unsigned long long			q_base;

	unsigned long long			ent_dwords;
	unsigned int				max_n_shift;
	unsigned int				prod;
	unsigned int				cons;
	unsigned long long			reg;
};

typedef struct smmu_dev_info {
	unsigned int			en;
	unsigned long long 		strtb_base;
	struct arm_smmu_queue	cmdq;
	struct arm_smmu_queue	evtq;
}SMMU_DEV_INFO;

typedef struct ste_s_info
{
	struct
	{
		unsigned int valid				: 1;
		unsigned int Config				: 3;
		unsigned int S1Fmt				: 2;
		unsigned int S1ContextPtr_low	: 26;
	} w0;

	struct
	{
		unsigned int S1ContextPtr_high	: 20;
		unsigned int reserved			: 7;
		unsigned int S1CDMax			: 5;
	} w1;

	struct
	{
		unsigned int S1DSS				:2;
		unsigned int S1CIR				:2;
		unsigned int S1COR				:2;
		unsigned int S1CSH				:2;
		unsigned int reserved0			:4;
		unsigned int DRE				:1;
		unsigned int CONT				:4;
		unsigned int DCP				:1;
		unsigned int PPAR 				:1;
		unsigned int MEV  				:1;
		unsigned int reserved1			:7;
		unsigned int S1STALLD			:1;
		unsigned int EATS 				:2;
		unsigned int STRW 				:2;
	} w2;

	struct
	{
		unsigned int MemAttr  			:4;
		unsigned int MTCFG				:1;
		unsigned int ALLOCCFG 			:4;
		unsigned int reserved2			:3;
		unsigned int SHCFG				:2;
		unsigned int NSCFG				:2;
		unsigned int PRIVCFG  			:2;
		unsigned int INSTCFG 			:2;
		unsigned int reserved3			:12;
	} w3;

	struct
	{
	unsigned int S2VMID				:16;
	unsigned int IMPDEF				:16;
	} w4;

	struct
	{
	unsigned int S2T0SZ   			:6;
	unsigned int S2SL0				:2;
	unsigned int S2IR0				:2;
	unsigned int S2OR0				:2;
	unsigned int S2SH0				:2;
	unsigned int S2TG 				:2;
	unsigned int S2PS 				:3;
	unsigned int S2AA64   			:1;
	unsigned int S2ENDI  			:1;
	unsigned int S2AFFD 			:1;
	unsigned int S2PTW				:1;
	unsigned int S2HD 				:1;
	unsigned int S2HA 				:1;
	unsigned int S2S 				:1;
	unsigned int S2R 				:1;
	unsigned int reserved0			:5;
	} w5;

	unsigned int w6;
	unsigned int w7;
	unsigned int w8;
	unsigned int w9;
	unsigned int w10;
	unsigned int w11;
	unsigned int w12;
	unsigned int w13;
	unsigned int w14;
	unsigned int w15;
}STE_S_INFO;


typedef struct cd_s_info
{
	struct
	{
		unsigned int T0SZ :6;
		unsigned int TG0  :2;
		unsigned int IR0  :2;
		unsigned int OR0  :2;
		unsigned int SH0  :2;
		unsigned int EPD0 :1;
		unsigned int ENDI :1;
		unsigned int T1SZ :6;
		unsigned int TG1  :2;
		unsigned int IR1  :2;
		unsigned int OR1  :2;
		unsigned int SH1  :2;
		unsigned int EPD1 :1;
		unsigned int valid:1;
	} w0;

	struct
	{
	unsigned int IPS  :3;
	unsigned int AFFD :1;
	unsigned int WXN  :1;
	unsigned int UWXN :1;
	unsigned int TBI  :2;
	unsigned int PAN  :1;
	unsigned int AA64 :1;
	unsigned int HD   :1;
	unsigned int HA   :1;
	unsigned int S:1;
	unsigned int R:1;
	unsigned int A:1;
	unsigned int ASET :1;
	unsigned int ASID :16;
	} w1;

	struct
	{
	unsigned int NSCFG0   :1;
	unsigned int HAD0 :1;
	unsigned int reserved0:2;
	unsigned int TTB0_low :28;
	} w2;

	struct
	{
		unsigned int TTB0_high:20;
		unsigned int reserved1:8;
		unsigned int HWU59:1;
		unsigned int HWU60:1;
		unsigned int HWU61:1;
		unsigned int HWU62:1;
	} w3;

	struct
	{
	unsigned int NSCFG1   :1;
	unsigned int HAD1 :1;
	unsigned int reserved0:2;
	unsigned int TTB1_low :28;
	} w4;

	struct
	{
	unsigned int TTB1_high:20;
	unsigned int reserved1:12;
	} w5;

	unsigned int MAIR0;
	unsigned int MAIR1;

	unsigned int AMAIR0;
	unsigned int AMAIR1;


	unsigned int IMPDEF;


	unsigned long long w11;
	unsigned long long w12;
	unsigned long long w13;
	unsigned long long w14;
	unsigned long long w15;
}CD_S_INFO;

int device_smmu_ste_table_init(struct vastai_pci_info *priv);
int smmu_fill_prefetch_cmd_descriptor(struct vastai_pci_info *priv, int optcode, int stream_id, int substream_id, int size, int stride, u64 address);
int smmu_fill_cfg_invalid_cmd_descriptor(struct vastai_pci_info *priv, int optcode , int substream_id, int leaf);
int smmu_fill_tlb_invalid_cmd_descriptor(struct vastai_pci_info *priv, int optcode , int asid, int leaf, u64 address, u32 range);
void smmu_fill_tlb_invalid_cmd_descriptor_port(void *devInfo, u64 address, u32 range);
int smmu_fill_resum_cmd_descriptor(struct vastai_pci_info *priv, int stream_id, int stag, int action);
int smmu_fill_sync_cmd_descriptor(struct vastai_pci_info *priv);
void va_get_smmu_err(struct vastai_pci_info *priv, struct pcie_transfer_cmd *event_err);
int get_page_entry_info(struct vastai_pci_info *priv, u64 va, int pid);
void walk_page_from_dev(struct vastai_pci_info *priv, int pid);

int vastai_smmu_init(struct vastai_pci_info *priv);
int va_kill_pid(struct vastai_pci_info *priv, int pid);
int va_create_pid(struct vastai_pci_info *priv, int pid);
int va_create_page_mapping(struct vastai_pci_info *priv, u64 pa, u64 va, int size, int pid, int s_bit);
int va_free_page_maping(struct vastai_pci_info *priv, u64 va, u32 size, int pid);
u64 va_virt_to_phys(struct vastai_pci_info *priv, u64 va, int pid);
u64 va_phys_to_virt(struct vastai_pci_info *priv, u64 pa, int pid);
void walk_translation_info(struct vastai_pci_info *priv, int pid);
int va_create_page_mapping_port(void *priv, u64 pa, u64 va, int size, int pid, int s_bit);
int va_create_pid_port(struct vastai_pci_info *priv, int pid);
int va_free_page_maping_port(void *priv, u64 va, u32 size, int pid);
int va_kill_pid_port(void *priv, int pid);


#endif
