/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/04
 * Author: adan.xue
 */

#include <linux/ktime.h>
#include <linux/delay.h>

#include "vastai_pci.h"
#include "pcie_2_reg.h"
#include "va_dma_core.h"

#define pcie2_dma_host_dbg(fmt, args...) do {	\
	VASTAI_PCI_DBG(NULL, 0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_host_err(fmt, args...) do {	\
	VASTAI_PCI_ERR(NULL, 0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_host_info(fmt, args...) do {	\
	VASTAI_PCI_INFO(NULL, 0xff, fmt, ##args);	\
} while(0);

struct pcie2_dma_host_cfg {
	u8 channel_id;
	u64 dma_reg;
};

struct pcie2_dma_host_channel {
	struct pcie2_dma_host_cfg *cfg;
	void *dma_reg_va;
};

struct pcie2_dma_host_device {
	u8 device_id;
	struct pcie2_dma_host_channel rd_ch;
	struct pcie2_dma_host_channel wr_ch;
};

//TODO: cfg should be from the capability of dev by reading dev reg
#define PCIE2_DMA_HOST_CFG_ITEM(__id, __dma_reg)	\
{	\
	.channel_id = __id,				\
	.dma_reg = __dma_reg,				\
}

static struct pcie2_dma_host_cfg dma_rd_cfg[] = {
	PCIE2_DMA_HOST_CFG_ITEM(0, PCIE2_DMA_REG_RD_CH(0)),
};
static struct pcie2_dma_host_cfg dma_wr_cfg[] = {
	PCIE2_DMA_HOST_CFG_ITEM(0, PCIE2_DMA_REG_WR_CH(0)),
};

static inline int pcie2_dma_host_poll_done(struct pcie2_dma_host_channel *ch,
					   u32 sleep_us, u32 timeout_us)
{
	ktime_t timeout;

	timeout = ktime_add_us(ktime_get(), timeout_us);
	might_sleep_if(sleep_us);
	do {
		/* poll channel status*/
		if ((readl(ch->dma_reg_va + PCIE2_DMA_REG_STATUS) == 0x03) &&
		    (readl(ch->dma_reg_va + PCIE2_DMA_REG_XFERSIZE) == 0))
		    break;

		if (timeout_us && ktime_compare(ktime_get(), timeout) > 0)
			return -EIO;

		if (sleep_us)
			usleep_range((sleep_us >> 2) + 1, sleep_us);
	} while (1);

	return 0;
}

static int pcie2_dma_host_ch_transfer(struct pcie2_dma_host_channel *ch,
				      struct va_dma_desc_elem *elem,
				      enum dma_transfer_direction direction)
{
	char *ch_name = (direction == DMA_DEV_TO_MEM) ? "wrch" : "rdch";
	u32 value;

	value = readl(ch->dma_reg_va + PCIE2_DMA_REG_STATUS);
	if (value == 1) {
		pcie2_dma_host_err("dma(%s_%d) is busy\n",
			ch_name, ch->cfg->channel_id);
		return -EBUSY;
	} else if (value == 2) {
		pcie2_dma_host_err("dma(%s_%d) is aborted\n",
			ch_name, ch->cfg->channel_id);
		return -EIO;
	} else if (value == 0) {
		pcie2_dma_host_err("dma(%s_%d) unknown error\n",
			ch_name, ch->cfg->channel_id);
		return -EIO;
	}

	if (direction == DMA_DEV_TO_MEM) {
		/**
		 * wr_ch
		 * source addr: dev memory
		 * dest addr: cpu memory
		 */
		writel(lower_32_bits(elem->dev_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_SAR_LOW);
		writel(upper_32_bits(elem->dev_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_SAR_HIGH);
		writel(lower_32_bits(elem->cpu_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_DAR_LOW);
		writel(upper_32_bits(elem->cpu_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_DAR_HIGH);
	}
	else {
		/**
		 * rd_ch
		 * source addr: cpu memory
		 * dest addr: dev memory
		 */
		writel(lower_32_bits(elem->cpu_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_SAR_LOW);
		writel(upper_32_bits(elem->cpu_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_SAR_HIGH);
		writel(lower_32_bits(elem->dev_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_DAR_LOW);
		writel(upper_32_bits(elem->dev_addr),
			ch->dma_reg_va + PCIE2_DMA_REG_DAR_HIGH);
	}

	/* set transfer size, max 4G, min 1B */
	writel(elem->size, ch->dma_reg_va + PCIE2_DMA_REG_XFERSIZE);

	/* start transfer */
	writel(1, ch->dma_reg_va + PICE2_DMA_REG_DOORBELL);

	if (pcie2_dma_host_poll_done(ch, 1000, 10000000)) {
		pcie2_dma_host_err("dma(%s_%d) transfer timeout, "
			"dma_status=%d\n",
			ch_name, ch->cfg->channel_id,
			readl(ch->dma_reg_va + PCIE2_DMA_REG_STATUS));
		return -EIO;
	}

	pcie2_dma_host_dbg("a dam transfer: mem_addr=0x%llx, dev_addr=0x%llx,"
			   " len=0x%x, dir=%s\n",
			   elem->cpu_addr, elem->dev_addr, elem->size,
			   (direction == DMA_DEV_TO_MEM) ? "d2m" : "m2d");

	return 0;
}

static int pcie2_dma_host_desc_submit(void *priv,
				      struct va_dma_descriptor *desc)
{
	int ret;
	struct pcie2_dma_host_channel *ch;
	struct pcie2_dma_host_device *pcie2_dma;
	struct va_dma_desc_elem *cur_elem;

	pcie2_dma = (struct pcie2_dma_host_device *)priv;

	ch = (desc->direction == DMA_DEV_TO_MEM)
			? &pcie2_dma->wr_ch : &pcie2_dma->rd_ch;

	if ((desc->direction != DMA_DEV_TO_MEM) &&
	    (desc->direction != DMA_MEM_TO_DEV)) {
		pcie2_dma_host_err("dma desc direction is invalid, %d\n",
				desc->direction);
		return -EINVAL;
	}

	list_for_each_entry(cur_elem, &desc->elem_head, node) {
		ret = pcie2_dma_host_ch_transfer(ch, cur_elem, desc->direction);
		if (ret)
			return ret;
	}

	if (desc->callback)
		desc->callback(desc->callback_param);

	return 0;
}

static int pcie2_dma_host_deinit(void* priv)
{
	struct pcie2_dma_host_device *pcie2_dma;

	pcie2_dma = (struct pcie2_dma_host_device *)priv;

	/* disable channel */
	writel(0, pcie2_dma->wr_ch.dma_reg_va + PICE2_DMA_REG_EN);
	writel(0, pcie2_dma->rd_ch.dma_reg_va + PICE2_DMA_REG_EN);

	kfree(pcie2_dma);

	return 0;
}

extern void * vastai_pci_mmio_kva_get(struct vastai_pci_info *priv,
				      u32 die_index,
				      u64 relative_addr,
				      u32 len);
static int _pcie2_dma_host_ch_init(struct vastai_pci_info *priv,
				   struct pcie2_dma_host_channel *ch,
				   struct pcie2_dma_host_cfg *cfg,
				   char *dir)
{
	ch->cfg = cfg;

	ch->dma_reg_va = vastai_pci_mmio_kva_get(priv, 0, cfg->dma_reg, 1);
	if (!ch->dma_reg_va) {
		pcie2_dma_host_err("dma_host(%s_%d) reg addr is invalid\n",
				   dir, cfg->channel_id);
		return -ENXIO;
	}

	/* disable linked list mode: bit0 */
	writel(0, ch->dma_reg_va + PCIE2_DMA_REG_CONTROL1);
	/* enable channel */
	writel(1, ch->dma_reg_va + PICE2_DMA_REG_EN);

	return 0;
}

struct va_dma_ops pcie2_dma_host_ops = {
	.submit = pcie2_dma_host_desc_submit,
	.deinit = pcie2_dma_host_deinit,
	.stop = NULL,
};

int va_pcie2_dma_host_init(struct vastai_pci_info *priv)
{
	int i, ret;
	struct pcie2_dma_host_device *pcie2_dma;
	va_dma_t *dma_dev;

	if (ARRAY_SIZE(dma_rd_cfg) != ARRAY_SIZE(dma_wr_cfg)) {
		pcie2_dma_host_err("the num of dma rd(%lu)/wr(%lu)"
			      "channel cfg don't match\n",
			      ARRAY_SIZE(dma_rd_cfg),
			      ARRAY_SIZE(dma_wr_cfg));
		return -EINVAL;
	}

	for (i = 0; i < ARRAY_SIZE(dma_rd_cfg); i++) {
		pcie2_dma = kzalloc(sizeof(struct pcie2_dma_host_device),
					GFP_KERNEL);
		if (!pcie2_dma) {
			pcie2_dma_host_err("pcie2_dma_host kmalloc fail\n");
			return -ENOMEM;
		}
		pcie2_dma->device_id = i;
		if (_pcie2_dma_host_ch_init(priv, &pcie2_dma->rd_ch,
				       &dma_rd_cfg[i], "rd_ch"))
			return -EIO;
		if (_pcie2_dma_host_ch_init(priv, &pcie2_dma->wr_ch,
				       &dma_wr_cfg[i], "wr_ch"))
			return -EIO;

		dma_dev = kzalloc(sizeof(va_dma_t), GFP_KERNEL);
		if (!dma_dev) {
			pcie2_dma_host_err("va_dam_t kmalloc fail\n");
			return -ENOMEM;
		}

		snprintf(dma_dev->name, VA_DMA_NAME_LEN_MAX,
			"pcie2_dma_host_%d", i);

		dma_dev->attr = VA_DMA_ATTR_DIR_MEM_TO_DEV |
				VA_DMA_ATTR_DIR_DEV_TO_MEM |
				VA_DMA_ATTR_SUPPORT_SHARED;
		dma_dev->ops = &pcie2_dma_host_ops;
		dma_dev->priv = pcie2_dma;
		ret = va_dma_add(priv, dma_dev);
		if (ret)
			return -EPERM;
	}

	/* DMA bypass ATU */
	//the DMA_BYPASS of IATU_REGION_CTRL_2_VIEWPORT_OFF_OUTBOUND

	return 0;
}

