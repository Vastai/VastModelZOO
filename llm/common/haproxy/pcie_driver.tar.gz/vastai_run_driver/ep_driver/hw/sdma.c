/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/05/24
 * Author: Kaien Ye
 */
#include <linux/kfifo.h>
#include <linux/ktime.h>
#include <linux/delay.h>

#include "vastai_pci.h"
#include "vastai_state.h"
#include "sdma.h"
#include "va_dma_core.h"
#include "va_irq.h"
#include "hw_config.h"
#include "vastai_pcie_public.h"
#include "sg100_gmcu.h"
#include "hw_queue.h"
#include "sg100_sdma.h"
#ifdef CONFIG_VASTAI_GFX
#include "../../gfx/gfx_mm.h"
#endif

#define pcie2_dma_dbg(fmt, args...) do {	\
	VASTAI_PCI_DBG(NULL,0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_err(fmt, args...) do {	\
	VASTAI_PCI_ERR(NULL,0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_info(fmt, args...) do {	\
	VASTAI_PCI_INFO(NULL,0xff, fmt, ##args);	\
} while(0);

int check_cur_sdma(struct vastai_pci_info *priv)
{
	int* ch_reg_data;
	int fatal_err, nofatal_err;
	int irq_reg_data;
	int i, ret=0;

	ch_reg_data = kzalloc(0x400, GFP_KERNEL);
	if (!ch_reg_data) {
		VASTAI_PCI_ERR(priv, 0,
				"pmd kmalloc fail\n");
		ret = -ENOMEM;
		return ret;
	}

	ret = vastai_read_by_smcu(priv, 0xaa0000, 0x400, ch_reg_data);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}

	ret = vastai_read_by_smcu(priv, 0xaa046c, 0x4, &irq_reg_data);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}

	ret = vastai_read_by_smcu(priv, 0xaa04b0, 0x4, &fatal_err);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}

	ret = vastai_read_by_smcu(priv, 0xaa04b8, 0x4, &nofatal_err);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}

	VASTAI_PCI_INFO(priv, 0,"************************* SDMA STATUS CHECK *************************\n");
	if(fatal_err)
		VASTAI_PCI_INFO(priv, 0,"ERROR:Get Fatal ERROR, 0x%x\n", fatal_err);
	else
		VASTAI_PCI_INFO(priv, 0,"There are no fatal err\n");

	if(nofatal_err)
		VASTAI_PCI_INFO(priv, 0,"ERROR:Get Non-Fatal ERROR, 0x%x\n", nofatal_err);
	else
		VASTAI_PCI_INFO(priv, 0,"There are no non-fatal err\n");

	VASTAI_PCI_INFO(priv, 0,"irq status:0x%x\n", irq_reg_data);

	for (i = 0; i < 32; i++)
	{
		VASTAI_PCI_INFO(priv, 0,"CH[%2d]  Desc_Done=0x%06x  Desc_addr=0x%08x  sid=%02d  pid=%03d\n",
				i, ch_reg_data[(i * 8) + 5], ch_reg_data[(i * 8) + 1], (ch_reg_data[(i * 8) + 6]) & 0x1F, ((ch_reg_data[(i * 8) + 6]) >> 6) & 0xFF);
	}

	return ret;
}

int sdma_debug(struct vastai_pci_info *priv, int chl_idx)
{
	int i,ret=0;
	int reg_base = (chl_idx < SDMA_CHL_CNT) ? SG100_SDMA0_CSR_BASE : SG100_SDMA1_CSR_BASE;
	u32 offset_chl = (chl_idx < SDMA_CHL_CNT) ? chl_idx : (chl_idx - SDMA_CHL_CNT);
	int* reg_data;
	int* reg_temp;

	reg_data = kzalloc(0x40, GFP_KERNEL);
	if (!reg_data) {
		VASTAI_PCI_ERR(priv, 0,
				"pmd kmalloc fail\n");
		ret = -ENOMEM;
		return ret;
	}

	reg_temp = reg_data;
	ret = vastai_read_by_smcu(priv, reg_base + 0x20 * offset_chl, 0x20, reg_temp);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	reg_temp+=8;

	ret = vastai_read_by_smcu(priv, 0xaa046c, 0x4, reg_temp);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	reg_temp+=1;


	ret = vastai_read_by_smcu(priv, 0xaa04b0, 0x10, reg_temp);
	if (ret) {
		VASTAI_PCI_ERR(priv, 0,"%s Invalidate pmd entry fail!, %d\n", __func__, ret);
		ret = -EPERM;
		return ret;
	}
	reg_temp+=4;

	for(i=0; i< 52; i+=4)
	{
		if(i<32)
		{
			pcie2_dma_info("0x%x:0x%x\n", 0xaa0000 + i + (offset_chl * 0x20), *reg_data);
		}
		else if(32==i)
		{
			pcie2_dma_info("0x%x:0x%x\n", 0xaa046c, *reg_data);
		}
		else if(32 < i)
		{
			pcie2_dma_info("0x%x:0x%x\n", 0xaa04b0 + i - 36, *reg_data);
		}
		reg_data++;
	}

	return ret;
}
static inline void ll_desc_fill(union sdma_ll_desc_element *data, struct va_dma_desc_elem *elem,
				enum dma_transfer_direction direction, u8 is_last, u64 msgq_addr_p, u8 src_mmu, u8 dst_mmu, u8 sync_tail)
{
	struct sdma_ll_write_desc_element *wr_data = NULL;
	struct sdma_ll_copy_desc_element  *cp_data = NULL;
	int irq_en = 0;

	/* Only the last desc enable an sdma done interrupt */
	if (is_last && (sync_tail == VASTAI_CHIP_SYNC))
	{
		irq_en = 1;
	}

    if(elem->desc_type == SDMA_OP_CODE_COPY)
    {
        pcie2_dma_dbg("desc_type=COPY, cpu_addr:0x%#llx, dev_addr:0x%#llx, size:0x%x, next desc addr: %#llx\n",
               elem->cpu_addr, elem->dev_addr, elem->size, msgq_addr_p);
        cp_data = &data->sll_cp_desc;

    	if (direction == DMA_DEV_TO_MEM) {
    		cp_data->src_addr_low = lower_32_bits(elem->dev_addr);
    		cp_data->src_addr_upp = upper_32_bits(elem->dev_addr);
    		cp_data->dst_addr_low = lower_32_bits(elem->cpu_addr);
    		cp_data->dst_addr_upp = upper_32_bits(elem->cpu_addr);
			/* DEV TO MEM src_hst is NOC dst_hst is PCIE*/
			cp_data->src_hst= 0;
			cp_data->dst_hst= 1;
    	}
        else if (direction == DMA_MEM_TO_DEV)
        {
    		cp_data->src_addr_low = lower_32_bits(elem->cpu_addr);
    		cp_data->src_addr_upp = upper_32_bits(elem->cpu_addr);
    		cp_data->dst_addr_low = lower_32_bits(elem->dev_addr);
    		cp_data->dst_addr_upp = upper_32_bits(elem->dev_addr);
			/* MEM TO DEV dst_hst is PCIE src_hst is NOC*/
			cp_data->src_hst= 1;
			cp_data->dst_hst= 0;
    	}
		else if (direction == DMA_MEM_TO_MEM)
		{
			cp_data->src_addr_low = lower_32_bits(elem->cpu_addr);
			cp_data->src_addr_upp = upper_32_bits(elem->cpu_addr);
			cp_data->dst_addr_low = lower_32_bits(elem->dev_addr);
			cp_data->dst_addr_upp = upper_32_bits(elem->dev_addr);
			/* MEM TO DEV dst_hst is PCIE src_hst is NOC*/
			cp_data->src_hst= 1;
			cp_data->dst_hst= 1;
		}
		else if (direction == DMA_DEV_TO_DEV)
		{
			cp_data->src_addr_low = lower_32_bits(elem->cpu_addr);
			cp_data->src_addr_upp = upper_32_bits(elem->cpu_addr);
			cp_data->dst_addr_low = lower_32_bits(elem->dev_addr);
			cp_data->dst_addr_upp = upper_32_bits(elem->dev_addr);
			/* MEM TO DEV dst_hst is PCIE src_hst is NOC*/
			cp_data->src_hst= 0;
			cp_data->dst_hst= 0;
		}
		else
		{
			pcie2_dma_info("Bad direction\n");
		}

			/* if ARM MMU is not enable, src_mmu and dst_mmu must to be 0 */
			cp_data->op = elem->desc_type;
			cp_data->trans_length = elem->size;
			cp_data->ll_last = is_last;
			cp_data->int_en = irq_en;
			cp_data->next_p_low = lower_32_bits(msgq_addr_p);
			cp_data->next_p_upp_8b = upper_32_bits(msgq_addr_p) & 0xFF;
			cp_data->src_mmu = !src_mmu;
			cp_data->dst_mmu = !dst_mmu;
			cp_data->dscp_cnt= 1;

    }
    else if(elem->desc_type == SDMA_OP_CODE_FILL)
    {
	    pcie2_dma_dbg("desc_type=FILL, dev_addr:0x%#llx, data:0x%#llx, size:0x%x, next desc addr:%#llx\n",
	               elem->dev_addr, elem->cpu_addr, elem->size, msgq_addr_p);
	    wr_data = &data->sll_wr_desc;
        if (direction == DMA_MEM_TO_DEV){
            wr_data->write_data_low = lower_32_bits(elem->cpu_addr);    // Use cpu_addr as the fill patten data.
            wr_data->write_data_upp = upper_32_bits(elem->cpu_addr);
            wr_data->dst_addr_low = lower_32_bits(elem->dev_addr);
            wr_data->dst_addr_upp = upper_32_bits(elem->dev_addr);
        } else {
            wr_data->write_data_low = lower_32_bits(elem->dev_addr);    // Use cpu_addr as the fill patten data.
            wr_data->write_data_upp = upper_32_bits(elem->dev_addr);
            wr_data->dst_addr_low = lower_32_bits(elem->cpu_addr);
            wr_data->dst_addr_upp = upper_32_bits(elem->cpu_addr);
        }
        wr_data->op = elem->desc_type;
        wr_data->trans_length = elem->size;
        wr_data->ll_last = is_last;
        wr_data->next_p_low = lower_32_bits(msgq_addr_p);
        wr_data->next_p_upp_8b = upper_32_bits(msgq_addr_p) & 0xFF;
		wr_data->dscp_cnt= 1;
		wr_data->int_en = irq_en;

		if (direction == DMA_DEV_TO_MEM)
		{
			wr_data->dst_hst= 1;
		}
		else
		{
			wr_data->dst_hst= 0;
		}

        if(dst_mmu){
            wr_data->dst_mmu= 0;
        }
        else{
            wr_data->dst_mmu= 1;
        }

    }
	else
	{
		pcie2_dma_info("descriptor type invalid!\n");
	}

}


static inline void ll_linklist_fill(struct sdma_ll_info_element *link, u64 next_llp)
{
	link->ll_addr_low  = lower_32_bits(next_llp);
	link->ll_addr_high = upper_32_bits(next_llp);
}

static inline int wait_sdma_desc_msgq_enough(struct hw_msgq *msgq,
				int elem_nums, u32 sleep_us, u32 timeout_us)
{
	ktime_t timeout;

	timeout = ktime_add_us(ktime_get(), timeout_us);
	might_sleep_if(sleep_us);
	do {
		/* poll channel status*/
		if (msgq_unused(msgq) >= elem_nums)
		    break;

		if (timeout_us && ktime_compare(ktime_get(), timeout) > 0)
			return -EIO;

		if (sleep_us) {
			pcie2_dma_info("wait_dma_msgq: sleep(%dus), unused=%d,"
					" need=%d\n", sleep_us,
					msgq_unused(msgq), elem_nums);
			usleep_range((sleep_us >> 2) + 1, sleep_us);
		}
	} while(1);

	return 0;
}

#define va_kfifo_in(fifo) \
({ \
		typeof((fifo) + 1) __tmpl = (fifo); \
		__tmpl->kfifo.in; \
})

#define va_kfifo_out(fifo) \
({ \
		typeof((fifo) + 1) __tmpl = (fifo); \
		__tmpl->kfifo.out; \
})

void sdma_reset(struct vastai_pci_info *priv)
{
	va_dma_t *dma;
	struct vastai_sdma_device *va_sdma;
	struct va_dma_descriptor *desc;
	struct vastai_sdma_channel *ch = NULL;
	int ret;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		return;
	}

	desc = kmalloc(sizeof(struct va_dma_descriptor), GFP_ATOMIC);
	if (!desc) {
		pcie2_dma_err("va_dma_descriptor kmalloc fails\n");
		return;
	}

	va_sdma = (struct vastai_sdma_device *)dma->priv;
	ch = &va_sdma->ch0;

RESET_SDMA:

	pcie2_dma_err("Chip into reboot/reset, start to clear DRV status, info_fifo in:%u,out:%u!\n",
				va_kfifo_in(&(ch->info_fifo)), va_kfifo_out(&(ch->info_fifo)));

	while(!kfifo_is_empty(&(ch->info_fifo)))
	{
		ret = kfifo_out(&ch->info_fifo, &desc, 1);
		if (1 != ret) {
			pcie2_dma_err("%s: dma desc_fifo out fail, %d\n",
						ch->name, 1);
		}

		desc->callback(desc->callback_param);
	}

	kfifo_reset(&(ch->info_fifo));
	if (!(ch == &va_sdma->ch1))
	{
		ch = &va_sdma->ch1;
		goto RESET_SDMA;
	}
	mdelay(1);

	return;
}


static int vastai_sdma_desc_submit(void *priv, struct va_dma_descriptor *desc)
{
	int ret = 0;
	struct vastai_sdma_channel *ch;
	struct vastai_sdma_device *va_sdma;
	struct sdma_ll_info_element *info_msg;
	union  sdma_ll_desc_element *ll_buf;
	union  sdma_ll_desc_element *cur_desc = NULL;
	struct va_dma_desc_elem *cur_elem;
	struct vastai_pci_info *pci_info;
	int total_nums;
	int elem_index, ll_index;
	u8 is_last = 0;
	u64 real_ddr_base = 0, desc_addr;
	int num;
	int state = 0;

	if (desc->direction > DMA_TRANS_NONE){
		pcie2_dma_err("desc direction is invalid, %d\n", desc->direction);
		return -EINVAL;
	}

	if (NULL == desc->priv)
	{
		pcie2_dma_err("priv is NULL\n");
		return -EINVAL;
	}

	pci_info = (struct vastai_pci_info *)desc->priv;

	state = vastai_get_pci_state(pci_info);
	if (VASTAI_NORMAL_STATE != state) {
		pcie2_dma_err("%s:pcie state error[%s]\n", __func__, state_name(state));
		return -EINVAL;
	}

	if (desc->pid < 0 || desc->pid > 256)
	{
		desc->pid = 0;
	}
	va_sdma = (struct vastai_sdma_device *)priv;

	if (HIGH_LEVEL_TASK == desc->priority)
		ch = &va_sdma->ch0;
	else if (LOW_LEVEL_TASK == desc->priority)
		ch = &va_sdma->ch1;
	else{
		pcie2_dma_err("Task priority is invalid\n");
		ch = &va_sdma->ch1;
	}

	if ((desc->elem_num > 1024 * 4) || (!desc->elem_num)) {
		pcie2_dma_err("%s: desc elem num is unsupport, %d\n", ch->name, desc->elem_num);
		BUG();
		return -EPERM;
	}

	total_nums = desc->elem_num;

	ll_buf = kzalloc(sizeof(union sdma_ll_desc_element) * total_nums, GFP_KERNEL);
	if (!ll_buf) {
		pcie2_dma_err("%s: ll_buf kmalloc failed, %d\n",
				ch->name, total_nums);
		ret = -ENOMEM;
		goto err_free_desc;
	}

	info_msg = kzalloc(sizeof(struct sdma_ll_info_element), GFP_KERNEL);
	if (!info_msg) {
		pcie2_dma_err("%s: info_msg kmalloc failed\n",ch->name);
		ret = -ENOMEM;
		goto err_free_info;
	}

	mutex_lock(&ch->lock);

	if (0 == desc->desc_loc)
	{
		ret = wait_sdma_desc_msgq_enough(&ch->desc_msgq, total_nums, 1000, 200 * 1000);
		if (ret) {
			pcie2_dma_err("%s: wait desc msgq timeout, %d\n",
					ch->name, total_nums);
			ret = -EIO;
			goto err_free_lock;
		}
		cur_desc = ch->first_desc_msg + msgq_wr(&ch->desc_msgq);
		ll_linklist_fill(info_msg, (u64)cur_desc);
	}
	else
	{
		#ifndef CONFIG_DDK_ALLOC_MEM
			real_ddr_base = ((u64)((u64)pci_info->priv_hw_cfg->header.hi32_ddr_base << 32)|
								pci_info->priv_hw_cfg->header.lo32_ddr_base) + 0xA000000;
			/* Descriptor addr must be offset by mpu, so we need to cut the ddr_base of function*/
			desc_addr = real_ddr_base - ((u64)((u64)pci_info->priv_hw_cfg->header.hi32_ddr_base << 32)|
								pci_info->priv_hw_cfg->header.lo32_ddr_base) + 0x1040000000;
		#else
			desc_addr = desc->desc_addr;
			/* Descriptor addr must be offset by mpu, so we need to cut the ddr_base of function*/
			real_ddr_base = desc_addr + ((u64)((u64)pci_info->priv_hw_cfg->header.hi32_ddr_base << 32)|
								pci_info->priv_hw_cfg->header.lo32_ddr_base) - 0x1040000000 ;
		#endif

		ll_linklist_fill(info_msg, desc_addr);
	}

	/* init */
	elem_index = 0;
	ll_index = 0;
	cur_elem = container_of(desc->elem_head.next, struct va_dma_desc_elem, node);

    while(ll_index < total_nums)
    {
        if((elem_index + 1) < total_nums)
            is_last = 0;
        else
            is_last = 1;

		if (0 == desc->desc_loc)
		{
			if (cur_desc >= ch->last_desc_msg) {
				cur_desc = ch->first_desc_msg;
			} else {
				cur_desc ++;
			}

			if (cur_elem->size < 4)
			{
				ret = -ENOMEM;
				goto err_free_lock;
			}

			ll_desc_fill(&ll_buf[ll_index], cur_elem,  desc->direction, is_last, (u64)cur_desc, desc->src_mmu, desc->dest_mmu, desc->sync_tail);
		}
		else
		{
			desc_addr += sizeof(union  sdma_ll_desc_element);
			if (cur_elem->size < 4)
			{
				ret = -ENOMEM;
				goto err_free_lock;
			}
			ll_desc_fill(&ll_buf[ll_index], cur_elem,  desc->direction, is_last, desc_addr, desc->src_mmu, desc->dest_mmu, desc->sync_tail);
		}
		ll_index++;
		elem_index++;

		cur_elem = container_of(cur_elem->node.next, struct va_dma_desc_elem, node);
    }

	if ((elem_index != desc->elem_num) || (&cur_elem->node != &desc->elem_head)) {
		pcie2_dma_err("%s: dma link list abnormal\n", ch->name);
		ret = -EPIPE;
		goto err_free_lock;
	}

	if (desc->sync_tail == VASTAI_CHIP_SYNC)
	{
		if (kfifo_is_full(&ch->info_fifo)) {
			pcie2_dma_err("info_fifo in:%u,out:%u!\n", va_kfifo_in(&ch->info_fifo), va_kfifo_out(&ch->info_fifo));
			pcie2_dma_err("%s: info_fifo is full!\n", ch->name);
			num = kfifo_avail(&ch->info_fifo);
			pcie2_dma_err("kfifo aval:0x%x\n", num);
			num = kfifo_len(&ch->info_fifo);
			pcie2_dma_err("kfifo len:0x%x\n\n", num);
			goto err_free_lock;
		}

		/* desc_fifo must run before dma_msgq */
		ret = kfifo_in(&ch->info_fifo, &desc, 1);
		if (ret != 1) {
			pcie2_dma_err("%s: dma desc_fifo in fail\n", ch->name);
			ret = -EIO;
			goto err_free_lock;
		}
	}

	if (0 == desc->desc_loc)
	{
		ret = msgq_in_entriely(&ch->desc_msgq, ll_buf, ll_index);
		if (ret != (ll_index)) {
			pcie2_dma_err("%s: dma desc_msgq in fail, %d\n", ch->name, ll_index);
			if (desc->sync_tail == VASTAI_CHIP_SYNC)
				ret = kfifo_out(&ch->info_fifo, &desc, 1);
			ret = -EIO;
			goto err_free_lock;
		}
	}
	else
	{
		/*TBD*/
		pcie2_dma_info("%s: dma descriptor storage on ddr!\n", ch->name);
		ret = vastai_pci_mem_write(pci_info, 0, real_ddr_base, ll_buf, ll_index * sizeof(union sdma_ll_desc_element));
		if (ret) {
			VASTAI_PCI_ERR(priv, 0,
					"%s write sdma descriptor to dev ddr fail!, %d\n",
					__func__, ret);
			if (desc->sync_tail == VASTAI_CHIP_SYNC)
				ret = kfifo_out(&ch->info_fifo, &desc, 1);
			ret = -EPERM;
			goto err_free_lock;
		}
	}

	/* this is ll_info */
	info_msg->pid = desc->pid;
	info_msg->ll_size = desc->elem_num;
	info_msg->loc = desc->desc_loc;
	info_msg->d2d = desc->d2d;
	info_msg->sync_tail = desc->sync_tail;

	ret = wait_sdma_desc_msgq_enough(&ch->info_msgq, 1, 1000, 200 * 1000);
	if (ret) {
		pcie2_dma_err("%s: wait desc msgq timeout, %d\n",
				ch->name, total_nums);
		if (desc->sync_tail == VASTAI_CHIP_SYNC)
			ret = kfifo_out(&ch->info_fifo, &desc, 1);
		ret = -EIO;
		goto err_free_lock;
	}

	ret = msgq_in_entriely(&ch->info_msgq, info_msg, 1);
	if (ret != 1) {
		pcie2_dma_err("%s: dma desc_msgq in fail, %d\n", ch->name, ret);
		if (desc->sync_tail == VASTAI_CHIP_SYNC)
			ret = kfifo_out(&ch->info_fifo, &desc, 1);
		ret = -EIO;
		goto err_free_lock;
	}

	pcie2_dma_dbg("%s pid(%d) submit done, elem_num=%d, d2d=%d, sync_tail=%d, desc_addr:%#llx\n", ch->name, info_msg->pid, info_msg->ll_size, info_msg->d2d, info_msg->sync_tail, desc_addr);

	ret = 0;

err_free_lock:
	mutex_unlock(&ch->lock);
err_free_info:
	kfree(info_msg);
err_free_desc:
	kfree(ll_buf);

	return ret;
}

static void vastai_sdma_irq_callback(void *arg, struct host_irq_msg *msg)
{
	int num, i, ret;
	struct va_dma_descriptor **desc;
	struct vastai_sdma_device *va_sdma;
	struct host_irq_pcie2_dma_msg *dma_msg;
	struct vastai_sdma_channel *ch = NULL;

	if (!arg || !msg) {
		BUG();
		return;
	}

	va_sdma = (struct vastai_sdma_device *)arg;
    // TBD
	dma_msg = &msg->msg.pcie2_dma;

	if (msg->irq_num == SDMA_CH0)
		ch = &va_sdma->ch0;
	if (msg->irq_num == SDMA_CH1)
		ch = &va_sdma->ch1;

	num = dma_msg->done_nums;
	num = 1;
	desc = kmalloc(sizeof(struct va_dma_descriptor *) * num, GFP_ATOMIC);
	if (!desc) {
		pcie2_dma_err("%s: va_dma_descriptor kmalloc fails, %d\n",
			      ch->name, num);
		return;
	}

	ret = kfifo_out(&ch->info_fifo, desc, num);
	if (num != ret) {
		pcie2_dma_err("%s: dma desc_fifo out fail, %d\n",
			      ch->name, num);
		goto err_free;
	}

	for (i = 0; i < num; i++) {
		if (desc[i]->callback)
			desc[i]->callback(desc[i]->callback_param);
	}

err_free:
	kfree(desc);
}

static int _vastai_sdma_ch_init(struct vastai_pci_info *priv,
			      struct vastai_sdma_channel *ch, u8 ch_id)
{
	char info_name[VA_HW_MSGQ_NAME_LEN_MAX];
	char desc_name[VA_HW_MSGQ_NAME_LEN_MAX];
	int ret = 0;
	void *info_reg_kva;
	void *info_buf_kva;
	void *desc_reg_kva;
	void *desc_buf_kva;

	snprintf(ch->name, VA_DMA_NAME_LEN_MAX, "%s%d", "sdma_ch", ch_id);

	// the csram address passed to the SDMA will be offset by the MPU,so wo need to cut a offset
	ch->first_info_msg = (struct sdma_ll_info_element *)(ch->info_cfg.msgq_buf -
					priv->priv_hw_cfg->header.csram_base + 0x800000);
	ch->last_info_msg = (struct sdma_ll_info_element  *)((ch->info_cfg.msgq_buf -
						priv->priv_hw_cfg->header.csram_base + 0x800000) +
						ch->info_cfg.msgq_buf_size - sizeof(struct sdma_ll_info_element));

	ch->first_desc_msg = (union sdma_ll_desc_element *)(ch->desc_cfg.msgq_buf -
					priv->priv_hw_cfg->header.csram_base + 0x800000);
	ch->last_desc_msg = (union sdma_ll_desc_element *)((ch->desc_cfg.msgq_buf -
						priv->priv_hw_cfg->header.csram_base + 0x800000) +
						ch->desc_cfg.msgq_buf_size - sizeof(union sdma_ll_desc_element));

	info_reg_kva = vastai_pci_mmio_kva_get(priv, 0, ch->info_cfg.msgq_reg, 1);
	if (!info_reg_kva) {
		pcie2_dma_err("sdma_ch%d: info msgq reg addr(%llx) is invalid\n",
			      ch_id, ch->info_cfg.msgq_reg);
		return -ENXIO;
	}

	info_buf_kva = vastai_pci_mmio_kva_get(priv, 0, ch->info_cfg.msgq_buf, 1);
	if (!info_buf_kva) {
		pcie2_dma_err("sdma_ch%d: info buf addr(%llx) is invalid\n",
				   ch_id, ch->info_cfg.msgq_buf);
		return -ENXIO;
	}

	desc_reg_kva = vastai_pci_mmio_kva_get(priv, 0, ch->desc_cfg.msgq_reg, 1);
	if (!info_reg_kva) {
		pcie2_dma_err("sdma_ch%d: desc msgq reg addr(%llx) is invalid\n",
			      ch_id, ch->desc_cfg.msgq_reg);
		return -ENXIO;
	}

	desc_buf_kva = vastai_pci_mmio_kva_get(priv, 0, ch->desc_cfg.msgq_buf, 1);
	if (!info_buf_kva) {
		pcie2_dma_err("sdma_ch%d: desc buf addr(%llx) is invalid\n",
				   ch_id, ch->desc_cfg.msgq_buf);
		return -ENXIO;
	}

	pcie2_dma_info("sdma_ch%d: info msgq reg addr:0x%llx, info msgq buf addr:0x%llx, info msgq buf size:0x%x,\n",
			ch_id, ch->info_cfg.msgq_reg, ch->info_cfg.msgq_buf, ch->info_cfg.msgq_buf_size);

	pcie2_dma_info("sdma_ch%d: desc msgq reg addr:0x%llx, desc msgq buf addr:0x%llx, desc msgq buf size:0x%x,\n",
			ch_id, ch->desc_cfg.msgq_reg, ch->desc_cfg.msgq_buf, ch->desc_cfg.msgq_buf_size);

	/* info_msg used to store msgq info about trigger sdma */
	snprintf(info_name, VA_HW_MSGQ_NAME_LEN_MAX, "%s_info_msgq", ch->name);
	ret = hw_msgq_init(&ch->info_msgq,
			info_name,
			(uint64_t)info_reg_kva,
			(uint64_t)info_buf_kva,
			ch->info_cfg.msgq_buf_size,
			sizeof(struct sdma_ll_info_element),
			priv);
	if (ret) {
		pcie2_dma_err("%s(), %s: info_hw_msgq_init fail, %d\n", __func__, ch->name, ret);
		return -EPERM;
	}

	/* info_msg used to store sdma descriptor info about move data */
	snprintf(desc_name, VA_HW_MSGQ_NAME_LEN_MAX, "%s_desc_msgq", ch->name);
	ret = hw_msgq_init(&ch->desc_msgq,
			desc_name,
			(uint64_t)desc_reg_kva,
			(uint64_t)desc_buf_kva,
			ch->desc_cfg.msgq_buf_size,
			sizeof(union sdma_ll_desc_element),
			priv);
	if (ret) {
		pcie2_dma_err("%s(), %s: desc_hw_msgq_init fail, %d\n", __func__, ch->name, ret);
		return -EPERM;
	}

	INIT_KFIFO(ch->info_fifo);
	mutex_init(&ch->lock);

	return 0;
}

static int init_sdma_elem_cfg(struct vastai_pci_info *priv, struct vastai_sdma_ch_cfg *cfg, int chl_id)
{
	struct ring_buf_entry *ch_entry = NULL;
	if (chl_id == SDMA_CH0)
	{
		if( ONLY_1_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_1_PF_GMCU1_HIGH_PRIORITY_SDMA_ELEM_NAME);
		} else if (ONLY_2_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_2_PF_HIGH_PRIORITY_SDMA_ELEM_NAME);
		} else {
			ch_entry = find_hw_cfg_acord_name(priv, COMMON_HIGH_PRIORITY_SDMA_ELEM_NAME);
		}
	}
	else if(chl_id == SDMA_CH1)
	{
		if( ONLY_1_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_1_PF_GMCU1_LOW_PRIORITY_SDMA_ELEM_NAME);
		} else if (ONLY_2_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_2_PF_LOW_PRIORITY_SDMA_ELEM_NAME);
		} else {
			ch_entry = find_hw_cfg_acord_name(priv, COMMON_LOW_PRIORITY_SDMA_ELEM_NAME);
		}
	}
	else
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Wrong channle id\n");

	if(NULL==ch_entry){
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "init_sdma_cfg fail\n");
		return -EINVAL;
	}
	cfg->msgq_reg	= ch_entry->msgq_ctrl_reg_base;
	cfg->msgq_buf	= ch_entry->ring_buf_base;
	cfg->msgq_buf_size = ch_entry->ring_buf_size;

	return 0;
}

static int init_sdma_msgq_cfg(struct vastai_pci_info *priv, struct vastai_sdma_ch_cfg *cfg, int chl_id)
{
	struct ring_buf_entry *ch_entry = NULL;

	if (chl_id == SDMA_CH0)
	{
		if( ONLY_1_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_1_PF_GMCU1_HIGH_PRIORITY_MSGQ_INFO_NAME);
		} else if (ONLY_2_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_2_PF_GMCU_HIGH_PRIORITY_MSGQ_INFO_NAME);
		} else {
			ch_entry = find_hw_cfg_acord_name(priv, COMMON_HIGH_PRIORITY_MSGQ_NAME);
		}
	}
	else if (chl_id == SDMA_CH1)
	{
		if( ONLY_1_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_1_PF_GMCU1_LOW_PRIORITY_MSGQ_INFO_NAME);
		} else if (ONLY_2_PF == priv->fn_mode) {
			ch_entry = find_hw_cfg_acord_name(priv, ONLY_2_PF_GMCU_LOW_PRIORITY_MSGQ_INFO_NAME);
		} else {
			ch_entry = find_hw_cfg_acord_name(priv, COMMON_LOW_PRIORITY_MSGQ_NAME);
		}
	}
	else
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Wrong channle id\n");

	if(NULL==ch_entry){
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "init_sdma_cfg fail\n");
			return -EINVAL;
	}
	cfg->msgq_reg	  = ch_entry->msgq_ctrl_reg_base;
	cfg->msgq_buf	  = ch_entry->ring_buf_base;
	cfg->msgq_buf_size = ch_entry->ring_buf_size;

	return 0;
}

static int vastai_sdma_deinit(void *priv)
{
	struct vastai_sdma_device *va_sdma = priv;

	//TODO
	//va_host_irq_unregister(enum host_irq_num num);
	kfree(va_sdma);

	return 0;
}

struct va_dma_ops vastai_sdma_ops = {
	.submit = vastai_sdma_desc_submit,
	.deinit = vastai_sdma_deinit,
	.stop = NULL,
};

int vastai_sdma_init(struct vastai_pci_info *priv)
{
	int ret;
	struct vastai_sdma_device *va_sdma;
	va_dma_t *dma_dev;

	if (!priv) {
		return -EINVAL;
	}

	va_sdma = kzalloc(sizeof(struct vastai_sdma_device), GFP_KERNEL);
	if (!va_sdma) {
		pcie2_dma_err("pcie2_dma kmalloc fail\n");
		return -ENOMEM;
	}

	ret = init_sdma_elem_cfg(priv, &va_sdma->ch0.desc_cfg, SDMA_CH0);
	if(ret){
		pcie2_dma_err("init sdma channel0 cfg fail\n");
		return -EIO;
	}

	ret = init_sdma_msgq_cfg(priv, &va_sdma->ch0.info_cfg, SDMA_CH0);
	if(ret){
		pcie2_dma_err("init sdma channel0 cfg fail\n");
		return -EIO;
	}

	ret = init_sdma_elem_cfg(priv, &va_sdma->ch1.desc_cfg, SDMA_CH1);
	if(ret){
		pcie2_dma_err("init sdma channel1 cfg fail\n");
		return -EIO;
	}

	ret = init_sdma_msgq_cfg(priv, &va_sdma->ch1.info_cfg, SDMA_CH1);
	if(ret){
		pcie2_dma_err("init sdma channel1 cfg fail\n");
		return -EIO;
	}

	snprintf(va_sdma->name, VA_DMA_NAME_LEN_MAX, "vastai_sdma");

	if (_vastai_sdma_ch_init(priv, &va_sdma->ch0, SDMA_CH0)) {
		pcie2_dma_err("%s(), %s channel0 init fail\n", __func__, va_sdma->name);
		return -EIO;
	}

	if (_vastai_sdma_ch_init(priv, &va_sdma->ch1, SDMA_CH1)) {
		pcie2_dma_err("%s(), %s channel1 init fail\n", __func__, va_sdma->name);
		return -EIO;
	}

	dma_dev = kzalloc(sizeof(va_dma_t), GFP_KERNEL);
	if (!dma_dev) {
		pcie2_dma_err("dma_dev kmalloc fail\n");
		return -ENOMEM;
	}
	snprintf(dma_dev->name, VA_DMA_NAME_LEN_MAX, "%s", va_sdma->name);
	dma_dev->attr = VA_DMA_ATTR_DIR_MEM_TO_DEV |
			VA_DMA_ATTR_DIR_DEV_TO_MEM |
			VA_DMA_ATTR_SUPPORT_SHARED;
	dma_dev->ops = &vastai_sdma_ops;
	dma_dev->priv = va_sdma;
	dma_dev->pci_info = priv;
	ret = va_dma_add(priv, dma_dev);
	if (ret) {
		pcie2_dma_err("%s: va_dma_add fail, %d\n", dma_dev->name, ret);
		return -EPERM;
	}
	priv->dma_dev = dma_dev;

	ret = va_host_irq_register(priv, SDMA_CH0,
				   vastai_sdma_irq_callback, va_sdma);
	if (ret) {
		pcie2_dma_err("%s: va_host_irq_register fail, irq=%d, ret=%d\n",
			      va_sdma->name, 0, ret);
		return -EIO;
	}

	ret = va_host_irq_register(priv, SDMA_CH1,
				   vastai_sdma_irq_callback, va_sdma);
	if (ret) {
		pcie2_dma_err("%s: va_host_irq_register fail, irq=%d, ret=%d\n",
			      va_sdma->name, 0, ret);
		return -EIO;
	}

	sema_init(&priv->credit_sem, VASTAI_DMA_CREDIT_LIMIT_SG);

	pcie2_dma_dbg("sdma init done!\n");

	return 0;
}

