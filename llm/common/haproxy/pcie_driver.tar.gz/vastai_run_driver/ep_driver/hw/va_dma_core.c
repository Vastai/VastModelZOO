/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/04
 * Author: adan.xue
 */

#include <linux/list.h>
#include <linux/spinlock.h>

#include "va_dma_core.h"

#define va_dma_dbg(fmt, args...) do {	\
	VASTAI_PCI_DBG(NULL, 0xff, fmt, ##args);	\
} while(0);

#define va_dma_err(fmt, args...) do {	\
	VASTAI_PCI_ERR(NULL, 0xff, fmt, ##args);	\
} while(0);

#define va_dma_info(fmt, args...) do {	\
	VASTAI_PCI_INFO(NULL, 0xff, fmt, ##args);	\
} while(0);

void va_dma_descriptor_free(struct va_dma_descriptor *desc)
{
	struct va_dma_desc_elem *pos, *next;

	list_for_each_entry_safe(pos, next, &desc->elem_head, node) {
		kfree(pos);
	}

	kfree(desc);
}
EXPORT_SYMBOL(va_dma_descriptor_free);

int add_elem_to_dma_desc(struct va_dma_descriptor *desc,
				u32 len, u64 mem, u64 dev)
{
	struct va_dma_desc_elem *elem;

	elem = kzalloc(sizeof(struct va_dma_desc_elem), GFP_KERNEL);
	if (!elem) {
		va_dma_err("dma desc elem kmalloc fail\n");
		return -1;
	}

	elem->size = len;
	elem->cpu_addr = mem;
	elem->dev_addr = dev;
	desc->total_len += len;

	va_dma_dbg("add_elem_to_dma_desc: cpu=0x%llx, dev=0x%llx, len=%x\n",
			mem, dev, len);

	list_add_tail(&(elem->node), &(desc->elem_head));
	return 0;
}
EXPORT_SYMBOL(add_elem_to_dma_desc);

struct va_dma_descriptor *va_dma_prep_slave_sg(va_dma_t *dma,
				struct scatterlist *sgl,
				unsigned int sg_len,
				u64 dev_addr,
				enum dma_transfer_direction direction)
{
	int ret;
	struct va_dma_descriptor *desc;
	unsigned int elem_num = 0;
	struct scatterlist *sg, *sg_next_p;
	unsigned int i;
	u64 len, len_next;
	dma_addr_t addr, addr_next;

	if (!dma || !sgl || !sg_len) {
		va_dma_err("%s: invalid parameter\n", dma->name);
		return NULL;
	}

	if (!is_slave_direction(direction)) {
		va_dma_err("%s: isn't slave dirction\n", dma->name);
		return NULL;
	}

	desc = kzalloc(sizeof(*desc), GFP_KERNEL);
	if (!desc) {
		va_dma_err("%s: desc alloc error\n", dma->name);
		return NULL;
	}

	va_dma_dbg("%s: once dma transfer: dir=%s\n",
		   dma->name, (direction == DMA_MEM_TO_DEV) ? "m2d" : "d2m" );

	INIT_LIST_HEAD(&desc->elem_head);

	for_each_sg(sgl, sg, sg_len, i) {
		len = sg_dma_len(sg);
		addr = sg_dma_address(sg);

		if (len == 0)
			break;

		while ((i + 1) < sg_len) {
			sg_next_p = sg_next(sg);
			len_next = sg_dma_len(sg_next_p);
			addr_next = sg_dma_address(sg_next_p);

			if (len_next == 0)
				break;

			if (addr + len == addr_next) {
				len += len_next;
				i++;
				sg = sg_next_p;
			} else {
				break;
			}
		}

		if (direction == DMA_MEM_TO_DEV) {
			dma->monitor.tx_byte += len;
		} else {
			dma->monitor.rx_byte += len;
		}

		elem_num++;
		ret = add_elem_to_dma_desc(desc, len, addr, dev_addr);
		if (ret) {
			va_dma_err("%s: add elem to desc failed, %llu\n",
					dma->name, len);
			goto err_free;
		}
		dev_addr += len;
	}

	if (!elem_num)
		goto err_free;
	desc->elem_num = elem_num;
	desc->direction = direction;
	desc->priv = dma->pci_info;

	return desc;

err_free:
	va_dma_descriptor_free(desc);
	return NULL;
}
EXPORT_SYMBOL(va_dma_prep_slave_sg);

struct va_dma_descriptor *va_dma_prep_desc_array(va_dma_t *dma,
				u64 *mem_addr, u64 *dev_addr, u32 *size,
				u32 elem_nums,
				enum dma_transfer_direction direction)
{
	int ret;
	struct va_dma_descriptor *desc;
	int i;

	if (!dma || !mem_addr || !dev_addr || !size || !elem_nums) {
		va_dma_err("%s: invalid parameter\n", dma->name);
		return NULL;
	}

	if (!is_slave_direction(direction)) {
		va_dma_err("%s: isn't slave dirction\n", dma->name);
		return NULL;
	}

	desc = kzalloc(sizeof(*desc), GFP_KERNEL);
	if (!desc) {
		va_dma_err("%s: desc alloc error\n", dma->name);
		return NULL;
	}

	va_dma_dbg("%s: once dma transfer: dir=%s\n",
		   dma->name, (direction == DMA_MEM_TO_DEV) ? "m2d" : "d2m" );

	INIT_LIST_HEAD(&desc->elem_head);

	for (i = 0; i < elem_nums; i++) {
		ret = add_elem_to_dma_desc(desc, size[i], mem_addr[i],
					   dev_addr[i]);
		if (ret) {
			va_dma_err("%s: add elem to desc failed, %u\n",
					dma->name, size[i]);
			goto err_free;
		}
	}

	desc->elem_num = elem_nums;
	desc->direction = direction;

	return desc;

err_free:
	va_dma_descriptor_free(desc);
	return NULL;
}

int va_dma_desc_submit(va_dma_t *dma, struct va_dma_descriptor *desc)
{
	int ret = 0;

	if (!dma || !desc)
		return -EINVAL;

	if (!desc->elem_num)
		return -EINVAL;

	//TODO: add monitor

	if (dma->ops->submit)
		ret = dma->ops->submit(dma->priv, desc);

	if (ret)
		return -ENODEV;

	va_dma_dbg("%s: desc submit, dir=%s, elem_nums=%u\n",
		   dma->name,
		   (desc->direction == DMA_MEM_TO_DEV) ? "m2d" : "d2m",
		   desc->elem_num);
	return 0;
}
EXPORT_SYMBOL(va_dma_desc_submit);

va_dma_t *va_dma_alloc(struct vastai_pci_info *priv, u32 flags, u32 attr)
{
	struct va_dma_table *dma_table;
	va_dma_t *pos, *next;

	if (!priv) {
		va_dma_err("va_dma_alloc: priv is NULL\n");
		return NULL;
	}

	dma_table = &priv->dma_table;

	spin_lock(&dma_table->lock);
	list_for_each_entry_safe(pos, next, &dma_table->head, node) {
		if ((kref_read(&pos->ref_cnt) > 1) &&
		    !(pos->attr & VA_DMA_ATTR_SUPPORT_SHARED))
			continue;
		if ((pos->attr & attr) == attr) {
			kref_get(&pos->ref_cnt);
			spin_unlock(&dma_table->lock);
			//va_dma_dbg("alloc %s succeed\n", pos->name);
			return pos;
		}
	}
	spin_unlock(&dma_table->lock);
	return NULL;
}

static void va_dma_free_err_report(struct kref *kref)
{
	va_dma_t *dma;

	dma = container_of(kref, va_dma_t, ref_cnt);
	va_dma_err("dma(%s) free fault!\n", dma->name);
}

int va_dma_free(struct vastai_pci_info *priv, va_dma_t *dma)
{
	if (!priv)
		return -EINVAL;

	spin_lock(&priv->dma_table.lock);
	kref_put(&dma->ref_cnt, va_dma_free_err_report);
	spin_unlock(&priv->dma_table.lock);

	return 0;
}

int va_dma_add(struct vastai_pci_info *priv, va_dma_t *dma)
{
	struct va_dma_table *dma_table;

	if (!priv || !dma)
		return -EINVAL;

	dma_table = &priv->dma_table;

	dma->monitor.tx_byte = 0;
	dma->monitor.rx_byte = 0;

	spin_lock(&dma_table->lock);
	kref_init(&dma->ref_cnt);
	list_add_tail(&dma->node, &dma_table->head);
	spin_unlock(&dma_table->lock);

	//TODO: add somethings to debugfs as a dma debug node

	va_dma_dbg("add %s succeed\n", dma->name);
	return 0;
}

static void va_dma_release(struct kref *kref)
{
	va_dma_t *dma;
	int ret;

	dma = container_of(kref, va_dma_t, ref_cnt);
	if (dma->ops->deinit) {
		ret = dma->ops->deinit(dma->priv);
		if (ret)
			va_dma_err("dma(%s) release fail, %d\n",
					dma->name, ret);
	}
	//NOTE: va_dma_t must be created by dynamic kmalloc
	kfree(dma);
}

int va_dma_release_all(struct vastai_pci_info *priv)
{
	va_dma_t *pos, *next;
	struct va_dma_table *dma_table;

	if (!priv)
		return -EINVAL;

	dma_table = &priv->dma_table;

	spin_lock(&dma_table->lock);
	list_for_each_entry_safe(pos, next, &dma_table->head, node) {
		list_del(&pos->node);
		if (kref_put(&pos->ref_cnt, va_dma_release) != 1)
			va_dma_err("dma(%s) deinit fail", pos->name);
	}

	spin_unlock(&dma_table->lock);
	return 0;
}

int va_dma_core_init(struct vastai_pci_info *priv)
{
	struct va_dma_table *dma_table;

	if (!priv)
		return -EINVAL;

	dma_table = &priv->dma_table;

	spin_lock_init(&dma_table->lock);
	INIT_LIST_HEAD(&dma_table->head);

	return 0;
}
