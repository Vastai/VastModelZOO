/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/04
 * Author: adan.xue
 */

#include "vastai_pci.h"
#include "va_dma_core.h"
#include "sdma.h"
#include "smmu.h"
#include "../../include/common/sg100/sg100_gmcu.h"
#include <linux/delay.h>
#include "vastai_dmabuf.h"

extern struct vastai_dma_buf dmb[4];

static void sdma_transfer_test_callback(void *param)
{
	struct completion *completion = param;
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "#######SDMA IRQ comes. %s\n", __func__);

	if (completion)
		complete(completion);
	return;
}

#define VA_SDMA_TEST_SELFCHECK_EN 1

// Func:
// Params: dir: 0 host-->host; 1 host --> dev; 2 dev --> host; 3 dev --> dev
//              By default: dmb[0]: src addr;  dmb[1]: dest addr, if we need test MEM to MEM.
//              dev_addr: dev DDR address.
void va_sdma_op_cp_test(struct vastai_pci_info *priv, u8 loc_dir, u8 mmu_en, u64 addr0, u64 addr1, u32 trans_len, u32 pid);
void va_sdma_op_fill_test(struct vastai_pci_info *priv, u8 loc_dir, u8 dst_mmu, u64 dst_addr, u32 trans_len, u64 trans_val, int pid);
void va_sdma_op_fence_test(struct vastai_pci_info *priv, u8 dir, u8 mmu_en, u64 dev_addr, u32 trans_len, u32 desc_cnt, u64 wr_data);
int va_sdma_cp_test_for_probe(struct vastai_pci_info *priv, u8 loc_dir, u8 mmu_en, u64 addr0, u64 addr1, u32 trans_len, u32 pid);

void va_sdma_op_cp_test(struct vastai_pci_info *priv, u8 loc_dir, u8 mmu_en, u64 addr0, u64 addr1, u32 trans_len, u32 pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	int dir, loc;
	int src_mmu, dst_mmu;
	int ret = 0;

	src_mmu = (mmu_en >> 4) & 0xF;
	dst_mmu = mmu_en & 0xF;
	dir = loc_dir & 0xF;
	loc = (loc_dir >> 4) & 0xF;

	if (dir >= DMA_TRANS_NONE)
	{
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Direction is Unvalid!\n");
	}

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return;
	}

	if (trans_len <= 0)
	{
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"The transfer data size(%d) is invalid!\n", trans_len);
		goto dma_free;
	}

	if (dir != DMA_DEV_TO_DEV)
	{
		if (trans_len > dmb[0].size)
		{
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"The transfer data size cannot exceed %#X!\n", dmb[0].size);
			goto dma_free;
		}
	}
	elem.size = trans_len;
	elem.desc_type = SDMA_OP_CODE_COPY;

	va_create_pid(priv, pid);
	switch(dir)
	{
		case DMA_MEM_TO_MEM: {
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "dir is DMA_MEM_TO_MEM\n");
			if (src_mmu){
				elem.cpu_addr = (u64)dmb[0].vir;
				va_create_page_mapping(priv, dmb[0].dma_bus_addr, (u64)dmb[0].vir, trans_len, pid, 1);
			}
			else{
				elem.cpu_addr = dmb[0].dma_bus_addr;
			}

			if (dst_mmu){
				elem.dev_addr = (u64)dmb[1].vir;
				va_create_page_mapping(priv, dmb[1].dma_bus_addr, (u64)dmb[1].vir, trans_len, pid, 1);
			}
			else{
				elem.dev_addr = dmb[1].dma_bus_addr;
			}
			break;
		}

		case DMA_MEM_TO_DEV: {
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "dir is DMA_MEM_TO_DEV\n");
			if (src_mmu){
				elem.cpu_addr = (u64)dmb[0].vir;
				va_create_page_mapping(priv, dmb[0].dma_bus_addr, (u64)dmb[0].vir, trans_len, pid, 1);
			}
			else{
				elem.cpu_addr = dmb[0].dma_bus_addr;
			}

			elem.dev_addr = addr0;
			break;
		}

		case DMA_DEV_TO_MEM: {
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "dir is DMA_DEV_TO_MEM\n");
			if (dst_mmu){
				elem.cpu_addr = (u64)dmb[0].vir;
				va_create_page_mapping(priv, dmb[0].dma_bus_addr, (u64)dmb[0].vir, trans_len, pid, 1);
			}
			else{
				elem.cpu_addr = dmb[0].dma_bus_addr;
			}
			elem.dev_addr = addr0;
			break;
		}

		case DMA_DEV_TO_DEV: {
			VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "dir is DMA_DEV_TO_DEV\n");
			elem.cpu_addr = addr0;
			elem.dev_addr = addr1;
		}

		default:
			break;
	}

	init_completion(&completion);

	desc.direction = dir;
	INIT_LIST_HEAD(&desc.elem_head);
	desc.elem_num = 1;
	desc.callback = sdma_transfer_test_callback;
	desc.callback_param = &completion;
	elem.desc_type = SDMA_OP_CODE_COPY;
	desc.dest_mmu = dst_mmu;
	desc.src_mmu  = src_mmu;
	desc.pid = pid;
	desc.desc_loc = loc;
	desc.priv = priv;
	desc.sync_tail = 0;
	desc.d2d = 0;
	list_add_tail(&(elem.node), &(desc.elem_head));

	ret = va_dma_desc_submit(dma, &desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "SDMA transfer completoin!\n");

dma_free:
	va_dma_free(priv, dma);

	return;
}

void va_sdma_op_fill_test(struct vastai_pci_info *priv, u8 loc_dir, u8 dst_mmu, u64 dst_addr, u32 trans_len, u64 trans_val, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	int ret = 0;
	int s_bit = 0;
	int dir, loc;

	dir = loc_dir & 0xF;
	loc = (loc_dir >> 4) & 0xF;

	ret = va_create_pid(priv, pid);
	if (ret)
	{
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"Init CD entry of pid(%d) failed!\n", pid);
		return;
	}

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return;
	}

	init_completion(&completion);
	if(dir >= DMA_TRANS_NONE)
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: error trans dir: %d\n", __func__, dir);

	desc.direction = dir & 0xF;
	INIT_LIST_HEAD(&desc.elem_head);
	desc.elem_num = 1;
	desc.callback = sdma_transfer_test_callback;
	desc.callback_param = &completion;

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "once_dma_transfer: dev_addr=%#llX, dir=%d, dst_mmu=%d, trans_len=%#x, trans_val=0x%llx\n",
							dst_addr, dir, dst_mmu, trans_len, trans_val);

	elem.desc_type = SDMA_OP_CODE_FILL;
	elem.size = trans_len;
	elem.cpu_addr = trans_val;

	// By default: dmb[0]: src addr, dmb[1]: dest addr if we need test MEM to MEM.
	if(dir == DMA_MEM_TO_DEV)
	{
		if (dst_mmu){
			elem.dev_addr = (u64)dst_addr;
			s_bit = 0;

			/* add pte entry */
			ret = va_create_page_mapping(priv, 0x1040000000, dst_addr, trans_len/VASTAI_PAGE_SIZE, pid, s_bit);
			if (ret) {
				VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
						   "%s: init translate entry failed! %d\n", __func__, ret);
				goto dma_free;

			}
		}
		else{
			elem.dev_addr = (u64)dst_addr;
		}
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "dir = %d\n", dir);
	}
	else if(dir == DMA_DEV_TO_MEM)
	{
		if (dst_mmu){
			elem.dev_addr = (u64)dmb[0].vir;
			s_bit = 1;

			ret = va_create_page_mapping(priv, dmb[0].dma_bus_addr, (u64)dmb[0].vir, dmb[0].size, pid, s_bit);
			if (ret) {
				VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
					       "%s: init translate entry failed! %d\n", __func__, ret);
				goto dma_free;
			}
		}
		else{
			elem.cpu_addr = dmb[0].dma_bus_addr;
            elem.dev_addr = trans_val;
		}
	}
	else
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: Invalid descriptor optcode\n", __func__);
		goto dma_free;
	}
	list_add_tail(&(elem.node), &(desc.elem_head));

	desc.dest_mmu = dst_mmu;
	desc.src_mmu  = 0;
	desc.pid = pid;
	desc.desc_loc = loc;
	desc.priv = priv;
	desc.sync_tail = 0;
	desc.d2d = 0;
	ret = va_dma_desc_submit(dma, &desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "SDMA transfer completoin!\n");

dma_free:
	va_dma_free(priv, dma);

	return;

}

void va_sdma_op_fence_test(struct vastai_pci_info *priv, u8 dir, u8 mmu_en, u64 dev_addr, u32 trans_len, u32 desc_cnt, u64 wr_data)
{

}


#define WAIT_COMPLETITION_TIMEOUT  10000  // ms
// Func: ret > 0: succeeded
int va_sdma_cp_test_for_probe(struct vastai_pci_info *priv, u8 loc_dir, u8 mmu_en, u64 addr0, u64 addr1, u32 trans_len, u32 pid)
{
	va_dma_t *dma = NULL;
	struct va_dma_descriptor desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	int dir, loc;
	int src_mmu, dst_mmu;
	int ret = 0;
	struct vastai_dma_buf dm_test;

	memset(&desc, 0, sizeof(struct va_dma_descriptor));
	src_mmu = (mmu_en >> 4) & 0xF;
	dst_mmu = mmu_en & 0xF;
	dir = loc_dir & 0xF;
	loc = (loc_dir >> 4) & 0xF;

	if (dir >= DMA_TRANS_NONE)
	{
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Direction is Unvalid!\n");
	}

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		ret = -EIO;
		goto dma_free;
	}

	if (trans_len <= 0)
	{
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"The transfer data size(%d) is invalid!\n", trans_len);
		ret = -EIO;
		goto dma_free;
	}

	ret = vastai_udma_malloc(priv, &dm_test, trans_len);
	if (ret != 0)
	{
		ret = -ENOMEM;
		goto dma_free;
	}
	memset((unsigned char *)(dm_test.vir), 0x5a5a5a5a, trans_len);

	if (dir != DMA_DEV_TO_DEV)
	{
		if (trans_len > dm_test.size)
		{
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"The transfer data size cannot exceed %#X!\n", dm_test.size);
			ret = -EIO;
			goto dma_free;
		}
	}
	elem.size = trans_len;
	elem.desc_type = SDMA_OP_CODE_COPY;

	//va_create_pid(priv, pid);
	switch(dir)
	{
		case DMA_MEM_TO_DEV: {
			VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "dir is DMA_MEM_TO_DEV\n");
			if (src_mmu){
				elem.cpu_addr = (u64)dmb[0].vir;
				va_create_page_mapping(priv, dm_test.dma_bus_addr, (u64)dm_test.vir, trans_len, pid, 1);
			}
			else{
				elem.cpu_addr = dm_test.dma_bus_addr;
			}

			elem.dev_addr = addr0;
			break;
		}

		case DMA_DEV_TO_MEM: {
			VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "dir is DMA_DEV_TO_MEM\n");
			if (dst_mmu){
				elem.cpu_addr = (u64)dm_test.vir;
				va_create_page_mapping(priv, dm_test.dma_bus_addr, (u64)dm_test.vir, trans_len, pid, 1);
			}
			else{
				elem.cpu_addr = dm_test.dma_bus_addr;
			}
			elem.dev_addr = addr0;
			break;
		}

		default:
			break;
	}

	init_completion(&completion);

	desc.direction = dir;
	INIT_LIST_HEAD(&desc.elem_head);
	desc.elem_num = 1;
	desc.callback = sdma_transfer_test_callback;
	desc.callback_param = &completion;
	elem.desc_type = SDMA_OP_CODE_COPY;
	desc.dest_mmu = dst_mmu;
	desc.src_mmu  = src_mmu;
	desc.pid = pid;
	desc.desc_loc = loc;
	desc.priv = priv;
	list_add_tail(&(elem.node), &(desc.elem_head));

	ret = va_dma_desc_submit(dma, &desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: push_dma_desc error %d\n", __func__, ret);
		ret = -EIO;
		goto dma_free;
	}

	// ret > 0: succeeded
	ret = wait_for_completion_interruptible_timeout(&completion, msecs_to_jiffies(WAIT_COMPLETITION_TIMEOUT));
	if (ret < 0) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "WARNING: %s: wait completion is interrupted: %d\n", __func__, ret);

		mdelay(2000);
		ret = -EIO;
		goto dma_free;
	} else if(ret == 0) {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "WARNING: %s: wait completion is timeout.\n", __func__);
		ret = -EIO;
		goto dma_free;
	}

dma_free:
	va_dma_free(priv, dma);
	vastai_udma_free(priv, &dm_test);
	return ret;
}
