/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/03/04
 * Author: adan.xue
 */
#include <linux/kfifo.h>
#include <linux/ktime.h>
#include <linux/delay.h>

#include "vastai_pci.h"
#include "pcie_2_dma.h"
#include "pcie_2_reg.h"
#include "va_dma_core.h"
#include "va_irq.h"
#include "../../include/common/sg100/sg100_gmcu.h"
#include "../../include/common/sg100/hw_queue.h"


static u8 submit_bar_num = 0;
static struct pcie2_dma_device *g_pcie2_dma[8];
static void *g_buf_ker_va;
static int va_pcie2_dma_channel_raw_setup(struct vastai_pci_info *priv, u64 *reg_base, struct pcie2_dma_ch_cfg *cfg, u8 device_id);

#define pcie2_dma_dbg(fmt, args...) do {	\
	VASTAI_PCI_DBG(NULL,0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_err(fmt, args...) do {	\
	VASTAI_PCI_ERR(NULL,0xff, fmt, ##args);	\
} while(0);

#define pcie2_dma_info(fmt, args...) do {	\
	VASTAI_PCI_INFO(NULL,0xff, fmt, ##args);	\
} while(0);

/**
 * ctrl of the DMA linked list info element
 * bit0:     CYCLE_BIT
 * bit17~21: ELEMENT_PREFETCH
 * bit28~31: magic flag
 * total_len: total bytes
 */
struct pcie2_dma_ll_info {
	u32 ctrl;
	u32 ll_size;
	u32 llp_lo;
	u32 llp_hi;
	u32 total_len;
	u32 reserve_1;
};

/**
 * ctrl of the DMA linked list data element
 * bit0: CYCLE_BIT
 * bit2: LLP
 * bit3: LWIE
 * bit4: RWIE
 */
struct pcie2_dma_ll_data {
	u32 ctrl;
	u32 size;
	u32 sar_lo;
	u32 sar_hi;
	u32 dar_lo;
	u32 dar_hi;
};

/**
 * ctrl of the DMA linked list link element
 * bit0:     CYCLE_BIT
 * bit1:     TCB
 * bit2:     LLP
 * bit17~21: ELEMENT_PREFETCH
 */
struct pcie2_dma_ll_link {
	u32 ctrl;
	u32 reserve_0;
	u32 llp_lo;
	u32 llp_hi;
	u32 reserve_1;
	u32 reserve_2;
};

union pcie2_dma_ll_element {
	struct pcie2_dma_ll_info info;
	struct pcie2_dma_ll_data data;
	struct pcie2_dma_ll_link link;
};

#define HOST_DMA_FIFO_DEPTH (1024 * 2)
struct pcie2_dma_channel {
	char *name;
	u8 dir;
	u16 pf_depth;
	struct mutex lock;
	struct hw_msgq desc_msgq;
	union pcie2_dma_ll_element *last_msg;
	union pcie2_dma_ll_element *first_msg;
	DECLARE_KFIFO(desc_fifo, struct va_dma_descriptor *,
		      HOST_DMA_FIFO_DEPTH);
	struct pcie2_dma_ch_cfg *cfg;
	u64 reg_off;
};

struct pcie2_dma_device {
	char *name;
	u8 id;
	struct pcie2_dma_channel rd_ch;
	struct pcie2_dma_channel wr_ch;
};

static inline void ll_data_fill(struct pcie2_dma_ll_data *data,
				struct va_dma_desc_elem *elem,
				enum dma_transfer_direction direction)
{
	data->ctrl = 0;
	data->size = elem->size;
	if (direction == DMA_DEV_TO_MEM) {
		data->sar_lo = lower_32_bits(elem->dev_addr);
		data->sar_hi = upper_32_bits(elem->dev_addr);
		data->dar_lo = lower_32_bits(elem->cpu_addr);
		data->dar_hi = upper_32_bits(elem->cpu_addr);
	} else {
		data->sar_lo = lower_32_bits(elem->cpu_addr);
		data->sar_hi = upper_32_bits(elem->cpu_addr);
		data->dar_lo = lower_32_bits(elem->dev_addr);
		data->dar_hi = upper_32_bits(elem->dev_addr);
	}
}

static inline void ll_link_fill_prefetch(struct pcie2_dma_ll_link *link,
					 int elem_prefetch)
{
	//FIXME: 5bit or 7bit
	link->ctrl |= ((elem_prefetch & 0x7f) << 17);
}

/**
 * init CCS = 0, then
 *    CYCLE_BIT = 0: continue to transfer
 *    CYCLE_BIT = 1: stop transfer
 */
static inline void ll_link_fill(struct pcie2_dma_ll_link *link,
				u64 next_llp,
				int is_stop)
{
	if (is_stop) {
		link->ctrl = 0x5;
	} else {
		link->ctrl = 0x4;
		link->llp_lo = lower_32_bits(next_llp);
		link->llp_hi = upper_32_bits(next_llp);
	}
}

static inline int wait_dma_desc_msgq_enough(struct hw_msgq *msgq,
				int elem_nums, u32 sleep_us, u32 timeout_us)
{
	ktime_t timeout;

	timeout = ktime_add_us(ktime_get(), timeout_us);
	might_sleep_if(sleep_us);
	do {
		/* poll channel status*/
		if (msgq_unused(msgq) >= elem_nums)
		    break;

		if (timeout_us && ktime_compare(ktime_get(), timeout) > 0)
			return -EIO;

		if (sleep_us) {
			pcie2_dma_info("wait_dma_msgq: sleep(%dus), unused=%d,"
					" need=%d\n", sleep_us,
					msgq_unused(msgq), elem_nums);
			usleep_range((sleep_us >> 2) + 1, sleep_us);
		}
	} while (1);

	return 0;
}


static int pcie2_dma_desc_submit(void *priv,
			  struct va_dma_descriptor *desc)
{
	int ret = 0;
	struct pcie2_dma_channel *ch;
	struct pcie2_dma_device *pcie2_dma;
	union pcie2_dma_ll_element *ll_buf;
	union pcie2_dma_ll_element *cur_msg;
	struct va_dma_desc_elem *cur_elem;
	int total_nums;
	int elem_index, ll_index, data_cnt, cur_link;

	if ((desc->direction != DMA_DEV_TO_MEM) &&
	    (desc->direction != DMA_MEM_TO_DEV)) {
		pcie2_dma_err("desc direction is invalid, %d\n",
			      desc->direction);
		return -EINVAL;
	}

	pcie2_dma = (struct pcie2_dma_device *)priv;

	ch = (desc->direction == DMA_DEV_TO_MEM)
			? &pcie2_dma->wr_ch : &pcie2_dma->rd_ch;

	if (kfifo_is_full(&ch->desc_fifo)) {
		pcie2_dma_err("%s: desc_fifo is full!\n", ch->name);
		return -EPERM;
	}

	if ((desc->elem_num > 1024 * 4) || (!desc->elem_num)) {
		pcie2_dma_err("%s: desc elem num is unsupport, %d\n",
				ch->name, desc->elem_num);
		BUG();
		return -EPERM;
	}

	mutex_lock(&ch->lock);
	/**
	 * the content of the total_nums
	 * 0:               ll_info
	 * (1 ~ pf_depth):  ll_data
	 * pf_depth + 1:    ll_link
	 * ......           ll_data, ll_link ......
	 * the extra one:   reserved as ll_link elem if the desc list include
	 * the last and first of ring buffer
	 */
	total_nums = desc->elem_num + 1 + 1 +
		((desc->elem_num + ch->pf_depth - 1) / ch->pf_depth);

	ret = wait_dma_desc_msgq_enough(&ch->desc_msgq, total_nums,
					1000, 200 * 1000);
	if (ret) {
		pcie2_dma_err("%s: wait desc msgq timeout, %d\n",
				ch->name, total_nums);
		ret = -EIO;
		goto err_unlock;
	}

	cur_msg = ch->first_msg + msgq_wr(&ch->desc_msgq);

	ll_buf = kzalloc(sizeof(union pcie2_dma_ll_element) * total_nums,
			  GFP_KERNEL);
	if (!ll_buf) {
		pcie2_dma_err("%s: ll_buf kmalloc failed, %d\n",
				ch->name, total_nums);
		ret = -ENOMEM;
		goto err_unlock;
	}

	pcie2_dma_dbg("--------%s: fill link list buf--------\n", ch->name);

	/* init */
	elem_index = 0;
	ll_index = 0;
	data_cnt = 0;
	cur_elem = container_of(desc->elem_head.next,
				struct va_dma_desc_elem, node);

	pcie2_dma_dbg("ll_info: addr=%llx\n", (u64)cur_msg);
	if (cur_msg >= ch->last_msg) {
		cur_msg = ch->first_msg;
	} else {
		cur_msg ++;
	}
	/* this is ll_info */
	ll_link_fill(&ll_buf[ll_index].link, (u64)cur_msg, 0);
	cur_link = ll_index;
	ll_index++;
	while (ll_index < total_nums) {
		if (elem_index >= desc->elem_num) {
			ll_link_fill(&ll_buf[ll_index].link, 0, 1);
			pcie2_dma_dbg("ll_link(last): addr=%llx\n",
				      (u64)cur_msg);
			ll_link_fill_prefetch(&ll_buf[cur_link].link, data_cnt);
			ll_index ++;
			break;
		}
		if (cur_msg >= ch->last_msg) {
			/* filter two continuously ll_link elem */
			if (ll_buf[ll_index - 1].link.ctrl & 0x4) {
				ll_link_fill(&ll_buf[cur_link].link,
				     (u64)(ch->first_msg), 0);
				/* skip the elem, just mark it is dummy link */
				ll_buf[ll_index].link.ctrl = 0x4;
			} else {
				ll_link_fill(&ll_buf[ll_index].link,
				     (u64)(ch->first_msg), 0);
				pcie2_dma_dbg("ll_link(end): addr=%llx\n",
						(u64)cur_msg);
				ll_link_fill_prefetch(&ll_buf[cur_link].link,
						data_cnt);
				cur_link = ll_index;
			}
			ll_index ++;
			cur_msg = ch->first_msg;
			data_cnt = 0;
			continue;
		}
		if (data_cnt == ch->pf_depth) {
			ll_link_fill(&ll_buf[ll_index].link,
				     (u64)(cur_msg + 1), 0);
			pcie2_dma_dbg("ll_link: addr=%llx\n", (u64)cur_msg);
			ll_link_fill_prefetch(&ll_buf[cur_link].link,
					      data_cnt);
			cur_link = ll_index;
			data_cnt = 0;
		} else {
			ll_data_fill(&ll_buf[ll_index].data,
				     cur_elem,
				     desc->direction);
			pcie2_dma_dbg("ll_data: addr=%llx\n", (u64)cur_msg);
			cur_elem = container_of(cur_elem->node.next,
					struct va_dma_desc_elem, node);
			elem_index ++;
			data_cnt ++;
		}
		ll_index ++;
		cur_msg ++;
	}

	if ((elem_index != desc->elem_num)
	 || (&cur_elem->node != &desc->elem_head)) {
		pcie2_dma_err("%s: dma link list abnormal\n", ch->name);
		ret = -EPIPE;
		goto err_free;
	}
	ll_buf[0].info.ll_size = ll_index - 1; //subtract ll_info elem
	ll_buf[0].info.ctrl |= 0xa0000000; //add magic num
	ll_buf[0].info.total_len = desc->total_len;

	/* desc_fifo must run before dma_msgq */
	ret = kfifo_in(&ch->desc_fifo, &desc, 1);
	if (ret != 1) {
		pcie2_dma_err("%s: dma desc_fifo in fail\n", ch->name);
		ret = -EIO;
		goto err_free;
	}

	ret = msgq_in_entriely(&ch->desc_msgq, ll_buf, ll_index);
	if (ret != (ll_index)) {
		pcie2_dma_err("%s: dma desc_msgq in fail, %d\n",
			      ch->name, ll_index);
		ret = kfifo_out(&ch->desc_fifo, &desc, 1);
		ret = -EIO;
		goto err_free;
	}
#if PCIE_2_DMA_PERF_MONITOR_EN
	desc->trigger_time = ktime_get();
#endif

	pcie2_dma_dbg("%s: fill link list done: total_nums=%u, elem_nums=%u\n",
			ch->name, ll_index, elem_index);

	ret = 0;

err_free:
	kfree(ll_buf);
err_unlock:
	mutex_unlock(&ch->lock);

	return ret;
}

static void pcie2_dma_irq_callback(void *arg, struct host_irq_msg *msg)
{
	int num, i, ret;
	struct va_dma_descriptor **desc;
	struct pcie2_dma_device *pcie2_dma;
	struct host_irq_pcie2_dma_msg *dma_msg;
	struct pcie2_dma_channel *ch;

	if (!arg || !msg) {
		BUG();
		return;
	}

	pcie2_dma = (struct pcie2_dma_device *)arg;
	dma_msg = &msg->msg.pcie2_dma;

	ch = (dma_msg->dir == PCIE2_DMA_WR_DEV_TO_MEM)
		? &pcie2_dma->wr_ch : &pcie2_dma->rd_ch;

	num = dma_msg->done_nums;
	desc = kmalloc(sizeof(struct va_dma_descriptor *) * num, GFP_ATOMIC);
	if (!desc) {
		pcie2_dma_err("%s: va_dma_descriptor kmalloc fails, %d\n",
			      ch->name, num);
		return;
	}
	ret = kfifo_out(&ch->desc_fifo, desc, num);
	if (num != ret) {
		pcie2_dma_err("%s: dma desc_fifo out fail, %d\n",
			      ch->name, num);
		goto err_free;
	}

	for (i = 0; i < num; i++) {
#if PCIE_2_DMA_PERF_MONITOR_EN
		desc[i]->done_time = ktime_get();
		pcie2_dma_info("one pcie_2_dma transfer: time=%lldms, "
			       "total_len=%d, dir=%s\n",
			ktime_to_ms(desc[i]->done_time - desc[i]->trigger_time),
			desc[i]->total_len,
			desc[i]->direction == DMA_DEV_TO_MEM ? "d2m" : "m2d");
#endif
		if (desc[i]->callback)
			desc[i]->callback(desc[i]->callback_param);
	}

err_free:
	kfree(desc);
}

static int _pcie2_dma_ch_init(struct vastai_pci_info *priv,
			      struct pcie2_dma_channel *ch,
			      struct pcie2_dma_ch_cfg *cfg,
				  u8 device_id)
{
	char name[VA_HW_MSGQ_NAME_LEN_MAX];
	int ret;
	void *reg_ker_va;
	void *buf_ker_va;

	ch->cfg = cfg;
	ch->name = cfg->name;
	ch->dir = cfg->dir;
	ch->pf_depth = cfg->pf_depth;
	ch->first_msg = (union pcie2_dma_ll_element *)cfg->desc_msgq_buf;
	ch->last_msg = (union pcie2_dma_ll_element *)(cfg->desc_msgq_buf
			+ cfg->desc_msgq_buf_size
			- sizeof(union pcie2_dma_ll_element));

	pcie2_dma_info("%s: first_msg=0x%llx, last_msg=0x%llx\n",
			ch->name, (u64)ch->first_msg, (u64)ch->last_msg);

	reg_ker_va = vastai_pci_mmio_kva_get(priv, 0,
					     cfg->desc_msgq_reg, 1);
	if (!reg_ker_va) {
		pcie2_dma_err("%s: desc msgq reg addr(%llx) is invalid\n",
			      cfg->name, cfg->desc_msgq_reg);
		return -ENXIO;
	}
	buf_ker_va = vastai_pci_mmio_kva_get(priv, 0,
					     cfg->desc_msgq_buf, 1);
	if (!buf_ker_va) {
		pcie2_dma_err("%s: desc msgq buf addr(%llx) is invalid\n",
				   cfg->name, cfg->desc_msgq_buf);
		return -ENXIO;
	}

	snprintf(name, VA_HW_MSGQ_NAME_LEN_MAX, "%s_msgq", ch->name);
	ret = hw_msgq_init(&ch->desc_msgq,
			name,
			(uint64_t)reg_ker_va,
			(uint64_t)buf_ker_va,
			cfg->desc_msgq_buf_size,
			sizeof(struct pcie2_dma_ll_data),
			priv);
	if (ret) {
		pcie2_dma_err("%s: hw_msgq_init fail, %d\n", ch->name, ret);
		return -EPERM;
	}

	INIT_KFIFO(ch->desc_fifo);
	mutex_init(&ch->lock);

	return 0;
}

static int _pcie2_dma_raw_ch_init(struct vastai_pci_info *priv,
			      struct pcie2_dma_channel *ch,
			      struct pcie2_dma_ch_cfg *cfg,
				  u8 device_id)
{
	int ret;

	ch->cfg = cfg;
	ch->name = cfg->name;
	ch->dir = cfg->dir;
	ch->pf_depth = cfg->pf_depth;
	ch->first_msg = (union pcie2_dma_ll_element *)cfg->desc_msgq_buf;
	ch->last_msg = (union pcie2_dma_ll_element *)(cfg->desc_msgq_buf
			+ cfg->desc_msgq_buf_size
			- sizeof(union pcie2_dma_ll_element));
    
	pcie2_dma_info("%s(), %s: first_msg=0x%llx, last_msg=0x%llx\n",
			__func__, ch->name, (u64)ch->first_msg, (u64)ch->last_msg);
    
	pcie2_dma_info("%s(), desc_msgq_reg=0x%llx, desc_msgq_buf=0x%llx, sz=%#x\n",
			__func__, cfg->desc_msgq_reg, cfg->desc_msgq_buf, cfg->desc_msgq_buf_size);

	g_buf_ker_va = vastai_pci_mmio_kva_get(priv, 0, cfg->desc_msgq_buf, 1);
	if (!g_buf_ker_va) {
		pcie2_dma_err("%s: desc msgq buf addr(%llx) is invalid\n",
				   cfg->name, cfg->desc_msgq_buf);
		return -ENXIO;
	}

	ret = va_pcie2_dma_channel_raw_setup(priv, &ch->reg_off, cfg, device_id);
	if (ret)
	{
		pcie2_dma_err("%s: channel raw setup fail, %d\n", ch->name, ret);
		return -ENXIO;
	}

	mutex_init(&ch->lock);
    
	return 0;
}

static int pcie2_dma_deinit(void *priv)
{
	struct pcie2_dma_device *pcie2_dma = priv;

	//TODO
	//va_host_irq_unregister(enum host_irq_num num);
	kfree(pcie2_dma);

	//TODO
	//mutex deinit

	return 0;
}

struct va_dma_ops pcie2_dma_ops = {
	.submit = pcie2_dma_desc_submit,
	.deinit = pcie2_dma_deinit,
	.stop = NULL,
};

int va_pcie2_dma_init(struct vastai_pci_info *priv, struct pcie2_dma_cfg *cfg)
{
	int ret;
	struct pcie2_dma_device *pcie2_dma;
	va_dma_t *dma_dev;
	
    VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s() \n", __func__);
    
	if (!priv || !cfg) {
		return -EINVAL;
	}
    
	pcie2_dma = kzalloc(sizeof(struct pcie2_dma_device), GFP_KERNEL);
	if (!pcie2_dma) {
		pcie2_dma_err("pcie2_dma kmalloc fail\n");
		return -ENOMEM;
	}

	pcie2_dma->name = cfg->name;
	pcie2_dma->id = cfg->device_id;

	if (_pcie2_dma_ch_init(priv, &pcie2_dma->rd_ch, &cfg->rd_cfg, cfg->device_id)) {
		pcie2_dma_err("%s: rd channel init fail\n", pcie2_dma->name);
		return -EIO;
	}
    
	if (_pcie2_dma_ch_init(priv, &pcie2_dma->wr_ch, &cfg->wr_cfg, cfg->device_id)) {
		pcie2_dma_err("%s: wr channel init fail\n", pcie2_dma->name);
		return -EIO;
	}
    
	dma_dev = kzalloc(sizeof(va_dma_t), GFP_KERNEL);
	if (!dma_dev) {
		pcie2_dma_err("dma_dev kmalloc fail\n");
		return -ENOMEM;
	}
	snprintf(dma_dev->name, VA_DMA_NAME_LEN_MAX, "%s", pcie2_dma->name);
	dma_dev->attr = VA_DMA_ATTR_DIR_MEM_TO_DEV |
			VA_DMA_ATTR_DIR_DEV_TO_MEM |
			VA_DMA_ATTR_SUPPORT_SHARED;
	dma_dev->ops = &pcie2_dma_ops;
	dma_dev->priv = pcie2_dma;
	ret = va_dma_add(priv, dma_dev);
	if (ret) {
		pcie2_dma_err("%s: va_dma_add fail, %d\n", dma_dev->name, ret);
		return -EPERM;
	}

	ret = va_host_irq_register(priv, cfg->irq_num,
				   pcie2_dma_irq_callback, pcie2_dma);
	if (ret) {
		pcie2_dma_err("%s: va_host_irq_register fail, irq=%d, ret=%d\n",
			      pcie2_dma->name, cfg->irq_num, ret);
		return -EIO;
	}

	pcie2_dma_dbg("pcie2 dma init done!\n");

	return 0;
}

static int va_pcie2_dma_channel_raw_setup(struct vastai_pci_info *priv, u64 *reg_base, struct pcie2_dma_ch_cfg *cfg, u8 device_id)
{
	u32 val_set = 0;
	u64 reg_off = 0;
	u8 current_id = 0;
	u64 pkg_off = 0;
	u8 bar_num = 0;

	pcie2_dma_err("channel init priv->dev->devfn = %d\n", priv->dev->devfn);
	if (device_id < 4)
	{
		bar_num = 0;
		current_id = device_id;
		pkg_off = 0;
	}
	else if (device_id >= 4 && device_id <= 7)
	{
		bar_num = 2;
		current_id = device_id - 4;
		pkg_off = 0xcd000;
	}
	else
	{
		pcie2_dma_err("device_id (%d)> 7\n", device_id);
		return -EINVAL;
	}
	
	if (cfg->dir == PCIE2_DMA_WR_DEV_TO_MEM)
	{
		reg_off = 0x2000 * (current_id + 1) + pkg_off;
	} else if (cfg->dir == PCIE2_DMA_RD_MEM_TO_DEV)
	{
		reg_off = 0x2000 * (current_id + 1) + 0x1000 + pkg_off;
	} else 
	{
		return -EINVAL;
	}

	/*setup pcie dma controller*/
	/* enable linked list mode: bit0 */
	val_set = 0x01;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PCIE2_DMA_REG_CONTROL1, &val_set, 4);

	/* enable channel */
	val_set = 0x01;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PICE2_DMA_REG_EN, &val_set, 4);
	
	/* CB=CCS=0 */
	val_set = 0x01;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PCIE2_DMA_REG_CYCLE, &val_set, 4);

	/* ELEMENT_PREFETCH bit[6:0] */
	val_set = 0x00;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PICE2_DMA_REG_ELEM_PF, &val_set, 4);

	/* PF_DEPTH bit[25:16] */
	val_set = 0xf0000;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PCIE2_DMA_REG_QOS, &val_set, 4);

	/* enable local interrupt for abort and stop */
	val_set = 0x52;
	vastai_pci_mmio_write(priv, bar_num, reg_off + PCIE2_DMA_REG_INT_SETUP, &val_set,4);

	*reg_base = reg_off;

	return 0;
}

int pcie2_dma_raw_init(struct vastai_pci_info *priv, struct pcie2_dma_cfg *cfg)
{
    VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s() \n", __func__);
    
	if (!priv || !cfg) {
		return -EINVAL;
	}

	g_pcie2_dma[priv->dev->devfn] = kzalloc(sizeof(struct pcie2_dma_device), GFP_KERNEL);
	if (!g_pcie2_dma[priv->dev->devfn]) {
		pcie2_dma_err("pcie2_dma kmalloc fail\n");
		return -ENOMEM;
	}

	g_pcie2_dma[priv->dev->devfn]->name = cfg->name;
	g_pcie2_dma[priv->dev->devfn]->id = cfg->device_id;

	if (_pcie2_dma_raw_ch_init(priv, &g_pcie2_dma[priv->dev->devfn]->rd_ch, &cfg->rd_cfg, cfg->device_id)) {
		pcie2_dma_err("%s: rd channel init fail\n", g_pcie2_dma[priv->dev->devfn]->name);
		return -EIO;
	}
    
	if (_pcie2_dma_raw_ch_init(priv, &g_pcie2_dma[priv->dev->devfn]->wr_ch, &cfg->wr_cfg, cfg->device_id)) {
		pcie2_dma_err("%s: wr channel init fail\n", g_pcie2_dma[priv->dev->devfn]->name);
		return -EIO;
	}

	pcie2_dma_dbg("pcie2 raw dma init done!\n");

	return 0;
}

static void pcie_dma_issue(struct vastai_pci_info *priv,
						   struct pcie2_dma_channel *ch,
		                   uint32_t start_point_low,
		                   uint32_t start_point_high,
		                   uint8_t elem_prefetch)
{
	u32 val_set = 0;

	pcie2_dma_dbg("start_point_low = 0x%x, start_point_high = 0x%x ch->reg_off = 0x%llx\n", start_point_low, start_point_high, ch->reg_off);

	val_set = start_point_low;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PCIE2_DMA_REG_LLP_LOW, &val_set, 4);

	val_set = start_point_high;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PCIE2_DMA_REG_LLP_HIGH, &val_set, 4);

	/* ELEMENT_PREFETCH bit[6:0] */
	val_set = elem_prefetch & 0x7f;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PICE2_DMA_REG_ELEM_PF, &val_set, 4);

	/* start dma transfer */
	val_set = 0x01;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PICE2_DMA_REG_DOORBELL, &val_set, 4);
}

int pcie2_dma_desc_submit_raw(struct vastai_pci_info *priv, struct va_dma_descriptor *desc)
{
	int ret = 0;
	u32 int_state, val_set, cnt = 30;
	struct pcie2_dma_channel *ch;
	union pcie2_dma_ll_element *ll_buf;
	union pcie2_dma_ll_element *cur_msg;
	struct va_dma_desc_elem *cur_elem;
	int total_nums;
	int elem_index, ll_index, data_cnt, cur_link;
	
	pcie2_dma_err("desc submit priv->dev->devfn = %d\n", priv->dev->devfn);
	if (priv->dev->devfn < 4)
	{
		submit_bar_num = 0;
	}
	else 
	{
		submit_bar_num = 2;
	}

	if ((desc->direction != DMA_DEV_TO_MEM) &&
	    (desc->direction != DMA_MEM_TO_DEV)) {
		pcie2_dma_err("desc direction is invalid, %d\n",
			      desc->direction);
		return -EINVAL;
	}

	ch = (desc->direction == DMA_DEV_TO_MEM)
			? &g_pcie2_dma[priv->dev->devfn]->wr_ch : &g_pcie2_dma[priv->dev->devfn]->rd_ch;

	if ((desc->elem_num > 1024 * 4) || (!desc->elem_num)) {
		pcie2_dma_err("%s: desc elem num is unsupport, %d\n",
				ch->name, desc->elem_num);
		BUG();
		return -EPERM;
	}

	mutex_lock(&ch->lock);
	/**
	 * the content of the total_nums
	 * 0:               ll_info
	 * (1 ~ pf_depth):  ll_data
	 * pf_depth + 1:    ll_link
	 * ......           ll_data, ll_link ......
	 * the extra one:   reserved as ll_link elem if the desc list include
	 * the last and first of ring buffer
	 */
	total_nums = desc->elem_num + 1 + 1 +
		((desc->elem_num + ch->pf_depth - 1) / ch->pf_depth);

	cur_msg = ch->first_msg;

	ll_buf = kzalloc(sizeof(union pcie2_dma_ll_element) * total_nums,
			  GFP_KERNEL);
	if (!ll_buf) {
		pcie2_dma_err("%s: ll_buf kmalloc failed, %d\n",
				ch->name, total_nums);
		ret = -ENOMEM;
		goto err_unlock;
	}

	pcie2_dma_dbg("--------%s: fill link list buf--------\n", ch->name);

	/* init */
	elem_index = 0;
	ll_index = 0;
	data_cnt = 0;
	cur_elem = container_of(desc->elem_head.next,
				struct va_dma_desc_elem, node);

	pcie2_dma_dbg("ll_info: addr=%llx\n", (u64)cur_msg);
	if (cur_msg >= ch->last_msg) {
		cur_msg = ch->first_msg;
	} else {
		cur_msg ++;
	}
	/* this is ll_info */
	ll_link_fill(&ll_buf[ll_index].link, (u64)cur_msg, 0);
	cur_link = ll_index;
	ll_index++;
	while (ll_index < total_nums) {
		if (elem_index >= desc->elem_num) {
			ll_link_fill(&ll_buf[ll_index].link, 0, 1);
			pcie2_dma_dbg("ll_link(last): addr=%llx\n",
				      (u64)cur_msg);
			ll_link_fill_prefetch(&ll_buf[cur_link].link, data_cnt);
			ll_index ++;
			break;
		}
		if (cur_msg >= ch->last_msg) {
			/* filter two continuously ll_link elem */
			if (ll_buf[ll_index - 1].link.ctrl & 0x4) {
				ll_link_fill(&ll_buf[cur_link].link,
				     (u64)(ch->first_msg), 0);
				/* skip the elem, just mark it is dummy link */
				ll_buf[ll_index].link.ctrl = 0x4;
			} else {
				ll_link_fill(&ll_buf[ll_index].link,
				     (u64)(ch->first_msg), 0);
				pcie2_dma_dbg("ll_link(end): addr=%llx\n",
						(u64)cur_msg);
				ll_link_fill_prefetch(&ll_buf[cur_link].link,
						data_cnt);
				cur_link = ll_index;
			}
			ll_index ++;
			cur_msg = ch->first_msg;
			data_cnt = 0;
			continue;
		}
		if (data_cnt == ch->pf_depth) {
			ll_link_fill(&ll_buf[ll_index].link,
				     (u64)(cur_msg + 1), 0);
			pcie2_dma_dbg("ll_link: addr=%llx\n", (u64)cur_msg);
			ll_link_fill_prefetch(&ll_buf[cur_link].link,
					      data_cnt);
			cur_link = ll_index;
			data_cnt = 0;
		} else {
			ll_data_fill(&ll_buf[ll_index].data,
				     cur_elem,
				     desc->direction);
			pcie2_dma_dbg("ll_data: addr=%llx\n", (u64)cur_msg);
			cur_elem = container_of(cur_elem->node.next,
					struct va_dma_desc_elem, node);
			elem_index ++;
			data_cnt ++;
		}
		ll_index ++;
		cur_msg ++;
	}

	if ((elem_index != desc->elem_num)
	 || (&cur_elem->node != &desc->elem_head)) {
		pcie2_dma_err("%s: dma link list abnormal\n", ch->name);
		ret = -EPIPE;
		goto err_free;
	}
	ll_buf[0].info.ll_size = ll_index - 1; //subtract ll_info elem
	ll_buf[0].info.ctrl |= 0xa0000000; //add magic num
	ll_buf[0].info.total_len = desc->total_len;

	pcie2_dma_dbg("%s: fill link list : total_len=%u, ctrl =%u size = %u\n", ch->name, ll_buf[0].info.total_len, ll_buf[0].info.ctrl, ll_buf[0].info.ll_size);

	vastai_pci_mem_write(priv, 0, (u64)ch->first_msg, ll_buf, sizeof(union pcie2_dma_ll_element) * total_nums);

	//_msgq_copy_dev_to_mem(g_buf_ker_va, ll_buf, sizeof(union pcie2_dma_ll_element) * total_nums);

	/*pcie dma issue*/
	pcie_dma_issue(priv, ch, ll_buf[0].info.llp_lo, ll_buf[0].info.llp_hi, ll_buf[0].info.ctrl >> 17);

	/*polling done*/
	do
	{
		msleep(1);
		vastai_pci_mmio_read(priv, 2, ch->reg_off + PCIE2_DMA_REG_INT_STATUS, &int_state, 4);
		cnt--;
	} while (int_state != 0x01 && cnt);
	
	/* clear */
	cnt = 30;
	val_set = 0x01;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PCIE2_DMA_REG_INT_CLEAR, &val_set, 4);
	int_state = 0x01;
	while (int_state && cnt) {
		vastai_pci_mmio_read(priv, submit_bar_num, ch->reg_off + PCIE2_DMA_REG_INT_STATUS, &int_state, 4);
		cnt--;
	};

	val_set = 0x0;
	vastai_pci_mmio_write(priv, submit_bar_num, ch->reg_off + PCIE2_DMA_REG_INT_CLEAR, &val_set, 4);
	ret = 0;
	pcie2_dma_dbg("%s: fill link list done: total_nums=%u, elem_nums=%u\n",
			ch->name, ll_index, elem_index);

err_free:
	kfree(ll_buf);
err_unlock:
	mutex_unlock(&ch->lock);

	return ret;
}

