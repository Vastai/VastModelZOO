#include "vastai_die.h"
#include "vastai_pci_test.h"
#include "vastai_fifo.h"
#include "vastai_udma_engine.h"
#include "vastai_pci_dbg.h"

#include "vastai_pci_boot.h" //vastai_die_get_pcie_atter need this header
#include "vastai_pci_vf.h"


/*
 * smcu boot stage:
 * bit31(gpio3/pkg sel), bit30(gpio2/last die), bit29(dieid/slave die)
 * die_num die_id val      bit31 bit30 bit29
 * 1-die   die0   3'h2     0     1     0
 * 2-die   die0   3'h0     0     0     0
 * 2-die   die1   3'h3     0     1     1
 * 4-die   die0   3'h4     1     0     0
 * 4-die   die1   3'h1     0     0     1
 * 4-die   die2   3'h5     1     0     1
 * 4-die   die3   3'h7     1     1     1
 */
struct vastai_die_cfg die_cfg[] = {
	{ 2, VASTAI_SINGLE_DIE, VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0}}, //TODO: vf
	{ 0, VASTAI_TWO_DIE,    VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0}},
	{ 3, VASTAI_TWO_DIE,    VASTAI_DIE1, VASTAI_PKG0, {VASTAI_FN0}},
	{ 4, VASTAI_FOUR_DIE,   VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0}},
	{ 1, VASTAI_FOUR_DIE,   VASTAI_DIE1, VASTAI_PKG0, {VASTAI_FN0}},
	{ 5, VASTAI_FOUR_DIE,   VASTAI_DIE2, VASTAI_PKG1, {VASTAI_FN0}},
	{ 7, VASTAI_FOUR_DIE,   VASTAI_DIE3, VASTAI_PKG1, {VASTAI_FN0}}
};

struct vastai_die_cfg die_cfg_sg[] = {
	{0, VASTAI_SINGLE_DIE, VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0, VASTAI_FN1, VASTAI_FN2, VASTAI_FN3}},   // Single pkg(die) per board No DP enabled
	{1, VASTAI_TWO_DIE,    VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0, VASTAI_FN1, VASTAI_FN2, VASTAI_FN3}},   // Master-slave pkg per board’s master pkg.
	{2, VASTAI_TWO_DIE,    VASTAI_DIE1, VASTAI_PKG1, {VASTAI_FN4, VASTAI_FN5, VASTAI_FN6, VASTAI_FN7}},   // Master-slave pkg per board’s slave pkg.
	{7, VASTAI_SINGLE_DIE, VASTAI_DIE0, VASTAI_PKG0, {VASTAI_FN0, VASTAI_FN1, VASTAI_FN2, VASTAI_FN3}}};  // PKG_MODE 1, PCB board with DP enabled. And only single pkg for this mode.

#define VASTAI_DIE_ERR(die, fmt, args...) \
	do { \
		VASTAI_PCI_ERR(die->pci_info, \
			((union die_index_data)die->die_index).die_id, \
			fmt, ##args); \
	} while (0)

#define VASTAI_DIE_INFO(die, fmt, args...) \
	do { \
		VASTAI_PCI_INFO(die->pci_info, \
			((union die_index_data)die->die_index).die_id, \
			fmt, ##args); \
	} while (0)

#define VASTAI_DIE_DBG(die, fmt, args...) \
	do { \
		VASTAI_PCI_DBG(die->pci_info, \
			((union die_index_data)die->die_index).die_id, \
			fmt, ##args); \
	} while (0)

#define vastai_die_mem_read(die, addr, buf, len) \
	vastai_pci_mem_read(die->pci_info, die->die_index, addr, buf, len)

#define vastai_die_mem_write(die, addr, buf, len) \
	vastai_pci_mem_write(die->pci_info, die->die_index, addr, buf, len)

#ifdef CONFIG_VASTAI_PCI_SET_BAR
static const int vastai_pci_set_bar = 1;
#else
static const int vastai_pci_set_bar = 0;
#endif

int vastai_die_get_pcie_attr(struct vastai_sv100_die *die)
{
	int ret;
	union link_control_status_reg reg;
	union link_control_cap_reg    reg2;
	u64 reg_addr = VASTAI_PCI_LINK_CONTROL_STATUS_REG;
	u64 reg_addr2 = VASTAI_PCI_LINK_CONTROL_CAP_REG;
	int die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);
	bool is_slave_die;
	struct vastai_die_info *die_info =
		vastai_get_die_info(die->pci_info, die_id);

	if (die_id > 0 && !vastai_pci_set_bar) {
		return 0;
	}
	ret = vastai_pci_mem_read_direct(die->pci_info, die->die_index,
					reg_addr, &(reg.val), 4);
	if (ret < 0)
		VASTAI_DIE_ERR(die, "%s [read] 0x%llx, len=4, error:%d\n",
				__func__, reg_addr, ret);
	ret = vastai_is_slave_die(die->pci_info, die_id, &is_slave_die);
	if (ret)
		return ret;
	if (is_slave_die) {
		if (die_info->die_id_in_card == die_id) {//va1
			die->pcie_nls[1] = reg.bit.negotiated_link_speed;
			die->pcie_nlw[1] = reg.bit.negotiated_link_width;
			die->pci_info->dies[die_id -1].pcie_nls[1] = die->pcie_nls[1];
			die->pci_info->dies[die_id -1].pcie_nlw[1] = die->pcie_nlw[1];
			return 0;
		}
	}
	if (die_id != 0) {//va10
		die->pcie_nls[2] = reg.bit.negotiated_link_speed;
		die->pcie_nlw[2] = reg.bit.negotiated_link_width;
		die->pci_info->dies[die_id -1].pcie_nls[2] = die->pcie_nls[2];
		die->pci_info->dies[die_id -1].pcie_nlw[2] = die->pcie_nlw[2];
		return 0;
	}
	die->pcie_nls[0] = reg.bit.negotiated_link_speed;
	die->pcie_nlw[0] = reg.bit.negotiated_link_width;

	if(die_id == 0) {
		ret = vastai_pci_mem_read_direct(die->pci_info, die->die_index,
						reg_addr2, &(reg2.val), 4);
		if (ret < 0)
			VASTAI_DIE_ERR(die, "%s [read] 0x%llx, len=4, error:%d\n",
					__func__, reg_addr2, ret);
		die->pcie_mls = reg2.bit.max_link_speed;
		die->pcie_mlw = reg2.bit.max_link_width;
	}

//	if (die_id > 0 && (die->pci_info->minish_bar_size == 1))
//		vastai_pci_reset_bar_at(die->pci_info, die->die_index);

	return ret;
}

extern void vastai_dma_done(void *data);
extern void vastai_pci_proc_smcu_msg1(void *i_die);
extern void vastai_pci_proc_smcu_msg1_spe(void *i_die);
extern void vastai_pop_core(void *p_die_irq);
extern void vastai_pop_all_odsp(void *p_irq_idx);

DEFINE_MUTEX(core_info_mutex);
struct core_info_entry *cores_info = NULL;
extern void exception_proc_work(struct work_struct *work);
extern void exception_proc_work_new_per_core(struct work_struct *work);

void event_notify_per_core(struct vastai_core *core, u32 event)
{
	core->event_type = event;

	schedule_work(&core->exception_work_new);

	return;
}

int vastai_get_core_hw_config(struct vastai_sv100_die *die)
{
	int ret = 0;
	u32 size = CORE_TOTAL_NUM*sizeof(struct core_info_entry);
	u64 hw_config_addr = (die->pci_info->is_virtfn) ? SV100_HW_VF_CONFIG : SV100_HW_CONFIG;

	mutex_lock(&core_info_mutex);
	if(cores_info == NULL) {
		cores_info = kzalloc(size, GFP_KERNEL);
		if(!cores_info) {
			VASTAI_PCI_ERR(die->pci_info, vastai_pci_get_die_id(die->pci_info, die->die_index),
					"%s: no mem\n", __func__);
			mutex_unlock(&core_info_mutex);
			return -ENOMEM;
		}
		ret = vastai_pci_mem_read_direct(die->pci_info, die->die_index,
						 hw_config_addr+offsetof(struct sv100_hw_cfg, core_cfg),
						 cores_info, size);
	}
	mutex_unlock(&core_info_mutex);
	return ret;
}
extern int vastai_pop_smcu_msg1_handle(void *pci_info, u32 die_index, int irq, void *ctxt, void *out);

static void vastai_queue_work(void *core_work)
{
	queue_work(((struct vastai_core_work *)core_work)->wq,
			&((struct vastai_core_work *)core_work)->work);
}

static void vastai_core_work_proc(struct work_struct *work)
{
	struct vastai_core_work *core_work =
		container_of(work, struct vastai_core_work, work);

	core_work->handler_function(core_work->irq_idx);
}
static struct workqueue_struct *vastai_get_work_queue(struct vastai_sv100_die *die, int core_index)
{
	if ((core_index >= CORE_POINT_VDMCU0) && (core_index <= CORE_POINT_VDMCU2))
		return die->dec_msix_wq;
	else if ((core_index >= CORE_POINT_VEMCU0) && (core_index <= CORE_POINT_VEMCU3))
		return die->enc_msix_wq;
	else if ((core_index >= CORE_POINT_VDSP0) && (core_index <= CORE_POINT_VDSP3))
		return die->vdsp_msix_wq;
	else if (core_index == CORE_POINT_CMCU)
		return die->ai_msix_wq;
	else
		return NULL;
}
static int vastai_core_work_queue_init(struct vastai_sv100_die *die)
{
	int ret = 0;

	die->ai_msix_wq = alloc_workqueue("vastai_ai_msix_wq",
				WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (!die->ai_msix_wq) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc vastai_ai_msix_wq failed!\n", __func__);
		ret = -EIO;
		goto ERR_AI;
	}
	die->enc_msix_wq = alloc_workqueue("vastai_enc_msix_wq",
				WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (!die->enc_msix_wq) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc vastai_enc_msix_wq failed!\n", __func__);
		ret = -EIO;
		goto ERR_ENC;
	}
	die->dec_msix_wq = alloc_workqueue("vastai_dec_msix_wq",
				WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (!die->dec_msix_wq) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc vastai_dec_msix_wq failed!\n", __func__);
		ret = -EIO;
		goto ERR_DEC;
	}
	die->vdsp_msix_wq = alloc_workqueue("vastai_vdsp_msix_wq",
				WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (!die->vdsp_msix_wq) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc vastai_vdsp_msix_wq failed!\n", __func__);
		ret = -EIO;
		goto ERR_VDSP;
	}

	return ret;
ERR_VDSP:
	destroy_workqueue(die->dec_msix_wq);
ERR_DEC:
	destroy_workqueue(die->enc_msix_wq);
ERR_ENC:
	destroy_workqueue(die->ai_msix_wq);
ERR_AI:
	return ret;
}
static void vastai_core_work_queue_deinit(struct vastai_sv100_die *die)
{
	if (die->vdsp_msix_wq) {
		flush_workqueue(die->vdsp_msix_wq);
		destroy_workqueue(die->vdsp_msix_wq);
	}
	if (die->dec_msix_wq) {
		flush_workqueue(die->dec_msix_wq);
		destroy_workqueue(die->dec_msix_wq);
	}
	if (die->enc_msix_wq) {
		flush_workqueue(die->enc_msix_wq);
		destroy_workqueue(die->enc_msix_wq);
	}
	if (die->ai_msix_wq) {
		flush_workqueue(die->ai_msix_wq);
		destroy_workqueue(die->ai_msix_wq);
	}
}

static int vastai_core_fifo_cache_init(struct vastai_core *core)
{
	int i;

	for (i = 0; i < 2; i++) {
		if ((core->core_bit >= CORE_POINT_VDSP0) &&
				(core->core_bit <= CORE_POINT_VDSP3)) {
			core->pop_cache[i] = kzalloc(sizeof(struct vastai_fifo), GFP_KERNEL);
			if (!core->pop_cache[i])
				return -ENOMEM;
			core->push_cache[i] = kzalloc(sizeof(struct vastai_fifo), GFP_KERNEL);
			if (!core->push_cache[i])
				return -ENOMEM;
		} else {
			core->pop_cache[i] = NULL;
			core->push_cache[i] = NULL;
		}
	}
	return 0;
}

static void vastai_core_fifo_cache_deinit(struct vastai_core *core)
{
	int i;

	for (i = 0; i < 2; i++) {
		if (core->pop_cache[i]) {
			kfree(core->pop_cache[i]);
			core->pop_cache[i] = NULL;
		}
		if (core->push_cache[i]) {
			kfree(core->push_cache[i]);
			core->push_cache[i] = NULL;
		}
	}
}

int vastai_mcu_init(struct vastai_sv100_die *die)
{
	int ret = 0;
	u8 die_irq_offset = VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM;
	u32 die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);
	int i = 0;
	int j = 0;

	ret = vastai_get_core_hw_config(die);
	if(ret) {
		VASTAI_PCI_ERR(die->pci_info, 0,
				"%s: get core hw config err ret[%d]\n", __func__, ret);
		return ret;
	}

	if (die->pci_info->ai_video_workqueue_enable) {
		ret = vastai_core_work_queue_init(die);
		if(ret) {
			VASTAI_PCI_ERR(die->pci_info, 0,
					"%s: vastai_core_work_queue_init ret[%d]\n", __func__, ret);
			return ret;
		}
	}

	ret = vastai_irq_register(die->pci_info, die->die_index, SMCU_2_HOST_INT0, vastai_pop_smcu_msg1_handle, NULL);

	/* odsp is special, all odsp use irq 21, and irq 21 will pop all odsp fifo */
	i=CORE_POINT_ODSP0;
	for(j=0; j<2; j++) {
		if(cores_info[i].pop_fifo_addr[j] != -1) {
			if(cores_info[i].die_irq[j] != -1) {
				ret = va_register_pcie_interrupt(die->pci_info, cores_info[i].die_irq[j] + die_id * die_irq_offset,
								 vastai_pop_all_odsp, &(die->core[i].irq_idx[j]));
				if(ret)
					return ret;
			}
		}
	}

	for(i=0; i<CORE_TOTAL_NUM; i++) {
		die->core[i].die      = die;
		die->core[i].core_bit = i;
		die->core[i].cores_info_ref = &cores_info[i];
		die->core[i].log_cache_rp = 0xffffffff;
		die->core[i].log_last_rp = 0xffffffff;
		ret = vastai_core_fifo_cache_init(&die->core[i]);
		if (ret)
			goto ERR_CACHE_INIT;
		for(j=0; j<2; j++) {
			if(cores_info[i].pop_fifo_addr[j] != -1) {
				spin_lock_init(&(die->core[i].rd_ring_buf_lock));
				INIT_WORK(&die->core[i].exception_work, exception_proc_work);
				INIT_WORK(&die->core[i].exception_work_new, exception_proc_work_new_per_core);

				die->core[i].irq_idx[j] = j;
				if(cores_info[i].die_irq[j] != -1) {
					struct workqueue_struct *wq;
					if (!die->pci_info->ai_video_workqueue_enable || !(wq = vastai_get_work_queue(die, i))) {
						ret = va_register_pcie_interrupt(die->pci_info, cores_info[i].die_irq[j] + die_id * die_irq_offset,
									 vastai_pop_core, &(die->core[i].irq_idx[j]));
						if (ret)
							goto ERR_CACHE_INIT;
					} else {
						INIT_WORK(&(die->core[i].core_work[j].work), vastai_core_work_proc);
						die->core[i].core_work[j].die = die;
						die->core[i].core_work[j].wq = wq;
						die->core[i].core_work[j].irq_idx = &(die->core[i].irq_idx[j]);
						die->core[i].core_work[j].handler_function = vastai_pop_core;
						ret = va_register_pcie_interrupt(die->pci_info, cores_info[i].die_irq[j] + die_id *die_irq_offset,
									 vastai_queue_work, &(die->core[i].core_work[j]));
						if (ret)
							goto ERR_CACHE_INIT;
					}

				}
			}
		}

		if(die->core[i].cores_info_ref->is_use_ring_buf)
			spin_lock_init(&(die->core[i].wr_ring_buf_lock));
	}

	return 0;

ERR_CACHE_INIT:
	while(i+1) {
		vastai_core_fifo_cache_deinit(&die->core[i--]);
	}

	return ret;
}

void vastai_init_heartbeat(struct vastai_pci_info *pci_info, u32 die_id)
{
	int i = 0;
	int j = 0;

	for(i=0; i<HEARTBEAT_MAX_CNT; i++)
		for(j=0; j<ADDR(pci_info, HEARTBEAT_CNT_REG_NUM); j++)
			pci_info->heartbeat.dies[die_id].last_counts[i][j] = 0;

	pci_info->heartbeat.dies[die_id].tail = 0;
	pci_info->heartbeat.dies[die_id].head = 0;

	return;
}

void vastai_cmdbuf_init(struct vastai_pci_info *pci_info, struct vastai_sv100_die *die)
{
	struct vastai_fifo fifo = { 0 };
	int i;
	u32 cancel_cmd_buf_addr;

	void *mem = kzalloc(VASTAI_CMD_BUF_LEN, GFP_KERNEL);
	for (i = 0; i < VASTAI_CMD_BUF_NR; i++) {
		vastai_pci_mem_write_direct(pci_info, die->die_index,
				     MSG_PCIE_TO_CMDBUF + i*VASTAI_CMD_BUF_LEN,
				     mem,
				     VASTAI_CMD_BUF_LEN);

		vastai_fifo_init_arg(
			&fifo, sizeof(union buf_data),
			VASTAI_CMD_BUF_LEN);
		vastai_pci_mem_write_direct(pci_info, die->die_index,
				     MSG_PCIE_TO_CMDBUF + i*VASTAI_CMD_BUF_LEN,
				     &fifo,
				     sizeof(fifo));
	}

	cancel_cmd_buf_addr = MSG_PCIE_TO_CMDBUF + (VASTAI_CMD_BUF_LEN * VASTAI_CMD_BUF_NR);
	for (i = 0; i < VASTAI_CANCEL_CMD_BUF_NR; i++) {
		vastai_pci_mem_write_direct(pci_info, die->die_index,
				     cancel_cmd_buf_addr + i*VASTAI_CANCEL_CMD_BUF_NR,
				     mem,
				     VASTAI_CANCEL_CMD_BUF_LEN);

		vastai_fifo_init_arg(
			&fifo, sizeof(union buf_data),
			VASTAI_CANCEL_CMD_BUF_LEN);
		vastai_pci_mem_write_direct(pci_info, die->die_index,
				     cancel_cmd_buf_addr + i*VASTAI_CANCEL_CMD_BUF_NR,
				     &fifo,
				     sizeof(fifo));
	}

	kfree(mem);
}

int vastai_die_init(struct vastai_sv100_die *die,
			  struct vastai_pci_info *pci_info, u32 die_id)
{
	struct vastai_fifo fifo = { 0 };
	int ret = 0;

	die->pci_info = pci_info;
	die->die_index = vastai_pci_gen_die_index(pci_info, die_id);
	die->test_dm_sg = NULL;
	die->vatool_dm_sg = NULL;

	if (!die->pci_info || die->die_index == UINT_MAX) {
		return -EIO;
	}

	if(vastai_get_die_boot_mode(die)) {
		return -EIO;
	}

	die->harvest_info.dlc_cores = 0;
	die->get_dlc_info_cnt = 0;
	die->harvest_info.type =
		VASTAI_HARVEST_ALL_DLC_AND_ODSP_DISABLED;

	vastai_die_msgq_init(die);

#ifdef CONFIG_VASTAI_TOOLS_SUITE
	/* vatools smi block config */
	vatools_fw_config_smi(pci_info, die->die_index);
#endif

	if(die->boot_mode != BOOT_PF_NORMAL) vastai_vf_os_fifo_init(die);

	vastai_fifo_init_arg(
		&fifo, sizeof(struct vastai_cedar_img_info),
		1024);
	vastai_pci_mem_write_direct(pci_info, die->die_index,
			     CEDAR_SVC_INFO, &fifo, sizeof(fifo));

	mutex_init(&die->cedar_lock);

	vastai_cmdbuf_init(pci_info, die);
#ifdef CONFIG_TOOLS_V2
	mutex_init(&die->tools_die_mutex);
#endif

	die->dev_freq = 100;
	atomic_set(&die->ctrl_cmd_list.ctrl_seq_id, 0);
	INIT_LIST_HEAD(&die->ctrl_cmd_list.ctrl_cmd_head.list);
	mutex_init(&(die->get_dlc_mutex));
	init_completion(&(die->get_dlc_core_done));
	init_completion(&(die->stop_bw_done));

	ret = va_register_pcie_interrupt(pci_info, SMCU_2_HOST_DMA_DONE + die_id*(pci_info->irq_num / VASTAI_SV100_MAX_DIE_NUM),
									 vastai_dma_done, die);
	if(ret)
			return ret;
	ret = va_register_pcie_interrupt(pci_info, SMCU_2_HOST_INT1 + die_id*(VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM), /*TODO: consider SG100*/
					 vastai_pci_proc_smcu_msg1_spe, die);
	if(ret)
		return ret;
	ret = va_register_pcie_interrupt(pci_info, HOST_GUEST_INT + die_id *(VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM),
					 vastai_proc_peer_msg, die);
	if(ret)
		return ret;

	ret = vastai_mcu_init(die);
	if(ret)
		return ret;
	vastai_pci_set_vdsp_depth(die->pci_info, die_id,
				  VASTAI_PCIE_2_VDSP_MSG_DEPTH, 0);
	vastai_pci_set_vdsp_2st_depth(die->pci_info, die_id,
				  VASTAI_PCIE_2_VDSP_2ST_MSG_DEPTH, 0);
	vastai_pci_set_cmcu_depth(die->pci_info, die_id,
				  VASTAI_PCIE_2_CMCU_MSG_DEPTH);
	vastai_pci_set_odsp_depth(die->pci_info, die_id,
				  VASTAI_PCIE_2_ODSP_MSG_DEPTH);
	vastai_init_heartbeat(pci_info, die_id);

	return vastai_udma_init(die);
}

void vastai_die_deinit(struct vastai_sv100_die *die)
{
	int i;

	for(i = 0; i < CORE_TOTAL_NUM; i++) {
		vastai_core_fifo_cache_deinit(&die->core[i]);
	}
	vastai_core_work_queue_deinit(die);
	vastai_udma_deinit(die);
}

void vastai_global_die_init(struct vastai_addr_info *vastai_global_addr_info)
{
	vastai_global_addr_info[SV100].die_cfg = die_cfg;
	vastai_global_addr_info[SG100].die_cfg = die_cfg_sg;
	vastai_global_addr_info[SV100].die_config_tab_size = sizeof(die_cfg)/sizeof(die_cfg[0]);
	vastai_global_addr_info[SG100].die_config_tab_size = sizeof(die_cfg_sg)/sizeof(die_cfg_sg[0]);
}


