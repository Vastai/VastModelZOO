#include <linux/version.h>
#include <linux/dma-buf.h>
#include <linux/count_zeros.h>
#include <rdma/ib_umem.h>
#if KERNEL_VERSION(5,10,0) <= LINUX_VERSION_CODE && \
	!defined(RHEL_RELEASE_VERSION)
#include <linux/dma-map-ops.h>
#endif
#include "vastai_pci.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 4, 0)
MODULE_IMPORT_NS(DMA_BUF);
#endif

#define LARGEST_PG_SHIFT     31
#define DEFAULT_PAGE_SIZE    0x40000000ULL       /* 1G   */
#define MAX_PAGE_SIZE        0x80000000ULL       /* 2G   */
#define VCCL_RDMA_MAX_HOSTBUF_SIZE 0x1000000ULL        /* 16MB */

struct rdma_hostbuf_elem {
	dma_addr_t dma_bus_addr;
	void *vir;
	int size;
};

struct rdma_hostbuf_list {
	u32 entry_count;
	struct rdma_hostbuf_elem *buf_list[0];
};

struct rdma_dmabuf_priv {
	struct vastai_pci_info * pci_info;
	struct dma_buf *dmabuf;
	struct rdma_hostbuf_list *hostbuf_list;
	u64 soc_addr;
	u32 die_index;
	u32 die_id;
	rdma_mem_type_t mem_type;
};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
static u64 find_best_pgsz(struct vastai_pci_info *pci_info, u32 die_index, u64 virt, u64 size)
{
	u64 mask, pgsz_bitmap, pa[3], va[3];
	int i, ret;
	pgsz_bitmap = GENMASK(LARGEST_PG_SHIFT, PAGE_SHIFT);

	va[0] = virt;
	va[1] = virt + size/2 + 1;
	va[2] = virt + size - 1;
	for(i = 0; i < 3; i ++) {
		ret = vastai_ddr_to_bar(pci_info, die_index, va[i], &pa[i]);
		if(ret) {
			VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
							"%s:%d, trans ddr addr to bar addr failed, va[%d]:0x%llx.",
							__func__, __LINE__, i, va[i]);
			return 0;
		}
	}

	pgsz_bitmap &= GENMASK(BITS_PER_LONG - 1, PAGE_SHIFT);
	mask = pgsz_bitmap & GENMASK(BITS_PER_LONG - 1, bits_per((size- 1 + virt) ^ virt));

	for(i = 0; i < 3; i++) {
		mask |= pa[i] ^ va[i];
	}

	if (mask)
		pgsz_bitmap &= GENMASK(count_trailing_zeros(mask), 0);
	return pgsz_bitmap ? rounddown_pow_of_two(pgsz_bitmap) : 0;
}

static int set_dma_sg(struct scatterlist *sg, u64 bar_address, u64 chunk_size,
			struct device *dev, enum dma_data_direction dir)
{
	dma_addr_t addr;
	int rc;

	addr = dma_map_resource(dev, bar_address, chunk_size, dir,
				DMA_ATTR_SKIP_CPU_SYNC);
	rc = dma_mapping_error(dev, addr);
	if (rc)
		return rc;

	sg_set_page(sg, NULL, chunk_size, 0);
	sg_dma_address(sg) = addr;
	sg_dma_len(sg) = chunk_size;
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s:%d, bar_address:0x%llx, addr:0x%llx, size:0x%llx.",
					__func__, __LINE__, bar_address, addr, chunk_size);
	return 0;
}

static struct sg_table *alloc_sgt_from_device_pages(struct vastai_pci_info *pci_info, u32 die_index,
                        u64 dev_addr, u64 npages,
						u64 page_size, u64 exported_size, u64 offset,
						struct device *dev, enum dma_data_direction dir)
{
	u64 dma_max_seg_size, curr_page, size, chunk_size, left_size_to_export, left_size_in_page,
		left_size_in_dma_seg, device_address, bar_address, start_page;
	struct scatterlist *sg;
	unsigned int nents, i;
	struct sg_table *sgt;
	bool next_sg_entry;
	int rc;
	u32 die_id = vastai_pci_get_die_id(pci_info, die_index);

	/* Align max segment size to PAGE_SIZE to fit the minimal IOMMU mapping granularity */
	dma_max_seg_size = ALIGN_DOWN(dma_get_max_seg_size(dev), PAGE_SIZE);
	if (dma_max_seg_size < PAGE_SIZE) {
		VASTAI_PCI_ERR(pci_info, die_id,
				"%s:%d, dma_max_seg_size %llu can't be smaller than PAGE_SIZE",
				__func__, __LINE__, dma_max_seg_size);
		return ERR_PTR(-EINVAL);
	}

	sgt = kzalloc(sizeof(*sgt), GFP_KERNEL);
	if (!sgt)
		return ERR_PTR(-ENOMEM);

	/* Calculate the required number of entries for the SG table */
	curr_page = start_page = 0;
	nents = 1;
	left_size_to_export = exported_size;
	left_size_in_page = page_size - offset;
	left_size_in_dma_seg = dma_max_seg_size;
	next_sg_entry = false;

	while (true) {
		size = min3(left_size_to_export, left_size_in_page, left_size_in_dma_seg);
		left_size_to_export -= size;
		left_size_in_page -= size;
		left_size_in_dma_seg -= size;

		if (!left_size_to_export)
			break;

		if (!left_size_in_page) {
			/* left_size_to_export is not zero so there must be another page */
			if(dev_addr + curr_page * page_size + page_size != dev_addr + (curr_page + 1) * page_size)
				next_sg_entry = true;

			++curr_page;
			left_size_in_page = page_size;
		}

		if (!left_size_in_dma_seg) {
			next_sg_entry = true;
			left_size_in_dma_seg = dma_max_seg_size;
		}

		if (next_sg_entry) {
			++nents;
			next_sg_entry = false;
		}
	}

	rc = sg_alloc_table(sgt, nents, GFP_KERNEL | __GFP_ZERO);
	if (rc)
		goto err_free_sgt;

	/* Prepare the SG table entries */
	curr_page = start_page;
	// device_address = pages[curr_page] + offset;
	device_address = dev_addr + curr_page * page_size + offset;
	left_size_to_export = exported_size;
	left_size_in_page = page_size - offset;
	left_size_in_dma_seg = dma_max_seg_size;
	next_sg_entry = false;

	for_each_sgtable_dma_sg(sgt, sg, i) {
		rc = vastai_ddr_to_bar(pci_info, die_index, device_address, &bar_address);
		if(rc) {
			VASTAI_PCI_ERR(pci_info, die_id, "%s:%d, trans ddr addr to bar addr failed, device_address:0x%llx.", __func__, __LINE__, device_address);
			goto err_unmap;
		}
		chunk_size = 0;

		for ( ; curr_page < npages ; ++curr_page) {
			size = min3(left_size_to_export, left_size_in_page, left_size_in_dma_seg);
			chunk_size += size;
			left_size_to_export -= size;
			left_size_in_page -= size;
			left_size_in_dma_seg -= size;

			if (!left_size_to_export)
				break;

			if (!left_size_in_page) {
				/* left_size_to_export is not zero so there must be another page */
				if(dev_addr + curr_page * page_size + page_size != dev_addr + (curr_page + 1) * page_size) {
					device_address = dev_addr + (curr_page + 1) * page_size;
					next_sg_entry = true;
				}

				left_size_in_page = page_size;
			}

			if (!left_size_in_dma_seg) {
				/*
				 * Skip setting a new device address if already moving to a page
				 * which is not contiguous with the current page.
				 */
				if (!next_sg_entry) {
					device_address += chunk_size;
					next_sg_entry = true;
				}

				left_size_in_dma_seg = dma_max_seg_size;
			}

			if (next_sg_entry) {
				next_sg_entry = false;
				break;
			}
		}

		rc = set_dma_sg(sg, bar_address, chunk_size, dev, dir);
		if (rc)
			goto err_unmap;
	}

	/* There should be nothing left to export exactly after looping over all SG elements */
	if (left_size_to_export) {
		VASTAI_PCI_ERR(pci_info, die_id,
			"%s:%d, left size to export 0x%#llx after initializing %u SG elements",
			__func__, __LINE__, left_size_to_export, sgt->nents);
		rc = -ENOMEM;
		goto err_unmap;
	}

	/*
	 * Because we are not going to include a CPU list, we want to have some chance that other
	 * users will detect this when going over SG table, by setting the orig_nents to 0 and using
	 * only nents (length of DMA list).
	 */
	sgt->orig_nents = 0;

	VASTAI_PCI_DBG(pci_info, die_id, "%s:%d, prepared SG table with %u entries for importer %s",
					__func__, __LINE__, nents, dev_name(dev));
	for_each_sgtable_dma_sg(sgt, sg, i)
		VASTAI_PCI_DBG(pci_info, die_id,
			"%s:%d, SG entry %d: address 0x%#llx, length %#x",
			__func__, __LINE__, i, sg_dma_address(sg), sg_dma_len(sg));

	return sgt;

err_unmap:
	for_each_sgtable_dma_sg(sgt, sg, i) {
		if (!sg_dma_len(sg))
			continue;

		dma_unmap_resource(dev, sg_dma_address(sg), sg_dma_len(sg), dir,
					DMA_ATTR_SKIP_CPU_SYNC);
	}

	sg_free_table(sgt);

err_free_sgt:
	kfree(sgt);
	return ERR_PTR(rc);
}

static struct sg_table*
vastai_rdma_map_devmem(struct dma_buf_attachment *attachment,
				enum dma_data_direction dir)
{
	struct dma_buf *dma_buf = attachment->dmabuf;
	struct rdma_dmabuf_priv *rdma_dmabuf;
	struct vastai_pci_info *pci_info;
	struct ib_umem_dmabuf *umem_dmabuf;
	struct ib_umem *umem;
	struct sg_table *sgt;
	u64 request_size, exported_size, offset, soc_addr, page_size;
	u32 die_index, die_id;

	if (!attachment->peer2peer) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Failed to map dmabuf because p2p is disabled");
		return ERR_PTR(-EPERM);
	}

	rdma_dmabuf = (struct rdma_dmabuf_priv *)dma_buf->priv;
	pci_info= rdma_dmabuf->pci_info;
	die_index = rdma_dmabuf->die_index;
	die_id = rdma_dmabuf->die_id;
	soc_addr = rdma_dmabuf->soc_addr;
	exported_size = rdma_dmabuf->dmabuf->size;

	umem_dmabuf = (struct ib_umem_dmabuf *)attachment->importer_priv;
	umem = &umem_dmabuf->umem;
	offset = umem->address;
	request_size = umem->length; //size to reg mr
	page_size = find_best_pgsz(pci_info, die_index, soc_addr, request_size);
	if(page_size == 0 || page_size > MAX_PAGE_SIZE)
		page_size = DEFAULT_PAGE_SIZE;

	if(page_size > request_size)
		page_size = request_size;

	if(request_size > exported_size) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s:%d, invalid size, request_size:0x%llx > exported_size:0x%llx",
						__func__, __LINE__, request_size, exported_size);
		return ERR_PTR(-EINVAL);
	}

	sgt = alloc_sgt_from_device_pages(pci_info, die_index, soc_addr, 1, page_size, exported_size, offset,
						attachment->dev, dir);
	if (IS_ERR(sgt))
		VASTAI_PCI_ERR(pci_info, die_id, "%s:%d, failed (%ld) to initialize sgt for dmabuf",
						__func__, __LINE__, PTR_ERR(sgt));

	VASTAI_PCI_DBG(pci_info, die_id,
                    "%s:%d, rdma dmabuf map info: exported_size:0x%llx, request_size:0x%llx, page_size:0x%llx, offset:0x%llx, soc_addr:0x%llx",
                    __func__, __LINE__, exported_size, request_size, page_size, offset, soc_addr);
	return sgt;
}

static struct sg_table*
vastai_rdma_map_hostmem(struct dma_buf_attachment *attachment,
				enum dma_data_direction dir)
{
	struct dma_buf *dma_buf = attachment->dmabuf;
	struct device *dev = attachment->dev;
	struct sg_table *sgt = NULL;
	struct scatterlist *sg = NULL;
	struct rdma_dmabuf_priv *rdma_dmabuf = NULL;
	struct rdma_hostbuf_list *hostbuf_list = NULL;
	struct vastai_pci_info *pci_info = NULL;
	size_t export_size = dma_buf->size;
	size_t remain_size = export_size;
	u32 die_id, nents = 0, i = 0;
	int ret = 0;

	rdma_dmabuf = (struct rdma_dmabuf_priv *)dma_buf->priv;
	pci_info= rdma_dmabuf->pci_info;
	die_id = rdma_dmabuf->die_id;
	hostbuf_list = rdma_dmabuf->hostbuf_list;
	nents = hostbuf_list->entry_count;

	sgt = kzalloc(sizeof(struct sg_table), GFP_KERNEL);
	if (!sgt)
		return ERR_PTR(-ENOMEM);

	ret = sg_alloc_table(sgt, nents, GFP_KERNEL | __GFP_ZERO);
	if (ret)
		goto err_free_sgt;

	for_each_sgtable_dma_sg(sgt, sg, i) {
		size_t temp_size = remain_size <= VASTAI_MAX_DMA_BUF ? remain_size : VASTAI_MAX_DMA_BUF;
		struct rdma_hostbuf_elem *dm = hostbuf_list->buf_list[i];
		if(!dm) {
			VASTAI_PCI_ERR(pci_info, die_id, "%s:%d dm in hostbuf list is null", __func__, __LINE__);
			ret = -EINVAL;
			goto err_unmap;
		}
		ret = set_dma_sg(sg, dm->dma_bus_addr, temp_size, dev, dir);
		if (ret)
			goto err_unmap;
	}
	sgt->orig_nents = 0;

	return sgt;

err_unmap:
	for_each_sgtable_dma_sg(sgt, sg, i) {
		if (!sg_dma_len(sg))
			continue;
		dma_unmap_resource(dev, sg_dma_address(sg), sg_dma_len(sg), dir,
					DMA_ATTR_SKIP_CPU_SYNC);
	}
	sg_free_table(sgt);

err_free_sgt:
	kfree(sgt);
	return ERR_PTR(ret);
}

static struct sg_table *
vastai_rdma_map_dmabuf(struct dma_buf_attachment *attachment,
				enum dma_data_direction dir)
{
	struct dma_buf *dma_buf = attachment->dmabuf;
	struct rdma_dmabuf_priv *rdma_dmabuf;
	struct sg_table *sgt;
	rdma_mem_type_t mem_type;

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	if (!attachment->peer2peer) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "Failed to map dmabuf because p2p is disabled");
		return ERR_PTR(-EPERM);
	}

	rdma_dmabuf = (struct rdma_dmabuf_priv *)dma_buf->priv;
	mem_type = rdma_dmabuf->mem_type;

	if(mem_type == rdmaHostMem) {
		sgt = vastai_rdma_map_hostmem(attachment, dir);
	} else if(mem_type == rdmaDevMem) {
		sgt = vastai_rdma_map_devmem(attachment, dir);
	}

	return sgt;
}

static void vastai_rdma_unmap_dmabuf(struct dma_buf_attachment *attachment,
				  struct sg_table *sgt,
				  enum dma_data_direction dir)
{
	struct scatterlist *sg;
	int i;

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	for_each_sgtable_dma_sg(sgt, sg, i)
		dma_unmap_resource(attachment->dev, sg_dma_address(sg),
					sg_dma_len(sg), dir,
					DMA_ATTR_SKIP_CPU_SYNC);

	/* Need to restore orig_nents because sg_free_table use that field */
	sgt->orig_nents = sgt->nents;
	sg_free_table(sgt);
	kfree(sgt);
}

static int vastai_rdma_dmabuf_pin(struct dma_buf_attachment *attach)
{
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	return 0;
}

static void vastai_rdma_dmabuf_unpin(struct dma_buf_attachment *attach)
{
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
}

static int vastai_mmap_rdma_dmabuf(struct dma_buf *dmabuf,
			       struct vm_area_struct *vma)
{
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	return 0;
}

static int vastai_rdma_dmabuf_attach(struct dma_buf *dmabuf,
				 struct dma_buf_attachment *attach)
{
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	return 0;
}

static void vastai_rdma_dmabuf_detach(struct dma_buf *dmabuf,
				  struct dma_buf_attachment *attach)
{
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
}
#endif

static int vastai_validate_soc_addr(struct vastai_pci_info *pci_info,
                                    u32 die_index, u64 addr, u64 len)
{
	 if (addr >= pci_info->ddr_min_addr &&
		 (addr + len) <= pci_info->ddr_max_addr )
		 return 0;
	 else if (addr >= CSRAM_BASE_ADDR &&
		 (addr + len) <= CSRAM_BASE_ADDR + SZ_1M)
		 return 0;
	 else {
		 VASTAI_PCI_ERR(pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"%s:%d, device addr:0x%llx,len:0x%llx is invalid",
				 __func__, __LINE__, addr, len);
		 return -EINVAL;
	 }
}

static struct rdma_hostbuf_elem*
rdma_hostbuf_create(struct vastai_pci_info *pci_info, size_t size)
{
	struct device *dev = &(pci_info->dev->dev);
	struct rdma_hostbuf_elem *dm = kzalloc(sizeof(struct rdma_hostbuf_elem), GFP_KERNEL);
	if (!dm)
		return NULL;

	dm->vir = dma_alloc_coherent(dev, size, &dm->dma_bus_addr, GFP_KERNEL | __GFP_NOWARN);
	if (!dm->vir)
		goto dma_alloc_err;

	dm->size = size;
	return dm;

dma_alloc_err:
	kfree(dm);
	return NULL;
}

void rdma_hostbuf_destroy(struct vastai_pci_info *pci_info,
				struct rdma_hostbuf_elem *dm)
{
	struct device *dev = &(pci_info->dev->dev);
	if (!dev) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "%s dev is NULL!\n", __func__);
		return;
	}
	dma_free_coherent(dev, dm->size, dm->vir, dm->dma_bus_addr);
	memset(dm, 0x00, sizeof(struct rdma_hostbuf_elem));
	return;
}

static struct rdma_hostbuf_list*
hostbuf_list_get(struct vastai_pci_info *pci_info,
		u64 export_size,
		rdma_mem_type_t mem_type)
{
	struct rdma_hostbuf_list *hostbuf_list = NULL;
	size_t remain_size = export_size;
	u32 entry_count = 0;
	int i = 0;

	if(mem_type == rdmaDevMem)
		return NULL;

	entry_count = vast_div_round_up(export_size, VASTAI_MAX_DMA_BUF);
	hostbuf_list = kzalloc(sizeof(struct rdma_hostbuf_list) +
				entry_count * sizeof(struct rdma_hostbuf_elem *), GFP_KERNEL);
	if(!hostbuf_list)
		return NULL;

	hostbuf_list->entry_count = entry_count;
	for (i = 0; i < entry_count; i++) {
		size_t temp_size = remain_size <= VASTAI_MAX_DMA_BUF ?	remain_size : VASTAI_MAX_DMA_BUF;
		struct rdma_hostbuf_elem *dm = rdma_hostbuf_create(pci_info, temp_size);
		if (!dm) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				       "%s rdma host buf malloc failed, size:%ld\n",
				       __func__, temp_size);
			goto hostbuf_alloc_err;
		}
		hostbuf_list->buf_list[i] = dm;
		remain_size -= temp_size;
	}

	return hostbuf_list;

hostbuf_alloc_err:
	while (i) {
		struct rdma_hostbuf_elem *dm = hostbuf_list->buf_list[--i];
		rdma_hostbuf_destroy(pci_info, dm);
	}
	kfree(hostbuf_list);
	return NULL;
}

static void hostbuf_list_put(struct vastai_pci_info *pci_info,
				struct rdma_hostbuf_list* hostbuf_list)
{
	u32 entry_count = 0;
	int i = 0;
	if(!pci_info || !hostbuf_list)
		return;

	entry_count = hostbuf_list->entry_count;
	for (i = 0; i < entry_count; i++) {
		struct rdma_hostbuf_elem *dm = hostbuf_list->buf_list[i];
		if(dm)
			rdma_hostbuf_destroy(pci_info, dm);
	}
	kfree(hostbuf_list);
}

static u64 get_export_size(u64 size, rdma_mem_type_t mem_type)
{
	if(mem_type == rdmaHostMem && size > VCCL_RDMA_MAX_HOSTBUF_SIZE)
			return VCCL_RDMA_MAX_HOSTBUF_SIZE;
	return size;
}

static void vastai_rdma_release_dmabuf(struct dma_buf *dmabuf)
{
	struct rdma_dmabuf_priv *rdma_dmabuf = NULL;
	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s enter", __func__);
	if(!dmabuf) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s:%d, invalid input parameter.", __func__, __LINE__);
		return;
	}

	rdma_dmabuf = dmabuf->priv;
	hostbuf_list_put(rdma_dmabuf->pci_info, rdma_dmabuf->hostbuf_list);
	kfree(rdma_dmabuf);
}

int vastai_rdma_hostbuf_get(int dmabuf_fd, u32* buf_num, u64* buf_list)
{
	struct dma_buf *dmabuf = NULL;
	struct rdma_dmabuf_priv *rdma_dmabuf = NULL;
	struct rdma_hostbuf_list *hostbuf_list = NULL;
	u64 *addr_list = NULL;
	int i = 0, ret = 0;

	if(!buf_list) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s buf_list is null.", __func__);
		return -EINVAL;
	}

	dmabuf = dma_buf_get(dmabuf_fd);
	if(!dmabuf) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s get dma buf failed.", __func__);
		return -EINVAL;
	}

	rdma_dmabuf = dmabuf->priv;
	if(!rdma_dmabuf) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s get rdma dmabuf priv failed.", __func__);
		ret = -EINVAL;
		goto err_dmabuf_put;
	}

	hostbuf_list = rdma_dmabuf->hostbuf_list;
	if(!hostbuf_list) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s get host buf list failed.", __func__);
		ret = -EINVAL;
		goto err_dmabuf_put;
	}

	*buf_num = hostbuf_list->entry_count;
	addr_list = kzalloc(*buf_num * sizeof(u64), GFP_KERNEL);
	if(!addr_list) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s alloc mem for host buf addr list failed.", __func__);
		ret = -ENOMEM;
		goto err_dmabuf_put;
	}

	for (i = 0; i < *buf_num; i++) {
		struct rdma_hostbuf_elem *dm = hostbuf_list->buf_list[i];
		if (!dm) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s get host buf list element failed.\n", __func__);
			ret = -EINVAL;
			goto err_alloc_addr_list;
		}
		*(addr_list + i) = (u64)dm->dma_bus_addr;
	}

	ret = vastai_pci_copy_to_user(buf_list, addr_list, *buf_num * sizeof(u64));
	if(ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s copy host buf list addr to user failed.", __func__);
		ret = -EINVAL;
		goto err_alloc_addr_list;
	}

err_alloc_addr_list:
	kfree(addr_list);
err_dmabuf_put:
	dma_buf_put(dmabuf);
	return ret;
}

static const struct dma_buf_ops vastai_rdma_dmabuf_ops = {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	.attach = vastai_rdma_dmabuf_attach,
	.detach = vastai_rdma_dmabuf_detach,
	.pin = vastai_rdma_dmabuf_pin,
	.unpin = vastai_rdma_dmabuf_unpin,
	.map_dma_buf = vastai_rdma_map_dmabuf,
	.unmap_dma_buf = vastai_rdma_unmap_dmabuf,
	.mmap = vastai_mmap_rdma_dmabuf,
#endif
	.release = vastai_rdma_release_dmabuf,
};

struct dma_buf *vastai_rdma_dmabuf_export(struct vastai_pci_info *pci_info,
						u32 die_index,
						u64 size,
						u64* addr,
						rdma_mem_type_t mem_type)
{
	DEFINE_DMA_BUF_EXPORT_INFO(exp_info);
	struct rdma_dmabuf_priv *rdma_dmabuf = NULL;
	struct rdma_hostbuf_list* hostbuf_list = NULL;
	int ret = 0;
	u64 export_size = get_export_size(size, mem_type);

	if(!pci_info || !addr) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "invalid input parameter, pci_info or vaddr is null.");
		return NULL;
	}

	VASTAI_PCI_DBG(pci_info, vastai_pci_get_die_id(pci_info, die_index), "%s enter", __func__);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 12, 0)
	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "kernel version lower than 5.12.0, can not support rdma dmabuf.");
	return NULL;
#endif

	if(mem_type == rdmaDevMem) {
		ret = vastai_validate_soc_addr(pci_info, die_index, *addr, size);
		if(ret) {
			VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
							"%s:%d, input soc addr is invalid, addr:0x%llx, size:0x%llx.",
							__func__, __LINE__, *addr, size);
			return NULL;
		}
	}

	rdma_dmabuf = (struct rdma_dmabuf_priv*)kzalloc(sizeof(*rdma_dmabuf), GFP_KERNEL);
	rdma_dmabuf->pci_info = pci_info;
	rdma_dmabuf->die_index = die_index;
	rdma_dmabuf->die_id = vastai_pci_get_die_id(pci_info, die_index);
	rdma_dmabuf->soc_addr = *addr;
	rdma_dmabuf->mem_type = mem_type;

	hostbuf_list = hostbuf_list_get(pci_info, size, mem_type);
	if(mem_type == rdmaHostMem && !hostbuf_list) {
		VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
						"%s:%d, rdma use host memory, but alloc hostbuf failed.",
						__func__, __LINE__);
		return NULL;
	}
	rdma_dmabuf->hostbuf_list = hostbuf_list;

	exp_info.ops = &vastai_rdma_dmabuf_ops;
	exp_info.size = export_size;
	exp_info.flags = O_CLOEXEC | O_RDWR;
	exp_info.priv = rdma_dmabuf;

	rdma_dmabuf->dmabuf = dma_buf_export(&exp_info);
	if (IS_ERR(rdma_dmabuf->dmabuf)) {
		ret = PTR_ERR(rdma_dmabuf->dmabuf);
		VASTAI_PCI_ERR(pci_info, rdma_dmabuf->die_id, "%s:%d, failed to export rdma dma-buf, ret:%d", __func__, __LINE__, ret);
		goto err_free_rdma_dmabuf;
	}

	VASTAI_PCI_DBG(pci_info, rdma_dmabuf->die_id,
                    "%s:%d, rdma dmabuf export info: mem_type:%d vaddr:0x%llx, size:0x%llx",
                    __func__, __LINE__, mem_type, rdma_dmabuf->soc_addr, export_size);

	return rdma_dmabuf->dmabuf;

err_free_rdma_dmabuf:
	hostbuf_list_put(pci_info, rdma_dmabuf->hostbuf_list);
	kfree(rdma_dmabuf);
	return NULL;
}
