/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/delay.h>
#include <linux/dma-buf.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/mempool.h>
#include <linux/iommu.h>
#include <linux/module.h>
#if KERNEL_VERSION(5,10,0) <= LINUX_VERSION_CODE && \
	!defined(RHEL_RELEASE_VERSION)
#include <linux/dma-map-ops.h>
#endif
#include "vastai_pci.h"
#include "vastai_dmabuf.h"

#ifdef CONFIG_VASTAI_KUNIT
#include "stub.h"
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 4, 0)
MODULE_IMPORT_NS(DMA_BUF);
#endif

/* dma_manager:
	-. dmabuf user space api
	-. dma buf malloc and free
	-. mempool create and manager
*/
static inline struct vastai_dma_buf *vastai_dma_buf_sg_create(
			struct vastai_pci_info *pci_info, size_t size, gfp_t gfp_mask);
/**
 * vastai_udma_malloc - alloc buf with dma coherent
 * @pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe()
 * @dm:	this function will fill this struct. It must be __NOT__ null pointer
 * @size: size of the buf.
 *
 * Return: success return zero. other value is errno.
 *
 * this function will alloc buffer with coherent, it will retry when alloc is failed,
 *  patient is 10.
 */
int vastai_udma_malloc(struct vastai_pci_info *pci_info,
		       struct vastai_dma_buf *dm, int size)
{
	struct device *dev;
	int patient = 10;

	if ((!pci_info) || (!pci_info->dev)) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s pci_info 0x%p or dev 0x%p is NULL\n",
			       __func__, pci_info, pci_info->dev);
		return -ENXIO;
	}
	dev = &(pci_info->dev->dev);
	if (!dev) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "%s dev is NULL!\n",
			       __func__);
		return -ENODEV;
	}

	dm->vir = dma_alloc_coherent(dev, size,
				     (dma_addr_t *)(&(dm->dma_bus_addr)),
				     GFP_DMA32 | GFP_KERNEL);

	while (dm->vir == 0 && patient--) {
		msleep(1);
		dm->vir =
			dma_alloc_coherent(dev, size,
					   (dma_addr_t *)(&(dm->dma_bus_addr)),
					   GFP_DMA32 | GFP_KERNEL);
	}

	if (dm->vir == 0) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s dma_alloc_coherent err, size=0x%x\n",
			       __func__, size);
		return -ENOMEM;
	}
	dm->size = size;
	VASTAI_PCI_DBG(pci_info, DUMMY_DIE_ID,
		       "%s dma_alloc_coherent(%d) %p 0x%lx\n", __func__, size,
		       dm->vir, dm->dma_bus_addr);
	if (pci_info->die_num_in_fn > 1 && (dm->dma_bus_addr & (~DMA_BIT_MASK(36)))) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s dma addr not support 0x%lx\n", __func__,
			       dm->dma_bus_addr);
		vastai_udma_free(pci_info, dm);
		return -ENOMEM;
	}
	dm->pci_info = pci_info;

	return 0;
}

/**
 * vastai_udma_free - free buf that alloc by vastai_udma_alloc
 * @pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe()
 * @dm:	that buf want to free, fill by vastai_udma_alloc
 *
 * always success.
 */
int vastai_udma_free(struct vastai_pci_info *pci_info,
		     struct vastai_dma_buf *dm)
{
	struct device *dev;

	if ((!pci_info) || (!pci_info->dev)) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s pci_info 0x%p or dev 0x%p is NULL\n",
			       __func__, pci_info, pci_info->dev);
		return -ENXIO;
	}
	dev = &(pci_info->dev->dev);
	if (!dev) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "%s dev is NULL!\n",
			       __func__);
		return -ENODEV;
	}
	VASTAI_PCI_DBG(pci_info, DUMMY_DIE_ID,
		       "dma_free_coherent(0x%x, %p,0x%lx)\n", dm->size, dm->vir,
		       dm->dma_bus_addr);
	dma_free_coherent(dev, dm->size, (void *)(dm->vir), dm->dma_bus_addr);
	memset(dm, 0x00, sizeof(struct vastai_dma_buf));

	return 0;
}

struct vastai_buf_list {
	u32 entry_count;
	struct vastai_dma_buf *buf_list[0];
};

u32 get_vastai_dma_buf_count(struct dma_buf *dma_buf)
{
	struct vastai_buf_list *buf_list =
		(struct vastai_buf_list *)dma_buf->priv;

	return buf_list->entry_count;
}

struct vastai_dma_buf *get_vastai_dma_buf(struct dma_buf *dma_buf, u32 index)
{
	struct vastai_buf_list *buf_list =
		(struct vastai_buf_list *)dma_buf->priv;

	if (index >= buf_list->entry_count)
		return NULL;

	return buf_list->buf_list[index];
}

static struct sg_table *
vastai_map_dma_buf(struct dma_buf_attachment *attachment,
		   enum dma_data_direction dir)
{
	return NULL;
}

static void vastai_unmap_dma_buf(struct dma_buf_attachment *attachment,
				 struct sg_table *table,
				 enum dma_data_direction dir)
{
}

static void vastai_release_dma_buf(struct dma_buf *dmabuf)
{
	u32 entry_count = get_vastai_dma_buf_count(dmabuf);
	u32 i;

	for (i = 0; i < entry_count; i++) {
		struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);
		vastai_mempool_put(dm->pci_info, dm);
	}
	kfree(dmabuf->priv);
}
static void vastai_free_pages(struct page **pages, u8 *pages_order, int size)
{
	int i = 0;

	while (size > 0) {
		__free_pages(pages[i], pages_order[i]);
		size -= PAGE_SIZE << pages_order[i];
		i += 1 << pages_order[i];
	}
}

void vastai_udma_sg_free(struct vastai_pci_info *pci_info,
				struct vastai_dma_buf *dm)
{
	struct device *dev = &(dm->pci_info->dev->dev);
	struct sg_table *sgt = &dm->sg_table;

	dma_unmap_sg(dev, sgt->sgl, sgt->orig_nents, 0);
	if (dm->vir)
		vm_unmap_ram(dm->vir, dm->num_pages);
	sg_free_table(sgt);
	vastai_free_pages(dm->pages,
		dm->pages_order,
		ALIGN(dm->size, PAGE_SIZE));
	kvfree(dm->pages_order);
	kvfree(dm->pages);
}

static void vastai_release_dma_buf_sg(struct dma_buf *dmabuf)
{
	struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, 0);

	vastai_udma_sg_free(dm->pci_info, dm);

	kfree(dmabuf->priv);
}

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 3)
static void *vastai_kmap_dma_buf(struct dma_buf *dmabuf, unsigned long page_num)
{
	return NULL;
}

#endif
#elif KERNEL_VERSION(5,6,0) > LINUX_VERSION_CODE
static void *vastai_kmap_dma_buf(struct dma_buf *dmabuf, unsigned long page_num)
{
	return NULL;
}
#endif

static int vastai_mmap_dma_buf(struct dma_buf *dmabuf,
			       struct vm_area_struct *vma)
{
	u32 i = 0;
	size_t remain_size = vma->vm_end - vma->vm_start;
	unsigned long start = vma->vm_start;
	int ret;
#if (defined(__aarch64__) || defined(__arm__))
	unsigned long ori_start = vma->vm_start;
#endif
	while (remain_size) {
		struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);
		size_t size = remain_size < dm->size ? remain_size : dm->size;
#if (defined(__aarch64__) || defined(__arm__))
		vma->vm_end = vma->vm_start + size;
		ret = dma_mmap_coherent(&dm->pci_info->dev->dev, vma, dm->vir,
					dm->dma_bus_addr, size);
		vma->vm_start += size;
#else
		ret = remap_pfn_range(vma, start,
				      (dm->phy) >> PAGE_SHIFT, size,
				      vma->vm_page_prot);
#endif
		if (ret) {
			VASTAI_PCI_ERR(dm->pci_info, DUMMY_DIE_ID,
				       "remap_pfn_range err %d\n", ret);
			return ret;
		}
		start += size;
		remain_size -= size;
		i += 1;
	}
#if (defined(__aarch64__) || defined(__arm__))
	vma->vm_start = ori_start;
#endif
	return 0;
}

static int vastai_mmap_dma_buf_sg(struct dma_buf *dmabuf,
				struct vm_area_struct *vma)
{
	int ret = 0;
	size_t remain_size = vma->vm_end - vma->vm_start;
	unsigned long start = vma->vm_start;
	struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, 0);
	int i = 0;

	while (remain_size) {
		size_t dm_size = PAGE_SIZE << dm->pages_order[i];
		size_t size = remain_size < dm_size ? remain_size : dm_size;
		ret = remap_pfn_range(vma, start,
				      page_to_pfn(dm->pages[i]), size,
				      vma->vm_page_prot);
		if (ret) {
			VASTAI_PCI_ERR(dm->pci_info, DUMMY_DIE_ID,
				       "remap_pfn_range err %d\n", ret);
			return ret;
		}

		start += size;
		remain_size -= size;
		i += 1 << dm->pages_order[i];
	}

	return ret;
}

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 1)
static void *vastai_map_atomic(struct dma_buf *dmabuf, unsigned long page_num)
{
	return NULL;
}
#endif
#elif KERNEL_VERSION(4, 19, 0) >= LINUX_VERSION_CODE
static void *vastai_map_atomic(struct dma_buf *dmabuf, unsigned long page_num)
{
	return NULL;
}
#endif

/* refer to driver-api/dma-buf.rst */
static const struct dma_buf_ops vastai_dma_buf_ops = {
	.map_dma_buf = vastai_map_dma_buf,
	.unmap_dma_buf = vastai_unmap_dma_buf,
	.release = vastai_release_dma_buf,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 3)
	.map = vastai_kmap_dma_buf,
#endif
#elif KERNEL_VERSION(5,6,0) > LINUX_VERSION_CODE
	.map = vastai_kmap_dma_buf,
#endif
	.mmap = vastai_mmap_dma_buf,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 1)
	.map_atomic = vastai_map_atomic,
#endif
#elif KERNEL_VERSION(4, 19, 0) >= LINUX_VERSION_CODE
	.map_atomic = vastai_map_atomic,
#endif
};

static const struct dma_buf_ops vastai_dma_buf_sg_ops = {
	.map_dma_buf = vastai_map_dma_buf,
	.unmap_dma_buf = vastai_unmap_dma_buf,
	.release = vastai_release_dma_buf_sg,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 3)
	.map = vastai_kmap_dma_buf,
#endif
#elif KERNEL_VERSION(5,6,0) > LINUX_VERSION_CODE
	.map = vastai_kmap_dma_buf,
#endif
	.mmap = vastai_mmap_dma_buf_sg,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 1)
	.map_atomic = vastai_map_atomic,
#endif
#elif KERNEL_VERSION(4, 19, 0) >= LINUX_VERSION_CODE
	.map_atomic = vastai_map_atomic,
#endif
};

/**
 * @brief vastai's dma_buf constructor. it will alloc coherent buf, and as dmabuf to user space.
 *
 * @param pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 * @param size: size of this buffer.
 * @return struct dma_buf*
 */
struct dma_buf *vastai_alloc_dma_buf(struct vastai_pci_info *pci_info, int size)
{
	DEFINE_DMA_BUF_EXPORT_INFO(exp_info);
	struct dma_buf *dmabuf;
	u32 entry_count = vast_div_round_up(size, VASTAI_MAX_DMA_BUF);
	int remain_size = size;
	struct vastai_buf_list *buf_list =
		kmalloc(sizeof(struct vastai_buf_list) +
				entry_count * sizeof(struct vastai_dma_buf *),
			GFP_KERNEL);
	int i = 0;

	if (!buf_list)
		return NULL;

	buf_list->entry_count = entry_count;

	for (i = 0; i < entry_count; i++) {
		int temp_size = remain_size <= VASTAI_MAX_DMA_BUF ?
					remain_size :
					VASTAI_MAX_DMA_BUF;
		struct vastai_dma_buf **dm = &(buf_list->buf_list[i]);

		*dm = vastai_mempool_get(pci_info, temp_size);

		if (*dm== NULL) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				       "%s malloc failed size %d\n",
				       __FUNCTION__, size);
			goto UDMA_MALLOC_ERR;
		}
		remain_size -= temp_size;
	}

	exp_info.ops = &vastai_dma_buf_ops;
	exp_info.size = size;
	exp_info.flags = O_CLOEXEC | O_RDWR;
	exp_info.priv = buf_list;

	dmabuf = dma_buf_export(&exp_info);
	if (IS_ERR(dmabuf)) {
		goto DMA_BUF_EXPORT_ERR;
	}

	return dmabuf;
DMA_BUF_EXPORT_ERR:

UDMA_MALLOC_ERR:
	while (i) {
		struct vastai_dma_buf *dm = buf_list->buf_list[--i];
		vastai_mempool_put(pci_info, dm);
	}

	kfree(buf_list);

	return NULL;
}
struct dma_buf *vastai_alloc_dma_buf_sg(struct vastai_pci_info *pci_info, int size)
{
	DEFINE_DMA_BUF_EXPORT_INFO(exp_info);
	struct dma_buf *dmabuf;
	struct vastai_buf_list *buf_list =
		kmalloc(sizeof(struct vastai_buf_list) +
			sizeof(struct vastai_dma_buf *),
			GFP_KERNEL);
	struct vastai_dma_buf **dm;

	if (!buf_list)
		return NULL;

	dm = &(buf_list->buf_list[0]);

	*dm = vastai_dma_buf_sg_create(pci_info, size, GFP_KERNEL);
	if (*dm == NULL)
		goto UDMA_MALLOC_ERR;

	buf_list->entry_count = 1;

	exp_info.ops = &vastai_dma_buf_sg_ops;
	exp_info.size = size;
	exp_info.flags = O_CLOEXEC | O_RDWR;
	exp_info.priv = buf_list;

	dmabuf = dma_buf_export(&exp_info);
	if (IS_ERR(dmabuf)) {
		goto DMA_BUF_EXPORT_ERR;
	}

	return dmabuf;
DMA_BUF_EXPORT_ERR:

UDMA_MALLOC_ERR:
	kfree(buf_list);

	return NULL;
}

/**
 * @buf_count: The number of buf in this pool
 * @pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 */
struct vastai_mem_pool {
	atomic_t buf_count;
	struct vastai_pci_info *pci_info;
	mempool_t *pool;
};

#define VASTAI_VCCL_MEM_POOL_NUM  (8)
#define VASTAI_VCCL_MEM_POOL_SIZE (0x100000)

extern void *_mempool_alloc(mempool_t *pool, gfp_t gfp_mask);
extern void _mempool_free(void *element, mempool_t *pool);

static void vastai_release_vccl_buf(struct dma_buf *dmabuf)
{
	u32 entry_count = get_vastai_dma_buf_count(dmabuf);
	u32 i;

	for (i = 0; i < entry_count; i++) {
		struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);
		VASTAI_PCI_DBG(dm->pci_info, DUMMY_DIE_ID,
			"%s node[%d] dma_bus_addr 0x%lx is released",
			__func__, dm->pci_info->vccl_pool->pool->curr_nr, dm->dma_bus_addr);
		_mempool_free(dm, dm->pci_info->vccl_pool->pool);
	}
	kfree(dmabuf->priv);
}

static const struct dma_buf_ops vastai_vccl_buf_ops = {
	.map_dma_buf = vastai_map_dma_buf,
	.unmap_dma_buf = vastai_unmap_dma_buf,
	.release = vastai_release_vccl_buf,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 3)
	.map = vastai_kmap_dma_buf,
#endif
#elif KERNEL_VERSION(5,6,0) > LINUX_VERSION_CODE
	.map = vastai_kmap_dma_buf,
#endif
	.mmap = vastai_mmap_dma_buf,

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 1)
	.map_atomic = vastai_map_atomic,
#endif
#elif KERNEL_VERSION(4, 19, 0) >= LINUX_VERSION_CODE
	.map_atomic = vastai_map_atomic,
#endif
};

struct dma_buf *vastai_alloc_vccl_buf(struct vastai_pci_info *pci_info, int size, u64 *addr)
{
	DEFINE_DMA_BUF_EXPORT_INFO(exp_info);
	struct dma_buf *dmabuf;
	struct vastai_dma_buf **dm;
	struct vastai_buf_list *buf_list =
		kmalloc(sizeof(struct vastai_buf_list) +
				sizeof(struct vastai_dma_buf *), GFP_KERNEL);

	if (!buf_list)
		return NULL;

	if (!pci_info->vccl_pool) {
		goto FREE_BUF_LIST;
	}
	if (size > VASTAI_VCCL_MEM_POOL_SIZE) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			"%s: size 0x%x exceeds maximum 0x%x\n",
			__func__, size, VASTAI_VCCL_MEM_POOL_SIZE);
		goto FREE_BUF_LIST;
	}

	buf_list->entry_count = 1;
	dm = &(buf_list->buf_list[0]);
	*dm = _mempool_alloc(pci_info->vccl_pool->pool, GFP_KERNEL);
	if (*dm == NULL) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			"%s failed, size %d\n",
			__func__, size);
		goto FREE_BUF_LIST;
	}
	*addr = (*dm)->dma_bus_addr;

	exp_info.ops = &vastai_vccl_buf_ops;
	exp_info.size = size;
	exp_info.flags = O_CLOEXEC | O_RDWR;
	exp_info.priv = buf_list;

	dmabuf = dma_buf_export(&exp_info);
	if (IS_ERR(dmabuf)) {
		goto FREE_MEMPOOL;
	}

	VASTAI_PCI_DBG(pci_info, DUMMY_DIE_ID,
		"%s node[%d] dma_bus_addr 0x%llx, vir 0x%llx, size 0x%x\n",
		__func__, pci_info->vccl_pool->pool->curr_nr, (u64)(*dm)->dma_bus_addr, (u64)(*dm)->vir, size);
	return dmabuf;

FREE_MEMPOOL:
	_mempool_free(*dm, (*dm)->pci_info->vccl_pool->pool);
FREE_BUF_LIST:
	kfree(buf_list);

	return NULL;
}

struct dma_buf *vastai_alloc_dma_buf_with_addr(struct vastai_pci_info *pci_info, int size, u64 *addr)
{
	struct dma_buf *dmabuf;
	struct vastai_dma_buf *dm;

	dmabuf = vastai_alloc_dma_buf(pci_info, size);
	if (!dmabuf)
		return NULL;

	dm = get_vastai_dma_buf(dmabuf, 0);

	*addr = dm->dma_bus_addr;

	return dmabuf;
}

phys_addr_t vastai_get_kern_phys_address(void *address)
{
	return virt_to_phys(address);
}

struct vastai_dma_buf *
vastai_dma_buf_create(struct vastai_pci_info *pci_info, size_t size,
		      gfp_t gfp_mask)
{
	struct device *dev = &(pci_info->dev->dev);

	struct vastai_dma_buf *dm =
		kzalloc(sizeof(struct vastai_dma_buf), gfp_mask);
	if (!dm) {
		return NULL;
	}
	dm->vir = dma_alloc_coherent(
		dev, size, (dma_addr_t *)&(dm->dma_bus_addr), gfp_mask | __GFP_NOWARN);
	if (!dm->vir) {
#ifdef ENABLE_MEMPOOL
		VASTAI_PCI_INFO(
			pci_info, DUMMY_DIE_ID,
			"%s system memory is not enough, we will alloc memory from mem pool 0x%lx\n",
			__func__, size);
#endif
		goto ERROR_FREE_DM;
	}
	dm->size = size;
	dm->pci_info = pci_info;
#if (!defined(__aarch64__) && !defined(__arm__))
	dm->phy = vastai_get_kern_phys_address(dm->vir);
	if (dm->phy == 0) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "failed to look up physical address\n");
		goto ERROR_ALLOC;
	}
#endif
	VASTAI_PCI_DBG(pci_info, DUMMY_DIE_ID, "%s(0x%lx) %p 0x%lx\n", __func__,
		       size, dm->vir, dm->dma_bus_addr);
	return dm;
#if (!defined(__aarch64__) && !defined(__arm__))
ERROR_ALLOC:
	dma_free_coherent(dev, dm->size, (void *)(dm->vir), dm->dma_bus_addr);
#endif
ERROR_FREE_DM:
	kfree(dm);
	return NULL;
}

void vastai_dma_buf_destroy(struct vastai_dma_buf *dm)
{
	vastai_udma_free(dm->pci_info, dm);
	kfree(dm);
}

static int vastai_dma_sg_alloc_compacted(
				struct vastai_pci_info *pci_info,
				struct vastai_dma_buf *buf,
				gfp_t gfp_flags)
{
	unsigned int last_page = 0;
	unsigned long size = ALIGN(buf->size, PAGE_SIZE);
	int node = dev_to_node(&pci_info->dev->dev);

	while (size > 0) {
		struct page *pages;
		int order;
		int i;

		order = get_order(size);
		/* Don't over allocate*/
		if ((PAGE_SIZE << order) > size)
			order--;

		pages = NULL;
		while (!pages) {
			pages = alloc_pages_node(node, GFP_KERNEL | __GFP_ZERO |
					__GFP_NOWARN | gfp_flags, order);
			if (pages)
			  break;

			if (order == 0) {
				vastai_free_pages(buf->pages,
					buf->pages_order,
					ALIGN(buf->size, PAGE_SIZE) - size);
				return -ENOMEM;
			}
			order--;
		}

		buf->pages_order[last_page] = order;
		for (i = 0; i < (1 << order); i++)
			buf->pages[last_page++] = &pages[i];
		size -= PAGE_SIZE << order;
	}

	return 0;
}

static inline struct vastai_dma_buf *vastai_dma_buf_sg_create(
					struct vastai_pci_info *pci_info,
					size_t size,
					gfp_t gfp_mask)
{
	struct device *dev = &(pci_info->dev->dev);
	int ret = 0;
	struct sg_table *sgt;
	struct vastai_dma_buf *dm = kzalloc(sizeof(struct vastai_dma_buf),
					gfp_mask);
	if (!dm) {
		return NULL;
	}
	dm->size = size;
	dm->num_pages = ALIGN(size, PAGE_SIZE) >> PAGE_SHIFT;
	dm->pci_info = pci_info;

	dm->pages_order = kvmalloc_array(dm->num_pages, sizeof(u8),
				GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages_order)
		goto ERROR_FREE_DM;

	dm->pages = kvmalloc_array(dm->num_pages, sizeof(struct page *),
				GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages)
		goto ERROR_FREE_PAGE_ORDER;


	ret = vastai_dma_sg_alloc_compacted(pci_info, dm, gfp_mask);
	if (ret)
		goto ERROR_FREE_PAGE_PTR;

#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8, 5)
	dm->vir = vm_map_ram(dm->pages, dm->num_pages, -1, PAGE_KERNEL);
#else
	dm->vir = vm_map_ram(dm->pages, dm->num_pages, -1);
#endif
#elif KERNEL_VERSION(5, 8, 0) > LINUX_VERSION_CODE
	dm->vir = vm_map_ram(dm->pages, dm->num_pages, -1, PAGE_KERNEL);
#else
	dm->vir = vm_map_ram(dm->pages, dm->num_pages, -1);
#endif

	if (!dm->vir)
		goto ERROR_FREE_PAGE;

	ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
					dm->num_pages,
					0,
					size,
					GFP_KERNEL);
	if (ret)
		goto ERROR_FREE_VM;

	sgt = &dm->sg_table;
	sgt->nents = dma_map_sg(dev, sgt->sgl, sgt->orig_nents, 0);
	if (!sgt->nents)
		goto ERROR_FREE_TABLE;

	VASTAI_PCI_DBG(pci_info, DUMMY_DIE_ID,
				"%s(0x%lx) %p 0x%lx\n", __func__,
				size, dm->vir, dm->dma_bus_addr);
	return dm;
ERROR_FREE_TABLE:
	sg_free_table(&dm->sg_table);
ERROR_FREE_VM:
	vm_unmap_ram(dm->vir, dm->num_pages);
ERROR_FREE_PAGE:
	vastai_free_pages(dm->pages,
			dm->pages_order,
			ALIGN(size, PAGE_SIZE));
ERROR_FREE_PAGE_PTR:
	kvfree(dm->pages);
ERROR_FREE_PAGE_ORDER:
	kvfree(dm->pages_order);
ERROR_FREE_DM:
	kfree(dm);
	return NULL;
}
static unsigned long get_contiguous_size(struct sg_table *sgt)
{
	struct scatterlist *s;
	dma_addr_t expected = sg_dma_address(sgt->sgl);
	unsigned int i;
	unsigned long size = 0;

	for_each_sg(sgt->sgl, s, sgt->nents, i) {
		if (sg_dma_address(s) != expected)
			break;
		expected = sg_dma_address(s) + sg_dma_len(s);
		size += sg_dma_len(s);
	}
	return size;
}
struct vastai_dma_buf *vastai_dma_buf_sg_get(
				struct vastai_pci_info *pci_info,
				size_t size)
{
	unsigned long contig_size;
	struct vastai_dma_buf *dm;
	dm = vastai_dma_buf_sg_create(pci_info, size, GFP_KERNEL);
	if (!dm) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "vastai_dma_buf_sg_create err\n");
		return NULL;
	}
	contig_size = get_contiguous_size(&dm->sg_table);
	if (contig_size < size) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "can't allco continue iova\n");
		vastai_udma_sg_free(pci_info, dm);
		return NULL;
	}
	dm->dma_bus_addr = sg_dma_address(dm->sg_table.sgl);
	return dm;
}
void vastai_dma_buf_sg_put(
			struct vastai_pci_info *pci_info,
			struct vastai_dma_buf *dm) {
	vastai_udma_sg_free(pci_info, dm);
	kfree(dm);
}
bool iommu_is_enable(struct vastai_pci_info *pci_info)
{
	if (pci_info->iommu_en)
		return true;
	else
		return false;
}
static void iommu_check(struct vastai_pci_info *pci_info)
{
	struct device *dev = &(pci_info->dev->dev);
	struct iommu_domain *domain =
			iommu_get_domain_for_dev(dev);

	if (domain && (domain->type & IOMMU_DOMAIN_DMA) == IOMMU_DOMAIN_DMA) {
		pci_info->max_dma_node_size = VASTAI_MAX_DMA_PAYLOAD;
		pci_info->iommu_en = true;
		pci_info->pDmaStartGetDevHostAddr = vastai_dma_sg_start_get_host_addr;
		pci_info->pDmaStartSetDescFunc    = vastai_dma_sg_set_desc_start;
	} else {
		pci_info->max_dma_node_size = VASTAI_MAX_DMA_BUF;
		pci_info->iommu_en =  false;
		pci_info->pDmaStartGetDevHostAddr = vastai_dma_start_get_host_addr;
		pci_info->pDmaStartSetDescFunc    = vastai_ioctl_dma_start_set_desc_new;
	}

	VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
			       "iommu is %s\n", pci_info->iommu_en ? "enable" :"disable");
}

static void *vastai_mempool_node_alloc(gfp_t gfp_mask, void *pool_data)
{
	struct vastai_mem_pool *vastai_pool =
		(struct vastai_mem_pool *)pool_data;
	struct vastai_dma_buf *dm = vastai_dma_buf_create(
		vastai_pool->pci_info, VASTAI_MEM_POOL_BUF_SIZE, gfp_mask);

	if (!dm)
		return NULL;

	atomic_inc(&vastai_pool->buf_count);
	return dm;
}

static void vastai_mempool_node_free(void *element, void *pool_data)
{
	struct vastai_mem_pool *vastai_pool =
		(struct vastai_mem_pool *)pool_data;
	struct vastai_dma_buf *dm = (struct vastai_dma_buf *)element;

	vastai_dma_buf_destroy(dm);
	atomic_dec(&vastai_pool->buf_count);
}

static void *vastai_vccl_mempool_node_alloc(gfp_t gfp_mask, void *pool_data)
{
	struct vastai_mem_pool *vastai_pool =
		(struct vastai_mem_pool *)pool_data;
	struct vastai_dma_buf *dm = vastai_dma_buf_create(
		vastai_pool->pci_info, VASTAI_VCCL_MEM_POOL_SIZE, gfp_mask);

	if (!dm)
		return NULL;

	VASTAI_PCI_INFO(vastai_pool->pci_info, DUMMY_DIE_ID,
		"%s: node[%d] dma_bus_addr 0x%lx, size 0x%x\n",
		__func__, vastai_pool->buf_count.counter, dm->dma_bus_addr, VASTAI_VCCL_MEM_POOL_SIZE);
	atomic_inc(&vastai_pool->buf_count);
	return dm;
}

int vastai_vccl_mempool_init(struct vastai_pci_info *pci_info)
{
	struct vastai_mem_pool *vastai_pool =
		kzalloc(sizeof(struct vastai_mem_pool), GFP_KERNEL);

	if (!vastai_pool) {
		return -EINVAL;
	}

	vastai_pool->pci_info = pci_info;
	pci_info->vccl_pool = vastai_pool;
	pci_info->vccl_pool->pool =
		mempool_create(VASTAI_VCCL_MEM_POOL_NUM,
			       vastai_vccl_mempool_node_alloc,
			       vastai_mempool_node_free, vastai_pool);
	if (!pci_info->vccl_pool->pool)
		return -ENOMEM;

	return 0;
}

void vastai_vccl_mempool_deinit(struct vastai_pci_info *pci_info)
{
	mempool_destroy(pci_info->vccl_pool->pool);
	kfree(pci_info->vccl_pool);
}

/**
 * @brief this function init a vastai_pool into pci_info. it had been been called before
 * 	user call vastai_mempool_alloc or vastai_mempool_free. vastai_mempool_deinit
 * 	function can free obj that create by this function.
 *
 * @param pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 * @return int: success return 0. other is errno
 */
int vastai_mempool_init(struct vastai_pci_info *pci_info)
{
#ifdef ENABLE_MEMPOOL
	struct vastai_mem_pool *vastai_pool =
		kzalloc(sizeof(struct vastai_mem_pool), GFP_KERNEL);

	if (!vastai_pool) {
		return -EINVAL;
	}

	vastai_pool->pci_info = pci_info;
	pci_info->vastai_pool = vastai_pool;
	pci_info->vastai_pool->pool =
		mempool_create(VASTAI_MEM_POOL_MIN_NR,
			       vastai_mempool_node_alloc,
			       vastai_mempool_node_free, vastai_pool);
	if (!pci_info->vastai_pool->pool)
		return -ENOMEM;
	sema_init(&pci_info->mempool_sem, 1);
#else
	pci_info->vastai_pool = NULL;
#endif
	return 0;
}

/**
 * @brief this function free obj that create by vastai_mempool_init.
 *
 * @param pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 */
void vastai_mempool_deinit(struct vastai_pci_info *pci_info)
{
#ifdef ENABLE_MEMPOOL
	mempool_destroy(pci_info->vastai_pool->pool);
	kfree(pci_info->vastai_pool);
#endif
}

/**
 * @brief get a vastai_dma_buf, this function will alloc from dma_alloc_coherent with size,
 * 		hence we need to save system's buf. (mempool node size always is VASTAI_MEM_POOL_BUF_SIZE,
 * 		if we only need a buf with KB, this is too waste to work).
 *
 * @param pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 * @param size: buf's size.
 * @return struct vastai_dma_buf*: success is __NOT__ NULL. free it by vastai_mempool_free.
 */
struct vastai_dma_buf *vastai_mempool_get(struct vastai_pci_info *pci_info,
					  size_t size)
{
	struct vastai_dma_buf *dm;
	int ret = 0;

	if (!pci_info) {
		return NULL;
	}
#ifdef ENABLE_MEMPOOL_EX
	dm = vastai_mempool_ex_get(pci_info, size);
#else
	dm = vastai_dma_buf_create(pci_info, size, GFP_KERNEL);
#endif
	/* alloc success */
	if (dm)
		return dm;

	/* we check vastai_pool inited, if not, we return alloc failed */
	if (!pci_info->vastai_pool) {
		return NULL;
	}

	/* we check size is less than mempool_alloc's entry size */
	if (size > VASTAI_MAX_DMA_BUF) {
		return NULL;
	}

	ret = down_interruptible(&pci_info->mempool_sem);
	if (ret != 0) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s Is user send kill signal? \n", __FUNCTION__);
		return NULL;
	}
	dm = mempool_alloc(pci_info->vastai_pool->pool, GFP_KERNEL);
	if (!dm) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s get node from vastai_pool err. count: %d\n",
			       __func__,
			       atomic_read(&pci_info->vastai_pool->buf_count));
	}
	up(&pci_info->mempool_sem);

	return dm;
}

/**
 * @brief put a vastai_dma_buf into pool that pci_info pointer to pcie_device's pool
 *
 * @param pci_info: pointer to the pcie device which was initaialized with vastai_pci_probe().
 * @param dm: what node want be put.
 *
 * always success.
 */
void vastai_mempool_put(struct vastai_pci_info *pci_info,
			struct vastai_dma_buf *dm)
{
	if(!vastai_is_find_pci_info(pci_info))
		return;

#ifdef ENABLE_MEMPOOL_EX
	if (dm->is_from_pool_ex) {
		vastai_mempool_ex_put(pci_info, dm);
		return;
	}
#endif
	/* if dm->size == VASTAI_MEM_POOL_BUF_SIZE, we may put it into dma_mem_pool, or free it,
	 * determine by mempool_api */
	if (dm->size == VASTAI_MEM_POOL_BUF_SIZE && pci_info->vastai_pool) {
		mempool_free(dm, pci_info->vastai_pool->pool);
	} else {
#ifndef ENABLE_MEMPOOL_EX
		/* __NOT__ put dm into mempool when it size != VASTAI_MEM_POOL_BUF_SIZE */
		vastai_dma_buf_destroy(dm);
#endif
	}
}

int is_vastai_mempool_rich(struct vastai_pci_info *pci_info)
{
	struct vastai_mem_pool *vastai_pool = pci_info->vastai_pool;
	return vastai_pool->pool->curr_nr >= vastai_pool->pool->min_nr;
}

int vastai_dmabuf_init(struct vastai_pci_info *pci_info)
{
	int ret;
	if ((pci_info->die_num_in_fn == 1) &&
		(pci_info->dev->vendor != PCI_VENDOR_ID_ALIBABA))
		ret = dma_set_mask_and_coherent(&(pci_info->dev->dev),
						DMA_BIT_MASK(64));
	else
		ret = dma_set_mask_and_coherent(&(pci_info->dev->dev),
						DMA_BIT_MASK(32));
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info, DUMMY_DIE_ID,
			"Failed to enable 64-bit or 32-bit DMA.  Trying to continue, but this might not work.\n");
		return ret;
	}
	iommu_check(pci_info);
	ret = vastai_mempool_init(pci_info);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "Failed to init vastai mempool errno %d\n", ret);

		return ret;
	}
	ret = vastai_vccl_mempool_init(pci_info);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "Failed to init vccl mempool errno %d\n", ret);

		return ret;
	}
	return 0;
}

void vastai_dmabuf_deinit(struct vastai_pci_info *pci_info)
{
	vastai_mempool_deinit(pci_info);
	vastai_vccl_mempool_deinit(pci_info);
}
