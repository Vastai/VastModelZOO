/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/delay.h>
#include "vastai_udma_engine.h"
#include <linux/dma-buf.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/bitops.h>
#include <linux/workqueue.h>
#include <linux/kernel.h>
#include <linux/sched/signal.h>
#include "vastai_dmabuf.h"
#include "vatools.h"
#include "vastai_utils.h"

#ifdef VATOOLS_PROFILER_ENABLE
static bool dma_time_debug_enable = 1;
#else
static bool dma_time_debug_enable = 0;
#endif
module_param(dma_time_debug_enable, bool, 0644);
MODULE_PARM_DESC(dma_time_debug_enable , "Vastai dma time statistics");

int dma_desc_credit = VASTAI_DMA_DEFAULT_CREDIT;
module_param(dma_desc_credit, int, 0644);
MODULE_PARM_DESC(dma_desc_credit, "Vastai sv100 dma desc credit, int");

int dma_desc_credit_sg = VASTAI_DMA_SUBMIT_LIMIT;
module_param(dma_desc_credit_sg, int, 0644);
MODULE_PARM_DESC(dma_desc_credit_sg, "Vastai sg100 dma desc credit, int");

#ifdef VATOOLS_PROFILER_ENABLE
extern unsigned int profiler_timeline_enable;
#endif

static inline int vastai_list_is_first(const struct list_head *list,
					const struct list_head *head)
{
	return list->prev == head;
}

static inline int vastai_get_udma_chn(struct pcie_transfer_info *trans)
{
	return GET_UDMA_CHN(trans->dir, trans->is_rc);
}
/* udma_engine:
	-. pcie dma descriptor create\fill
	-. push pcie dma descriptor to device csram
	-. handle dma complete msix
*/
u64 vastai_udma_push_desc(struct vastai_pci_info *pci_info,
			  unsigned int die_index, unsigned int dma_chn,
			  u64 sys_addr, u64 ext_addr, u32 length, u8 ctr_byte)
{
	PCIE_xd_desc temp = { 0 };
	u32 die_id = ((union die_index_data)die_index).die_id;
	u64 fifo_addr = pci_info->dies[die_id].udma_chn[dma_chn].udma_config.dma_desc_fifo_addr;
	struct vastai_fifo *fifo;
	int ret;

	int vf_id;
	int vf_bdf;

	if (pci_info->is_virtfn) {
		vf_bdf = pci_info->vf_bdf;
		vf_id = pci_info->vf_bdf & 0x7;
		switch (vf_id) {
		case VASTAI_PCI_VF_ID_1:
			/* Configure udma request id for VF1 */
			temp.ext_attr |= vf_bdf << 10;
			break;
		case VASTAI_PCI_VF_ID_2:
		case VASTAI_PCI_VF_ID_3:
		case VASTAI_PCI_VF_ID_4:
			/* VF-2/3/4 go through Die0 EP OB region */
			ext_addr |= 0xb000000000 + (vf_id - 1) * VASTAI_DIE1_BASE;
			break;
		default: break;
		}
	}

	fifo = &(pci_info->dies[die_id].udma_chn[dma_chn].dma_desc_fifo);
	temp.sys_lo_addr = ((uint32_t)(sys_addr & VASTAI_VAL_DW_MASK));
	temp.sys_hi_addr = ((uint32_t)((sys_addr >> 32) & VASTAI_VAL_DW_MASK));

	temp.ext_lo_addr = ((uint32_t)(ext_addr & VASTAI_VAL_DW_MASK));
	temp.ext_hi_addr = ((uint32_t)((ext_addr >> 32) & VASTAI_VAL_DW_MASK));

	temp.size_and_ctrl.size = (length & VASTAI_UDMA_LENGTH_MASK);
	temp.size_and_ctrl.ctrl_bits.control_bits = (ctr_byte);

	ret = vastai_fifo_push_elem(pci_info, die_index, fifo_addr, &temp,
				    fifo);/*TODO:create desc_fifo*/
	/* TODO: handle fifo is full */
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "push dma_desc is error %d\n",
			       ret);
		return U64_MAX;
	}

	return vastai_fifo_wr_get_front(fifo, fifo_addr);
}

u64 vastai_udma_push_desc_with_trans(struct vastai_pci_info *pci_info,
			  unsigned int die_index, unsigned int dma_chn, u32 trans_addr,
			  u64 sys_addr, u64 ext_addr, u32 length, u8 ctr_byte)
{
	PCIE_xd_desc temp = { 0 };
	u32 die_id = ((union die_index_data)die_index).die_id;
	u64 fifo_addr = pci_info->dies[die_id].udma_chn[dma_chn].udma_config.dma_desc_fifo_addr;
	struct vastai_fifo *fifo;
	int ret;

	int vf_id;
	int vf_bdf;

	if (pci_info->is_virtfn) {
		vf_bdf = pci_info->vf_bdf;
		vf_id = pci_info->vf_bdf & 0x7;
		switch (vf_id) {
		case VASTAI_PCI_VF_ID_1:
			/* Configure udma request id for VF1 */
			temp.ext_attr |= vf_bdf << 10;
			break;
		case VASTAI_PCI_VF_ID_2:
		case VASTAI_PCI_VF_ID_3:
		case VASTAI_PCI_VF_ID_4:
			/* VF-2/3/4 go through Die0 EP OB region */
			ext_addr |= 0xb000000000 + (vf_id - 1) * VASTAI_DIE1_BASE;
			break;
		default: break;
		}
	}

	fifo = &(pci_info->dies[die_id].udma_chn[dma_chn].dma_desc_fifo);
	temp.sys_lo_addr = ((uint32_t)(sys_addr & VASTAI_VAL_DW_MASK));
	temp.sys_hi_addr = ((uint32_t)((sys_addr >> 32) & VASTAI_VAL_DW_MASK));

	temp.ext_lo_addr = ((uint32_t)(ext_addr & VASTAI_VAL_DW_MASK));
	temp.ext_hi_addr = ((uint32_t)((ext_addr >> 32) & VASTAI_VAL_DW_MASK));

	temp.size_and_ctrl.size = (length & VASTAI_UDMA_LENGTH_MASK);
	temp.size_and_ctrl.ctrl_bits.control_bits = (ctr_byte);

	temp.trans_info_addr = trans_addr;

	/*TODO:create desc_fifo*/
	ret = vastai_fifo_push_elem(pci_info, die_index, fifo_addr, &temp,fifo);
	/* TODO: handle fifo is full */
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "push dma_desc is error %d\n", ret);
		return U64_MAX;
	}

	return vastai_fifo_wr_get_front(fifo, fifo_addr);
}


void vastai_set_desc_link(struct vastai_pci_info *pci_info,
			  unsigned int die_index, u64 *desc_tab, int num)
{
	int i;
	int ret;
	u32 die_id = ((union die_index_data)die_index).die_id;

	/* set desc_tab list */
	for (i = 0; i < num - 1; i++) {
		u32 next_desc = desc_tab[i + 1] & VASTAI_VAL_DW_MASK;
		u64 next_desc_hi = (desc_tab[i + 1] >> 32) & VASTAI_VAL_DW_MASK;
		u32 size_and_ctrl;
		ret = vastai_pci_mem_write(pci_info, die_index,
					   desc_tab[i] +
						   offsetof(PCIE_xd_desc, next),
					   &next_desc, sizeof(u32));
		if (ret)
			VASTAI_PCI_ERR(pci_info, die_id,
				       "%s write low error %d\n", __FUNCTION__,
				       ret);
		ret = vastai_pci_mem_write(pci_info, die_index,
					   desc_tab[i] + offsetof(PCIE_xd_desc,
								  next_hi_addr),
					   &next_desc_hi, sizeof(u32));
		if (ret)
			VASTAI_PCI_ERR(pci_info, die_id,
				       "%s write low error %d\n", __FUNCTION__,
				       ret);
		ret = vastai_pci_mem_read(
			pci_info, die_index,
			desc_tab[i] + offsetof(PCIE_xd_desc, size_and_ctrl),
			&size_and_ctrl, sizeof(size_and_ctrl));
		if (ret)
			VASTAI_PCI_ERR(pci_info, die_id,
				       "%s read size_ctrl error %d\n",
				       __FUNCTION__, ret);
		size_and_ctrl |= (BIT(5) << 24); /* set continue */
		ret = vastai_pci_mem_write(
			pci_info, die_index,
			desc_tab[i] + offsetof(PCIE_xd_desc, size_and_ctrl),
			&size_and_ctrl, sizeof(size_and_ctrl));
		if (ret)
			VASTAI_PCI_ERR(pci_info, die_id,
				       "%s write size_ctrl error %d\n",
				       __FUNCTION__, ret);
	}
}

/* for tirgger dma, we need fill transfer info and fill msg_queue */
/* TODO: refactor relastionship between buf_desc and pcie_transfer_info */
static u64 vastai_pci_push_trans_info(struct vastai_pci_info *pci_info,
				      unsigned int die_index,
				      struct pcie_transfer_info *trans,
				      u64 *desc)
{
	u64 trans_cur_addr_u64 = 0;
	struct vastai_fifo *fifo;
	u64 fifo_addr = 0;
	int ret;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);
	int udma_chn = vastai_get_udma_chn(trans);
	struct vastai_sv100_die *die = &(pci_info->dies[die_id]);

	fifo = &(die->udma_chn[udma_chn].trans_info_fifo);
	fifo_addr = die->udma_chn[udma_chn].udma_config.trans_info_fifo_addr;

	ret = vastai_fifo_push_elem_local_fifo(pci_info, die_index, fifo_addr+(u32)offsetof(struct vastai_fifo, buf),
						fifo, trans);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id,
			       "push trans_info is error %d\n", ret);
		return U64_MAX;
	}
	/* set last desc point to this trans_cur_addr_u32 */
	trans_cur_addr_u64 = vastai_fifo_wr_get_front(fifo, fifo_addr);
#if 0
	trans_cur_addr_u32 = trans_cur_addr_u64 & UINT_MAX;
	vastai_pci_mem_write(pci_info, die_index,
			     desc[trans->num] +
				     offsetof(PCIE_xd_desc, trans_info_addr),
			     &trans_cur_addr_u32, sizeof(u32));
#endif
	return trans_cur_addr_u64;
}

static struct vastai_pci_info *die_2_pci_info(struct vastai_sv100_die *die)
{
	return die->pci_info;
}

#define work_struct_2_die(work) (container_of(work, struct vastai_sv100_die, dma_done))
static void dma_done_work_func(struct work_struct *work)
{
	struct vastai_sv100_die *die =	work_struct_2_die(work);
	struct vastai_pci_info *pci_info = die_2_pci_info(die);
	struct vastai_fifo fifo_cache = {0};
	struct vastai_udma_chn *chn;
	u32 trans_info_addr = 0;
	u32 die_index = die->die_index;
	u32 die_id = vastai_pci_get_die_id(pci_info, die_index);
	u64 msg0_addr = MSG_SMCUQ0_TO_PCIE;
	int ret = 0;

	VASTAI_PCI_DBG(pci_info, die_id, "%s %d\n", __func__, __LINE__);

	if (!pci_info || !die)
			return;

	if (pci_info->is_virtfn)
			msg0_addr += VASTAI_PCIE_SMCU_0_VF_OFFSET;

	mutex_lock(&die->done_lock);
	while (!vastai_fifo_pop_elem(pci_info, die_index, msg0_addr,
                             &trans_info_addr, &fifo_cache, NORMAL_FIFO)) {
		struct pcie_transfer_info trans;
		u64 cur_addr;
		u32 dma_chn;
		u64 fifo_addr;
		struct vastai_fifo *fifo;
		u32 trans_object_len = dma_time_debug_enable ?
					sizeof(trans): sizeof(trans) - 8;

		vastai_pci_mem_read(pci_info, die_index, trans_info_addr, &trans,
				    trans_object_len);
		if (trans.dir == 0xff || trans.is_rc == 0xff || trans.type == 0xff ||
			trans.chn == 0xffffffff || trans.pcie_config_addr == 0xffffffff) {
			VASTAI_PCI_ERR(
				pci_info, die_id,
				"read transfer info error\n");
			mutex_unlock(&die->done_lock);
			return;
		}
		dma_chn = GET_UDMA_CHN(trans.dir, trans.is_rc);
		fifo_addr = die->udma_chn[dma_chn].udma_config.trans_info_fifo_addr;

		fifo = &(pci_info->dies[die_id].udma_chn[dma_chn].trans_info_fifo);

		ret = vastai_fifo_pop_elem_local_fifo(pci_info, die_index,
							0, fifo,
							NULL);
		if (ret) {
			VASTAI_PCI_ERR(
				pci_info, die_id,
				"pop transfer info fifo err %d\n",
				ret);
			mutex_unlock(&die->done_lock);
			return;
		}
		cur_addr = vastai_fifo_rd_get_front(fifo, fifo_addr);

		if (cur_addr != trans_info_addr) {
			VASTAI_PCI_ERR(
				pci_info, die_id,
				"ERROR transfer info addr, expect 0x%llx get 0x%x\n",
				cur_addr, trans_info_addr);
			mutex_unlock(&die->done_lock);
			return;
		}
		trans.data_struct->time_of_dma_run = trans.time_of_dma_run;
		trans.data_struct->time_of_dma_finish = trans.time_of_dma_finish;

		if (trans.failed) {
			trans.data_struct->status |= UDMA_DATA_INVALID;
			trans.data_struct->retry_cnt++;
			VASTAI_PCI_ERR(pci_info, die_id, "dma trans failed!\n");
		} else trans.data_struct->status = 0;

		chn = &(pci_info->dies[die_id].udma_chn[dma_chn]);
		atomic_dec(&chn->ongoing_count);
		complete(&(trans.data_struct->dma_comp));
		VASTAI_PCI_DBG(pci_info, die_id, "%s get data_struct 0x%p\n",
			       __func__, trans.data_struct);
	}
	mutex_unlock(&die->done_lock);

	return;
}


static int inline vastai_record_vdmcu_id(struct vastai_pci_info *pci_info,
					  int die_index,
					  struct data_struct *data)
{
	u64 sys_addr;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);
	int vdmcu_id = 0xff;

	switch (data->trans.chn) {
		case 0x1000000:
			vdmcu_id = 0;
			break;
		case 0x2000000:
			vdmcu_id = 1;
			break;
		case 0x4000000:
			vdmcu_id = 2;
			break;
	};

	if (vdmcu_id < 0 || vdmcu_id >= 3)
		return 0;

	sys_addr = data->trans.vdmcu_dma_msg_dst;
	if (pci_info->dies[die_id].vdmcu_pre_addr_table[vdmcu_id] == sys_addr) {
		VASTAI_PCI_INFO(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s vdmcu:%d get same addr=0x%llx\n",
			       __FUNCTION__, vdmcu_id, sys_addr);
		return -EBUSY;
	} else {
		pci_info->dies[die_id].vdmcu_pre_addr_table[vdmcu_id] = sys_addr;
	}
	return 0;
}

static int vastai_pci_start_tx_transfer_info(struct vastai_pci_info *pci_info,
	unsigned int die_index, struct data_struct *data, bool is_retry)
{
	struct pcie_transfer_info *trans = &data->trans;
	struct buf_desc *buf_desc = NULL;
	u32 num = 0;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);
	u64 *desc;
	u64 trans_cur_addr_u64 = 0;
	int ret;
	u32 msgq_id;

	if (!is_retry) {
		ret = vastai_record_vdmcu_id(pci_info, die_index, data);
		if (ret)
			return ret;
	}

	/* fill transfer info */
	trans->is_vf = (pci_info->is_virtfn) ? 1 : 0;
	trans->data_struct = data;
	VASTAI_PCI_DBG(pci_info, die_id,
		       "%s, type=%d, chn=0x%x, dir=%d, num=%d\n", __func__,
		       trans->type, trans->chn, trans->dir, trans->num);

	desc = kmalloc(sizeof(u64) * (trans->num + 1), GFP_KERNEL);
	if (!desc) {
		VASTAI_PCI_ERR(pci_info, die_id,
			       "%s kmalloc is failed! need buf size is 0x%lx\n",
			       __FUNCTION__, sizeof(u64) * trans->num);
		return -EINVAL;
	}

	trans_cur_addr_u64 = vastai_pci_push_trans_info(pci_info, die_index, trans, desc);
	if (trans_cur_addr_u64 == U64_MAX) {
		ret =  -EIO;
		goto ERROR;
	}

	list_for_each_entry (buf_desc, &(data->head), node) {
		u64 sys_addr;
		u64 ext_addr;
		u8 ctrl_byte = 0;

		sys_addr = buf_desc->data.data_desc.sys_addr;
		ext_addr = buf_desc->data.data_desc.ext_addr;
		if (die_id != 0 && !trans->is_rc)
			ext_addr |= 0xb000000000;
		if (list_is_last(&(buf_desc->node), &(data->head)))
			ctrl_byte |= BIT(0);

		desc[num + 1] = vastai_udma_push_desc_with_trans(
			pci_info, die_index,
			vastai_get_udma_chn(trans), (u32)trans_cur_addr_u64,
			sys_addr, ext_addr, buf_desc->data.data_desc.len,
			ctrl_byte);
		if (desc[num + 1] == U64_MAX) {
			ret =  -EIO;
			goto ERROR;
		}
		VASTAI_PCI_DBG(
			pci_info, die_id,
			"%s, len=%d, sys=0x%llx, ext=0x%llx, desc[0x%llx]\n",
			__func__, buf_desc->data.data_desc.len,
			buf_desc->data.data_desc.sys_addr,
			buf_desc->data.data_desc.ext_addr, desc[1]);
		if (++num > trans->num) /* this is a bug! */ {
			VASTAI_PCI_ERR(pci_info, die_id,
				       "cur num:%d not equal data_num %d\n",
				       num, data->trans.num);
			ret = -EINVAL;
			goto ERROR;
		}
	}
	vastai_set_desc_link(pci_info, die_index, desc + 1, trans->num);/* set desc_tab list */
#if 0
	trans->pcie_config_addr = desc[1];
#else
	vastai_pci_mem_write(pci_info, die_index, trans_cur_addr_u64 +
				offsetof(struct pcie_transfer_info, pcie_config_addr),
				&desc[1], sizeof(u32));
#endif

#if 0
	/* set append list */
	if (pci_info->dies[die_id].dma_last_desc[trans.dir]) {
		desc[0] = pci_info->dies[die_id].dma_last_desc[trans.dir];
		vastai_set_desc_link(pci_info, die_index, desc, 2);
	}
	pci_info->dies[die_id].dma_last_desc[trans.dir] = desc[data->num];
#endif

	data->time_of_host_trigger_dma = vastai_get_host_time_ns();

	msgq_id = vastai_get_msgq_id(pci_info, MSGQ_DMA);
	vastai_pci_vmsgq_wr(&(pci_info->dies[die_id].vmsgq[msgq_id]),
						(u32 *)&trans_cur_addr_u64, sizeof(u32));

	kfree(desc);
	return 0;
ERROR:
	kfree(desc);
	return ret;
}

#ifdef VATOOLS_PROFILER_ENABLE
static void vastai_get_dma_transinfo(void *priv, u32 die_index,
				     struct data_struct *data,
				     profiler_dma_checkpoint_t *dma_profiler)
{
	struct buf_desc *buf_desc = NULL;

	dma_profiler->pid = data->pid;
	dma_profiler->dev_id = vastai_pci_info_get_dev_id(priv);
	dma_profiler->die_id = vastai_pci_get_die_id(priv, die_index);
	dma_profiler->die_index = die_index;
	dma_profiler->time_of_driver_notify_host_dma_done =
		vastai_get_host_time_ns();
	dma_profiler->time_of_host_trigger_dma = data->time_of_host_trigger_dma;
	dma_profiler->time_of_dma_run = data->time_of_dma_run;
	dma_profiler->time_of_dma_finish = data->time_of_dma_finish;
	dma_profiler->dma_dir = data->trans.dir;

	list_for_each_entry (buf_desc, &(data->head), node) {
		if (vastai_list_is_first(&(buf_desc->node), &(data->head))) {
			dma_profiler->dma_axi_addr =
				buf_desc->data.data_desc.sys_addr;
		}
		dma_profiler->dma_data_size += buf_desc->data.data_desc.len;
	}

	return;
}
#endif

static void vastai_print_get_signal_type(struct vastai_pci_info *pci_info,
					 unsigned int die_index)
{
	int i;
	for (i = 1; i < SIGRTMAX; i++) {
		if (sigismember(&current->pending.signal, i))
				VASTAI_PCI_INFO(pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"receive signal:%d\n",i);
	}
}
static int vastai_check_ddr_limit(struct vastai_pci_info *pcie_dev,
							 int die_index,
							 u64 addr,
							 u32 len)
{
	 if (addr >= pcie_dev->ddr_min_addr &&
		 (addr + len) <= pcie_dev->ddr_max_addr )
		 return 0;
	 else if (addr >= CSRAM_BASE_ADDR &&
		 (addr + len) <= CSRAM_BASE_ADDR + SZ_1M)
		 return 0;
	 else {
		 VASTAI_PCI_ERR(pcie_dev,
				vastai_pci_get_die_id(pcie_dev, die_index),
				"%s device addr:0x%llx,len:0x%x is invalid\n",
				__FUNCTION__, addr, len);
		 return -EINVAL;
	 }
}

static int vastai_pci_transfer_data_sync(struct vastai_pci_info *pci_info,
					 unsigned int die_index,
					 struct data_struct *data)
{
	bool retry = false;
	int ret = 0;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);
	struct vastai_sv100_die *die = &(pci_info->dies[die_id]);
	struct vastai_udma_chn* chn;
	struct buf_desc *buf_desc = NULL;
#ifdef VATOOLS_PROFILER_ENABLE
	profiler_dma_checkpoint_t dma_profiler;
#endif

	if (list_empty(&data->head)) {
		return -EINVAL;
	}

	list_for_each_entry (buf_desc, &(data->head), node) {
		u64 dev_addr;
		u32 lenth;

		dev_addr = buf_desc->data.data_desc.sys_addr;
		lenth = buf_desc->data.data_desc.len;

		if ((ret = vastai_check_ddr_limit(pci_info,
					die_index,
					dev_addr,
					lenth)) != 0) {
			return ret;
		}

	}

	if (pci_info->disable == true)
		return -EIO;

	init_completion(&data->dma_comp);
#ifdef VATOOLS_PROFILER_ENABLE
	memset(&dma_profiler, 0, sizeof(profiler_dma_checkpoint_t));
	dma_profiler.time_of_driver_recv_dma_req = vastai_get_host_time_ns();
#endif
_DMA_RETRY:
	chn = &die->udma_chn[GET_UDMA_CHN(data->trans.dir, data->trans.is_rc)];
	mutex_lock(&chn->trans_mutex);
	atomic_inc(&chn->ongoing_count);
	ret = vastai_pci_start_tx_transfer_info(pci_info, die_index, data, retry);
	mutex_unlock(&chn->trans_mutex);
	if (ret) {
		atomic_dec(&chn->ongoing_count);
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s start transfer data failed %d\n",
			       __FUNCTION__,
			       ret);
		return ret;
	}

	ret = wait_for_completion_interruptible(&data->dma_comp);
	if (ret) {
		unsigned long timeout = jiffies + 1*HZ;

		vastai_print_get_signal_type(pci_info, die_index);
		while (!completion_done(&data->dma_comp)) {
			msleep(1);
			if (time_after(jiffies, timeout))
				break;
		}
		if (!completion_done(&data->dma_comp)) {
			atomic_dec(&chn->ongoing_count);
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info, die_index),
				       "%s wait_for_completion error %d\n",
				       __FUNCTION__, ret);
		}
		else
			ret = 0;
	}
	if(atomic_read(&pci_info->pci_state) == VASTAI_HOTP_STATE) {
		ret = -512;
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s pcie hot plug\n",
			       __FUNCTION__);
	}
	if (data->status) {
		if (data->retry_cnt >= 3) {
			VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s dma failed 3 times\n", __FUNCTION__);
		} else {
			VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s dma_trans retried %d times\n", __FUNCTION__, data->retry_cnt);
			retry = true;
			goto _DMA_RETRY;
		}
	}
#ifdef VATOOLS_PROFILER_ENABLE
	if (dma_time_debug_enable && profiler_timeline_enable) {
		/*record dma profiler info*/
		vastai_get_dma_transinfo(pci_info, die_index, data, &dma_profiler);
		vatools_profiler_dma_checkpoint(&dma_profiler);
	}
#endif
	return ret;
}

int vastai_pci_data_movement(void *pci_info, int die_index, u64 local_addr,
			     u64 remote_addr, u32 len, bool is_local_2_remote)
{
	struct data_struct dma_data_struct = { 0 };
	struct buf_desc desc;
	int ret = 0;

	memset(&desc, 0, sizeof(desc));
	INIT_LIST_HEAD(&dma_data_struct.head);

	desc.data.data_desc.sys_addr = local_addr;
	desc.data.data_desc.ext_addr = remote_addr;
	desc.data.data_desc.len = len;

	list_add_tail(&(desc.node), &(dma_data_struct.head));

	dma_data_struct.trans.num = 1;
	dma_data_struct.trans.chn = 0;
	dma_data_struct.trans.dir = is_local_2_remote;
	dma_data_struct.trans.is_rc = 1;

	ret = vastai_pci_transfer_data_sync(pci_info, die_index,
					    &dma_data_struct);

	return ret;
}

struct buf_desc_buf {
	struct buf_desc desc;
	struct vastai_dma_buf *buf;
};

static int fill_dma_buf(void *pcie_dev, struct buf_desc_buf *dma_buf,
			const struct vastai_dmadesc *desc)
{
	if (!desc->is_src_dma_addr) {
		if (iommu_is_enable(pcie_dev)) {
			dma_buf->buf = vastai_dma_buf_sg_get(pcie_dev,
						desc->dma_lenth);
		} else {
			dma_buf->buf = vastai_mempool_get(pcie_dev,
						desc->dma_lenth);
		}

		if (!dma_buf->buf) {
			VASTAI_PCI_ERR(pcie_dev, DUMMY_DIE_ID,
				       "%s udma alloc failed\n", __FUNCTION__);
			return -ENOMEM;
		}
		dma_buf->desc.data.data_desc.ext_addr =
			dma_buf->buf->dma_bus_addr;
	} else {
		dma_buf->desc.data.data_desc.ext_addr =
			desc->host_addr.dma_addr;
	}

	memcpy(dma_buf->desc.data.data_desc.user_data, desc->user_prive,
	       sizeof(u32) * 4);
	dma_buf->desc.data.data_desc.len = desc->dma_lenth;

	dma_buf->desc.data.data_desc.sys_addr = desc->dev_addr;
	return 0;
}

static void clean_dma_buf(void *pcie_dev, struct buf_desc_buf *dma_buf,
			  u32 is_src_dma_addr)
{
	if (!is_src_dma_addr) {
		if (iommu_is_enable(pcie_dev))
			vastai_dma_buf_sg_put(pcie_dev, dma_buf->buf);
		else
			vastai_mempool_put(pcie_dev, dma_buf->buf);
	}
	memset(dma_buf, 0, sizeof(struct buf_desc_buf));
}

int vastai_pci_dma_transfer_sync(struct vastai_pci_info *pci_info, int die_index,
				 union core_bitmap core_id,
				 struct vastai_dmadesc desc[], int desc_num, int pid)
{
	return vastai_pci_dma_transfer_sync_pid(pci_info, die_index, core_id,
						desc, desc_num, pid);
}

int vastai_dma_get_credit(struct vastai_pci_info *pci_info,
					int expect_num)
{
	if (!(pci_info->addr->is_vastai_mempool_rich(pci_info)))
		return 1;

	return min(*(ADDR(pci_info, dma_desc_credit)), expect_num);
}

int vastai_pci_dma_common_mem_copy(bool is_host_to_dev, struct vastai_dmadesc *cur_desc,
						  struct vastai_dma_buf *buf,
						  void *pci_info,
						  int die_index)
{
	int ret = 0;

	if (!(cur_desc->is_src_dma_addr)) {
		if (cur_desc->is_src_not_user_mem) {
			if(is_host_to_dev)
				memcpy(buf->vir, cur_desc->host_addr.vir_addr, cur_desc->dma_lenth);
			else
				memcpy(cur_desc->host_addr.vir_addr, buf->vir, cur_desc->dma_lenth);
		} else {
			if(is_host_to_dev)
				ret = copy_from_user_compact(buf->vir, cur_desc->host_addr.vir_addr, cur_desc->dma_lenth);
			else
				ret = copy_to_user_compact(cur_desc->host_addr.vir_addr, buf->vir, cur_desc->dma_lenth);
			if (ret) {
				VASTAI_PCI_ERR(
					pci_info,
					vastai_pci_get_die_id(
						pci_info, die_index),
					"%s copy %s user failed dma[0x%p] user[0x%p]\n",
					__FUNCTION__,
					is_host_to_dev ? "from" : "to",
					buf->vir,
					(void *)cur_desc->host_addr.vir_addr);
				return -EFAULT;
			}
		}
	}

	return ret;
}

int vastai_pci_dma_trans_input_param_check(struct vastai_pci_info *pci_info, int die_index,
							  struct vastai_dmadesc desc[], int total_desc_num)
{
	int i = 0;

	if (total_desc_num < 1) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s desc_num is 0\n", __FUNCTION__);
		return -EFAULT;
	}

	/* check list is vaild */
	for (i = 0; i < total_desc_num; i++) {
		if (!IS_ALIGNED((u64)desc[i].dev_addr, SZ_4K)) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info,
							     die_index),
				       "%s device addr 0x%llx is not 0x%x align",
				       __FUNCTION__, (u64)desc[i].dev_addr, SZ_4K);
			return -EFAULT;
		}
		if (desc[i].is_src_dma_addr &&
				!IS_ALIGNED(desc[i].host_addr.dma_addr, SZ_4K)) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info,
							     die_index),
				       "%s host addr 0x%llx is not 0x%x align",
				       __FUNCTION__, (u64)desc[i].host_addr.dma_addr, SZ_4K);
			return -EFAULT;
		}
	}

	return 0;
}

int vastai_pci_dma_transfer_sync_pid(struct vastai_pci_info *pci_info, int die_index,
				     union core_bitmap core_id,
				     struct vastai_dmadesc desc[], int total_desc_num,
				     int pid)
{
	struct data_struct *dma_data_struct = NULL;
	int i = 0;
	int ret = 0;
	bool host_to_dev;
	struct buf_desc_buf *dma_buf = NULL;
	struct vastai_dmadesc *cur_desc = NULL;
	int dma_transfer_total = 0;
	int cur_num = 0;
	int die_id = vastai_pci_get_die_id(pci_info, die_index);
	struct vastai_sv100_die *die = &(pci_info->dies[die_id]);
	int clean_start, clean_end;

	if (!total_desc_num) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info,
						     die_index),
			       "%s total_desc_num:%d is invalid \n",
			       __FUNCTION__, total_desc_num);
		return -EINVAL;
	}
	host_to_dev = desc[0].is_host_to_dev;
	ret = vastai_pci_dma_trans_input_param_check(pci_info, die_index, desc, total_desc_num);
	if(ret)
		return ret;

	ret = down_interruptible(&die->credit_sem);
	if (ret != 0) {
		return ret;
	}

	while(total_desc_num > dma_transfer_total) {
		cur_num = vastai_dma_get_credit(pci_info, total_desc_num - dma_transfer_total);/*TODO:Up to 8 at a time*/

		dma_data_struct = kmem_cache_zalloc(die->data_struct_slab, GFP_KERNEL);
		if (!dma_data_struct) {
			ret = -ENOMEM;
			goto UP_DMA_SEM;
		}
		INIT_LIST_HEAD(&dma_data_struct->head);

		dma_buf = kvmalloc(sizeof(*dma_buf) * cur_num, GFP_KERNEL);
		if (!dma_buf) {
			ret = -ENOMEM;
			goto CLEAN_DATA_STRUCT;
		}
		cur_desc = &desc[dma_transfer_total];

		for (i = 0; i < cur_num; i++) {/*TODO：Start filling dma_desc*/
			ret = fill_dma_buf(pci_info, &(dma_buf[i]), &(cur_desc[i]));
			if (ret) {
				clean_start = 0;
				clean_end = i;
				goto CLEAN_DMA_BUF;
			}

			if (host_to_dev){
				ret = vastai_pci_dma_common_mem_copy(host_to_dev,
					&(cur_desc[i]), dma_buf[i].buf, pci_info, die_index);
				if(ret) {
					clean_start = 0;
					clean_end = i + 1;
					goto CLEAN_DMA_BUF;
				}
			}

			list_add_tail(&(dma_buf[i].desc.node), &(dma_data_struct->head));
		}

		dma_data_struct->trans.num = cur_num;
		if (total_desc_num <= (dma_transfer_total+cur_num)) {
			dma_data_struct->trans.chn = core_id.val;
			dma_data_struct->trans.vdmcu_dma_msg_len = desc[0].dma_lenth;
			dma_data_struct->trans.vdmcu_dma_msg_dst = desc[0].dev_addr;
		}
		dma_data_struct->trans.dir = host_to_dev ? 0 : 1;
		dma_data_struct->trans.is_rc = 0;
		dma_data_struct->pid = pid;
		ret = vastai_pci_transfer_data_sync(pci_info, die_index,
						    dma_data_struct);
		if (ret && ret != -EBUSY) {
			clean_start = 0;
			clean_end = cur_num;
			goto CLEAN_DMA_BUF;
		}

		for (i = 0; i < cur_num; i++) {
			if (!host_to_dev){
				ret = vastai_pci_dma_common_mem_copy(host_to_dev,
					&(cur_desc[i]), dma_buf[i].buf, pci_info, die_index);
				if(ret) {
					clean_start = i;
					clean_end = cur_num;
					goto CLEAN_DMA_BUF;
				}
			}
			clean_dma_buf(pci_info, &(dma_buf[i]),
				      cur_desc->is_src_dma_addr);
		}

		kvfree(dma_buf);
		kmem_cache_free(die->data_struct_slab, dma_data_struct);
		dma_transfer_total += cur_num;
	}

	up(&die->credit_sem);
	return ret;
CLEAN_DMA_BUF:
	for (i = clean_start; i < clean_end; i++) {
		clean_dma_buf(pci_info, &(dma_buf[i]),
			      cur_desc->is_src_dma_addr);
	}
	kvfree(dma_buf);
CLEAN_DATA_STRUCT:
	kmem_cache_free(die->data_struct_slab, dma_data_struct);
UP_DMA_SEM:
	up(&die->credit_sem);
	return ret;
}
static dma_addr_t sg_addr(struct vastai_pci_info *pci_info,
				struct scatterlist *sg)
{
	return iommu_is_enable(pci_info) ? sg_dma_address(sg)
					: sg_phys(sg);

}

int vastai_dma_set_desc_memset(struct vastai_dmadesc* desc,
						dma_addr_t dma_bus_addr,
						int i,
						u64 axi_addr,
						u32 done_size,
						u32 is_host_to_dev,
						u32 is_src_not_user_mem,
						u32 is_src_dma_addr,
						u32 size)
{
	int ret = 0;

	desc[i].is_host_to_dev = is_host_to_dev;
	desc[i].is_src_not_user_mem = is_src_not_user_mem;
	desc[i].is_src_dma_addr = is_src_dma_addr;
	desc[i].dev_addr = axi_addr+ done_size;

	if(size < VASTAI_MAX_MEMSET_BUF){
		desc[i].dma_lenth = size;
	} else {
		desc[i].dma_lenth = VASTAI_MAX_MEMSET_BUF;
	}

	desc[i].host_addr.dma_addr = dma_bus_addr;
	return ret;
}

int vastai_dma_sg_set_desc(struct vastai_dmadesc* desc,
					u64 dma_len,
					u64 host_addr,
					u64 axi_addr,
					u32 is_host_to_dev,
					u32 is_src_not_user_mem,
					u32 is_src_dma_addr)
{
	int ret=0;

	desc->is_host_to_dev      = is_host_to_dev;
	desc->is_src_not_user_mem = is_src_not_user_mem;
	desc->is_src_dma_addr     = is_src_dma_addr;
	desc->dev_addr            = axi_addr;
	desc->dma_lenth           = dma_len;
	desc->host_addr.dma_addr  = host_addr;

	return ret;
}

int vastai_pci_dma_transfer_memset(void *pci_info,
			int die_index,
			union core_bitmap core_id,
			dma_addr_t dma_bus_addr,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size)
{
	u32 done_size = 0;
	int ret = 0;
	int i = 0;
	struct vastai_dmadesc *desc;
	u32 entry_count = vast_div_round_up(size, VASTAI_MAX_MEMSET_BUF);

	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
					GFP_KERNEL);
	while (done_size < size) {
		if (ret)
			break;
		ret = vastai_dma_set_desc_memset(desc,
						dma_bus_addr,
						i,
						axi_addr,
						done_size,
						is_host_to_dev,
						is_src_not_user_mem,
						is_src_dma_addr,
						size);

		if (ret)
			break;
		++i;

		if(size < VASTAI_MAX_MEMSET_BUF) {
			done_size += size;
		} else {
			done_size += VASTAI_MAX_MEMSET_BUF;
		}
	}
	ret = vastai_pci_dma_transfer_sync(pci_info, die_index,
						core_id,
						desc, i, -1);
	kvfree(desc);
	return ret;
}

int vastai_pci_dma_transfer_sg(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			struct vastai_dma_buf *dm,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size)
{
	u32 temp_size;
	u32 done_size = 0;
	int ret = 0;
	int i=0;
	struct vastai_dmadesc *desc;
	u64 host_addr = 0;
	u32 entry_count;
	struct scatterlist *sg;
	u64 sgl_len;
	dma_addr_t sgl_addr;

	if (iommu_is_enable(pci_info)) {
		entry_count = vast_div_round_up(size, pci_info->max_dma_node_size);
		/*...................Optimize desc to become an array and record its size..............*/
		host_addr = sg_addr(pci_info, dm->sg_table.sgl);

		desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
						GFP_KERNEL);
		while (done_size < size) {
			temp_size = min((u32)pci_info->max_dma_node_size,
					size - done_size);

			ret=vastai_dma_sg_set_desc(&desc[i],temp_size,
							host_addr + done_size,
							axi_addr + done_size,
							is_host_to_dev,
							is_src_not_user_mem,
							is_src_dma_addr);

			if (ret)
				break;
			++i;
			done_size += temp_size;
		}
	} else {
		/* use dma link list mode */
		entry_count = dm->sg_table.nents;
		desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count, GFP_KERNEL);
		if (!desc) {
			VASTAI_PCI_ERR(
				pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"kvmalloc failed: (%d)\n",
				entry_count);
			return -ENOMEM;
		}

		/* fill desc list */
		i = 0;
		for_each_sg(dm->sg_table.sgl, sg, dm->sg_table.nents, i) {
			sgl_addr = sg_phys(sg);
			sgl_len = sg->length;
			if (sgl_len == 0)
				break;
			vastai_dma_sg_set_desc(&desc[i], sgl_len,
							sgl_addr,
							axi_addr + done_size,
							is_host_to_dev,
							is_src_not_user_mem,
							is_src_dma_addr);
			VASTAI_PCI_DBG(
				pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"sg(%d) ext_addr=0x%llx, len=0x%llx, done_size=%u, axi addr=0x%llx\n",
				i, sgl_addr, sgl_len, done_size, axi_addr + done_size);
			done_size += sgl_len;
		}
	}
	ret = vastai_pci_dma_transfer_sync(pci_info, die_index,
						core_id,
						desc, i, -1);
	kvfree(desc);

	return ret;
}

/**
 * vastai_sg_alloc_table_from_pages - Allocate and initialize an sg table from
 *			         an array of pages(from kernel v4.15.0 src code)
 * @sgt:	 The sg table header to use
 * @pages:	 Pointer to an array of page pointers
 * @n_pages:	 Number of pages in the pages array
 * @offset:      Offset from start of the first page to the start of a buffer
 * @size:        Number of valid bytes in the buffer (after offset)
 * @max_segment: Maximum size of a scatterlist node in bytes (page aligned)
 * @gfp_mask:	 GFP allocation mask
 *
 *  Description:
 *    Allocate and initialize an sg table from a list of pages. Contiguous
 *    ranges of the pages are squashed into a single scatterlist node up to the
 *    maximum size specified in @max_segment. An user may provide an offset at a
 *    start and a size of valid data in a buffer specified by the page array.
 *    The returned sg table is released by sg_free_table.
 *
 * Returns:
 *   0 on success, negative error on failure
 */
int vastai_sg_alloc_table_from_pages(struct sg_table *sgt, struct page **pages,
				unsigned int n_pages, unsigned int offset,
				unsigned long size, unsigned int max_segment,
				gfp_t gfp_mask)
{
	unsigned int chunks, cur_page, seg_len, i;
	int ret;
	struct scatterlist *s;

	if (WARN_ON(!max_segment || offset_in_page(max_segment)))
		return -EINVAL;

	/* compute number of contiguous chunks */
	chunks = 1;
	seg_len = 0;
	for (i = 1; i < n_pages; i++) {
		seg_len += PAGE_SIZE;
		if (seg_len >= max_segment ||
		    page_to_pfn(pages[i]) != page_to_pfn(pages[i - 1]) + 1) {
			chunks++;
			seg_len = 0;
		}
	}

	ret = sg_alloc_table(sgt, chunks, gfp_mask);
	if (unlikely(ret))
		return ret;

	/* merging chunks and putting them into the scatterlist */
	cur_page = 0;
	for_each_sg(sgt->sgl, s, sgt->orig_nents, i) {
		unsigned int j, chunk_size;

		/* look for the end of the current chunk */
		seg_len = 0;
		for (j = cur_page + 1; j < n_pages; j++) {
			seg_len += PAGE_SIZE;
			if (seg_len >= max_segment ||
			    page_to_pfn(pages[j]) !=
			    page_to_pfn(pages[j - 1]) + 1)
				break;
		}

		chunk_size = ((j - cur_page) << PAGE_SHIFT) - offset;
		sg_set_page(s, pages[cur_page],
			    min_t(unsigned long, size, chunk_size), offset);
		size -= chunk_size;
		offset = 0;
		cur_page = j;
	}

	return 0;
}

int vastai_dma_sg_trans_get_host_addr(struct vastai_pci_info *pci_info, int i,
							struct dma_buf *dmabuf, u64 *host_addr,
							u64 *dev_addr, void *dma_node, u32 done_size)
{
	int ret = 0;
	struct sg_table *sgt;
	dma_node_trans_cmd_t *dma_trans_cmd = (dma_node_trans_cmd_t *)dma_node;
	unsigned long offset = ((u64)dma_trans_cmd->vir_addr) & ((1 << PAGE_SHIFT) - 1);
	unsigned int num_pages = (dma_trans_cmd->length + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	unsigned int gup_flags = 0;
	int num_pinned_pages = 0;
	struct vastai_dma_buf *dm = (struct vastai_dma_buf *)dmabuf;

	dm->pages = kvmalloc_array(num_pages, sizeof(struct page *),
			GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"kvmalloc_array failed\n");

		return -ENOMEM;
	}

	dm->num_pages = num_pages;
	gup_flags = dma_trans_cmd->is_dev_to_host ? FOLL_WRITE : 0;
	num_pinned_pages = get_user_pages_fast(
			(u64)dma_trans_cmd->vir_addr,
			(int)num_pages,
			gup_flags,
			dm->pages);
	if (num_pinned_pages != num_pages)
	{
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"get_user_pages_fast failed: (%d - %u)\n",
			num_pinned_pages, num_pages);

		ret = -EINVAL;
		goto ERROR_FREE_PAGE;
	}

	if (iommu_is_enable(pci_info))
		ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, 0, dma_trans_cmd->length, GFP_KERNEL);
	else
		ret = vastai_sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, 0, dma_trans_cmd->length,
				VASTAI_MAX_DMA_PAYLOAD, GFP_KERNEL);
	VASTAI_PCI_DBG(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"num_pages %d, nents %d\n", num_pages, dm->sg_table.nents);

	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"sg_alloc_table_from_pages failed:%d \n", ret);

		goto ERROR_FREE_PIN_PAGE;
	}
	sgt = &dm->sg_table;
	if (iommu_is_enable(pci_info))
		sgt->nents = dma_map_sg(&(pci_info->dev->dev), sgt->sgl, sgt->orig_nents, 0);

	if (!sgt->nents) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"dma_map_sg failed:%d \n", ret);

		goto ERROR_FREE_TABLE;
	}

	return ret;
ERROR_FREE_TABLE:
	sg_free_table(&dm->sg_table);
ERROR_FREE_PIN_PAGE:
	for (i = 0; i < num_pinned_pages; i++)
		put_page(dm->pages[i]);
ERROR_FREE_PAGE:
	kvfree(dm->pages);

	return ret;
}

int vastai_pci_dma_transfer_by_uaddr_new(struct vastai_pci_info *pci_info,
						union core_bitmap core_id,
						dma_node_trans_cmd_t *dma_trans_cmd)
{
	struct device *dev = &(pci_info->dev->dev);
	int i = 0;
	int ret;
	struct vastai_dma_buf dm = {0};

	ret = vastai_dma_sg_trans_get_host_addr(pci_info, i, (struct dma_buf*)&dm,
						NULL, NULL, dma_trans_cmd, 0);
	if(ret)
		return ret;

	ret = vastai_pci_dma_transfer_sg(pci_info,
				  dma_trans_cmd->die_index,
				  core_id, &dm,
				  1,
				  !(dma_trans_cmd->is_dev_to_host),
				  1,
				  dma_trans_cmd->axi_addr,
				  dma_trans_cmd->length);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, dma_trans_cmd->die_index),
			"vastai_pci_dma_transfer_sg failed:%d \n", ret);
	}
	if (iommu_is_enable(pci_info))
		dma_unmap_sg(dev, dm.sg_table.sgl, dm.sg_table.orig_nents, 0);
	sg_free_table(&dm.sg_table);
	for (i = 0; i < dm.num_pages; i++)
		put_page(dm.pages[i]);
	kvfree(dm.pages);

	return ret;
}


int vastai_pci_dma_transfer_by_uaddr(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u32 is_host_to_dev,
			u64 axi_addr,
			u64 user_addr,
			u32 size)
{
	struct device *dev = &(pci_info->dev->dev);
	struct sg_table *sgt;
	int num_pinned_pages = 0;
	unsigned long offset = user_addr & ((1 << PAGE_SHIFT) - 1);
	unsigned int num_pages = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	unsigned int gup_flags = 0;
	int i;
	int ret;
	struct vastai_dma_buf *dm =
		kzalloc(sizeof(struct vastai_dma_buf), GFP_KERNEL);
	if (!dm)
		return -ENOMEM;

	dm->pages = kvmalloc_array(num_pages, sizeof(struct page *),
			GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"kvmalloc_array failed\n");

		ret = -ENOMEM;
		goto ERROR_FREE_DM;
	}

	dm->pci_info = pci_info;
	dm->num_pages = num_pages;
	gup_flags = is_host_to_dev ? 0 : FOLL_WRITE;
	num_pinned_pages = get_user_pages_fast(
			user_addr,
			(int)num_pages,
			gup_flags,
			dm->pages);
	if (num_pinned_pages != num_pages)
	{
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"get_user_pages_fast failed: (%d - %u)\n",
			num_pinned_pages, num_pages);

		ret = -EINVAL;
		goto ERROR_FREE_PAGE;
	}

	ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, 0, size, GFP_KERNEL);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"sg_alloc_table_from_pages failed:%d \n", ret);

		goto ERROR_FREE_PIN_PAGE;
	}
	sgt = &dm->sg_table;
	sgt->nents = dma_map_sg(dev, sgt->sgl, sgt->orig_nents, 0);
	if (!sgt->nents) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"dma_map_sg failed:%d \n", ret);

		goto ERROR_FREE_TABLE;
	}
#if 1
	ret = vastai_pci_dma_transfer_sg(pci_info,
				  die_index,
				  core_id, dm,
				  1,
				  is_host_to_dev,
				  1,
				  axi_addr,
				  size);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"vastai_pci_dma_transfer_sg failed:%d \n", ret);
	}
#endif
//	printk("transfer ok\n");

	dma_unmap_sg(dev, sgt->sgl, sgt->orig_nents, 0);
ERROR_FREE_TABLE:
	sg_free_table(&dm->sg_table);
ERROR_FREE_PIN_PAGE:
	for (i = 0; i < num_pinned_pages; i++)
		put_page(dm->pages[i]);
ERROR_FREE_PAGE:
	kvfree(dm->pages);
ERROR_FREE_DM:
	kfree(dm);

	return ret;
}

int vastai_get_udma_hw_config(struct vastai_sv100_die *die)
{
	int ret = 0;
	u32 size = sizeof(struct vastai_udma_config);
	int ch = 0;
	struct vastai_pci_info *priv = die->pci_info;
	u64 hw_addr = (priv->is_virtfn) ? SV100_HW_VF_CONFIG : SV100_HW_CONFIG;

	for(ch=0; ch<VASTAI_DMA_CHN; ch++) {
		ret = vastai_pci_mem_read_direct(priv, die->die_index,
					 hw_addr+offsetof(struct sv100_hw_cfg, udma_config[ch]),
					 &die->udma_chn[ch].udma_config, size);
	}

	return ret;
}

int vastai_udma_init(struct vastai_sv100_die *die)
{
	int ret = 0;
	int chn;
	int i = 0;
	u32 dma_desc_fifo_size = VASTAI_DMA_DESC_FIFO_SIZE;
	u32 transfer_info_fifo_size = VASTAI_DMA_TRANS_INFO_FIFO_SIZE;
	u32 fifo_size = 0;
	struct vastai_fifo fifo = { 0 };

	ret = vastai_get_udma_hw_config(die);
	if(ret) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s read udma hw config err ret[%d]\n", __func__, ret);
		return ret;
	}

	/* init smcu dma desc fifo */
	/* init dma chn fifo */
	for (i = 0; i < VASTAI_DMA_CHN; i++) {
		u64 dma_desc_fifo_addr = die->udma_chn[i].udma_config.dma_desc_fifo_addr;
		if (die->boot_mode == BOOT_VF_SRIOV) {
			fifo_size = VASTAI_DMA_DESC_FIFO_SIZE - VASTAI_DMA_DESC_VF_OFFSET;
		} else if (die->boot_mode == BOOT_PF_SRIOV){
			fifo_size = VASTAI_DMA_DESC_FIFO_SIZE;
		} else {
			fifo_size = VASTAI_DMA_DESC_FIFO_SIZE;
		}
		vastai_fifo_init_arg(
			&fifo, ALIGN(sizeof(PCIE_xd_desc), 4), fifo_size);
		vastai_pci_mem_write_direct(die->pci_info, die->die_index,
				     dma_desc_fifo_addr,
				     &fifo, sizeof(fifo));
	}

	if (die->boot_mode == BOOT_VF_SRIOV) {
		fifo_size = VASTAI_DMA_TRANS_INFO_FIFO_SIZE - VASTAI_DMA_TRANS_INFO_VF_OFFSET;
	} else if (die->boot_mode == BOOT_PF_SRIOV) {
		fifo_size = VASTAI_DMA_TRANS_INFO_FIFO_SIZE;
	} else {
		fifo_size = VASTAI_DMA_TRANS_INFO_FIFO_SIZE;
	}
	vastai_fifo_init_arg(
		&fifo, ALIGN(sizeof(struct pcie_transfer_info), 4),
		fifo_size);
	for (i = 0; i < VASTAI_DMA_CHN; i++) {
		u64 trans_info_addr = die->udma_chn[i].udma_config.trans_info_fifo_addr;
		vastai_pci_mem_write_direct(die->pci_info, die->die_index,
					trans_info_addr, &fifo, sizeof(fifo));
	}

	if (die->pci_info->is_virtfn) {
		dma_desc_fifo_size -= VASTAI_DMA_DESC_VF_OFFSET;
		transfer_info_fifo_size -= VASTAI_DMA_TRANS_INFO_VF_OFFSET;
	}
	if (die->pci_info->is_virtfn)
		sema_init(&die->credit_sem, VASTAI_VF_SRIOV_DMA_CREDIT_LIMIT);
	else
		sema_init(&die->credit_sem, VASTAI_DMA_CREDIT_LIMIT);

	die->udma_wq = alloc_workqueue("vastai_dma_wq",
			WQ_MEM_RECLAIM|WQ_UNBOUND|WQ_CPU_INTENSIVE, 1);
	if (!die->udma_wq) {
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc dma_wq failed!\n", __func__);
		goto UDMA_WQ_FAILED;
	}

	for (chn = 0; chn < VASTAI_DMA_CHN; chn ++) {
		struct vastai_udma_chn *udma_chn = &(die->udma_chn[chn]);

		mutex_init(&(udma_chn->trans_mutex));

		vastai_fifo_init_arg(&(udma_chn->dma_desc_fifo),
				     ALIGN(sizeof(PCIE_xd_desc), 4),
				     dma_desc_fifo_size);
		vastai_fifo_init_arg(&(udma_chn->trans_info_fifo),
				ALIGN(sizeof(struct pcie_transfer_info), 4),
				transfer_info_fifo_size);
	}
	INIT_WORK(&(die->dma_done), dma_done_work_func);
	mutex_init(&(die->done_lock));
	die->data_struct_slab = kmem_cache_create("vastai_data_struct",
					     sizeof(struct data_struct), 0,
					     SLAB_HWCACHE_ALIGN, NULL);
	if (die->data_struct_slab == NULL){
		VASTAI_PCI_ERR(die->pci_info, DUMMY_DIE_ID,
			       "%s alloc data_struct_slab failed!\n", __func__);
		goto UDMA_WQ_FAILED;
	}

	return 0;

UDMA_WQ_FAILED:
	kfree(die->udma_wq);

	return -ENOMEM;
}

void vastai_udma_deinit(struct vastai_sv100_die *die)
{
	flush_workqueue(die->udma_wq);
	destroy_workqueue(die->udma_wq);
	die->udma_wq = NULL;
	if(die->data_struct_slab)
		kmem_cache_destroy(die->data_struct_slab);
	VASTAI_PCI_INFO(die->pci_info, DUMMY_DIE_ID, "%s done!\n", __func__);
}

struct vastai_dma_pos_info {
	u32 current_channel;
	u32 current_line;
	u32 current_line_pos;
	u32 next_dst_offset;
	int complete;
};

/**
 * 将channel buf 里的数据搬运到一个 dma buf中。它通过ret val， 使自己对上一次的结果有记忆。
 */
static int vastai_dma_copy_from_user(struct vastai_channel_buf *channel_buf,
				     int channel_num,
				     struct vastai_dma_buf *buf,
				     struct vastai_dma_pos_info *meta)
{
	int channel_i = meta->current_channel;
	u32 line_i = meta->current_line;
	int ret = 0;
	u32 dst_done_size = meta->next_dst_offset;
	u32 src_done_size =
		(channel_buf[meta->current_channel].src_width_offset +
		 channel_buf[meta->current_channel].width) *
			meta->current_line +
		meta->current_line_pos;

	if (meta->complete == 1)
		return 0;

	if (meta->current_line_pos) {
		u32 real_size;
		if (channel_buf[channel_i].width < meta->current_line_pos)
			return -EINVAL;
		real_size =
			channel_buf[channel_i].width - meta->current_line_pos;
		ret = copy_from_user_compact(buf->vir + dst_done_size,
				     (void *)channel_buf[channel_i].user_buf +
					     src_done_size,
				     real_size);
		if (ret)
			return ret;

		dst_done_size +=
			(real_size + channel_buf[channel_i].dst_width_offset);
		src_done_size +=
			(real_size + channel_buf[channel_i].src_width_offset);
		line_i += 1;
	}

	for (; channel_i < channel_num; channel_i++) {
		for (; line_i < channel_buf[channel_i].high; line_i++) {
			/* 如果 当前剩余的dma buf 不够 */
			if ((channel_buf[channel_i].width +
			     channel_buf[channel_i].dst_width_offset) >
			    (buf->size - dst_done_size)) {
				u32 real_size =
					min(channel_buf[channel_i].width,
					    buf->size - dst_done_size);
				u32 line_remain = channel_buf[channel_i].width -
						  real_size;

				ret = copy_from_user_compact(
						buf->vir + dst_done_size,
						(void *)channel_buf[channel_i].user_buf +
						src_done_size,
						real_size);
				if (ret)
					return ret;

				dst_done_size += real_size;
				meta->current_channel = channel_i;
				meta->current_line_pos =
					line_remain ? real_size : 0;
				meta->next_dst_offset =
					line_remain ?
						0 :
						(channel_buf[channel_i]
							 .dst_width_offset -
						 (buf->size - dst_done_size));
				meta->current_line = meta->next_dst_offset ?
							     ++line_i :
							     line_i;
				return 0;
			}
			/* 正常逻辑 */
				ret = copy_from_user_compact(buf->vir + dst_done_size,
						(void *)channel_buf[channel_i].user_buf +
						src_done_size,
						channel_buf[channel_i].width);
			if (ret)
				return ret;

			dst_done_size +=
				(channel_buf[channel_i].width +
				 channel_buf[channel_i].dst_width_offset);
			src_done_size +=
				(channel_buf[channel_i].width +
				 channel_buf[channel_i].src_width_offset);
		}
		line_i = 0;
		src_done_size = 0;
		dst_done_size += (channel_buf[channel_i].width +
				  channel_buf[channel_i].dst_width_offset) *
				 channel_buf[channel_i].dst_high_offset;
		if (dst_done_size > buf->size && channel_i < channel_num) {
			meta->current_channel = ++channel_i;
			meta->current_line = 0;
			meta->current_line_pos = 0;
			meta->next_dst_offset = dst_done_size - buf->size;
			return 0;
		}
	}
	/* all is done */
	meta->current_channel = 0;
	meta->current_line = 0;
	meta->current_line_pos = 0;
	meta->next_dst_offset = 0;
	meta->complete = 1;
	return ret;
}

int vastai_dma_video(struct vastai_pci_info *pci_info, int die_index, union core_bitmap core_id,
		     struct vastai_channel_buf *channel_buf, int channel_num,
		     u64 dev_addr, int pid)
{
	unsigned long channel_buf_total_size = 0;
	int i = 0;
	int ret;
	struct data_struct dma_data_struct = { 0 };
	unsigned long dma_transfer_total_len = 0;
	struct vastai_dma_pos_info meta = { 0 };
	int dma_num;
	struct buf_desc_buf *dma_buf = NULL;

	memset(&meta, 0, sizeof(struct vastai_dma_pos_info));
	for (i = 0; i < channel_num; i++) {
		channel_buf_total_size +=
			(channel_buf[i].width +
			 channel_buf[i].dst_width_offset) *
			(channel_buf[i].high + channel_buf[i].dst_high_offset);
	}

	ret = down_interruptible(&(pci_info->dies[vastai_pci_get_die_id(pci_info, die_index)].credit_sem));
	if (ret != 0)
		return ret;

	while (channel_buf_total_size - dma_transfer_total_len) {
		unsigned long remain_size =
			channel_buf_total_size - dma_transfer_total_len;
		dma_num = vast_div_round_up(remain_size, VASTAI_MAX_DMA_BUF);

		memset(&dma_data_struct, 0, sizeof(struct data_struct));
		INIT_LIST_HEAD(&dma_data_struct.head);

		dma_num = vastai_dma_get_credit(pci_info, dma_num);
		dma_buf = kvmalloc(sizeof(struct buf_desc_buf) * dma_num,
				   GFP_KERNEL);
		if (!dma_buf) {
			/* TODO ERROR HANDLE */
			VASTAI_PCI_ERR(
				pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"%s dma_buf alloc failed\n", __FUNCTION__);
			ret = -ENOMEM;
			goto UP_DMA_SEM;
		}

		for (i = 0; i < dma_num; i++) {
			u32 dma_len = min(remain_size,
					(unsigned long)VASTAI_MAX_DMA_BUF);
			if (iommu_is_enable(pci_info)) {
				dma_buf[i].buf = vastai_dma_buf_sg_get(pci_info,
								dma_len);
			} else {
				dma_buf[i].buf = vastai_mempool_get(pci_info,
								dma_len);
			}
			if (!dma_buf[i].buf) {
				dma_num = i;
				ret = -ENOMEM;
				goto CLEAN_DMA_BUF;
			}
			ret = vastai_dma_copy_from_user(channel_buf,
							channel_num,
							dma_buf[i].buf, &meta);
			if (ret) {
				/* TODO ERROR HANDLE */
				VASTAI_PCI_ERR(
					pci_info,
					vastai_pci_get_die_id(pci_info,
							      die_index),
					"%s vastai_dma_copy_from_user failed, err:%d\n",
					__FUNCTION__, ret);
				dma_num = i;
				goto CLEAN_DMA_BUF;
			}
			dma_buf[i].desc.data.data_desc.ext_addr =
				dma_buf[i].buf->dma_bus_addr;
			dma_buf[i].desc.data.data_desc.len = dma_len;
			dma_buf[i].desc.data.data_desc.sys_addr =
				dev_addr + dma_transfer_total_len;

			list_add_tail(&(dma_buf[i].desc.node),
				      &(dma_data_struct.head));
			remain_size -= dma_len;
			dma_transfer_total_len += dma_len;
		}

		dma_data_struct.trans.num = dma_num;
		dma_data_struct.trans.dir = 0;
		dma_data_struct.trans.is_rc = 0;
		ret = vastai_pci_transfer_data_sync(pci_info, die_index,
						    &dma_data_struct);
		if (ret) {
			/* TODO ERROR HANDLE */
			ssleep(1);
			VASTAI_PCI_ERR(
				pci_info,
				vastai_pci_get_die_id(pci_info, die_index),
				"%s vastai_pci_transfer_data_sync failed, err:%d\n",
				__FUNCTION__, ret);
			goto CLEAN_DMA_BUF;
		}
		for (i = 0; i < dma_num; i++) {
			clean_dma_buf(pci_info, &(dma_buf[i]), 0);
		}
		kvfree(dma_buf);
	}
	up(&pci_info->dies[vastai_pci_get_die_id(pci_info, die_index)].credit_sem);

	return 0;
CLEAN_DMA_BUF:
	for (i = 0; i < dma_num; i++) {
		clean_dma_buf(pci_info, &(dma_buf[i]), 0);
	}
	kvfree(dma_buf);
UP_DMA_SEM:
	up(&pci_info->dies[vastai_pci_get_die_id(pci_info, die_index)].credit_sem);
	return ret;
}

void vastai_global_dma_init(struct vastai_addr_info *vastai_global_addr_info)
{
	vastai_global_addr_info[SV100].dma_desc_credit = &dma_desc_credit;
	vastai_global_addr_info[SG100].dma_desc_credit = &dma_desc_credit_sg;

	vastai_global_addr_info[SV100].p_dma_transfer_sync = vastai_pci_dma_transfer_sync;
	vastai_global_addr_info[SG100].p_dma_transfer_sync = vastai_sdma_transfer_sync_pid;

	vastai_global_addr_info[SV100].is_vastai_mempool_rich = is_vastai_mempool_rich;
	vastai_global_addr_info[SG100].is_vastai_mempool_rich = is_vastai_mempool_rich_sg;
}

