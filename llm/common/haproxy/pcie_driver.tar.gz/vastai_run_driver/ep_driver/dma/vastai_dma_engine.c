/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/delay.h>
#include "vastai_udma_engine.h"
#include <linux/dma-buf.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/bitops.h>
#include <linux/workqueue.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include "vastai_dmabuf.h"
#include "hw/va_dma_core.h"
#include "hw/pcie_2_dma.h"
#include "hw/smmu.h"

//#include "vatools_define.h"
//#include "vatools_profiler.h"

static inline int vastai_list_is_first(const struct list_head *list,
				       const struct list_head *head)
{
	return list->prev == head;
}

int vastai_pcie_dma_transfer_sync(struct vastai_pci_info *pci_info, int die_index,
				 union core_bitmap core_id,
				 struct vastai_dmadesc desc[], int desc_num)
{
	return pci_info->addr->p_dma_transfer_sync(pci_info, die_index, core_id,
						         desc, desc_num, 0);
}

static int fill_dma_buf(void *priv, struct va_dma_desc_elem *elem,
			 const struct vastai_dmadesc *desc)
{
	if (!desc->is_src_dma_addr) {
		 if (iommu_is_enable(priv)) {
			elem->buf = vastai_dma_buf_sg_get(priv,
						 desc->dma_lenth);
		} else {
			elem->buf = vastai_mempool_get(priv,
						 desc->dma_lenth);
		}

		if (!elem->buf) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
						"%s udma alloc failed\n", __FUNCTION__);
			return -ENOMEM;
		}
		elem->cpu_addr =
			elem->buf->dma_bus_addr;
	} else {
		elem->cpu_addr =
			 desc->host_addr.dma_addr;
	}

	elem->size = desc->dma_lenth;
	elem->dev_addr = desc->dev_addr;

	return 0;
}

static void clean_dma_buf(void *pcie_dev, struct va_dma_desc_elem *elem,
			   u32 is_src_dma_addr)
{
	if (!is_src_dma_addr) {
		if (iommu_is_enable(pcie_dev))
			vastai_dma_buf_sg_put(pcie_dev, elem->buf);
		else
			vastai_mempool_put(pcie_dev, elem->buf);
	}
	memset(elem, 0, sizeof(struct va_dma_desc_elem));
}

static void vastai_sdma_complete(void *param)
{
	struct completion *completion = param;

	if (completion)
	complete(completion);
	return;
}

int vastai_hdma_transfer_sync_pid(void *priv, int die_index,
				 union core_bitmap core_id,
				 struct vastai_dmadesc desc[], int desc_num, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor dma_desc;
	struct va_dma_desc_elem *elem;
	struct completion completion;
	bool host_to_dev = desc[0].is_host_to_dev;

	int ret = 0;
	u8 dir;
	int i;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	elem = kvmalloc(sizeof(*elem) * desc_num, GFP_KERNEL);
	if (!elem) {
		ret = -ENOMEM;
		goto dma_free;
	}

	init_completion(&completion);

	if(desc[0].is_host_to_dev)
	{
		dir = DMA_MEM_TO_DEV;
	}
	else
	{
		dir = DMA_DEV_TO_MEM;
	}

	dma_desc.direction = dir;
	INIT_LIST_HEAD(&dma_desc.elem_head);
	dma_desc.elem_num = 0;
	dma_desc.callback = vastai_sdma_complete;
	dma_desc.callback_param = &completion;

	for (i = 0; i < desc_num; i++)
	{
		elem[i].desc_type = 0;
		ret = fill_dma_buf(priv, &(elem[i]), &(desc[i]));
		if (ret) {
			desc_num = i;
			goto CLEAN_DMA_BUF;
		}

		if (host_to_dev){
			ret = vastai_pci_dma_common_mem_copy(host_to_dev,
				&(desc[i]), elem[i].buf, priv, die_index);
			if(ret)
				goto CLEAN_DMA_BUF;
		}
		dma_desc.elem_num = dma_desc.elem_num + 1;
		list_add_tail(&(elem[i].node), &(dma_desc.elem_head));
	}

	ret = va_dma_desc_submit(dma, &dma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: wait completion error %d\n", __func__, ret);
		goto dma_free;
	}

	for (i = 0; i <  desc_num; i++) {
		if (!host_to_dev){
			ret = vastai_pci_dma_common_mem_copy(host_to_dev,
				&(desc[i]), elem[i].buf, priv, die_index);
			if(ret)
				goto CLEAN_DMA_BUF;
		}
		clean_dma_buf(priv, &(elem[i]),
			      desc->is_src_dma_addr);
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "PCIE DMA transfer completoin!\n");
	kvfree(elem);

	return ret;
CLEAN_DMA_BUF:
	for (i = 0; i < dma_desc.elem_num; i++) {
		clean_dma_buf(priv, &(elem[i]),
				 desc->is_src_dma_addr);
	}
	kvfree(elem);

dma_free:
	va_dma_free(priv, dma);

	return ret;
}

int vastai_gfx_video_share_sync_pid(void *priv, int pid, struct dma_buf *dmabuf, int dir, u64 dev_addr)
{
	struct sg_table *table;
	struct scatterlist *sg;
	struct dma_buf_attachment *attachment;
	int i;
	u64 dev_pa = dev_addr;
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem *elem;
	int ret, total_desc_num, direction, src_mmu = 0, dst_mmu = 0;
	struct completion completion;
	struct vastai_pci_info *pci_info = priv;

	attachment = dma_buf_attach(dmabuf, &(pci_info->dev->dev));
	table = dma_buf_map_attachment(attachment, DMA_BIDIRECTIONAL);

	sg = table->sgl;
	total_desc_num = table->nents;

	if(dir)
	{
		direction = DMA_MEM_TO_DEV;
	}
	else
	{
		direction = DMA_DEV_TO_MEM;
	}

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	init_completion(&completion);
	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.direction = direction;
	sdma_desc.callback = vastai_sdma_complete;
	sdma_desc.callback_param = &completion;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.pid = pid;
	sdma_desc.desc_loc = 0;
	sdma_desc.priv = priv;
	sdma_desc.elem_num = total_desc_num;
	sdma_desc.d2d = 0;
	sdma_desc.sync_tail = 0;

	elem = kvmalloc(sizeof(*elem) * total_desc_num, GFP_KERNEL);
	if (!elem) {
		ret = -ENOMEM;
		goto dma_free;
	}

	for (i = 0; i < total_desc_num; i++) {
		elem[i].desc_type = 0;
		elem[i].cpu_addr = sg_dma_address(sg);
		elem[i].size = sg_dma_len(sg);
		elem[i].dev_addr = dev_pa;

		dev_pa += sg_dma_len(sg);
		sg = sg_next(sg);
		list_add_tail(&(elem[i].node), &(sdma_desc.elem_head));
	}

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

dma_free:
	va_dma_free(priv, dma);
	kvfree(elem);
	return ret;
}

int is_vastai_mempool_rich_sg(struct vastai_pci_info *pci_info)
{
	return true;
}

extern int vastai_dma_get_credit(struct vastai_pci_info *pci_info, int expect_num);

int vastai_sdma_transfer_sync_pid(struct vastai_pci_info *priv, int die_index,
				union core_bitmap core_id,
				struct vastai_dmadesc desc[], int desc_num, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem *elem;
	bool host_to_dev = desc[0].is_host_to_dev;
	int dma_transfer_total = 0;
	int total_desc_num = desc_num;
	int ret = 0;
	u8 dir;
	int src_mmu = 0;
	int dst_mmu = 0;
	int i, cur_num;
	struct vastai_dmadesc *cur_desc = desc;
	struct completion completion;
	init_completion(&completion);

#ifdef VASTAI_PERFORMANCE_TEST
	int size = 0;
#endif
	ret = down_interruptible(&priv->credit_sem);
	if (ret != 0) {
		return ret;
	}

	dma = priv->dma_dev;

	if(desc[0].is_host_to_dev)
	{
		dir = DMA_MEM_TO_DEV;
	}
	else
	{
		dir = DMA_DEV_TO_MEM;
	}

	while(total_desc_num > dma_transfer_total) {
		cur_num = vastai_dma_get_credit(priv, total_desc_num - dma_transfer_total);

		VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID,
				"%s: push total %d elem, is_src_dma_addr:%d, is_not_usr_mem:%d\n", __func__, cur_num, cur_desc->is_src_dma_addr, cur_desc->is_src_not_user_mem);

		memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
		INIT_LIST_HEAD(&sdma_desc.elem_head);
		sdma_desc.direction = dir;
		sdma_desc.elem_num = 0;
		sdma_desc.callback = vastai_sdma_complete;
		sdma_desc.callback_param = &completion;
		sdma_desc.src_mmu = src_mmu;
		sdma_desc.dest_mmu = dst_mmu;
		sdma_desc.pid = pid;
		sdma_desc.desc_loc = 0;
		sdma_desc.priv = priv;
		sdma_desc.elem_num = cur_num;
		sdma_desc.d2d = 0;
		sdma_desc.sync_tail = 0;
		sdma_desc.priority = 0;

		elem = kvmalloc(sizeof(*elem) * cur_num, GFP_KERNEL);
		if (!elem) {
			ret = -ENOMEM;
			goto dma_free;
		}

		cur_desc = &desc[dma_transfer_total];
		for (i = 0; i < cur_num; i++)
		{
			elem[i].desc_type = 0;
			ret = fill_dma_buf(priv, &(elem[i]), &(cur_desc[i]));
			if (ret) {
				cur_num = i;
				goto dma_free;
			}

			if (host_to_dev){
				ret = vastai_pci_dma_common_mem_copy(host_to_dev,
					&(cur_desc[i]), elem[i].buf, priv, die_index);
				if(ret)
					goto CLEAN_DMA_BUF;
			}

			list_add_tail(&(elem[i].node), &(sdma_desc.elem_head));
#ifdef VASTAI_PERFORMANCE_TEST
			size += elem[i].size;
#endif
		}

#ifdef VASTAI_PERFORMANCE_TEST
        unsigned long old_ts, now_ts;
        old_ts= ktime_get();
#endif
		ret = va_dma_desc_submit(dma, &sdma_desc);
		if (ret) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				       "%s: push_dma_desc error %d\n", __func__, ret);
			goto CLEAN_DMA_BUF;
		}

		ret = wait_for_completion_interruptible(&completion);
		if (ret) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				       "%s: wait completion error %d\n", __func__, ret);
			mdelay(2000);
			goto CLEAN_DMA_BUF;
		}

#ifdef VASTAI_PERFORMANCE_TEST
        now_ts= ktime_get();
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"%dk : %06lu(us)\n", size/1024, (now_ts - old_ts)/1000);
#endif
		for (i = 0; i <  cur_num; i++) {
			if (!host_to_dev){
				ret = vastai_pci_dma_common_mem_copy(host_to_dev,
					&(cur_desc[i]), elem[i].buf, priv, die_index);
				if(ret)
					goto CLEAN_DMA_BUF;
			}
			clean_dma_buf(priv, &(elem[i]),
				      cur_desc->is_src_dma_addr);
		}

		reinit_completion(&completion);
		kvfree(elem);
		dma_transfer_total += cur_num;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s\n", "**SDMA Completion**");
	up(&priv->credit_sem);

	return ret;
CLEAN_DMA_BUF:
	for (i = 0; i < cur_num; i++) {
		clean_dma_buf(priv, &(elem[i]),
				 cur_desc->is_src_dma_addr);
	}
	kvfree(elem);

dma_free:
	up(&priv->credit_sem);

	return ret;
}

int vastai_sdma_transfer_asyn_pid(void *priv, int die_index,
				union core_bitmap core_id,
				struct vastai_dmadesc desc[], int desc_num, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem *elem;
	bool host_to_dev = desc[0].is_host_to_dev;
	int dma_transfer_total = 0;
	int total_desc_num = desc_num;
	int ret = 0;
	u8 dir;
	int src_mmu = 0;
	int dst_mmu = 0;
	int i, remain_num;
	struct vastai_dmadesc *cur_desc = desc;

#ifdef VASTAI_PERFORMANCE_TEST
	int size = 0;
#endif

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	if(desc[0].is_host_to_dev)
	{
		dir = DMA_MEM_TO_DEV;
	}
	else
	{
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: reading from chip does not support asynchrony\n", __func__);
		return -EAGAIN;
	}

	while(total_desc_num > dma_transfer_total)
	{
		remain_num = total_desc_num - dma_transfer_total;

		if (remain_num > VASTAI_DMA_SUBMIT_LIMIT)
			remain_num = VASTAI_DMA_SUBMIT_LIMIT;

		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
				       "%s: push total %d elem", __func__, remain_num);

		memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
		INIT_LIST_HEAD(&sdma_desc.elem_head);
		sdma_desc.direction = dir;
		sdma_desc.elem_num = 0;
		sdma_desc.callback = NULL;
		sdma_desc.callback_param = NULL;
		sdma_desc.src_mmu = src_mmu;
		sdma_desc.dest_mmu = dst_mmu;
		sdma_desc.pid = pid;
		sdma_desc.desc_loc = 0;
		sdma_desc.priv = priv;
		sdma_desc.elem_num = remain_num;
		sdma_desc.d2d = 0;
		sdma_desc.sync_tail = 1;

		elem = kvmalloc(sizeof(*elem) * remain_num, GFP_KERNEL);
		if (!elem) {
			ret = -ENOMEM;
			goto dma_free;
		}

		for (i = 0; i < remain_num; i++)
		{
			elem[i].desc_type = 0;
			ret = fill_dma_buf(priv, &(elem[i]), &(cur_desc[i]));
			if (ret) {
				remain_num = i;
				goto dma_free;
			}

			ret = vastai_pci_dma_common_mem_copy(host_to_dev,
				&(cur_desc[i]), elem[i].buf, priv, die_index);
			if(ret)
				goto CLEAN_DMA_BUF;

			list_add_tail(&(elem[i].node), &(sdma_desc.elem_head));
#ifdef VASTAI_PERFORMANCE_TEST
			size += elem[i].size;
#endif
		}

#ifdef VASTAI_PERFORMANCE_TEST
        unsigned long old_ts, now_ts;
        old_ts= ktime_get();
#endif
		ret = va_dma_desc_submit(dma, &sdma_desc);
		if (ret) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				       "%s: push_dma_desc error %d\n", __func__, ret);
			goto CLEAN_DMA_BUF;
		}

#ifdef VASTAI_PERFORMANCE_TEST
        now_ts= ktime_get();
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"%dk : %06lu(us)\n", size/1024, (now_ts - old_ts)/1000);
#endif
		for (i = 0; i <  remain_num; i++) {
			clean_dma_buf(priv, &(elem[i]),
				      cur_desc->is_src_dma_addr);
		}

		kvfree(elem);
		dma_transfer_total += remain_num;
		cur_desc += VASTAI_DMA_SUBMIT_LIMIT;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);
	va_dma_free(priv, dma);

	return ret;
CLEAN_DMA_BUF:
	for (i = 0; i < remain_num; i++) {
		clean_dma_buf(priv, &(elem[i]),
				 cur_desc->is_src_dma_addr);
	}
	kvfree(elem);

dma_free:
	va_dma_free(priv, dma);

	return ret;
}

int vastai_dev2dev_sdma_sync_pid(void *priv, int die_index,
				u64 src_addr, u64 dst_addr, u32 length, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	int ret = 0;
	int src_mmu = 0;
	int dst_mmu = 0;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	init_completion(&completion);

	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.direction = DMA_DEV_TO_DEV;
	sdma_desc.elem_num = 1;
	sdma_desc.callback = vastai_sdma_complete;
	sdma_desc.callback_param = &completion;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.pid = pid;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 0;
	sdma_desc.priv = priv;
	sdma_desc.sync_tail = 0;

	elem.cpu_addr = src_addr;
	elem.dev_addr = dst_addr;
	elem.size = length;
	elem.desc_type = 0;
	list_add_tail(&(elem.node), &(sdma_desc.elem_head));

#ifdef VASTAI_PERFORMANCE_TEST
	unsigned long old_ts, now_ts;
	old_ts= ktime_get();
#endif

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

#ifdef VASTAI_PERFORMANCE_TEST
	now_ts= ktime_get();
	VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"%dk : %06lu(us)\n", length/1024, (now_ts - old_ts)/1000);
#endif

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);

	va_dma_free(priv, dma);
	return ret;
dma_free:
	va_dma_free(priv, dma);

	return ret;
}

int vastai_dev2dev_sdma_asyn_pid(void *priv, int die_index,
				u64 src_addr, u64 dst_addr, u32 length, int pid)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem elem;
	int ret = 0;
	int src_mmu = 0;
	int dst_mmu = 0;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));

	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.direction = DMA_DEV_TO_DEV;
	sdma_desc.elem_num = 1;
	sdma_desc.callback = NULL;
	sdma_desc.callback_param = NULL;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.pid = pid;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 0;
	sdma_desc.priv = priv;
	sdma_desc.sync_tail = 1;

	elem.cpu_addr = src_addr;
	elem.dev_addr = dst_addr;
	elem.size = length;
	elem.desc_type = 0;
	list_add_tail(&(elem.node), &(sdma_desc.elem_head));

#ifdef VASTAI_PERFORMANCE_TEST
	unsigned long old_ts, now_ts;
	old_ts= ktime_get();
#endif

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

#ifdef VASTAI_PERFORMANCE_TEST
	now_ts= ktime_get();
	VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"%dk : %06lu(us)\n", length/1024, (now_ts - old_ts)/1000);
#endif

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);

	va_dma_free(priv, dma);
	return ret;
dma_free:
	va_dma_free(priv, dma);

	return ret;
}

int vastai_salve2master_sdma_sync_pid(void *priv, int dir,
				u64 src_addr, u64 dst_addr, u32 length)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	int ret = 0;
	int src_mmu = 0;
	int dst_mmu = 0;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	init_completion(&completion);
	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));

	// 0:read, 1:write
	if (dir)
	{
		sdma_desc.direction = DMA_DEV_TO_MEM;
		elem.cpu_addr = dst_addr;
		elem.dev_addr = src_addr;
	}
	else
	{
		sdma_desc.direction = DMA_MEM_TO_DEV;
		elem.cpu_addr = src_addr;
		elem.dev_addr = dst_addr;
	}

	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.elem_num = 1;
	sdma_desc.callback = vastai_sdma_complete;
	sdma_desc.callback_param = &completion;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 1;
	sdma_desc.priv = priv;
	sdma_desc.sync_tail = 0;

	elem.size = length;
	elem.desc_type = 0;
	list_add_tail(&(elem.node), &(sdma_desc.elem_head));

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);

	va_dma_free(priv, dma);
	return ret;
dma_free:
	va_dma_free(priv, dma);

	return ret;
}

int vastai_salve2master_sdma_asyn_pid(void *priv, int dir,
				u64 src_addr, u64 dst_addr, u32 length)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem elem;
	int ret = 0;
	int src_mmu = 0;
	int dst_mmu = 0;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
	// 0:read, 1:write
	if (dir)
	{
		sdma_desc.direction = DMA_DEV_TO_MEM;
		elem.cpu_addr = dst_addr;
		elem.dev_addr = src_addr;
	}
	else
	{
		sdma_desc.direction = DMA_MEM_TO_DEV;
		elem.cpu_addr = src_addr;
		elem.dev_addr = dst_addr;
	}

	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.elem_num = 1;
	sdma_desc.callback = NULL;
	sdma_desc.callback_param = NULL;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 1;
	sdma_desc.priv = priv;
	sdma_desc.sync_tail = 1;

	elem.size = length;
	elem.desc_type = 0;
	list_add_tail(&(elem.node), &(sdma_desc.elem_head));

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);

	va_dma_free(priv, dma);
	return ret;
dma_free:
	va_dma_free(priv, dma);

	return ret;
}

static dma_addr_t sg_addr(struct vastai_pci_info *pci_info,
				struct scatterlist *sg)
{
	return iommu_is_enable(pci_info) ? sg_dma_address(sg)
					: sg_phys(sg);
}

static u32 sg_len(struct vastai_pci_info *pci_info,
				struct scatterlist *sg)
{
	return iommu_is_enable(pci_info) ? sg_dma_len(sg)
					: sg->length;

}

/* sg_gather:
	find max size whicth can be gathered.
	return dma_addr and size.
*/

static int sg_gather(struct vastai_pci_info *pci_info ,
			struct vastai_sg_gather_info *sg_info,
			u32 max_gather_size)
{
	u32 len, len_next, cur_sg_remain_len;
	dma_addr_t addr, addr_next;
	struct scatterlist *sg, *sg_next_p;
	u32 i = sg_info->cur_sg_index;

	sg = sg_info->cur_sg;
	if (sg_info->cur_sg_remain_len == 0) {
		len = sg_len(pci_info, sg);
		sg_info->gather_addr = sg_addr(pci_info, sg);
		sg_info->gather_len = 0;
		sg_info->cur_sg_remain_len = len;
	}

	if (sg_info->cur_sg_remain_len > max_gather_size) {
		len = max_gather_size;
		addr = sg_info->gather_addr + sg_info->gather_len;
		cur_sg_remain_len = sg_info->cur_sg_remain_len - len;
	} else {
		len = sg_info->cur_sg_remain_len;
		addr = sg_info->gather_addr + sg_info->gather_len;
		while ((i + 1) < sg_info->sg_len) {
			sg_next_p = sg_next(sg);
			addr_next = sg_addr(pci_info, sg_next_p);
			len_next = sg_len(pci_info, sg_next_p);
			if (len_next == 0)
				break;
			if (addr + len == addr_next) {
				i++;
				sg = sg_next_p;
				if (len + len_next > max_gather_size) {
					cur_sg_remain_len = len + len_next -
							max_gather_size;
					len = max_gather_size;
					break;
				} else {
					len += len_next;
					cur_sg_remain_len = 0;
				}
			} else {
				i++;
				sg = sg_next_p;
				cur_sg_remain_len = 0;
				break;
			}
		}
	}
	sg_info->cur_sg = sg;
	sg_info->cur_sg_index = i;
	sg_info->gather_addr = addr;
	sg_info->gather_len = len;
	sg_info->cur_sg_remain_len = cur_sg_remain_len;

	return 0;
}

static int vastai_dma_set_desc_memset(struct vastai_dmadesc* desc,
            dma_addr_t dma_bus_addr,
            int i,
            u64 axi_addr,
            u32 done_size,
            u32 is_host_to_dev,
            u32 is_src_not_user_mem,
            u32 is_src_dma_addr,
            u32 size)
{
	int ret = 0;
	desc[i].is_host_to_dev = is_host_to_dev;
	desc[i].is_src_not_user_mem = is_src_not_user_mem;
	desc[i].is_src_dma_addr = is_src_dma_addr;
	desc[i].dev_addr = axi_addr+ done_size;

    if(size < VASTAI_MAX_MEMSET_BUF){

        desc[i].dma_lenth = size;
    }else{

        desc[i].dma_lenth = VASTAI_MAX_MEMSET_BUF;
    }

	desc[i].host_addr.dma_addr = dma_bus_addr;
	return ret;
}
int vastai_sdma_sg_set_desc(struct vastai_dmadesc* desc,
            struct vastai_sg_gather_info sg_info,
            int i,
            u64 axi_addr,
            u32 done_size,
            u32 is_host_to_dev,
            u32 is_src_not_user_mem,
            u32 is_src_dma_addr)
{
	int ret=0;
	desc[i].is_host_to_dev = is_host_to_dev;
	desc[i].is_src_not_user_mem = is_src_not_user_mem;
	desc[i].is_src_dma_addr = is_src_dma_addr;
	desc[i].dev_addr = axi_addr+ done_size;
	desc[i].dma_lenth = sg_info.gather_len;
	desc[i].host_addr.dma_addr = sg_info.gather_addr;
	return ret;
}

int vastai_sdma_transfer_memset(void *pci_info,
			int die_index,
			union core_bitmap core_id,
			dma_addr_t dma_bus_addr,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size)
{
	u32 done_size = 0;
	int ret = 0;
	int i = 0;
	struct vastai_dmadesc *desc;
	u32 entry_count = DIV_ROUND_UP(size, VASTAI_MAX_MEMSET_BUF);

	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
					GFP_KERNEL);
	while (done_size < size) {
		if (ret)
			break;
        ret = vastai_dma_set_desc_memset(desc,
                                         dma_bus_addr,
                                         i,
                                         axi_addr,
                                         done_size,
                                         is_host_to_dev,
                                         is_src_not_user_mem,
                                         is_src_dma_addr,
                                         size);

		if (ret)
		  break;
		++i;
        if(size < VASTAI_MAX_MEMSET_BUF){

            done_size += size;
        }else{

            done_size += VASTAI_MAX_MEMSET_BUF;
        }
	}
	ret = vastai_pci_dma_transfer_sync(
                pci_info, die_index, core_id,
				desc, i, -1);
	kvfree(desc);
	return ret;
}

int vastai_sdma_transfer_sg(void *pci_info,
			int die_index,
			union core_bitmap core_id,
			struct vastai_dma_buf *dm,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size)
{
	u32 max_gather_size;
	u32 done_size = 0;
	int ret = 0;
	int i=0;
	struct scatterlist *sg;
	struct vastai_sg_gather_info sg_info;
	struct vastai_dmadesc *desc;
	u32 entry_count = DIV_ROUND_UP(size, VASTAI_MAX_DMA_PAYLOAD);
	/*...................Optimize desc to become an array and record its size..............*/
	memset(&sg_info, 0, sizeof(struct vastai_sg_gather_info));
	sg_info.cur_sg = dm->sg_table.sgl;
	sg_info.sg_len = dm->sg_table.nents;
	sg = sg_info.cur_sg;

	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
					GFP_KERNEL);
	while (done_size < size) {
		max_gather_size = min((u32)VASTAI_MAX_DMA_PAYLOAD,
							size - done_size);
		ret = sg_gather(pci_info, &sg_info, max_gather_size);
		if (ret)
			break;
        ret=vastai_sdma_sg_set_desc(desc,
                                sg_info,
                                i,
                                axi_addr,
                                done_size,
                                is_host_to_dev,
                                is_src_not_user_mem,
                                is_src_dma_addr);

		if (ret)
		  break;
		++i;
		done_size += sg_info.gather_len;
	}
	ret = vastai_pci_dma_transfer_sync(
                pci_info, die_index, core_id,
				desc, i, -1);
	kvfree(desc);
	return ret;
}

int vastai_sdma_transfer_by_uaddr(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u32 is_host_to_dev,
			u64 axi_addr,
			u64 user_addr,
			u32 size)
{
	struct device *dev = &(pci_info->dev->dev);
	struct sg_table *sgt;
	int num_pinned_pages = 0;
	unsigned long offset = user_addr & ((1 << PAGE_SHIFT) - 1);
	unsigned int num_pages = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	unsigned int gup_flags = 0;
	int i;
	int ret;
	struct vastai_dma_buf *dm =
		kzalloc(sizeof(struct vastai_dma_buf), GFP_KERNEL);
	if (!dm)
		return -ENOMEM;

	dm->pages = kvmalloc_array(num_pages, sizeof(struct page *),
			GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"kvmalloc_array failed\n");

		ret = -ENOMEM;
		goto ERROR_FREE_DM;
	}

	dm->pci_info = pci_info;
	dm->num_pages = num_pages;
	gup_flags = is_host_to_dev ? 0 : FOLL_WRITE;
	num_pinned_pages = get_user_pages_fast(
			user_addr,
			(int)num_pages,
			gup_flags,
			dm->pages);
	if (num_pinned_pages != num_pages)
	{
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"get_user_pages_fast failed: (%d - %u)\n",
			num_pinned_pages, num_pages);

		ret = -EINVAL;
		goto ERROR_FREE_PAGE;
	}

	ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, 0, size, GFP_KERNEL);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"sg_alloc_table_from_pages failed:%d \n", ret);

		goto ERROR_FREE_PIN_PAGE;
	}
	sgt = &dm->sg_table;
	sgt->nents = dma_map_sg(dev, sgt->sgl, sgt->orig_nents, 0);
	if (!sgt->nents) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"dma_map_sg failed:%d \n", ret);

		goto ERROR_FREE_TABLE;
	}
#if 1
	ret = vastai_sdma_transfer_sg(pci_info,
				  die_index,
				  core_id, dm,
				  1,
				  is_host_to_dev,
				  1,
				  axi_addr,
				  size);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"vastai_sdma_transfer_sg failed:%d \n", ret);
	}
#endif
//	printk("transfer ok\n");

	dma_unmap_sg(dev, sgt->sgl, sgt->orig_nents, 0);
ERROR_FREE_TABLE:
	sg_free_table(&dm->sg_table);
ERROR_FREE_PIN_PAGE:
	for (i = 0; i < num_pinned_pages; i++)
		put_page(dm->pages[i]);
ERROR_FREE_PAGE:
	kvfree(dm->pages);
ERROR_FREE_DM:
	kfree(dm);

	return ret;
}

#ifdef ARM_SMMU_ENBALE
int vastai_sdma_transfer_by_uaddr_withmmu(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u32 is_host_to_dev,
			u64 dev_addr,
			u64 user_addr,
			u32 size)
{
	struct device *dev = &(pci_info->dev->dev);
	struct sg_table *sgt;
	int i = 0, ret = 0, src_mmu = 0, dst_mmu = 0, pid = 0, num_pinned_pages = 0;
	unsigned long offset = user_addr & ((1 << PAGE_SHIFT) - 1);
	unsigned int num_pages = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	unsigned int gup_flags = 0;
	u64 va;
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem elem;
	struct completion completion;
	struct vastai_dma_buf *dm =
		kzalloc(sizeof(struct vastai_dma_buf), GFP_KERNEL);

	u64 total_length = 0;

	pid_t usr_pid = task_tgid_nr(current);

	if (!dm)
		return -ENOMEM;

	pid = vastai_map_pid_from_user(pci_info, usr_pid);
	if (pid < 0)
	{
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s: map vastai pid(%d) failed\n", __func__, usr_pid);
		return -ENOMEM;
	}

	dm->pages = kvmalloc_array(num_pages, sizeof(struct page *),
			GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"kvmalloc_array failed\n");

		ret = -ENOMEM;
		goto ERROR_FREE_DM;
	}

	dm->pci_info = pci_info;
	dm->num_pages = num_pages;
	gup_flags = is_host_to_dev ? 0 : FOLL_WRITE;
	num_pinned_pages = get_user_pages_fast(
			user_addr,
			(int)num_pages,
			gup_flags,
			dm->pages);
	if (num_pinned_pages != num_pages)
	{
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"get_user_pages_fast failed: (%d - %u)\n",
			num_pinned_pages, num_pages);

		ret = -EINVAL;
		goto ERROR_FREE_PAGE;
	}
#if 0
	for (i=0; i< num_pages; i++)
	{
		printk("i:%d, cnt:0x%x, flag:0x%lx", i, dm->pages[i]->_mapcount, dm->pages[i]->flags);
	}

		int pfn=0, phy=0;
	/*get pfn by page_to_pfn*/
	for (i = 0; i < sgt->orig_nents; i++)
	{
		pfn = page_to_pfn(dm->pages[i]);
	//	phy = pfn_to_phys(pfn);
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"i:%d pfn:%d phy:0x%x\n", i, pfn, phy);
	}
#endif

	ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, 0, size, GFP_KERNEL);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"sg_alloc_table_from_pages failed:%d \n", ret);

		goto ERROR_FREE_PIN_PAGE;
	}
	sgt = &dm->sg_table;
#if 0
		for (i = 0; i < sgt->orig_nents; i++)
	{
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"i:%3d, va:0x%16llx, pa:0x%10x, length:0x%6x, dma_len:0x%6x\n",
				i, dm->sg_table.sgl[i].page_link, dm->sg_table.sgl[i].dma_address, dm->sg_table.sgl[i].length, dm->sg_table.sgl[i].dma_length);
	}
#endif
	sgt->nents = dma_map_sg(dev, sgt->sgl, sgt->orig_nents, 0);
	if (!sgt->nents) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"dma_map_sg failed:%d \n", ret);

		goto ERROR_FREE_TABLE;
	}

	/* start to set sdma descriptor */
	dma = va_dma_alloc(pci_info, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));
#if 0
	for (i = 0; i < sgt->nents; i++)
	{
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"i:%3d, va:0x%16x, pa:0x%10x, length:0x%6x, dma_len:0x%6x\n",
				i, dm->sg_table.sgl[i].page_link, dm->sg_table.sgl[i].dma_address, dm->sg_table.sgl[i].length, dm->sg_table.sgl[i].dma_length);
	}
#endif
	total_length = 0;
	if (!pci_info->iommu_en)
	{
		va = user_addr & VASTAI_PAGE_MASK;
#if 0
		for (i = 0; i < sgt->nents; i++)
		{
			if (dm->sg_table.sgl[i].dma_length)
			{
				total_length += dm->sg_table.sgl[i].dma_length;
				VASTAI_PCI_ERR(pci_info,
                       				 vastai_pci_get_die_id(pci_info, die_index),
                        		"i:%d, length:0x%x, total_length:0x%x\n", i, dm->sg_table.sgl[i].dma_length, total_length);
				va_create_page_mapping(pci_info, dm->sg_table.sgl[i].dma_address , va, dm->sg_table.sgl[i].dma_length, pid, 1);
			}
				va += dm->sg_table.sgl[i].dma_length;
		}
#endif
		if (is_host_to_dev)
		{
			sdma_desc.direction = DMA_MEM_TO_DEV;
			elem.cpu_addr = user_addr;
			elem.dev_addr = dev_addr;
			src_mmu = 1;
			dst_mmu = 0;
		}
		else
		{
			sdma_desc.direction = DMA_DEV_TO_MEM;
			elem.cpu_addr = dev_addr;
			elem.dev_addr = user_addr;
			src_mmu = 0;
			dst_mmu = 1;
		}
	}
	else
	{
		if (is_host_to_dev)
		{
			sdma_desc.direction = DMA_MEM_TO_DEV;
			elem.cpu_addr = dm->sg_table.sgl[i].dma_address + offset;
			elem.dev_addr = dev_addr;
		}
		else
		{
			sdma_desc.direction = DMA_DEV_TO_MEM;
			elem.cpu_addr = dev_addr;
			elem.dev_addr = dm->sg_table.sgl[i].dma_address + offset;
		}
		src_mmu = 0;
		dst_mmu = 0;
	}

	init_completion(&completion);

	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.elem_num = 1;
	sdma_desc.callback = vastai_sdma_complete;
	sdma_desc.callback_param = &completion;
	sdma_desc.pid = pid;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 0;
	sdma_desc.priv = pci_info;
	sdma_desc.sync_tail = 0;
	sdma_desc.priority = 0;

	elem.size = size;
	elem.desc_type = 0;
	list_add_tail(&(elem.node), &(sdma_desc.elem_head));

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
				   "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s() transfer completoin!\n", __func__);
//	va_free_page_maping(pci_info, user_addr, size, pid);

dma_free:
	va_dma_free(pci_info, dma);

	dma_unmap_sg(dev, sgt->sgl, sgt->orig_nents, 0);
ERROR_FREE_TABLE:
	sg_free_table(&dm->sg_table);
ERROR_FREE_PIN_PAGE:
	for (i = 0; i < num_pinned_pages; i++)
		put_page(dm->pages[i]);
ERROR_FREE_PAGE:
	kvfree(dm->pages);
ERROR_FREE_DM:
	kfree(dm);

#if 0
	ret = vastai_unmap_pid_from_user(pci_info, pid);
	if (ret < 0)
	{
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s: unmap vastai pid(%d) failed\n", __func__, pid);
		return -ENOMEM;
	}
#endif
	return ret;
}

int vastai_pcie_dma_raw_transfer_by_uaddr(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u32 is_host_to_dev,
			u64 axi_addr,
			u64 user_addr,
			u32 size)
{
	struct device *dev = &(pci_info->dev->dev);
	int num_pinned_pages = 0;
	unsigned long offset = user_addr & ((1 << PAGE_SHIFT) - 1);
	unsigned int num_pages = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	unsigned int gup_flags = 0;
	int i;
	int ret;
	struct vastai_dma_buf *dm =
		kzalloc(sizeof(struct vastai_dma_buf), GFP_KERNEL);

	struct va_dma_descriptor pcie_dma_desc;
	struct va_dma_desc_elem *elem = NULL;
	unsigned int elem_num = 0;
	struct scatterlist *sg, *sg_next_p;
	u64 len, len_next;
	dma_addr_t addr, addr_next;

	if (!dm)
		return -ENOMEM;

	dm->pages = kvmalloc_array(num_pages, sizeof(struct page *),
			GFP_KERNEL | __GFP_ZERO);
	if (!dm->pages) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"kvmalloc_array failed\n");

		ret = -ENOMEM;
		goto ERROR_FREE_DM;
	}

	dm->pci_info = pci_info;
	dm->num_pages = num_pages;
	gup_flags = is_host_to_dev ? 0 : FOLL_WRITE;
	num_pinned_pages = get_user_pages_fast(
			user_addr,
			(int)num_pages,
			gup_flags,
			dm->pages);
	if (num_pinned_pages != num_pages)
	{
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"get_user_pages_fast failed: (%d - %u)\n",
			num_pinned_pages, num_pages);

		ret = -EINVAL;
		goto ERROR_FREE_PAGE;
	}

	ret = sg_alloc_table_from_pages(&dm->sg_table, dm->pages,
				dm->num_pages, offset, size, GFP_KERNEL);
	if (ret) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"sg_alloc_table_from_pages failed:%d \n", ret);

		goto ERROR_FREE_PIN_PAGE;
	}
	pcie_dma_desc.direction = is_host_to_dev ? DMA_MEM_TO_DEV : DMA_DEV_TO_MEM;
	dm->sg_table.nents = dma_map_sg(dev, dm->sg_table.sgl, dm->sg_table.orig_nents, (enum dma_data_direction)pcie_dma_desc.direction);
	if (!dm->sg_table.nents) {
		VASTAI_PCI_ERR(
			pci_info,
			vastai_pci_get_die_id(pci_info, die_index),
			"dma_map_sg failed:%d \n", ret);

		goto ERROR_FREE_TABLE;
	}

	printk("XT:sg total nents=%u, orig_nents=%u\n", dm->sg_table.nents, dm->sg_table.orig_nents);

	for_each_sg(dm->sg_table.sgl, sg, dm->sg_table.nents, i) {
		printk("XT: sg(%d) mem_addr=%llx, len=%x, offset=%x, page_link=%lx\n",
				i, sg_dma_address(sg), sg_dma_len(sg), sg->offset, sg->page_link);
	}

	INIT_LIST_HEAD(&pcie_dma_desc.elem_head);

	for_each_sg(dm->sg_table.sgl, sg, dm->sg_table.nents, i) {
		len = sg_dma_len(sg);
		addr = sg_dma_address(sg);

		if (len == 0)
			break;

		while ((i + 1) < dm->sg_table.nents) {
			sg_next_p = sg_next(sg);
			len_next = sg_dma_len(sg_next_p);
			addr_next = sg_dma_address(sg_next_p);

			if (len_next == 0)
				break;

			if (addr + len == addr_next) {
				len += len_next;
				i++;
				sg = sg_next_p;
			} else {
				break;
			}
		}

		elem = kzalloc(sizeof(struct va_dma_desc_elem), GFP_KERNEL);
		if (!elem)
		{
			printk("elem alloc error\n");
			goto ERROR_FREE_ELEM;
		}
		elem_num++;
		elem->size = len;
		elem->cpu_addr = addr;
		elem->dev_addr = axi_addr;
		pcie_dma_desc.total_len += len;
		list_add_tail(&(elem->node), &(pcie_dma_desc.elem_head));
		axi_addr += len;
	}

	printk("%s %d elem_num=%d\n", __func__, __LINE__, elem_num);
	if (!elem_num)
		goto ERROR_FREE_TABLE;

	pcie_dma_desc.elem_num = elem_num;
	ret = pcie2_dma_desc_submit_raw(pci_info, &pcie_dma_desc);
	if (ret)
	{
		printk("pcie dma desc submit raw failed \n");
	}
	else
	{
		printk("transfer ok\n");
	}

ERROR_FREE_TABLE:
	dma_unmap_sg(dev, dm->sg_table.sgl, dm->sg_table.orig_nents, 0);
	sg_free_table(&dm->sg_table);
ERROR_FREE_PIN_PAGE:
	for (i = 0; i < num_pinned_pages; i++)
		put_page(dm->pages[i]);
ERROR_FREE_PAGE:
	kvfree(dm->pages);
ERROR_FREE_DM:
	kfree(dm);
ERROR_FREE_ELEM:
	kfree(elem);

	return ret;
}
#endif

int vastai_sdma_fill_data(struct vastai_pci_info *priv,
			int die_index,
			union core_bitmap core_id,
			u64 axi_addr,
			u64 data,
			u32 size)
{
	va_dma_t *dma;
	struct va_dma_descriptor sdma_desc;
	struct va_dma_desc_elem *elem;
	struct completion completion;
	int ret = 0;
	int src_mmu = 0;
	int dst_mmu = 0;
	int pid = 0;

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV | VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: dma alloc failed\n", __func__);
		return -EAGAIN;
	}

	elem = kvmalloc(sizeof(*elem), GFP_KERNEL);
	if (!elem) {
		ret = -ENOMEM;
		goto dma_free;
	}

	init_completion(&completion);
	memset(&sdma_desc, 0, sizeof(struct va_dma_descriptor));

	sdma_desc.direction = DMA_MEM_TO_DEV;
	INIT_LIST_HEAD(&sdma_desc.elem_head);
	sdma_desc.elem_num = 1;
	sdma_desc.callback = vastai_sdma_complete;
	sdma_desc.callback_param = &completion;
	sdma_desc.src_mmu = src_mmu;
	sdma_desc.dest_mmu = dst_mmu;
	sdma_desc.pid = pid;
	sdma_desc.desc_loc = 0;
	sdma_desc.d2d = 0;
	sdma_desc.priv = priv;
	sdma_desc.sync_tail = 0;

	elem->cpu_addr = data;
	elem->desc_type = 2;
	elem->dev_addr = axi_addr;
	elem->size = size;
	list_add_tail(&(elem->node), &(sdma_desc.elem_head));

	ret = va_dma_desc_submit(dma, &sdma_desc);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: push_dma_desc error %d\n", __func__, ret);
		goto dma_free;
	}

	ret = wait_for_completion_interruptible(&completion);
	if (ret) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,
			       "%s: wait completion error %d\n", __func__, ret);
		mdelay(2000);
		goto dma_free;
	}

	VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, "%s transfer completoin!\n", __func__);

dma_free:
	va_dma_free(priv, dma);
	return ret;
}

struct vastai_dma_pos_info {
	u32 current_channel;
	u32 current_line;
	u32 current_line_pos;
	u32 next_dst_offset;
	int complete;
};