#include <linux/dmi.h>
#include <crypto/hash.h>

#include "vastai_dmi_table.h"
#include "vastai_export_api.h"
#include "sg100_cmd.h"


#define DMI_STATE 0x8BC0748
#define DEFAULT_SYS_VENDOR			"No Sys Vendor"
#define DEFAULT_PRODUCTION_NAME		"No Product Name"

struct dmi_info host_dmi_info;

#define INSPUR_SA5212M4				0x010101
#define INSPUR_NF5280M5				0x010201
#define INSPUR_NF5280M6				0x010202
#define INSPUR_NF5468M5				0x010301
#define INSPUR_NF5468M6				0x010302
#define INSPUR_NE5260M5				0x010401
#define LTHPC_SR222						0x020101
#define HUAQIN_P6410					0x020101
#define SUPERMICRO_AS_4124GS_TNR		0x040101
#define SUPERMICRO_SYS_6949GP_TRT	0x040101
#define XFUSION_2288H_V5				0x030101
#define XFUSION_2288H_V6				0x030102
#define HUAWEI_TAISHAN_200			0x050101
#define LENOVO_THINKSYSTEM_SR665		0x060101
#define NEW_H3C_UNISERVER_R4900_G5	0x040101
#define NEW_H3C_UNISERVER_R5300_G5	0x070201
#define H3C_R4900_G3					0x070301
#define SYS_MANU_SYS_PRO_NAME		0x0f0101
#define DEFAULT_STR_DEFAULT_STR		0x0f0201

struct dmi_info dmi_table[] = {
	{
		.sys_vendor = "Inspur",
		.product_name = "SA5212M4",
		.id = INSPUR_SA5212M4,
	}, {
		.sys_vendor = "Inspur",
		.product_name = "NF5280M5",
		.id = INSPUR_NF5280M5,
	}, {
		.sys_vendor = "Inspur",
		.product_name = "NF5280M6",
		.id = INSPUR_NF5280M6,
	}, {
		.sys_vendor = "Inspur",
		.product_name = "NF5468M5",
		.id = INSPUR_NF5468M5,
	}, {
		.sys_vendor = "Inspur",
		.product_name = "NF5468M6",
		.id = INSPUR_NF5468M6,
	}, {
		.sys_vendor = "Inspur",
		.product_name = "NE5260M5",
		.id = INSPUR_NE5260M5,
	},{
		.sys_vendor = "LTHPC",
		.product_name = "SR222-Server-System",
		.id = LTHPC_SR222,
	}, {
		.sys_vendor = "HUAQIN",
		.product_name = "P6410",
		.id = HUAQIN_P6410,
	}, {
		.sys_vendor = "Supermicro",
		.product_name = "AS -4124GS-TNR",
		.id = SUPERMICRO_AS_4124GS_TNR,
	}, {
		.sys_vendor = "Supermicro",
		.product_name = "SYS-6949GP-TRT",
		.id = SUPERMICRO_SYS_6949GP_TRT,
	}, {
		.sys_vendor = "XFUSION",
		.product_name = "2288H V5",
		.id = XFUSION_2288H_V5,
	}, {
		.sys_vendor = "XFUSION",
		.product_name = "2288H V6",
		.id = XFUSION_2288H_V6,
	}, {
		.sys_vendor = "Huawei",
		.product_name = "TaiShan 200 (Model 2280)",
		.id = HUAWEI_TAISHAN_200,
	}, {
		.sys_vendor = "Lenovo",
		.product_name = "ThinkSystem SR665",
		.id = LENOVO_THINKSYSTEM_SR665,
	}, {
		.sys_vendor = "New H3C Technologies",
		.product_name = "H3C UniServer R4900 G5",
		.id = NEW_H3C_UNISERVER_R4900_G5,
	}, {
		.sys_vendor = "New H3C Technologies",
		.product_name = "H3C UniServer R5300 G5",
		.id = NEW_H3C_UNISERVER_R5300_G5,
	}, {
		.sys_vendor = "H3C",
		.product_name = "R4900 G3",
		.id = H3C_R4900_G3,
	}, {
		.sys_vendor = "System manufacturer",
		.product_name = "System Product Name",
		.id = SYS_MANU_SYS_PRO_NAME,
	}, {
		.sys_vendor = "Default string",
		.product_name = "Default string",
		.id = DEFAULT_STR_DEFAULT_STR,
	}
};

static inline int dmicmp(const struct dmi_info *dmi1,
			  const struct dmi_info *dmi2)
{
	int ret;

	ret = strncmp(dmi1->sys_vendor,
		      dmi2->sys_vendor, strlen(dmi1->sys_vendor));
	if (ret)
		return ret;

	ret = strncmp(dmi1->product_name,
		      dmi2->product_name, strlen(dmi1->product_name));
	return ret;
}

static u32 dmi_info_get_id(struct dmi_info *dmi_info)
{
	u32 id = UINT_MAX;
	int i = 0;

	for (i = 0; i < ARRAY_SIZE(dmi_table); i++) {
		if (!dmicmp(&dmi_table[i], dmi_info)) {
			id = dmi_table[i].id;
			break;
		}
	}
	return id;
}

static void dmi_info_print(struct vastai_pci_info *pci_info)
{
	u32 reg;
	int ret;
	char *dev_state;

	VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "dmi info: host vendor %s:%s\n",
		host_dmi_info.sys_vendor,
		host_dmi_info.product_name);

	if(vastai_get_board_type(pci_info) == SV100) {
		ret = vastai_pci_mem_read(pci_info, -1, DMI_STATE, &reg, sizeof(reg));
		if (ret) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "%s read reg error\n",
					__FUNCTION__);
		}


		switch (reg & 0x3) {
		case 0b00:
			dev_state = "Server need reboot to use new cfg.";
			break;
		case 0b01:
			dev_state = "Server cfg is match and be used.";
			break;
		case 0b10:
			dev_state = "Server cfg is miss. Please confirm the pcie cfg.";
			break;
		default:
			dev_state = "ERROR reg val.";
			break;
		}
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s\n", dev_state);
	}
	return;
}

static int dmi_trigger_smcu_write_flash(struct vastai_pci_info *pci_info)
{
	int ret = 0;

	if(vastai_get_board_type(pci_info) == SV100) {
		u64 para = host_dmi_info.hash;

		para = para<<32 | host_dmi_info.id;
		ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[0].die_index,
					    VASTAI_PCIE_SUB_DMI_FLASH,
					    para);
	}

	if(vastai_get_board_type(pci_info) == SG100) {
		struct pcie_transfer_cmd trans;

		trans.w0.s_data0.optcode	= SMCU_DMI_FLASH;
		trans.w1.data1			= host_dmi_info.id;
		ret = vastai_pci_send_msg(pci_info, 0, COMMON_HOST_TO_SMCU_CMD_BUF, &trans, 0);
	}

	return ret;
}

int dmi_set_device(struct vastai_pci_info *pci_info)
{
	int ret = 0;

	ret = dmi_trigger_smcu_write_flash(pci_info);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID, "%s send dmi failed\n",
				__FUNCTION__);
	}

	dmi_info_print(pci_info);
	return ret;
}
void vastai_cal_sha256(const char *str, u32 *hash)
{
	struct crypto_shash *tfm;
	struct shash_desc *desc;
	int ret;
	size_t desc_size;
	u8 out[32];

	memset(out, 0, 32);
	tfm = crypto_alloc_shash("sha256", 0, 0);
	if (IS_ERR(tfm)) {
		printk(KERN_ERR "alg: hash: Failed to load transform for %s: "
		       "%ld\n", "sha1", PTR_ERR(tfm));
		return;
	}

	desc_size = crypto_shash_descsize(tfm) + sizeof(*desc);
	desc = kzalloc(desc_size, GFP_KERNEL);
	if (!desc)
		goto error_no_desc;
	desc->tfm = tfm;
	ret = crypto_shash_digest(desc, str, strlen(str), out);
	if (ret < 0)
		goto error;
	*hash = *(u32 *)out;

	error:
	kfree(desc);
	error_no_desc:
	crypto_free_shash(tfm);

	return;
}
 void vastai_test_cal_dmi_sha256(void)
{
	int i = 0;
	u32 hash;
	for (i = 0; i < ARRAY_SIZE(dmi_table); i++) {
		vastai_cal_sha256(dmi_table[i].product_name, &hash);
		printk("%s:0x%08x\n", dmi_table[i].product_name, hash);
	}
}

void dmi_info_init(void)
{
	host_dmi_info.sys_vendor = dmi_get_system_info(DMI_SYS_VENDOR);
	host_dmi_info.product_name = dmi_get_system_info(DMI_PRODUCT_NAME);
	if((host_dmi_info.sys_vendor != NULL) && (host_dmi_info.product_name != NULL)) {
		host_dmi_info.id = dmi_info_get_id(&host_dmi_info);
	}
	else if ((host_dmi_info.sys_vendor == NULL) && (host_dmi_info.product_name != NULL)) {
		host_dmi_info.sys_vendor = DEFAULT_SYS_VENDOR;
		host_dmi_info.id = UINT_MAX;
	}
	else if ((host_dmi_info.sys_vendor != NULL) && (host_dmi_info.product_name == NULL)) {
		host_dmi_info.product_name = DEFAULT_PRODUCTION_NAME;
		host_dmi_info.id = UINT_MAX;
	}
	else {
		host_dmi_info.sys_vendor = DEFAULT_SYS_VENDOR;
		host_dmi_info.product_name = DEFAULT_PRODUCTION_NAME;
		host_dmi_info.id = UINT_MAX;
	}
	vastai_cal_sha256(host_dmi_info.product_name, &host_dmi_info.hash);
	printk("vastai host vendor:%s product:%s id:%d, hash:0x%08x\n",
			host_dmi_info.sys_vendor,
			host_dmi_info.product_name,
			host_dmi_info.id,
			host_dmi_info.hash);
}

