#include "vastai_pci.h"

struct msgq_config {
	u32 addr;
	u32 int_reg_addr;
	u32 ring_buf_start;
	u32 ring_buf_len;
};

static const struct msgq_config smcu_msgq_config[] = {
	{
		.addr = CMCU_MSGQ_GRP0_AFULL_REG,
		.int_reg_addr = CMCU_MSGQ_GRP0_INT_REG,
		.ring_buf_start = MSG_PCIE_TO_SMCUQ0,
		.ring_buf_len = VASTAI_PCIE_MSGQ_0_SIZE,
	}, {
		.addr = CMCU_MSGQ_GRP1_AFULL_REG,
		.int_reg_addr = CMCU_MSGQ_GRP1_INT_REG,
		.ring_buf_start = MSG_PCIE_TO_SMCUQ1,
		.ring_buf_len = VASTAI_PCIE_MSGQ_1_SIZE,
	},
};

static struct vastai_sv100_die *get_die(struct msgq *msgq)
{
	if (!msgq) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s msgq_point is null\n",
				__FUNCTION__);
	}
	return container_of(msgq, struct vastai_sv100_die, msgq[msgq->msgq_id]);
}

static void
msgq_init(struct msgq *msgq, s32 msgq_id, const struct msgq_config *reg_config)
{
	struct vastai_pci_info *pci_info;
	struct vastai_sv100_die *die;
	u32 die_id;
	int ret;
	u32 reg_val;

	if (!msgq) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s is failed, msgq is null.\n",
				__FUNCTION__);
		return;
	}

	msgq->overflow = false;
	msgq->msgq_id = msgq_id;
	/* 1. pci_info must be init before msgq_init
	 * 2. vastai_sv100_die->pci_info must be init before msgq_init
	 * 3. vastai_sv100_die must have struct msgq (msgq can not be point)
	 */
	die = get_die(msgq);
	if (!die || !die->pci_info) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s is failed, die struct info is error.\n",
				__FUNCTION__);
		return;
	}
	pci_info = die->pci_info;
	die_id = vastai_pci_get_die_id(pci_info, die->die_index);

	/* check point is valid */
	if (!pci_info || (&pci_info->dies[die_id] != die)
			|| (&die->msgq[msgq_id] != msgq)) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed, point is invalid.\n",
				__FUNCTION__);	
		return;

	}
	/* init reg */
	memset(&msgq->msgq_cache, 0, sizeof(msgq->msgq_cache));
	msgq->addr = reg_config->addr;
	msgq->msgq_cache.start = reg_config->ring_buf_start;
	msgq->msgq_cache.end = reg_config->ring_buf_start
			+ reg_config->ring_buf_len;
	msgq->msgq_cache.wr = msgq->msgq_cache.rd = msgq->msgq_cache.start;
	ret = vastai_pci_mem_write_direct(pci_info, die->die_index,
				reg_config->addr, &msgq->msgq_cache,
				sizeof(msgq->msgq_cache));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed, reg write failed.\n",
				__FUNCTION__);
		return;
	}

	/* enable irq */
	ret = vastai_pci_mem_read_direct(pci_info, die->die_index,
				reg_config->int_reg_addr, &reg_val, 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed, read int reg failed.\n",
				__FUNCTION__);
		return;
	}
	reg_val &= 0xFFFFFFF7;
	ret = vastai_pci_mem_write_direct(pci_info, die->die_index,
				reg_config->int_reg_addr, &reg_val, 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s is failed, enable irq failed.\n",
				__FUNCTION__);
		return;
	}

	spin_lock_init(&msgq->msgq_lock);

}

void vmsgq_init(struct vmsgq* vmsgq, int msgq_id, struct vastai_sv100_die *die)
{
	vmsgq->ptr = &die->msgq[msgq_id];
	spin_lock_init(&vmsgq->vmsgq_lock);
	if (die->boot_mode == BOOT_PF_NORMAL) {
		vmsgq->msgq_wr_hdl = vastai_pci_msgq_wr;
		vmsgq->msgq_spe_wr_hdl = vastai_pci_msgq_wr_spe;
	} else {
		vmsgq->msgq_wr_hdl = vastai_pci_msgq_wr_sriov;
		vmsgq->msgq_spe_wr_hdl = vastai_pci_msgq_wr_spe_sriov;
	}
}

/* init smcu's two msgq */
void vastai_die_msgq_init(struct vastai_sv100_die *die)
{
	struct vastai_pci_info *pci_info = die->pci_info;
	if (pci_info->is_physfn) {
		msgq_init(&die->msgq[0], 0, &smcu_msgq_config[0]);
		msgq_init(&die->msgq[1], 1, &smcu_msgq_config[1]);
		vmsgq_init(&die->vmsgq[0], 0, die);
		vmsgq_init(&die->vmsgq[1], 1, die);
	} else {
		msgq_init(&die->msgq[1], 1, &smcu_msgq_config[1]);
		vmsgq_init(&die->vmsgq[0], 1, die);
		vmsgq_init(&die->vmsgq[1], 1, die);
	}
}

static bool msgq_fifo_is_break(struct vastai_msgq *msgq_temp)
{
	if (msgq_temp->rd == 0xffffffff || msgq_temp->wr == 0xffffffff ||
		msgq_temp->start == 0xffffffff || msgq_temp->end == 0xffffffff)
		return true;
	else
		return false;
}
/**
 * @brief send msg and trigger msgqueue interrupt to smcu.
 *
 * @param msgq: select the msgqueue, pci_info->dies[x].msgq[x].
 * @param data: data want send.
 * @param data_size: data's size.
 * @return int: 0 is success. other is failed.
 */
int msgq_type2size[MSGQ_TYPE_MAX] = {
	[MSGQ_DMA] = sizeof(u32),
	[MSGQ_CMD] = sizeof(struct pcie_transfer_info),
};

int vastai_check_msgq_data_size(u32 data_size)
{
	int i;
	for (i = 0; i < MSGQ_TYPE_MAX; i++) {
		if (msgq_type2size[i] == data_size) {
			return 0;
		}
	}
	return -1;
}

int vastai_pci_msgq_cache_update(struct msgq *msgq)
{
	struct vastai_pci_info *pci_info = get_die(msgq)->pci_info;
	struct vastai_msgq *msgq_temp = &msgq->msgq_cache;
	int die_index = get_die(msgq)->die_index;
	u64 msg_addr = msgq->addr;
	unsigned long irq_flag;
	int ret = 0;

	spin_lock_irqsave(&msgq->msgq_lock, irq_flag);
	ret = vastai_pci_mem_read(pci_info, die_index, msg_addr,
							  msgq_temp, sizeof(*msgq_temp));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
					   "%s mem_read err, ret=%d\n", __func__, ret);
		goto OUT;
	}

OUT:
	spin_unlock_irqrestore(&msgq->msgq_lock, irq_flag);
	return ret;
}

int vastai_pci_msgq_wr(struct msgq *msgq, void *data, u32 data_size)
{
	struct vastai_pci_info *pci_info = get_die(msgq)->pci_info;
	int die_index = get_die(msgq)->die_index;
	struct vastai_msgq *msgq_temp = &msgq->msgq_cache;
	int ret = 0;
	u64 msg_addr = msgq->addr;
	unsigned long irq_flag;
	u32 is_read = 0;

	spin_lock_irqsave(&msgq->msgq_lock, irq_flag);
FLASH_MSGQ:
	if (msgq_temp->wr == msgq_temp->rd || !msgq_temp->start || !msgq_temp->end) {
		ret = vastai_pci_mem_read(pci_info, die_index, msg_addr,
					  msgq_temp,
					  sizeof(*msgq_temp));
		if (ret) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info, die_index),
				       "%s mem_read err, ret=%d\n", __func__, ret);
			goto OUT;
		}

		if (msgq_fifo_is_break(msgq_temp)) {
			VASTAI_PCI_ERR(
				pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s rd:%x, wr:%x, start:%x, end:%x\n",
				__func__, msgq_temp->rd, msgq_temp->wr,msgq_temp->start, msgq_temp->end);
			ret = -ENXIO;
			goto OUT;
		}
		is_read = 1;
	}

	if (msgq_temp->wr < msgq_temp->start) {
		msgq_temp->wr = msgq_temp->start;
	} else {
		msgq_temp->wr = msgq_temp->wr + data_size;
	}

	if (msgq_temp->wr + data_size >= msgq_temp->end)
		msgq_temp->wr = msgq_temp->start;

	/* only trigger once */
	if (msgq_temp->wr == msgq_temp->rd && !is_read)
		goto FLASH_MSGQ;

	if (msgq_temp->wr == msgq_temp->rd) {
		VASTAI_PCI_ERR(
			pci_info, vastai_pci_get_die_id(pci_info, die_index),
			"%s wr = rd = 0x%x, pls check is smcu reinit? or init failed\n",
			__func__, msgq_temp->wr);
		ret = -ENOMEM;
		goto OUT;
	}

	vastai_pci_mem_write(pci_info, die_index, (u64)msgq_temp->wr, data,
			     data_size);
	VASTAI_PCI_DBG(pci_info, vastai_pci_get_die_id(pci_info, die_index),
		       "%s wr:0x%x, rd:0x%x\n", __func__, msgq_temp->wr,
		       msgq_temp->rd);
	mb();
	ret = vastai_pci_mem_write(pci_info, die_index,
				   msg_addr + offsetof(struct vastai_msgq, wr),
				   &(msgq_temp->wr), 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s mem_write err, ret=%d\n", __func__, ret);
	}
OUT:
	spin_unlock_irqrestore(&msgq->msgq_lock, irq_flag);
	return ret;
}

int vastai_pci_msgq_wr_spe(struct msgq *msgq, void *data, u32 data_size)
{
	struct vastai_pci_info *pci_info = get_die(msgq)->pci_info;
	int die_index = get_die(msgq)->die_index;
	struct vastai_msgq *msgq_temp = &msgq->msgq_cache;
	int ret = 0;
	u64 msg_addr = msgq->addr;
	unsigned long irq_flag;
	u32 is_read = 0;

	spin_lock_irqsave(&msgq->msgq_lock, irq_flag);
FLASH_MSGQ:
	if (msgq_temp->wr == msgq_temp->rd || !msgq_temp->start || !msgq_temp->end) {
		ret = vastai_pci_mem_read_direct(pci_info, die_index, msg_addr,
					  msgq_temp,
					  sizeof(*msgq_temp));
		if (ret) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info, die_index),
				       "%s mem_read err, ret=%d\n", __func__, ret);
			goto OUT;
		}

		if (msgq_fifo_is_break(msgq_temp)) {
			VASTAI_PCI_ERR(
				pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s rd:%x, wr:%x, start:%x, end:%x\n",
				__func__, msgq_temp->rd, msgq_temp->wr,msgq_temp->start, msgq_temp->end);
			ret = -ENXIO;
			goto OUT;
		}
		is_read = 1;
	}

	if (msgq_temp->wr < msgq_temp->start) {
		msgq_temp->wr = msgq_temp->start;
	} else {
		msgq_temp->wr = msgq_temp->wr + data_size;
	}

	if (msgq_temp->wr + data_size >= msgq_temp->end)
		msgq_temp->wr = msgq_temp->start;

	/* only trigger once */
	if (msgq_temp->wr == msgq_temp->rd && !is_read)
		goto FLASH_MSGQ;

	if (msgq_temp->wr == msgq_temp->rd) {
		VASTAI_PCI_ERR(
			pci_info, vastai_pci_get_die_id(pci_info, die_index),
			"%s wr = rd = 0x%x, pls check is smcu reinit? or init failed\n",
			__func__, msgq_temp->wr);
		ret = -ENOMEM;
		goto OUT;
	}

	vastai_pci_mem_write_direct(pci_info, die_index, (u64)msgq_temp->wr, data,
			     data_size);
	VASTAI_PCI_DBG(pci_info, vastai_pci_get_die_id(pci_info, die_index),
		       "%s wr:0x%x, rd:0x%x\n", __func__, msgq_temp->wr,
		       msgq_temp->rd);
	mb();
	ret = vastai_pci_mem_write_direct(pci_info, die_index,
				   msg_addr + offsetof(struct vastai_msgq, wr),
				   &(msgq_temp->wr), 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s mem_write err, ret=%d\n", __func__, ret);
	}
OUT:
	spin_unlock_irqrestore(&msgq->msgq_lock, irq_flag);
	return ret;
}

#define IF_NEED_FETCH(wr, rd, wr_under_rd) (wr >= rd && wr_under_rd)
int vastai_pci_msgq_wr_sriov(struct msgq *msgq, void *data, u32 data_size)
{
	struct vastai_pci_info *pci_info = get_die(msgq)->pci_info;
	int die_index = get_die(msgq)->die_index;
	struct vastai_msgq *msgq_temp = &msgq->msgq_cache;
	struct msgq_header hdr = { 0 };
	u32 hdr_pos;
	u32 data_pos;
	int ret = 0;
	u64 msg_addr = msgq->addr;
	unsigned long irq_flag;
	u32 is_read = 0;
	bool need_flash = false;
	u32 last_rd;

	hdr.type = (data_size == 4) ? 0 : 1;
	if (vastai_check_msgq_data_size(data_size)) {
		VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
					   "%s msgq data_size(%d) illegal\n", __func__, data_size);
	}
	spin_lock_irqsave(&msgq->msgq_lock, irq_flag);
FLASH_MSGQ:
	if (msgq_temp->wr == msgq_temp->rd || need_flash) {
		last_rd = msgq_temp->rd;
		ret = vastai_pci_mem_read(pci_info, die_index, msg_addr,
					  msgq_temp,
					  sizeof(*msgq_temp));
		if (ret) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info, die_index),
				       "%s mem_read err, ret=%d\n", __func__, ret);
			goto OUT;
		}

		if (msgq_fifo_is_break(msgq_temp)) {
			VASTAI_PCI_ERR(
				pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s rd:%x, wr:%x, start:%x, end:%x\n",
				__func__, msgq_temp->rd, msgq_temp->wr,msgq_temp->start, msgq_temp->end);
			ret = -ENXIO;
			goto OUT;
		}
		if (msgq_temp->rd < last_rd) msgq->overflow = false;
		need_flash = false;
		is_read = 1;
	}
	/* Decide the start addr where to put msg_header */
	if (msgq_temp->wr + sizeof(hdr) > msgq_temp->end) {
		hdr_pos = msgq_temp->start;
		msgq->overflow = true;
	} else {
		hdr_pos = msgq_temp->wr;
	}
	msgq_temp->wr = hdr_pos + sizeof(hdr);

	/* Decide the start addr where to put the leading msg */
	if (msgq_temp->wr + data_size > msgq_temp->end) {
		data_pos = msgq_temp->start;
		msgq->overflow = true;
		hdr.overflow = 1;
	} else {
		data_pos = msgq_temp->wr;
	}
	msgq_temp->wr = data_pos + data_size;

	/* only trigger once */
	if(IF_NEED_FETCH(msgq_temp->wr, msgq_temp->rd, msgq->overflow) && !is_read) {
		need_flash = true;
		goto FLASH_MSGQ;
	}

	if (msgq_temp->wr == msgq_temp->rd) {
		VASTAI_PCI_ERR(
			pci_info, vastai_pci_get_die_id(pci_info, die_index),
			"%s wr = rd = 0x%x, pls check is smcu reinit? or init failed\n",
			__func__, msgq_temp->wr);
		ret = -ENOMEM;
		goto OUT;
	}

	vastai_pci_mem_write(pci_info, die_index, (u64)hdr_pos, &hdr, sizeof(hdr));
	vastai_pci_mem_write(pci_info, die_index, (u64)data_pos, data, data_size);

	VASTAI_PCI_DBG(pci_info, vastai_pci_get_die_id(pci_info, die_index),
		       "%s wr:0x%x, rd:0x%x\n", __func__, msgq_temp->wr,
		       msgq_temp->rd);
	mb();
	ret = vastai_pci_mem_write(pci_info, die_index,
				   msg_addr + offsetof(struct vastai_msgq, wr),
				   &(msgq_temp->wr), 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s mem_write err, ret=%d\n", __func__, ret);
	}
OUT:
	spin_unlock_irqrestore(&msgq->msgq_lock, irq_flag);
	return ret;
}

int vastai_pci_msgq_wr_spe_sriov(struct msgq *msgq, void *data, u32 data_size)
{
	struct vastai_pci_info *pci_info = get_die(msgq)->pci_info;
	int die_index = get_die(msgq)->die_index;
	struct vastai_msgq *msgq_temp = &msgq->msgq_cache;
	struct msgq_header hdr = { 0 };
	u32 hdr_pos;
	u32 data_pos;
	int ret = 0;
	u64 msg_addr = msgq->addr;
	unsigned long irq_flag;
	u32 is_read = 0;
	bool need_flash = false;
	u32 last_rd;

	hdr.type = (data_size == 4) ? 0 : 1;
	if (vastai_check_msgq_data_size(data_size)) {
		VASTAI_PCI_ERR(pci_info, vastai_pci_get_die_id(pci_info, die_index),
					   "%s msgq data_size(%d) illegal\n", __func__, data_size);
	}
	spin_lock_irqsave(&msgq->msgq_lock, irq_flag);
FLASH_MSGQ:
	if (msgq_temp->wr == msgq_temp->rd || need_flash) {
		last_rd = msgq_temp->rd;
		ret = vastai_pci_mem_read_direct(pci_info, die_index, msg_addr,
					  msgq_temp,
					  sizeof(*msgq_temp));
		if (ret) {
			VASTAI_PCI_ERR(pci_info,
				       vastai_pci_get_die_id(pci_info, die_index),
				       "%s mem_read err, ret=%d\n", __func__, ret);
			goto OUT;
		}

		if (msgq_fifo_is_break(msgq_temp)) {
			VASTAI_PCI_ERR(
				pci_info, vastai_pci_get_die_id(pci_info, die_index),
				"%s rd:%x, wr:%x, start:%x, end:%x\n",
				__func__, msgq_temp->rd, msgq_temp->wr,msgq_temp->start, msgq_temp->end);
			ret = -ENXIO;
			goto OUT;
		}
		if (msgq_temp->rd < last_rd) msgq->overflow = false;
		need_flash = false;
		is_read = 1;
	}
	/* Decide the start addr where to put msg_header */
	if (msgq_temp->wr + sizeof(hdr) > msgq_temp->end) {
		hdr_pos = msgq_temp->start;
		msgq->overflow = true;
	} else {
		hdr_pos = msgq_temp->wr;
	}
	msgq_temp->wr = hdr_pos + sizeof(hdr);

	/* Decide the start addr where to put the leading msg */
	if (msgq_temp->wr + data_size > msgq_temp->end) {
		data_pos = msgq_temp->start;
		msgq->overflow = true;
		hdr.overflow = 1;
	} else {
		data_pos = msgq_temp->wr;
	}
	msgq_temp->wr = data_pos + data_size;

	/* only trigger once */
	if(IF_NEED_FETCH(msgq_temp->wr, msgq_temp->rd, msgq->overflow) && !is_read) {
		need_flash = true;
		goto FLASH_MSGQ;
	}

	if (msgq_temp->wr == msgq_temp->rd) {
		VASTAI_PCI_ERR(
			pci_info, vastai_pci_get_die_id(pci_info, die_index),
			"%s wr = rd = 0x%x, pls check is smcu reinit? or init failed\n",
			__func__, msgq_temp->wr);
		ret = -ENOMEM;
		goto OUT;
	}

	vastai_pci_mem_write_direct(pci_info, die_index, (u64)hdr_pos, &hdr, sizeof(hdr));
	vastai_pci_mem_write_direct(pci_info, die_index, (u64)data_pos, data, data_size);

	VASTAI_PCI_DBG(pci_info, vastai_pci_get_die_id(pci_info, die_index),
		       "%s wr:0x%x, rd:0x%x\n", __func__, msgq_temp->wr,
		       msgq_temp->rd);
	mb();
	ret = vastai_pci_mem_write_direct(pci_info, die_index,
				   msg_addr + offsetof(struct vastai_msgq, wr),
				   &(msgq_temp->wr), 4);
	if (ret) {
		VASTAI_PCI_ERR(pci_info,
			       vastai_pci_get_die_id(pci_info, die_index),
			       "%s mem_write err, ret=%d\n", __func__, ret);
	}
OUT:
	spin_unlock_irqrestore(&msgq->msgq_lock, irq_flag);
	return ret;
}

int vastai_pci_vmsgq_wr(struct vmsgq *vmsgq, void *data, u32 data_size)
{
	int ret = 0;
	struct msgq* msgq;
	unsigned long irq_flag;
	spin_lock_irqsave(&vmsgq->vmsgq_lock, irq_flag);
	msgq = vmsgq->ptr;
	ret = vmsgq->msgq_wr_hdl(msgq, data, data_size);
	spin_unlock_irqrestore(&vmsgq->vmsgq_lock, irq_flag);
	return ret;
}

int vastai_pci_vmsgq_wr_spe(struct vmsgq *vmsgq, void *data, u32 data_size)
{
	int ret = 0;
	struct msgq* msgq;
	unsigned long irq_flag;
	spin_lock_irqsave(&vmsgq->vmsgq_lock, irq_flag);
	msgq = vmsgq->ptr;
	ret = vmsgq->msgq_spe_wr_hdl(msgq, data, data_size);
	spin_unlock_irqrestore(&vmsgq->vmsgq_lock, irq_flag);
	return ret;
}


