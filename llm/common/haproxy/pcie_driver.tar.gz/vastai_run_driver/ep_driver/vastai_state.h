#ifndef __VASTAI_STATE_H__
#define __VASTAI_STATE_H__

#include "vastai_pci.h"
#include "vastai_pci_api.h"

#define VASTAI_STATE_TRANSIT_SUCCESS 0

int vastai_pci_state_boot_start(struct vastai_pci_info* priv);
void vastai_pci_state_boot_done(struct vastai_pci_info* priv);
void vastai_pci_state_reset_start(struct vastai_pci_info* priv);
void vastai_pci_state_reset_done(struct vastai_pci_info* priv);
int vastai_pci_state_update_start(struct vastai_pci_info* priv, int die_id);
void vastai_pci_state_update_done(struct vastai_pci_info* priv, int die_id);
void vastai_pci_state_power_off(struct vastai_pci_info* priv);
void vastai_pci_state_sync_error(struct vastai_pci_info* priv);
void vastai_pci_state_debug(struct vastai_pci_info* priv);
int vastai_get_pci_state(struct vastai_pci_info* priv);
int vastai_pci_state_change(struct vastai_pci_info* priv, u8 cur_state, u8 next_state);
char* state_name(int state);

#endif
