#include <linux/version.h>
#include <linux/mempool.h>
#include <linux/mm.h>
#include <linux/kmemleak.h>

#include "vastai_pci.h"
#include "vastai_dmabuf.h"

#define VASTAI_POOL_NUM 11

#if defined(CONFIG_DEBUG_SLAB) || defined(CONFIG_SLUB_DEBUG_ON)
static void poison_error(mempool_t *pool, void *element, size_t size,
			 size_t byte)
{
	const int nr = pool->curr_nr;
	const int start = max_t(int, byte - (BITS_PER_LONG / 8), 0);
	const int end = min_t(int, byte + (BITS_PER_LONG / 8), size);
	int i;

	pr_err("BUG: mempool element poison mismatch\n");
	pr_err("Mempool %p size %zu\n", pool, size);
	pr_err(" nr=%d @ %p: %s0x", nr, element, start > 0 ? "... " : "");
	for (i = start; i < end; i++)
		pr_cont("%x ", *(u8 *)(element + i));
	pr_cont("%s\n", end < size ? "..." : "");
	dump_stack();
}

static void __check_element(mempool_t *pool, void *element, size_t size)
{
	u8 *obj = element;
	size_t i;

	for (i = 0; i < size; i++) {
		u8 exp = (i < size - 1) ? POISON_FREE : POISON_END;

		if (obj[i] != exp) {
			poison_error(pool, element, size, i);
			return;
		}
	}
	memset(obj, POISON_INUSE, size);
}

static void check_element(mempool_t *pool, void *element)
{
	/* Mempools backed by slab allocator */
	if (pool->free == mempool_free_slab || pool->free == mempool_kfree) {
		__check_element(pool, element, ksize(element));
	} else if (pool->free == mempool_free_pages) {
		/* Mempools backed by page allocator */
		int order = (int)(long)pool->pool_data;
		void *addr = kmap_atomic((struct page *)element);

		__check_element(pool, addr, 1UL << (PAGE_SHIFT + order));
		kunmap_atomic(addr);
	}
}

static void __poison_element(void *element, size_t size)
{
	u8 *obj = element;

	memset(obj, POISON_FREE, size - 1);
	obj[size - 1] = POISON_END;
}

static void poison_element(mempool_t *pool, void *element)
{
	/* Mempools backed by slab allocator */
	if (pool->alloc == mempool_alloc_slab || pool->alloc == mempool_kmalloc) {
		__poison_element(element, ksize(element));
	} else if (pool->alloc == mempool_alloc_pages) {
		/* Mempools backed by page allocator */
		int order = (int)(long)pool->pool_data;
		void *addr = kmap_atomic((struct page *)element);

		__poison_element(addr, 1UL << (PAGE_SHIFT + order));
		kunmap_atomic(addr);
	}
}
#else /* CONFIG_DEBUG_SLAB || CONFIG_SLUB_DEBUG_ON */
static inline void check_element(mempool_t *pool, void *element)
{
}
static inline void poison_element(mempool_t *pool, void *element)
{
}
#endif /* CONFIG_DEBUG_SLAB || CONFIG_SLUB_DEBUG_ON */

static __always_inline void add_element(mempool_t *pool, void *element)
{
	BUG_ON(pool->curr_nr >= pool->min_nr);
	poison_element(pool, element);
	pool->elements[pool->curr_nr++] = element;
}

static void *remove_element(mempool_t *pool)
{
	void *element = pool->elements[--pool->curr_nr];

	BUG_ON(pool->curr_nr < 0);
	check_element(pool, element);
	return element;
}

static int _mempool_resize(mempool_t *pool, int new_min_nr)
{
	void *element;
	void **new_elements;
	unsigned long flags;

	BUG_ON(new_min_nr <= 0);
	might_sleep();

	spin_lock_irqsave(&pool->lock, flags);
	if (new_min_nr <= pool->min_nr) {
		while (new_min_nr != pool->min_nr) {
			element = remove_element(pool);
			pool->min_nr--;
			spin_unlock_irqrestore(&pool->lock, flags);
			pool->free(element, pool->pool_data);
			spin_lock_irqsave(&pool->lock, flags);
		}
		goto out_unlock;
	}
	spin_unlock_irqrestore(&pool->lock, flags);

	/* Grow the pool */
	new_elements = kmalloc_array(new_min_nr, sizeof(*new_elements),
				     GFP_KERNEL);
	if (!new_elements)
		return -ENOMEM;

	spin_lock_irqsave(&pool->lock, flags);
	if (unlikely(new_min_nr <= pool->min_nr)) {
		/* Raced, other resize will do our work */
		spin_unlock_irqrestore(&pool->lock, flags);
		kfree(new_elements);
		goto out;
	}
	memcpy(new_elements, pool->elements,
			pool->curr_nr * sizeof(*new_elements));
	kfree(pool->elements);
	pool->elements = new_elements;

	while (new_min_nr != pool->min_nr) {
		spin_unlock_irqrestore(&pool->lock, flags);
		element = pool->alloc(GFP_KERNEL, pool->pool_data);
		if (!element)
			goto out;
		spin_lock_irqsave(&pool->lock, flags);
		if (pool->curr_nr < pool->min_nr) {
			add_element(pool, element);
			pool->min_nr++;
		} else {
			spin_unlock_irqrestore(&pool->lock, flags);
			pool->free(element, pool->pool_data);	/* Raced */
			goto out;
		}
	}
out_unlock:
	spin_unlock_irqrestore(&pool->lock, flags);
out:
	return 0;
}



void *_mempool_alloc(mempool_t *pool, gfp_t gfp_mask)
{
	unsigned long flags;

	spin_lock_irqsave(&pool->lock, flags);
	if (likely(pool->curr_nr)) {
		void * element = remove_element(pool);
		spin_unlock_irqrestore(&pool->lock, flags);
		/* paired with rmb in mempool_free(), read comment there */
		smp_wmb();
		/*
		 * Update the allocation stack trace as this is more useful
		 * for debugging.
		 */
		kmemleak_update_trace(element);
		return element;
	}
	spin_unlock_irqrestore(&pool->lock, flags);
	return NULL;
#if 0
	/* Let's wait for someone else to return an element to @pool */
	init_wait(&wait);
	prepare_to_wait(&pool->wait, &wait, TASK_UNINTERRUPTIBLE);

	spin_unlock_irqrestore(&pool->lock, flags);

	/*
	 * FIXME: this should be io_schedule().  The timeout is there as a
	 * workaround for some DM problems in 2.6.18.
	 */
	io_schedule_timeout(5*HZ);

	finish_wait(&pool->wait, &wait);
	goto repeat_alloc;
#endif
}

void _mempool_free(void *element, mempool_t *pool)
{
	if (unlikely(element == NULL))
		return;

	if (unlikely(READ_ONCE(pool->curr_nr) < pool->min_nr)) {
		unsigned long flags;

		spin_lock_irqsave(&pool->lock, flags);
		if (likely(pool->curr_nr < pool->min_nr)) {
			add_element(pool, element);
			spin_unlock_irqrestore(&pool->lock, flags);
//			wake_up(&pool->wait);
			return;
		}
		spin_unlock_irqrestore(&pool->lock, flags);
	}
	pool->free(element, pool->pool_data);
}


struct vastai_mem_pool_element {
	struct vastai_pci_info *pci_info;
	int order;
	atomic_t used_count;
	mempool_t *pool;
	spinlock_t pool_lock;
};

struct vastai_mem_pool_ex {
	struct vastai_pci_info *pci_info;
	struct vastai_mem_pool_element element[VASTAI_POOL_NUM];
};

static size_t order_to_size(unsigned int order)
{
	return (size_t)PAGE_SIZE << order;
}

static void *vastai_mempool_ex_node_alloc(gfp_t gfp_mask, void *pool_data)
{
	struct vastai_mem_pool_element *vastai_pool =
		(struct vastai_mem_pool_element *)pool_data;

	struct vastai_dma_buf *dm = vastai_dma_buf_create(
		vastai_pool->pci_info, order_to_size(vastai_pool->order), gfp_mask);

	if (!dm)
		return NULL;
	dm->is_from_pool_ex = true;
	return dm;
}

static void vastai_mempool_ex_node_free(void *element, void *pool_data)
{
	struct vastai_dma_buf *dm = (struct vastai_dma_buf *)element;

	vastai_dma_buf_destroy(dm);
}

struct vastai_dma_buf *vastai_mempool_ex_get(struct vastai_pci_info *pci_info,
					  size_t size)
{
	struct vastai_dma_buf *dm;
	int order;
	unsigned long flags;
	if (!pci_info) {
		return NULL;
	}

	/* we check vastai_pool inited, if not, we return alloc failed */
	if (!pci_info->vastai_pool_ex) {
		return NULL;
	}

	order = get_order(size);

	spin_lock_irqsave(&pci_info->vastai_pool_ex->element[order].pool_lock, flags);
retry:

	dm = _mempool_alloc(pci_info->vastai_pool_ex->element[order].pool, GFP_KERNEL);
	if (!dm) {
		u32 count = pci_info->vastai_pool_ex->element[order].pool->min_nr + 1;
		int ret;
		ret = _mempool_resize(pci_info->vastai_pool_ex->element[order].pool, count);
		if (!ret) {
			goto retry;
		}
		else {
			spin_unlock_irqrestore(&pci_info->vastai_pool_ex->element[order].pool_lock, flags);
			return NULL;
		}
	}
	atomic_inc(&pci_info->vastai_pool_ex->element[order].used_count);
	spin_unlock_irqrestore(&pci_info->vastai_pool_ex->element[order].pool_lock, flags);
	return dm;
}

void vastai_mempool_ex_put(struct vastai_pci_info *pci_info,
		  struct vastai_dma_buf *dm)
{
	int order;

	order = get_order(dm->size);
	_mempool_free(dm, pci_info->vastai_pool_ex->element[order].pool);
	atomic_dec(&pci_info->vastai_pool_ex->element[order].used_count);
}

int vastai_mempool_ex_init(struct vastai_pci_info *pci_info)
{
	int i;
	struct vastai_mem_pool_ex  *vastai_pool_ex =
		kzalloc(sizeof(struct vastai_mem_pool_ex), GFP_KERNEL);

	if (!vastai_pool_ex) {
		return -EINVAL;
	}

	vastai_pool_ex->pci_info = pci_info;

	pci_info->vastai_pool_ex = vastai_pool_ex;
	for (i = 0; i < VASTAI_POOL_NUM; i++) {
		spin_lock_init(&pci_info->vastai_pool_ex->element[i].pool_lock);
		pci_info->vastai_pool_ex->element[i].order = i;
		pci_info->vastai_pool_ex->element[i].pci_info = pci_info;
		atomic_set(&pci_info->vastai_pool_ex->element[i].used_count, 0);
		pci_info->vastai_pool_ex->element[i].pool =
			mempool_create(VASTAI_MEM_POOL_MIN_NR,
				       vastai_mempool_ex_node_alloc,
				       vastai_mempool_ex_node_free, &vastai_pool_ex->element[i]);
			if (!pci_info->vastai_pool_ex->element[i].pool)
				goto FREE_MEMPOOL;
	}

	return 0;
FREE_MEMPOOL:
	for (i = 0; i < VASTAI_POOL_NUM; i++) {
		if (pci_info->vastai_pool_ex->element[i].pool) {
			mempool_destroy(pci_info->vastai_pool_ex->element[i].pool);
		} else {
			break;
		}
	}
	kfree (pci_info->vastai_pool_ex);
	return -1;
}

void vastai_mempool_ex_deinit(struct vastai_pci_info *pci_info)
{
	int i;
	if (!pci_info->vastai_pool_ex)
		return;
	for (i = 0; i < VASTAI_POOL_NUM; i++) {
		if (pci_info->vastai_pool_ex->element[i].pool) {
			mempool_destroy(pci_info->vastai_pool_ex->element[i].pool);
		}
	}

	kfree(pci_info->vastai_pool_ex);
}
void vastai_show_mempool_ex(struct vastai_pci_info *pci_info)
{
	int i;
	for (i = 0; i < VASTAI_POOL_NUM; i++) {
		if (pci_info->vastai_pool_ex->element[i].pool) {
			VASTAI_PCI_INFO(
				pci_info, DUMMY_DIE_ID,
				"pool size:0x%lx, total count:%u, used count:%d, cur:%d\n",
				order_to_size(pci_info->vastai_pool_ex->element[i].order),
				pci_info->vastai_pool_ex->element[i].pool->min_nr,
				atomic_read(&(pci_info->vastai_pool_ex->element[i].used_count)),
				pci_info->vastai_pool_ex->element[i].pool->curr_nr);
		}
	}
}
void vastai_reset_mempool_ex(struct vastai_pci_info *pci_info)
{
	int i;
	for (i = 0; i < VASTAI_POOL_NUM; i++) {
		if (pci_info->vastai_pool_ex->element[i].pool) {
			_mempool_resize(pci_info->vastai_pool_ex->element[i].pool,
					VASTAI_MEM_POOL_MIN_NR);
		}
	}
}

