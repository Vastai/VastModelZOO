#include "vastai_pci.h"


static bool is_mmio_addr(struct vastai_pci_info *priv, unsigned int die_id,
				u64 addr, size_t size)
{
	u64 die_offset = die_id * VASTAI_DIE1_BASE;
	u64 absolute_addr = die_offset | addr;

	absolute_addr = priv->addr->p_trans_addr(priv, die_id, addr, absolute_addr);

	if ((absolute_addr >= priv->bar[VASTAI_PCI_BAR0].at_addr) &&
	    ((absolute_addr + size) < priv->bar[VASTAI_PCI_BAR0].at_addr +
			    priv->bar[VASTAI_PCI_BAR0].mmio_len)) {
		return true;
	} else if ((absolute_addr >= priv->bar[VASTAI_PCI_BAR1].at_addr) &&
		   ((absolute_addr + size) < priv->bar[VASTAI_PCI_BAR1].at_addr +
				   priv->bar[VASTAI_PCI_BAR1].mmio_len)) {
		return true;
	} else if ((absolute_addr >= priv->bar[VASTAI_PCI_BAR2].at_addr) &&
		   ((absolute_addr + size) < priv->bar[VASTAI_PCI_BAR2].at_addr +
				   priv->bar[VASTAI_PCI_BAR2].mmio_len)) {
		return true;
	} else if((absolute_addr >= priv->bar[VASTAI_PCI_BAR4].at_addr) &&
		  ((absolute_addr + size) < priv->bar[VASTAI_PCI_BAR4].at_addr +
				   priv->bar[VASTAI_PCI_BAR4].mmio_len)){
		return true;
	}

	return false;
}

/* 传输层read，不感知dma传输或者mmio读取，优先使用mmio读取，不允许切bar */
int vastai_pci_tl_read(struct vastai_pci_info *priv, unsigned int die_id,
				u64 dev_addr, void *data, size_t size)
{
	int ret;

	if(is_mmio_addr(priv, die_id, dev_addr, size)) {
		ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
							dev_addr, data, size);
		if (ret < 0)
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx, len=%d, error:%d\n",
				       __func__, dev_addr, (int)(size), ret);
	} else {
		struct vastai_dmadesc desc;
		union core_bitmap core_id = {.val = 0}; /* no core need be tirgger */
		void *vir_addr_malloc = 0;
		void *vir_addr_4K = 0;

		if(dev_addr % PAGE_SIZE) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx not page size align\n",
				       __func__, dev_addr);
		}

		vir_addr_malloc = vmalloc(size + PAGE_SIZE);
		if(!vir_addr_malloc) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: failed to vmalloc\n",
				       __func__);
			return -ENOMEM;
		}

		vir_addr_4K = (void*)PAGE_ALIGN((u64)vir_addr_malloc);

		desc.is_src_dma_addr		= 0;
		desc.is_host_to_dev		= 0;	// read
		desc.is_src_not_user_mem	= 1;
		desc.host_addr.dma_addr		= 0;
		desc.host_addr.vir_addr		= vir_addr_4K;
		desc.dev_addr			= dev_addr;
		desc.dma_lenth			= size;

		VASTAI_PCI_DBG(priv, die_id, "read use dma!\n");
		ret = priv->addr->p_dma_transfer_sync(priv, vastai_pci_get_die_index(priv, die_id), core_id, &desc, 1, -1);
		if (ret) {
			VASTAI_PCI_ERR(priv, die_id, "%s: dma transfer fail, ret = %d\n", __func__, ret);
		}
		memcpy(data, vir_addr_4K, size);
		vfree(vir_addr_malloc);
	}

	return ret;
}

/* 传输层write，不感知dma传输或者mmio写入，优先使用mmio写入，不允许切bar */
int vastai_pci_tl_write(struct vastai_pci_info *priv, unsigned int die_id,
				u64 dev_addr, void *data, size_t size)
{
	int ret;

	if(is_mmio_addr(priv, die_id, dev_addr, size)) {
		ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
							dev_addr, data, size);
		if (ret < 0)
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [write] 0x%llx, len=%d, error:%d\n",
				       __func__, dev_addr, (int)(size), ret);
	} else {
		struct vastai_dmadesc desc;
		union core_bitmap core_id = {.val = 0}; /* no core need be tirgger */
		void *vir_addr_malloc = 0;
		void *vir_addr_4K = 0;

		if(dev_addr % PAGE_SIZE) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx not page size align\n",
				       __func__, dev_addr);
		}

		vir_addr_malloc = vmalloc(size + PAGE_SIZE);
		if(!vir_addr_malloc) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: failed to vmalloc\n",
				       __func__);
			return -ENOMEM;
		}

		vir_addr_4K = (void*)PAGE_ALIGN((u64)vir_addr_malloc);
		memcpy(vir_addr_4K, data, size);

		desc.is_src_dma_addr		= 0;
		desc.is_host_to_dev		= 1;	// write
		desc.is_src_not_user_mem	= 1;
		desc.host_addr.dma_addr 	= 0;
		desc.host_addr.vir_addr 	= vir_addr_4K;
		desc.dev_addr			= dev_addr;
		desc.dma_lenth			= size;

		VASTAI_PCI_DBG(priv, die_id, "write use dma!\n");
		ret = priv->addr->p_dma_transfer_sync(priv, vastai_pci_get_die_index(priv, die_id), core_id, &desc, 1, -1);
		if (ret) {
			VASTAI_PCI_ERR(priv, die_id, "%s: dma transfer fail, ret = %d\n", __func__, ret);
		}
		vfree(vir_addr_malloc);
	}

	return ret;
}

