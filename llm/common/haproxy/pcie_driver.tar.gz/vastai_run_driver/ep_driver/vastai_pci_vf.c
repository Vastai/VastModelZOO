/*
 * vastai_pci_vf
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/10/13
 * Author: xiangming.yang
 */
#include <linux/rtc.h>
#include <linux/timer.h>
#include <linux/delay.h>

#include "vastai_pci.h"
#include "vastai_die.h"
#include "vastai_pci_api.h"
#include "vastai_pci_vf.h"
#include "vastai_state.h"
#include "vastai_udma_engine.h"

#define SRIOV_INFO_MAGIC 0x76697274 /* virt */

void vastai_notify_peer_msg(struct vastai_pci_info* priv, int die_id)
{
	struct pcie_transfer_info cmd = {0};
	u32 msgq_id;

	cmd.type = VASTAI_PEER_CMD;
	msgq_id = vastai_get_msgq_id(priv, MSGQ_CMD);
	vastai_pci_vmsgq_wr(&(priv->dies[die_id].vmsgq[msgq_id]), &cmd, sizeof(cmd));
}

static void vastai_send_msg_to_peer(struct vastai_pci_info* priv, int die_id, struct vastai_os_msg* src)
{
	int ret;
	u32 fifo_addr = priv->vf_fifo.local_addr;
	int die_index = vastai_pci_get_die_index(priv, die_id);

	ret = vastai_fifo_push_elem(priv, die_index, fifo_addr, src, NULL);
	if(ret) {
		VASTAI_PCI_ERR(priv, die_id, "msg to peer failed: %d\n", ret);
	}

	vastai_notify_peer_msg(priv, die_id);
}

void vastai_send_msg_to_peer_test(struct vastai_pci_info* priv, int die_id)
{
	struct vastai_os_msg msg = {0};

	msg.type = 0x1000;
	msg.cmd = 0x2000;

	vastai_send_msg_to_peer(priv, die_id, &msg);
}

void vastai_proc_peer_msg(void *i_die)
{
	struct vastai_sv100_die *die = i_die;
	struct vastai_pci_info* priv = die->pci_info;
	struct vastai_os_msg msg;
	u32 msg_addr = priv->vf_fifo.peer_addr;

	while (!vastai_fifo_pop_elem(priv, die->die_index, msg_addr, &msg, NULL, NORMAL_FIFO)) {
		VASTAI_PCI_INFO(priv, vastai_pci_get_die_id(priv, die->die_index),
				"msg from peer: (%d, %d)\n", msg.type, msg.cmd);
	}
}

void vastai_vf_os_fifo_init(struct vastai_sv100_die *die)
{
	struct vastai_pci_info* priv = die->pci_info;
	struct vastai_fifo fifo = {0};
	u32 fifo_size = VF_FIFO_SIZE;

	vastai_fifo_init_arg(&fifo, ALIGN(sizeof(struct vastai_os_msg), 4), fifo_size);

	if(priv->is_physfn) {
		priv->vf_fifo.local_addr = VF_FIFO_BASE;
		priv->vf_fifo.peer_addr = VF_FIFO_BASE + VF_FIFO_SIZE;
	}
	else {
		priv->vf_fifo.local_addr = VF_FIFO_BASE + VF_FIFO_SIZE;
		priv->vf_fifo.peer_addr = VF_FIFO_BASE;
	}

	/* only init local fifo */
	vastai_pci_mem_write_direct(priv, die->die_index,
			priv->vf_fifo.local_addr, &fifo, sizeof(fifo));
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"init vf_fifo[0x%x, 0x%x]\n", priv->vf_fifo.local_addr, fifo_size);
}

void vastai_pci_config_vf_bar_at(struct vastai_pci_info *priv, int bar)
{
	mutex_lock(&priv->set_bar_lock);

	priv->bar[bar].minish_bar_size = 1;
	switch (bar) {
		case VASTAI_PCI_BAR0:
			priv->bar[bar].at_addr = VASTAI_PCIE_VF_BAR0_AXI_ADDR;
			break;
		case VASTAI_PCI_BAR1:
			priv->bar[bar].at_addr = VASTAI_PCIE_VF_BAR1_AXI_ADDR;
			break;
		case VASTAI_PCI_BAR2:
			priv->bar[bar].at_addr = VASTAI_PCIE_VF_BAR2_AXI_ADDR;
			break;
		case VASTAI_PCI_BAR4:
			priv->bar[bar].at_addr = VASTAI_PCIE_VF_BAR4_AXI_ADDR;
			break;
		default:
			priv->bar[bar].at_addr = VASTAI_PCIE_VF_BAR_RESERVED;
			break;
	}
	mutex_unlock(&priv->set_bar_lock);
}

static char* boot_mode_string(u32 boot_mode)
{
	switch(boot_mode)
	{
	case BOOT_PF_NORMAL:
		return "BOOT_PF_NORMAL";
	case BOOT_PF_SRIOV:
		return "BOOT_PF_SRIOV";
	case BOOT_VF_SRIOV:
		return "BOOT_VF_SRIOV";
	default:
		return "Unknown";
	}
}

static int check_sriov_magic(struct vastai_sv100_die *die)
{
	int ret = 0;
	u32 fw_magic = 0;
	u32 addr = VF_INFO_BASE + offsetof(sriov_info_t, magic);
	ret = vastai_pci_mem_read_direct(die->pci_info, die->die_index,
				addr, &fw_magic, sizeof(u32));
	if (ret != 0 || fw_magic != SRIOV_INFO_MAGIC) {
		VASTAI_PCI_INFO(die->pci_info,
		        vastai_pci_get_die_id(die->pci_info, die->die_index),
		        "sriov magic mismatch: fw(0x%x) and driver(0x%x)\n",
		        fw_magic, SRIOV_INFO_MAGIC);
		ret = -EINVAL;
	}
	return ret;
}

int vastai_get_die_boot_mode(struct vastai_sv100_die *die)
{
	int ret = 0;
	u64 reg_addr;
	int die_index = die->die_index;
	struct vastai_pci_info* priv = die->pci_info;

	if (priv->is_physfn) {
		if (check_sriov_magic(die)) {
			die->boot_mode = BOOT_PF_NORMAL;
			VASTAI_PCI_INFO(priv, vastai_pci_get_die_id(priv, die_index),
			        "use default boot_mode: %s\n",
			        boot_mode_string(die->boot_mode));
			return ret;
		}

		reg_addr = VF_INFO_BASE + offsetof(sriov_info_t, boot_mode);
		ret = vastai_pci_mem_read_direct(priv, die_index, reg_addr,
						&(die->boot_mode), sizeof(u32));
		if (ret) {
			VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die_index),
					"%s read boot mode error: %d\n",
					__func__, ret);
			return ret;
		}
	} else {
		die->boot_mode = BOOT_VF_SRIOV;
	}
	VASTAI_PCI_INFO(priv, vastai_pci_get_die_id(priv, die_index),
	        "boot_mode: %s\n",
	        boot_mode_string(die->boot_mode));

	return ret;
}

static int vastai_get_vf_bdf(struct vastai_pci_info *pci_info)
{
	int ret = 0;
	int die_index = pci_info->dies[VASTAI_DIE0].die_index;
	u32 addr = VF_INFO_BASE + offsetof(sriov_info_t, vf);
	u32 value = 0;
	ret = vastai_pci_mem_read_direct(pci_info, die_index,
				addr, &value, sizeof(u32));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_index,
				"%s read vf bdf error: %d\n", __func__, ret);
		return ret;
	}

	if ((value & 0x7) <= 0 || (value & 0x7) > MAX_SUPPORT_VF) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s invalid vf device 0x%x\n", __func__, value);
		return -ENODEV;
	}

	pci_info->vf_bdf = value;
	VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
			"vf_id: %d\n", pci_info->vf_bdf & 0x7);
	return 0;
}

static int vastai_check_vf_status(struct vastai_pci_info *pci_info)
{
	int ret = 0;
	int die_index = pci_info->dies[VASTAI_DIE0].die_index;
	u32 addr = VF_INFO_BASE + offsetof(sriov_info_t, vf_status);
	u32 value;
	ret = vastai_pci_mem_read_direct(pci_info, die_index,
				addr, &value, sizeof(u32));
	if (ret) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"%s read vf status error: %d\n", __func__, ret);
		return ret;
	}

	if (value != VF_ACTIVATED) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				   "%s vf-%d is not activated\n",
				   __func__, pci_info->vf_bdf & 0x7);
		return -EINVAL;
	}
	return ret;
}

static int vastai_get_vf_info(struct vastai_pci_info *priv)
{
	int ret = 0;

	ret = vastai_check_vf_status(priv);
	if (ret < 0)
		return ret;

	return vastai_get_vf_bdf(priv);
}

static int vastai_vf_die_info_init(struct vastai_pci_info *priv)
{
	union die_index_data index_data = {0};

	index_data.dev_id = priv->dev_id;
	index_data.die_id = VASTAI_DIE0;
	index_data.seq_num = vastai_get_seqnum(priv, index_data.die_id);
	priv->dies[VASTAI_DIE0].die_index = index_data.val;
	priv->dies[VASTAI_DIE0].pci_info = priv;

	return vastai_get_vf_info(priv);
}

static void vastai_vf_timer(struct timer_list *timer)
{
	struct vastai_pci_info *priv = from_timer(priv, timer, vf_timer);

	/* timer should be trigger in next 1s */
	timer->expires = jiffies + 1 * HZ;

	/* trigger timer */
	add_timer(timer);
}


void vastai_vf_timer_init(struct vastai_pci_info *pciv)
{
	timer_setup(&(pciv->vf_timer), vastai_vf_timer, 0);
	vastai_vf_timer(&(pciv->vf_timer));
}


int vastai_pci_vf_init(struct vastai_pci_info *priv)
{
	int ret = 0;
	ret = vastai_pci_state_boot_start(priv);
	if (ret != VASTAI_STATE_TRANSIT_SUCCESS) {
		return ret;
	}

	ret = vastai_vf_die_info_init(priv);
	if (ret < 0)
		return ret;

	/* init software manage source */
	ret = vastai_die_init(&(priv->dies[0]), priv, 0);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "Failed to do die init, error %d\n", ret);
		return ret;
	}
	vastai_pci_state_boot_done(priv);

	if (priv->irq_type == VASTAI_MSIX_IRQ) {
		ret = vastai_send_pcie_cmd(priv, priv->dies[0].die_index,
			   VASTAI_PCIE_SUB_CONFIG_VF_MSIX_ATU, 0);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					   "Failed to config die0's ep ob region for vf msix, error %d\n",
					   ret);
			return ret;
		}
	}
	vastai_pci_get_fw_ver(priv, 0xFFF, true);

	return 0;
}

/**
 * Wait for dma task finish under the conditon that die udma chn mutex held.
 */
int wait_chn_dma_finish(struct vastai_sv100_die* die, struct vastai_udma_chn* chn, int idx)
{
	struct vastai_pci_info *pci_info = die->pci_info;
	int die_id = vastai_pci_get_die_id(pci_info, die->die_index);
	int sleep_cnt = 20;          // sleep up to 10 times
	int sleep_time = 50;         // sleep up to 100ms each time
	int i = 0;
	int ret = 1;
	for (i = 0; i < sleep_cnt; i++) {
		if (!ret) break;
		if(!atomic_read(&chn->ongoing_count)) ret = 0;
		msleep(sleep_time);
	}
	if (ret) {
		VASTAI_PCI_ERR(pci_info, die_id, "%s: die[%d] wait for dma chn[%d]"
					   "idle failed\n", __func__, die_id, idx);
	}
	return ret;
}

#define SRIOV_ENABLE  0
#define SRIOV_DISABLE 1

void vastai_dma_set_resource_sriov(struct vastai_sv100_die* die, int ops)
{
	struct vastai_fifo fifo = {0};
	struct vastai_pci_info* pci_info = die->pci_info;
	u64 dma_desc_fifo_addr;
	u64 trans_info_fifo_addr;
	u32 fifo_size;
	int i;
	int die_id = vastai_pci_get_die_id(pci_info, die->die_index);

	/* reset dma desc fifo */
	for (i = 0; i < VASTAI_DMA_CHN; i++) {
		mutex_lock(&die->udma_chn[i].trans_mutex);

		/* wait for previous dma task to finish */
		wait_chn_dma_finish(die, &die->udma_chn[i], i);

		/* reset dma desc/trans fifo */
		dma_desc_fifo_addr = die->udma_chn[i].udma_config.dma_desc_fifo_addr;
		if (ops == SRIOV_ENABLE) fifo_size = VASTAI_DMA_DESC_VF_OFFSET;
		else fifo_size = VASTAI_DMA_DESC_FIFO_SIZE;
		vastai_fifo_init_arg(&fifo, ALIGN(sizeof(PCIE_xd_desc), 4), fifo_size);
		memcpy(&die->udma_chn[i].dma_desc_fifo, &fifo, sizeof(struct vastai_fifo));
		vastai_pci_mem_write_direct(pci_info, die->die_index,
									dma_desc_fifo_addr, &fifo, sizeof(fifo));

		trans_info_fifo_addr = die->udma_chn[i].udma_config.trans_info_fifo_addr;
		if (ops == SRIOV_ENABLE) fifo_size = VASTAI_DMA_TRANS_INFO_VF_OFFSET;
		else fifo_size = VASTAI_DMA_TRANS_INFO_FIFO_SIZE;
		vastai_fifo_init_arg(&fifo, ALIGN(sizeof(struct pcie_transfer_info), 4),
							 fifo_size);
		memcpy(&die->udma_chn[i].trans_info_fifo, &fifo, sizeof(struct vastai_fifo));
		vastai_pci_mem_write_direct(pci_info, die->die_index,
									trans_info_fifo_addr, &fifo, sizeof(fifo));

		mutex_unlock(&die->udma_chn[i].trans_mutex);
		VASTAI_PCI_DBG(pci_info, die_id, "%s: die[%d] chn[%d] reset OK\n", __func__, die_id, i);

		mb();
	}
	/* reset dma transfer_info fifo */

	if (ops == SRIOV_ENABLE)
		sema_init(&die->credit_sem, VASTAI_PF_SRIOV_DMA_CREDIT_LIMIT);
	else
		sema_init(&die->credit_sem, VASTAI_DMA_CREDIT_LIMIT);
}

void set_die_vmsgq_map(struct vastai_sv100_die* die, int vid, int pid, int ops) {
	int die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);
	unsigned long irq_flags;
	int old_id;
	int new_id;

	spin_lock_irqsave(&(die->vmsgq[vid].vmsgq_lock), irq_flags);

	old_id = die->vmsgq[vid].ptr->msgq_id;
	die->vmsgq[vid].ptr = &die->msgq[pid];
	new_id = die->vmsgq[vid].ptr->msgq_id;

	/* When assigning msgq used by "VM/VF", fetch msgq cache first before use.*/
	if (ops == SRIOV_DISABLE) {
		vastai_pci_msgq_cache_update(die->vmsgq[vid].ptr);
	}

	spin_unlock_irqrestore(&(die->vmsgq[vid].vmsgq_lock), irq_flags);

	VASTAI_PCI_DBG(die->pci_info, die_id, "%s vmsgq[%d] -> pmsgq[%d to %d]"
				   "switched\n", __func__, vid, old_id, new_id);
}

int vastai_pci_vf_activate(struct vastai_pci_info *pci_info, int num_vfs)
{
	struct vastai_sv100_die *die;
	int ops = SRIOV_ENABLE;
	int ret;
	int i;

	if (num_vfs > pci_info->die_num_in_fn) {
		num_vfs = pci_info->die_num_in_fn;
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "vf_num[%d] exceed max_vfs "
						"default to die_num[%d]\n", num_vfs, pci_info->die_num_in_fn);
	}

	for (i = 0; i < num_vfs; i++) {
		die = &pci_info->dies[i];
		if (die->vf_in_use) continue;

		vastai_dma_set_resource_sriov(die, ops);
		set_die_vmsgq_map(die, 1, 0, ops);

		ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[i].die_index,
				   VASTAI_PCIE_SUB_ACTIVATE_VF, 0);
		if (ret < 0)
			return ret;
		/* wait completion int from smcu */
		if (wait_for_completion_timeout(
				&(pci_info->activate_vf_done),
				msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"activate die-%d vf-%d timeout\n",	i, i + 1);
			return -ETIMEDOUT;
		}
		die->vf_in_use = true;
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
			"die-%d vf-%d activated\n", i, i + 1);
		reinit_completion(&(pci_info->activate_vf_done));
	}
	return 0;
}

int vastai_pci_vf_deactivate(struct vastai_pci_info *pci_info)
{
	struct vastai_sv100_die *die;
	int ops = SRIOV_DISABLE;
	int ret;
	int i;

	for (i = 0; i < pci_info->die_num_in_fn; i++) {
		die = &pci_info->dies[i];
		if (!die->vf_in_use) continue;

		ret = vastai_send_pcie_cmd(pci_info, pci_info->dies[i].die_index,
				   VASTAI_PCIE_SUB_DEACTIVATE_VF, 0);
		if (ret < 0)
			return ret;
		/* wait completion int from smcu */
		if (wait_for_completion_timeout(
				&(pci_info->deactivate_vf_done),
				msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				"deactivate die-%d vf-%d timeout\n", i, i + 1);
			return -ETIMEDOUT;
		}

		/**
		 * Keep dma resource reset after vf deactivated, since vf dma fifo would
		 * be checked with "vf-info->vf_activated" if any dma operation finish.
		 * PF must not occupie the space until vf-deactivation cmd sent to smcu
		 * in case that vf_dma_fifo header is polluted by PF dma desc.
		 */
		vastai_dma_set_resource_sriov(die, ops);
		set_die_vmsgq_map(die, 1, 1, ops);
		die->vf_in_use = false;
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
			"die-%d vf-%d deactivated\n", i, i + 1);
		reinit_completion(&(pci_info->deactivate_vf_done));
	}
	return 0;
}

