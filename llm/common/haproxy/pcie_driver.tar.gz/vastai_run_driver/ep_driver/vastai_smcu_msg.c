#include "vastai_pci.h"
#include "vastai_die.h"
#include "vastai_state.h"
#include "vastai_pci_boot.h"
#include "vatools.h"

#ifdef CONFIG_VASTAI_RAS
#include "vastai_ras.h"
#endif

extern vastai_reset_handle g_reset_ai_handle;

u8 core_point_to_heartbeat(u8 core_point)
{
	return core_point + 1;
}

void vastai_pci_msg1_log_read(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	complete(&die->log_comp);
}

static void vastai_print_ecc_entry(void *priv, u64 fifo_addr, u32 die_index)
{
	struct vastai_fifo fifo = { 0 };
	u64 ecc_addr = 0x0;
	struct ecc_entry entry = { 0 };
	union die_index_data die_temp = { .val = die_index };

	vastai_pci_mem_read(priv, die_index, fifo_addr, &fifo, sizeof(fifo));
	ecc_addr = ((fifo.wr - 1) * fifo.elem_size) + fifo_addr + 0x10;

	vastai_pci_mem_read(priv, die_index, ecc_addr, &entry, sizeof(entry));

	VASTAI_PCI_ERR(priv, die_temp.die_id,
		       "[vaerr] Get DDR ECC error addr_l 0x%x addr_h 0x%x\n",
		       entry.addr_1, entry.addr_h);
}

void vastai_pci_msg1_ecc_2bit(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	complete(&die->ecc_2bit_err);
}

void vastai_pci_msg1_ecc_1bit(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	vastai_print_ecc_entry(die->pci_info, ECC_2BIT_BUF, die->die_index);
}

void vastai_pci_msg1_ecc_2bit_flash(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	vastai_print_ecc_entry(die->pci_info, ECC_1BIT_BUF, die->die_index);
}

void vastai_pci_msg1_freq_temp(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_PVT;
	err_head.sub_component = VASTAI_RAS_PVT_SMCU;
	err_head.err_reason = SMCU_OVERTEMP_PROTECTION;
	err_head.err_severity = ERR_NONFATAL;

	ras_add_kern_event(die, err_head, 1, (u32)msg->info[0]);
	//ras_add_other_event(RAS_OTHER_EVENT_TEMP, 3, die->die_index, die->dev_freq, msg->info[0]);
#endif

	if (die->dev_freq > msg->info[0]) {
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"[vawarn] Frequency reduced, due to over-temperature!\n");
	} else {
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"[vawarn] Frequency returned to normal, as temperature returned to normal.\n");
	}
	die->dev_freq = msg->info[0];
}

void vastai_pci_msg1_freq_volt(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_PVT;
	err_head.sub_component = VASTAI_RAS_PVT_SMCU;
	err_head.err_reason = SMCU_OVERCURRENT_PROTECTION;
	err_head.err_severity = ERR_NONFATAL;

	ras_add_kern_event(die, err_head, 1, (u32)msg->info[0]);
	//ras_add_other_event(RAS_OTHER_EVENT_VOLT, 3, die->die_index, die->dev_freq, msg->info[0]);
#endif
	if (die->dev_freq > msg->info[0]) {
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"[vawarn] Frequency reduced, due to over-current!\n");
	} else {
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"[vawarn] Frequency returned to normal, as current returned to normal.\n");
	}
	die->dev_freq = msg->info[0];
}

void vastai_pci_msg1_pcie_err(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	struct vastai_pcie_link_err pcie_link_err = {0};
	int i;

	/* FIXME: read pcie_link_err from csram */
	for (i = 0; i < ARRAY_SIZE(pcie_link_err.err_list); i++) {
		if (((pcie_link_err.error_type >>  (i * 4)) & 0xf) == 2) { /* type 2 is pcie_link error */
			switch (pcie_link_err.err_list[i].sub_err_type) {
			case PCIE_LOCAL_ERROR:
				VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
					"[vaerr] Get PCIe local error, error status = %d\n",
					pcie_link_err.err_list[i].AddrLOrErrSt.ErrSt);
				break;
			case PCIE_LINK_ERROR:
				VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
					"[vaerr] Get PCIe link error, error status = %d\n",
					pcie_link_err.err_list[i].AddrLOrErrSt.ErrSt);
				break;
			case PCIE_DMA_ERROR:
				VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
					"[vaerr] Get PCIe dma error, error status = %d\n",
					pcie_link_err.err_list[i].AddrLOrErrSt.ErrSt);
				break;
			}
		}
	}
}

void vastai_pci_msg1_rw_xspi(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->rw_xspi_msg = msg->val >> 8;
	atomic_set(&(die->xspi_flag), 0);
	complete(&die->rw_xspi);
}

void vastai_pci_msg1_ctrl_cmpl(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	vastai_ctrl_cmd_compeletion(die->pci_info, die->die_index, msg);
}

void vastai_pci_msg1_dma_broken(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
			"Dma list can't append! pls check.\n");
}

void vastai_pci_msg1_powerdown(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	int i;
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_PVT;
	err_head.sub_component = VASTAI_RAS_PVT_BMCU;
	err_head.err_reason = BMCU_POWERDOWN;
	err_head.err_severity = ERR_FATAL;

	ras_add_kern_event(die, err_head, 1, (u32)msg->info[0]);
	//ras_add_other_event(RAS_OTHER_EVENT_BMCU, 1, die->die_index);
#endif
	/* set smcu machine state for each die */
	VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
			"bmcu power down alert occurs, ret=%d.\n", msg->info[0]);
	for (i = 0; i < die->pci_info->die_num_in_fn; i++) {
		vastai_send_pcie_cmd(die->pci_info, die->die_index,
					VASTAI_PCIE_SUB_SET_MACHINE_STATE, 1);
#if 0
		atomic_set(&die->pci_info->pci_state, VASTAI_EXIT_STATE);
#else
		vastai_pci_state_power_off(die->pci_info);
#endif
	}
}

void vastai_pci_msg1_bmcu_xspi(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->pci_info->bmcu_return_val = msg->info[0];
	complete(&(die->pci_info->bmcu_update_comp));
}

void vastai_pci_msg1_smi_ack(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u8 bc = (msg->val >> 16) & 0xFF;
	VASTAI_PCI_DBG(die->pci_info, (u8)die->die_index,
		"recv VASTAI_PCIE_MSG1_SMI_ACK block_id=%d",
		bc);

	if (bc >= 2) {
		VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
			"[ERROR] SMI block count > 2 ");
		die->smi_ack_msg[0] = 0;
		die->smi_ack_msg[1] = 0;
		complete(&die->smi_ack[0]);
		complete(&die->smi_ack[1]);
		return;
	}
	die->smi_ack_msg[bc] = (msg->val >> 8) & 0xFF;
	complete(&die->smi_ack[bc]);
}

void vastai_pci_msg1_core_sync_ack(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	VASTAI_PCI_DBG(die->pci_info, (u8)die->die_index,
		"recv VASTAI_PCIE_MSG1_CORE_TIME_SYNC_ACK\n");
	complete(&die->core_time_sync_ack);
}

u32 ai_core_mask(void);

void vastai_pci_msg1_exception(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_OTHERS;
	err_head.sub_component = VASTAI_RAS_SYSTEM_RESET;
	err_head.err_severity = ERR_NONFATAL;
	err_head.err_reason = RAS_OTHER_EVENT_RST;
#endif

	switch(msg->info[0])
	{
	case CORE_2_CORE_RESET_AI_SYS_HANG_SUBCMD: {
		u32 ai_mask = ai_core_mask();

		die->heartbeat_mask |= ai_mask;
		die->core[CORE_POINT_CMCU].is_exception = true;

#ifdef CONFIG_VASTAI_RAS
		ras_add_kern_event(die, err_head, 2, CORE_POINT_CMCU, RESET_START);
		//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, CORE_POINT_CMCU, RESET_START);
#endif
		schedule_work(&die->core[CORE_POINT_CMCU].exception_work);
		break;
	}
	case CORE_2_CORE_RESET_AI_FINISH_SUBCMD: {
		//设置heart beat
		u32 ai_mask = ai_core_mask();
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
				   "recv RESET_AI_FINISH_SUBCMD \n");
#ifdef CONFIG_VASTAI_RAS
		ras_add_kern_event(die, err_head, 2, CORE_POINT_CMCU, RESET_END);
		//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, CORE_POINT_CMCU, RESET_END);
#endif
		if(die->pci_info->vadev.dev_cap != VASTAI_HW_TYPE_VIDEO_ONLY)
			die->heartbeat_mask &= ~ai_mask;
		event_notify_per_core(&die->core[CORE_POINT_CMCU], RESET_END);
		break;
	}
	case CORE_2_CORE_RESET_VDSP_HANG_SUBCMD: {
		u32 vdsp_mask =  1<<(HEARTBEAT_VDSP0+(msg->info[1]-CORE_POINT_VDSP0));
		//设置heart beat
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
				   "recv vdsp hang subcmd core[%s]\n", die->core[msg->info[1]].cores_info_ref->core_name);
#ifdef CONFIG_VASTAI_RAS
		ras_add_kern_event(die, err_head, 2, msg->info[1], RESET_START);
		//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, msg->info[1], RESET_START);
#endif
		die->heartbeat_mask |= vdsp_mask;
		die->core[msg->info[1]].is_exception = true;
		schedule_work(&die->core[msg->info[1]].exception_work);
		break;
	}
	case CORE_2_CORE_RESET_VDSP_FINISH_SUBCMD:	{
		//设置heart beat
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
				   "recv RESET_VDSP%u_FINISH_SUBCMD\n", msg->info[1] - CORE_POINT_VDSP0);
#ifdef CONFIG_VASTAI_RAS
		ras_add_kern_event(die, err_head, 2, msg->info[1], RESET_END);
		//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, msg->info[1], RESET_END);
#endif
		die->heartbeat_mask &= ~(1<<(msg->info[1] - CORE_POINT_VDSP0 + HEARTBEAT_VDSP0));
		event_notify_per_core(&die->core[msg->info[1]], RESET_END);
		break;
	}
	default:
		break;
	}
}

void vastai_pci_msg1_core_exception(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_OTHERS;
	err_head.sub_component = VASTAI_RAS_SYSTEM_RESET;
	err_head.err_reason = RAS_OTHER_EVENT_RST;
	err_head.err_severity = ERR_NONFATAL;

	ras_add_kern_event(die, err_head, 2, msg->info[0], RESET_END);
	//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, msg->info[0], RESET_START);
#endif

	die->core[msg->info[0]].is_exception = true;
	schedule_work(&die->core[msg->info[0]].exception_work);
}

void vastai_pci_msg1_core_reset_ack(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_OTHERS;
	err_head.sub_component = VASTAI_RAS_SYSTEM_RESET;
	err_head.err_reason = RAS_OTHER_EVENT_RST;
	err_head.err_severity = ERR_NONFATAL;

	ras_add_kern_event(die, err_head, 2, msg->info[0], RESET_END);
	//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, msg->info[0], RESET_END);
#endif

	die->heartbeat_mask &= ~(1 << core_point_to_heartbeat(msg->info[0]));

	event_notify_per_core(&die->core[msg->info[0]], RESET_END);
	VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
		"receive core reset ack core:%s, ret:%x\n",
		die->core[msg->info[0]].cores_info_ref->core_name, msg->info[1]);
}

void vastai_pci_msg1_ve1_fan_warn(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	if (msg->info[0] == 0)
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"ve1s fan speed warn clear.\n");
	else
		VASTAI_PCI_INFO(die->pci_info, (u8)die->die_index,
			"ve1s fan speed warn, ret=%d%%.\n", msg->info[0]);
}

void vastai_pci_msg1_video_excep(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
#ifdef CONFIG_VASTAI_RAS
	struct vastai_ras_err_head err_head;

	err_head.timestamp = vastai_get_host_time_ns()/1000000000;
	err_head.component = VASTAI_RAS_OTHERS;
	err_head.sub_component = VASTAI_RAS_SYSTEM_RESET;
	err_head.err_reason = RAS_OTHER_EVENT_RST;
	err_head.err_severity = ERR_NONFATAL;

	ras_add_kern_event(die, err_head, 2, msg->info[0], msg->info[1]);
	//ras_add_other_event(RAS_OTHER_EVENT_RST, 3, die->die_index, msg->info[0], msg->info[1]);
#endif

	//info[0]:core_id, info[1]:exception num
	event_notify_per_core(&die->core[msg->info[0]], msg->info[1]);
	VASTAI_PCI_ERR(die->pci_info, (u8)die->die_index,
		"recv video exception, core:%s, exp_num:%x\n", die->core[msg->info[0]].cores_info_ref->core_name, msg->info[1]);
}

void vastai_pci_msg1_get_dlc_core_done(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u16 tmp = (u16)(msg->info[1] << 8) | msg->info[0];
	u8 type = (tmp >> 12) & 0xf;
	u8 cfg = msg->info[2];
	u8 die_id = (u8)die->die_index;

	die->harvest_info.type = type;
	die->harvest_info.dlc_cores = tmp;

	if (type == VASTAI_HARVEST_ALL_DLC_ENABLE)
		if (!die->get_dlc_info_cnt) {
			VASTAI_PCI_INFO(die->pci_info, die_id,
				"Harvest: All DLC & ODSP core are enabled.\n");

		}else {
			VASTAI_PCI_DBG(die->pci_info, die_id,
				"Harvest: All DLC & ODSP core are enabled.\n");
		}

	else if (type == VASTAI_HARVEST_TYPE1 || type == VASTAI_HARVEST_TYPE2)
		if (!die->get_dlc_info_cnt) {
			VASTAI_PCI_INFO(die->pci_info, die_id,
				"Harvest: CodecDis=[%d] OakCfgId=[%d] Type=[%d] Harvest_Core=[0x%x] (DLC%d DLC%d DLC%d DLC%d).\n",
				((cfg>>3)&0x1), (cfg&0x7), type, (tmp&0xfff), ((tmp>>9)&0x7),
				((tmp>>6)&0x7), ((tmp>>3)&0x7), (tmp&0x7));
		}else {
			VASTAI_PCI_DBG(die->pci_info, die_id,
				"Harvest: CodecDis=[%d] OakCfgId=[%d] Type=[%d] Harvest_Core=[0x%x] (DLC%d DLC%d DLC%d DLC%d).\n",
				((cfg>>3)&0x1), (cfg&0x7), type, (tmp&0xfff), ((tmp>>9)&0x7),
				((tmp>>6)&0x7), ((tmp>>3)&0x7), (tmp&0x7));
		}
	else if (type == VASTAI_HARVEST_ALL_DLC_DISABLED) {
		die->harvest_info.type = VASTAI_HARVEST_TYPE1;
		if (tmp & 0x1) {
			if (!die->get_dlc_info_cnt) {
				VASTAI_PCI_INFO(die->pci_info, die_id,
					"Harvest: All DLC & ODSP core are not available and disabled.\n");
			} else {
				VASTAI_PCI_DBG(die->pci_info, die_id,
					"Harvest: All DLC & ODSP core are not available and disabled.\n");
			}
		}else {
			if (!die->get_dlc_info_cnt) {
				VASTAI_PCI_INFO(die->pci_info, die_id,
					"Harvest: All DLC core are not available and disabled, All ODSP core are enabled.\n");
			}else {
				VASTAI_PCI_DBG(die->pci_info, die_id,
					"Harvest: All DLC core are not available and disabled, All ODSP core are enabled.\n");
			}
		}
	}
	else if (type == VASTAI_HARVEST_ALL_DLC_AND_ODSP_DISABLED) {
		die->harvest_info.type = VASTAI_HARVEST_TYPE1;
		if (!die->get_dlc_info_cnt) {
			VASTAI_PCI_INFO(die->pci_info, die_id,
				"Harvest: All DLC & ODSP core are not available and disabled.\n");
		} else {
			VASTAI_PCI_DBG(die->pci_info, die_id,
				"Harvest: All DLC & ODSP core are not available and disabled.\n");
		}
	}
	else
		VASTAI_PCI_INFO(die->pci_info, die_id,
			"Harvest: Invalid type.\n");
	complete(&die->get_dlc_core_done);
}

void vastai_pci_msg1_activate_vf_done(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	complete(&die->pci_info->activate_vf_done);
}

void vastai_pci_msg1_deactivate_vf_done(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	complete(&die->pci_info->deactivate_vf_done);
}

void vastai_pci_msg1_max_smi_h(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->max_smi_h = msg->info[0] + (msg->info[1]<<8);
}

void vastai_pci_msg1_max_smi_l(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->max_smi_l = msg->info[0] + (msg->info[1]<<8);
}

extern struct vastai_pci_info *vastai_get_peer_priv(struct vastai_pci_info *priv, u8 *die_id_in_fn);
void vastai_pci_msg1_dpm_evt(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u32 max_smi_l;
	u8 die_id = (u8)die->die_index;
	struct vastai_pci_info *priv = NULL;
	die->max_smi_l =( msg->info[2] << 16) + (msg->info[1] << 8) + msg->info[0];
	max_smi_l = die->max_smi_l;

	priv = vastai_get_peer_priv(die->pci_info, &die_id);
	vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
				VASTAI_PCIE_SUB_DPM_EVENT, max_smi_l);
}

void vastai_pci_msg1_bmcu_new_path_confirm(struct vastai_pci_info *priv, struct smcu_to_host_msg1 *msg)
{
	if(VASTAI_BMCU_BL0_NEW_PATH_IDENTIFY == msg->info[0]) {
		priv->bmcu_dl_addr = VASTAI_BMCU_NEW_PATH_ADDR;
		priv->bl0_dl_addr  = VASTAI_BL0_NEW_PATH_ADDR;
		priv->bl0_read_addr = VASTAI_BL0_READ_BASE_ADDR;
	}
}

void vastai_pci_msg1_dl_with_service(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	struct vastai_pci_info *priv = die->pci_info;

	if(VASTAI_DL_WITH_SERVICE_IDENTIFY == msg->info[2]) {
		priv->bitmap_dl_support = msg->info[0] + (msg->info[1]<<8);
		vastai_send_smcu_cmd(priv, die->die_index,
					VASTAI_SMCU_SUB_DL_WITH_SERVICE_ACK, 0);
	}
}

void vastai_pci_msg1_tc_type(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->pci_info->tc_type = msg->info[0];
	complete(&die->pci_info->tc_type_comp);
}

void vastai_pci_msg1_get_harv_errcode(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	struct vastai_pci_info *priv = die->pci_info;
	u8 err_code = 0;
	u16 card_type = 0;

	err_code = msg->info[0];
	card_type = msg->info[1] | (msg->info[2] << 8);

	if (err_code != 0) {
		if (card_type == 0x01) {
			 //VA1V PN harvest err code
			 if (err_code == 1) {
				VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die->die_index),
					"va1v harvest error: va1v HA chip's harvest config is not 3.\n");
			 }
		}
		else {
			VASTAI_PCI_ERR(priv, vastai_pci_get_die_id(priv, die->die_index),
				"card_type[0x%x] is mismatch harvest error_code[0x%x].\n", card_type, err_code);
		}
	}
}

#ifdef CONFIG_VASTAI_RAS
void vastai_pci_msg1_ras_err(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	queue_work(die->ras_wq, &die->ras_work);
}
#endif

static void vastai_d2d_work(struct work_struct *work)
{
	struct vastai_sv100_die *die;
	u8 die_id;
	struct vastai_pci_info *priv_peer = NULL;
	int retry_cnt = 3000;

	die = container_of(work, struct vastai_sv100_die, d2d_work);
	if (die == NULL || die->pci_info == NULL)
		return;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	while(!(priv_peer = vastai_get_peer_priv(die->pci_info, &die_id))) {
		msleep(1);
		retry_cnt--;
		if(retry_cnt == 0) {
			VASTAI_PCI_ERR(die->pci_info, die_id,
				"%s peer timeout\n", __func__);
			return;
		}
	}
	retry_cnt = 3000;
	while((atomic_read(&priv_peer->pci_state) != VASTAI_NORMAL_STATE)) {
		msleep(1);
		retry_cnt--;
		if(retry_cnt == 0) {
			VASTAI_PCI_ERR(die->pci_info, die_id,
				"%s polling NORMAL_STATE timeout\n", __func__);
			return;
		}
	}

	priv_peer->dies[die_id].pcie_nls[1] = die->pcie_nls[1];
	priv_peer->dies[die_id].pcie_nlw[1] = die->pcie_nlw[1];
	VASTAI_PCI_INFO(die->pci_info, die_id,
		"%s polling NORMAL_STATE done\n", __func__);

	vastai_send_pcie_cmd(priv_peer, priv_peer->dies[die_id].die_index,
				VASTAI_PCIE_SUB_D2D_LINK_ACK, 0);

}
void vastai_pci_msg1_proc_d2d_link(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u8 die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_send_pcie_cmd(die->pci_info, die->pci_info->dies[die_id].die_index,
				VASTAI_PCIE_SUB_D2D_LINK_ACK, 0);

	VASTAI_PCI_INFO(die->pci_info, die_id,
				"d2d GEN%dx%d\n", msg->info[0], msg->info[1]);

	die->pcie_nls[1] = msg->info[0];
	die->pcie_nlw[1] = msg->info[1];

	INIT_WORK(&(die->d2d_work), vastai_d2d_work);
	schedule_work(&die->d2d_work);
}

void vastai_pci_msg1_stop_bw_done(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u8 die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);
	VASTAI_PCI_INFO(die->pci_info, die_id,"stop bw done\n");
	complete(&die->stop_bw_done);
}

void vastai_pci_msg1_read_addr_h(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	u8 die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	die->read_addr_h = msg->info[0] + (msg->info[1]<<8);
	VASTAI_PCI_INFO(die->pci_info, die_id, "read by smcu[0x%x]\n", (die->read_addr_h<<16) + die->read_addr_l);
}

void vastai_pci_msg1_read_addr_l(struct vastai_sv100_die *die, struct smcu_to_host_msg1 *msg)
{
	die->read_addr_l = msg->info[0] + (msg->info[1]<<8);
}

typedef void (*vastai_pci_msg1_hook)(struct vastai_sv100_die *die,
			struct smcu_to_host_msg1 *msg);

vastai_pci_msg1_hook vastai_pci_msg1_hooks[] = {
	[0 ... VASTAI_PCIE_MSG1_DPM_EVENT] = NULL,
	[VASTAI_PCIE_MSG1_LOG_READ] = vastai_pci_msg1_log_read,
	[VASTAI_PCIE_MSG1_ECC_2BIT_ERR] = vastai_pci_msg1_ecc_2bit,
	[VASTAI_PCIE_MSG1_ECC_1BIT_ERR] = vastai_pci_msg1_ecc_1bit,
	[VASTAI_PCIE_MSG1_ECC_2BIT_FROM_FLASH] = vastai_pci_msg1_ecc_2bit_flash,
	[VASTAI_PCIE_MSG1_FREQ_REDUCE_BY_TEMP] = vastai_pci_msg1_freq_temp,
	[VASTAI_PCIE_MSG1_FREQ_REDUCE_BY_VOLT] = vastai_pci_msg1_freq_volt,
	[VASTAI_PCIE_MSG1_PCIE_ERR] = vastai_pci_msg1_pcie_err,
	[VASTAI_PCIE_MSG1_RW_XSPI] = vastai_pci_msg1_rw_xspi,
	[VASTAI_PCIE_MSG1_CTRL_COMPLETION] = vastai_pci_msg1_ctrl_cmpl,
	[VASTAI_PCIE_MSG1_DMA_LIST_BROKEN] = vastai_pci_msg1_dma_broken,
	[VASTAI_PCIE_MSG1_POWER_DOWN_BY_BMCU] = vastai_pci_msg1_powerdown,
	[VASTAI_PCIE_MSG1_BMCU_XSPI_FINISH] = vastai_pci_msg1_bmcu_xspi,
	[VASTAI_PCIE_MSG1_SMI_ACK] = vastai_pci_msg1_smi_ack,
	[VASTAI_PCIE_MSG1_CORE_TIME_SYNC_ACK] = vastai_pci_msg1_core_sync_ack,
	[VASTAI_PCIE_MSG1_EXCEPTION] = vastai_pci_msg1_exception,
	[VASTAI_PCIE_MSG1_CORE_EXCEPTION] = vastai_pci_msg1_core_exception,
	[VASTAI_PCIE_MSG1_CORE_RESET_ACK] = vastai_pci_msg1_core_reset_ack,
	[VASTAI_PCIE_MSG1_VE1_FAN_WARN] = vastai_pci_msg1_ve1_fan_warn,
	[VASTAI_PCIE_MSG1_VIDEO_EXCEPTION] = vastai_pci_msg1_video_excep,
	[VASTAI_PCIE_MSG1_GET_DLC_CORE_DONE] = vastai_pci_msg1_get_dlc_core_done,
	[VASTAI_PCIE_MSG1_ACTIVATE_VF] = vastai_pci_msg1_activate_vf_done,
	[VASTAI_PCIE_MSG1_DEACTIVATE_VF] = vastai_pci_msg1_deactivate_vf_done,
	[VASTAI_PCIE_MSG1_MAX_SMI_H] = vastai_pci_msg1_max_smi_h,
	[VASTAI_PCIE_MSG1_MAX_SMI_L] = vastai_pci_msg1_max_smi_l,
	[VASTAI_PCIE_MSG1_DPM_EVENT] = vastai_pci_msg1_dpm_evt,
	[VASTAI_PCIE_MSG1_TRANSCODING_TYPE] = vastai_pci_msg1_tc_type,
	[VASTAI_PCIE_MSG1_GET_HARV_ERRCODE] = vastai_pci_msg1_get_harv_errcode,
#ifdef CONFIG_VASTAI_RAS
	[VASTAI_PCIE_MSG1_RAS_ERR] = vastai_pci_msg1_ras_err,
#endif
	[VASTAI_PCIE_MSG1_D2D_LINK] = vastai_pci_msg1_proc_d2d_link,
	[VASTAI_PCIE_MSG1_STOP_BW_DONE] = vastai_pci_msg1_stop_bw_done,
	[VASTAI_PCIE_MSG1_READ_ADDR_H] = vastai_pci_msg1_read_addr_h,
	[VASTAI_PCIE_MSG1_READ_ADDR_L] = vastai_pci_msg1_read_addr_l,
};

void vastai_pci_proc_smcu_msg1_spe(void *i_die)
{
	u32 die_index;
	struct vastai_sv100_die *die = i_die;
	unsigned long flags = 0;
	struct vastai_pci_info *priv = die->pci_info;
	struct smcu_to_host_msg1 msg;
	u64 msg1_spe_addr = MSG_SMCUQ1_TO_PCIE + VASTAI_PCIE_MSGQ_1_SIZE;
	u32 die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	if (!die || !die->pci_info)
		return;

	die_index = die->die_index;

	spin_lock_irqsave(&priv->msgq_1_lock, flags);

	while (!vastai_fifo_pop_elem(priv, die_index,
				msg1_spe_addr, &msg, NULL, SPE_FIFO)) {
		switch (msg.type) {
		case VASTAI_PCIE_MSG1_SET_BAR_DONE: {
			complete(&priv->set_bar_done);
			break;
		}
		case VASTAI_PCIE_MSG1_BMCU_NEW_PATH_CONFIRM: {
			if(die_id == 0)
				vastai_pci_msg1_bmcu_new_path_confirm(priv, &msg);
			break;
		}
		case VASTAI_PCIE_SW_ATU_DONE: {
			complete(&priv->switch_atu_comp);
			break;
		}
		case VASTAI_PCIE_MSG1_DL_WITH_SERVICE: {
			vastai_pci_msg1_dl_with_service(die, &msg);
			break;
		}
		case VASTAI_PCIE_MSG1_PEER_DIE_DN_ACK: {
			complete(&die->wait_dn_ack);
			break;
		}
		default:
			break;
		}
	}

	spin_unlock_irqrestore(&priv->msgq_1_lock, flags);
}

int vastai_pop_smcu_msg1_handle(void *pci_info, u32 die_index, int irq, void *ctxt, void *out)
{
	struct vastai_pci_info *priv = pci_info;
	struct smcu_to_host_msg1 *msg = out;
	u32 die_id = vastai_pci_get_die_id(priv, die_index);
	struct vastai_sv100_die *die = &priv->dies[die_id];

	if (msg->type < ARRAY_SIZE(vastai_pci_msg1_hooks)) {
		if (vastai_pci_msg1_hooks[msg->type])
			vastai_pci_msg1_hooks[msg->type](die, msg);
		else
			VASTAI_PCI_ERR(priv, die_id,
				"%s no callback for msg type %d\n", __func__, msg->type);
	} else {
		VASTAI_PCI_ERR(priv, die_id,
			"%s invalid msg type %d\n", __func__, msg->type);
	}

	return 0;
}

void vastai_pci_proc_smcu_msg1(void *i_die)
{
	u32 die_index;
	struct vastai_sv100_die *die = i_die;
	unsigned long flags = 0;
	struct vastai_pci_info *priv = die->pci_info;
	struct smcu_to_host_msg1 msg;
	u64 msg1_addr = MSG_SMCUQ1_TO_PCIE;

	if (!die || !die->pci_info)
		return;

	die_index = die->die_index;
	if (priv->is_virtfn)
		msg1_addr += VASTAI_PCIE_SMCU_1_VF_OFFSET;

	spin_lock_irqsave(&priv->msgq_1_lock, flags);

	while (!vastai_fifo_pop_elem(priv, die_index, msg1_addr, &msg, NULL, NORMAL_FIFO)) {
		vastai_pop_smcu_msg1_handle(priv, die_index, 1, NULL, &msg);
	}
	spin_unlock_irqrestore(&priv->msgq_1_lock, flags);
}

