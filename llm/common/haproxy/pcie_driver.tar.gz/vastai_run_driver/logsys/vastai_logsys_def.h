#ifndef __VASTAI_LOGSYS_DEF_H__
#define __VASTAI_LOGSYS_DEF_H__

#define PC_ENV 0

#define DEBUG_LOG 0

#define VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR 0

#if (PC_ENV == 0)
#include <linux/cdev.h>
#include <linux/kernel.h>
#include <linux/timer.h>
#include <linux/timex.h>
#include <linux/rtc.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#endif

#if (PC_ENV == 1)
#include <malloc.h>
#include <string.h>
#include <stdio.h>
//#include <winbase.h>
#include <Windows.h>
#pragma warning(disable : 4996)
#pragma warning(disable : 4101)
#pragma warning(disable : 4102)
#endif

#if (PC_ENV == 1)
typedef unsigned int u32;
typedef int s32;
typedef unsigned long long u64;
typedef int ssize_t;
typedef int loff_t;
#define HZ 250
#endif

#define _S_LINE(x)  #x
#define __S_LINE(x) _S_LINE(x)

#define LINESTR "LINE[" __S_LINE(__LINE__) "]"

#if (PC_ENV == 0)
#define PACKED __attribute__((packed))
#else
#define PACKED
#define __user
#endif

#if (PC_ENV == 1)
typedef unsigned int atomic_t;
struct mutex {
	CRITICAL_SECTION cs;
};
typedef struct win32_wait_queue_head_t {
	u32 abc;
} wait_queue_head_t;
typedef struct win32_dev_t {
	u32 abc;
} dev_t;
struct cdev {
	u32 abc;
};
struct class {
	u32 abc;
};
struct device {
	u32 abc;
};
struct file_operations {
	u32 abc;
};
struct rtc_time {
	int tm_sec;
	int tm_min;
	int tm_hour;
	int tm_mday;
	int tm_mon;
	int tm_year;
	int tm_wday;
};
#define pr_err	printf
#define pr_info printf
#define __func__ __FUNCTION__
#define __line__	    __LINE__
#define GFP_KERNEL	    0
#define PTR_ERR(a)	    1
#define kzalloc(size, mode) malloc(size)
#define vmalloc(size)	    malloc(size)
#define vfree(p)
#define DECLARE_WAITQUEUE(wait, current) u32 wait, current
#define add_wait_queue(a, b)
#define wake_up(a)
#define TASK_UNINTERRUPTIBLE 0
#define TASK_INTERRUPTIBLE   0
#define TASK_RUNNING	     1
#define set_current_state(a)
#define wait_event_timeout(a, b, c) 1
#define remove_wait_queue(a, b)
#define init_waitqueue_head(a)
#define alloc_chrdev_region(a, b, c, d) 0
#define class_destroy(a)
#define cdev_del(a)
#define unregister_chrdev_region(a, b)
#define kfree(a) free(a)
#define kthread_stop(a)
#define device_destroy(a, b)
void mutex_init(struct mutex *io_pmutex);
void mutex_destroy(struct mutex *io_pmutex);
void mutex_lock(struct mutex *io_pmutex);
void mutex_unlock(struct mutex *io_pmutex);
u64 get_jiffies_64();
#define atomic_set(p, v)		*p = v
#define ENOMEM				12
#define ENOSPC				28
#define container_of(ptr, type, member) (struct vastai_logsys_env *)0
#define copy_to_user(a, b, c)
#define copy_from_user(a, b, c)
#define mm_segment_t	   u32
#define filp_open(a, b, c) (struct file *)0
#define filp_close(a, b)
#define IS_ERR(a)			(a == NULL)
#define fasync_helper(a, b, c, d)	0
#define call_usermodehelper(a, b, c, d) 0
#define get_fs()			0
#define set_fs(a)
#define vfs_write(a, b, c, d)
#define vfs_read(a, b, c, d)
#define vastai_pci_mem_read(a, b, c, d, e)
#define vastai_pci_mem_write(a, b, c, d, e)
struct file {
	void *private_data;
	void *f_pos;
};
struct inode {
	u32 i_cdev;
};
struct vastai_sv100_die {
	u32 die_index;
};
struct vastai_pci_info {
	u32 die_num;
	struct vastai_sv100_die dies[16];
};
#endif

#define VASTAI_LOGSYS_PR_HEAD "logsys081601 " LINESTR " "

#define VASTAI_LOGSYS_BUF_SIZE 0x100000
/*
May be used, need to change according to circumstance.
Used to trace code by find the place to set die count.
*/
//#define VASTAI_LOGSYS_DIE_COUNT							1

#define VASTAI_LOGSYS_DIE_MAXCOUNT 2

#define VASTAI_LOGSYS_CORECOUNT 29

/*
Currently, do not use the mode, set it 0. 
Set it 1 to enable.
*/
#define VASTAI_LOGSYS_LOGBUFFER_ENABLE 0

#define VASTAI_LOGSYS_LOGBUFFER_DELETEFILE_WHENNOTNEED 1

/*
Core type list. 
*/
#define VASTAI_LOGSYS_CORETYPE_CMCU  0x0 // id[0-0]	1
#define VASTAI_LOGSYS_CORETYPE_LMCU  0x1 // id[0-7]	8
#define VASTAI_LOGSYS_CORETYPE_ODSP  0x2 // id[0-7]	8
#define VASTAI_LOGSYS_CORETYPE_VDSP  0x8 // id[0-3]	4
#define VASTAI_LOGSYS_CORETYPE_VDMCU 0xA // id[0-2]	3
#define VASTAI_LOGSYS_CORETYPE_VEMCU 0xB // id[0-3]	4
#define VASTAI_LOGSYS_CORETYPE_SMCU  0xF // id[0-0]	1

#define VASTAI_LOGSYS_COREID_DEFINE_3(t)                                       \
	(t << 6) | 0, (t << 6) | 1, (t << 6) | 2
#define VASTAI_LOGSYS_COREID_DEFINE_4(t)                                       \
	(t << 6) | 0, (t << 6) | 1, (t << 6) | 2, (t << 6) | 3
#define VASTAI_LOGSYS_COREID_DEFINE_8(t)                                       \
	(t << 6) | 0, (t << 6) | 1, (t << 6) | 2, (t << 6) | 3, (t << 6) | 4,  \
		(t << 6) | 5, (t << 6) | 6, (t << 6) | 7

#define VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED 0x8CF3294
#define VASTAI_LOGSYS_CTRL_INITDONE_MAGIC     0x7D3A2E9B
#define VASTAI_LOGSYS_CTRL_STARTADDR_PATH     0x8CF3290
#define VASTAI_LOGSYS_CTRL_STARTADDR_BUF      0x8CF3270

#define VASTAI_LOGSYS_RPWP_STARTADDR 0x8CF30A0
#define VASTAI_LOGSYS_RPWP_SIZE	     0x10

#define VASTAI_LOGSYS_BUF_STARTADDR_LOWADDR  0x12000000
#define VASTAI_LOGSYS_BUF_STARTADDR_HIGHADDR 0x8

enum VASTAI_LOGSYS_TYPE {
	VASTAI_LOGSYS_TYPE_MIN = 0,
	VASTAI_LOGSYS_TYPE_MINMINUSONE = VASTAI_LOGSYS_TYPE_MIN - 1,

	VASTAI_LOGSYS_TYPE_STRING,
	VASTAI_LOGSYS_TYPE_MEMORY,
	VASTAI_LOGSYS_TYPE_TRACEID,
	VASTAI_LOGSYS_TYPE_POINT,

	VASTAI_LOGSYS_TYPE_MAXADDONE,
	VASTAI_LOGSYS_TYPE_MAX = VASTAI_LOGSYS_TYPE_MAXADDONE - 1,
};

enum VASTAI_LOGSYS_LEVEL {
	VASTAI_LOGSYS_LEVEL_MIN = 0,
	VASTAI_LOGSYS_LEVEL_MINMINUSONE = VASTAI_LOGSYS_LEVEL_MIN - 1,

	VASTAI_LOGSYS_LEVEL_ERR,
	VASTAI_LOGSYS_LEVEL_WARN,
	VASTAI_LOGSYS_LEVEL_INFO,
	VASTAI_LOGSYS_LEVEL_DEBUG,

	VASTAI_LOGSYS_LEVEL_MAXADDONE,
	VASTAI_LOGSYS_LEVEL_MAX = VASTAI_LOGSYS_LEVEL_MAXADDONE - 1,
};

#define VASTAI_LOGSYS_PATH_UART 0
#define VASTAI_LOGSYS_PATH_PCIE 1

typedef struct PACKED vastai_logsys_ringbuf {
	u64 ddr_baseaddr;
	u32 wpoffset;
	u32 rpoffset;
} T_VASTAI_LOGSYS_RINGBUF;

/*
logsys kernel part define
*/

#define VASTAI_LOGSYS_MAX_DEVICES 1
#define VASTAI_LOGSYS_DEVICE_NAME "logsys"
#define VASTAI_LOGSYS_PERCORE_USER_MAX                                         \
	8 // include block users, do not include clear buffer user

/*
Limit to kernel kzalloc size limit.
*/
#define VASTAI_LOGSYS_READDDR_BUFSIZE 4096

/*
The log buf size is VASTAI_LOGSYS_BUF_SIZE, when the current log is near 2/3 of all 
buffer, we need to record down to the file so that the log buf will not full.
*/
#define VASTAI_LOGSYS_BUF_NEARFULL 0xC0000

/*
logsys file part define
*/

/*
The logsys file base directory.
The head string of the directory.
*/
#define VASTAI_LOGSYS_FILE_DIR		  "/var/log/vastai/fwlog"
#define VASTAI_LOGSYS_FILE_DIR_MAXLEN	  256
#define VASTAI_LOGSYS_FILE_SPLIT	  "/"
#define VASTAI_LOGSYS_FILE_PCI_TIMEFORMAT "[%d_%d_%d]"
#define VASTAI_LOGSYS_FILE_SUFFIX	  ".txt"

/*
Currently at most 256M.
*/
#define VASTAI_LOGSYS_FILE_MAXSIZE 0x10000000
/*
Currently at most 1M.
*/
#define VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE 0x100000
/*
One log at most 1k(10bits). When memory type, the string length max size will be 
less than the size. Other type, the size is smaller.
*/
#define VASTAI_LOGSYS_USER_READSESSION_BUFFER_MAXSIZE 8192
/*
For original data stored, store only one single log.
*/
#define VASTAI_LOGSYS_USER_READSESSION_TEMPBUFFER_FORONELOG_MAXSIZE 2048

/*
When we use the enum to return driver interface, the value is the negative value 
which the abs is the same.
*/
enum VASTAI_LOGSYS_ENV_ERROR {
	/*
	All no error value should be 0.
	*/
	VASTAI_LOGSYS_ENV_ERROR_NOERROR,

	VASTAI_LOGSYS_ENV_ERROR_MIN = 10000,
	VASTAI_LOGSYS_ENV_ERROR_MINMINUSONE = VASTAI_LOGSYS_ENV_ERROR_MIN - 1,

	VASTAI_LOGSYS_ENV_ERROR_NOMEM,
	VASTAI_LOGSYS_ENV_ERROR_REGISTERDEVICE_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_CDEV_ADD_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_CLASS_CREATE_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_DEVICE_CREATE_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_CREATE_LOGSYS_DIR_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_DELETE_OLD_DIR_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_NEW_DIR_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_REMOVE_CANNOT_FIND_PCI,
	VASTAI_LOGSYS_ENV_ERROR_FILEOPEN_FAIL,
	VASTAI_LOGSYS_ENV_ERROR_FILELIST_ADD_TOOMUCH,
	VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENADD,
	VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET,
	VASTAI_LOGSYS_ENV_ERROR_BINDINFODEF_PUSER_ISNULL_WHENLOGMODE,
	VASTAI_LOGSYS_ENV_ERROR_BINDINFO_PUSER_ISNULL_WHENLOGMODE,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_CLEARBUFFER_WHENPOS_NOTBEGIN,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETSIZE_OVER_INPUTSIZE,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSPOINTER_ISNULL,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETLOGBUFFER_TOTALUNEXPECTED,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OVERINPUT,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OUTOFRANGE,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILELIST_ISEMPTY_WHENGET,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_LOGBUFFER_ISEMPTY_WHENGET,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILEGET_UNEXPECTED_ZERO,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSLEFT_UNEXPECTED_NOTZERO,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POS_UNEXPECTED_OUTOFRANGE,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH,
	VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE,

	VASTAI_LOGSYS_ENV_ERROR_MAXADDONE,
	VASTAI_LOGSYS_ENV_ERROR_MAX = VASTAI_LOGSYS_ENV_ERROR_MAXADDONE - 1,
};

/*
When we use the enum to return driver interface, the value is the negative value 
which the abs is the same.
Recoverable error: you can use write/ioctl operation to change the bind status or 
other status, so that it can recovery.
*/
enum VASTAI_LOGSYS_USER_ERROR {
	/*
	All no error value should be 0.
	*/
	VASTAI_LOGSYS_USER_ERROR_NOERROR = 0,

	VASTAI_LOGSYS_USER_ERROR_MIN = 20000,
	VASTAI_LOGSYS_USER_ERROR_MINMINUSONE = VASTAI_LOGSYS_USER_ERROR_MIN - 1,

	/*
	Can not kzalloc memory.
	*/
	VASTAI_LOGSYS_USER_ERROR_NOMEM,
	/*
	Unknown operation cause user's env is NULL.
	*/
	VASTAI_LOGSYS_USER_ERROR_USERENV_NULL,
	/*
	Unknown operation cause user's env is not input env.
	*/
	VASTAI_LOGSYS_USER_ERROR_USERENV_NOTMATCH,
	/*
	You cannot do two operation at one time of one specific user.
	*/
	VASTAI_LOGSYS_USER_ERROR_TWOOPER_ATONETIME,
	/*
	Currently, we do not record recoverable error down except
	VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE.
	*/
	VASTAI_LOGSYS_USER_ERROR_UNEXPECTED_RECORD,

	//////////////////////////////////////////////////
	// Recoverable error begin
	// Currently, we only will record the VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE
	// error, we will not record other recoverable error.

	VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN,
	VASTAI_LOGSYS_USER_ERROR_NEEDREBIND_MIN =
		VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN,
	VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MINMINUSONE =
		VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN - 1,
	/*
	The error is the only error that need to do rebind operation next 
	otherwise the user will not work.
	The user status will not be set by bg thread, because we need to let 
	user know the pci remove event occurs, so when the user do operation 
	after the event, any operation will return the need rebind by pci 
	remove error, but after that the user can do write operation to change 
	mode info or change mode log before do other operation.
	You need to rebind the correspondent cores.
	It is recoverable error.
	You need to rebind otherwise the user will not work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE,
	VASTAI_LOGSYS_USER_ERROR_NEEDREBIND_MAXADDONE,
	VASTAI_LOGSYS_USER_ERROR_NEEDREBIND_MAX =
		VASTAI_LOGSYS_USER_ERROR_NEEDREBIND_MAXADDONE - 1,
	/*
	You can not set default output log begin offset when info mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_INFO,
	/*
	You can not set default output log begin offset when clear buffer mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_CLEARBUFFER,
	/*
	You can not set default output log begin offset when block mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_BLOCK,
	/*
	You can not set output log begin offset when info mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_INFO,
	/*
	You can not set output log begin offset when clear buffer mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_CLEARBUFFER,
	/*
	You can not set output log begin offset when block mode.
	The user will ignore the current operation.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_BLOCK,
	/*
	The position over the total valid byte.
	It was a info log and the position will goto the newest byte.
	The user will continue work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_POSITIVE,
	/*
	The position over the current begin position.
	It was a info log and the position will goto the current begin.
	The user will continue work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_NEGATIVE,
	/*
	Write operation format error.
	The user will continue work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR,
	/*
	Write operation too long.
	The user will continue work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_TOO_LONG,
	/*
	Write operation format error in common description of pcie die core.
	The user will continue work.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR,
	/*
	Write operation format error when log all pci, set pci -1, which is 
	not allowed.
	When do log operation, the following error will cause current status 
	back to info default init status.
	When do log add operation, the following error will only cause the 
	current log add operation is ignored, the current operation will not 
	affect the previous bind.
	*/
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLPCI_NOTALLOW,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLDIE_NOTALLOW,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_NOCORE_TOBIND,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_CLEARBUFFER_EXIST,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_BLOCKUSER_REACHMAX,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_CURRENTISNOTLOG,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BCLEARBUFFER_NOTMATCH_PREVIOUS,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BBLOCK_NOTMATCH_PREVIOUS,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BINDINFO_ALREADY_EXIST,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGLEVEL_OUTOFRANGE,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGENABLE_VALUEWRONG,
	VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PATH_VALUEWRONG,
	VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE,
	VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_NOBINDTOREAD,

	VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAXADDONE,
	VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAX =
		VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAXADDONE - 1,

	// Recoverable error end
	//////////////////////////////////////////////////

	VASTAI_LOGSYS_USER_ERROR_MAXADDONE,
	VASTAI_LOGSYS_USER_ERROR_MAX = VASTAI_LOGSYS_USER_ERROR_MAXADDONE - 1,
};

enum VASTAI_LOGSYS_MODE {
	/*
	Output info. Do not output log.
	Currently, it is the default mode.
	*/
	VASTAI_LOGSYS_MODE_INFO,
	/*
	Output log when read.
	*/
	VASTAI_LOGSYS_MODE_LOG,
};

enum VASTAI_LOGSYS_CALLER {
	VASTAI_LOGSYS_CALLER_MIN = 0,
	VASTAI_LOGSYS_CALLER_MINMINUSONE = VASTAI_LOGSYS_CALLER_MIN - 1,

	/*
	The default caller is shell cat.
	*/
	VASTAI_LOGSYS_CALLER_SHELLCAT,
	/*
	You should use ioctl to change caller type to caller C.
	*/
	VASTAI_LOGSYS_CALLER_C,

	VASTAI_LOGSYS_CALLER_MAXADDONE,
	VASTAI_LOGSYS_CALLER_MAX = VASTAI_LOGSYS_CALLER_MAXADDONE - 1,
};

enum VASTAI_LOGSYS_STORE {
	VASTAI_LOGSYS_STORE_MIN = 0,
	VASTAI_LOGSYS_STORE_MINMINUSONE = VASTAI_LOGSYS_STORE_MIN - 1,

	/*
	The default store mode is file. When bind the log to a specific 
	user of clear buffer mode, it will change the store path to wait 
	program to get log buffer.
	*/
	VASTAI_LOGSYS_STORE_FILE,
	/*
	When bind the log to a specific user of clear buffer mode, you need 
	to get log from read operation frequently, otherwise, the log buffer 
	will be full and block logic in the code.
	*/
	VASTAI_LOGSYS_STORE_PROGRAM,

	VASTAI_LOGSYS_STORE_MAXADDONE,
	VASTAI_LOGSYS_STORE_MAX = VASTAI_LOGSYS_STORE_MAXADDONE - 1,
};

//////////////////////////////////////////////////////////////////////////
// write operation format begin

/*
write operation example:
[oper_enum]
oper_enum is VASTAI_LOGSYS_OPER_***

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO
output info when read operation
1) output info of all pci
[oper_enum]-1
2) output info of specific pci
[oper_enum]pci_dev_id
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
3) output info of specific die of specific pci
[oper_enum]pci_dev_id:die_index
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG
output log when read operation
format like:
1) output log of all core of specific pci die
[oper_enum][bblock][bclearbuffer]pci_dev_id:die_index:-1
bblock is 1 means the read operation will not return until have log
bblock is 0 means the read operation will return immediately
bclearbuffer is 1 means the read operation will clear the log buffer which is got out
bclearbuffer is 0 means the read operation will not clear the log buffer which is got out
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
-1 means all of the core
2��output log of specific core of specific pci die
[oper_enum][bblock][bclearbuffer]pci_dev_id:die_index:coreidbegin0-coreidend0,coreidbegin1-coreidend1,...
bblock is 1 means the read operation will not return until have log
bblock is 0 means the read operation will return immediately
bclearbuffer is 1 means the read operation will clear the log buffer which is got out
bclearbuffer is 0 means the read operation will not clear the log buffer which is got out
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
coreidbeginN is the begin coreid of begin-end pair index N 
coreidendN is the begin coreid of begin-end pair index N 

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD
add output log when read operation
VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD operation add the log filter on the base of 
previous log.
format like:
1) add output log of all core of specific pci die
bblock and bclearbuffer is the same as the first log entry
[oper_enum]pci_dev_id:die_index:-1
2��output log of specific core of specific pci die
bblock and bclearbuffer is the same as the first log entry
[oper_enum]pci_dev_id:die_index:coreidbegin0-coreidend0,coreidbegin1-coreidend1,...

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_OUTPUTLOG_PERCORE_BEGIN_OFFSET
change the beginning offset of per core log correspondent to the current user when caller 
is program, while to the all of the shell user when caller is shell.
When the caller is shell, you can not set the value when the default log bind info is 
clear buffer mode. Also, when the current user is clear buffer mode, you can not set the 
begin offset. When you set clear buffer mode, the offset will change back to zero.
format like(offset can be positive or negative):
[oper_enum]offset

when oper_enum is VASTAI_LOGSYS_OPER_CLEAR_BUFFER
1) clear buffer of all pci
[oper_enum]-1
2) clear buffer of specific pci
[oper_enum]pci_dev_id
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
3) clear buffer of all core of specific pci die
[oper_enum]pci_dev_id:die_index
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
4) clear buffer of specific core of specific pci die
[oper_enum]pci_dev_id:die_index:coreidbegin0-coreidend0,coreidbegin1-coreidend1,...
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
coreidbeginN is the begin coreid of begin-end pair index N 
coreidendN is the begin coreid of begin-end pair index N 

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_LEVEL
level listed below:
LOG_LEVEL_ERR 0
LOG_LEVEL_WARN 1
LOG_LEVEL_INFO 2
LOG_LEVEL_DEBUG 3
enable:
0 means disable log
1 means enable log
1) change log level of all pci
[oper_enum][level:enable]-1
2) change log level of specific pci
[oper_enum][level:enable]pci_dev_id
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
3) change log level of all core of specific pci die
[oper_enum][level:enable]pci_dev_id:die_index
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
4) change log level of specific core of specific pci die
[oper_enum][level:enable]pci_dev_id:die_index:coreidbegin0-coreidend0,coreidbegin1-coreidend1,...
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
coreidbeginN is the begin coreid of begin-end pair index N 
coreidendN is the begin coreid of begin-end pair index N 

when oper_enum is VASTAI_LOGSYS_OPER_CHANGE_PATH
path:
0 means uart log
1 means pcie log
1) change log path of all pci
[oper_enum][path]-1
2) change log level of specific pci
[oper_enum][path]pci_dev_id
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
3) change log level of all core of specific pci die
[oper_enum][path]pci_dev_id:die_index
pci_dev_id is the "%u" format string of vastai_pci_info.dev_id
die_index is the die index of the pci, index begin from 0
*/

enum VASTAI_LOGSYS_OPER {
	VASTAI_LOGSYS_OPER_MIN = 0,
	VASTAI_LOGSYS_OPER_MINUSONE = VASTAI_LOGSYS_OPER_MIN - 1,

	VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO,
	VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG,
	VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD,
	VASTAI_LOGSYS_OPER_CHANGE_OUTPUTLOG_PERCORE_BEGIN_OFFSET,
	VASTAI_LOGSYS_OPER_CLEAR_BUFFER,
	VASTAI_LOGSYS_OPER_CHANGE_LEVEL,
	VASTAI_LOGSYS_OPER_CHANGE_PATH,

	VASTAI_LOGSYS_OPER_MAXADDONE,
	VASTAI_LOGSYS_OPER_MAX = VASTAI_LOGSYS_OPER_MAXADDONE - 1,
	VASTAI_LOGSYS_OPER_MODE_COUNT =
		VASTAI_LOGSYS_OPER_MAX - VASTAI_LOGSYS_OPER_MIN + 1,
};

enum VASTAI_LOGSYS_IOCTL_CHANGE_CALLER {
	/*
	The default caller is shell cat.
	*/
	VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_SHELLCAT,
	/*
	When C program, you do not need to set pos to the head every time 
	before you do read operation.
	Otherwise, when mode is not CALLER_C, and you do not set pos to the head, 
	the read operation will check the current pos, and when current pos is 
	not 0, the function will return immediately without output log to apply 
	shell cat operation.
	*/
	VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_C,
};

// write operation format end
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// Inner defines begin

enum VASTAI_LOGSYS_DRVINNER_OPER {
	VASTAI_LOGSYS_DRVINNER_OPER_MIN = 0,
	VASTAI_LOGSYS_DRVINNER_OPER_MINMINUSONE =
		VASTAI_LOGSYS_DRVINNER_OPER_MIN - 1,

	/*
	Currently do nothing.
	*/
	VASTAI_LOGSYS_DRVINNER_OPER_NOOPER,
	/*
	Changed by pcore, to notify the user that there is pci being removed and need 
	user to rebind log.
	Once the status is changed to this, it will return the current operation.
	*/
	VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE,
	VASTAI_LOGSYS_DRVINNER_OPER_OPEN,
	VASTAI_LOGSYS_DRVINNER_OPER_RELEASE,
	VASTAI_LOGSYS_DRVINNER_OPER_READ,
	VASTAI_LOGSYS_DRVINNER_OPER_WRITE,
	VASTAI_LOGSYS_DRVINNER_OPER_IOCTL,
	VASTAI_LOGSYS_DRVINNER_OPER_LLSEEK,
	VASTAI_LOGSYS_DRVINNER_OPER_POLL,
	VASTAI_LOGSYS_DRVINNER_OPER_FASYNC,

	VASTAI_LOGSYS_DRVINNER_OPER_MAXADDONE,
	VASTAI_LOGSYS_DRVINNER_OPER_MAX =
		VASTAI_LOGSYS_DRVINNER_OPER_MAXADDONE - 1,
};

// Inner defines end
//////////////////////////////////////////////////////////////////////////

#endif
