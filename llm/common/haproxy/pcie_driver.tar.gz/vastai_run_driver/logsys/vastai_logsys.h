#ifndef __VASTAI_LOGSYS_H__
#define __VASTAI_LOGSYS_H__

#include "vastai_logsys_def.h"

#if (PC_ENV == 0)

#include <linux/cdev.h>
#include <linux/kernel.h>

#endif

struct vastai_logsys_filelist;
struct vastai_logsys_pci_env;
struct vastai_logsys_pci_die_env;
struct vastai_logsys_pci_die_core_env;

/*
The minimize file struct node.
*/
struct PACKED vastai_logsys_file {
	/*
	The parent node where store the file.
	Use the pointer to get the base string of file path.
	*/
	struct vastai_logsys_filelist *plist;

#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
	u32 fileindex;
#endif
	/*
	The file will be close only when the file node is to be 
	deleted.
	*/
	struct file *pfile;
	/*
	The biggest value is VASTAI_LOGSYS_FILE_MAXSIZE.
	When value is VASTAI_LOGSYS_FILE_MAXSIZE, it means the 
	current file is full.
	The program need to make sure the size is not bigger than 
	VASTAI_LOGSYS_FILE_MAXSIZE.
	*/
	u32 wpbyte;

	struct vastai_logsys_file *ppre;
	struct vastai_logsys_file *pnext;
};

/*
One file at most VASTAI_LOGSYS_FILE_MAXSIZE size.
So we need a file list to store the content.
*/
struct PACKED vastai_logsys_filelist {
	/*
	The base string of the file path of the file list.
	*/
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
	struct vastai_logsys_file *phead;
	struct vastai_logsys_file *ptail;
	/*
	The begin file pointer may not be phead. Because the clear buffer operation 
	will not clear the current using file pointer. It will clear all of the 
	previous file pointer.
	*/
	struct vastai_logsys_file *pfilebegin;
	/*
	The begin offset of pfilebegin to tag the begin position of the core log 
	head.
	*/
	u32 filebeginrpbyte;
	/*
	The number added next to filepathbase to ensure the file name will not be 
	the same. It will never be reset to 0.
	*/
	u32 fileindex;
};

struct PACKED vastai_logsys_pci_die_core_env {
	/*
	The index begin from 0, used by logsys only.
	*/
	u32 pci_dev_id;
	struct vastai_pci_info *p_pci_info;
	u32 die_index;
	u32 die_index_global;

	u32 core_index;

	/*
	0 means not being destroyed
	1 means being destroyed and can not bind new user and exist users need to handle 
	the current operation over immediately
	*/
	atomic_t bbeingdestroyed;

	/*
	Protect the wp pointer be used/changed by one user.
	Protect the following variables:
	1) arraynum_puser_block
	2) parray_puser_block
	3) puser_clearbuffer
	4) pfilelist
	But once get the pfilelist, the mutex only protect the end link node
	which is just got. Currently, we protect the whole link in convenience.
	Tips: The block wait operation will not in the mutex time, but the set block 
	status operation is in mutex.
	Tips: IMPORTANT!
	Be careful! The mutex may be within mutex user. Because, the user do unbind 
	operation should be a atomic operation as the bg thread may release the core 
	resource when user unbind it.
	Be careful! The mutex may be within mutex pci. Because, the user add bind info 
	operation should ensure the pci pointer and the core pointer is valid when do 
	the operation.
	*/
	struct mutex mutex_core;
	u32 parray_puserbblock[VASTAI_LOGSYS_PERCORE_USER_MAX];
	/*
	The array of puser which correspondent to the specific core.
	At most VASTAI_LOGSYS_PERCORE_USER_MAX users (except clear buffer user) can bind 
	to one core, including block and unblock users, not including clear buffer user.
	The clear buffer puser will not record in the parray_puser_block.
	The puser which is not block mode will not record into the parray_puserbblock.
	Do not need to record the unblock mode puser.
	When use the parray_puser array, you should ignore the ppre and pnext of the 
	array element.
	*/
	struct vastai_logsys_user *parray_puser[VASTAI_LOGSYS_PERCORE_USER_MAX];
	/*
	The clearbuffer puser may not be block mode.
	*/
	struct vastai_logsys_user *puser_clearbuffer;
	/*
	1 means the clear buffer user is block mode
	0 means the clear buffer user is not block mode
	*/
	u32 bblock_clearbuffer;

	/*
	The file list to store the log of the correspondent core.
	*/
	struct vastai_logsys_filelist filelist;

#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
	/*
	The logbuffer will be used when puser_clearbuffer is not NULL.
	When puser_clearbuffer is set back to NULL, you need to set wpoffset and 
	rpoffset to 0, so that the sum count of current byte is correct.
	When read from ddr, bak save the core log and decide whether to save the log 
	in file according to the current log buffer status. When the log buffer is 
	nearly full, you need to save the log in the file.
	*/
	unsigned char logbuffer[VASTAI_LOGSYS_BUF_SIZE];
	char __user *plogbuffer; // size is VASTAI_LOGSYS_BUF_SIZE
#else
	unsigned char logbuffer[4]; // for compile only, do not use
	char __user *plogbuffer; // for compile reserved only, do not use
#endif

	/*
	The log buffer left to read begin from rpoffset to wpoffset.
	The logbuffer will be used when puser_clearbuffer is not NULL.
	The wp offset of the logbuffer array.
	*/
	u32 wpoffset;
	/*
	The log buffer left to read begin from rpoffset to wpoffset.
	The logbuffer will be used when puser_clearbuffer is not NULL.
	The rp offset of the logbuffer array.
	*/
	u32 rpoffset;

	/*
	Current data.
	The total valid bytes sum at the current, including the logbuffer array (from 
	the rp to wp) and the log file(from the file list filebeginrpbyte of pfilebegin).
	The value is equal to currbytelogbuffer plus currbytefile.
	*/
	size_t currbytesum;
	/*
	Current data.
	*/
	size_t currbytelogbuffer;
	/*
	Current data.
	*/
	size_t currbytefile;

	/*
	Clear data.
	The clear bytes sum.
	*/
	size_t clearbytesum;

	/*
	Always the sum of currbytesum and clearbytesum.
	*/
	size_t totalbytesum;
};

/*
For puser use.
*/
struct PACKED vastai_logsys_pci_die_pcore_node {
	struct vastai_logsys_pci_die_core_env *pcore;
	struct vastai_logsys_pci_die_pcore_node *ppre;
	struct vastai_logsys_pci_die_pcore_node *pnext;
};

void internal_vastai_gettimeofday(struct rtc_time *io_ptm);

int internal_vastai_logsys_createdir(char *i_dir);
int internal_vastai_logsys_rmdir(char *i_dir);
int internal_vastai_logsys_rmandcreatedir(char *i_dir);
int internal_vastai_logsys_mvdir(char *i_olddir, char *i_newdir);
int internal_vastai_logsys_touch(char *i_path);

u32 internal_getcoredscrbycoreid(unsigned char *i_pcoredscr, u32 i_coreid);

/*
Create a empty file and open.
*/
void internal_vastai_logsys_filelist_init(
	struct vastai_logsys_filelist *io_pfilelist);
/*
When i_bcannewfile is 0, you should use the current file.
When i_bcannewfile is 1, you should check whether the current file is big, when 
is big, you should open a new file and record the log.
*/
void internal_vastai_logsys_filelist_add(
	struct vastai_logsys_filelist *io_pfilelist,
	unsigned char *i_parraydata, u32 i_arraynum, u32 i_bcannewfile);
/*
When check file list is NULL, it will return -1.
The function use bclear option to decide whether to clear the file which is 
just read.
The caller should ensure the log buffer is valid and have log buffer, 
otherwise it will return -1.
*/
ssize_t internal_vastai_logsys_filelist_getfrombeginwithclear_inner(
	struct vastai_logsys_filelist *io_pfilelist,
	unsigned char *io_parraydata, u32 i_arraynum);
/*
The only difference between the following function with the upper one is the 
buffer pointer is user mode.
The caller should ensure the log buffer is valid and have log buffer, 
otherwise it will return -1.
*/
ssize_t internal_vastai_logsys_filelist_getfrombeginwithclear_user(
	struct vastai_logsys_filelist *io_pfilelist,
	char __user *io_parraydata_user, u32 i_arraynum);
/*
When check file list is NULL, it will return -1.
The caller should ensure the position will not out of the range.
When we find the position is out of range, it will return -1.
When the input is equal to the biggest pos, it will return 0.
When the input is valid, it will return the size of read bytes. It may be 
smaller than the input size.
io_ppos can not be NULL, *io_ppos output the position of current read. You 
can use it to know how many byte size currently moved, and also you can 
use it to double check the system.
When the return value is 0, you can use *io_ppos to know where currently 
read.
The caller should ensure the log buffer is valid and have log buffer, 
otherwise it will return -1.
Tips: the pos is begin from the filebeginrpbyte of pfilebegin.
The function do not support clear operation.
*/
ssize_t internal_vastai_logsys_filelist_getfrompos_inner(
	struct vastai_logsys_filelist *io_pfilelist, loff_t *io_ppos,
	unsigned char *io_parraydata, u32 i_arraynum, loff_t i_pos);
/*
The only difference between the following function with the upper one is the 
buffer pointer is user mode.
The caller should ensure the log buffer is valid and have log buffer, 
otherwise it will return -1.
*/
ssize_t internal_vastai_logsys_filelist_getfrompos_user(
	struct vastai_logsys_filelist *io_pfilelist, loff_t *io_ppos,
	char __user *io_parraydata_user, u32 i_arraynum, loff_t i_pos);
/*
Clear from the start, clear the input size i_clearsize.
When occur error, the return value is bigger than 0.
*/
u32 internal_vastai_logsys_filelist_clear(
	struct vastai_logsys_filelist *io_pfilelist, loff_t i_clearsize);
/*
Clear all of the file node except the last node.
*/
void internal_vastai_logsys_filelist_clearall(
	struct vastai_logsys_filelist *io_pfilelist);

/*
Inner log ring buffer function
i_pos is the offset from the beginning of the inner log buffer ring buffer.
When i_pos is not 0, you can not set i_bclearbuffer to 1.
The caller should ensure the position will not out of the range.
When we find the position is out of range, it will return -1.
The caller should ensure the log buffer is valid and have log buffer, 
otherwise it will return -1.
*/
ssize_t internal_vastai_logsys_corelog_logbuffer_gettouser(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_parraydata_user, u32 i_arraynum, loff_t i_pos,
	u32 i_bclearbuffer);
/*
The only difference is the output pointer is not user space pointer.
*/
ssize_t internal_vastai_logsys_corelog_logbuffer_gettoinner(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char *io_parraydata_user, u32 i_arraynum, loff_t i_pos,
	u32 i_bclearbuffer);

/*
Be careful, the function will not use mutex.
You should ensure the filepathbase string is already set before call the function.
*/
void internal_vastai_logsys_corelog_init_fileandlogbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore);
/*
Be careful, the function will not use mutex.
*/
void internal_vastai_logsys_corelog_deinit_fileandlogbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore);
/*
Be careful, the function will not use mutex.
Read core log buffer from ddr to drive space of file used by driver.
Once read, the function will update the rp pointer which stored on the csram.
When read from ddr, bak save the core log and decide whether to save the log 
in file according to the current log buffer status. When the log buffer is 
nearly full, you need to save the log in the file.
*/
int internal_vastai_logsys_corelog_readddrtodrv(
	struct vastai_logsys_pci_die_core_env *io_pcore);
/*
Be careful, the function will not use mutex.
The return value is the size of the read bytes of the operation.
The value may be smaller than the input i_size means already read to the end.
The value may be zero means there is no left log to read.
The i_posfromcurrbegin is from the begin of the current core log.
*o_ptotalbyteindex output the total byte index from the history beginning when 
the read end. You can set it to NULL meaning you do not care of it.
You may use it to continue reading the log from the last read operation.
You can use clear buffer operation to change the begin position.
Tips: only when i_posfromcurrbegin is 0, the function will clear the buffer 
from the beginning.
Tips: when o_ptotalbyteindex is not NULL, it will output the current position. 
When return size is 0, the output position offset to the current begin is smaller 
than or equal to the input size. 
When return size is bigger than 0, the output position offset to the current 
begin is bigger than or equal to the input size.
When the input position is out of the total sum byte count, the function will
return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE.
*/
ssize_t internal_vastai_logsys_corelog_readdrvtouser_fromcurrbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_pbuffer, loff_t *o_ptotalbyteindex,
	loff_t i_posfromcurrbegin, size_t i_size, u32 i_clearbuffer);
/*
The only difference is the io_pbuffer pointer is not user space pointer.
*/
ssize_t internal_vastai_logsys_corelog_readdrvtoinner_fromcurrbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore, char *io_pbuffer,
	loff_t *o_ptotalbyteindex, loff_t i_posfromcurrbegin, size_t i_size,
	u32 i_clearbuffer);
/*
Be careful, the function will not use mutex.
The return value is the size of the read bytes of the operation.
The value may be smaller than the input i_size means already read to the end.
The value may be zero means there is no left log to read.
The i_posfrombegin is from the begin of the core log.
When the input position is out of the total sum byte count, the function will
return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE.
No clearbuffer choice, not clearbuffer mode, you should use 
internal_vastai_logsys_corelog_readdrvtouser_fromcurrbegin instead 
when need clearbuffer.
*/
ssize_t internal_vastai_logsys_corelog_readdrvtouser_fromtotalbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_pbuffer, loff_t *o_ptotalbyteindex,
	loff_t i_posfromtotalbegin, size_t i_size);
/*
The only difference is the io_pbuffer pointer is not user space pointer.
*/
ssize_t internal_vastai_logsys_corelog_readdrvtoinner_fromtotalbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore, char *io_pbuffer,
	loff_t *o_ptotalbyteindex, loff_t i_posfromtotalbegin, size_t i_size);
/*
i_totalbyteindex is the current total byte index.
The function find the next log begin position, output to o_ptotalbyteindex.
When the current position reach end, the function will output the same value 
as input i_totalbyteindex.
*/
u32 internal_vastai_logsys_corelog_findnextlogbeginpos(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	loff_t *o_ptotalbyteindex, loff_t i_totalbyteindex);
/*
Get the nearest begin position(ensure it is the log start).
By find the begin pos of the nearest file and find the pos.
The return value is 0 or VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE.
*/
u32 internal_vastai_logsys_corelog_findnearestpos_fromtotalbeginandoffset(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	loff_t *o_ptotalbyteindex, loff_t i_beginoffsetdef);
/*
Be careful, the function will not use mutex.
Change the begin position of the core log.
Clear buffer operation will release the control node of the previous core log.
*/
void internal_vastai_logsys_corelog_clearbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore);
/*
Be careful, the function will not user mutex pci.
But the function will use mutex core.
Iterate every core of the die, do clear buffer operation.
*/
void internal_vastai_logsys_corelog_clearbuffer_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie);
/*
Be careful, the function will not use mutex pci.
But the function will use mutex core.
Iterate every core of every die of the pci, do clear buffer operation.
*/
void internal_vastai_logsys_corelog_clearbuffer_ofpci(
	struct vastai_logsys_pci_env *io_ppci);

/*
Be careful, the function will not use mutex.
Change the begin position of the core log.
Change level operation will release the control node of the previous core log.
*/
void internal_vastai_logsys_corelog_changelevel(
	struct vastai_logsys_pci_die_core_env *io_pcore, u32 i_loglevel,
	u32 i_logenable);
/*
Be careful, the function will not use mutex pci.
But the function will use mutex core.
Iterate every core of the die, do change level operation.
*/
void internal_vastai_logsys_corelog_changelevel_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie, u32 i_loglevel,
	u32 i_logenable);
/*
Be careful, the function will not use mutex pci.
But the function will use mutex core.
Iterate every core of every die of the pci, do change level operation.
*/
void internal_vastai_logsys_corelog_changelevel_ofpci(
	struct vastai_logsys_pci_env *io_ppci, u32 i_loglevel, u32 i_logenable);

/*
Be careful, the function will not use mutex pci.
The function will not use other mutex.
*/
void internal_vastai_logsys_corelog_changepath_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie, u32 i_path);
/*
Be careful, the function will not use mutex pci.
The function will not use other mutex.
*/
void internal_vastai_logsys_corelog_changepath_ofpci(
	struct vastai_logsys_pci_env *io_ppci, u32 i_path);

/*
specific die of specific pci
*/
struct PACKED vastai_logsys_pci_die_env {
	/*
	The index begin from 0, used by logsys only.
	*/
	u32 pci_dev_id;
	struct vastai_pci_info *p_pci_info;
	u32 die_count; // less than or equal to VASTAI_LOGSYS_DIE_MAXCOUNT
	u32 die_index; // current index, begin from 0
	u32 die_index_global;

	/*
	0 means not being destroyed
	1 means being destroyed and can not bind new user and exist users need to handle 
	the current operation over immediately
	*/
	atomic_t bbeingdestroyed;

	/*
	one mutex correspondent to log ring buffer of one core
	Use mutex to ensure the log read operation be done by one thread at one time.
	*/
	struct vastai_logsys_pci_die_core_env
		parray_core_env[VASTAI_LOGSYS_CORECOUNT];
	/*
	The die env is not the endpoint, so we only record the base string instead of 
	creating the file list.
	*/
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
};

struct PACKED vastai_logsys_pci_env {
	/*
	The index begin from 0, used by logsys only. Can not change.
	*/
	u32 pci_dev_id;
	/*
	Can not change.
	*/
	struct vastai_pci_info *p_pci_info;
	u32 die_count; // less than or equal to VASTAI_LOGSYS_DIE_MAXCOUNT
	struct vastai_logsys_pci_die_env
		parray_die_env[VASTAI_LOGSYS_DIE_MAXCOUNT];

	/*
	0 means not being destroyed
	1 means being destroyed and can not bind new user and exist users need to handle 
	the current operation over immediately
	*/
	atomic_t bbeingdestroyed;

	struct vastai_logsys_pci_env *ppre;
	struct vastai_logsys_pci_env *pnext;
	/*
	The pci env is not the endpoint, so we only record the base string instead of 
	creating the file list.
	*/
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
};

/*
The bind info of which path to output log information.
*/
struct PACKED vastai_logsys_user_mode_info {
	/*
	(u32)(-1) means all pci.
	The default info mode is all pci.
	Currently, the id begin from 0.
	*/
	u32 pci_dev_id;
	/*
	When pci_dev_id is not (u32)-1, the die_index is valid.
	*/
	u32 die_index;
	/*
	parray_bcore[N]=1 means need to output the log info of the specific core
	index of the pci_dev_id die_index die
	parray_bcore[N]=0 means do not need to output the log info of the specific core
	index of the pci_dev_id die_index die
	*/
	u32 parray_bcore[VASTAI_LOGSYS_CORECOUNT];
};

struct PACKED vastai_logsys_user_error_details {
	char function[128];
	u32 linenumber;
};

struct vastai_logsys_user;

struct PACKED vastai_logsys_user_mode_log {
	/*
	0 means using non-block mode.
	1 means using block mode.
	One specific core of specific die of specific pci should at most have one block 
	mode dev. Otherwise, the second caller will be invalid and set 
	VASTAI_LOGSYS_DEV_LOG_INVALID_ERROR_BLOCK_ONECORE_TWICE to errorindex.
	*/
	u32 bblock;
	/*
	0 means will not clear buffer after get out the log.
	1 means will clear buffer after get out the log.
	One specific core of specific die of specific pci should at most have one clear 
	buffer log mode dev. Otherwise, the second caller will be invalid and set 
	VASTAI_LOGSYS_DEV_LOG_INVALID_ERROR_LOGCLEARBUFFERMODE_TWICE to errorindex.
	*/
	u32 bclearbuffer;
	/*
	(u32)(-1) means all pci.
	*/
	u32 pci_dev_id;
	/*
	When pci_dev_id is not (u32)-1, the die_index is valid.
	*/
	u32 die_index;
	/*
	parray_bcore[N]=1 means need to output the log info of the specific core
	index of the pci_dev_id die_index die
	parray_bcore[N]=0 means do not need to output the log info of the specific core
	index of the pci_dev_id die_index die
	*/
	u32 parray_bcore[VASTAI_LOGSYS_CORECOUNT];
	struct vastai_logsys_user_mode_log *ppre;
	struct vastai_logsys_user_mode_log *pnext;
};

/*
You can set it to log info mode to trigger unbind all log.
Of course, when the user close, it will unbind all log.
*/
struct PACKED vastai_logsys_user_bindinfo {
	/*
	See VASTAI_LOGSYS_MODE_***
	Info mode: output log info data.
	Log mode: output log.
	*/
	u32 mode;

	struct vastai_logsys_user_mode_info user_mode_info;

	struct vastai_logsys_user_mode_log *puser_mode_log_head;
	struct vastai_logsys_user_mode_log *puser_mode_log_tail;
};

/*
It will not do the deinit operation.
*/
void internal_vastai_logsys_user_bindinfo_init(
	struct vastai_logsys_user_bindinfo *io_pbindinfo);
/*
It will not do the deinit operation.
*/
void internal_vastai_logsys_user_bindinfo_init_by_src(
	struct vastai_logsys_user_bindinfo *io_pbindinfodst,
	struct vastai_logsys_user_bindinfo *i_pbindinfosrc);
void internal_vastai_logsys_user_bindinfo_deinit(
	struct vastai_logsys_user_bindinfo *io_pbindinfo);

struct PACKED vastai_logsys_user_readsession {
	/*
	Every change to the pcorenode will be followed by settings of 
	totalbyteindexend.
	*/
	struct vastai_logsys_pci_die_pcore_node *pcorenode;
	/*
	The buffer is valid only when caller is shellcat.
	*/
	char buffer[VASTAI_LOGSYS_USER_READSESSION_BUFFER_MAXSIZE];
	/*
	The buffer is valid only when caller is shellcat.
	The size of the buffer valid bytes. When the buffersize is 0, 
	it means the buffer is not used at the current time.
	The size will not 4 alignment, because it is for shellcat user 
	parse string output use.
	*/
	u32 buffersize;
	/*
	When the buffersize is not 0, the value is the start point of 
	the current read log. The record totalbyteindex of core is equal to the 
	value, not totalbyteindexnext.
	*/
	loff_t totalbyteindexcurr;
	/*
	When shellcat user, the buffer is valid, so the bufferindex is index to 
	the buffer.
	When C user, the buffer index is of the totalbyteindexcurr to 
	totalbyteindexnext.
	*/
	u32 bufferindex;
	/*
	The total byte index of the next log to read after reading the 
	buffer. When the buffersize is 0, the value should be the same 
	as totalbyteindexcurr.
	*/
	loff_t totalbyteindexnext;
	/*
	The end of the total byte index of one read operation.
	*/
	loff_t totalbyteindexend;

	/*
	The buffer is for log original data temp stored.
	The buffer is for single log only.
	*/
	char tempbuffer
		[VASTAI_LOGSYS_USER_READSESSION_TEMPBUFFER_FORONELOG_MAXSIZE];
};

/*
Set the pcorenode to NULL, and set all of the other value to 0 as default 
value.
*/
void internal_vastai_logsys_user_readsession_reset_tonull(
	struct vastai_logsys_user_readsession *io_preadsession);
/*
Update readsession status by caller mode and totalbyteindex.
The function will check the input totalbyteindex is the end 
of the readsession, when yes, it will set to the parse end 
status. When not, it will update the status like buffer when 
caller shellcat.
*/
u32 internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
	struct vastai_logsys_user_readsession *io_preadsession,
	struct vastai_logsys_pci_die_pcore_node *i_pcorenode, u32 i_callertype,
	loff_t i_totalbyteindex);
/*
Clear buffer from totalbyteindexcurr of input readsession to 
totalbyteindexnext of input readsession.
You should ensure the totalbyteindexcurr is the current byte 
index start of the input core.
*/
u32 internal_vastai_logsys_user_readsession_clearcurrtonext(
	struct vastai_logsys_user_readsession *io_preadsession,
	struct vastai_logsys_pci_die_pcore_node *i_pcorenode);
/*
Init the readsession context by a new corenode's core.
The function will not use any mutex.
The caller mode is VASTAI_LOGSYS_CALLER_SHELLCAT or 
VASTAI_LOGSYS_CALLER_C.
The function will use core mutex, when the function return
as the readsession have data to read, the function still 
in the correspondent core mutex. Otherwise, when the return 
*o_preachend is 1, the function will quit core mutex before 
return. When *o_preachend is 0 and the return value is 0, 
the readsession have data to read.
You should quit any core mutex before call the function.
When the function return value is not 0, the function quit 
core mutex before return.
The input i_pcorenode should not be NULL.
*/
u32 internal_vastai_logsys_user_readsession_init_bycorenode(
	struct vastai_logsys_user_readsession *io_preadsession,
	u32 *o_preachend, struct vastai_logsys_pci_die_pcore_node *i_pcorenode,
	u32 i_callertype, loff_t i_beginoffset);
/*
When the readsession current node have data to read, it will do nothing.
When the readsession current node have no data to read, it will iterate 
the following node until find data to read. Every node will use the input 
i_beginoffset settings.
The function will use core mutex, when the function return
as the readsession have data to read, the function still 
in the correspondent core mutex. Otherwise, when the return 
*o_preachend is 1, the function will quit core mutex before 
return. When *o_preachend is 0 and the return value is 0, 
the readsession have data to read.
You should quit any core mutex before call the function.
When the function return value is not 0, the function quit 
core mutex before return.
Be careful!
The function will not check the bufferindex to check whether have data 
is empty, it will only check whether totalbyteindexcurr is equal to 
totalbyteindexend to judge the data full status.
*/
u32 internal_vastai_logsys_user_readsession_update_finddatatoread(
	struct vastai_logsys_user_readsession *io_preadsession,
	u32 *o_preachend, u32 i_callertype, loff_t i_beginoffset);

/*
One vastai_logsys_dev correspondent to one user.
No other process will use the structure except the current user process.
*/
struct PACKED vastai_logsys_user {
	struct vastai_logsys_env *penv;

	/*
	The mutex protect the userdrvoper, bpcoreupdated and the pcore in use 
	by the current user.
	It will also protect bindinfo and caller type.
	Every enter the lock, we need to check whether the current userdrvoper 
	is VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE. If yes, we do 
	nothing but change status to need rebind. Because the bg thread already 
	finish the deinit operation including the bind log info deinit.
	Be careful! The mutex may be within mutex pci. Because, the user do bind 
	operation should be a atomic operation as the bg thread may user the puser
	pointer when log reach.
	*/
	struct mutex mutex_user;
	/*
	See enum define:
	VASTAI_LOGSYS_DRVINNER_OPER_***
	VASTAI_LOGSYS_DRVINNER_OPER_NOOPER means no operation.
	*/
	u32 userdrvoper;
	/*
	1 means unbind operation by pci remove is done
	0 means unbind operation by pci remove has not been done, need to continue
	wait
	*/
	u32 bunbindfinished;
	/*
	The pcore inuse list.
	The pcore node may be delete by pcore with the operation to set bpcoreupdated 1
	within one mutex lock and unlock time.
	*/
	struct vastai_logsys_pci_die_pcore_node *pcore_head;
	struct vastai_logsys_pci_die_pcore_node *pcore_tail;

	/*
	Signaled by log handler when correspondent log is reached. Notify the block 
	user. Once the user receive the signal, it will check all the correspondent 
	core log. 
	Also, when there is core removed by the pci remove, it will also signal. 
	You need to handle the pci remove circumstance. Currently, when all of the 
	bind core is removed, the block will return to user and tell user that there 
	is no correspondent core. But when there is still correspondent core, the 
	driver operation will still block until the correspondent core log reached.
	Another usage is when the pci remove core do the user unbind operation, user 
	need to wait the signal to know when to do the following operation after 
	unbind. We should wait the signal to avoid pci remove unbind operation use 
	pointer which may be released immediately by user.
	*/
	wait_queue_head_t wq_breakblock;

	/*
	The wq_breakblock correspondent tag.
	*/
	u32 bbreakblock;

	/*
	Only the specific user process will use the variable, so you can use it 
	without in/out mutex.
	The default number is VASTAI_LOGSYS_USER_ERROR_NOERROR.
	See VASTAI_LOGSYS_USER_ERROR_***.
	Recoverable error can be overwritten by newer operation.
	Unrecoverable error will not change.
	*/
	u32 errorindex;
	struct vastai_logsys_user_error_details errordetails;

	/*
	The default bindinfo is info mode, bind all pci.
	*/
	struct vastai_logsys_user_bindinfo bindinfo;

	/*
	The default value is VASTAI_LOGSYS_CALLER_SHELLCAT.
	When you do not call ioctl, the callertype is always shell cat.
	Use ioctl cmd=VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_C to the mode to caller C to 
	avoid check pos so that we do not need to lseek file when do next read 
	operation.
	Tips: when the callertype is not shell cat, you must do log bind 
	operation.
	*/
	u32 callertype;

	/*
	The info mode buffer to be read by user.
	*/
	char infobuffer[VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE];
	/*
	The default value is 0.
	The size length including '\0' of the infobuffer content.
	*/
	u32 infobuffertotalsize;
	/*
	Next byte index of the position of info buffer array.
	0 means last read reach end.
	*/
	u32 infobuffercurrindex;

	/*
	The read operation session variable.
	Record the current log read operation node pointer.
	When an operation is done or have not any operation, the value is NULL.
	Once bind the value will be reset to NULL.
	*/
	struct vastai_logsys_user_readsession readsession;

	/*
	Only affect log mode, not affect info mode.
	Affect every core.
	*/
	loff_t beginoffsetdef;

	/*
	For async use.
	*/
	struct fasync_struct *fasync;

	struct vastai_logsys_user *ppre;
	struct vastai_logsys_user *pnext;
};

struct PACKED vastai_logsys_env {
	dev_t dev;
	struct cdev cdev;
	struct class *class;
	struct device *device;
	/*
	Default value is VASTAI_LOGSYS_ENV_ERROR_NOERROR.
	When errorindex is not VASTAI_LOGSYS_ENV_ERROR_NOERROR, the following 
	operation will not continue. And the value can not be changed again.
	*/
	u32 errorindex;
	struct vastai_logsys_user_error_details errordetails;
	/*
	The base directory string before pci info.
	*/
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
	/*
	Need to add the lock when get specific pci env pointer or add/minus one pci.
	*/
	struct mutex mutex_pci_list;
	struct vastai_logsys_pci_env *ppci_head;
	struct vastai_logsys_pci_env *ppci_tail;
	/*
	Need to add the lock when get specific pci env pointer or add/minus one dev.
	*/
	struct mutex mutex_user_list;
	struct vastai_logsys_user *puser_head;
	struct vastai_logsys_user *puser_tail;

	/*
	The mutex protect the default bindinfo which is shared within the env.
	Because the user operation may change the bindinfo, we need to make sure 
	when the user do the operation within the user mutex, so that the mutex 
	bindinfodef is within the user mutex. 
	Be careful, not to add mutex bindinfodef outside mutex_puser. 
	Tips: we will add mutex bindinfodef within mutex_puser lock and unlock.
	The mutex protect the totalbyteindexdef also.
	*/
	struct mutex mutex_bindinfodef;
	struct vastai_logsys_user_bindinfo bindinfodef;
	/*
	The default total byte offset begin default value when not clear buffer 
	mode. Mutex mutex_bindinfodef will protect the variable.
	*/
	loff_t beginoffsetdef;

	/*
	The mutex protect the following variable about background log thread.
	*/
	struct mutex mutex_bgthread;
	/*
	1 means the bg log thread should quit
	0 means the bg log thread should continue running
	Only for signal bg log thread use.
	Only one bg log thread, so when receive signal, we 
	need to set it back.
	*/
	u32 bbgquit;
	/*
	1 means need to handle log
	0 means do not need to handle log
	*/
	u32 breadlog;
	/*
	1 means the bg log thread finish quit operation
	0 means the bg log thread have not finish quit operation
	Notify the pci remove process that the bg thread have 
	finish quit operation.
	*/
	u32 bbgfinishquit;
	/*
	The thread which iterate every core and do log operation at the background.
	*/
	struct task_struct *pbgthread;
	/*
	When bg thread need quit or pci need removed or pci insert, it will send 
	the signal.
	*/
	wait_queue_head_t wq_bglog_breaksleep;
	/*
	Signal that background log thread has received pci remove msg and notify 
	the pci remove process.
	*/
	wait_queue_head_t wq_bglog_hasreceivedmsg;
	/*
	When pci have been removed from the pci list, the pci remove deinit function 
	will send the signal to bg log thread to let the bg log thread continue to do 
	the log opertion. Because the bg log thread need to iterate every pci every die
	every core to read log from ddr.
	*/
	wait_queue_head_t wq_bglog_pci_removed;
	/*
	Notify the pci remove operation process that the bg thread have finish the 
	quit operation.
	*/
	wait_queue_head_t wq_bglog_finishquit;
	/*
	1 means pci inserted event occur
	0 means no pci inserted event occur
	*/
	u32 bbgpciinserted;
	/*
	1 means pci removed event occur
	0 means no pci removed event occur
	Tips: after bg log thread received the msg, the value will be set back to 0.
	Only for signal bg log thread use.
	Only one bg log thread, so when receive signal, we 
	need to set it back.
	*/
	u32 bbgpciremoved;
	/*
	1 means the thread quit by signal
	0 means the thread quit not by signal
	*/
	u32 bsignalquit;
	/*
	1 means just received pci removed message
	0 means not receive pci removed message just now
	Tips: after pci remove process received the notify, the value will be set back 
	to 0. When the bg thread receive the pci remove msg, it will set the value to 1, 
	and when the pci remove process get the value 1 signal, you should set it back 
	to 0.
	*/
	u32 bbgreceived_pciremovedmsg;
	/*
	1 means pci remove operation is done
	0 means pci remove operation has not been done
	The pci remove operation process have done the pci remove operation, it should 
	notify the bgthread.
	*/
	u32 bbgpciremoveddone;
};

struct PACKED vastai_logsys_write_oper_commdscr {
	/*
	(u32)(-1) means all pci.
	The default info mode is all pci.
	Currently, the id begin from 0.
	*/
	u32 pci_dev_id;
	/*
	When pci_dev_id is not (u32)-1, the die_index is valid.
	*/
	u32 die_index;
	/*
	parray_bcore[N]=1 means need to output the log info of the specific core
	index of the pci_dev_id die_index die
	parray_bcore[N]=0 means do not need to output the log info of the specific core
	index of the pci_dev_id die_index die
	*/
	u32 parray_bcore[VASTAI_LOGSYS_CORECOUNT];
};

struct PACKED vastai_logsys_write_oper_change_level {
	/*
	LOG_LEVEL_ERR 0
	LOG_LEVEL_WARN 1
	LOG_LEVEL_INFO 2
	LOG_LEVEL_DEBUG 3
	*/
	u32 loglevel;
	/*
	0: disable
	1: enable
	*/
	u32 logenable;
	struct vastai_logsys_write_oper_commdscr commdscr;
};

struct PACKED vastai_logsys_write_oper_change_path {
	/*
	0: UART VASTAI_LOGSYS_PATH_UART
	1: PCIE VASTAI_LOGSYS_PATH_PCIE
	*/
	u32 path;
	struct vastai_logsys_write_oper_commdscr commdscr;
};

struct PACKED vastai_logsys_write_oper {
	u32 oper_enum;
	struct vastai_logsys_write_oper_commdscr change_mode_info;
	struct vastai_logsys_user_mode_log change_mode_log;
	struct vastai_logsys_user_mode_log change_mode_log_add;
	loff_t change_outputlog_percore_begin_offset;
	struct vastai_logsys_write_oper_commdscr clear_buffer;
	struct vastai_logsys_write_oper_change_level change_level;
	struct vastai_logsys_write_oper_change_path change_path;
};

/*
The function will not use any mutex.
When the write operation is mode log, it will not do bind operation, it will 
only record the bind info. 
*/
void internal_vastai_logsys_user_bindinfo_init_by_write_oper(
	struct vastai_logsys_user_bindinfo *io_pbindinfo,
	struct vastai_logsys_write_oper *i_pwriteoper);
/*
The function will not use any mutex.
We should ensure we already in the user mutex before run inside the function.
When the return value is 0, it means no error.
When the return value is not 0, it means you can not bind the current log add 
entry of the input write operation.
*/
u32 internal_vastai_logsys_user_bindinfo_logadd_check(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_write_oper *i_pwriteoper);
/*
The function will not use any mutex.
*/
void internal_vastai_logsys_user_bindinfo_resettoinfo_whenerror(
	struct vastai_logsys_user_bindinfo *io_pbindinfo);

/*
Used by internal_parse_write_oper only.
When return 0, means no error.
io_pcommdscr is the pointer to the parse instruction string pointer.
*/
u32 internal_parse_write_oper_pci_die_core(
	struct vastai_logsys_write_oper_commdscr *io_pcommdscr,
	char **io_ppinputstr);
/*
When return negative value means error, and the code is the error code's negative value.
When return 0, means no error.
*/
u32 internal_parse_write_oper(struct vastai_logsys_write_oper *io_pwriteoper,
			      char *i_pinputstr);

int internal_thread_log_background(void *i_para);

/*
Function which will be called by other .c files.
*/
int vastai_logsys_probe_init(struct vastai_pci_info *i_pci_info);
/*
Function which will be called by other .c files.
*/
void vastai_logsys_remove_deinit(struct vastai_pci_info *i_pci_info);

/*
Internal function list.
*/

/*
Get the pci env pointer by pdev and pci_dev_id.
When return NULL, means do not find.
*/
struct vastai_logsys_pci_env *
internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
	struct vastai_logsys_env *i_penv, u32 i_pci_dev_id);
struct vastai_logsys_pci_env *
internal_vastai_logsys_get_pci_by_pcidevid_withlock(
	struct vastai_logsys_env *i_penv, u32 i_pci_dev_id);
/*
When return VASTAI_LOGSYS_USER_ERROR_NOERROR, means succeed to set the input drv inner operation.
When return not VASTAI_LOGSYS_USER_ERROR_NOERROR, 
means cannot set input drv inner operation, the current drv inner operation 
is unbind by pci remove, you need to wait the signal that the pci remove trigger user unbind 
operation done, and the function will set the set the status to need rebind(by change error 
index). It will return VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND.
Another situation will also return not VASTAI_LOGSYS_USER_ERROR_NOERROR, 
is that when the current operation is not nooper, 
and it is not unbind oper, but you want to set a new oper, it will be regarded as a fatal error 
and you cannot do the following operation. Because you can not do the user operation in multi
thread or process of one specific user instance. It will return VASTAI_LOGSYS_USER_ERROR_TWOOPER_ATONETIME.
Tips: the role of the caller should be the user process.
Tips: when return VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND, the function will ensure the pci remove 
operation finish using the user instance so that the user can release the correspondent resource.
Tips: when return no error, the function will remain lock status.
*/
u32 internal_vastai_logsys_drvinner_oper_set_and_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, u32 i_drvinner_oper,
	const char *i_pfunc, u32 i_linenum);
#define VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(io_puser, i_drvinner_oper)    \
	internal_vastai_logsys_drvinner_oper_set_and_lock_returnerrorindex(    \
		io_puser, i_drvinner_oper, __func__, __LINE__)
#define CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(io_puser,                         \
							  i_drvinner_oper)                  \
	do {                                                                                \
		int ret =                                                                   \
			internal_vastai_logsys_drvinner_oper_set_and_lock_returnerrorindex( \
				io_puser, i_drvinner_oper, __func__,                        \
				__LINE__);                                                  \
		if (ret != VASTAI_LOGSYS_USER_ERROR_NOERROR)                                \
			return -ret;                                                        \
	} while (0)

u32 internal_vastai_logsys_drvinner_oper_setinfoorlog_and_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, u32 i_drvinner_oper,
	const char *i_pfunc, u32 i_linenum);
#define VASTAI_LOGSYS_DRVINNER_OPER_SETINFOORLOG_AND_LOCK(io_puser,                  \
							  i_drvinner_oper)           \
	internal_vastai_logsys_drvinner_oper_setinfoorlog_and_lock_returnerrorindex( \
		io_puser, i_drvinner_oper, __func__, __LINE__)
#define CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SETINFOORLOG_AND_LOCK(                                  \
	io_puser, i_drvinner_oper)                                                                   \
	do {                                                                                         \
		int ret =                                                                            \
			internal_vastai_logsys_drvinner_oper_setinfoorlog_and_lock_returnerrorindex( \
				io_puser, i_drvinner_oper, __func__,                                 \
				__LINE__);                                                           \
		if (ret != VASTAI_LOGSYS_USER_ERROR_NOERROR)                                         \
			return -ret;                                                                 \
	} while (0)

/*
When do user operation, you must use the function to enter mutex.
When the function return, we already wait the bg thread do the deinit 
operation done if the drv inner operation is unbind by pcie remove.
*/
u32 internal_vastai_logsys_user_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, const char *i_pfunc,
	u32 i_linenum);
#define VASTAI_LOGSYS_USER_LOCK(io_puser)                                      \
	internal_vastai_logsys_user_lock_returnerrorindex(io_puser, __func__,  \
							  __LINE__)
#define CHECKRETPOSITIVE_VASTAI_LOGSYS_USER_LOCK(io_puser)                     \
	do {                                                                   \
		retmacroint =                                                  \
			internal_vastai_logsys_user_lock_returnerrorindex(     \
				io_puser, __func__, __LINE__);                 \
		if (retmacroint != VASTAI_LOGSYS_USER_ERROR_NOERROR)           \
			return retmacroint;                                    \
	} while (0)
#define CHECKRET_VASTAI_LOGSYS_USER_LOCK(io_puser)                             \
	do {                                                                   \
		int retmacroint =                                              \
			internal_vastai_logsys_user_lock_returnerrorindex(     \
				io_puser, __func__, __LINE__);                 \
		if (retmacroint != VASTAI_LOGSYS_USER_ERROR_NOERROR)           \
			return -retmacroint;                                   \
	} while (0)
void internal_vastai_logsys_user_set_nooper(struct vastai_logsys_user *io_puser);
void internal_vastai_logsys_user_set_nooper_and_unlockuser(
	struct vastai_logsys_user *io_puser);
void internal_vastai_logsys_user_set_nooper_except_norecoverableerror(
	struct vastai_logsys_user *io_puser, u32 i_errorcode);
void internal_vastai_logsys_user_set_nooper_except_norecoverableerror_and_unlockuser(
	struct vastai_logsys_user *io_puser, u32 i_errorcode);
#define CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE(io_puser,                  \
							       i_errorcode)               \
	do {                                                                              \
		if (i_errorcode != 0) {                                                   \
			CHECKRET_VASTAI_LOGSYS_USER_LOCK(io_puser);                       \
			internal_vastai_logsys_user_set_nooper_except_norecoverableerror( \
				io_puser, i_errorcode);                                   \
			mutex_unlock(&io_puser->mutex_user);                              \
			return -i_errorcode;                                              \
		}                                                                         \
	} while (0)
#define CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(                    \
	io_puser, i_errorcode)                                                            \
	do {                                                                              \
		if (i_errorcode != 0) {                                                   \
			internal_vastai_logsys_user_set_nooper_except_norecoverableerror( \
				io_puser, i_errorcode);                                   \
			mutex_unlock(&io_puser->mutex_user);                              \
			return -i_errorcode;                                              \
		}                                                                         \
	} while (0)
#define RET_VASTAI_LOGSYS_SET_NOOPER(io_puser, ret)                            \
	do {                                                                   \
		CHECKRET_VASTAI_LOGSYS_USER_LOCK(io_puser);                    \
		io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;    \
		mutex_unlock(&io_puser->mutex_user);                           \
		return ret;                                                    \
	} while (0)
#define RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(io_puser, ret)                     \
	do {                                                                   \
		io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;    \
		mutex_unlock(&io_puser->mutex_user);                           \
		return ret;                                                    \
	} while (0)

/*
Unbind all core which have bind to the user.
You need to unlock other mutex before run the function.
The function will use user mutex.
The function will only be called by background thread.
The function will not only delete the user from the core's user list, 
it will also delete the log entry of the user.
*/
void internal_vastai_logsys_unbind_allcore_oftheuser_bybgthread(
	struct vastai_logsys_user *io_puser);
/*
Quit any mutex before enter the function.
Enter user mutex, check whether not being destroyed by bg thread, 
and then get the core pointer, and quit user mutex and enter core 
mutex, release core bind info, and then back check user being 
destroyed by bg thread, and then release the core pointer in user.
Only release core of user one by one until release all of the core
of the user.
When i_breleasedef is 1, we use it when do write operation, we need to 
release the default bindinfo. 
When i_breleasedef is 0, we use it when do release operation, we do 
not need to release the default bindinfo.
The function will not only delete the user from the core's user list, 
it will also delete the log entry of the user.
*/
u32 internal_vastai_logsys_unbind_allcore_oftheuser_byuserthread(
	struct vastai_logsys_user *io_puser, u32 i_breleasedef);
/*
Quit any mutex before enter the function.
Enter user mutex, check whether not being destroyed by bg thread, 
and per core bind entry to check if exist the core, when not exist,
add the core bind entry.
When find one correspondent core does not exist, the whole operation 
will restore back to the previous status.
When occur error, the function will release the previous core bind.
Tips: when do log add operation, you need to use log add by userthread 
function as below.
*/
u32 internal_vastai_logsys_bind_log_byuserthread(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_user_mode_log *i_plog);
/*
The difference between the function and the upper function is that 
the function will check the block and clearbuffer option is the same 
as the previous settings.
*/
u32 internal_vastai_logsys_bind_logadd_byuserthread(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_user_mode_log *i_plog);
/*
Add the pcore to the user's core node list.
The function will not use any mutex.
When find exist pcore, it will return 
VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE.
*/
u32 internal_vastai_logsys_addcore_tocorenode_ofuser(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_pci_die_core_env *i_pcore);
/*
Delete the pcore from the user's core node list.
The function will not use any mutex.
When do not find exist pcore, it will return 
VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE.
Currently, we do not use the function to release the node.
Use the delete all correspondent function instead.
*/
u32 internal_vastai_logsys_deletecore_fromcorenode_ofuser(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_pci_die_core_env *i_pcore);
void internal_vastai_logsys_deleteallcore_fromcorenode_ofuser(
	struct vastai_logsys_user *io_puser);

/*
The function will use pci mutex, user mutex and core mutex.
The function will return the error index when do not find the correspondent resource.
The function will add '\0' at the end of the buffer.
Whatever the function return 0 or not, the function will update the size of the buffer 
content.
The return value list:
VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE: fatal error, not allowed
VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE: need to stop handle, allowed
VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH: the info is not full caused by 
inner buffer not so big enough, allowed
VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE: there's no core 
correspondent to the current bind info
*/
u32 internal_vastai_logsys_refreshinfobuffer(
	struct vastai_logsys_user *io_puser);
/*
The function will not use pci mutex, but it will use core mutex.
Whatever the function return 0 or not, the function will update the size of the buffer 
buffer and the size left.
*/
u32 internal_vastai_logsys_getpciinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_env *i_ppci);
/*
The function will not use pci mutex, but it will use core mutex.
Whatever the function return 0 or not, the function will update the size of the buffer 
buffer and the size left.
*/
u32 internal_vastai_logsys_getdieinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_die_env *i_pdie);
/*
The function will not use any mutex.
Whatever the function return 0 or not, the function will update the size of the buffer 
buffer and the size left.
*/
u32 internal_vastai_logsys_getcoreinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_die_core_env *i_pcore);

/*
Function and macro.
Env error record.
The function will set the environment error and all of the following operation will 
not continue after the environment error set.
The env error index will not changed again after first change.
*/
void internal_vastai_logsys_env_error_record(struct vastai_logsys_env *io_penv,
					     u32 i_errorindex,
					     const char *i_pfunc,
					     u32 i_linenum);
#define VASTAI_LOGSYS_ENV_ERROR_RECORD(io_penv, i_errindex)                    \
	internal_vastai_logsys_env_error_record(io_penv, i_errindex, __func__, \
						__LINE__)

/*
Function and macro.
User error record.
The function will change the user's dev to NULL so that we can check the dev pointer 
NULL to avoid unexpected error when the next driver interface called.
The function will output log of the current error.
When the user's dev is already NULL and the errorindex is not NOERROR, the function 
will do nothing. When the user's dev is already NULL and the errorindex is NOERROR, 
the function will record the error.
*/
void internal_vastai_logsys_user_error_record(
	struct vastai_logsys_user *io_puser, u32 i_errorindex,
	const char *i_pfunc, u32 i_linenum);
#define VASTAI_LOGSYS_USER_ERROR_RECORD(io_puser, i_errindex)                  \
	internal_vastai_logsys_user_error_record(io_puser, i_errindex,         \
						 __func__, __LINE__)

/*
Function and macro.
Env check.
Output 0 when do not check fail.
When return negative value, it means occur error and can not continue to run.
When return negative value, you can use the return value to return driver interface.
The function will check the error index of env.
*/
int internal_vastai_logsys_env_check(struct vastai_logsys_env *i_penv);
#define VASTAI_LOGSYS_ENV_CHECK(i_penv) internal_vastai_logsys_env_check(i_penv)

/*
Function and macro.
Env and user environment check.
First do internal_vastai_logsys_env_check function to check env.
When return negative value, it means occur error and can not continue to run.
When return negative value, you can use the return value to return driver interface.
The function will check the env pointer, when is NULL, it will return negative value 
according to the error index stored.
When the user's env is not NULL but is not equal to i_penv, it will regarded as a error
and write down. The i_pfunc and i_linenum parameter is used when meet the circumstance.
When input i_bignorerecoverable is 1, the function will only check the unrecoverable 
error and return error index only when the unrecoverable error occur.
When input i_bignorerecoverable is 0, the function will check all of the error index,
and it will return all type of error index.
Tips: has input parameter u32 i_bignorerecoverable.
*/
int internal_vastai_logsys_env_user_check(struct vastai_logsys_env *i_penv,
					  struct vastai_logsys_user *io_puser,
					  u32 i_bignorerecoverable,
					  const char *i_pfunc, u32 i_linenum);
#define VASTAI_LOGSYS_ENV_USER_CHECK_ALL(i_penv, io_puser)                     \
	internal_vastai_logsys_env_user_check(i_penv, io_puser, 0, __func__,   \
					      __LINE__)
#define VASTAI_LOGSYS_ENV_USER_CHECK_IGNORE_RECOVERABLE_ERROR(i_penv,          \
							      io_puser)        \
	internal_vastai_logsys_env_user_check(i_penv, io_puser, 1, __func__,   \
					      __LINE__)

#define CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(i_penv, io_puser)            \
	do {                                                                   \
		retmacroint = internal_vastai_logsys_env_user_check(           \
			i_penv, io_puser, 0, __func__, __LINE__);              \
		if (retmacroint < 0)                                           \
			return retmacroint;                                    \
	} while (0)
#define CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_IGNORE_RECOVERABLE_ERROR(        \
	i_penv, io_puser)                                                      \
	do {                                                                   \
		retmacroint = internal_vastai_logsys_env_user_check(           \
			i_penv, io_puser, 1, __func__, __LINE__);              \
		if (retmacroint < 0)                                           \
			return retmacroint;                                    \
	} while (0)
#define SIMPLE_KERNEL_LOG                                                      \
	pr_err(VASTAI_LOGSYS_PR_HEAD "unexpected error in %s[%d]\n", __func__, \
	       __LINE__)
#if (DEBUG_LOG == 1)
#define SIMPLE_DEBUG_LOG                                                       \
	pr_err(VASTAI_LOGSYS_PR_HEAD "trace code [%d]\n", __LINE__)
#else
#define SIMPLE_DEBUG_LOG
#endif

#endif
