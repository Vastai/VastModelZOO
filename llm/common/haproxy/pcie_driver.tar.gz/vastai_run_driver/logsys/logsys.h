#ifndef _LOGSYS_H_
#define _LOGSYS_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <linux/ctype.h>
#include "sg100_base.h"
#include "vastai_pci.h"

#define LOGSYS_CORE_COUNT           17
#define LOGSYS_DDR_BASE_ADDR        0x1032000000ULL
#define LOGSYS_CORE_BUF             0x100000
#define LOGSYS_CORE_BUF_WP_MASK     0xfffff
#define LOGSYS_CORE_BLOCK_SIZE      0x1000
#define LOGSYS_BLOCKEND_NOLOG_TAG   0x5A3B96D2

enum
{
    LOGSYS_SMCU_0_INDEX = 0,
    LOGSYS_CMCU_0_INDEX,
    LOGSYS_OMCU_0_INDEX,
    LOGSYS_OMCU_1_INDEX,
    LOGSYS_GMCU_0_INDEX,
    LOGSYS_GMCU_1_INDEX,
    LOGSYS_GMCU_2_INDEX,
    LOGSYS_GMCU_3_INDEX,
    LOGSYS_VEMCU_0_INDEX,
    LOGSYS_VEMCU_1_INDEX,
    LOGSYS_VEMCU_2_INDEX,
    LOGSYS_VEMCU_3_INDEX,
    LOGSYS_ODSP_0_INDEX,
    LOGSYS_ODSP_1_INDEX,
    LOGSYS_VDSP_0_INDEX,
    LOGSYS_VDSP_1_INDEX,
    LOGSYS_PMCU_0_INDEX,
};

typedef union logsys_msg_info_s
{
    struct
    {
        u16 msg_level   : 3;
        u16 msg_type    : 3;
        u16 msg_len     : 10;
    };
    u16 n_val;
}logsys_msg_info_t;

typedef struct logsys_header_s
{
    u8 head_flag;
    u8 log_sn;
    logsys_msg_info_t msg_info;
    u32 timestamp;
} logsys_header_t;

int logsys_init(struct vastai_pci_info *priv);
void logsys_deinit(struct vastai_pci_info *priv);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SYSLOG_H__ */
