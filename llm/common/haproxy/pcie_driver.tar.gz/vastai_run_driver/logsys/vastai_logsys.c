#include "vastai_logsys.h"

#if (PC_ENV == 0)

#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/module.h>

#include <linux/poll.h>
#include <linux/printk.h>
#include <linux/slab.h>
// #include <linux/interrupt.h>
#include <linux/completion.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/signal.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/delay.h>

#include <linux/pci.h>
#include "vastai_pci.h"

#endif

/*
Currently, only one instance. 
When _penv is NULL, do the init operation.
*/
static struct vastai_logsys_env *_penv = NULL;
/*
Currently, the id is the pci index begin from 0.
*/
static u32 _pci_dev_id = 0;

static u32 _parray_coreid[VASTAI_LOGSYS_CORECOUNT] = {
	(VASTAI_LOGSYS_CORETYPE_SMCU << 6) | 0,
	(VASTAI_LOGSYS_CORETYPE_CMCU << 6) | 0,
	VASTAI_LOGSYS_COREID_DEFINE_8(VASTAI_LOGSYS_CORETYPE_LMCU),
	VASTAI_LOGSYS_COREID_DEFINE_8(VASTAI_LOGSYS_CORETYPE_ODSP),
	VASTAI_LOGSYS_COREID_DEFINE_3(VASTAI_LOGSYS_CORETYPE_VDMCU),
	VASTAI_LOGSYS_COREID_DEFINE_4(VASTAI_LOGSYS_CORETYPE_VEMCU),
	VASTAI_LOGSYS_COREID_DEFINE_4(VASTAI_LOGSYS_CORETYPE_VDSP),
};

static int vastai_logsys_open(struct inode *i_inode, struct file *io_pfile);
static ssize_t vastai_logsys_read(struct file *i_pfile, char __user *io_pbuffer,
				  size_t i_size, loff_t *io_ppos);
static ssize_t vastai_logsys_write(struct file *i_pfile,
				   const char __user *i_pbuffer, size_t i_size,
				   loff_t *io_ppos);
static long vastai_logsys_ioctl(struct file *i_pfile, unsigned int i_cmd,
				unsigned long i_arg);
static int vastai_logsys_fasync(int i_fd, struct file *i_pfile, int i_mode);
static int vastai_logsys_release(struct inode *i_inode, struct file *i_pfile);
static loff_t vastai_logsys_llseek(struct file *i_pfile, loff_t i_offset,
				   int i_orig);
static unsigned int vastai_logsys_poll(struct file *i_pfile,
				       struct poll_table_struct *i_pwait);

#undef vfs_read
#define vfs_read(i_file, addr, num, ppos) vfs_read_ex(i_file, addr, num, ppos)

#undef vfs_write
#define vfs_write(i_file, addr, num, ppos) vfs_write_ex(i_file, addr, num, ppos)

//#undef mm_segment_t
static mm_segment_t _aaa;

#undef get_fs
#define get_fs() _aaa

#undef set_fs
#define set_fs(a)

/*
Debug use only.
*/
static u32 _bfirstread = 1;
static u32 _bfirstwrite = 1;

void vfs_read_ex(struct file *i_file, char *i_addr, unsigned long i_arraynum,
		 loff_t *ppos)
{
	ssize_t ret = 0;
	//vfs_read_ex(i_file, *ppos, addr, num);
	//kernel_read(i_file, *ppos, i_addr, i_arraynumppos
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD
		"read file pos = %d, i_arraynum = %d, read u32 = 0x%x\n",
		*ppos, i_arraynum, *((u32 *)i_addr));
#endif
	ret = kernel_read(i_file, i_addr, i_arraynum, ppos);
#if (DEBUG_LOG == 1)
	if (ret != i_arraynum) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "read file error[%d]\n", ret);
	}
	if (_bfirstread == 1) {
		pr_info(VASTAI_LOGSYS_PR_HEAD "read file first u32 = 0x%x\n",
			*((u32 *)i_addr));
		_bfirstread = 0;
	}
#endif
}

void vfs_write_ex(struct file *i_file, char *i_addr, unsigned long i_arraynum,
		  loff_t *ppos)
{
	ssize_t ret = 0;
	ret = kernel_write(i_file, i_addr, i_arraynum, ppos);
#if (DEBUG_LOG == 1)
	if (ret != i_arraynum) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "write file error[%d]\n", ret);
	}
	if (_bfirstwrite == 1) {
		pr_info(VASTAI_LOGSYS_PR_HEAD "write file first u32 = 0x%x\n",
			*((u32 *)i_addr));
		_bfirstwrite = 0;
	}
#endif
	//kernel_write(i_file, i_addr, i_arraynum, *ppos);
}

#if (PC_ENV == 1)
static const struct file_operations _fop = { 0 };
#else
static const struct file_operations _fop = {
	.owner = THIS_MODULE,
	.llseek = vastai_logsys_llseek,
	.read = vastai_logsys_read,
	.write = vastai_logsys_write,
	.poll = vastai_logsys_poll,
	.unlocked_ioctl = vastai_logsys_ioctl,
	.open = vastai_logsys_open,
	.release = vastai_logsys_release,
	.fasync = vastai_logsys_fasync,
};
#endif

#if (PC_ENV == 1)
void mutex_init(struct mutex *io_pmutex)
{
	InitializeCriticalSection(&io_pmutex->cs);
}
void mutex_destroy(struct mutex *io_pmutex)
{
	DeleteCriticalSection(&io_pmutex->cs);
}
void mutex_lock(struct mutex *io_pmutex)
{
	EnterCriticalSection(&io_pmutex->cs);
}
void mutex_unlock(struct mutex *io_pmutex)
{
	LeaveCriticalSection(&io_pmutex->cs);
}
u64 get_jiffies_64()
{
	return timeGetTime();
}
#endif

u32 internal_getcoredscrbycoreid(unsigned char *i_pcoredscr, u32 i_coreid)
{
	u32 ret = 0;
	u32 coretype = i_coreid >> 6;
	u32 coreindex = (i_coreid & 0x3F);
	unsigned char typedscr[8] = { 0 };
	switch (coretype) {
	case VASTAI_LOGSYS_CORETYPE_SMCU:
		strcpy((char *)typedscr, "SMCU");
		break;
	case VASTAI_LOGSYS_CORETYPE_CMCU:
		strcpy((char *)typedscr, "CMCU");
		break;
	case VASTAI_LOGSYS_CORETYPE_VDMCU:
		strcpy((char *)typedscr, "VDMCU");
		break;
	case VASTAI_LOGSYS_CORETYPE_VEMCU:
		strcpy((char *)typedscr, "VEMCU");
		break;
	case VASTAI_LOGSYS_CORETYPE_VDSP:
		strcpy((char *)typedscr, "VDSP");
		break;
	case VASTAI_LOGSYS_CORETYPE_LMCU:
		strcpy((char *)typedscr, "LMCU");
		break;
	case VASTAI_LOGSYS_CORETYPE_ODSP:
		strcpy((char *)typedscr, "ODSP");
		break;
	default:
		pr_err(VASTAI_LOGSYS_PR_HEAD "%s: switch default error\n",
		       __func__);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	sprintf((char *)i_pcoredscr, "%s[%u]", typedscr, coreindex);
	return ret;
}

void internal_vastai_logsys_user_bindinfo_init_by_write_oper(
	struct vastai_logsys_user_bindinfo *io_pbindinfo,
	struct vastai_logsys_write_oper *i_pwriteoper)
{
	u32 corei = 0;
	struct vastai_logsys_user_mode_log *pnew = NULL;

	/*
	Before call the function, we should already do the deinit operation first.
	So here, we do not need to deinit again.
	*/

	if (i_pwriteoper->oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO) {
		io_pbindinfo->mode = VASTAI_LOGSYS_MODE_INFO;
		SIMPLE_DEBUG_LOG;
		io_pbindinfo->user_mode_info.pci_dev_id =
			i_pwriteoper->change_mode_info.pci_dev_id;
		io_pbindinfo->user_mode_info.die_index =
			i_pwriteoper->change_mode_info.die_index;
		for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
			io_pbindinfo->user_mode_info.parray_bcore[corei] =
				i_pwriteoper->change_mode_info
					.parray_bcore[corei];
		}
		SIMPLE_DEBUG_LOG;
		return;
	}
	if (i_pwriteoper->oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG) {
		io_pbindinfo->mode = VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG;
		SIMPLE_DEBUG_LOG;
		/*
		The list should be NULL now.
		*/
		pnew = kzalloc(sizeof(struct vastai_logsys_user_mode_log),
			       GFP_KERNEL);
		*pnew = i_pwriteoper->change_mode_log;
		pnew->ppre = pnew->pnext = NULL;
		io_pbindinfo->puser_mode_log_head =
			io_pbindinfo->puser_mode_log_tail = pnew;
		SIMPLE_DEBUG_LOG;
		return;
	} else if (i_pwriteoper->oper_enum ==
		   VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD) {
		/*
		The list should not be NULL now.
		*/
		pnew = kzalloc(sizeof(struct vastai_logsys_user_mode_log),
			       GFP_KERNEL);
		*pnew = i_pwriteoper->change_mode_log_add;
		io_pbindinfo->puser_mode_log_tail->pnext = pnew;
		pnew->ppre = io_pbindinfo->puser_mode_log_tail;
		pnew->pnext = NULL;
		io_pbindinfo->puser_mode_log_tail = pnew;
		return;
	}
}

u32 internal_vastai_logsys_user_bindinfo_logadd_check(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_write_oper *i_pwriteoper)
{
	struct vastai_logsys_user_bindinfo *pbindinfo = &io_puser->bindinfo;
	struct vastai_logsys_user_mode_log *plog =
		pbindinfo->puser_mode_log_head;
	struct vastai_logsys_user_mode_log *plognew =
		&i_pwriteoper->change_mode_log_add;
	u32 corei = 0;
	if (i_pwriteoper->oper_enum != VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD) {
		SIMPLE_KERNEL_LOG;
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (pbindinfo->mode != VASTAI_LOGSYS_MODE_LOG) {
		SIMPLE_KERNEL_LOG;
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	/*
	We do not need to check pci_dev_id is -1 or die_index is -1, because we already 
	check it when do the write operation parse.
	*/
	if (plognew->pci_dev_id == -1 || plognew->die_index == -1) {
		SIMPLE_KERNEL_LOG;
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	/*
	Check every log entry to compare with the input write operation log add entry.
	*/
	while (plog) {
		if (plog->die_index == plognew->die_index) {
			/*
			Check whether have a core the plog and plognew both have bind.
			*/
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				if (plog->parray_bcore[corei] == 1 &&
				    plognew->parray_bcore[corei] == 1) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "Bind Log add Check ERROR! plog and plognew both bind pci[%d]die[%d]core[%d]\n",
					       plog->pci_dev_id,
					       plog->die_index, corei);
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BINDINFO_ALREADY_EXIST;
				}
			}
		}
		plog = plog->pnext;
	}
	return 0;
}

void internal_vastai_logsys_user_bindinfo_resettoinfo_whenerror(
	struct vastai_logsys_user_bindinfo *io_pbindinfo)
{
	internal_vastai_logsys_user_bindinfo_deinit(io_pbindinfo);
}

u32 internal_parse_write_oper_pci_die_core(
	struct vastai_logsys_write_oper_commdscr *io_pcommdscr,
	char **io_ppinputstr)
{
	char *pcurr = *io_ppinputstr;
	char strforcountlen[64] = { 0 };
	int countlen = 0;
	int pci_dev_id = 0;
	int die_index = 0;
	int coreid = 0;
	int coreid_begin = 0, coreid_end = 0;
	int corei = 0;
	char colon = 0, colon1 = 0;

#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "*pcurr = %s\n", pcurr);
#endif

	sscanf(pcurr, "%d%c%d%c", &pci_dev_id, &colon, &die_index, &colon1);

	if (colon != ':' || colon1 != ':') {
		SIMPLE_DEBUG_LOG;
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
	}
	if (pci_dev_id < 0) {
		SIMPLE_DEBUG_LOG;
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
	}
	if (die_index >= 8) {
		SIMPLE_DEBUG_LOG;
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
	}
	io_pcommdscr->pci_dev_id = pci_dev_id;
	io_pcommdscr->die_index = die_index;

	countlen = sprintf(strforcountlen, "%d%c%d%c", pci_dev_id, colon,
			   die_index, colon1);
	pcurr = pcurr + countlen;

	sscanf(pcurr, "%d", &coreid);
	if (coreid == -1) {
		for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
			io_pcommdscr->parray_bcore[corei] = 1;
		}
		countlen = sprintf(pcurr, "%d", coreid);
		pcurr = pcurr + countlen;
		*io_ppinputstr = pcurr;
		return 0;
	}
	/*
	Set the default parray_bcore to every element to 0.
	*/
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		io_pcommdscr->parray_bcore[corei] = 0;
	}

#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "*pcurr = %s\n", pcurr);
#endif

	while (1) {
		sscanf(pcurr, "%d", &coreid_begin);
		if (coreid_begin < 0 ||
		    coreid_begin >= VASTAI_LOGSYS_CORECOUNT) {
			SIMPLE_DEBUG_LOG;
			return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
		}
		countlen = sprintf(strforcountlen, "%d", coreid_begin);
		pcurr = pcurr + countlen;
		if (*pcurr == ',') {
			pcurr++;
			continue;
		}
		if (*pcurr == '\0' || *pcurr == '\n') {
			/*
			Only one core.
			*/
			io_pcommdscr->parray_bcore[coreid_begin] = 1;
			return 0;
		}
		if (*pcurr != '-') {
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD "*pcurr = %x\n", *pcurr);
#endif
			SIMPLE_DEBUG_LOG;
			return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
		}
		pcurr++;
		sscanf(pcurr, "%d", &coreid_end);
		if (coreid_end < 0 || coreid_end >= VASTAI_LOGSYS_CORECOUNT) {
			SIMPLE_DEBUG_LOG;
			return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR_IN_COMMDSCR;
		}
		/*
		coreid_begin to coreid_end
		*/
		for (corei = coreid_begin; corei <= coreid_end; corei++) {
			io_pcommdscr->parray_bcore[corei] = 1;
		}
		countlen = sprintf(strforcountlen, "%d", coreid_end);
		pcurr = pcurr + countlen;
		if (*pcurr == ',') {
			pcurr++;
			continue;
		}
		if (*pcurr == '\0') {
			*io_ppinputstr = pcurr;
			return 0;
		}
	}
}

u32 internal_parse_write_oper(struct vastai_logsys_write_oper *io_pwriteoper,
			      char *i_pinputstr)
{
	char *pcurr = i_pinputstr = NULL, *pcurrbak = NULL;
	char strforcountlen[64] = { 0 };
	int countlen = 0;
	char operhead = 0, opertail = 0, colon = 0, operhead1 = 0,
	     opertail1 = 0;
	u32 oper_enum = 0;
	int pci_dev_id = 0;
	int die_index = 0;
	int bblock = 0, bclearbuffer = 0;
	u32 retparse = 0;
	struct vastai_logsys_write_oper_commdscr commdscr = { 0 };
	u32 corei = 0;
	u32 loglevel = 0;
	u32 logenable = 0;
	u32 path = 0;

	sscanf(pcurr, "%c%d%c", &operhead, &oper_enum, &opertail);

	if (operhead != '[') {
		pr_err(VASTAI_LOGSYS_PR_HEAD "write operation head is not [\n");
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
	}
	if (opertail != ']') {
		pr_err(VASTAI_LOGSYS_PR_HEAD "write operation head is not ]\n");
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
	}
	if (oper_enum >= VASTAI_LOGSYS_OPER_MIN &&
	    oper_enum <= VASTAI_LOGSYS_OPER_MAX) {
		countlen = sprintf(strforcountlen, "%c%d%c", operhead,
				   oper_enum, opertail);
		pcurr = pcurr + countlen;

		if (countlen <= 0) {
			SIMPLE_KERNEL_LOG;
			return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
		}

		io_pwriteoper->oper_enum = oper_enum;

		if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO) {
			sscanf(pcurr, "%d", &pci_dev_id);
			if (pci_dev_id == -1) {
				io_pwriteoper->change_mode_info.pci_dev_id =
					pci_dev_id;
				return 0;
			} else {
				io_pwriteoper->change_mode_info.pci_dev_id =
					pci_dev_id;
				countlen = sprintf(strforcountlen, "%d",
						   pci_dev_id);
				pcurr = pcurr + countlen;
				sscanf(pcurr, "%c%d", &colon, &die_index);
				if (die_index == -1) {
					io_pwriteoper->change_mode_info
						.die_index = die_index;
					return 0;
				} else if (die_index >= 8) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				} else {
					io_pwriteoper->change_mode_info
						.die_index = die_index;
					return 0;
				}
			}
		} else if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG) {
			sscanf(pcurr, "%c%d%c%c%d%c", &operhead, &bblock,
			       &opertail, &operhead1, &bclearbuffer,
			       &opertail1);

			if (operhead != '[' || opertail != ']' ||
			    operhead != '[' || opertail != ']') {
				if (bblock != 0 && bblock != 1) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				}
				if (bclearbuffer != 0 && bclearbuffer != 1) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				}
			}

			io_pwriteoper->change_mode_log.bblock = bblock;
			io_pwriteoper->change_mode_log.bclearbuffer =
				bclearbuffer;

			countlen = sprintf(strforcountlen, "%c%d%c%c%d%c",
					   operhead, bblock, opertail,
					   operhead1, bclearbuffer, opertail1);
			pcurr = pcurr + countlen;

			retparse = internal_parse_write_oper_pci_die_core(
				&commdscr, &pcurr);
			if (retparse > 0) {
				pr_err(VASTAI_LOGSYS_PR_HEAD
				       "write_oper error ret=%d\n",
				       retparse);
				SIMPLE_KERNEL_LOG;
				return retparse;
			}

			if (commdscr.pci_dev_id == -1) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLPCI_NOTALLOW;
			}
			if (commdscr.die_index == -1) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLDIE_NOTALLOW;
			}

			io_pwriteoper->change_mode_log.pci_dev_id =
				commdscr.pci_dev_id;
			io_pwriteoper->change_mode_log.die_index =
				commdscr.die_index;
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				io_pwriteoper->change_mode_log
					.parray_bcore[corei] =
					commdscr.parray_bcore[corei];
			}
			return 0;
		} else if (oper_enum ==
			   VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD) {
			sscanf(pcurr, "%c%d%c%c%d%c", &operhead, &bblock,
			       &opertail, &operhead1, &bclearbuffer,
			       &opertail1);

			if (operhead != '[' || opertail != ']' ||
			    operhead != '[' || opertail != ']') {
				if (bblock != 0 && bblock != 1) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				}
				if (bclearbuffer != 0 && bclearbuffer != 1) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				}
			}

			io_pwriteoper->change_mode_log_add.bblock = bblock;
			io_pwriteoper->change_mode_log_add.bclearbuffer =
				bclearbuffer;

			countlen = sprintf(strforcountlen, "%c%d%c%c%d%c",
					   operhead, bblock, opertail,
					   operhead1, bclearbuffer, opertail1);
			pcurr = pcurr + countlen;

			retparse = internal_parse_write_oper_pci_die_core(
				&commdscr, &pcurr);
			if (retparse > 0) {
				SIMPLE_KERNEL_LOG;
				return retparse;
			}

			if (commdscr.pci_dev_id == -1) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLPCI_NOTALLOW;
			}
			if (commdscr.die_index == -1) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLDIE_NOTALLOW;
			}

			io_pwriteoper->change_mode_log_add.pci_dev_id =
				commdscr.pci_dev_id;
			io_pwriteoper->change_mode_log_add.die_index =
				commdscr.die_index;
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				io_pwriteoper->change_mode_log_add
					.parray_bcore[corei] =
					commdscr.parray_bcore[corei];
			}
			return 0;
		} else if (oper_enum ==
			   VASTAI_LOGSYS_OPER_CHANGE_OUTPUTLOG_PERCORE_BEGIN_OFFSET) {
			sscanf(pcurr, "%lld",
			       &io_pwriteoper
					->change_outputlog_percore_begin_offset);
			return 0;
		} else if (oper_enum == VASTAI_LOGSYS_OPER_CLEAR_BUFFER) {
			/*
			First, check 1) 2) 3) cases.
			*/
			pcurrbak = pcurr; // bak for case 4)
			sscanf(pcurr, "%d", &pci_dev_id);
			if (pci_dev_id == -1) {
				io_pwriteoper->clear_buffer.pci_dev_id =
					pci_dev_id;
				return 0;
			} else {
				io_pwriteoper->clear_buffer.pci_dev_id =
					pci_dev_id;
				countlen = sprintf(strforcountlen, "%d",
						   pci_dev_id);
				pcurr = pcurr + countlen;
				sscanf(pcurr, "%c%d", &colon, &die_index);
				if (die_index == -1) {
					io_pwriteoper->clear_buffer.die_index =
						die_index;
					return 0;
				} else if (die_index >= 8) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				} else {
					io_pwriteoper->clear_buffer.die_index =
						die_index;
					countlen = sprintf(strforcountlen, "%d",
							   die_index);
					pcurr = pcurr + countlen;
					if (*pcurr == '\0') {
						/*
						All of the core.
						*/
						for (corei = 0;
						     corei <
						     VASTAI_LOGSYS_CORECOUNT;
						     corei++) {
							io_pwriteoper
								->clear_buffer
								.parray_bcore
									[corei] =
								1;
						}
						return 0;
					} else if (*pcurr != ':') {
						SIMPLE_KERNEL_LOG;
						return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
					}
					/*
					Back to pci_dev_id part to parse.
					*/
					pcurr = pcurrbak;
					retparse =
						internal_parse_write_oper_pci_die_core(
							&commdscr, &pcurr);
					if (retparse > 0) {
						SIMPLE_KERNEL_LOG;
						return retparse;
					}

					io_pwriteoper->clear_buffer.pci_dev_id =
						commdscr.pci_dev_id;
					io_pwriteoper->clear_buffer.die_index =
						commdscr.die_index;
					for (corei = 0;
					     corei < VASTAI_LOGSYS_CORECOUNT;
					     corei++) {
						io_pwriteoper->clear_buffer
							.parray_bcore[corei] =
							commdscr.parray_bcore
								[corei];
					}
					return 0;
				}
			}
		} else if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_LEVEL) {
			sscanf(pcurr, "%c%d%c%d%c", &operhead, &loglevel,
			       &colon, &logenable, &opertail);
			if (operhead != '[' || opertail != ']') {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			if (colon != ':') {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			if (loglevel > VASTAI_LOGSYS_LEVEL_MAX) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			if (logenable != 0 && logenable != 1) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			io_pwriteoper->change_level.loglevel = loglevel;
			io_pwriteoper->change_level.logenable = logenable;
			countlen =
				sprintf(strforcountlen, "%c%d%c%d%c", operhead,
					loglevel, colon, logenable, opertail);
			pcurr = pcurr + countlen;
			/*
			First, check 1) 2) 3) cases.
			*/
			pcurrbak = pcurr; // bak for case 4)
			sscanf(pcurr, "%d", &pci_dev_id);
			if (pci_dev_id == -1) {
				io_pwriteoper->change_level.commdscr.pci_dev_id =
					pci_dev_id;
				return 0;
			} else {
				io_pwriteoper->change_level.commdscr.pci_dev_id =
					pci_dev_id;
				countlen = sprintf(strforcountlen, "%d",
						   pci_dev_id);
				pcurr = pcurr + countlen;
				sscanf(pcurr, "%c%d", &colon, &die_index);
				if (die_index == -1) {
					io_pwriteoper->change_level.commdscr
						.die_index = die_index;
					return 0;
				} else if (die_index >= 8) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				} else {
					io_pwriteoper->change_level.commdscr
						.die_index = die_index;
					countlen = sprintf(strforcountlen, "%d",
							   die_index);
					pcurr = pcurr + countlen;
					if (*pcurr == '\0') {
						/*
						All of the core.
						*/
						for (corei = 0;
						     corei <
						     VASTAI_LOGSYS_CORECOUNT;
						     corei++) {
							io_pwriteoper
								->change_level
								.commdscr
								.parray_bcore
									[corei] =
								1;
						}
						return 0;
					} else if (*pcurr != ':') {
						SIMPLE_KERNEL_LOG;
						return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
					}
					/*
					Back to pci_dev_id part to parse.
					*/
					pcurr = pcurrbak;
					retparse =
						internal_parse_write_oper_pci_die_core(
							&commdscr, &pcurr);
					if (retparse > 0) {
						SIMPLE_KERNEL_LOG;
						return retparse;
					}

					io_pwriteoper->change_level.commdscr
						.pci_dev_id =
						commdscr.pci_dev_id;
					io_pwriteoper->change_level.commdscr
						.die_index = commdscr.die_index;
					for (corei = 0;
					     corei < VASTAI_LOGSYS_CORECOUNT;
					     corei++) {
						io_pwriteoper->change_level
							.commdscr
							.parray_bcore[corei] =
							commdscr.parray_bcore
								[corei];
					}
					return 0;
				}
			}
		} else if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_PATH) {
			sscanf(pcurr, "%c%d%c", &operhead, &path, &opertail);
			if (operhead != '[' || opertail != ']') {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			if (path != VASTAI_LOGSYS_PATH_UART &&
			    path != VASTAI_LOGSYS_PATH_PCIE) {
				SIMPLE_KERNEL_LOG;
				return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
			}
			io_pwriteoper->change_path.path = path;

			sscanf(pcurr, "%d", &pci_dev_id);
			if (pci_dev_id == -1) {
				io_pwriteoper->change_path.commdscr.pci_dev_id =
					pci_dev_id;
				return 0;
			} else {
				io_pwriteoper->change_path.commdscr.pci_dev_id =
					pci_dev_id;
				countlen = sprintf(strforcountlen, "%d",
						   pci_dev_id);
				pcurr = pcurr + countlen;
				sscanf(pcurr, "%c%d", &colon, &die_index);
				if (die_index == -1) {
					io_pwriteoper->change_path.commdscr
						.die_index = die_index;
					return 0;
				} else if (die_index >= 8) {
					SIMPLE_KERNEL_LOG;
					return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
				} else {
					io_pwriteoper->change_path.commdscr
						.die_index = die_index;
					return 0;
				}
			}
		}
	} else {
		pr_err(VASTAI_LOGSYS_PR_HEAD "write operation enum is wrong\n");
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_ERROR;
	}
	return 0;
}

int internal_thread_log_background(void *i_para)
{
	int ret = 0;
	int corereadret = 0;
	u32 timeoutret = 0;
	u64 timebegin = 0;
	u64 timecurr = 0;
	u64 timespan = 0;
	struct vastai_logsys_env *penv = (struct vastai_logsys_env *)i_para;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	/*
	Record down the corelogloop begin status.
	When the corelogloop handle so quickly that the loop log operation has 
	already loop one circle.
	*/
	struct vastai_logsys_pci_env *ppci_begin = NULL;
	struct vastai_logsys_pci_die_env *pdie_begin = NULL;
	struct vastai_logsys_pci_die_core_env *pcore_begin = NULL;
	u32 diei = 0;
	u32 corei = 0;
	u32 timeouthz = HZ / 10;
	DECLARE_WAITQUEUE(wait, current);

	//allow_signal(SIGURG);

	allow_signal(SIGTERM);

	//allow_signal(SIGKILL);

	//allow_signal(SIGSTOP);
	allow_signal(SIGCONT);

	/*
	To avoid pci read/write error which encounter when conflict with video
	*/
	msleep(50);

gotofirstcore:
	/*
	Check whether have pci removed event or bg need quit.
	*/
	mutex_lock(&penv->mutex_bgthread);
	if (penv->bbgquit == 1) {
		penv->bbgquit = 0;
		mutex_unlock(&penv->mutex_bgthread);
		goto out;
	}
	mutex_unlock(&penv->mutex_bgthread);
	/*
	Set the control info to the first core of the first die of the first pci.
	*/
	mutex_lock(&penv->mutex_pci_list);
	ppci = penv->ppci_head;
	mutex_unlock(&penv->mutex_pci_list);
	if (ppci != NULL) {
		diei = 0;
		pdie = &ppci->parray_die_env[diei];
		corei = 0;
		pcore = &pdie->parray_core_env[corei];
	} else {
		timeouthz = HZ / 10;
		goto sleepwaitsignal;
	}

corelog:
	/*
	Iterate core log, quit when timeout.
	*/
	timebegin = get_jiffies_64();

	/*
	Record down the current core pos.
	*/
	ppci_begin = ppci;
	pdie_begin = pdie;
	pcore_begin = pcore;

corelogloop:
	/*
	Check whether have pci removed event or bg need quit.
	*/
	mutex_lock(&penv->mutex_bgthread);

	if (penv->bbgquit == 1) {
		penv->bbgquit = 0;
		mutex_unlock(&penv->mutex_bgthread);
		goto out;
	}

	if (penv->bbgpciinserted == 1) {
		penv->bbgpciinserted = 0;
		mutex_unlock(&penv->mutex_bgthread);
		goto gotofirstcore;
	}

	if (penv->bbgpciremoved == 1) {
		penv->bbgreceived_pciremovedmsg = 1;
		penv->bbgpciremoved = 0;
		mutex_unlock(&penv->mutex_bgthread);
		wake_up(&penv->wq_bglog_hasreceivedmsg);
		/*
		Wait pci removed event handle over.
		*/
		while (1) {
			add_wait_queue(&penv->wq_bglog_pci_removed, &wait);
			set_current_state(TASK_UNINTERRUPTIBLE);
			timeoutret = wait_event_timeout(
				penv->wq_bglog_pci_removed,
				((penv->bbgquit == 1) ||
				 (penv->bbgpciremoveddone == 1)),
				HZ / 10); // 0.001 second(suppose 1G hz)
			remove_wait_queue(&penv->wq_bglog_pci_removed, &wait);
			set_current_state(TASK_RUNNING);
			pr_err(VASTAI_LOGSYS_PR_HEAD "timeout[%d]line[%d]\n",
			       timeoutret, __LINE__);
			mutex_lock(&penv->mutex_bgthread);
			if (penv->bbgquit == 1) {
				penv->bbgquit = 0;
				/*
				Clear the pci remove signal also, because the following clear 
				operation will not be performed. So clear it here.
				*/
				if (penv->bbgpciremoveddone == 1) {
					/*
					It is reasonable, there is no error.
					*/
					//pr_err(VASTAI_LOGSYS_PR_HEAD "bbgpciremoveddone unexpected 1 line[%d]\n", __LINE__);
					penv->bbgpciremoveddone = 0;
				}
				mutex_unlock(&penv->mutex_bgthread);
				goto out;
			}
			if (penv->bbgpciremoveddone == 1) {
				penv->bbgpciremoveddone = 0;
				mutex_unlock(&penv->mutex_bgthread);
				goto gotofirstcore;
			}
			mutex_unlock(&penv->mutex_bgthread);
		}
	}
	mutex_unlock(&penv->mutex_bgthread);
	/*
	When run here, already ensure the pcore pointer is valid.
	Do core log operation.
	*/
	mutex_lock(&pcore->mutex_core);
	corereadret = internal_vastai_logsys_corelog_readddrtodrv(pcore);
	mutex_unlock(&pcore->mutex_core);
	if (corereadret < 0) {
		//goto out;
	}
	/*
	Set next pcore.
	*/
	if (corei + 1 < VASTAI_LOGSYS_CORECOUNT) {
		corei++;
		pcore = &pdie->parray_core_env[corei];
		goto checkfinishoneloop;
	}

#if 0
	/*
	Only for debug, do not read the second die.
	*/
	corei = 0;
	pcore = &pdie->parray_core_env[corei];
	goto corelogloop;
#endif

	/*
	core index reach the end
	*/
	if (diei + 1 < ppci->die_count) {
		diei++;
		pdie = &ppci->parray_die_env[diei];
		corei = 0;
		pcore = &pdie->parray_core_env[corei];
	} else {
		/*
		die index reach the end
		*/
		mutex_lock(&penv->mutex_pci_list);
		if (ppci->pnext != NULL) {
			ppci = ppci->pnext;
		} else {
			ppci = penv->ppci_head;
		}
		mutex_unlock(&penv->mutex_pci_list);
		diei = 0;
		pdie = &ppci->parray_die_env[diei];
		corei = 0;
		pcore = &pdie->parray_core_env[corei];
	}

	/*
	Get current clock count.
	*/
	timecurr = get_jiffies_64();
	timespan = (u64)(timecurr - timebegin);
	//pr_err(VASTAI_LOGSYS_PR_HEAD "timespan = %d\n", timespan);
	//if (timespan < (u64)(1000000))
	//{
checkfinishoneloop:
	/*
		When not timeout, and the next core is not the begin core, 
		back to corelogloop to continue log the following core.
		*/
	if (ppci != ppci_begin || pdie != pdie_begin || pcore != pcore_begin) {
		//pr_err(VASTAI_LOGSYS_PR_HEAD "pci[%d]die[%d]core[%d]\n", ppci->pci_dev_id, pdie->die_index, pcore->core_index);
		//timeouthz = HZ/100;
		goto corelogloop;
	}
	//else
	//{
	//	timeouthz = HZ/10;
	//}
	/*
		When already goto the pci begin point, it means we already iterate 
		all of the core once in the time span, so do do not need to continue 
		read log immediately. Sleep some time.
		*/
	//goto sleepwaitsignal;
	//}

sleepwaitsignal:
	/*
	sleep
	*/
	add_wait_queue(&penv->wq_bglog_breaksleep, &wait);
	set_current_state(TASK_INTERRUPTIBLE);
	//pr_info(VASTAI_LOGSYS_PR_HEAD "bglog thread wait sleep signal\n");
	timeoutret = wait_event_timeout(penv->wq_bglog_breaksleep,
					((penv->bbgquit == 1) ||
					 (penv->bbgpciremoved == 1) ||
					 (penv->bbgpciinserted == 1)),
					HZ / 10); // 0.01 second(suppose 1G hz)
#if 1
	if (signal_pending(current)) {
		SIMPLE_DEBUG_LOG;
#if 1
		if (penv->bbgquit != 1) {
			SIMPLE_DEBUG_LOG;
			penv->bbgquit = 0;
			penv->bsignalquit = 1;
			remove_wait_queue(&penv->wq_bglog_breaksleep, &wait);
			set_current_state(TASK_RUNNING);
			//pr_info(VASTAI_LOGSYS_PR_HEAD "bglog thread quit when receive signal\n");
			penv->bbgpciremoved = 0;
			penv->bbgpciinserted = 0;
			penv->bbgfinishquit = 1;
			wake_up(&penv->wq_bglog_finishquit);
#if 1
			mutex_lock(&penv->mutex_pci_list);
			ppci = penv->ppci_head;
			mutex_unlock(&penv->mutex_pci_list);
			if (ppci != NULL) {
				for (diei = 0; diei < ppci->die_count; diei++) {
					pdie = &ppci->parray_die_env[diei];
					for (corei = 0;
					     corei < VASTAI_LOGSYS_CORECOUNT;
					     corei++) {
						pcore = &pdie->parray_core_env
								 [corei];
						internal_vastai_logsys_corelog_deinit_fileandlogbuffer(
							pcore);
#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
						/*
						vfree the logbuffer. Currently, do not use the mode.
						Currently, we do not use the mode
						*/
						vfree(pcore->plogbuffer);
#endif
					}
				}
			}
#endif
			ret = -ERESTARTSYS;
			do_exit(ret);
			return ret;
		}
#endif
	}
#endif
	remove_wait_queue(&penv->wq_bglog_breaksleep, &wait);
	set_current_state(TASK_RUNNING);
	//pr_err(VASTAI_LOGSYS_PR_HEAD "timeout[%d]line[%d]\n", timeoutret, __LINE__);
	mutex_lock(&penv->mutex_bgthread);
	if (penv->bbgquit == 1) {
		penv->bbgquit = 0;
		if (penv->bbgpciremoved == 1) {
			//pr_err(VASTAI_LOGSYS_PR_HEAD "bbgpciremoved unexpected 1 line[%d]\n", __LINE__);
			penv->bbgpciremoved = 0;
		}
		if (penv->bbgpciinserted == 1) {
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "bbgpciinserted unexpected 1 line[%d]\n",
			       __LINE__);
			penv->bbgpciinserted = 0;
		}
		mutex_unlock(&penv->mutex_bgthread);
		goto out;
	}
	if (penv->bbgpciremoved == 1) {
		penv->bbgreceived_pciremovedmsg = 1;
		penv->bbgpciremoved = 0;
		if (penv->bbgpciinserted == 1) {
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "bbgpciinserted unexpected 1 line[%d]\n",
			       __LINE__);
			penv->bbgpciinserted = 0;
		}
		mutex_unlock(&penv->mutex_bgthread);
		wake_up(&penv->wq_bglog_hasreceivedmsg);
		while (1) {
			/*
			Wait pci removed event handle over.
			*/
			add_wait_queue(&penv->wq_bglog_pci_removed, &wait);
			set_current_state(TASK_UNINTERRUPTIBLE);
			timeoutret = wait_event_timeout(
				penv->wq_bglog_pci_removed,
				((penv->bbgquit == 1) ||
				 (penv->bbgpciremoveddone == 1)),
				HZ / 10); // 0.001 second(suppose 1G hz)
			remove_wait_queue(&penv->wq_bglog_pci_removed, &wait);
			set_current_state(TASK_RUNNING);
			//pr_err(VASTAI_LOGSYS_PR_HEAD "timeout[%d]line[%d]\n", timeoutret, __LINE__);
			mutex_lock(&penv->mutex_bgthread);
			if (penv->bbgquit == 1) {
				//pr_err(VASTAI_LOGSYS_PR_HEAD "bbgquit unexpected 1 line[%d]\n", __LINE__);
				penv->bbgquit = 0;
				mutex_unlock(&penv->mutex_bgthread);
				goto out;
			}
			if (penv->bbgpciremoveddone == 1) {
				penv->bbgpciremoveddone = 0;
				mutex_unlock(&penv->mutex_bgthread);
				goto gotofirstcore;
			}
			mutex_unlock(&penv->mutex_bgthread);
		}
	} else if (penv->bbgpciinserted == 1) {
		penv->bbgpciinserted = 0;
		mutex_unlock(&penv->mutex_bgthread);
		goto gotofirstcore;
	}

	mutex_unlock(&penv->mutex_bgthread);
	/*
	When not special case, we move the current core to the next.
	*/
	if (ppci == NULL) {
		/*
		Check again.
		*/
		mutex_lock(&penv->mutex_pci_list);
		ppci = penv->ppci_head;
		mutex_unlock(&penv->mutex_pci_list);
		if (ppci == NULL) {
			//timeouthz = HZ/10;
			goto sleepwaitsignal;
		} else {
			diei = 0;
			pdie = &ppci->parray_die_env[diei];
			corei = 0;
			pcore = &pdie->parray_core_env[corei];
			goto corelog;
		}
	}

	//if (timeouthz == HZ/100)
	{
		//pr_info(VASTAI_LOGSYS_PR_HEAD "goto corelogloop current pci[%d]die[%d]core[%d]\n", ppci->pci_dev_id, pdie->die_index, pcore->core_index);
		//goto corelogloop;
	}

	//pr_info(VASTAI_LOGSYS_PR_HEAD "goto corelog current pci[%d]die[%d]core[%d]\n", ppci->pci_dev_id, pdie->die_index, pcore->core_index);

	/*
	When run here means just already loop once.
	*/
	goto corelog;

#if 0
	if (corei + 1 < VASTAI_LOGSYS_CORECOUNT)
	{
		corei ++;
		pcore = &pdie->parray_core_env[corei];
		goto corelog;
	}

#if 0
	/*
	Only for debug, do not read the second die.
	*/
	corei = 0;
	pcore = &pdie->parray_core_env[corei];
	goto corelog;
#endif

	/*
	core index reach the end
	*/
	if (diei + 1 < ppci->die_count)
	{
		diei ++;
		pdie = &ppci->parray_die_env[diei];
		corei = 0;
		pcore = &pdie->parray_core_env[corei];
		goto corelog;
	}
	/*
	die index reach the end
	*/
	mutex_lock(&penv->mutex_pci_list);
	if (ppci->pnext != NULL)
	{
		ppci = ppci->pnext;
	}
	else
	{
		ppci = penv->ppci_head;
	}
	mutex_unlock(&penv->mutex_pci_list);
	diei = 0;
	pdie = &ppci->parray_die_env[diei];
	corei = 0;
	pcore = &pdie->parray_core_env[corei];
	goto corelog;
#endif

out:
	penv->bbgfinishquit = 1;
	wake_up(&penv->wq_bglog_finishquit);
	return ret;
}

#if 0

struct timer_list					_timerreadlog;

static void timer_function(unsigned long i_input)
{
	//pr_info("TIMER RUN HERE 1111!\n");
	if (_penv == NULL)
	{
		del_timer(&_timerreadlog);
		return;
	}
	//pr_info("TIMER RUN HERE! 2222\n");
	_penv->breadlog = 1;
	wake_up(&_penv->wq_bglog_pci_removed);
	del_timer(&_timerreadlog);
	init_timer(&_timerreadlog);
	_timerreadlog.function = timer_function;
	_timerreadlog.data = (unsigned long) 0;
	_timerreadlog.expires = jiffies + HZ / 10;
	add_timer(&_timerreadlog);
}

#endif

/*
Run when insmod vastai_pci.ko
*/
int vastai_logsys_probe_init(struct vastai_pci_info *i_pci_info)
{
	int ret = 0;
	dev_t dev = 0;
	//int logi;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	struct vastai_pci_info *ppciinfo = i_pci_info = NULL;
	//u32 diecount;
	u32 diei = 0;
	u32 corei = 0;
	u32 puseri = 0;
	//struct timeval tv;
	struct rtc_time tm = { 0 };
	char filepath[VASTAI_LOGSYS_FILE_DIR_MAXLEN] = { 0 };
	char indexstr[32] = { 0 };
	char coredscr[32] = { 0 };

	SIMPLE_DEBUG_LOG;

	if (penv != NULL) {
		goto afterinitpenv;
	}
	penv = kzalloc(sizeof(struct vastai_logsys_env), GFP_KERNEL);
	if (penv == NULL) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "%s: failed to kzalloc vastai_logsys device\n",
		       __func__);
		return -ENOMEM;
	}

	/*
	First set the error index to no error.
	*/
	penv->errorindex = VASTAI_LOGSYS_ENV_ERROR_NOERROR;

	_penv = penv;

	ret = alloc_chrdev_region(&dev, 0, VASTAI_LOGSYS_MAX_DEVICES,
				  VASTAI_LOGSYS_DEVICE_NAME);
	if (ret) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "%s: failed to register vastai_logsys device\n",
		       __func__);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_REGISTERDEVICE_FAIL);
		return -19; //ENODEV;
	}
	penv->dev = dev;

#if (PC_ENV == 0)
	penv->cdev.owner = THIS_MODULE;
	cdev_init(&penv->cdev, &_fop);
	ret = cdev_add(&penv->cdev, dev, VASTAI_LOGSYS_MAX_DEVICES);
	if (ret) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_CDEV_ADD_FAIL);
		goto out;
	}

#if KERNEL_VERSION(6,4,0) > LINUX_VERSION_CODE
		penv->class = class_create(THIS_MODULE, VASTAI_LOGSYS_DEVICE_NAME);
#else
		penv->class = class_create(VASTAI_LOGSYS_DEVICE_NAME);
#endif
	if (IS_ERR(penv->class)) {
		ret = PTR_ERR(penv->class);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_CLASS_CREATE_FAIL);
		goto out_unreg_chrdev;
	}
	penv->device = device_create(penv->class, NULL, dev, NULL,
				     VASTAI_LOGSYS_DEVICE_NAME);
	if (IS_ERR(penv->device)) {
		ret = PTR_ERR(penv->device);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_DEVICE_CREATE_FAIL);
		goto out_unreg_class;
	}
#endif

	/*
	Init pci and user linked list.
	*/
	mutex_init(&penv->mutex_pci_list);
	mutex_lock(&penv->mutex_pci_list);
	penv->ppci_head = penv->ppci_tail = NULL;
	mutex_unlock(&penv->mutex_pci_list);

	mutex_init(&penv->mutex_user_list);
	mutex_lock(&penv->mutex_user_list);
	penv->puser_head = penv->puser_tail = NULL;
	mutex_unlock(&penv->mutex_user_list);

	/*
	Set default bind info.
	*/
	mutex_init(&penv->mutex_bindinfodef);
	mutex_lock(&penv->mutex_bindinfodef);
	internal_vastai_logsys_user_bindinfo_init(&penv->bindinfodef);
	mutex_unlock(&penv->mutex_bindinfodef);

	SIMPLE_DEBUG_LOG;

	/*
	Ensure the file directory exist.
	*/
#if 1
	internal_vastai_logsys_createdir(VASTAI_LOGSYS_FILE_DIR);
#else
	/*
	Can not use the following user mode function.
	*/
	if (opendir(VASTAI_LOGSYS_FILE_DIR) == NULL) {
		/*
		Need to create the directory.
		Let group user and other user can not w/x file.
		*/
		if (mkdir(VASTAI_LOGSYS_FILE_DIR, S_IRWXU | S_IRGRP | S_IROTH) <
		    0) {
			ret = -ENOENT;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				penv,
				VASTAI_LOGSYS_ENV_ERROR_CREATE_LOGSYS_DIR_FAIL);
			goto out_unreg_penv;
		}
	}
#endif
	/*
	Get file path according to the local time.
	*/
	internal_vastai_gettimeofday(&tm);
	sprintf(filepath,
		VASTAI_LOGSYS_FILE_DIR VASTAI_LOGSYS_FILE_SPLIT
		"%d_%d_%d_%d_%d_%d",
		tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour,
		tm.tm_min, tm.tm_sec);
	strcpy(penv->filepathbase, filepath);
#if 1
	/*
	Create the base directory of all vastai pci logsys.
	*/
	internal_vastai_logsys_rmandcreatedir(filepath);
#else
	/*
	When exist the directory, rm the directory.
	*/
	if (opendir(filepath) == NULL) {
		if (rmdir(filepath) < 0) {
			ret = -ENOENT;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				penv,
				VASTAI_LOGSYS_ENV_ERROR_DELETE_OLD_DIR_FAIL);
			goto out_unreg_penv;
		}
	}
	/*
	New the directory of the base directory of once kernel module run.
	*/
	if (mkdir(filepath, S_IRWXU | S_IRGRP | S_IROTH) < 0) {
		ret = -ENOENT;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_NEW_DIR_FAIL);
		goto out_unreg_penv;
	}
#endif

	/*
	Create background thread which will iterate every core of every die of every pci.
	*/
	mutex_init(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;
	mutex_lock(&penv->mutex_bgthread);
	penv->bbgquit = 0;
	penv->bbgfinishquit = 0;
	penv->bbgpciinserted = 0;
	penv->bbgpciremoved = 0;
	penv->bsignalquit = 0;
	penv->bbgreceived_pciremovedmsg = 0;
	penv->bbgpciremoveddone = 0;
	penv->breadlog = 0;
	init_waitqueue_head(&penv->wq_bglog_breaksleep);
	init_waitqueue_head(&penv->wq_bglog_hasreceivedmsg);
	init_waitqueue_head(&penv->wq_bglog_pci_removed);
	init_waitqueue_head(&penv->wq_bglog_finishquit);
	mutex_unlock(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;
#if (PC_ENV == 0)
	penv->pbgthread = kthread_create(internal_thread_log_background, penv,
					 "background_log");
	SIMPLE_DEBUG_LOG;
	if (!IS_ERR(penv->pbgthread)) {
		wake_up_process(penv->pbgthread);
	}
	SIMPLE_DEBUG_LOG;
#endif

#if 0
	init_timer(&_timerreadlog);
	_timerreadlog.function = timer_function;
	_timerreadlog.data = (unsigned long) 0;
	_timerreadlog.expires = jiffies + HZ / 10;
	add_timer(&_timerreadlog);
#endif

afterinitpenv:

	/*
	Init every core of every die of the current pci.
	*/

	/*
	kzalloc pci node
	*/
	ppci = kzalloc(sizeof(struct vastai_logsys_pci_env), GFP_KERNEL);
	if (ppci == NULL) {
		pr_err("VASTAI_LOGSYS_PR_HEAD kzalloc size[%lu] no memory\n",
		       sizeof(struct vastai_logsys_pci_env));
		VASTAI_LOGSYS_ENV_ERROR_RECORD(penv,
					       VASTAI_LOGSYS_ENV_ERROR_NOMEM);
		goto out_unreg_penv;
	}

	ppci->pci_dev_id = _pci_dev_id;
	_pci_dev_id++;
	ppci->p_pci_info = ppciinfo;
	ppci->die_count = i_pci_info->die_num_in_fn;
	atomic_set(&ppci->bbeingdestroyed, 0);

	/*
	Before init every die of the current pci, get the current file path base.
	*/
	strcpy(ppci->filepathbase, penv->filepathbase);
	strcat(ppci->filepathbase, VASTAI_LOGSYS_FILE_SPLIT);
	strcat(ppci->filepathbase, "pci");
	sprintf(indexstr, "%d", ppci->pci_dev_id);
	strcat(ppci->filepathbase, indexstr);
	/*
	Get the current time of pci inserted.
	*/
	internal_vastai_gettimeofday(&tm);
	sprintf(filepath, VASTAI_LOGSYS_FILE_PCI_TIMEFORMAT, tm.tm_hour,
		tm.tm_min, tm.tm_sec);
	strcat(ppci->filepathbase, filepath);
	/*
	Create the current pci base directory.
	*/
	internal_vastai_logsys_createdir(ppci->filepathbase);

#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "ppci->die_count = %d\n",
		ppci->die_count);
#endif

	for (diei = 0; diei < ppci->die_count; diei++) {
		pdie = &ppci->parray_die_env[diei];
		pdie->pci_dev_id = ppci->pci_dev_id;
		pdie->p_pci_info = ppciinfo;
		pdie->die_index = diei;
		pdie->die_index_global = i_pci_info->dies[diei].die_index;
		atomic_set(&pdie->bbeingdestroyed, 0);
		sprintf(indexstr, "%d[%d]", diei, pdie->die_index_global);
		sprintf(pdie->filepathbase, "%s" VASTAI_LOGSYS_FILE_SPLIT "%s",
			ppci->filepathbase, indexstr);
		/*
		Create the current die base directory.
		*/
		internal_vastai_logsys_createdir(pdie->filepathbase);

		for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
			pcore = &pdie->parray_core_env[corei];
			pcore->pci_dev_id = ppci->pci_dev_id;
			pcore->p_pci_info = ppciinfo;
			pcore->die_index = diei;
			pcore->die_index_global = pdie->die_index_global;
			pcore->core_index = corei;
			atomic_set(&pcore->bbeingdestroyed, 0);
			mutex_init(&pcore->mutex_core);
			mutex_lock(&pcore->mutex_core);
			for (puseri = 0;
			     puseri < VASTAI_LOGSYS_PERCORE_USER_MAX;
			     puseri++) {
				pcore->parray_puserbblock[puseri] = 0;
				pcore->parray_puser[puseri] = NULL;
			}
			pcore->puser_clearbuffer = NULL;
			pcore->bblock_clearbuffer = 0;
			internal_getcoredscrbycoreid((unsigned char *)coredscr,
						     _parray_coreid[corei]);
			sprintf(pcore->filelist.filepathbase,
				"%s" VASTAI_LOGSYS_FILE_SPLIT "%s",
				pdie->filepathbase, coredscr);
			/*
			Create the current core base directory.
			*/
			internal_vastai_logsys_createdir(
				pcore->filelist.filepathbase);
#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
			/*
			The vmalloc operation. Currently, we do not use the mode.
			*/
			pcore->plogbuffer = vmalloc(VASTAI_LOGSYS_BUF_SIZE);
#endif
			internal_vastai_logsys_corelog_init_fileandlogbuffer(
				pcore);
			mutex_unlock(&pcore->mutex_core);
		}
	}

	/*
	When pci is ready, add to the pci linked list.
	*/
	mutex_lock(&penv->mutex_pci_list);
	if (penv->ppci_tail == NULL) {
		ppci->ppre = ppci->pnext = NULL;
		penv->ppci_head = penv->ppci_tail = ppci;
	} else {
		penv->ppci_tail->pnext = ppci;
		ppci->ppre = penv->ppci_tail;
		penv->ppci_tail = ppci;
	}
	mutex_unlock(&penv->mutex_pci_list);
	/*
	Notify the pci insert event.
	*/
	mutex_lock(&penv->mutex_bgthread);
	penv->bbgpciinserted = 1;
	wake_up(&penv->wq_bglog_breaksleep);
	mutex_unlock(&penv->mutex_bgthread);

	/*
	Init succeed.
	*/
	//for (logi = 0; logi < 10; logi ++)
	{
		pr_err(VASTAI_LOGSYS_PR_HEAD "logsys init succeed!\n");
	}
	return 0;

out_unreg_penv:
	/*
	The bg thread may exist. So we can not destroy the mutex.
	*/
	//mutex_destroy(&penv->mutex_pci_list);
	//mutex_destroy(&penv->mutex_user_list);

	/*
	Currently, do not do any release operation.
	*/

out_unreg_class:
	//class_destroy(penv->class);
out_unreg_chrdev:
	//cdev_del(&(penv->cdev));
out:
	//unregister_chrdev_region(dev, VASTAI_LOGSYS_MAX_DEVICES);
	//kfree(penv);
	pr_err(VASTAI_LOGSYS_PR_HEAD "%s: driver init failed\n", __FILE__);
	return ret;
}

void vastai_logsys_remove_deinit(struct vastai_pci_info *i_pci_info)
{
	int ret = 0;
	u32 timeoutret = 0;
	int logi = 0;
	struct vastai_logsys_env *penv = NULL;
	dev_t dev = 0;
	struct vastai_logsys_user *puser = NULL, *puserdel = NULL;
	struct vastai_logsys_pci_env *ppci = NULL, *ppcidel = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	u32 diei = 0;
	u32 corei = 0;
	u32 useri = 0;
	u32 bthelastpci = 0;
	//char filepathbasenew[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
	//struct rtc_time tm;

	DECLARE_WAITQUEUE(wait, current);

	pr_err(VASTAI_LOGSYS_PR_HEAD "remove deinit operation!\n");

	ret = VASTAI_LOGSYS_ENV_CHECK(_penv);
	SIMPLE_DEBUG_LOG;
	if (ret < 0) {
		return;
	}
	penv = _penv;
	mutex_lock(&penv->mutex_pci_list);
	/*
	First, try to find the current pci.
	*/
	ppci = penv->ppci_head;
	ppcidel = NULL;
	while (ppci) {
		if (ppci->p_pci_info == i_pci_info) {
			ppcidel = ppci;
			break;
		}
	}
	mutex_unlock(&penv->mutex_pci_list);
	SIMPLE_DEBUG_LOG;
	if (ppcidel == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			penv, VASTAI_LOGSYS_ENV_ERROR_REMOVE_CANNOT_FIND_PCI);
		return;
	}

	/*
	First, wait the background thread receive the pci remove msg.
	*/
	mutex_lock(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;
	penv->bbgpciremoved = 1;
	wake_up(&penv->wq_bglog_breaksleep);
	while (1) {
		if (penv->bbgreceived_pciremovedmsg == 1) {
			break;
		}
		mutex_unlock(&penv->mutex_bgthread);
		add_wait_queue(&penv->wq_bglog_hasreceivedmsg, &wait);
		set_current_state(TASK_UNINTERRUPTIBLE);
		SIMPLE_DEBUG_LOG;
		timeoutret = wait_event_timeout(
			penv->wq_bglog_hasreceivedmsg,
			(penv->bbgreceived_pciremovedmsg == 1),
			HZ / 10); // every 0.0001 second(1G)
		remove_wait_queue(&penv->wq_bglog_hasreceivedmsg, &wait);
		set_current_state(TASK_RUNNING);
		SIMPLE_DEBUG_LOG;
		mutex_lock(&penv->mutex_bgthread);
	}

	mutex_unlock(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;

	/*
	Tag pci/die/core that is being destroyed. Whenever the user is in operation or 
	not, whatever the user is block operation or not, mutex into the user lock and 
	clear the bind core list. And then clear the puser of the correspondent core.
	User can know by enter lock and check the userdrvoper is 
	VASTAI_LOGSYS_USERDRV_OPER_NEEDREBIND.
	Of course, when the user operation is block mode, we should signal it to break 
	block.
	*/
	atomic_set(&ppcidel->bbeingdestroyed, 1);
	SIMPLE_DEBUG_LOG;
	for (diei = 0; diei < ppcidel->die_count; diei++) {
		pdie = &ppcidel->parray_die_env[diei];
		atomic_set(&pdie->bbeingdestroyed, 1);
		for (corei = 0; corei < pdie->die_count; corei++) {
			pcore = &pdie->parray_core_env[corei];
			atomic_set(&pcore->bbeingdestroyed, 1);
			SIMPLE_DEBUG_LOG;
			/*
			Get the next user of the core to handle.
			*/
			mutex_lock(&pcore->mutex_core);
			for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX;
			     useri++) {
				puser = pcore->parray_puser[useri];
				if (puser != NULL) {
					/*
					Release the core mutex before iterate the user bind core
					list.
					*/
					mutex_unlock(&pcore->mutex_core);

					/*
					Handle user unbind operation. Not only unbind the current core, but 
					unbind other core which correspondent to the user.
					*/
					internal_vastai_logsys_unbind_allcore_oftheuser_bybgthread(
						puser);

					mutex_lock(&pcore->mutex_core);
				}
			}
			mutex_unlock(&pcore->mutex_core);
		}
	}
	SIMPLE_DEBUG_LOG;

	/*
	After notify and unbind all correspondent user, we can delete the pci 
	from the linked list now, 
	*/
	bthelastpci = 0;
	mutex_lock(&penv->mutex_pci_list);
	if (ppcidel->ppre != NULL) {
		ppcidel->ppre->pnext = ppcidel->pnext;
	}
	if (ppcidel->pnext != NULL) {
		ppcidel->pnext->ppre = ppcidel->ppre;
	}
	if (ppcidel == penv->ppci_head) {
		if (ppcidel == penv->ppci_tail) {
			penv->ppci_head = penv->ppci_tail = NULL;
			bthelastpci = 1;
		} else {
			penv->ppci_head = penv->ppci_head->pnext;
		}
	} else if (ppcidel == penv->ppci_tail) {
		penv->ppci_tail = penv->ppci_tail->ppre;
	}
	SIMPLE_DEBUG_LOG;
	mutex_unlock(&penv->mutex_pci_list);
	SIMPLE_DEBUG_LOG;
	for (diei = 0; diei < ppcidel->die_count; diei++) {
		pdie = &ppcidel->parray_die_env[diei];
		for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
			pcore = &pdie->parray_core_env[corei];
			mutex_destroy(&pcore->mutex_core);
			internal_vastai_logsys_corelog_deinit_fileandlogbuffer(
				pcore);
#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
			/*
			vfree the logbuffer. Currently, do not use the mode.
			Currently, we do not use the mode
			*/
			vfree(pcore->plogbuffer);
#endif
		}
	}
#if 0
	/*
	In the end, add the end time to the file base of the removed pci.
	*/
	internal_vastai_gettimeofday(&tm);
	sprintf(filepathbasenew, "%s-" VASTAI_LOGSYS_FILE_PCI_TIMEFORMAT, tm.tm_hour, tm.tm_min, tm.tm_sec);
	internal_vastai_logsys_mvdir(ppcidel->filepathbase, filepathbasenew);
#endif
	kfree(ppcidel);
	SIMPLE_DEBUG_LOG;
	/*
	The pci remove operation is done, notify the bg thread to continue read log.
	*/
	mutex_lock(&penv->mutex_bgthread);
	penv->bbgpciremoveddone = 1;
	SIMPLE_DEBUG_LOG;
	wake_up(&penv->wq_bglog_pci_removed);
	mutex_unlock(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;

	if (bthelastpci == 0) {
		return;
	}

	//isthelastpci:
	/*
	Stop the background thread.
	*/
	mutex_lock(&penv->mutex_bgthread);
	penv->bbgquit = 1;
	wake_up(&penv->wq_bglog_breaksleep);
	mutex_unlock(&penv->mutex_bgthread);
	SIMPLE_DEBUG_LOG;
	/*
	Here, we should wait until the bg thread quit.
	*/
	while (1) {
		add_wait_queue(&penv->wq_bglog_finishquit, &wait);
		SIMPLE_DEBUG_LOG;
		set_current_state(TASK_UNINTERRUPTIBLE);
		SIMPLE_DEBUG_LOG;
		timeoutret = wait_event_timeout(
			penv->wq_bglog_finishquit, (penv->bbgfinishquit),
			HZ * 10); // 0.01 second(suppose 1G hz)
		remove_wait_queue(&penv->wq_bglog_finishquit, &wait);
		SIMPLE_DEBUG_LOG;
		set_current_state(TASK_RUNNING);
		SIMPLE_DEBUG_LOG;
		if (penv->bbgfinishquit == 1) {
			penv->bbgfinishquit = 0;
			break;
		}
	}
	if (penv->bsignalquit != 1) {
		SIMPLE_DEBUG_LOG;
		kthread_stop(penv->pbgthread);
		SIMPLE_DEBUG_LOG;
	}
	mutex_destroy(&penv->mutex_bgthread);

	/*
	When remove the last pci, need to deinit the env control variable.
	*/
	dev = penv->dev;
	device_destroy(penv->class, dev);
	class_destroy(penv->class);
	cdev_del(&penv->cdev);
	unregister_chrdev_region(dev, VASTAI_LOGSYS_MAX_DEVICES);

	mutex_lock(&penv->mutex_user_list);
	SIMPLE_DEBUG_LOG;
	puser = penv->puser_head;
	while (puser) {
		puserdel = puser;
		puser = puser->pnext;
		kfree(puserdel);
	}
	mutex_unlock(&penv->mutex_user_list);
	SIMPLE_DEBUG_LOG;

	mutex_lock(&penv->mutex_pci_list);
	ppci = penv->ppci_head;
	while (ppci) {
		ppcidel = ppci;
		ppci = ppci->pnext;
	}
	mutex_unlock(&penv->mutex_pci_list);

	mutex_destroy(&penv->mutex_user_list);
	mutex_destroy(&penv->mutex_pci_list);

	mutex_lock(&penv->mutex_bindinfodef);
	internal_vastai_logsys_user_bindinfo_deinit(&penv->bindinfodef);
	mutex_unlock(&penv->mutex_bindinfodef);
	mutex_destroy(&penv->mutex_bindinfodef);
	SIMPLE_DEBUG_LOG;

	kfree(_penv);
	_penv = NULL;
	SIMPLE_DEBUG_LOG;
}

static int vastai_logsys_open(struct inode *i_inode, struct file *io_pfile)
{
	struct vastai_logsys_env *penv = NULL;
	struct vastai_logsys_user *puser = NULL;
	SIMPLE_DEBUG_LOG;

	penv = container_of(i_inode->i_cdev, struct vastai_logsys_env, cdev);

	/*
	Create a new logsys user.
	*/
	puser = kzalloc(sizeof(struct vastai_logsys_user), GFP_KERNEL);
	if (!puser) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "%s: failed to kzalloc a new vastai_logsys user!\n",
		       __func__);
		return -ENOMEM;
	}
	puser->penv = penv;
	puser->fasync = NULL;

	mutex_init(&puser->mutex_user);

	mutex_lock(&puser->mutex_user);

	/*
	Other oper should use CHECKRET_INTERNAL_VASTAI_LOGSYS_DRVINNER_OPER_SET macro to set.
	*/
	puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_OPEN;
	puser->bunbindfinished = 0;
	puser->pcore_head = puser->pcore_tail = NULL;
	internal_vastai_logsys_user_readsession_reset_tonull(
		&puser->readsession);

	init_waitqueue_head(&puser->wq_breakblock);
	puser->bbreakblock = 0;

	puser->errorindex = VASTAI_LOGSYS_USER_ERROR_NOERROR;

	puser->callertype = VASTAI_LOGSYS_CALLER_SHELLCAT;

	mutex_lock(&penv->mutex_bindinfodef);
	/*
	The default caller mode is shellcat, it will copy the default bind info to the 
	user instance, so that when shellcat user do read operation, it will check whether 
	has bind and when not bind it will do bind operation.
	*/
	internal_vastai_logsys_user_bindinfo_init_by_src(&puser->bindinfo,
							 &penv->bindinfodef);
	puser->beginoffsetdef = penv->beginoffsetdef;
	mutex_unlock(&penv->mutex_bindinfodef);

	puser->infobuffertotalsize = 0;
	puser->infobuffercurrindex = 0;

	mutex_unlock(&puser->mutex_user);

	/*
	Add the new user to the end of chain.
	*/
	mutex_lock(&penv->mutex_user_list);
	if (penv->puser_tail == NULL) {
		puser->ppre = puser->pnext = NULL;
		penv->puser_head = penv->puser_tail = puser;
	} else {
		penv->puser_tail->pnext = puser;
		puser->ppre = penv->puser_tail;
		penv->puser_tail = puser;
	}
	mutex_unlock(&penv->mutex_user_list);

	io_pfile->private_data = puser;

	mutex_lock(&puser->mutex_user);
	puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;
	mutex_unlock(&puser->mutex_user);

	return 0;
}

/*
When current mode is info, it will output info immediately and return the total size which do not 
include '\0' at the end.
When current mode is log block, it will ensure buffer has log and return the total size which do 
not include '\0' at the end.
When current mode is log un-block, it will immediately return without wait until log dump in 
buffer.
*/
static ssize_t vastai_logsys_read(struct file *i_pfile, char __user *io_pbuffer,
				  size_t i_size, loff_t *io_ppos)
{
	int retmacroint = 0;
	u32 timeoutret = 0;
	ssize_t ret = i_size;
	ssize_t retsub = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;
	struct vastai_logsys_user_mode_log *plog = NULL;
	struct vastai_logsys_pci_die_pcore_node *pcorenode = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	struct vastai_logsys_user_readsession *preadsession = NULL;
	//u32 bneedrefresh;
	u32 infobufferleftsize = 0;
	u32 bclearbuffer = 0;
	u32 bblock = 0;
	u32 callertype = 0;
	loff_t beginoffsetdef = 0;
	size_t sizeleft = 0;
	loff_t curroffset = 0; // of user space buffer
	ssize_t retsigned = 0;
	loff_t outputtotalbyteindex = 0; // for corelog function output use
	/*
	Although the start pointer should be the current index begin when clearbuffer or block 
	mode, we need to record the current total byte index for the next operation use.
	*/
	//u32 totalbyteindex;
	u32 breachend = 0;
	/*
	For block mode use.
	*/
	DECLARE_WAITQUEUE(wait, current);
	SIMPLE_DEBUG_LOG;

#if (DEBUG_LOG == 1)
	pr_info("vastai logsys read begin\n");
#endif

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	SIMPLE_DEBUG_LOG;
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_READ);
	SIMPLE_DEBUG_LOG;

	if (puser->bindinfo.mode == VASTAI_LOGSYS_MODE_INFO) {
		SIMPLE_DEBUG_LOG;
		/*
		When mode is VASTAI_LOGSYS_CALLER_SHELLCAT,
		When the pos is not null, it means the function is called twice when do cat operation.
		*/
		if (puser->callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
			SIMPLE_DEBUG_LOG;
			if (*io_ppos == 0) {
				SIMPLE_DEBUG_LOG;
				/*
				Re-get the info.
				*/
				mutex_unlock(&puser->mutex_user);
				SIMPLE_DEBUG_LOG;
				retsub =
					internal_vastai_logsys_refreshinfobuffer(
						puser);
				SIMPLE_DEBUG_LOG;
				if (retsub ==
				    VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE) {
					SIMPLE_DEBUG_LOG;
					/*
					Do not need to change the oper due to the unexpected inner error.
					*/
					return -retsub;
				} else if (
					retsub ==
						VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE ||
					retsub ==
						VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE) {
					RET_VASTAI_LOGSYS_SET_NOOPER(puser,
								     -retsub);
					SIMPLE_DEBUG_LOG;
				} else if (retsub ==
						   VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH ||
					   retsub == 0) {
					SIMPLE_DEBUG_LOG;
					if (i_size == 0) {
						SIMPLE_DEBUG_LOG;
						RET_VASTAI_LOGSYS_SET_NOOPER(
							puser, 0);
					}
					CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
					if (i_size >=
					    puser->infobuffertotalsize) {
						SIMPLE_DEBUG_LOG;
						copy_to_user(
							io_pbuffer,
							puser->infobuffer,
							puser->infobuffertotalsize);
						SIMPLE_DEBUG_LOG;
						puser->infobuffercurrindex =
							puser->infobuffertotalsize;
						ret = puser->infobuffertotalsize;
						*io_ppos = *io_ppos + ret;
					} else {
						SIMPLE_DEBUG_LOG;
						copy_to_user(io_pbuffer,
							     puser->infobuffer,
							     i_size);
						SIMPLE_DEBUG_LOG;
						puser->infobuffercurrindex =
							i_size;
						ret = i_size;
						*io_ppos = *io_ppos + ret;
					}
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				} else {
					SIMPLE_DEBUG_LOG;
					ret = -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
					VASTAI_LOGSYS_ENV_ERROR_RECORD(
						puser->penv,
						VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
					return ret;
				}
			}
			/*
			Still in user mutex.
			Run here meaning the current position is not 0. 
			*/
			if (*io_ppos != puser->infobuffercurrindex) {
				SIMPLE_DEBUG_LOG;
				ret = -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					puser->penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
				mutex_unlock(&puser->mutex_user);
				return ret;
			}
			infobufferleftsize = puser->infobuffertotalsize -
					     puser->infobuffercurrindex;
			SIMPLE_DEBUG_LOG;
			if (infobufferleftsize == 0) {
				SIMPLE_DEBUG_LOG;
				ret = 0;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
			if (i_size >= infobufferleftsize) {
				SIMPLE_DEBUG_LOG;
				copy_to_user(io_pbuffer,
					     puser->infobuffer +
						     puser->infobuffercurrindex,
					     infobufferleftsize);
				SIMPLE_DEBUG_LOG;
				ret = infobufferleftsize;
				puser->infobuffercurrindex =
					puser->infobuffercurrindex + ret;
				*io_ppos = *io_ppos + ret;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			} else {
				SIMPLE_DEBUG_LOG;
				copy_to_user(io_pbuffer,
					     puser->infobuffer +
						     puser->infobuffercurrindex,
					     i_size);
				SIMPLE_DEBUG_LOG;
				ret = i_size;
				puser->infobuffercurrindex =
					puser->infobuffercurrindex + ret;
				*io_ppos = *io_ppos + ret;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
		}
		/*
		Run here means VASTAI_LOGSYS_CALLER_C mode.
		Still in user mutex.
		Handle info mode read operation.
		Pos forward until reach one's operation end, when reach end, next get 
		will return 0 and set pos back to 0. When return size is smaller than 
		the input size, the pos automatically set back to 0.
		*/
		if (*io_ppos == 0) {
			SIMPLE_DEBUG_LOG;
			/*
			Re-get the info.
			*/
			mutex_unlock(&puser->mutex_user);
			SIMPLE_DEBUG_LOG;
			retsub =
				internal_vastai_logsys_refreshinfobuffer(puser);
			SIMPLE_DEBUG_LOG;
			if (retsub ==
			    VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE) {
				SIMPLE_DEBUG_LOG;
				/*
				Do not need to change the oper due to the unexpected inner error.
				*/
				return -retsub;
			} else if (
				retsub ==
					VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE ||
				retsub ==
					VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE) {
				SIMPLE_DEBUG_LOG;
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, -retsub);
			} else if (retsub ==
					   VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH ||
				   retsub == 0) {
				SIMPLE_DEBUG_LOG;
				if (i_size == 0) {
					SIMPLE_DEBUG_LOG;
					RET_VASTAI_LOGSYS_SET_NOOPER(puser, 0);
				}
				SIMPLE_DEBUG_LOG;
				CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
				if (i_size > puser->infobuffertotalsize) {
					SIMPLE_DEBUG_LOG;
					/*
					When the return size is smaller than the input size, we can automatically 
					set the current position back to 0 to trigger re-get when next read.
					*/
					copy_to_user(
						io_pbuffer, puser->infobuffer,
						puser->infobuffertotalsize);
					SIMPLE_DEBUG_LOG;
					puser->infobuffercurrindex =
						puser->infobuffertotalsize;
					ret = puser->infobuffertotalsize;
					*io_ppos = 0;
				} else {
					SIMPLE_DEBUG_LOG;
					copy_to_user(io_pbuffer,
						     puser->infobuffer, i_size);
					SIMPLE_DEBUG_LOG;
					puser->infobuffercurrindex = i_size;
					ret = i_size;
					*io_ppos = *io_ppos + ret;
				}
				SIMPLE_DEBUG_LOG;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			} else {
				SIMPLE_DEBUG_LOG;
				ret = -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					puser->penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
				return ret;
			}
		}
		/*
		Still in user mutex.
		Run here meaning the current position is not 0. 
		*/
		if (*io_ppos != puser->infobuffercurrindex) {
			SIMPLE_DEBUG_LOG;
			ret = -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			mutex_unlock(&puser->mutex_user);
			SIMPLE_DEBUG_LOG;
			return ret;
		}
		infobufferleftsize =
			puser->infobuffertotalsize - puser->infobuffercurrindex;
		SIMPLE_DEBUG_LOG;
		if (infobufferleftsize == 0) {
			SIMPLE_DEBUG_LOG;
			ret = 0;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
		}
		if (i_size > infobufferleftsize) {
			SIMPLE_DEBUG_LOG;
			/*
			When the input size is bigger than the left size, automatically set the pos 
			back to 0.
			*/
			copy_to_user(io_pbuffer,
				     puser->infobuffer +
					     puser->infobuffercurrindex,
				     infobufferleftsize);
			SIMPLE_DEBUG_LOG;
			ret = infobufferleftsize;
			puser->infobuffercurrindex =
				puser->infobuffercurrindex + ret;
			*io_ppos = 0;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
		} else {
			SIMPLE_DEBUG_LOG;
			copy_to_user(io_pbuffer,
				     puser->infobuffer +
					     puser->infobuffercurrindex,
				     i_size);
			ret = i_size;
			puser->infobuffercurrindex =
				puser->infobuffercurrindex + ret;
			*io_ppos = *io_ppos + ret;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
		}
	}

	/*
	Run here means mode is log mode.
	*/

	if (i_size == 0) {
		SIMPLE_DEBUG_LOG;
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
	}
	/*
	Still in user mutex.
	Size is not 0.
	Do the bind operation when it is shellcat mode and have not bind.
	We need to check because the cat operation will trigger read operation 
	more than once when the data size is big.
	*/
	callertype = puser->callertype;
	if (callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
		/*
		When not bind log, need to bind when do read operation.
		*/
		if (puser->pcore_head == NULL) {
			SIMPLE_DEBUG_LOG;
			plog = puser->bindinfo.puser_mode_log_head;
			if (plog == NULL) {
				SIMPLE_DEBUG_LOG;
				SIMPLE_KERNEL_LOG;
				ret = VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_NOBINDTOREAD;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
			while (plog) {
				SIMPLE_DEBUG_LOG;
				mutex_unlock(&puser->mutex_user);
				retsub =
					internal_vastai_logsys_bind_log_byuserthread(
						puser, plog);
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE(
					puser, retsub);
				CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
				plog = plog->pnext;
			}
			/*
			Still in user mutex.
			*/
			internal_vastai_logsys_user_readsession_reset_tonull(
				&puser->readsession);
			SIMPLE_DEBUG_LOG;
			mutex_lock(&puser->penv->mutex_bindinfodef);
			puser->beginoffsetdef = puser->penv->beginoffsetdef;
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&puser->penv->mutex_bindinfodef);
			SIMPLE_DEBUG_LOG;
		}
	}
	SIMPLE_DEBUG_LOG;
	/*
	Still in user mutex.
	Run here means already bind log.
	*/
	/*
	When the pcorenode is NULL, we need to find the start point which have log, 
	when all of the node has no log and the type is not block mode, we will not read 
	anything. When the mode is block mode, we will wait until have find log. 
	*/
	bclearbuffer = puser->bindinfo.puser_mode_log_head->bclearbuffer;
	bblock = puser->bindinfo.puser_mode_log_head->bblock;
	preadsession = &puser->readsession;
	if (bclearbuffer == 1 || bblock == 1) {
		/*
		When the current mode is clearbuffer or block mode, we set the beginoffsetdef 
		to 0 which will be used afterwards.
		*/
		if (puser->beginoffsetdef != 0) {
			SIMPLE_KERNEL_LOG;
			/*
			Ignore the beginoffsetdef setting, set the start point to the current 
			start index.
			*/
			beginoffsetdef = 0;
		} else {
			beginoffsetdef = 0;
		}
	} else {
		beginoffsetdef = puser->beginoffsetdef;
	}
	SIMPLE_DEBUG_LOG;
	if (*io_ppos == 0) {
		/*
		Run here means *pos is 0.
		Need reset the readsession to null.
		Every cat operation will first enter with the pos is 0.
		C user can use llseek to set the position to 0 to trigger re-get.
		*/
		internal_vastai_logsys_user_readsession_reset_tonull(
			preadsession);
		SIMPLE_DEBUG_LOG;
	}
	SIMPLE_DEBUG_LOG;
	if (preadsession->pcorenode != NULL) {
		SIMPLE_DEBUG_LOG;
		/*
		When run here, the *io_ppos is not 0. The block mode only affect the first read 
		operation of one operation.
		When run here, when caller C mode, the last operation is not over. Because when 
		it is over, the last operation will let the preadsession reset to NULL.
		*/
		if (preadsession->totalbyteindexcurr ==
			    preadsession->totalbyteindexend &&
		    preadsession->pcorenode == puser->pcore_tail) {
			SIMPLE_DEBUG_LOG;
			/*
			Case One.
			Still in user mutex.
			When shellcat's last read data is not enough to read, it will cause the case that 
			the read point is the end and the input pos is not 0. So when it is the case, we 
			will do nothing but return 0. And in addition, we set the inner readsession back 
			to null for program more reliable.
			*/
			/*
			Case Two.
			Still in user mutex.
			When user c last read data is just reach the end and the size is match, it will 
			cause the last read operation will not trigger inner readsession back to null. 
			So when the pos is not 0, and the read point is the end, we need to set the inner 
			readsession back to null.
			*/
			internal_vastai_logsys_user_readsession_reset_tonull(
				preadsession);
			SIMPLE_DEBUG_LOG;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
			SIMPLE_DEBUG_LOG;
		}
		SIMPLE_DEBUG_LOG;
		/*
		When run here, it do not means it must have data. We need to check whether have data.
		Be careful, the following function will enter core lock when have data to read.
		When return value is not 0, it will not enter core lock.
		*/
		retsub =
			internal_vastai_logsys_user_readsession_update_finddatatoread(
				preadsession, &breachend, callertype,
				beginoffsetdef);
		if (retsub > 0) {
			SIMPLE_DEBUG_LOG;
			CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
				puser, retsub);
		}
		if (breachend == 1) {
			SIMPLE_DEBUG_LOG;
			internal_vastai_logsys_user_readsession_reset_tonull(
				preadsession);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
		}
		/*
		When run here, pcorenode is not NULL and have data to read, and enter lock of core to 
		be read data. Set the current pcorenode and pcore and then goto the read operation.
		*/
		pcorenode = preadsession->pcorenode;
		SIMPLE_DEBUG_LOG;
		pcore = pcorenode->pcore;
		goto hasfounddatatoread;
	}

	/*
	Still in user mutex.
	pcorenode of preadsession is NULL.
	Need to init and block according to the settings.
	*/
	if (puser->pcore_head == NULL) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_NOBINDTOREAD;
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
	}
	pcorenode = puser->pcore_head;
	SIMPLE_DEBUG_LOG;
	retsub = internal_vastai_logsys_user_readsession_init_bycorenode(
		preadsession, &breachend, pcorenode, callertype,
		beginoffsetdef);
	if (retsub > 0) {
		CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
			puser, retsub);
	}
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD
		"preadsession->totalbyteindexcurr = %ld, preadsession->totalbyteindexnext = %ld, preadsession->totalbyteindexend = %ld\n",
		preadsession->totalbyteindexcurr,
		preadsession->totalbyteindexnext,
		preadsession->totalbyteindexend);
#endif
	if (breachend == 0) {
		pcorenode = preadsession->pcorenode;
		SIMPLE_DEBUG_LOG;
		pcore = pcorenode->pcore;
		goto hasfounddatatoread;
	}
	/*
	No data to read.
	*/
	if (bblock == 0) {
		SIMPLE_DEBUG_LOG;
		/*
		No data to read, return 0.
		*/
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
	}
	/*
	When block mode, we need to wait until data reach.
	*/
	mutex_unlock(&puser->mutex_user);
	SIMPLE_DEBUG_LOG;
	while (1) {
		/*
		Check whether have log. 
		Because when block mode, it is always from the current position.
		So check currbytesum of the core.
		*/
		CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
		pcorenode = puser->pcore_head;
		retsub =
			internal_vastai_logsys_user_readsession_init_bycorenode(
				preadsession, &breachend, pcorenode, callertype,
				beginoffsetdef);
		if (breachend == 0) {
			/*
			Have data to read.
			*/
			break;
		}
		/*
		Still no log, continue waiting.
		*/
		mutex_unlock(&puser->mutex_user);
		add_wait_queue(&puser->wq_breakblock, &wait);
		set_current_state(TASK_UNINTERRUPTIBLE);
		timeoutret =
			wait_event_timeout(puser->wq_breakblock,
					   (puser->bbreakblock == 1), HZ / 10);
		puser->bbreakblock =
			0; // it is in user thread, so do not need to worry that the user instance is invalid
		remove_wait_queue(&puser->wq_breakblock, &wait);
		set_current_state(TASK_RUNNING);
	}
	pcorenode = preadsession->pcorenode;
	pcore = pcorenode->pcore;

	/*
	Still in user mutex.
	Also in core mutex to read data.
	Now have data to read.
	Now the bufferindex is the current position next to read.
	*/
hasfounddatatoread:
	/*
	When run here, the preadsession should not reach end.
	*/
	if (preadsession->totalbyteindexcurr ==
	    preadsession->totalbyteindexend) {
		ret = -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		mutex_unlock(&puser->mutex_user);
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	if (callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
		SIMPLE_DEBUG_LOG;
		sizeleft = i_size;
		curroffset = 0;
	shellcat_readloop:
		/*
		Still in user and core mutex.
		When shellcat, we use the buffer of preadsession.
		*/
		if (sizeleft <
		    preadsession->buffersize - preadsession->bufferindex) {
			/*
			The current log is not over. So we do not need to clearbuffer when 
			clearbuffer mode.
			*/
			mutex_unlock(&pcore->mutex_core);
			copy_to_user(
				io_pbuffer + curroffset,
				&preadsession->buffer[preadsession->bufferindex],
				sizeleft);
			preadsession->bufferindex =
				preadsession->bufferindex + sizeleft;
			*io_ppos = *io_ppos + sizeleft;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, i_size);
		}
		if (sizeleft ==
		    preadsession->buffersize - preadsession->bufferindex) {
			/*
			First copy log to user.
			*/
			copy_to_user(
				io_pbuffer + curroffset,
				&preadsession->buffer[preadsession->bufferindex],
				sizeleft);
			*io_ppos = *io_ppos + sizeleft;
			/*
			The current log is over, we need to check clearbuffer mode.
			Check clearbuffer mode, when is clearbuffer mode, clear the previous 
			just done buffer.
			*/
			if (bclearbuffer == 1) {
				retsub =
					internal_vastai_logsys_user_readsession_clearcurrtonext(
						preadsession, pcorenode);
				if (retsub > 0) {
					mutex_unlock(&pcore->mutex_core);
					SIMPLE_KERNEL_LOG;
					CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
						puser, retsub);
				}
			}
			/*
			Move the current point to the next.
			*/
			preadsession->totalbyteindexcurr =
				preadsession->totalbyteindexnext;
			/*
			The current log is over, we need to prepare the next log.
			*/
			if (preadsession->totalbyteindexcurr ==
			    preadsession->totalbyteindexend) {
				/*
				When the next point is the end of the current core, we should find data
				to read in the following core node.
				*/
				mutex_unlock(&pcore->mutex_core);
				retsub =
					internal_vastai_logsys_user_readsession_update_finddatatoread(
						preadsession, &breachend,
						callertype, beginoffsetdef);
				if (retsub > 0) {
					SIMPLE_KERNEL_LOG;
					CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
						puser, retsub);
				}
				if (breachend == 0) {
					pcorenode = preadsession->pcorenode;
					pcore = pcorenode->pcore;
					mutex_unlock(&pcore->mutex_core);
				}
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser,
								    i_size);
			}
			/*
			Still in mutex user and core.
			There is still some log of the current core to be read by user.
			*/
			retsub =
				internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
					preadsession, pcorenode,
					VASTAI_LOGSYS_CALLER_SHELLCAT,
					preadsession->totalbyteindexcurr);
			if (retsub > 0) {
				mutex_unlock(&pcore->mutex_core);
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
			/*
			Currently, there is no space to store the log.
			*/
			mutex_unlock(&pcore->mutex_core);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, i_size);
		}
		/*
		Still in user mutex. 
		Still in core mutex.
		*/
		/*
		When run here, sizeleft > preadsession->buffersize - preadsession->bufferindex.
		*/
		/*
		After we copy the current log to user, we need to prepare the next log and 
		copy the log to the left user space buffer.
		*/
		copy_to_user(io_pbuffer + curroffset,
			     &preadsession->buffer[preadsession->bufferindex],
			     preadsession->buffersize -
				     preadsession->bufferindex);
		*io_ppos = *io_ppos + (preadsession->buffersize -
				       preadsession->bufferindex);
		sizeleft = sizeleft - (preadsession->buffersize -
				       preadsession->bufferindex);
		SIMPLE_DEBUG_LOG;
		curroffset = curroffset + (preadsession->buffersize -
					   preadsession->bufferindex);
		SIMPLE_DEBUG_LOG;
		/*
		The current log is over, we need to check clearbuffer mode.
		Check clearbuffer mode, when is clearbuffer mode, clear the previous 
		just done buffer.
		*/
		if (bclearbuffer == 1) {
			SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD
				"preadsession->totalbyteindexcurr = %d, preadsession->totalbyteindexend = %d\n",
				preadsession->totalbyteindexcurr,
				preadsession->totalbyteindexend);
#endif
			retsub =
				internal_vastai_logsys_user_readsession_clearcurrtonext(
					preadsession, pcorenode);
			if (retsub > 0) {
				mutex_unlock(&pcore->mutex_core);
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
		}
		SIMPLE_DEBUG_LOG;
		/*
		Move the current point to the next.
		*/
		preadsession->totalbyteindexcurr =
			preadsession->totalbyteindexnext;
		SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"preadsession->totalbyteindexcurr = %d, preadsession->totalbyteindexend = %d\n",
			preadsession->totalbyteindexcurr,
			preadsession->totalbyteindexend);
#endif
		/*
		Still in user and core mutex.
		The current log is over, we need to prepare the next log.
		*/
		if (preadsession->totalbyteindexcurr ==
		    preadsession->totalbyteindexend) {
			/*
			When the next point is the end of the current core, we should find data
			to read in the following core node.
			*/
			mutex_unlock(&pcore->mutex_core);
			SIMPLE_DEBUG_LOG;
			retsub =
				internal_vastai_logsys_user_readsession_update_finddatatoread(
					preadsession, &breachend, callertype,
					beginoffsetdef);
			if (retsub > 0) {
				SIMPLE_KERNEL_LOG;
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
			SIMPLE_DEBUG_LOG;
			if (breachend == 1) {
				/*
				When reach end, we should return the current get size.
				Now is shellcat mode, so we do not need to reset preadsession to NULL as c mode.
				*/
				ret = i_size - sizeleft;
				SIMPLE_DEBUG_LOG;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
			pcorenode = preadsession->pcorenode;
			pcore = pcorenode->pcore;
			/*
			We have already update sizeleft and curroffset value when do copy_to_user 
			operation.
			*/
			goto shellcat_readloop;
		}
		SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"preadsession->totalbyteindexcurr = %d\n",
			preadsession->totalbyteindexcurr);
#endif
		/*
		Still in user and core mutex.
		There is still some log of the current core to be read by user.
		*/
		retsub =
			internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
				preadsession, pcorenode,
				VASTAI_LOGSYS_CALLER_SHELLCAT,
				preadsession->totalbyteindexcurr);
		if (retsub > 0) {
			mutex_unlock(&pcore->mutex_core);
			CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
				puser, retsub);
		}
		SIMPLE_DEBUG_LOG;
		/*
		We have already update sizeleft and curroffset value when do copy_to_user 
		operation.
		*/
		goto shellcat_readloop;
	} else // callertype == VASTAI_LOGSYS_CALLER_C
	{
		sizeleft = i_size;
		curroffset = 0;
	c_readloop:
		/*
		Still in user and core mutex.
		When caller is c, we directly get the log content from the core, not from the 
		buffer. But we use the bufferindex to follow the current read position.
		*/
		if (sizeleft < preadsession->totalbyteindexnext -
				       preadsession->totalbyteindexcurr -
				       preadsession->bufferindex) {
			/*
			The current log is not over. So we do not need to clearbuffer when 
			clearbuffer mode.
			*/
			retsigned =
				internal_vastai_logsys_corelog_readdrvtouser_fromtotalbegin(
					pcore, io_pbuffer + curroffset,
					&outputtotalbyteindex,
					preadsession->totalbyteindexcurr +
						preadsession->bufferindex,
					sizeleft);
			if (retsigned < 0) {
				SIMPLE_KERNEL_LOG;
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					puser->penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
				mutex_unlock(&pcore->mutex_core);
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
					puser,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			}
			preadsession->bufferindex =
				preadsession->bufferindex + sizeleft;
			*io_ppos = *io_ppos + sizeleft;
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, i_size);
		}
		if (sizeleft == preadsession->totalbyteindexnext -
					preadsession->totalbyteindexcurr -
					preadsession->bufferindex) {
			/*
			First copy log to user.
			*/
			retsigned =
				internal_vastai_logsys_corelog_readdrvtouser_fromtotalbegin(
					pcore, io_pbuffer + curroffset,
					&outputtotalbyteindex,
					preadsession->totalbyteindexcurr +
						preadsession->bufferindex,
					sizeleft);
			if (retsigned < 0) {
				SIMPLE_KERNEL_LOG;
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					puser->penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
				mutex_unlock(&pcore->mutex_core);
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
					puser,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			}
			*io_ppos = *io_ppos + sizeleft;
			/*
			The current log is over, we need to check clearbuffer mode.
			Check clearbuffer mode, when is clearbuffer mode, clear the previous 
			just done buffer.
			*/
			if (bclearbuffer == 1) {
				retsub =
					internal_vastai_logsys_user_readsession_clearcurrtonext(
						preadsession, pcorenode);
				if (retsub > 0) {
					mutex_unlock(&pcore->mutex_core);
					SIMPLE_KERNEL_LOG;
					CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
						puser, retsub);
				}
			}
			/*
			Move the current point to the next.
			*/
			preadsession->totalbyteindexcurr =
				preadsession->totalbyteindexnext;
			/*
			The current log is over, we need to prepare the next log.
			*/
			if (preadsession->totalbyteindexcurr ==
			    preadsession->totalbyteindexend) {
				/*
				When the next point is the end of the current core, we should find data
				to read in the following core node.
				*/
				mutex_unlock(&pcore->mutex_core);
				retsub =
					internal_vastai_logsys_user_readsession_update_finddatatoread(
						preadsession, &breachend,
						callertype, beginoffsetdef);
				if (retsub > 0) {
					SIMPLE_KERNEL_LOG;
					CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
						puser, retsub);
				}
				if (breachend == 0) {
					pcorenode = preadsession->pcorenode;
					pcore = pcorenode->pcore;
					mutex_unlock(&pcore->mutex_core);
				}
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser,
								    i_size);
			}
			/*
			Still in mutex user and core.
			There is still some log of the current core to be read by user.
			*/
			retsub =
				internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
					preadsession, pcorenode,
					VASTAI_LOGSYS_CALLER_C,
					preadsession->totalbyteindexcurr);
			if (retsub > 0) {
				mutex_unlock(&pcore->mutex_core);
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
			/*
			Currently, there is no space to store the log.
			*/
			mutex_unlock(&pcore->mutex_core);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, i_size);
		}
		/*
		Still in user mutex. 
		Still in core mutex.
		*/
		/*
		When run here, sizeleft > preadsession->totalbyteindexnext - preadsession->totalbyteindexcurr - preadsession->bufferindex
		*/
		/*
		After we copy the current log to user, we need to prepare the next log and 
		copy the log to the left user space buffer.
		*/
		retsigned =
			internal_vastai_logsys_corelog_readdrvtouser_fromtotalbegin(
				pcore, io_pbuffer + curroffset,
				&outputtotalbyteindex,
				preadsession->totalbyteindexcurr +
					preadsession->bufferindex,
				preadsession->totalbyteindexnext -
					preadsession->totalbyteindexcurr -
					preadsession->bufferindex);
		if (retsigned < 0) {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			mutex_unlock(&pcore->mutex_core);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
				puser,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		}
		*io_ppos = *io_ppos + (preadsession->totalbyteindexnext -
				       preadsession->totalbyteindexcurr -
				       preadsession->bufferindex);
		sizeleft = sizeleft - (preadsession->totalbyteindexnext -
				       preadsession->totalbyteindexcurr -
				       preadsession->bufferindex);
		curroffset = curroffset + (preadsession->totalbyteindexnext -
					   preadsession->totalbyteindexcurr -
					   preadsession->bufferindex);
		/*
		The current log is over, we need to check clearbuffer mode.
		Check clearbuffer mode, when is clearbuffer mode, clear the previous 
		just done buffer.
		*/
		if (bclearbuffer == 1) {
			SIMPLE_DEBUG_LOG;
			retsub =
				internal_vastai_logsys_user_readsession_clearcurrtonext(
					preadsession, pcorenode);
			SIMPLE_DEBUG_LOG;
			if (retsub > 0) {
				mutex_unlock(&pcore->mutex_core);
				SIMPLE_DEBUG_LOG;
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
		}
		/*
		Move the current point to the next.
		*/
		preadsession->totalbyteindexcurr =
			preadsession->totalbyteindexnext;
		/*
		The current log is over, we need to prepare the next log.
		*/
		if (preadsession->totalbyteindexcurr ==
		    preadsession->totalbyteindexend) {
			/*
			When the next point is the end of the current core, we should find data
			to read in the following core node.
			*/
			mutex_unlock(&pcore->mutex_core);
			retsub =
				internal_vastai_logsys_user_readsession_update_finddatatoread(
					preadsession, &breachend, callertype,
					beginoffsetdef);
			if (retsub > 0) {
				SIMPLE_KERNEL_LOG;
				CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
					puser, retsub);
			}
			if (breachend == 1) {
				/*
				When reach end, we should return the current get size.
				Now is c mode, we need to reset preadsession to NULL.
				*/
				puser->readsession.pcorenode = NULL;
				ret = i_size - sizeleft;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
			pcorenode = preadsession->pcorenode;
			pcore = pcorenode->pcore;
			/*
			We have already update sizeleft and curroffset value when do copy_to_user 
			operation.
			*/
			goto c_readloop;
		}
		/*
		Still in user and core mutex.
		There is still some log to be read by user.
		*/
		retsub =
			internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
				preadsession, pcorenode, VASTAI_LOGSYS_CALLER_C,
				preadsession->totalbyteindexcurr);
		if (retsub > 0) {
			mutex_unlock(&pcore->mutex_core);
			CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE_UNLOCK(
				puser, retsub);
		}
		/*
		We have already update sizeleft and curroffset value when do copy_to_user 
		operation.
		*/
		goto c_readloop;
	}
	SIMPLE_DEBUG_LOG;
	internal_vastai_logsys_user_set_nooper_and_unlockuser(puser);
	SIMPLE_DEBUG_LOG;

	//label_ret:
	return ret;
}

/*
See write operation format in vastai_logsys.h.
*/
static ssize_t vastai_logsys_write(struct file *i_pfile,
				   const char __user *i_pbuffer, size_t i_size,
				   loff_t *io_ppos)
{
	int retmacroint = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;
	u32 oper_enum = 0;
	ssize_t ret = i_size;
	ssize_t retfunc = 0;
	struct vastai_logsys_write_oper write_oper = NULL;
	u32 parseret = 0;
	u32 logaddcheck = 0;
	char operstr[256] = { 0 };
	u32 diei = 0;
	u32 diecount = 0;
	u32 coreiV = 0;
	u32 loglevel = 0;
	u32 logenable = 0;
	u32 path = 0;
	u32 callertype = 0;

#if (DEBUG_LOG == 1)
	pr_info("vastai logsys write begin\n");
#endif

	SIMPLE_DEBUG_LOG;
	/*
	Only when doing write operation can we ignore the recoverable error.
	Otherwise, should use CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL to check.
	*/
	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_IGNORE_RECOVERABLE_ERROR(penv,
								       puser);
	SIMPLE_DEBUG_LOG;

	/*
	First, parse the write instruction string to structure.
	*/
	if (i_size >= 256) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_TOO_LONG;
	}
	copy_from_user(operstr, i_pbuffer, i_size);
	parseret = internal_parse_write_oper(&write_oper, operstr);
	if (parseret != 0) {
		retfunc = 0 - parseret;
		return retfunc;
	}
	oper_enum = write_oper.oper_enum;

	/*
	When the current status is VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE, 
	we need to know whether it is the first receive operation, when it is not the 
	first handle operation, we can handle info and log write operation. 
	*/
	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO ||
	    oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG) {
		CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SETINFOORLOG_AND_LOCK(
			puser, VASTAI_LOGSYS_DRVINNER_OPER_WRITE);
	} else {
		CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
			puser, VASTAI_LOGSYS_DRVINNER_OPER_WRITE);
	}

	/*
	When the previous mode is log, the new mode is log or info not log add, then 
	release the current instance.
	*/

	callertype = puser->callertype;

	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_INFO) {
		/*
		When enter the function, already enter lock.
		You should remain lock when function return.
		*/
		mutex_unlock(&puser->mutex_user);
		SIMPLE_DEBUG_LOG;
		/*
		Whatever the return value is 0 or not, the function will quit mutex 
		when return. The following function will unbind env default bind info when 
		caller is shell.
		*/
		retfunc =
			internal_vastai_logsys_unbind_allcore_oftheuser_byuserthread(
				puser, 1);
		SIMPLE_DEBUG_LOG;
		CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE(puser,
								       retfunc);
		CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
		/*
		Set the new mode info.
		*/
		internal_vastai_logsys_user_bindinfo_init_by_write_oper(
			&puser->bindinfo, &write_oper);
		/*
		When the current caller is shell, we need to change the default settings.
		*/
		if (callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
			/*
			No error will occur when do the copy operation.
			*/
			mutex_lock(&puser->penv->mutex_bindinfodef);
			internal_vastai_logsys_user_bindinfo_init_by_write_oper(
				&puser->penv->bindinfodef, &write_oper);
			mutex_unlock(&puser->penv->mutex_bindinfodef);
		}
		puser->infobuffertotalsize = 0;
		puser->infobuffercurrindex = 0;
		SIMPLE_DEBUG_LOG;
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
	}
	/*
	Now is still in puser mutex.
	*/
	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG) {
		mutex_unlock(&puser->mutex_user);
		SIMPLE_DEBUG_LOG;
		retfunc =
			internal_vastai_logsys_unbind_allcore_oftheuser_byuserthread(
				puser, 1);
		SIMPLE_DEBUG_LOG;
		CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE(puser,
								       retfunc);
		/*
		When the caller is shellcat, we not only save the bind info to the current user's 
		bind info, we also save the bind info to the default bind info 
		and do not bind log info.
		*/
		if (callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
			mutex_lock(&puser->penv->mutex_bindinfodef);
			internal_vastai_logsys_user_bindinfo_init_by_write_oper(
				&puser->penv->bindinfodef, &write_oper);
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&puser->penv->mutex_bindinfodef);
			CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
			internal_vastai_logsys_user_bindinfo_init_by_write_oper(
				&puser->bindinfo, &write_oper);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
		}
		/*
		When the caller is c, we try bind the new log, when no error, 
		save the bind info.
		*/
		/*
		Try bind the new log.
		*/
		retfunc = internal_vastai_logsys_bind_log_byuserthread(
			puser, &write_oper.change_mode_log);
		SIMPLE_DEBUG_LOG;
		if (retfunc != 0) {
			/*
			When not succeed, it will back to info mode.
			*/
			CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);

			internal_vastai_logsys_user_bindinfo_resettoinfo_whenerror(
				&puser->bindinfo);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, retfunc);
		}
		/*
		In the end, we record the log mode and set the bind info.
		*/
		CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
		internal_vastai_logsys_user_bindinfo_init_by_write_oper(
			&puser->bindinfo, &write_oper);
		internal_vastai_logsys_user_readsession_reset_tonull(
			&puser->readsession);
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
	}
	/*
	Now is still in puser mutex.
	*/
	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_MODE_LOG_ADD) {
		/*
		When current mode is not log, we can not do the operation.
		*/
		if (puser->bindinfo.mode != VASTAI_LOGSYS_MODE_LOG) {
			mutex_unlock(&puser->mutex_user);
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_CURRENTISNOTLOG;
			SIMPLE_KERNEL_LOG;
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		/*
		When the caller is shellcat, we not only save the added bind info to the current user's 
		bind info, we also save the added bind info to the default bind info and do not bind log 
		info.
		Here still in user mutex.
		*/
		if (callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
			logaddcheck =
				internal_vastai_logsys_user_bindinfo_logadd_check(
					puser, &write_oper);
			SIMPLE_DEBUG_LOG;
			if (logaddcheck > 0) {
				ret = logaddcheck;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser,
								    -ret);
			}
			/*
			After check, add the log entry.
			*/
			mutex_unlock(&puser->mutex_user);
			mutex_lock(&puser->penv->mutex_bindinfodef);
			internal_vastai_logsys_user_bindinfo_init_by_write_oper(
				&puser->penv->bindinfodef, &write_oper);
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&puser->penv->mutex_bindinfodef);
			CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
			internal_vastai_logsys_user_bindinfo_init_by_write_oper(
				&puser->bindinfo, &write_oper);
			RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
		}
		/*
		When the current mode is log, the pcore_head should not be NULL, the 
		log entry should not be NULL.
		*/
		if (puser->bindinfo.puser_mode_log_head == NULL) {
			mutex_unlock(&puser->mutex_user);
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			return -ret;
		}
		if (puser->pcore_head == NULL) {
			mutex_unlock(&puser->mutex_user);
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			return -ret;
		}
		mutex_unlock(&puser->mutex_user);
		retfunc = internal_vastai_logsys_bind_logadd_byuserthread(
			puser, &write_oper.change_mode_log_add);
		CHECKRET_VASTAI_LOGSYS_SET_NOOPER_EXCEPT_NORECOVERABLE(puser,
								       retfunc);
		/*
		After successfully bind log add, we add the bind info.
		*/
		CHECKRET_VASTAI_LOGSYS_USER_LOCK(puser);
		//internal_vastai_logsys_user_bindinfo_init_by_write_oper(&puser->bindinfo, &write_oper);
		internal_vastai_logsys_user_readsession_reset_tonull(
			&puser->readsession);
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
	}
	/*
	Now is still in puser mutex.
	*/
	if (oper_enum ==
	    VASTAI_LOGSYS_OPER_CHANGE_OUTPUTLOG_PERCORE_BEGIN_OFFSET) {
		internal_vastai_logsys_user_readsession_reset_tonull(
			&puser->readsession);
		if (puser->callertype == VASTAI_LOGSYS_CALLER_C) {
			/*
			When the mode is C, we change the current per core begin offset.
			*/
			if (puser->bindinfo.mode == VASTAI_LOGSYS_MODE_INFO) {
				pr_err("You can not set user output log begin offset when info mode!\n");
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_INFO;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			} else // VASTAI_LOGSYS_MODE_LOG
			{
				if (puser->bindinfo.puser_mode_log_head ==
				    NULL) {
					VASTAI_LOGSYS_ENV_ERROR_RECORD(
						penv,
						VASTAI_LOGSYS_ENV_ERROR_BINDINFO_PUSER_ISNULL_WHENLOGMODE);
					ret = -VASTAI_LOGSYS_ENV_ERROR_BINDINFO_PUSER_ISNULL_WHENLOGMODE;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				if (penv->bindinfodef.puser_mode_log_head
					    ->bclearbuffer == 1) {
					pr_err("You can not set output log begin offset when clear buffer mode!\n");
					ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_CLEARBUFFER;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				if (penv->bindinfodef.puser_mode_log_head
					    ->bblock == 1) {
					pr_err("You can not set default output log begin offset when block mode!\n");
					ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_USEROFFSET_WHEN_BLOCK;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				puser->beginoffsetdef =
					write_oper
						.change_outputlog_percore_begin_offset;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
		} else {
			/*
			When the mode is shell, we change the default per core begin offset.
			When clear buffer or block mode, the operation is illegal.
			*/
			if (penv->bindinfodef.mode == VASTAI_LOGSYS_MODE_INFO) {
				pr_err("You can not set default output log begin offset when info mode!\n");
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_INFO;
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			} else // VASTAI_LOGSYS_MODE_LOG
			{
				if (penv->bindinfodef.puser_mode_log_head ==
				    NULL) {
					VASTAI_LOGSYS_ENV_ERROR_RECORD(
						penv,
						VASTAI_LOGSYS_ENV_ERROR_BINDINFODEF_PUSER_ISNULL_WHENLOGMODE);
					ret = -VASTAI_LOGSYS_ENV_ERROR_BINDINFODEF_PUSER_ISNULL_WHENLOGMODE;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				if (penv->bindinfodef.puser_mode_log_head
					    ->bclearbuffer == 1) {
					pr_err("You can not set default output log begin offset when clear buffer mode!\n");
					ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_CLEARBUFFER;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				if (penv->bindinfodef.puser_mode_log_head
					    ->bblock == 1) {
					pr_err("You can not set default output log begin offset when block mode!\n");
					ret = -VASTAI_LOGSYS_USER_ERROR_LOG_SET_DEFAULTOFFSET_WHEN_BLOCK;
					RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(
						puser, ret);
				}
				mutex_lock(&penv->mutex_bindinfodef);
				penv->beginoffsetdef =
					write_oper
						.change_outputlog_percore_begin_offset;
				mutex_unlock(&penv->mutex_bindinfodef);
				RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
			}
		}
		mutex_unlock(&puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	/*
	Now is still in puser mutex.
	*/
	if (oper_enum == VASTAI_LOGSYS_OPER_CLEAR_BUFFER) {
		mutex_unlock(&puser->mutex_user);
		internal_vastai_logsys_user_readsession_reset_tonull(
			&puser->readsession);
		if (write_oper.clear_buffer.pci_dev_id == -1) {
			/*
			Not in user mutex.
			*/
			/*
			To avoid pci pointer not exist when do clear buffer operation, 
			add pci mutex from the begin to the end to do the operation.
			*/
			mutex_lock(&penv->mutex_pci_list);
			ppci = penv->ppci_head;
			while (ppci) {
				internal_vastai_logsys_corelog_clearbuffer_ofpci(
					ppci);
				ppci = ppci->pnext;
			}
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		} else {
			/*
			Not in user mutex.
			*/
			mutex_lock(&penv->mutex_pci_list);
			ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
				penv, write_oper.clear_buffer.pci_dev_id);
			if (ppci == NULL) {
				mutex_unlock(&penv->mutex_pci_list);
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND;
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			if (write_oper.clear_buffer.die_index == -1) {
				internal_vastai_logsys_corelog_clearbuffer_ofpci(
					ppci);
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			/*
			Have die index. Need check die index within 0-diecount.
			*/
			diecount = ppci->die_count;
			diei = write_oper.clear_buffer.die_index;
			if (diei >= diecount) {
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG;
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			pdie = &ppci->parray_die_env[diei];
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				if (write_oper.clear_buffer
					    .parray_bcore[corei] == 1) {
					pcore = &pdie->parray_core_env[corei];
					mutex_lock(&pcore->mutex_core);
					internal_vastai_logsys_corelog_clearbuffer(
						pcore);
					mutex_unlock(&pcore->mutex_core);
				}
			}
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	/*
	Now is still in puser mutex.
	*/
	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_LEVEL) {
		mutex_unlock(&puser->mutex_user);
		loglevel = write_oper.change_level.loglevel;
		logenable = write_oper.change_level.logenable;
		if (loglevel > VASTAI_LOGSYS_LEVEL_MAX ||
		    loglevel < VASTAI_LOGSYS_LEVEL_MIN) {
			ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGLEVEL_OUTOFRANGE;
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		if (logenable > 1) {
			ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGENABLE_VALUEWRONG;
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}

		if (write_oper.change_level.commdscr.pci_dev_id == -1) {
			/*
			To avoid pci pointer not exist when do change level operation, 
			add pci mutex from the begin to the end to do the operation.
			Every operation do one pci change level.
			*/
			mutex_lock(&penv->mutex_pci_list);
			ppci = penv->ppci_head;
			while (ppci) {
				internal_vastai_logsys_corelog_changelevel_ofpci(
					ppci, loglevel, logenable);
				ppci = ppci->pnext;
			}
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		} else {
			mutex_lock(&penv->mutex_pci_list);
			ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
				penv,
				write_oper.change_level.commdscr.pci_dev_id);
			if (ppci == NULL) {
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND;
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			if (write_oper.change_level.commdscr.die_index == -1) {
				internal_vastai_logsys_corelog_changelevel_ofpci(
					ppci, loglevel, logenable);
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			/*
			Have die index. Need check die index within 0-diecount.
			*/
			diecount = ppci->die_count;
			diei = write_oper.change_level.commdscr.die_index;
			if (diei >= diecount) {
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG;
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			pdie = &ppci->parray_die_env[diei];
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				if (write_oper.change_level.commdscr
					    .parray_bcore[corei] == 1) {
					pcore = &pdie->parray_core_env[corei];
					mutex_lock(&pcore->mutex_core);
					internal_vastai_logsys_corelog_changelevel(
						pcore, loglevel, logenable);
					mutex_unlock(&pcore->mutex_core);
				}
			}
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (oper_enum == VASTAI_LOGSYS_OPER_CHANGE_PATH) {
		mutex_unlock(&puser->mutex_user);
		path = write_oper.change_path.path;
		if (path != VASTAI_LOGSYS_PATH_UART &&
		    path != VASTAI_LOGSYS_PATH_PCIE) {
			ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PATH_VALUEWRONG;
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		if (write_oper.change_path.commdscr.pci_dev_id == -1) {
			mutex_lock(&penv->mutex_pci_list);
			ppci = penv->ppci_head;
			while (ppci) {
				internal_vastai_logsys_corelog_changepath_ofpci(
					ppci, path);
				ppci = ppci->pnext;
			}
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		} else {
			mutex_lock(&penv->mutex_pci_list);
			ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
				penv,
				write_oper.change_path.commdscr.pci_dev_id);
			if (ppci == NULL) {
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND;
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			if (write_oper.change_path.commdscr.die_index == -1) {
				internal_vastai_logsys_corelog_changepath_ofpci(
					ppci, path);
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			/*
			Have die index. Need check die index within 0-diecount.
			*/
			diecount = ppci->die_count;
			diei = write_oper.change_path.commdscr.die_index;
			if (diei >= diecount) {
				ret = -VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG;
				mutex_unlock(&penv->mutex_pci_list);
				RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
			}
			pdie = &ppci->parray_die_env[diei];
			internal_vastai_logsys_corelog_changepath_ofdie(pdie,
									path);
			mutex_unlock(&penv->mutex_pci_list);
			RET_VASTAI_LOGSYS_SET_NOOPER(puser, ret);
		}
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return -VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}

	/*
	When still in user mutex and need to quit, you can goto the label to do the 
	operation. The operation will set the operation to none and unlock.
	*/
	//ret_label:
	internal_vastai_logsys_user_set_nooper_and_unlockuser(puser);

	return ret;
}

/*
When i_cmd is VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_SHELLCAT: the caller is shell cat
When i_cmd is VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_C: the caller is C program.
See the details in VASTAI_LOGSYS_*** description.
*/
static long vastai_logsys_ioctl(struct file *i_pfile, unsigned int i_cmd,
				unsigned long i_arg)
{
	int retmacroint = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_IOCTL);

	if (i_cmd == VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_SHELLCAT) {
		puser->callertype = VASTAI_LOGSYS_CALLER_SHELLCAT;
	} else if (i_cmd == VASTAI_LOGSYS_IOCTL_CHANGE_CALLER_C) {
		puser->callertype = VASTAI_LOGSYS_CALLER_C;
	}

	RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
}

static int vastai_logsys_fasync(int i_fd, struct file *i_pfile, int i_mode)
{
	int retmacroint = 0;
	int ret = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_FASYNC);

	ret = fasync_helper(i_fd, i_pfile, i_mode, &puser->fasync);

	RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, ret);
}

/*
When the current log user quit, call this function.
Unlike deinit function, the function will only release the resource of the 
current user.
*/
static int vastai_logsys_release(struct inode *i_inode, struct file *i_pfile)
{
	int retmacroint = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;
	//struct vastai_logsys_user_mode_log *plog, plogdel;
	//struct vastai_logsys_pci_env *ppci;
	//struct vastai_logsys_pci_die_env *pdie;
	//struct vastai_logsys_pci_die_core_env *pcore;
	//u32 diei;
	//u32 corei;
	//u32 puseri;
	ssize_t retfunc = 0;

#if (DEBUG_LOG == 1)
	pr_info("vastai logsys release begin\n");
#endif

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_RELEASE);

	/*
	Release the fasync resource. To be checked.
	*/
	//vastai_logsys_fasync(-1, i_pfile, 0);

	/*
	Still in user mutex.
	When log mode, need to clear extra resource.
	When info mode, do not need to clear the following log resource.
	*/
	if (puser->bindinfo.mode == VASTAI_LOGSYS_MODE_LOG) {
		mutex_unlock(&puser->mutex_user);
		retfunc =
			internal_vastai_logsys_unbind_allcore_oftheuser_byuserthread(
				puser, 0);
		/*
		Here, the retfunc will only be pci removed triggered, so it is ok. 
		We continue do the release operation.
		Here, we are not in user mutex.
		*/
		if (retfunc > 0) {
			/*
			When it is removed triggered, when the function return, we do not need to 
			worry about other thread may use the resource of the user, we just enter mutex 
			without use macro.
			*/
			mutex_lock(&puser->mutex_user);
			/*
			Ensure delete the user bindinfo.
			*/
			internal_vastai_logsys_user_bindinfo_deinit(
				&puser->bindinfo);
			mutex_unlock(&puser->mutex_user);
		} else {
			/*
			Successfully do the bindinfo release and the user unbind to core.
			Now is not in mutex.
			*/
		}
	} else {
		mutex_unlock(&puser->mutex_user);
	}

	/*
	Not in user mutex.
	Delete the current user instance from the puser linked list.
	*/

	mutex_lock(&penv->mutex_user_list);
	if (puser->ppre != NULL) {
		puser->ppre->pnext = puser->pnext;
	} else {
		puser->penv->puser_head = puser->pnext;
	}
	if (puser->pnext != NULL) {
		puser->pnext->ppre = puser->ppre;
	} else {
		puser->penv->puser_tail = puser->ppre;
	}
	mutex_unlock(&penv->mutex_user_list);
	/*
	Release the user inner resource.
	*/
	mutex_lock(&puser->mutex_user);
	// now do not need release any inner resoure here.
	mutex_unlock(&puser->mutex_user);
	mutex_destroy(&puser->mutex_user);
	kfree(puser);

#if (DEBUG_LOG == 1)
	pr_info("vastai logsys release end\n");
#endif
	return 0;
}

static loff_t vastai_logsys_llseek(struct file *i_pfile, loff_t i_offset,
				   int i_orig)
{
	int retmacroint = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_LLSEEK);

	if (i_offset == 0) {
		i_pfile->f_pos = 0;
		RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
	}
	pr_err("When llseek offset is not 0, the function will do nothing.\n");

	RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, i_orig);
}

static unsigned int vastai_logsys_poll(struct file *i_pfile,
				       struct poll_table_struct *i_pwait)
{
	int retmacroint = 0;
	struct vastai_logsys_env *penv = _penv;
	struct vastai_logsys_user *puser =
		(struct vastai_logsys_user *)i_pfile->private_data;

	CHECKRET_VASTAI_LOGSYS_ENV_USER_CHECK_ALL(penv, puser);
	CHECKRET_VASTAI_LOGSYS_DRVINNER_OPER_SET_AND_LOCK(
		puser, VASTAI_LOGSYS_DRVINNER_OPER_POLL);

	pr_err("You do not need to run poll\n");

	RET_VASTAI_LOGSYS_SET_NOOPER_UNLOCK(puser, 0);
}

void internal_vastai_gettimeofday(struct rtc_time *io_ptm)
{
#if (PC_ENV == 0)
#if 1 // higher kernel version
	struct timespec64 ts;
	ktime_get_real_ts64(&ts);
	ts.tv_sec += 8 * 60 * 60;
	//ts.tv_sec += sys_tz.tz_minuteswest * 60;
	//ts.tv_sec -= sys_tz.tz_minuteswest * 60;
	rtc_time_to_tm(ts.tv_sec, io_ptm);
#else
	struct timeval tv;
	do_gettimeofday(&tv);
	tv.tv_sec -= sys_tz.tz_minuteswest * 60;
	rtc_time_to_tm(tv.tv_sec, io_ptm);
#endif
#endif
}

int internal_vastai_logsys_createdir(char *i_dir)
{
	int ret = -1;
	char path[] = "/bin/mkdir";
	char *argv[] = { path, "-p", i_dir, NULL };
	char *envp[] = { NULL };
	ret = call_usermodehelper(path, argv, envp, UMH_WAIT_PROC);
	return ret;
}

#if 1
int internal_vastai_logsys_touch(char *i_path)
{
	int ret = -1;
	char path[] = "/bin/touch";
	char *argv[] = { path, "-f", i_path, NULL };
	char *envp[] = { NULL };
	ret = call_usermodehelper(path, argv, envp, UMH_WAIT_PROC);
	return ret;
}
#endif

int internal_vastai_logsys_rmdir(char *i_dir)
{
	int ret = -1;
	char path[] = "/bin/rm";
	char *argv[] = { path, "-rf", i_dir, NULL };
	char *envp[] = { NULL };
	ret = call_usermodehelper(path, argv, envp, UMH_WAIT_PROC);
	return ret;
}

int internal_vastai_logsys_rmandcreatedir(char *i_dir)
{
	int ret = -1;
	internal_vastai_logsys_createdir(i_dir);
	internal_vastai_logsys_rmdir(i_dir);
	internal_vastai_logsys_createdir(i_dir);
	return ret;
}

int internal_vastai_logsys_mvdir(char *i_olddir, char *i_newdir)
{
	int ret = -1;
	char path[] = "/bin/mv";
	char *argv[] = { path, i_olddir, i_newdir, NULL };
	char *envp[] = { NULL };
	ret = call_usermodehelper(path, argv, envp, UMH_WAIT_PROC);
	return ret;
}

static u32 _bhasfileopenerr = 0;

void internal_vastai_logsys_filelist_init(
	struct vastai_logsys_filelist *io_pfilelist)
{
	int err;
	//mm_segment_t old_fs;
	struct file *pfilenew = NULL;
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN] = 0;
	struct vastai_logsys_file *pfilenodenew = NULL;
	sprintf(filepathbase,
		"%s" VASTAI_LOGSYS_FILE_SPLIT "%u" VASTAI_LOGSYS_FILE_SUFFIX,
		io_pfilelist->filepathbase, io_pfilelist->fileindex);
	io_pfilelist->fileindex++;
	//internal_vastai_logsys_touch(filepathbase);
	pfilenew = filp_open(filepathbase, O_RDWR | O_CREAT, 0644);
	if (IS_ERR(pfilenew)) {
		err = PTR_ERR(pfilenew);
		if (_bhasfileopenerr == 0) {
			pr_err(VASTAI_LOGSYS_PR_HEAD "filepath = %s\n",
			       filepathbase);
			pr_err(VASTAI_LOGSYS_PR_HEAD "ptr_err = %d\n", err);
			_bhasfileopenerr = 1;
		}
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILEOPEN_FAIL);
		return;
	}
	pfilenodenew = kzalloc(sizeof(struct vastai_logsys_file), GFP_KERNEL);
	pfilenodenew->plist = io_pfilelist;
	pfilenodenew->pfile = pfilenew;
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
	filp_close(pfilenew, NULL);
#endif
	pfilenodenew->wpbyte = 0;
	pfilenodenew->ppre = pfilenodenew->pnext = NULL;
	io_pfilelist->phead = io_pfilelist->ptail = pfilenodenew;
	io_pfilelist->pfilebegin = pfilenodenew;
	io_pfilelist->filebeginrpbyte = 0;
}

void internal_vastai_logsys_filelist_add(
	struct vastai_logsys_filelist *io_pfilelist,
	unsigned char *i_parraydata, u32 i_arraynum, u32 i_bcannewfile)
{
	int err;
	mm_segment_t old_fs = 0;
	struct file *pfilenew = NULL;
	loff_t pos = 0;
	struct vastai_logsys_file *pfilenodenew = NULL;
	char filepathbase[VASTAI_LOGSYS_FILE_DIR_MAXLEN];
	if (i_arraynum == 0) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENADD);
		return;
	}
	if (i_arraynum >= VASTAI_LOGSYS_BUF_SIZE) {
		/*
		Unexpected value.
		*/
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ADD_TOOMUCH);
		return;
	}
	if (io_pfilelist->phead == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET);
		return;
	}
	if (i_bcannewfile == 1) {
		if (io_pfilelist->ptail->wpbyte + i_arraynum >=
		    VASTAI_LOGSYS_FILE_MAXSIZE) {
			//pfilenew = filp_open(io_pfilelist->filepathbase, O_RDWR | O_CREAT, 0644);
			sprintf(filepathbase,
				"%s" VASTAI_LOGSYS_FILE_SPLIT
				"%u" VASTAI_LOGSYS_FILE_SUFFIX,
				io_pfilelist->filepathbase,
				io_pfilelist->fileindex);
			io_pfilelist->fileindex++;
			pfilenew =
				filp_open(filepathbase, O_RDWR | O_CREAT, 0644);
			if (IS_ERR(pfilenew)) {
				err = PTR_ERR(pfilenew);
				//pr_err(VASTAI_LOGSYS_PR_HEAD "filepath = %s\n", filepathbase);
				if (_bhasfileopenerr == 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "ptr_err = %d\n",
					       err);
					_bhasfileopenerr = 1;
				}
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					_penv,
					VASTAI_LOGSYS_ENV_ERROR_FILEOPEN_FAIL);
				return;
			}
			pfilenodenew = kzalloc(
				sizeof(struct vastai_logsys_file), GFP_KERNEL);
			pfilenodenew->plist = io_pfilelist;
			pfilenodenew->pfile = pfilenew;
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
			pfilenodenew->fileindex =
				io_pfilelist->fileindex -
				1; // because already fileindex++, so -1 here
#endif
			pfilenodenew->wpbyte = 0;
			old_fs = get_fs();
			set_fs(KERNEL_DS);
			pos = 0;
			vfs_write(pfilenew, (char *)i_parraydata, i_arraynum,
				  &pos);
			pfilenodenew->wpbyte = i_arraynum;
			set_fs(old_fs);
			pfilenodenew->ppre = io_pfilelist->ptail;
			pfilenodenew->pnext = NULL;
			io_pfilelist->ptail->pnext = pfilenodenew;
			io_pfilelist->ptail = pfilenodenew;
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
			filp_close(pfilenew, NULL);
#endif
			return;
		}
	}
	old_fs = get_fs();
	set_fs(KERNEL_DS);
	pos = io_pfilelist->ptail->wpbyte;
	//pr_err(VASTAI_LOGSYS_PR_HEAD "pos = %d\n", io_pfilelist->ptail->wpbyte);
	//pr_err(VASTAI_LOGSYS_PR_HEAD "i_parraydata = %x, i_arraynum = %d\n", i_parraydata, i_arraynum);
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
	sprintf(filepathbase,
		"%s" VASTAI_LOGSYS_FILE_SPLIT "%u" VASTAI_LOGSYS_FILE_SUFFIX,
		io_pfilelist->filepathbase, io_pfilelist->ptail->fileindex);
	io_pfilelist->ptail->pfile = filp_open(filepathbase, O_RDWR, 0644);
#endif
	vfs_write(io_pfilelist->ptail->pfile, (char *)i_parraydata, i_arraynum,
		  &pos);
	io_pfilelist->ptail->wpbyte += i_arraynum;
	set_fs(old_fs);
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 1)
	filp_close(io_pfilelist->ptail->pfile, NULL);
#endif
}

ssize_t internal_vastai_logsys_filelist_getfrombeginwithclear_inner(
	struct vastai_logsys_filelist *io_pfilelist,
	unsigned char *io_parraydata, u32 i_arraynum)
{
	mm_segment_t old_fs = 0;
	loff_t pos = 0;
	struct vastai_logsys_file *pfile = io_pfilelist->pfilebegin;
	ssize_t ret = 0;
	size_t readsize = 0;
	size_t readsizetotal = 0;
	size_t readsizeleft = 0;
	unsigned char *preadbyte = NULL;
	struct vastai_logsys_file *pfiledel = NULL;
	if (io_pfilelist->phead == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET);
		return -1;
	}
	if (io_pfilelist->phead == io_pfilelist->ptail) {
		if (io_pfilelist->phead->wpbyte ==
		    io_pfilelist->filebeginrpbyte) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILELIST_ISEMPTY_WHENGET);
			return -1;
		}
	}
	if (i_arraynum == 0)
		return 0;
	if (io_pfilelist->pfilebegin->wpbyte == io_pfilelist->filebeginrpbyte) {
		if (io_pfilelist->pfilebegin->pnext == NULL) {
			goto notenough;
		}
		io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
		io_pfilelist->filebeginrpbyte = 0;
		if (io_pfilelist->pfilebegin->wpbyte == 0) {
			goto notenough;
		}
	}
	if (i_arraynum <
	    io_pfilelist->pfilebegin->wpbyte - io_pfilelist->filebeginrpbyte) {
		pos = io_pfilelist->filebeginrpbyte;
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		vfs_read(io_pfilelist->pfilebegin->pfile, io_parraydata,
			 i_arraynum, &pos);
		set_fs(old_fs);
		readsizetotal = i_arraynum;
		io_pfilelist->filebeginrpbyte =
			io_pfilelist->filebeginrpbyte + i_arraynum;
		goto clearoperation;
	} else if (i_arraynum == io_pfilelist->pfilebegin->wpbyte -
					 io_pfilelist->filebeginrpbyte) {
		pos = io_pfilelist->filebeginrpbyte;
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		vfs_read(io_pfilelist->pfilebegin->pfile, io_parraydata,
			 i_arraynum, &pos);
		set_fs(old_fs);
		if (io_pfilelist->pfilebegin->pnext != NULL) {
			io_pfilelist->pfilebegin =
				io_pfilelist->pfilebegin->pnext;
			io_pfilelist->filebeginrpbyte = 0;
		} else {
			io_pfilelist->filebeginrpbyte =
				io_pfilelist->pfilebegin->wpbyte;
		}
		readsizetotal = i_arraynum;
		goto clearoperation;
	}
	if (io_pfilelist->pfilebegin->pnext == NULL) {
		pos = io_pfilelist->filebeginrpbyte;
		readsize = io_pfilelist->pfilebegin->wpbyte -
			   io_pfilelist->filebeginrpbyte;
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		vfs_read(io_pfilelist->pfilebegin->pfile, io_parraydata,
			 readsize, &pos);
		set_fs(old_fs);
		io_pfilelist->filebeginrpbyte =
			io_pfilelist->pfilebegin->wpbyte;
		readsizetotal = readsize;
		goto notenough;
	}
	pos = io_pfilelist->filebeginrpbyte;
	readsize = io_pfilelist->pfilebegin->wpbyte -
		   io_pfilelist->filebeginrpbyte;
	old_fs = get_fs();
	set_fs(KERNEL_DS);
	vfs_read(io_pfilelist->pfilebegin->pfile, io_parraydata, readsize,
		 &pos);
	set_fs(old_fs);
	readsizetotal = readsize;
	readsizeleft = i_arraynum - readsize;
	io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
	preadbyte = io_parraydata + readsize;
	while (readsizeleft) {
		if (readsizeleft < io_pfilelist->pfilebegin->wpbyte) {
			old_fs = get_fs();
			set_fs(KERNEL_DS);
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
			vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte,
				 readsize, &pos);
			set_fs(old_fs);
			preadbyte = preadbyte + readsize;
			readsizetotal = readsizetotal + readsize;
			io_pfilelist->filebeginrpbyte = readsize;
			goto clearoperation;
		}
		if (readsizeleft == io_pfilelist->pfilebegin->wpbyte) {
			old_fs = get_fs();
			set_fs(KERNEL_DS);
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
			vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte,
				 readsize, &pos);
			set_fs(old_fs);
			preadbyte = preadbyte + readsize;
			readsizetotal = readsizetotal + readsize;
			if (io_pfilelist->pfilebegin->pnext == NULL) {
				io_pfilelist->filebeginrpbyte = readsize;
			} else {
				io_pfilelist->pfilebegin =
					io_pfilelist->pfilebegin->pnext;
				io_pfilelist->filebeginrpbyte = 0;
			}
			goto clearoperation;
		}
		if (io_pfilelist->pfilebegin->wpbyte == 0) {
			/*
			When goto next step, set the current begin byte.
			*/
			io_pfilelist->filebeginrpbyte = 0;
			goto notenough;
		}
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		pos = 0;
		readsize = io_pfilelist->pfilebegin->wpbyte;
		readsizeleft = readsizeleft - readsize;
		vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte, readsize,
			 &pos);
		set_fs(old_fs);
		preadbyte = preadbyte + readsize;
		readsizetotal = readsizetotal + readsize;
		if (io_pfilelist->pfilebegin->pnext == NULL) {
			io_pfilelist->filebeginrpbyte =
				io_pfilelist->pfilebegin->wpbyte;
			ret = readsizetotal;
			goto notenough;
		}
		io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
	}

notenough:
	/*
	Currently, only tag use.
	*/

/*
Clear the un-used file node.
*/
clearoperation:
	/*
	Do not delete all of the list when need to delete all.
	*/
	pfile = io_pfilelist->phead;
	while (pfile != io_pfilelist->pfilebegin) {
		pfiledel = pfile;
		pfile = pfile->pnext;
		filp_close(pfiledel->pfile, NULL);
		kfree(pfiledel);
	}
	io_pfilelist->phead = io_pfilelist->pfilebegin;
	io_pfilelist->pfilebegin->ppre = NULL;
	ret = readsizetotal;
	return ret;
}

ssize_t internal_vastai_logsys_filelist_getfrombeginwithclear_user(
	struct vastai_logsys_filelist *io_pfilelist,
	char __user *io_parraydata_user, u32 i_arraynum)
{
	//mm_segment_t old_fs;
	loff_t pos = 0;
	struct vastai_logsys_file *pfile = io_pfilelist->pfilebegin;
	ssize_t ret = 0;
	size_t readsize = 0;
	size_t readsizetotal = 0;
	size_t readsizeleft = 0;
	char __user *preadbyte_user = io_parraydata_user;
	struct vastai_logsys_file *pfiledel = NULL;
	if (io_pfilelist->phead == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET);
		return -1;
	}
	if (io_pfilelist->phead == io_pfilelist->ptail) {
		if (io_pfilelist->phead->wpbyte ==
		    io_pfilelist->filebeginrpbyte) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILELIST_ISEMPTY_WHENGET);
			return -1;
		}
	}
	if (i_arraynum == 0)
		return 0;
	if (io_pfilelist->pfilebegin->wpbyte == io_pfilelist->filebeginrpbyte) {
		if (io_pfilelist->pfilebegin->pnext == NULL) {
			goto notenough;
		}
		io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
		io_pfilelist->filebeginrpbyte = 0;
		if (io_pfilelist->pfilebegin->wpbyte == 0) {
			goto notenough;
		}
	}
	if (i_arraynum <
	    io_pfilelist->pfilebegin->wpbyte - io_pfilelist->filebeginrpbyte) {
		pos = io_pfilelist->filebeginrpbyte;
		vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte_user,
			 i_arraynum, &pos);
		readsizetotal = i_arraynum;
		io_pfilelist->filebeginrpbyte =
			io_pfilelist->filebeginrpbyte + i_arraynum;
		goto clearoperation;
	} else if (i_arraynum == io_pfilelist->pfilebegin->wpbyte -
					 io_pfilelist->filebeginrpbyte) {
		pos = io_pfilelist->filebeginrpbyte;
		vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte_user,
			 i_arraynum, &pos);
		if (io_pfilelist->pfilebegin->pnext != NULL) {
			io_pfilelist->pfilebegin =
				io_pfilelist->pfilebegin->pnext;
			io_pfilelist->filebeginrpbyte = 0;
		} else {
			io_pfilelist->filebeginrpbyte =
				io_pfilelist->pfilebegin->wpbyte;
		}
		readsizetotal = i_arraynum;
		goto clearoperation;
	}
	if (io_pfilelist->pfilebegin->pnext == NULL) {
		pos = io_pfilelist->filebeginrpbyte;
		readsize = io_pfilelist->pfilebegin->wpbyte -
			   io_pfilelist->filebeginrpbyte;
		vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte_user,
			 readsize, &pos);
		io_pfilelist->filebeginrpbyte =
			io_pfilelist->pfilebegin->wpbyte;
		readsizetotal = readsize;
		goto notenough;
	}
	pos = io_pfilelist->filebeginrpbyte;
	readsize = io_pfilelist->pfilebegin->wpbyte -
		   io_pfilelist->filebeginrpbyte;
	vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte_user, readsize,
		 &pos);
	readsizetotal = readsize;
	readsizeleft = i_arraynum - readsize;
	io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
	preadbyte_user = preadbyte_user + readsize;
	while (readsizeleft) {
		if (readsizeleft < io_pfilelist->pfilebegin->wpbyte) {
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
			vfs_read(io_pfilelist->pfilebegin->pfile,
				 preadbyte_user, readsize, &pos);
			preadbyte_user = preadbyte_user + readsize;
			readsizetotal = readsizetotal + readsize;
			io_pfilelist->filebeginrpbyte = readsize;
			goto clearoperation;
		}
		if (readsizeleft == io_pfilelist->pfilebegin->wpbyte) {
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
			vfs_read(io_pfilelist->pfilebegin->pfile,
				 preadbyte_user, readsize, &pos);
			preadbyte_user = preadbyte_user + readsize;
			readsizetotal = readsizetotal + readsize;
			if (io_pfilelist->pfilebegin->pnext == NULL) {
				io_pfilelist->filebeginrpbyte = readsize;
			} else {
				io_pfilelist->pfilebegin =
					io_pfilelist->pfilebegin->pnext;
				io_pfilelist->filebeginrpbyte = 0;
			}
			goto clearoperation;
		}
		if (io_pfilelist->pfilebegin->wpbyte == 0) {
			/*
			When goto next step, set the current begin byte.
			*/
			io_pfilelist->filebeginrpbyte = 0;
			goto notenough;
		}
		pos = 0;
		readsize = io_pfilelist->pfilebegin->wpbyte;
		readsizeleft = readsizeleft - readsize;
		vfs_read(io_pfilelist->pfilebegin->pfile, preadbyte_user,
			 readsize, &pos);
		preadbyte_user = preadbyte_user + readsize;
		readsizetotal = readsizetotal + readsize;
		if (io_pfilelist->pfilebegin->pnext == NULL) {
			io_pfilelist->filebeginrpbyte =
				io_pfilelist->pfilebegin->wpbyte;
			ret = readsizetotal;
			goto notenough;
		}
		io_pfilelist->pfilebegin = io_pfilelist->pfilebegin->pnext;
	}

notenough:
	/*
	Currently, only tag use.
	*/

/*
Clear the un-used file node.
*/
clearoperation:
	/*
	Do not delete all of the list when need to delete all.
	*/
	pfile = io_pfilelist->phead;
	while (pfile != io_pfilelist->pfilebegin) {
		pfiledel = pfile;
		pfile = pfile->pnext;
		filp_close(pfiledel->pfile, NULL);
		kfree(pfiledel);
	}
	io_pfilelist->phead = io_pfilelist->pfilebegin;
	io_pfilelist->pfilebegin->ppre = NULL;
	ret = readsizetotal;
	return ret;
}

ssize_t internal_vastai_logsys_filelist_getfrompos_inner(
	struct vastai_logsys_filelist *io_pfilelist, loff_t *io_ppos,
	unsigned char *io_parraydata, u32 i_arraynum, loff_t i_pos)
{
	mm_segment_t old_fs = 0;
	loff_t pos = 0;
	loff_t posleft = i_pos;
	struct vastai_logsys_file *pbegin = io_pfilelist->pfilebegin;
	u32 beginpos = io_pfilelist->filebeginrpbyte;
	ssize_t ret = 0;
	size_t readsize = 0;
	size_t readsizetotal = 0;
	size_t readsizeleft = i_arraynum;
	unsigned char *preadbyte = io_parraydata;
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n", posleft);
	pr_info(VASTAI_LOGSYS_PR_HEAD "beginpos = %d\n", beginpos);
#endif
	if (io_pfilelist->phead == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET);
		return -1;
	}
	if (io_pfilelist->phead == io_pfilelist->ptail) {
		if (io_pfilelist->phead->wpbyte ==
		    io_pfilelist->filebeginrpbyte) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILELIST_ISEMPTY_WHENGET);
			return -1;
		}
	}
	if (io_ppos == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSPOINTER_ISNULL);
		return -1;
	}
	*io_ppos = 0;
	if (i_arraynum == 0)
		return 0;
	/*
	First, get the start pointer to get the file data.
	*/
	if (posleft <= (loff_t)pbegin->wpbyte - (loff_t)beginpos) {
		*io_ppos = *io_ppos + posleft;
		beginpos = beginpos + posleft;
		goto readdata;
	}
	*io_ppos = *io_ppos + (pbegin->wpbyte - beginpos);
	if (pbegin->pnext == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OUTOFRANGE);
		return -1;
	}
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n", posleft);
#endif
	posleft = posleft - (pbegin->wpbyte - beginpos);
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n", posleft);
#endif
	pbegin = pbegin->pnext;
	beginpos = 0;
	while (posleft) {
		if (posleft <= (loff_t)pbegin->wpbyte) {
			*io_ppos = *io_ppos + posleft;
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n",
				posleft);
#endif
			beginpos = posleft;
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD "beginpos = %d\n",
				beginpos);
#endif
			goto readdata;
		}
		if (pbegin->pnext == NULL) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OUTOFRANGE);
			return -1;
		}
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n", posleft);
#endif
		posleft = posleft - pbegin->wpbyte;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "posleft = %d\n", posleft);
#endif
		*io_ppos = *io_ppos + pbegin->wpbyte;
		pbegin = pbegin->pnext;
	}

/*
Read from file pbegin beginpos.
*/
readdata:
	/*
	First check whether the current pos is the end of file.
	*/
	if (beginpos == pbegin->wpbyte) {
		if (pbegin->pnext == NULL) {
			ret = readsizetotal;
			return ret;
		}
		pbegin = pbegin->pnext;
		beginpos = 0;
	}
	if (readsizeleft <= pbegin->wpbyte - beginpos) {
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "beginpos = %d\n", beginpos);
#endif
		pos = beginpos;
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		readsize = readsizeleft;
		readsizeleft = 0;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "pos = %d\n", pos);
#endif
		vfs_read(pbegin->pfile, preadbyte, readsize, &pos);
		set_fs(old_fs);
		*io_ppos = *io_ppos + readsize;
		preadbyte = preadbyte + readsize;
		readsizetotal = readsizetotal + readsize;
		ret = readsizetotal;
		return ret;
	}
	pos = beginpos;
	old_fs = get_fs();
	set_fs(KERNEL_DS);
	readsize = pbegin->wpbyte - beginpos;
	readsizeleft = readsizeleft - readsize;
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "pos = %d\n", pos);
#endif
	vfs_read(pbegin->pfile, preadbyte, readsize, &pos);
	set_fs(old_fs);
	preadbyte = preadbyte + readsize;
	*io_ppos = *io_ppos + readsize;
	readsizetotal = readsizetotal + readsize;
	if (pbegin->pnext == NULL) {
		ret = readsizetotal;
		return ret;
	}
	pbegin = pbegin->pnext;
	beginpos = 0;
	while (readsizeleft) {
		if (readsizeleft <= pbegin->wpbyte) {
			old_fs = get_fs();
			set_fs(KERNEL_DS);
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD "pos = %d\n", pos);
#endif
			vfs_read(pbegin->pfile, preadbyte, readsize, &pos);
			set_fs(old_fs);
			preadbyte = preadbyte + readsize;
			*io_ppos = *io_ppos + readsize;
			readsizetotal = readsizetotal + readsize;
			ret = readsizetotal;
			return ret;
		}
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		pos = 0;
		readsize = pbegin->wpbyte;
		readsizeleft = readsizeleft - readsize;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "pos = %d\n", pos);
#endif
		vfs_read(pbegin->pfile, preadbyte, readsize, &pos);
		set_fs(old_fs);
		preadbyte = preadbyte + readsize;
		*io_ppos = *io_ppos + readsize;
		readsizetotal = readsizetotal + readsize;
		if (pbegin->pnext == NULL) {
			ret = readsizetotal;
			return ret;
		}
		pbegin = pbegin->pnext;
	}
	ret = readsizetotal;
	return ret;
}

ssize_t internal_vastai_logsys_filelist_getfrompos_user(
	struct vastai_logsys_filelist *io_pfilelist, loff_t *io_ppos,
	char __user *io_parraydata_user, u32 i_arraynum, loff_t i_pos)
{
	//mm_segment_t old_fs;
	loff_t pos = 0;
	loff_t posleft = i_pos;
	struct vastai_logsys_file *pbegin = io_pfilelist->pfilebegin;
	u32 beginpos = io_pfilelist->filebeginrpbyte;
	ssize_t ret = 0;
	size_t readsize = 0;
	size_t readsizetotal = 0;
	size_t readsizeleft = i_arraynum;
	char __user *preadbyte_user = io_parraydata_user;
	if (io_pfilelist->phead == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv, VASTAI_LOGSYS_ENV_ERROR_FILELIST_ISNULL_WHENGET);
		return -1;
	}
	if (io_pfilelist->phead == io_pfilelist->ptail) {
		if (io_pfilelist->phead->wpbyte ==
		    io_pfilelist->filebeginrpbyte) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILELIST_ISEMPTY_WHENGET);
			return -1;
		}
	}
	*io_ppos = 0;
	if (i_arraynum == 0)
		return 0;
	/*
	First, get the start pointer to get the file data.
	*/
	if (posleft <= (loff_t)pbegin->wpbyte - (loff_t)beginpos) {
		*io_ppos = *io_ppos + posleft;
		beginpos = beginpos + posleft;
		goto readdata;
	}
	*io_ppos = *io_ppos + (pbegin->wpbyte - beginpos);
	if (pbegin->pnext == NULL) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OUTOFRANGE);
		return -1;
	}
	posleft = posleft - (pbegin->wpbyte - beginpos);
	pbegin = pbegin->pnext;
	beginpos = 0;
	while (posleft) {
		if (posleft <= (loff_t)pbegin->wpbyte) {
			*io_ppos = *io_ppos + posleft;
			beginpos = posleft;
			goto readdata;
		}
		if (pbegin->pnext == NULL) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSITION_OUTOFRANGE);
			return -1;
		}
		posleft = posleft - pbegin->wpbyte;
		*io_ppos = *io_ppos + pbegin->wpbyte;
		pbegin = pbegin->pnext;
	}

/*
Read from file pbegin beginpos.
*/
readdata:
	/*
	First check whether the current pos is the end of file.
	*/
	if (beginpos == pbegin->wpbyte) {
		if (pbegin->pnext == NULL) {
			ret = readsizetotal;
			return ret;
		}
		pbegin = pbegin->pnext;
		beginpos = 0;
	}
	if (readsizeleft <= pbegin->wpbyte - beginpos) {
		pos = beginpos;
		readsize = readsizeleft;
		readsizeleft = 0;
		vfs_read(pbegin->pfile, preadbyte_user, readsize, &pos);
		*io_ppos = *io_ppos + readsize;
		preadbyte_user = preadbyte_user + readsize;
		readsizetotal = readsizetotal + readsize;
		ret = readsizetotal;
		return ret;
	}
	pos = beginpos;
	readsize = pbegin->wpbyte - beginpos;
	readsizeleft = readsizeleft - readsize;
	vfs_read(pbegin->pfile, preadbyte_user, readsize, &pos);
	preadbyte_user = preadbyte_user + readsize;
	*io_ppos = *io_ppos + readsize;
	readsizetotal = readsizetotal + readsize;
	if (pbegin->pnext == NULL) {
		ret = readsizetotal;
		return ret;
	}
	pbegin = pbegin->pnext;
	beginpos = 0;
	while (readsizeleft) {
		if (readsizeleft <= pbegin->wpbyte) {
			pos = 0;
			readsize = readsizeleft;
			readsizeleft = 0;
			vfs_read(pbegin->pfile, preadbyte_user, readsize, &pos);
			preadbyte_user = preadbyte_user + readsize;
			*io_ppos = *io_ppos + readsize;
			readsizetotal = readsizetotal + readsize;
			ret = readsizetotal;
			return ret;
		}
		pos = 0;
		readsize = pbegin->wpbyte;
		readsizeleft = readsizeleft - readsize;
		vfs_read(pbegin->pfile, preadbyte_user, readsize, &pos);
		preadbyte_user = preadbyte_user + readsize;
		*io_ppos = *io_ppos + readsize;
		readsizetotal = readsizetotal + readsize;
		if (pbegin->pnext == NULL) {
			ret = readsizetotal;
			return ret;
		}
		pbegin = pbegin->pnext;
	}
	ret = readsizetotal;
	return ret;
}

u32 internal_vastai_logsys_filelist_clear(
	struct vastai_logsys_filelist *io_pfilelist, loff_t i_clearsize)
{
	struct vastai_logsys_file *pfile = NULL, *pfiledelbegin = NULL,
				  *pfiledel = NULL, *pfiledelbak = NULL;
	pfile = io_pfilelist->pfilebegin;
	if (io_pfilelist->filebeginrpbyte == pfile->wpbyte) {
		if (pfile->pnext == NULL) {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
		pfile = pfile->pnext;
	}
	/*
	pfile is the file stores the log which need to clear.
	*/
	if (io_pfilelist->filebeginrpbyte + i_clearsize > pfile->wpbyte) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (io_pfilelist->filebeginrpbyte == pfile->wpbyte) {
		if (pfile->pnext == NULL) {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
		pfile = pfile->pnext;
		io_pfilelist->filebeginrpbyte = 0;
	} else {
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"io_pcore->filelist.filebeginrpbyte = %d\n",
			io_pfilelist->filebeginrpbyte);
#endif
		io_pfilelist->filebeginrpbyte =
			io_pfilelist->filebeginrpbyte + i_clearsize;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"io_pcore->filelist.filebeginrpbyte = %d\n",
			io_pfilelist->filebeginrpbyte);
#endif
	}
	/*
	Clear the file node from io_pfilelist->pfilebegin to pfile's previous node.
	*/
	pfiledelbegin = io_pfilelist->pfilebegin;
	io_pfilelist->pfilebegin = pfile;
	pfiledel = pfiledelbegin;
	while (1) {
		if (pfiledel == pfile) {
			return 0;
		}
		pfiledelbak = pfiledel;
		pfiledel->pnext->ppre = NULL;
		pfiledel = pfiledel->pnext;
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 0)
		filp_close(pfiledelbak->pfile, NULL);
#endif
		kfree(pfiledelbak);
	}
	return 0;
}

void internal_vastai_logsys_filelist_clearall(
	struct vastai_logsys_filelist *io_pfilelist)
{
	struct vastai_logsys_file *pfile = NULL, *pfiledel = NULL;
	pfile = io_pfilelist->phead;
	while (pfile != io_pfilelist->ptail) {
		pfiledel = pfile;
		pfile = pfile->pnext;
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 0)
		filp_close(pfiledel->pfile, NULL);
#endif
		kfree(pfiledel);
	}
	io_pfilelist->pfilebegin = io_pfilelist->ptail;
	io_pfilelist->phead = io_pfilelist->ptail;
	io_pfilelist->filebeginrpbyte = io_pfilelist->ptail->wpbyte;
	io_pfilelist->ptail->ppre = NULL;
}

ssize_t internal_vastai_logsys_corelog_logbuffer_gettouser(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_parraydata_user, u32 i_arraynum, loff_t i_pos,
	u32 i_bclearbuffer)
{
	loff_t posleft = i_pos;
	size_t sizeget = 0;
	size_t sizegettotal = 0;
	size_t sizeleftget = 0;
	unsigned char *plog = NULL;
	char __user *puser = NULL;
	/*
	Log buffer enable only when have clear buffer user.
	*/
	if (io_pcore->puser_clearbuffer == NULL ||
	    io_pcore->wpoffset == io_pcore->rpoffset) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_LOGBUFFER_ISEMPTY_WHENGET);
		return -1;
	}
	if (i_pos != 0 && i_bclearbuffer == 1) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_CLEARBUFFER_WHENPOS_NOTBEGIN);
		return -1;
	}
	if (i_pos >= (loff_t)io_pcore->currbytelogbuffer) {
		return 0;
	}
	if (io_pcore->wpoffset > io_pcore->rpoffset) {
		plog = io_pcore->logbuffer + io_pcore->rpoffset + i_pos;
		if (i_arraynum <= io_pcore->currbytelogbuffer - i_pos) {
			sizeget = i_arraynum;
		} else {
			sizeget = io_pcore->currbytelogbuffer - i_pos;
		}
		puser = io_parraydata_user;
		copy_to_user(puser, plog, sizeget);
		sizegettotal = sizeget;
		goto clearbuffercheck;
	}
	if (i_pos < VASTAI_LOGSYS_BUF_SIZE - (loff_t)io_pcore->rpoffset) {
		plog = io_pcore->logbuffer + io_pcore->rpoffset + i_pos;
		if (i_arraynum <=
		    VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset - i_pos) {
			sizeget = i_arraynum;
		} else {
			sizeget = VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset -
				  i_pos;
		}
		puser = io_parraydata_user;
		copy_to_user(puser, plog, sizeget);
		sizegettotal = sizeget;
		puser = io_parraydata_user + sizeget;
		sizeleftget = i_arraynum - sizeget;
		if (sizeleftget == 0) {
			goto clearbuffercheck;
		}
		if (sizeleftget <= io_pcore->currbytelogbuffer - sizeget) {
			sizeget = sizeleftget;
		} else {
			sizeget = io_pcore->currbytelogbuffer - sizeget;
		}
		plog = io_pcore->logbuffer;
		copy_to_user(puser, plog, sizeget);
		sizegettotal = sizegettotal + sizeget;
		goto clearbuffercheck;
	}

	posleft = posleft - (VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset);
	puser = io_parraydata_user;
	plog = io_pcore->logbuffer + posleft;
	if (i_arraynum <= io_pcore->wpoffset - posleft) {
		sizeget = i_arraynum;
	} else {
		sizeget = io_pcore->wpoffset - posleft;
	}
	copy_to_user(puser, plog, sizeget);

clearbuffercheck:
	if (i_pos == 0) {
		if (i_bclearbuffer == 1) {
			if (sizegettotal > io_pcore->currbytelogbuffer) {
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					_penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETLOGBUFFER_TOTALUNEXPECTED);
				return -1;
			}
			if (sizegettotal == io_pcore->currbytelogbuffer) {
				io_pcore->wpoffset = io_pcore->rpoffset = 0;
			} else {
				if (io_pcore->wpoffset > io_pcore->rpoffset) {
					io_pcore->rpoffset += sizegettotal;
				} else if (io_pcore->wpoffset <
					   io_pcore->rpoffset) {
					if (sizegettotal <
					    VASTAI_LOGSYS_BUF_SIZE -
						    io_pcore->rpoffset) {
						io_pcore->rpoffset +=
							sizegettotal;
					} else {
						io_pcore->rpoffset =
							sizegettotal -
							(VASTAI_LOGSYS_BUF_SIZE -
							 io_pcore->rpoffset);
					}
				}
			}
		}
	}

	return sizegettotal;
}

ssize_t internal_vastai_logsys_corelog_logbuffer_gettoinner(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char *io_parraydata_inner, u32 i_arraynum, loff_t i_pos,
	u32 i_bclearbuffer)
{
	loff_t posleft = i_pos;
	size_t sizeget = 0;
	size_t sizegettotal = 0;
	size_t sizeleftget = 0;
	unsigned char *plog = NULL;
	char *puser = NULL;
	/*
	Log buffer enable only when have clear buffer user.
	*/
	if (io_pcore->puser_clearbuffer == NULL ||
	    io_pcore->wpoffset == io_pcore->rpoffset) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_LOGBUFFER_ISEMPTY_WHENGET);
		return -1;
	}
	if (i_pos != 0 && i_bclearbuffer == 1) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_CLEARBUFFER_WHENPOS_NOTBEGIN);
		return -1;
	}
	if (i_pos >= (loff_t)io_pcore->currbytelogbuffer) {
		return 0;
	}
	if (io_pcore->wpoffset > io_pcore->rpoffset) {
		plog = io_pcore->logbuffer + io_pcore->rpoffset + i_pos;
		if (i_arraynum <= io_pcore->currbytelogbuffer - i_pos) {
			sizeget = i_arraynum;
		} else {
			sizeget = io_pcore->currbytelogbuffer - i_pos;
		}
		puser = io_parraydata_inner;
		memcpy(puser, plog, sizeget);
		sizegettotal = sizeget;
		goto clearbuffercheck;
	}
	if (i_pos < VASTAI_LOGSYS_BUF_SIZE - (loff_t)io_pcore->rpoffset) {
		plog = io_pcore->logbuffer + io_pcore->rpoffset + i_pos;
		if (i_arraynum <=
		    VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset - i_pos) {
			sizeget = i_arraynum;
		} else {
			sizeget = VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset -
				  i_pos;
		}
		puser = io_parraydata_inner;
		memcpy(puser, plog, sizeget);
		sizegettotal = sizeget;
		puser = io_parraydata_inner + sizeget;
		sizeleftget = i_arraynum - sizeget;
		if (sizeleftget == 0) {
			goto clearbuffercheck;
		}
		if (sizeleftget <= io_pcore->currbytelogbuffer - sizeget) {
			sizeget = sizeleftget;
		} else {
			sizeget = io_pcore->currbytelogbuffer - sizeget;
		}
		plog = io_pcore->logbuffer;
		memcpy(puser, plog, sizeget);
		sizegettotal = sizegettotal + sizeget;
		goto clearbuffercheck;
	}

	posleft = posleft - (VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset);
	puser = io_parraydata_inner;
	plog = io_pcore->logbuffer + posleft;
	if (i_arraynum <= io_pcore->wpoffset - posleft) {
		sizeget = i_arraynum;
	} else {
		sizeget = io_pcore->wpoffset - posleft;
	}
	memcpy(puser, plog, sizeget);

clearbuffercheck:
	if (i_pos == 0) {
		if (i_bclearbuffer == 1) {
			if (sizegettotal > io_pcore->currbytelogbuffer) {
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					_penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETLOGBUFFER_TOTALUNEXPECTED);
				return -1;
			}
			if (sizegettotal == io_pcore->currbytelogbuffer) {
				io_pcore->wpoffset = io_pcore->rpoffset = 0;
			} else {
				if (io_pcore->wpoffset > io_pcore->rpoffset) {
					io_pcore->rpoffset += sizegettotal;
				} else if (io_pcore->wpoffset <
					   io_pcore->rpoffset) {
					if (sizegettotal <
					    VASTAI_LOGSYS_BUF_SIZE -
						    io_pcore->rpoffset) {
						io_pcore->rpoffset +=
							sizegettotal;
					} else {
						io_pcore->rpoffset =
							sizegettotal -
							(VASTAI_LOGSYS_BUF_SIZE -
							 io_pcore->rpoffset);
					}
				}
			}
		}
	}

	return sizegettotal;
}

void internal_vastai_logsys_corelog_init_fileandlogbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore)
{
	internal_vastai_logsys_filelist_init(&io_pcore->filelist);
	/*
	Set wp and rp of the inner buffer to 0, meaning do not use the buffer at the current.
	*/
	io_pcore->wpoffset = io_pcore->rpoffset = 0;
	io_pcore->currbytesum = io_pcore->clearbytesum =
		io_pcore->totalbytesum = io_pcore->currbytelogbuffer =
			io_pcore->currbytefile = 0;
}

void internal_vastai_logsys_corelog_deinit_fileandlogbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore)
{
	struct vastai_logsys_file *pfile = NULL, *pfiledel = NULL;
	pfile = io_pcore->filelist.phead;
	while (pfile) {
		if (pfile->pfile != NULL) {
#if (VASTAI_LOGSYS_AVOID_REBOOT_MOUNT_ERROR == 0)
			filp_close(pfile->pfile, NULL);
#endif
		}
		pfiledel = pfile;
		pfile = pfile->pnext;
		kfree(pfiledel);
	}
}

#define DBG_READLOG 0

int internal_vastai_logsys_corelog_readddrtodrv(
	struct vastai_logsys_pci_die_core_env *io_pcore)
{
	int ret = 0;
	int pciret = 0;
	u32 logctrlinitdonemagic = 0;
	u32 path = 0;
	u64 ddr_ringbufaddr = VASTAI_LOGSYS_RPWP_STARTADDR +
			      (VASTAI_LOGSYS_RPWP_SIZE * io_pcore->core_index);
	T_VASTAI_LOGSYS_RINGBUF ringbuf = { 0 };
	u64 ddr_logaddr = 0;
	u32 oldsize = 0, newsize = 0;
	/*
	In kernel the stack is 8k or 16k, so we cannot define the big array here.
	*/
	unsigned char *plogbuffer = NULL;
	u32 curri = 0; // the current index of newsize
	u32 sizeleft = 0; // the size left to write to file
	//unsigned char logbuffertemp[VASTAI_LOGSYS_BUF_SIZE];
	u32 logbuffertempsize = 0;
	u32 useri = 0;
	u32 bcannewfile = 1;
	u32 bufferi = 0;
	unsigned char logcontentstr[32] = 0;

#if (DBG_READLOG == 1)
	if (io_pcore->die_index != 0) {
		pr_err("before readlog[initdone]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n",
		       io_pcore->pci_dev_id, io_pcore->die_index,
		       io_pcore->core_index,
		       VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED,
		       sizeof(logctrlinitdonemagic));
	}
#endif
	//pr_err("before readlog[initdone]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED, sizeof(logctrlinitdonemagic));
	pciret = vastai_pci_mem_read(io_pcore->p_pci_info,
				     io_pcore->die_index_global,
				     VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED,
				     &logctrlinitdonemagic,
				     sizeof(logctrlinitdonemagic));
	if (pciret < 0) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "read init done tag error!\n");
		return -1;
	}
#if (DBG_READLOG == 1)
	if (io_pcore->die_index != 0) {
		pr_err("after readlog[initdone]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n",
		       io_pcore->pci_dev_id, io_pcore->die_index,
		       io_pcore->core_index,
		       VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED,
		       sizeof(logctrlinitdonemagic));
	}
#endif
	//pr_err("after readlog[initdone]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED, sizeof(logctrlinitdonemagic));
	/*
	Smcu have not init the log ctrl.
	*/
	if (logctrlinitdonemagic != VASTAI_LOGSYS_CTRL_INITDONE_MAGIC) {
		//pr_err(VASTAI_LOGSYS_PR_HEAD "logctrlinitdonemagic is not correct!\n");
		return 0;
	}
#if (DBG_READLOG == 1)
	if (io_pcore->die_index != 0) {
		pr_err("before readlog[path]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n",
		       io_pcore->pci_dev_id, io_pcore->die_index,
		       io_pcore->core_index,
		       VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED, sizeof(path));
	}
#endif
	//pr_err("before readlog[path]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED, sizeof(path));
	pciret = vastai_pci_mem_read(io_pcore->p_pci_info,
				     io_pcore->die_index_global,
				     VASTAI_LOGSYS_CTRL_STARTADDR_PATH, &path,
				     sizeof(path));
	if (pciret < 0) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "read log path error!\n");
		return -1;
	}
#if (DBG_READLOG == 1)
	if (io_pcore->die_index != 0) {
		pr_err("before readlog[path]:pci[%d]die[%d]core[%d][global_index=%d]ddraddr[0x%llx]size[%d]\n",
		       io_pcore->pci_dev_id, io_pcore->die_index,
		       io_pcore->core_index, io_pcore->die_index_global,
		       VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED,
		       sizeof(logctrlinitdonemagic));
	}
#endif
	//pr_err("before readlog[path]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, VASTAI_LOGSYS_CTRL_STARTADDR_RESERVED, sizeof(logctrlinitdonemagic));
	/*
	Get the path lowest byte.
	*/
	//pr_err("path[u32] = %x\n", path);
	path = (path & 0xFF);
	//pr_err("path[u8] = %d\n", path);
	if (path == VASTAI_LOGSYS_PATH_UART) {
		//pr_err("uart path so return!\n");
		return 0;
	}
	//pr_err("NOT uart path so continue!\n");
	/*
	Get the core correspondent ddr address to t_ddr_addr.
	*/
	pciret =
		vastai_pci_mem_read(io_pcore->p_pci_info,
				    io_pcore->die_index_global, ddr_ringbufaddr,
				    &ringbuf, sizeof(ringbuf));
	if (pciret < 0) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "read ringbuffer rpwp error!\n");
		return -1;
	}
#if (DBG_READLOG == 1)
	if (io_pcore->die_index != 0) {
		pr_err("before read ringbuf point die[%d][global_index=%d][ringbuf.rpoffset=%ld][ringbuf.wpoffset=%ld]\n",
		       io_pcore->die_index, io_pcore->die_index_global,
		       ringbuf.rpoffset, ringbuf.wpoffset);
	}
#endif
	if (ringbuf.wpoffset == ringbuf.rpoffset) {
		return 0;
	}
	plogbuffer = kzalloc(VASTAI_LOGSYS_READDDR_BUFSIZE, GFP_KERNEL);
	if (plogbuffer == NULL) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "%s: failed to kzalloc logbuffer for ddr read to driver\n",
		       __func__);
		return -1;
	}

	if (ringbuf.wpoffset > ringbuf.rpoffset) {
		newsize = ringbuf.wpoffset - ringbuf.rpoffset;
	} else {
		newsize = (VASTAI_LOGSYS_BUF_SIZE - ringbuf.rpoffset +
			   ringbuf.wpoffset);
	}

#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
	if (io_pcore->puser_clearbuffer == NULL) {
		goto clearbufferisnull;
	}
#endif

#if (VASTAI_LOGSYS_LOGBUFFER_ENABLE == 1)
clearbufferisnotnull:
	/*
	Read the current log from ddr to the driver log buffer. When the driver log buffer is not enough to store the new log 
	buffer get from ddr, you need to dump all of the old log to the file and add the new log to the driver log buffer.
	From the rp to the wp of t_ddr_addr. The operation may be split to two part according to the rp wp position.
	*/
	/*
	Before store into the current log buffer, we need to check whether the previous log buffer will be overwritten by 
	the new log, when yes, we need to dump it to the file.
	We calculate the sum of old log buffer size and the new log size to write, when the sum is bigger or equal to the size 
	of the log buffer size, we need to flush old log first.
	*/
	if (io_pcore->wpoffset >= io_pcore->rpoffset) {
		oldsize = io_pcore->wpoffset - io_pcore->rpoffset;
	} else {
		oldsize = (VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset +
			   io_pcore->wpoffset);
	}
	if (oldsize + newsize >= VASTAI_LOGSYS_BUF_SIZE) {
		/*
		Need to dump old log to file first.
		*/
		/*
		Check whether need to do the dump operation twice due to split of ring buffer.
		*/
		if (io_pcore->wpoffset > io_pcore->rpoffset) {
			internal_vastai_logsys_filelist_add(
				&io_pcore->filelist,
				io_pcore->logbuffer + io_pcore->rpoffset,
				oldsize);
		} else {
			internal_vastai_logsys_filelist_add(
				&io_pcore->filelist,
				io_pcore->logbuffer + io_pcore->rpoffset,
				VASTAI_LOGSYS_BUF_SIZE - io_pcore->rpoffset);
			internal_vastai_logsys_filelist_add(&io_pcore->filelist,
							    io_pcore->logbuffer,
							    io_pcore->wpoffset);
		}
		io_pcore->wpoffset = io_pcore->rpoffset = 0;
	}
	if (ringbuf.wpoffset > ringbuf.rpoffset) {
		ddr_logaddr = ringbuf.ddr_baseaddr + ringbuf.rpoffset;
		vastai_pci_mem_read(io_pcore->p_pci_info,
				    io_pcore->die_index_global, ddr_logaddr,
				    io_pcore->logbuffer + ringbuf.rpoffset,
				    newsize);
	} else {
		ddr_logaddr = ringbuf.ddr_baseaddr + ringbuf.rpoffset;
		vastai_pci_mem_read(io_pcore->p_pci_info,
				    io_pcore->die_index_global, ddr_logaddr,
				    io_pcore->logbuffer + ringbuf.rpoffset,
				    VASTAI_LOGSYS_BUF_SIZE - ringbuf.rpoffset);
		ddr_logaddr = ringbuf.ddr_baseaddr;
		vastai_pci_mem_read(io_pcore->p_pci_info,
				    io_pcore->die_index_global, ddr_logaddr,
				    io_pcore->logbuffer, ringbuf.wpoffset);
	}
	if (io_pcore->wpoffset == io_pcore->rpoffset) {
		io_pcore->wpoffset = ringbuf.wpoffset;
		io_pcore->rpoffset = ringbuf.rpoffset;
	} else {
		io_pcore->wpoffset = ringbuf.wpoffset;
	}
	io_pcore->currbytesum += newsize;
	io_pcore->currbytelogbuffer = newsize;
	io_pcore->currbytefile += oldsize;
	io_pcore->totalbytesum += newsize;
	goto writerp;
#endif

	//clearbufferisnull:
	/*
	When clear buffer is null, we do not use inner logbuffer of the core. We directly write it to file.
	*/
	if (ringbuf.wpoffset > ringbuf.rpoffset) {
		ddr_logaddr = ringbuf.ddr_baseaddr + ringbuf.rpoffset;
		sizeleft = newsize;
		while (sizeleft > 0) {
			if (sizeleft <= VASTAI_LOGSYS_READDDR_BUFSIZE) {
#if (DBG_READLOG == 1)
				if (io_pcore->die_index != 0) {
					pr_err("before readlog:pci[%d]die[%d][global_index=%d]core[%d]ddraddr[0x%llx]size[%d]\n",
					       io_pcore->pci_dev_id,
					       io_pcore->die_index,
					       io_pcore->die_index_global,
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
				}
#endif
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer, sizeleft);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
					goto ret_label;
				}
#if (DBG_READLOG == 1)
				if (io_pcore->die_index != 0) {
					pr_err("after readlog:pci[%d]die[%d][global_index=%d]core[%d]ddraddr[0x%llx]size[%d]\n",
					       io_pcore->pci_dev_id,
					       io_pcore->die_index,
					       io_pcore->die_index_global,
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
				}
				for (bufferi = 0;
				     (bufferi < sizeleft && bufferi < 16);
				     bufferi++) {
					if (plogbuffer[bufferi] == '\0') {
						logcontentstr[bufferi] = ' ';
					} else {
						logcontentstr[bufferi] =
							plogbuffer[bufferi];
					}
				}
				logcontentstr[bufferi] = '\0';
				pr_info("after readlog:pci[%d]die[%d]core[%d]logcontent[%s]\n",
					io_pcore->pci_dev_id,
					io_pcore->die_index,
					io_pcore->core_index, logcontentstr);
#endif
				ddr_logaddr = ddr_logaddr + sizeleft;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					sizeleft, bcannewfile);
				bcannewfile = 0;
				sizeleft = 0;
				break;
			} else {
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr,
					       VASTAI_LOGSYS_READDDR_BUFSIZE);
					goto ret_label;
				}
				ddr_logaddr = ddr_logaddr +
					      VASTAI_LOGSYS_READDDR_BUFSIZE;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE,
					bcannewfile);
				bcannewfile = 0;
				sizeleft = sizeleft -
					   VASTAI_LOGSYS_READDDR_BUFSIZE;
			}
		}
		//vastai_pci_mem_read(io_pcore->p_pci_info, io_pcore->die_index_global, ddr_logaddr, logbuffertemp, newsize);
		//logbuffertempsize = newsize;
	} else {
		/*
		First part, rp to the end.
		*/
		ddr_logaddr = ringbuf.ddr_baseaddr + ringbuf.rpoffset;
		sizeleft = VASTAI_LOGSYS_BUF_SIZE - ringbuf.rpoffset;
		while (sizeleft > 0) {
			if (sizeleft <= VASTAI_LOGSYS_READDDR_BUFSIZE) {
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer, sizeleft);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
					goto ret_label;
				}
				ddr_logaddr = ddr_logaddr + sizeleft;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					sizeleft, bcannewfile);
				bcannewfile = 0;
				sizeleft = 0;
				break;
			} else {
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr,
					       VASTAI_LOGSYS_READDDR_BUFSIZE);
					goto ret_label;
				}
				ddr_logaddr = ddr_logaddr +
					      VASTAI_LOGSYS_READDDR_BUFSIZE;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE,
					bcannewfile);
				bcannewfile = 0;
				sizeleft = sizeleft -
					   VASTAI_LOGSYS_READDDR_BUFSIZE;
			}
		}
		//logbuffertempsize = VASTAI_LOGSYS_BUF_SIZE - ringbuf.rpoffset;

		/*
		Second part, begin to the wp.
		*/
		ddr_logaddr = ringbuf.ddr_baseaddr;
		sizeleft = ringbuf.wpoffset;
		while (sizeleft > 0) {
			if (sizeleft <= VASTAI_LOGSYS_READDDR_BUFSIZE) {
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer, sizeleft);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
					ret = -1;
					goto ret_label;
				}
				ddr_logaddr = ddr_logaddr + sizeleft;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, sizeleft);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					sizeleft, bcannewfile);
				bcannewfile = 0;
				sizeleft = 0;
				break;
			} else {
				//pr_err("before readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				pciret = vastai_pci_mem_read(
					io_pcore->p_pci_info,
					io_pcore->die_index_global, ddr_logaddr,
					plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE);
				if (pciret < 0) {
					pr_err(VASTAI_LOGSYS_PR_HEAD
					       "read core[%d] log ddraddr[0x%llx]size[%d] error!\n",
					       io_pcore->core_index,
					       ddr_logaddr, sizeleft);
					ret = -1;
					goto ret_label;
				}
				ddr_logaddr = ddr_logaddr +
					      VASTAI_LOGSYS_READDDR_BUFSIZE;
				//pr_err("after readlog:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_logaddr, VASTAI_LOGSYS_READDDR_BUFSIZE);
				internal_vastai_logsys_filelist_add(
					&io_pcore->filelist, plogbuffer,
					VASTAI_LOGSYS_READDDR_BUFSIZE,
					bcannewfile);
				bcannewfile = 0;
				sizeleft = sizeleft -
					   VASTAI_LOGSYS_READDDR_BUFSIZE;
			}
		}
		//logbuffertempsize = logbuffertempsize + ringbuf.wpoffset;
	}
	//internal_vastai_logsys_filelist_add(&io_pcore->filelist, logbuffertemp, logbuffertempsize);
	io_pcore->currbytesum += newsize;
	io_pcore->currbytefile += newsize;
	io_pcore->totalbytesum += newsize;
	//pr_info("pci[%d]die[%d]core[%d] io_pcore->totalbytesum = %ld\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, io_pcore->totalbytesum);
	goto writerp;

writerp:
	ringbuf.rpoffset = ringbuf.wpoffset;
	//pr_err("before write[rp]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_ringbufaddr + offsetof(T_VASTAI_LOGSYS_RINGBUF, rpoffset), sizeof(ringbuf.rpoffset));
	pciret = vastai_pci_mem_write(
		io_pcore->p_pci_info, io_pcore->die_index_global,
		ddr_ringbufaddr + offsetof(T_VASTAI_LOGSYS_RINGBUF, rpoffset),
		&ringbuf.rpoffset, sizeof(ringbuf.rpoffset));
	if (pciret < 0) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "write core[%d] rp[%lx] error!\n",
		       io_pcore->core_index, ringbuf.rpoffset);
		ret = -1;
		goto ret_label;
	}
	//pr_err("after write[rp]:pci[%d]die[%d]core[%d]ddraddr[0x%llx]size[%d]\n", io_pcore->pci_dev_id, io_pcore->die_index, io_pcore->core_index, ddr_ringbufaddr + offsetof(T_VASTAI_LOGSYS_RINGBUF, rpoffset), sizeof(ringbuf.rpoffset));
	//pr_err(VASTAI_LOGSYS_PR_HEAD "write wp[%d]\n", ringbuf.rpoffset);

	/*
Notify block user that have new log.
You do not need to add user mutex because the user instance will be valid until enter core 
and do core unbind operation.
*/
	//notifyhavenewlog:
	/*
	First notify clear buffer user if it is block mode.
	*/
	if (io_pcore->puser_clearbuffer != NULL &&
	    io_pcore->bblock_clearbuffer == 1) {
		//pr_err(VASTAI_LOGSYS_PR_HEAD "unexpected have puser_clearbuffer user!\n");
		io_pcore->puser_clearbuffer->bbreakblock = 1;
		wake_up(&io_pcore->puser_clearbuffer->wq_breakblock);
	}
	/*
	Then notify other block user.
	*/
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		if (io_pcore->parray_puser[useri] != NULL &&
		    io_pcore->parray_puserbblock[useri] == 1) {
			//pr_err(VASTAI_LOGSYS_PR_HEAD "unexpected have puserblock user!\n");
			io_pcore->parray_puser[useri]->bbreakblock = 1;
			wake_up(&io_pcore->parray_puser[useri]->wq_breakblock);
		}
	}

ret_label:
	kfree(plogbuffer);
	return ret;
}

ssize_t internal_vastai_logsys_corelog_readdrvtouser_fromcurrbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_pbuffer, loff_t *o_ptotalbyteindex,
	loff_t i_posfromcurrbegin, size_t i_size, u32 i_clearbuffer)
{
	ssize_t bufferget = 0;
	ssize_t fileget = 0;
	size_t sizeleft = i_size;
	size_t sizereadtotal = 0;
	char __user *puser = io_pbuffer;
	loff_t filereadpos = 0;
	loff_t posleft = i_posfromcurrbegin;

	if (i_posfromcurrbegin > (loff_t)io_pcore->currbytesum) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_POSITIVE;
	}
	if (i_size == 0) {
		return 0;
	}
	if (i_posfromcurrbegin == (loff_t)io_pcore->currbytesum) {
		return 0;
	}
	if (i_clearbuffer == 1) {
		if (i_posfromcurrbegin != 0) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_CLEARBUFFER_WHENPOS_NOTBEGIN);
			return -1;
		}
		if (io_pcore->currbytefile > 0) {
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD
				"io_pcore->filelist.filebeginrpbyte = %d\n",
				io_pcore->filelist.filebeginrpbyte);
#endif
			fileget =
				internal_vastai_logsys_filelist_getfrombeginwithclear_user(
					&io_pcore->filelist, puser, i_size);
#if (DEBUG_LOG == 1)
			pr_info(VASTAI_LOGSYS_PR_HEAD
				"io_pcore->filelist.filebeginrpbyte = %d\n",
				io_pcore->filelist.filebeginrpbyte);
#endif
			if (fileget < 0) {
				return fileget;
			}
			if (fileget > (ssize_t)i_size) {
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					_penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETSIZE_OVER_INPUTSIZE);
				return -1;
			}
			if (fileget == (ssize_t)i_size) {
				io_pcore->clearbytesum += fileget;
				io_pcore->currbytefile -= fileget;
				io_pcore->currbytesum -= fileget;
				if (o_ptotalbyteindex != NULL) {
					*o_ptotalbyteindex =
						io_pcore->clearbytesum +
						fileget;
				}
				return fileget;
			}
			puser = puser + fileget;
			/*
			Still need log. Log in the file is not enough.
			*/
			sizeleft = i_size - (size_t)fileget;
			sizereadtotal = (size_t)fileget;
			/*
			Check whether ring buffer has log.
			*/
			if (io_pcore->currbytelogbuffer == 0) {
				io_pcore->clearbytesum += fileget;
				io_pcore->currbytefile -= fileget;
				io_pcore->currbytesum -= fileget;
				if (o_ptotalbyteindex != NULL) {
					*o_ptotalbyteindex =
						io_pcore->clearbytesum +
						fileget;
				}
				return sizereadtotal;
			}
		}
		if (io_pcore->currbytelogbuffer > 0) {
			bufferget =
				internal_vastai_logsys_corelog_logbuffer_gettouser(
					io_pcore, puser, sizeleft, 0, 1);
			if (bufferget < 0) {
				return bufferget;
			}
			sizereadtotal = sizereadtotal + bufferget;
			io_pcore->clearbytesum += fileget;
			io_pcore->currbytefile -= fileget;
			io_pcore->currbytesum -= fileget;
			io_pcore->clearbytesum += bufferget;
			io_pcore->currbytelogbuffer -= bufferget;
			io_pcore->currbytesum -= bufferget;
			if (o_ptotalbyteindex != NULL) {
				*o_ptotalbyteindex = io_pcore->clearbytesum +
						     fileget + bufferget;
			}
		}
		return sizereadtotal;
	} // if (i_clearbuffer == 1)
	/*
	Run here means do not clear file or log buffer.
	*/
	if (io_pcore->currbytefile > 0 &&
	    i_posfromcurrbegin < (loff_t)io_pcore->currbytefile) {
		fileget = internal_vastai_logsys_filelist_getfrompos_user(
			&io_pcore->filelist, &filereadpos, puser, i_size,
			i_posfromcurrbegin);
		if (fileget < 0) {
			return fileget;
		}
		if (fileget > (ssize_t)i_size) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETSIZE_OVER_INPUTSIZE);
			return -1;
		}
		if (fileget == 0) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILEGET_UNEXPECTED_ZERO);
			return -1;
		}
		if (fileget == (ssize_t)i_size) {
			if (o_ptotalbyteindex != NULL) {
				*o_ptotalbyteindex = io_pcore->clearbytesum +
						     i_posfromcurrbegin +
						     fileget;
			}
			return fileget;
		}
		puser = puser + fileget;
		/*
		Still need log. Log in the file is not enough.
		*/
		sizeleft = i_size - (size_t)fileget;
		sizereadtotal = (size_t)fileget;
	}
	if (io_pcore->currbytelogbuffer > 0) {
		if (posleft > (loff_t)io_pcore->currbytelogbuffer) {
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POS_UNEXPECTED_OUTOFRANGE);
			return -1;
		}
		bufferget = internal_vastai_logsys_corelog_logbuffer_gettouser(
			io_pcore, puser, sizeleft, posleft, 0);
		if (bufferget < 0) {
			return bufferget;
		}
		sizereadtotal = sizereadtotal + bufferget;
		if (o_ptotalbyteindex != NULL) {
			*o_ptotalbyteindex = io_pcore->clearbytesum +
					     i_posfromcurrbegin + fileget +
					     bufferget;
		}
		return sizereadtotal;
	}
	if (posleft != 0) {
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSLEFT_UNEXPECTED_NOTZERO);
		return -1;
	}
	VASTAI_LOGSYS_ENV_ERROR_RECORD(
		_penv, VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
	return -1;
}

ssize_t internal_vastai_logsys_corelog_readdrvtoinner_fromcurrbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore, char *io_pbuffer,
	loff_t *o_ptotalbyteindex, loff_t i_posfromcurrbegin, size_t i_size,
	u32 i_clearbuffer)
{
	ssize_t bufferget = 0;
	ssize_t fileget = 0;
	size_t sizeleft = i_size;
	size_t sizereadtotal = 0;
	char *puser = io_pbuffer;
	loff_t filereadpos = 0;
	loff_t posleft = i_posfromcurrbegin;

	if (i_posfromcurrbegin > (loff_t)io_pcore->currbytesum) {
		SIMPLE_DEBUG_LOG;
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_POSITIVE;
	}
	if (i_size == 0) {
		SIMPLE_DEBUG_LOG;
		return 0;
	}
	if (i_posfromcurrbegin == io_pcore->currbytesum) {
		SIMPLE_DEBUG_LOG;
		return 0;
	}
	if (i_clearbuffer == 1) {
		SIMPLE_DEBUG_LOG;
		if (i_posfromcurrbegin != 0) {
			SIMPLE_DEBUG_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_CLEARBUFFER_WHENPOS_NOTBEGIN);
			return -1;
		}
		SIMPLE_DEBUG_LOG;
		if (io_pcore->currbytefile > 0) {
			SIMPLE_DEBUG_LOG;
			fileget =
				internal_vastai_logsys_filelist_getfrombeginwithclear_inner(
					&io_pcore->filelist, puser, i_size);
			if (fileget < 0) {
				SIMPLE_DEBUG_LOG;
				return fileget;
			}
			SIMPLE_DEBUG_LOG;
			if (fileget > (ssize_t)i_size) {
				SIMPLE_DEBUG_LOG;
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					_penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETSIZE_OVER_INPUTSIZE);
				return -1;
			}
			SIMPLE_DEBUG_LOG;
			if (fileget == i_size) {
				SIMPLE_DEBUG_LOG;
				io_pcore->clearbytesum += fileget;
				io_pcore->currbytefile -= fileget;
				io_pcore->currbytesum -= fileget;
				if (o_ptotalbyteindex != NULL) {
					SIMPLE_DEBUG_LOG;
					*o_ptotalbyteindex =
						io_pcore->clearbytesum +
						fileget;
				}
				SIMPLE_DEBUG_LOG;
				return fileget;
			}
			SIMPLE_DEBUG_LOG;
			puser = puser + fileget;
			/*
			Still need log. Log in the file is not enough.
			*/
			sizeleft = i_size - (size_t)fileget;
			SIMPLE_DEBUG_LOG;
			sizereadtotal = (size_t)fileget;
			/*
			Check whether ring buffer has log.
			*/
			if (io_pcore->currbytelogbuffer == 0) {
				SIMPLE_DEBUG_LOG;
				io_pcore->clearbytesum += fileget;
				io_pcore->currbytefile -= fileget;
				io_pcore->currbytesum -= fileget;
				if (o_ptotalbyteindex != NULL) {
					SIMPLE_DEBUG_LOG;
					*o_ptotalbyteindex =
						io_pcore->clearbytesum +
						fileget;
				}
				SIMPLE_DEBUG_LOG;
				return sizereadtotal;
			}
		}
		SIMPLE_DEBUG_LOG;
		if (io_pcore->currbytelogbuffer > 0) {
			SIMPLE_DEBUG_LOG;
			bufferget =
				internal_vastai_logsys_corelog_logbuffer_gettoinner(
					io_pcore, puser, sizeleft, 0, 1);
			if (bufferget < 0) {
				SIMPLE_DEBUG_LOG;
				return bufferget;
			}
			SIMPLE_DEBUG_LOG;
			sizereadtotal = sizereadtotal + bufferget;
			io_pcore->clearbytesum += fileget;
			io_pcore->currbytefile -= fileget;
			io_pcore->currbytesum -= fileget;
			io_pcore->clearbytesum += bufferget;
			io_pcore->currbytelogbuffer -= bufferget;
			io_pcore->currbytesum -= bufferget;
			SIMPLE_DEBUG_LOG;
			if (o_ptotalbyteindex != NULL) {
				SIMPLE_DEBUG_LOG;
				*o_ptotalbyteindex = io_pcore->clearbytesum +
						     fileget + bufferget;
			}
			SIMPLE_DEBUG_LOG;
		}
		SIMPLE_DEBUG_LOG;
		return sizereadtotal;
	} // if (i_clearbuffer == 1)
	/*
	Run here means do not clear file or log buffer.
	*/
	if (io_pcore->currbytefile > 0 &&
	    i_posfromcurrbegin < (loff_t)io_pcore->currbytefile) {
		SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "i_posfromcurrbegin = %d\n",
			i_posfromcurrbegin);
#endif
		fileget = internal_vastai_logsys_filelist_getfrompos_inner(
			&io_pcore->filelist, &filereadpos, puser, i_size,
			i_posfromcurrbegin);
		if (fileget < 0) {
			SIMPLE_DEBUG_LOG;
			return fileget;
		}
		if (fileget > (ssize_t)i_size) {
			SIMPLE_DEBUG_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_GETSIZE_OVER_INPUTSIZE);
			return -1;
		}
		SIMPLE_DEBUG_LOG;
		if (fileget == 0) {
			SIMPLE_DEBUG_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_FILEGET_UNEXPECTED_ZERO);
			return -1;
		}
		SIMPLE_DEBUG_LOG;
		if (fileget == i_size) {
			SIMPLE_DEBUG_LOG;
			if (o_ptotalbyteindex != NULL) {
				SIMPLE_DEBUG_LOG;
				*o_ptotalbyteindex = io_pcore->clearbytesum +
						     i_posfromcurrbegin +
						     fileget;
			}
			SIMPLE_DEBUG_LOG;
			return fileget;
		}
		SIMPLE_DEBUG_LOG;
		puser = puser + fileget;
		/*
		Still need log. Log in the file is not enough.
		*/
		sizeleft = i_size - (size_t)fileget;
		sizereadtotal = (size_t)fileget;
		SIMPLE_DEBUG_LOG;
	}
	if (io_pcore->currbytelogbuffer > 0) {
		SIMPLE_DEBUG_LOG;
		if (posleft > (loff_t)io_pcore->currbytelogbuffer) {
			SIMPLE_DEBUG_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POS_UNEXPECTED_OUTOFRANGE);
			return -1;
		}
		SIMPLE_DEBUG_LOG;
		bufferget = internal_vastai_logsys_corelog_logbuffer_gettoinner(
			io_pcore, puser, sizeleft, posleft, 0);
		if (bufferget < 0) {
			SIMPLE_DEBUG_LOG;
			return bufferget;
		}
		SIMPLE_DEBUG_LOG;
		sizereadtotal = sizereadtotal + bufferget;
		if (o_ptotalbyteindex != NULL) {
			SIMPLE_DEBUG_LOG;
			*o_ptotalbyteindex = io_pcore->clearbytesum +
					     i_posfromcurrbegin + fileget +
					     bufferget;
		}
		SIMPLE_DEBUG_LOG;
		return sizereadtotal;
	}
	SIMPLE_DEBUG_LOG;
	if (posleft != 0) {
		SIMPLE_DEBUG_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_POSLEFT_UNEXPECTED_NOTZERO);
		return -1;
	}
	SIMPLE_DEBUG_LOG;
	VASTAI_LOGSYS_ENV_ERROR_RECORD(
		_penv, VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
	return -1;
}

ssize_t internal_vastai_logsys_corelog_readdrvtouser_fromtotalbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	char __user *io_pbuffer, loff_t *o_ptotalbyteindex,
	loff_t i_posfromtotalbegin, size_t i_size)
{
	ssize_t ret = 0;
	loff_t posfromcurr = 0;
	if (i_posfromtotalbegin < (loff_t)io_pcore->clearbytesum) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_NEGATIVE;
	}
	if (i_posfromtotalbegin > (loff_t)io_pcore->totalbytesum) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_POSITIVE;
	}
	if (i_size == 0) {
		return 0;
	}
	if (i_posfromtotalbegin == (loff_t)io_pcore->totalbytesum) {
		return 0;
	}
	posfromcurr = i_posfromtotalbegin - io_pcore->clearbytesum;
	ret = internal_vastai_logsys_corelog_readdrvtouser_fromcurrbegin(
		io_pcore, io_pbuffer, o_ptotalbyteindex, posfromcurr, i_size,
		0);
	return ret;
}

ssize_t internal_vastai_logsys_corelog_readdrvtoinner_fromtotalbegin(
	struct vastai_logsys_pci_die_core_env *io_pcore, char *io_pbuffer,
	loff_t *o_ptotalbyteindex, loff_t i_posfromtotalbegin, size_t i_size)
{
	ssize_t ret = 0;
	loff_t posfromcurr = 0;
	if (i_posfromtotalbegin < (loff_t)io_pcore->clearbytesum) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_NEGATIVE;
	}
	if (i_posfromtotalbegin > (loff_t)io_pcore->totalbytesum) {
		return -VASTAI_LOGSYS_USER_ERROR_LOG_POSITION_OUTOFRANGE_POSITIVE;
	}
	if (i_size == 0) {
		return 0;
	}
	if (i_posfromtotalbegin == io_pcore->totalbytesum) {
		return 0;
	}
	posfromcurr = i_posfromtotalbegin - io_pcore->clearbytesum;
#if (DEBUG_LOG == 1)
	pr_info(VASTAI_LOGSYS_PR_HEAD "posfromcurr = %ld\n", posfromcurr);
#endif
	ret = internal_vastai_logsys_corelog_readdrvtoinner_fromcurrbegin(
		io_pcore, io_pbuffer, o_ptotalbyteindex, posfromcurr, i_size,
		0);
	return ret;
}

u32 internal_vastai_logsys_corelog_findnextlogbeginpos(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	loff_t *o_ptotalbyteindex, loff_t i_totalbyteindex)
{
	ssize_t retsub = 0;
	unsigned char parray_readbyte[64] = 0, *preadbyte = NULL, *pchar = NULL;
	u32 logu32 = 0;
	u32 logmode = 0;
	u32 tagandheaderlen = 0;
	u32 len = 0;
	u32 totallen = 0;
	//u32 buselogbuffer = 0;
	loff_t totalbyteindex = 0;

	if (i_totalbyteindex == io_pcore->totalbytesum) {
		*o_ptotalbyteindex = i_totalbyteindex;
		return 0;
	}
	retsub = internal_vastai_logsys_corelog_readdrvtoinner_fromtotalbegin(
		io_pcore, (char *)parray_readbyte, &totalbyteindex,
		i_totalbyteindex, 12);
	if (retsub < 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	preadbyte = parray_readbyte;
	logu32 = *preadbyte;
	logmode = ((logu32 & 0xF0) >> 4);
	if (logmode == VASTAI_LOGSYS_TYPE_STRING ||
	    logmode == VASTAI_LOGSYS_TYPE_MEMORY) {
		tagandheaderlen = 10;
	} else if (logmode == VASTAI_LOGSYS_TYPE_TRACEID ||
		   logmode == VASTAI_LOGSYS_TYPE_POINT) {
		tagandheaderlen = 8;
	} else {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if ((logu32 & 0xC) != 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	len = (((logu32 & 0x3) << 8) | ((logu32 & 0xFF00) >> 8));
	if (len == 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	totallen = tagandheaderlen + len;
	totallen = ((totallen + 3) / 4) * 4;
	*o_ptotalbyteindex = i_totalbyteindex + totallen;
	return 0;
}

u32 internal_vastai_logsys_corelog_findnearestpos_fromtotalbeginandoffset(
	struct vastai_logsys_pci_die_core_env *io_pcore,
	loff_t *o_ptotalbyteindex, loff_t i_beginoffsetdef)
{
	loff_t totalbyteindexunalign =
		0; // user expected position, but not the accurate start point
	loff_t totalbyteindexcurr =
		0; // at last the value is to output as the accurate start point
	loff_t pos = 0;
	struct vastai_logsys_file *pfile = NULL;
	mm_segment_t old_fs = 0;

	/*
	For parse log head use.
	*/
	unsigned char parray_readbyte[64] = 0, *preadbyte = NULL, *pchar = NULL;
	u32 logu32 = 0;
	u32 logmode = 0;
	u32 tagandheaderlen = 0;
	u32 len = 0;
	u32 totallen = 0;
	u32 buselogbuffer = 0;

	if (i_beginoffsetdef == 0) {
		*o_ptotalbyteindex = io_pcore->clearbytesum;
		return 0;
	}
	if (i_beginoffsetdef > 0) {
		if (i_beginoffsetdef >= (loff_t)io_pcore->totalbytesum) {
			*o_ptotalbyteindex = io_pcore->totalbytesum;
			return 0;
		}
		totalbyteindexunalign = i_beginoffsetdef;
	}
	if (i_beginoffsetdef < 0) {
		if ((-i_beginoffsetdef) >= (loff_t)io_pcore->currbytesum) {
			*o_ptotalbyteindex = io_pcore->currbytesum;
			return 0;
		}
		totalbyteindexunalign =
			io_pcore->totalbytesum + i_beginoffsetdef;
	}
	/*
	First check whether is within the log buffer.
	*/
	if (totalbyteindexunalign >
	    (loff_t)io_pcore->clearbytesum + (loff_t)io_pcore->currbytefile) {
		buselogbuffer = 1;
	}
	pfile = io_pcore->filelist.pfilebegin;
	/*
	Check whether only need the first file node.
	*/
	if (pfile->wpbyte - io_pcore->filelist.filebeginrpbyte ==
	    totalbyteindexunalign) {
		*o_ptotalbyteindex = totalbyteindexunalign;
		return 0;
	}
	if ((loff_t)pfile->wpbyte - (loff_t)io_pcore->filelist.filebeginrpbyte >
	    totalbyteindexunalign) {
		/*
		Only need to use the first file node.
		*/
		totalbyteindexcurr = 0;
		goto findaccurateposition;
	}
	/*
	Need to iterate the following file node.
	The first file is over, so the current total byte index is the valid size of the first file.
	*/
	totalbyteindexcurr = pfile->wpbyte - io_pcore->filelist.filebeginrpbyte;
	/*
	Find the last file position first.
	*/
	while (pfile->pnext) {
		pfile = pfile->pnext;
		if (totalbyteindexcurr + pfile->wpbyte ==
		    totalbyteindexunalign) {
			*o_ptotalbyteindex = totalbyteindexunalign;
			return 0;
		}
		if (totalbyteindexcurr + (loff_t)pfile->wpbyte >
		    totalbyteindexunalign) {
			goto findaccurateposition;
		}
		totalbyteindexcurr = totalbyteindexcurr + pfile->wpbyte;
	}
	/*
	Should not run here!
	*/
	SIMPLE_KERNEL_LOG;
	VASTAI_LOGSYS_ENV_ERROR_RECORD(
		_penv, VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
	return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;

	/*
	Find the accurate log position.
	*/
findaccurateposition:
	if (buselogbuffer == 0) {
		if (pfile == io_pcore->filelist.pfilebegin) {
			pos = io_pcore->filelist.filebeginrpbyte;
		} else {
			pos = 0;
		}
	} else {
		pos = 0;
	}
	/*
	When the next log's end point is bigger than totalbyteindexunalign, then we use the 
	totalbyteindexcurr as the output start point.
	*/
trymovenextlog:
	if (buselogbuffer == 0) {
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		vfs_read(pfile->pfile, parray_readbyte, 12, &pos);
		set_fs(old_fs);
	} else {
		internal_vastai_logsys_corelog_logbuffer_gettoinner(
			io_pcore, parray_readbyte, 12, pos, 0);
	}
	preadbyte = parray_readbyte;
	logu32 = *preadbyte;
	logmode = ((logu32 & 0xF0) >> 4);
	if (logmode == VASTAI_LOGSYS_TYPE_STRING ||
	    logmode == VASTAI_LOGSYS_TYPE_MEMORY) {
		tagandheaderlen = 10;
	} else if (logmode == VASTAI_LOGSYS_TYPE_TRACEID ||
		   logmode == VASTAI_LOGSYS_TYPE_POINT) {
		tagandheaderlen = 8;
	} else {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if ((logu32 & 0xC) != 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	len = (((logu32 & 0x3) << 8) | ((logu32 & 0xFF00) >> 8));
	if (len == 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	totallen = tagandheaderlen + len;
	totallen = ((totallen + 3) / 4) * 4;
	if (totalbyteindexcurr + totallen == totalbyteindexunalign) {
		*o_ptotalbyteindex = totalbyteindexunalign;
		return 0;
	}
	if (totalbyteindexcurr + (loff_t)totallen > totalbyteindexunalign) {
		*o_ptotalbyteindex = totalbyteindexcurr;
		return 0;
	}
	/*
	When the current log's end point is still smaller than the user expected point, 
	we need to move to next log.
	*/
	totalbyteindexcurr = totalbyteindexcurr + totallen;
	pos = pos + totallen;
	goto trymovenextlog;
}

void internal_vastai_logsys_corelog_clearbuffer(
	struct vastai_logsys_pci_die_core_env *io_pcore)
{
	io_pcore->clearbytesum += io_pcore->currbytesum;
	internal_vastai_logsys_filelist_clearall(&io_pcore->filelist);
	io_pcore->wpoffset = io_pcore->rpoffset = 0;
	io_pcore->currbytesum = io_pcore->currbytefile =
		io_pcore->currbytelogbuffer = 0;
}

void internal_vastai_logsys_corelog_clearbuffer_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie)
{
	u32 corei = 0;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		pcore = &io_pdie->parray_core_env[corei];
		mutex_lock(&pcore->mutex_core);
		internal_vastai_logsys_corelog_clearbuffer(pcore);
		mutex_unlock(&pcore->mutex_core);
	}
}

void internal_vastai_logsys_corelog_clearbuffer_ofpci(
	struct vastai_logsys_pci_env *io_ppci)
{
	u32 diei = 0;
	u32 diecount = 0;
	//u32 corei;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	diecount = io_ppci->die_count;
	for (diei = 0; diei < diecount; diei++) {
		pdie = &io_ppci->parray_die_env[diei];
		internal_vastai_logsys_corelog_clearbuffer_ofdie(pdie);
	}
}

void internal_vastai_logsys_corelog_changelevel(
	struct vastai_logsys_pci_die_core_env *io_pcore, u32 i_loglevel,
	u32 i_logenable)
{
	unsigned char logctrl = 0;
	u64 ddr_logctrladdr =
		VASTAI_LOGSYS_CTRL_STARTADDR_BUF + io_pcore->core_index;

	mutex_lock(&io_pcore->mutex_core);
	/*
	Get original log ctrl value.
	*/
	vastai_pci_mem_read(io_pcore->p_pci_info, io_pcore->die_index_global,
			    ddr_logctrladdr, &logctrl, sizeof(logctrl));
	logctrl = (((logctrl & 0x1E) | (i_loglevel << 5)) | i_logenable);
	vastai_pci_mem_write(io_pcore->p_pci_info, io_pcore->die_index_global,
			     ddr_logctrladdr, &logctrl, sizeof(logctrl));
	mutex_unlock(&io_pcore->mutex_core);
}

void internal_vastai_logsys_corelog_changelevel_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie, u32 i_loglevel,
	u32 i_logenable)
{
	u32 corei = 0;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		pcore = &io_pdie->parray_core_env[corei];
		mutex_lock(&pcore->mutex_core);
		internal_vastai_logsys_corelog_changelevel(pcore, i_loglevel,
							   i_logenable);
		mutex_unlock(&pcore->mutex_core);
	}
}

void internal_vastai_logsys_corelog_changelevel_ofpci(
	struct vastai_logsys_pci_env *io_ppci, u32 i_loglevel, u32 i_logenable)
{
	u32 diei = 0;
	u32 diecount = 0;
	//u32 corei;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	diecount = io_ppci->die_count;
	for (diei = 0; diei < diecount; diei++) {
		pdie = &io_ppci->parray_die_env[diei];
		internal_vastai_logsys_corelog_clearbuffer_ofdie(pdie);
	}
}

void internal_vastai_logsys_corelog_changepath_ofdie(
	struct vastai_logsys_pci_die_env *io_pdie, u32 i_path)
{
	unsigned char path = i_path;
	vastai_pci_mem_write(io_pdie->p_pci_info, io_pdie->die_index_global,
			     VASTAI_LOGSYS_CTRL_STARTADDR_PATH, &path,
			     sizeof(path));
}

void internal_vastai_logsys_corelog_changepath_ofpci(
	struct vastai_logsys_pci_env *io_ppci, u32 i_path)
{
	u32 diei = 0;
	u32 diecount = 0;
	//u32 corei;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	diecount = io_ppci->die_count;
	for (diei = 0; diei < diecount; diei++) {
		pdie = &io_ppci->parray_die_env[diei];
		internal_vastai_logsys_corelog_changepath_ofdie(pdie, i_path);
	}
}

void internal_vastai_logsys_user_bindinfo_init(
	struct vastai_logsys_user_bindinfo *io_pbindinfo)
{
	io_pbindinfo->mode = VASTAI_LOGSYS_MODE_INFO;
	io_pbindinfo->user_mode_info.pci_dev_id = -1;
	io_pbindinfo->puser_mode_log_head = io_pbindinfo->puser_mode_log_tail =
		NULL;
}

void internal_vastai_logsys_user_bindinfo_init_by_src(
	struct vastai_logsys_user_bindinfo *io_pbindinfodst,
	struct vastai_logsys_user_bindinfo *i_pbindinfosrc)
{
	struct vastai_logsys_user_mode_log
		*plog = i_pbindinfosrc->puser_mode_log_head,
		*pnew = NULL;
	if (i_pbindinfosrc->mode == VASTAI_LOGSYS_MODE_INFO) {
		io_pbindinfodst->mode = VASTAI_LOGSYS_MODE_INFO;
		SIMPLE_DEBUG_LOG;
		io_pbindinfodst->user_mode_info =
			i_pbindinfosrc->user_mode_info;
		io_pbindinfodst->puser_mode_log_head =
			io_pbindinfodst->puser_mode_log_tail = NULL;
		return;
	}
	io_pbindinfodst->mode = VASTAI_LOGSYS_MODE_LOG;
	SIMPLE_DEBUG_LOG;
	io_pbindinfodst->puser_mode_log_head =
		io_pbindinfodst->puser_mode_log_tail = NULL;
	while (plog) {
		pnew = kzalloc(sizeof(struct vastai_logsys_user_mode_log),
			       GFP_KERNEL);
		*pnew = *plog;
		plog = plog->pnext;
		/*
		Add to the dst link.
		*/
		pnew->pnext = NULL;
		if (io_pbindinfodst->puser_mode_log_head == NULL) {
			pnew->ppre = NULL;
			io_pbindinfodst->puser_mode_log_head =
				io_pbindinfodst->puser_mode_log_tail = pnew;
		} else {
			io_pbindinfodst->puser_mode_log_tail->pnext = pnew;
			pnew->ppre = io_pbindinfodst->puser_mode_log_tail;
			io_pbindinfodst->puser_mode_log_tail = pnew;
		}
	}
}

void internal_vastai_logsys_user_bindinfo_deinit(
	struct vastai_logsys_user_bindinfo *io_pbindinfo)
{
	struct vastai_logsys_user_mode_log
		*plog = io_pbindinfo->puser_mode_log_head,
		*pdel = NULL;
	/*
	In some circumstance, we may have not release the plog linked list when occur error. 
	So we need to check and delete here whatever the mode is log or not.
	*/
	while (plog) {
		pdel = plog;
		plog = plog->pnext;
		kfree(pdel);
	}
	io_pbindinfo->mode = VASTAI_LOGSYS_MODE_INFO;
	io_pbindinfo->puser_mode_log_head = io_pbindinfo->puser_mode_log_tail =
		NULL;
	io_pbindinfo->user_mode_info.pci_dev_id = -1;
}

void internal_vastai_logsys_user_readsession_reset_tonull(
	struct vastai_logsys_user_readsession *io_preadsession)
{
	io_preadsession->pcorenode = NULL;
	io_preadsession->buffersize = 0;
	io_preadsession->totalbyteindexcurr =
		io_preadsession->totalbyteindexnext = 0;
	io_preadsession->totalbyteindexend = 0;
	/*
	The buffer index is of buffer or of totalbyteindexcurr to totalbyteindexnext.
	*/
	io_preadsession->bufferindex = 0;
}

u32 internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
	struct vastai_logsys_user_readsession *io_preadsession,
	struct vastai_logsys_pci_die_pcore_node *i_pcorenode, u32 i_callertype,
	loff_t i_totalbyteindex)
{
	u32 ret = 0;
	struct vastai_logsys_pci_die_core_env *pcore = i_pcorenode->pcore;
	ssize_t retsub = 0;
	unsigned char parray_readbyte[64] = 0, *preadbyte = NULL, *pchar = NULL;
	u32 logu32 = 0;
	u32 logmode = 0;
	u32 tagandheaderlen = 0;
	u32 clockcount = 0;
	u32 coreid = 0;
	u32 len = 0;
	u32 totallen =
		0; // The total byte size of the log before parsing, 4 bytes alignment
	u32 bytei =
		0; // The index of byte to store the next log byte, start from 0
	unsigned char coredscr[16] = 0;
	char *pwritebyte = NULL;
	u32 bufferindex = 0;
	u32 sprintflen = 0;
	u32 traceid = 0;
	u32 pointaddr = 0, pointvalue = 0;
	u32 memlogi = 0;
	//unsigned char memlogsubstr[8];
	loff_t totalbyteindex = 0;
	u32 chari = 0;
	u32 loglevel = 0;
	unsigned char leveldscr[16] = 0;

	io_preadsession->pcorenode = i_pcorenode;
	io_preadsession->totalbyteindexcurr = i_totalbyteindex;
	if (io_preadsession->totalbyteindexcurr ==
	    io_preadsession->totalbyteindexend) {
		/*
		There is no log.
		*/
		io_preadsession->totalbyteindexnext =
			io_preadsession->totalbyteindexend;
		io_preadsession->bufferindex = io_preadsession->buffersize = 0;
		return 0;
	}

	/*
	When caller is shellcat, we need to prepare the buffer, when caller is C, we do not 
	need to prepare the buffer.
	*/
	if (i_callertype == VASTAI_LOGSYS_CALLER_C) {
		ret = internal_vastai_logsys_corelog_findnextlogbeginpos(
			pcore, &io_preadsession->totalbyteindexnext,
			i_totalbyteindex);
		if (ret > 0) {
			return ret;
		}
		return 0;
	}

	/*
	Should have log when run here.
	Need to parse the log.
	*/
	/*
	10 bytes when log is string or memory.
	8 bytes when log is traceid or point(at least 4 bytes).
	So we can get 12 bytes for we make log 4 bytes alignment.
	*/
	retsub = internal_vastai_logsys_corelog_readdrvtoinner_fromtotalbegin(
		pcore, parray_readbyte, &totalbyteindex, i_totalbyteindex, 12);
	if (retsub < 0) {
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	preadbyte = parray_readbyte;
	logu32 = *((u32 *)preadbyte);
	logmode = ((logu32 & 0xF0) >> 4);
	if (logmode == VASTAI_LOGSYS_TYPE_STRING ||
	    logmode == VASTAI_LOGSYS_TYPE_MEMORY) {
		tagandheaderlen = 10;
	} else if (logmode == VASTAI_LOGSYS_TYPE_TRACEID ||
		   logmode == VASTAI_LOGSYS_TYPE_POINT) {
		tagandheaderlen = 8;
	} else {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	/*
	log level part
	*/
	loglevel = ((logu32 & 0xC) >> 2);
	if (loglevel == VASTAI_LOGSYS_LEVEL_ERR) {
		strcpy(leveldscr, "err");
	} else if (loglevel == VASTAI_LOGSYS_LEVEL_WARN) {
		strcpy(leveldscr, "warn");
	} else if (loglevel == VASTAI_LOGSYS_LEVEL_INFO) {
		strcpy(leveldscr, "info");
	} else if (loglevel == VASTAI_LOGSYS_LEVEL_DEBUG) {
		strcpy(leveldscr, "debug");
	}
	//pr_info(VASTAI_LOGSYS_PR_HEAD "logu32 = %lx\n", logu32);
	//pr_info(VASTAI_LOGSYS_PR_HEAD "((logu32 & 0x3)<<8) = %lx\n", ((logu32 & 0x3)<<8));
	//pr_info(VASTAI_LOGSYS_PR_HEAD "((logu32 & 0xFF00)>>8) = %lx\n", ((logu32 & 0xFF00)>>8));
	len = (((logu32 & 0x3) << 8) | ((logu32 & 0xFF00) >> 8));
	if (len == 0) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (logmode == VASTAI_LOGSYS_TYPE_TRACEID) {
		if (len != 4) {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
	}
	if (logmode == VASTAI_LOGSYS_TYPE_POINT) {
		if (len != 8) {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
	}
	totallen = tagandheaderlen + len;
	totallen = ((totallen + 3) / 4) * 4;
	io_preadsession->totalbyteindexnext =
		io_preadsession->totalbyteindexcurr + totallen;
	/*
	Handle the next 2 bytes. The 2 bytes are the high 2 bytes of time stamp. 
	*/
	clockcount = ((logu32 & 0xFF000000) >>
		      8); // the lower byte store the highest byte mask
	clockcount = (clockcount | ((logu32 & 0xFF0000) << 8));
	bytei = 4;
	preadbyte = preadbyte + 4;
	/*
	Set variable according to log header part. 
	1. Time stamp low 2 bytes
	2. Core id
	Check log header part. 
	1. check separator when string and memory type. 
	2. Check core id(if is valid core id)
	3. (Need core id)Check time stamp. 
	*/
	for (chari = 0; bytei + chari < tagandheaderlen; chari++) {
		pchar = (preadbyte + chari);
		if (bytei + chari == 4) {
			clockcount = (clockcount | ((*pchar) << 8));
		} else if (bytei + chari == 5) {
			clockcount = (clockcount | (*pchar));
		}
		if (tagandheaderlen == 10) {
			if (bytei + chari == 6 ||
			    bytei + chari == 9) // should be ":"
			{
				if (*pchar != ':') {
					SIMPLE_KERNEL_LOG;
					VASTAI_LOGSYS_ENV_ERROR_RECORD(
						_penv,
						VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
					return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				}
			}
			if (bytei + chari == 7) {
				coreid = ((*pchar) << 8);
			} else if (bytei + chari == 8) {
				coreid = (coreid | (*pchar));
				ret = internal_getcoredscrbycoreid(coredscr,
								   coreid);
				if (ret > 0) {
					return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				}
				bufferindex = sprintf(
					io_preadsession->buffer,
					"[%u:%s:%s:%s:%u]", clockcount,
					coredscr, leveldscr,
					((logmode == VASTAI_LOGSYS_TYPE_STRING) ?
						 "str" :
						 ((logmode ==
						   VASTAI_LOGSYS_TYPE_MEMORY) ?
							  "mem" :
							  ((logmode ==
							    VASTAI_LOGSYS_TYPE_TRACEID) ?
								   "tra" :
								   "poi"))),
					len);
			}
		} else {
			if (bytei + chari == 6) {
				coreid = ((*pchar) << 8);
			} else if (bytei + chari == 7) {
				coreid = (coreid | (*pchar));
				ret = internal_getcoredscrbycoreid(coredscr,
								   coreid);
				if (ret > 0) {
					return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				}
				bufferindex = sprintf(
					io_preadsession->buffer,
					"[%u:%s:%s:%s:%u]", clockcount,
					coredscr, leveldscr,
					((logmode == VASTAI_LOGSYS_TYPE_STRING) ?
						 "str" :
						 ((logmode ==
						   VASTAI_LOGSYS_TYPE_MEMORY) ?
							  "mem" :
							  ((logmode ==
							    VASTAI_LOGSYS_TYPE_TRACEID) ?
								   "tra" :
								   "poi"))),
					len);
			}
		}
	}

	/*
	After we parse the head, we need to parse the log content.
	We first copy the original log content to the tempbuffer of readsession.
	*/

	retsub = internal_vastai_logsys_corelog_readdrvtoinner_fromtotalbegin(
		pcore, io_preadsession->tempbuffer, &totalbyteindex,
		io_preadsession->totalbyteindexcurr,
		io_preadsession->totalbyteindexnext -
			io_preadsession->totalbyteindexcurr);
	if (retsub < 0) {
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (logmode == VASTAI_LOGSYS_TYPE_STRING) {
		/*
		When string mode, check the end char is '\0'.
		*/
		if (io_preadsession->tempbuffer[tagandheaderlen + len - 1] !=
		    '\0') {
			SIMPLE_KERNEL_LOG;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				_penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
		pwritebyte = &io_preadsession->buffer[bufferindex];
		memcpy(pwritebyte,
		       &io_preadsession->tempbuffer[tagandheaderlen], len);
		io_preadsession->bufferindex = 0;
		io_preadsession->buffersize = bufferindex + len;
		/*
		When string mode and the current user is shellcat, we change the last byte from '\0' to 
		'\n' to make log more readable.
		*/
		io_preadsession->buffer[io_preadsession->buffersize - 1] = '\n';
		io_preadsession->buffer[io_preadsession->buffersize] =
			'\0'; // add '\0' for save
		return 0;
	}
	if (logmode == VASTAI_LOGSYS_TYPE_TRACEID) {
		traceid = 0;
		for (chari = 0; chari < 4; chari++) {
			pchar = &io_preadsession->tempbuffer
					 [tagandheaderlen +
					  chari]; // pchar is unsigned char pointer
			traceid = traceid | ((*pchar) << ((3 - chari) * 8));
			if (chari == 3) {
				pwritebyte =
					&io_preadsession->buffer[bufferindex];
				sprintflen = sprintf(pwritebyte, "%u", traceid);
				io_preadsession->bufferindex = 0;
				io_preadsession->buffersize =
					bufferindex + sprintflen;
			}
		}
		/*
		We add '\n' to the end of the buffer.
		*/
		io_preadsession->buffer[io_preadsession->buffersize] = '\n';
		io_preadsession->buffersize++;
		io_preadsession->buffer[io_preadsession->buffersize] =
			'\0'; // add '\0' for save
		return 0;
	}
	if (logmode == VASTAI_LOGSYS_TYPE_POINT) {
		pointaddr = pointvalue = 0;
		for (chari = 0; chari < 8; chari++) {
			pchar = &io_preadsession->tempbuffer
					 [tagandheaderlen +
					  chari]; // pchar is unsigned char pointer
			if (chari < 4) {
				pointaddr = pointaddr |
					    ((*pchar) << ((3 - chari) * 8));
			} else {
				pointvalue = pointvalue |
					     ((*pchar) << ((7 - chari) * 8));
				if (chari == 7) {
					pwritebyte =
						&io_preadsession
							 ->buffer[bufferindex];
					sprintflen =
						sprintf(pwritebyte, "0x%x[%u]",
							pointaddr, pointvalue);
					io_preadsession->bufferindex = 0;
					io_preadsession->buffersize =
						bufferindex + sprintflen;
				}
			}
		}
		/*
		We add '\n' to the end of the buffer.
		*/
		io_preadsession->buffer[io_preadsession->buffersize] = '\n';
		io_preadsession->buffersize++;
		io_preadsession->buffer[io_preadsession->buffersize] =
			'\0'; // add '\0' for save
		return 0;
	}
	/*
	Run here means mode memory.
	*/
	io_preadsession->bufferindex = 0;
	for (memlogi = 0; memlogi < len; memlogi++) {
		if (memlogi % 16 == 0) {
			if (memlogi == 0) {
				pwritebyte =
					&io_preadsession->buffer[bufferindex];
				sprintflen = sprintf(pwritebyte, "\n");
				io_preadsession->buffersize =
					io_preadsession->buffersize +
					sprintflen;
				bufferindex = bufferindex + sprintflen;
			}
			if (memlogi + 16 <= len) {
				pwritebyte =
					&io_preadsession->buffer[bufferindex];
				sprintflen = sprintf(pwritebyte, "0x%x-0x%x\t",
						     memlogi, memlogi + 16);
				io_preadsession->buffersize =
					io_preadsession->buffersize +
					sprintflen;
				bufferindex = bufferindex + sprintflen;
			} else {
				pwritebyte =
					&io_preadsession->buffer[bufferindex];
				sprintflen = sprintf(pwritebyte, "0x%x-0x%x\t",
						     memlogi, len);
				io_preadsession->buffersize =
					io_preadsession->buffersize +
					sprintflen;
				bufferindex = bufferindex + sprintflen;
			}
		} else if (memlogi % 4 == 0) {
			pwritebyte = &io_preadsession->buffer[bufferindex];
			sprintflen = sprintf(pwritebyte, "\t");
			io_preadsession->buffersize =
				io_preadsession->buffersize + sprintflen;
			bufferindex = bufferindex + sprintflen;
		}
		pwritebyte = &io_preadsession->buffer[bufferindex];
		sprintflen = sprintf(
			pwritebyte, "%x",
			io_preadsession->tempbuffer[tagandheaderlen + memlogi]);
		io_preadsession->buffersize =
			io_preadsession->buffersize + sprintflen;
		bufferindex = bufferindex + sprintflen;
		if (memlogi % 16 == 15 || memlogi == len - 1) {
			pwritebyte = &io_preadsession->buffer[bufferindex];
			sprintflen = sprintf(pwritebyte, "\n");
			io_preadsession->buffersize =
				io_preadsession->buffersize + sprintflen;
			bufferindex = bufferindex + sprintflen;
		}
	}
	/*
	We already add '\n' to the end of the buffer. So do not add it here.
	Add '\0' for save.
	*/
	io_preadsession->buffer[io_preadsession->buffersize] =
		'\0'; // add '\0' for save
	return 0;
}

u32 internal_vastai_logsys_user_readsession_clearcurrtonext(
	struct vastai_logsys_user_readsession *io_preadsession,
	struct vastai_logsys_pci_die_pcore_node *i_pcorenode)
{
	struct vastai_logsys_pci_die_core_env *pcore = i_pcorenode->pcore;
	loff_t clearsize = 0;
	u32 ret = 0;

	if (io_preadsession->totalbyteindexcurr != pcore->clearbytesum) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	if (io_preadsession->totalbyteindexnext ==
	    io_preadsession->totalbyteindexcurr) {
		return 0;
	}
	clearsize = io_preadsession->totalbyteindexnext -
		    io_preadsession->totalbyteindexcurr;
	/*
	Decide whether the log to clear is in the file or buffer.
	*/
	if (pcore->currbytefile == 0) {
		/*
		The current log is in the buffer.
		*/
		if (pcore->rpoffset + clearsize < VASTAI_LOGSYS_BUF_SIZE) {
			pcore->rpoffset = pcore->rpoffset + clearsize;
		} else {
			pcore->rpoffset = pcore->rpoffset + clearsize -
					  VASTAI_LOGSYS_BUF_SIZE;
		}
		pcore->currbytelogbuffer = pcore->currbytelogbuffer - clearsize;
	} else {
		ret = internal_vastai_logsys_filelist_clear(&pcore->filelist,
							    clearsize);
		if (ret > 0) {
			return ret;
		}
		pcore->currbytefile = pcore->currbytefile - clearsize;
	}
	pcore->clearbytesum = pcore->clearbytesum + clearsize;
	pcore->currbytesum = pcore->currbytesum - clearsize;
	return 0;
}

u32 internal_vastai_logsys_user_readsession_init_bycorenode(
	struct vastai_logsys_user_readsession *io_preadsession,
	u32 *o_preachend, struct vastai_logsys_pci_die_pcore_node *i_pcorenode,
	u32 i_callertype, loff_t i_beginoffset)
{
	u32 ret = 0;
	struct vastai_logsys_pci_die_pcore_node *pcorenode = i_pcorenode;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	loff_t totalbyteindex = 0;
	SIMPLE_DEBUG_LOG;
	if (pcorenode == NULL) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	SIMPLE_DEBUG_LOG;
	while (1) {
		pcore = pcorenode->pcore;
		SIMPLE_DEBUG_LOG;
		mutex_lock(&pcore->mutex_core);
		SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD "i_beginoffset = %ld\n",
			i_beginoffset);
		pr_info(VASTAI_LOGSYS_PR_HEAD "pcore->currbytesum = %ld\n",
			pcore->currbytesum);
		pr_info(VASTAI_LOGSYS_PR_HEAD "pcore->clearbytesum = %ld\n",
			pcore->clearbytesum);
#endif
		ret = internal_vastai_logsys_corelog_findnearestpos_fromtotalbeginandoffset(
			pcore, &totalbyteindex, i_beginoffset);
		SIMPLE_DEBUG_LOG;
		if (ret > 0) {
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&pcore->mutex_core);
			SIMPLE_DEBUG_LOG;
			return ret;
		}

		/*
		When run here, we already find the start point which is totalbyteindex.
		We set the bufferindex to 0, whatever the caller is C or shellcat.
		*/
		io_preadsession->bufferindex = 0;
		io_preadsession->totalbyteindexend = pcore->totalbytesum;
		SIMPLE_DEBUG_LOG;
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"core[%d] io_pcore->totalbytesum = %ld\n",
			pcore->core_index, pcore->totalbytesum);
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"io_preadsession->totalbyteindexend = %ld, totalbyteindex = %ld\n",
			io_preadsession->totalbyteindexend, totalbyteindex);
#endif

		/*
		The function will set pcorenode of preadsession.
		*/
		ret = internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
			io_preadsession, pcorenode, i_callertype,
			totalbyteindex);
		SIMPLE_DEBUG_LOG;
		if (ret > 0) {
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&pcore->mutex_core);
			SIMPLE_DEBUG_LOG;
			return ret;
		}
		SIMPLE_DEBUG_LOG;
		/*
		Check whether the core have data to read.
		*/
		if (io_preadsession->totalbyteindexcurr ==
		    io_preadsession->totalbyteindexend) {
			SIMPLE_DEBUG_LOG;
			if (pcorenode->pnext == NULL) {
				SIMPLE_DEBUG_LOG;
				/*
				Have no data to read. Need to find the following core.
				When there is no following core, *o_preachend output 1 
				and let the read point remain the last pcorenode and the 
				point is the end of the last pcorenode and unlock the 
				core mutex.
				*/
				*o_preachend = 1;
				SIMPLE_DEBUG_LOG;
				mutex_unlock(&pcore->mutex_core);
				return 0;
			}
			mutex_unlock(&pcore->mutex_core);
			SIMPLE_DEBUG_LOG;
			pcorenode = pcorenode->pnext;
			continue;
		}
		/*
		Have data to read. Remain core mutex lock status.
		*/
		*o_preachend = 0;
		SIMPLE_DEBUG_LOG;
		return 0;
	}
}

u32 internal_vastai_logsys_user_readsession_update_finddatatoread(
	struct vastai_logsys_user_readsession *io_preadsession,
	u32 *o_preachend, u32 i_callertype, loff_t i_beginoffset)
{
	u32 ret = 0;
	struct vastai_logsys_pci_die_pcore_node *pcorenode =
		io_preadsession->pcorenode;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	loff_t totalbyteindex = 0;
	SIMPLE_DEBUG_LOG;
	if (pcorenode == NULL) {
		SIMPLE_KERNEL_LOG;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			_penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		SIMPLE_DEBUG_LOG;
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}

	/*
	First, check whether the current status is have data to read.
	*/
	if (io_preadsession->totalbyteindexcurr !=
	    io_preadsession->totalbyteindexend) {
		SIMPLE_DEBUG_LOG;
		/*
		Though the current index is not end index, but it still may have no log to read.
		But we do not check it here, because we need to update the totalbyteindexcurr when 
		the current data is over. So when we call the function, we do not need to check.
		*/
		*o_preachend = 0;
		pcore = pcorenode->pcore;
		SIMPLE_DEBUG_LOG;
		mutex_lock(&pcore->mutex_core);
		return 0;
	} else {
		SIMPLE_DEBUG_LOG;
		if (pcorenode->pnext == NULL) {
			SIMPLE_DEBUG_LOG;
			*o_preachend = 1;
			return 0;
		}
		pcorenode = pcorenode->pnext;
	}

	while (1) {
		SIMPLE_DEBUG_LOG;
		pcore = pcorenode->pcore;
		mutex_lock(&pcore->mutex_core);
		ret = internal_vastai_logsys_corelog_findnearestpos_fromtotalbeginandoffset(
			pcore, &totalbyteindex, i_beginoffset);
		SIMPLE_DEBUG_LOG;
		if (ret > 0) {
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&pcore->mutex_core);
			return ret;
		}

		/*
		When run here, we already find the start point which is totalbyteindex.
		We set the bufferindex to 0, whatever the caller is C or shellcat.
		*/
		io_preadsession->bufferindex = 0;
		SIMPLE_DEBUG_LOG;
		io_preadsession->totalbyteindexend = pcore->totalbytesum;

		/*
		The function will set pcorenode of preadsession.
		*/
		ret = internal_vastai_logsys_user_readsession_update_bytotalbyteindex(
			io_preadsession, pcorenode, i_callertype,
			totalbyteindex);
		if (ret > 0) {
			SIMPLE_DEBUG_LOG;
			mutex_unlock(&pcore->mutex_core);
			return ret;
		}

		/*
		Check whether the core have data to read.
		*/
		if (io_preadsession->totalbyteindexcurr ==
		    io_preadsession->totalbyteindexend) {
			SIMPLE_DEBUG_LOG;
			if (pcorenode->pnext == NULL) {
				SIMPLE_DEBUG_LOG;
				/*
				Have no data to read. Need to find the following core.
				When there is no following core, *o_preachend output 1 
				and let the read point remain the last pcorenode and the 
				point is the end of the last pcorenode and unlock the 
				core mutex.
				*/
				*o_preachend = 1;
				mutex_unlock(&pcore->mutex_core);
				return 0;
			}
			mutex_unlock(&pcore->mutex_core);
			SIMPLE_DEBUG_LOG;
			pcorenode = pcorenode->pnext;
			continue;
		}
		SIMPLE_DEBUG_LOG;
		/*
		Have data to read. Remain core mutex lock status.
		*/
		*o_preachend = 0;
		return 0;
	}
}

struct vastai_logsys_pci_env *
internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
	struct vastai_logsys_env *i_penv, u32 i_pci_dev_id)
{
	struct vastai_logsys_pci_env *ppci = NULL;
	ppci = i_penv->ppci_head;
	while (ppci) {
		if (ppci->pci_dev_id == i_pci_dev_id) {
			break;
		}
		ppci = ppci->pnext;
	}
	return ppci;
}

struct vastai_logsys_pci_env *
internal_vastai_logsys_get_pci_by_pcidevid_withlock(
	struct vastai_logsys_env *i_penv, u32 i_pci_dev_id)
{
	struct vastai_logsys_pci_env *ppci = NULL;
	mutex_lock(&i_penv->mutex_pci_list);
	ppci = i_penv->ppci_head;
	while (ppci) {
		if (ppci->pci_dev_id == i_pci_dev_id) {
			break;
		}
		ppci = ppci->pnext;
	}
	mutex_unlock(&i_penv->mutex_pci_list);
	return ppci;
}

u32 internal_vastai_logsys_drvinner_oper_set_and_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, u32 i_drvinner_oper,
	const char *i_pfunc, u32 i_linenum)
{
	u32 ret = VASTAI_LOGSYS_USER_ERROR_NOERROR;
	u32 bneedwait = 0;
	DECLARE_WAITQUEUE(wait, current);
	mutex_lock(&io_puser->mutex_user);
	if (io_puser->userdrvoper ==
	    VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE) {
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE;
		io_puser->errorindex = ret;
		strcpy(io_puser->errordetails.function, i_pfunc);
		io_puser->errordetails.linenumber = i_linenum;
		if (io_puser->bunbindfinished == 1) {
			bneedwait = 0;
		} else {
			bneedwait = 1;
		}
		mutex_unlock(&io_puser->mutex_user);
		while (bneedwait == 1) {
			add_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_UNINTERRUPTIBLE);
			wait_event_timeout(io_puser->wq_breakblock,
					   (io_puser->bbreakblock == 1),
					   HZ / 10);
			io_puser->bbreakblock = 0;
			remove_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_RUNNING);
			mutex_lock(&io_puser->mutex_user);
			if (io_puser->bunbindfinished == 1) {
				bneedwait = 0;
			} else {
				bneedwait = 1;
			}
			mutex_unlock(&io_puser->mutex_user);
		}
		return ret;
	}
	if (io_puser->userdrvoper == VASTAI_LOGSYS_DRVINNER_OPER_NOOPER) {
		ret = VASTAI_LOGSYS_USER_ERROR_NOERROR;
		io_puser->userdrvoper = i_drvinner_oper;
		/*
		When return no error, remain lock status.
		*/
		return ret;
	}
	/*
	When the current operation is not no oper, it is not allowed.
	*/
	ret = VASTAI_LOGSYS_USER_ERROR_TWOOPER_ATONETIME;
	io_puser->errorindex = ret;
	strcpy(io_puser->errordetails.function, i_pfunc);
	io_puser->errordetails.linenumber = i_linenum;
	mutex_unlock(&io_puser->mutex_user);
	return ret;
}

u32 internal_vastai_logsys_drvinner_oper_setinfoorlog_and_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, u32 i_drvinner_oper,
	const char *i_pfunc, u32 i_linenum)
{
	u32 ret = VASTAI_LOGSYS_USER_ERROR_NOERROR;
	u32 bneedwait = 0;
	DECLARE_WAITQUEUE(wait, current);
	mutex_lock(&io_puser->mutex_user);
	if (io_puser->userdrvoper ==
	    VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE) {
		if (io_puser->errorindex ==
		    VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE) {
			/*
			When the user's error index already is pcie remove, means the user
			already know the event, when the user do set info or set log operation, 
			it is allowed.
			*/
			if (i_drvinner_oper !=
			    VASTAI_LOGSYS_DRVINNER_OPER_WRITE) {
				ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
				mutex_unlock(&io_puser->mutex_user);
				VASTAI_LOGSYS_ENV_ERROR_RECORD(
					io_puser->penv,
					VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
				return ret;
			}
			io_puser->userdrvoper = i_drvinner_oper;
			io_puser->errorindex = ret;
			mutex_unlock(&io_puser->mutex_user);
			return ret;
		} else {
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE;
			io_puser->errorindex = ret;
		}
		strcpy(io_puser->errordetails.function, i_pfunc);
		io_puser->errordetails.linenumber = i_linenum;
		if (io_puser->bunbindfinished == 1) {
			bneedwait = 0;
		} else {
			bneedwait = 1;
		}
		mutex_unlock(&io_puser->mutex_user);
		while (bneedwait == 1) {
			add_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_UNINTERRUPTIBLE);
			wait_event_timeout(io_puser->wq_breakblock,
					   (io_puser->bbreakblock == 1),
					   HZ / 10);
			io_puser->bbreakblock = 0;
			remove_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_RUNNING);
			mutex_lock(&io_puser->mutex_user);
			if (io_puser->bunbindfinished == 1) {
				bneedwait = 0;
			} else {
				bneedwait = 1;
			}
			mutex_unlock(&io_puser->mutex_user);
		}

		return ret;
	}
	if (io_puser->userdrvoper == VASTAI_LOGSYS_DRVINNER_OPER_NOOPER) {
		ret = VASTAI_LOGSYS_USER_ERROR_NOERROR;
		io_puser->userdrvoper = i_drvinner_oper;
		/*
		When return no error, remain lock status.
		*/
		return ret;
	}
	ret = VASTAI_LOGSYS_USER_ERROR_TWOOPER_ATONETIME;
	io_puser->errorindex = ret;
	strcpy(io_puser->errordetails.function, i_pfunc);
	io_puser->errordetails.linenumber = i_linenum;
	mutex_unlock(&io_puser->mutex_user);
	return ret;
}

u32 internal_vastai_logsys_user_lock_returnerrorindex(
	struct vastai_logsys_user *io_puser, const char *i_pfunc, u32 i_linenum)
{
	u32 bneedwait = 0;
	DECLARE_WAITQUEUE(wait, current);
	mutex_lock(&io_puser->mutex_user);
	if (io_puser->userdrvoper ==
	    VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE) {
		io_puser->errorindex =
			VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE;
		strcpy(io_puser->errordetails.function, i_pfunc);
		io_puser->errordetails.linenumber = i_linenum;
		if (io_puser->bunbindfinished == 1) {
			bneedwait = 0;
		} else {
			bneedwait = 1;
		}
		mutex_unlock(&io_puser->mutex_user);
		while (bneedwait == 1) {
			add_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_UNINTERRUPTIBLE);
			wait_event_timeout(io_puser->wq_breakblock,
					   (io_puser->bbreakblock == 1),
					   HZ / 10);
			io_puser->bbreakblock = 0;
			remove_wait_queue(&io_puser->wq_breakblock, &wait);
			set_current_state(TASK_RUNNING);
			mutex_lock(&io_puser->mutex_user);
			if (io_puser->bunbindfinished == 1) {
				bneedwait = 0;
			} else {
				bneedwait = 1;
			}
			mutex_unlock(&io_puser->mutex_user);
		}
		return VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE;
	}
	return VASTAI_LOGSYS_USER_ERROR_NOERROR;
}

void internal_vastai_logsys_user_set_nooper(struct vastai_logsys_user *io_puser)
{
	io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;
}

void internal_vastai_logsys_user_set_nooper_and_unlockuser(
	struct vastai_logsys_user *io_puser)
{
	io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;
	mutex_unlock(&io_puser->mutex_user);
}

void internal_vastai_logsys_user_set_nooper_except_norecoverableerror(
	struct vastai_logsys_user *io_puser, u32 i_errorcode)
{
	if (i_errorcode == 0 ||
	    (i_errorcode >= VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN &&
	     i_errorcode <= VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAX)) {
		io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;
	}
}

void internal_vastai_logsys_user_set_nooper_except_norecoverableerror_and_unlockuser(
	struct vastai_logsys_user *io_puser, u32 i_errorcode)
{
	if (i_errorcode == 0 ||
	    (i_errorcode >= VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN &&
	     i_errorcode <= VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAX)) {
		io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_NOOPER;
	}
	mutex_unlock(&io_puser->mutex_user);
}

void internal_vastai_logsys_unbind_allcore_oftheuser_bybgthread(
	struct vastai_logsys_user *io_puser)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	u32 useri = 0;

	/*
	First, tag the userdrvoper to the unbind tag. So that the user will wait the signal and 
	check the pcore_head is NULL to know the current user finish the unbind operation.
	*/
	mutex_lock(&io_puser->mutex_user);
	if (io_puser->userdrvoper ==
	    VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE) {
		/*
		When there is one pci remove operation is in operation of the current user, we do not 
		need to do it again because the previous operation will unbind all pci of the user.
		*/
		mutex_unlock(&io_puser->mutex_user);
		return;
	}
	io_puser->userdrvoper = VASTAI_LOGSYS_DRVINNER_OPER_UNBIND_BYPCIREMOVE;
	io_puser->bunbindfinished = 0;
	/*
	When the caller is shellcat and unbind yet, the pcore_head should be still NULL, so we 
	only judge by pcore_head.
	*/
	if (io_puser->pcore_head == NULL) {
		mutex_unlock(&io_puser->mutex_user);
		return;
	}

	/*
	Get the next pcorenode to handle.
	Need to lock before goto the label.
	*/
	//handlenextpcorenode:
	pcorenode = io_puser->pcore_head;
	pcore = pcorenode->pcore;
	mutex_unlock(&io_puser->mutex_user);
	/*
	Delete the puser of user list of the core.
	*/
	mutex_lock(&pcore->mutex_core);
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		if (pcore->parray_puser[useri] == io_puser) {
			pcore->parray_puser[useri] = NULL;
			pcore->parray_puserbblock[useri] = 0;
			break;
		}
	}
	mutex_unlock(&pcore->mutex_core);
	/*
	After delete the puser of user list of the core, delete the pcorenode and get the 
	next pcorenode and pcore to handle.
	*/
	mutex_lock(&io_puser->mutex_user);
	io_puser->pcore_head = io_puser->pcore_head->pnext;
	if (io_puser->pcore_head == NULL) {
		io_puser->pcore_tail = NULL;
		/*
		Handle over.
		*/
		kfree(pcorenode);
		goto handleover;
	} else {
		io_puser->pcore_head->ppre = NULL;
		kfree(pcorenode);
	}
handleover:
	/*
	Delete the log entry info.
	*/
	internal_vastai_logsys_user_bindinfo_deinit(&io_puser->bindinfo);
	internal_vastai_logsys_user_readsession_reset_tonull(
		&io_puser->readsession);
	/*
	Signal the unbind operation is over.
	*/
	io_puser->bunbindfinished = 1;
	io_puser->bbreakblock = 1;
	wake_up(&io_puser->wq_breakblock);
	mutex_unlock(&io_puser->mutex_user);
}

u32 internal_vastai_logsys_unbind_allcore_oftheuser_byuserthread(
	struct vastai_logsys_user *io_puser, u32 i_breleasedef)
{
	int retmacroint = 0;
	struct vastai_logsys_pci_die_pcore_node *pcorenode = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	//struct vastai_logsys_user_mode_log *plog;
	u32 ret = 0;
	u32 useri = 0;

	/*
	Reset the current info and log mode status back to init.
	*/
	CHECKRETPOSITIVE_VASTAI_LOGSYS_USER_LOCK(io_puser);
	io_puser->infobuffertotalsize = io_puser->infobuffercurrindex = 0;
	internal_vastai_logsys_user_readsession_reset_tonull(
		&io_puser->readsession);
	io_puser->beginoffsetdef = 0;
	/*
	Delete the user bind info entry.
	*/
	internal_vastai_logsys_user_bindinfo_deinit(&io_puser->bindinfo);
	if (i_breleasedef == 1) {
		if (io_puser->callertype == VASTAI_LOGSYS_CALLER_SHELLCAT) {
			/*
			When the current caller is shell, delete the default log bind entry.
			*/
			mutex_lock(&io_puser->penv->mutex_bindinfodef);
			internal_vastai_logsys_user_bindinfo_deinit(
				&io_puser->penv->bindinfodef);
			io_puser->penv->beginoffsetdef = 0;
			mutex_unlock(&io_puser->penv->mutex_bindinfodef);
		}
	}
	mutex_unlock(&io_puser->mutex_user);

handlenextpcorenode:
	/*
	When not error, will enter mutex. And the current status is not unbind by 
	pci remove.
	*/
	CHECKRETPOSITIVE_VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (io_puser->pcore_head == NULL) {
		goto ret_label;
	}
	/*
	Get the pcore pointer and do pcore unbind user operation.
	*/
	pcorenode = io_puser->pcore_head;
	pcore = pcorenode->pcore;
	mutex_lock(&pcore->mutex_core);
	/*
	Find the user pointer from the user list in the core and unbind it.
	*/
	if (pcore->puser_clearbuffer == io_puser) {
		pcore->puser_clearbuffer = NULL;
		pcore->bblock_clearbuffer = 0;
	} else {
		for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX;
		     useri++) {
			if (pcore->parray_puser[useri] == io_puser) {
				pcore->parray_puser[useri] = NULL;
				pcore->bblock_clearbuffer = 0;
				break;
			}
		}
	}
	mutex_unlock(&pcore->mutex_core);
	if (pcorenode->pnext == NULL) {
		kfree(pcorenode);
		io_puser->pcore_head = io_puser->pcore_tail = NULL;
		goto ret_label;
	} else {
		io_puser->pcore_head = pcorenode->pnext;
		io_puser->pcore_head->ppre = NULL;
		kfree(pcorenode);
		mutex_unlock(&io_puser->mutex_user);
		goto handlenextpcorenode;
	}

ret_label:

	/*
	Delete the log entry info.
	*/
	internal_vastai_logsys_user_bindinfo_deinit(&io_puser->bindinfo);
	mutex_unlock(&io_puser->mutex_user);
	return ret;
}

u32 internal_vastai_logsys_bind_log_byuserthread(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_user_mode_log *i_plog)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	u32 ret = 0;
	u32 retsub = 0;
	u32 useri = 0;
	u32 corei = 0;
	u32 firstcorei = 0; // of i_plog
	u32 othercorei = 0; // of i_plog
	u32 corelasti = 0; // of i_plog record the last bind
	u32 bclearbuffer = 0;

	if (i_plog->pci_dev_id == -1) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLPCI_NOTALLOW;
	}
	if (i_plog->die_index == -1) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLDIE_NOTALLOW;
	}
#if 1 // for log only
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
#if (DEBUG_LOG == 1)
		pr_info(VASTAI_LOGSYS_PR_HEAD
			"Line[%d] i_plog->parray_bcore[%d]=%d\n",
			__LINE__, corei, i_plog->parray_bcore[corei]);
#endif
	}
#endif
	/*
	Get the first core index.
	*/
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		if (i_plog->parray_bcore[corei] == 1) {
			break;
		}
	}
	firstcorei = corei;
	if (firstcorei >= VASTAI_LOGSYS_CORECOUNT) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_NOCORE_TOBIND;
	}

	/*
When add/check exist the first core, then the correspondent pci pointer 
will not be invalid except the puser is pci remove status.
*/
	//addfirstcore:
	/*
	Do the add operation of the puser to specific pcore of the input 
	description.
	*/
	SIMPLE_DEBUG_LOG;
	mutex_lock(&io_puser->penv->mutex_pci_list);
	SIMPLE_DEBUG_LOG;
	ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
		io_puser->penv, i_plog->pci_dev_id);
	SIMPLE_DEBUG_LOG;
	if (ppci == NULL) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND;
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	if (i_plog->die_index >= ppci->die_count) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG;
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	pdie = &ppci->parray_die_env[i_plog->die_index];
	pcore = &pdie->parray_core_env[firstcorei];
	SIMPLE_DEBUG_LOG;
	ret = VASTAI_LOGSYS_USER_LOCK(io_puser);
	SIMPLE_DEBUG_LOG;
	if (ret > 0) {
		SIMPLE_DEBUG_LOG;
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		SIMPLE_DEBUG_LOG;
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	mutex_lock(&pcore->mutex_core);
	SIMPLE_DEBUG_LOG;
	/*
	Check whether the core has no space to bind the user.
	*/
	bclearbuffer = i_plog->bclearbuffer;
	SIMPLE_DEBUG_LOG;
	if (i_plog->bclearbuffer == 1) {
		SIMPLE_DEBUG_LOG;
		if (pcore->puser_clearbuffer != NULL) {
			SIMPLE_DEBUG_LOG;
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_CLEARBUFFER_EXIST;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			mutex_unlock(&io_puser->penv->mutex_pci_list);
			return ret;
		}
		SIMPLE_DEBUG_LOG;
		pcore->puser_clearbuffer = io_puser;
		pcore->bblock_clearbuffer = i_plog->bblock;
		SIMPLE_DEBUG_LOG;
		goto firstcoreleavemutex;
	}
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		SIMPLE_DEBUG_LOG;
		if (pcore->parray_puser[useri] == NULL) {
			SIMPLE_DEBUG_LOG;
			break;
		}
	}
	SIMPLE_DEBUG_LOG;
	if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
		SIMPLE_DEBUG_LOG;
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_BLOCKUSER_REACHMAX;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	pcore->parray_puser[useri] = io_puser;
	pcore->parray_puserbblock[useri] = i_plog->bblock;
	SIMPLE_DEBUG_LOG;
firstcoreleavemutex:
	corelasti = firstcorei;
	SIMPLE_DEBUG_LOG;
	retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(io_puser,
								  pcore);
	SIMPLE_DEBUG_LOG;
	if (retsub > 0) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);
	mutex_unlock(&io_puser->penv->mutex_pci_list);
	SIMPLE_DEBUG_LOG;

	/*
	When handle not the first pcore, we do not need to enter pci mutex.
	Because the pci pointer will be valid until all of the pcore bind 
	user is invalid. We only need to check whether the user status is 
	remove by pci.
	*/
	othercorei = firstcorei;
	SIMPLE_DEBUG_LOG;
handleotherinputpcore:
	for (corei = othercorei + 1; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		if (i_plog->parray_bcore[corei] == 1) {
			break;
		}
	}
	othercorei = corei;
	if (othercorei >= VASTAI_LOGSYS_CORECOUNT) {
		/*
		Iterate over, bind all core of i_plog. Succeed!
		*/
		return ret;
	}
	SIMPLE_DEBUG_LOG;
	ret = VASTAI_LOGSYS_USER_LOCK(io_puser);
	SIMPLE_DEBUG_LOG;
	if (ret > 0) {
		/*
		The only circumstance is that the bg thread is release the 
		user by pci remove. So we do not need to goto unbindprevious. 
		*/
		return ret;
	}
	pcore = &pdie->parray_core_env[othercorei];
	SIMPLE_DEBUG_LOG;
	mutex_lock(&pcore->mutex_core);
	SIMPLE_DEBUG_LOG;
	if (i_plog->bclearbuffer == 1) {
		SIMPLE_DEBUG_LOG;
		if (pcore->puser_clearbuffer != NULL) {
			SIMPLE_DEBUG_LOG;
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_CLEARBUFFER_EXIST;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			SIMPLE_DEBUG_LOG;
			goto unbindprevious;
		}
		SIMPLE_DEBUG_LOG;
		pcore->puser_clearbuffer = io_puser;
		pcore->bblock_clearbuffer = i_plog->bblock;
		SIMPLE_DEBUG_LOG;
		retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(
			io_puser, pcore);
		SIMPLE_DEBUG_LOG;
		if (retsub > 0) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				io_puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return ret;
		}
		SIMPLE_DEBUG_LOG;
		goto othercoreleavemutex;
	}
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		SIMPLE_DEBUG_LOG;
		if (pcore->parray_puser[useri] == NULL) {
			SIMPLE_DEBUG_LOG;
			break;
		}
	}
	if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_BLOCKUSER_REACHMAX;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		goto unbindprevious;
	}
	SIMPLE_DEBUG_LOG;
	pcore->parray_puser[useri] = io_puser;
	pcore->parray_puserbblock[useri] = i_plog->bblock;
	SIMPLE_DEBUG_LOG;
	retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(io_puser,
								  pcore);
	SIMPLE_DEBUG_LOG;
	if (retsub > 0) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	SIMPLE_DEBUG_LOG;
othercoreleavemutex:
	corelasti = othercorei;
	SIMPLE_DEBUG_LOG;
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);
	SIMPLE_DEBUG_LOG;
	goto handleotherinputpcore;

	/*
	When occur error, unbind all of the previous bind.
	From firstcorei to corelasti
	*/
unbindprevious:
	SIMPLE_DEBUG_LOG;
	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	SIMPLE_DEBUG_LOG;
	if (retsub > 0) {
		return retsub;
	}
	pcorenode = io_puser->pcore_head;
	if (pcorenode == NULL) {
		mutex_unlock(&io_puser->mutex_user);
		return ret;
	}
	pcore = pcorenode->pcore;
	mutex_lock(&pcore->mutex_core);
	if (bclearbuffer == 1) {
		if (pcore->puser_clearbuffer == io_puser) {
			pcore->puser_clearbuffer = NULL;
			pcore->bblock_clearbuffer = 0;
		} else {
			SIMPLE_KERNEL_LOG;
		}
	} else {
		for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX;
		     useri++) {
			if (pcore->parray_puser[useri] == io_puser) {
				break;
			}
		}
		if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
			SIMPLE_KERNEL_LOG;
		} else {
			pcore->parray_puser[useri] = NULL;
			pcore->parray_puserbblock[useri] = 0;
		}
	}
	/*
	Change the head to the next one, and delete the instance.
	*/
	io_puser->pcore_head = io_puser->pcore_head->pnext;
	if (io_puser->pcore_head == NULL) {
		io_puser->pcore_tail = NULL;
	} else {
		io_puser->pcore_head->ppre = NULL;
	}
	kfree(pcorenode);
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);
	goto unbindprevious;
}

u32 internal_vastai_logsys_bind_logadd_byuserthread(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_user_mode_log *i_plog)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode = NULL;
	/*
	Record the previous tail pcore node down, when occur error, we will only unbind 
	the current log add operation.
	*/
	struct vastai_logsys_pci_die_pcore_node *pcorenodeprevioustail = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	u32 ret = 0;
	u32 retsub = 0;
	u32 bclearbuffer = 0;
	u32 bblock = 0;
	u32 corei = 0; // of i_plog
	u32 corelasti = 0; // of i_plog record the last bind
	u32 useri = 0;

	if (i_plog->pci_dev_id == -1) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLPCI_NOTALLOW;
	}
	if (i_plog->die_index == -1) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_FORMAT_LOGALLDIE_NOTALLOW;
	}
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		if (i_plog->parray_bcore[corei] == 1) {
			break;
		}
	}
	if (corei >= VASTAI_LOGSYS_CORECOUNT) {
		return VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_NOCORE_TOBIND;
	}

	/*
	First check whether have old log entry, if not output error.
	*/
	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (retsub > 0) {
		return retsub;
	}
	if (io_puser->pcore_head == NULL) {
		SIMPLE_KERNEL_LOG;
		mutex_unlock(&io_puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	bclearbuffer = io_puser->bindinfo.puser_mode_log_head->bclearbuffer;
	bblock = io_puser->bindinfo.puser_mode_log_head->bblock;
	if (i_plog->bclearbuffer != bclearbuffer) {
		SIMPLE_KERNEL_LOG;
		mutex_unlock(&io_puser->mutex_user);
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BCLEARBUFFER_NOTMATCH_PREVIOUS;
		return ret;
	}
	if (i_plog->bblock != bblock) {
		SIMPLE_KERNEL_LOG;
		mutex_unlock(&io_puser->mutex_user);
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_LOGADD_BBLOCK_NOTMATCH_PREVIOUS;
		return ret;
	}
	mutex_unlock(&io_puser->mutex_user);
	/*
	Get the pci pointer and bind the first core of the log entry.
	*/
	mutex_lock(&io_puser->penv->mutex_pci_list);
	ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
		io_puser->penv, i_plog->pci_dev_id);
	if (ppci == NULL) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_PCINOTFIND;
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	}
	if (i_plog->die_index >= ppci->die_count) {
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_DIEINDEX_TOOBIG;
		return ret;
	}
	pdie = &ppci->parray_die_env[i_plog->die_index];
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		if (i_plog->parray_bcore[corei] == 1) {
			break;
		}
	}
	corelasti = corei;
	if (corelasti >= VASTAI_LOGSYS_CORECOUNT) {
		/*
		Do not find any core to bind.
		*/
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_NOCORE_TOBIND;
		return ret;
	}
	pcore = &pdie->parray_core_env[corelasti];
	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (retsub > 0) {
		return retsub;
	}
	/*
	Before add new log pcore node to the tail, we record the previous tail.
	*/
	pcorenodeprevioustail =
		io_puser->pcore_tail; // we already check, the value will not be NULL
	mutex_lock(&pcore->mutex_core);
	if (bclearbuffer == 1) {
		if (pcore->puser_clearbuffer != NULL) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_CLEARBUFFER_EXIST;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			/*
			It is the first bind, so do not need to unbind previous.
			*/
			return ret;
		}
		pcore->puser_clearbuffer = io_puser;
		pcore->bblock_clearbuffer = bblock;
		retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(
			io_puser, pcore);
		if (retsub > 0) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				io_puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return ret;
		}
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		goto bindnextcore;
	}
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		if (pcore->parray_puser[useri] == NULL) {
			break;
		}
	}
	if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_BLOCKUSER_REACHMAX;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		return ret;
	}
	retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(io_puser,
								  pcore);
	if (retsub > 0) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);

bindnextcore:
	for (corei = corelasti + 1; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		if (i_plog->parray_bcore[corei] == 1) {
			break;
		}
	}
	corelasti = corei;
	if (corelasti >= VASTAI_LOGSYS_CORECOUNT) {
		/*
		Finish all bind log.
		*/
		if (ret != 0) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				io_puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return ret;
		}
		return ret;
	}
	pcore = &pdie->parray_core_env[corelasti];
	/*
	When run here, the user is already added into the pci list, so we do 
	not need to add mutex to use the pci pointer.
	*/
	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (retsub > 0) {
		return retsub;
	}
	mutex_lock(&pcore->mutex_core);
	if (bclearbuffer == 1) {
		if (pcore->puser_clearbuffer != NULL) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_CLEARBUFFER_EXIST;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			goto unbindcurrprevious;
		}
		pcore->puser_clearbuffer = io_puser;
		pcore->bblock_clearbuffer = bblock;
		retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(
			io_puser, pcore);
		if (retsub > 0) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			VASTAI_LOGSYS_ENV_ERROR_RECORD(
				io_puser->penv,
				VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
			return ret;
		}
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		goto bindnextcore;
	}
	for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX; useri++) {
		if (pcore->parray_puser[useri] == NULL) {
			break;
		}
	}
	if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_USER_ERROR_LOG_WRITE_OPER_CORE_BLOCKUSER_REACHMAX;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		goto unbindcurrprevious;
	}
	retsub = internal_vastai_logsys_addcore_tocorenode_ofuser(io_puser,
								  pcore);
	if (retsub > 0) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);
	goto bindnextcore;

	/*
	The current strategy is that we only unbind all previous log bind of the current 
	operation, it will not unbind all of the log.
	*/
unbindcurrprevious:
	/*
	Iterate every core of the user core node list.
	Unbind from the end log pointer to next to pcorenodeprevioustail.
	Unbind one and immediately delete the node within one mutex pair.
	*/
	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (retsub > 0) {
		return retsub;
	}
	pcorenode = io_puser->pcore_tail;
	if (pcorenode == pcorenodeprevioustail) {
		/*
		Reach the begin, return.
		*/
		mutex_unlock(&io_puser->mutex_user);
		return ret;
	} else if (pcorenode == io_puser->pcore_head) {
		mutex_unlock(&io_puser->mutex_user);
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	} else if (pcorenode == NULL) {
		mutex_unlock(&io_puser->mutex_user);
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	pcore = pcorenode->pcore;
	mutex_lock(&pcore->mutex_core);
	if (bclearbuffer == 1) {
		if (pcore->puser_clearbuffer == io_puser) {
			pcore->puser_clearbuffer = NULL;
			pcore->bblock_clearbuffer = 0;
		} else {
			SIMPLE_KERNEL_LOG;
		}
	} else {
		for (useri = 0; useri < VASTAI_LOGSYS_PERCORE_USER_MAX;
		     useri++) {
			if (pcore->parray_puser[useri] == io_puser) {
				break;
			}
		}
		if (useri >= VASTAI_LOGSYS_PERCORE_USER_MAX) {
			SIMPLE_KERNEL_LOG;
		} else {
			pcore->parray_puser[useri] = NULL;
			pcore->parray_puserbblock[useri] = 0;
		}
	}
	/*
	Change the tail to the previous one, and delete the instance.
	*/
	io_puser->pcore_tail = io_puser->pcore_tail->ppre;
	if (io_puser->pcore_tail == NULL) {
		SIMPLE_KERNEL_LOG;
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return ret;
	}
	io_puser->pcore_tail->pnext = NULL;
	kfree(pcorenode);
	mutex_unlock(&pcore->mutex_core);
	mutex_unlock(&io_puser->mutex_user);
	goto unbindcurrprevious;
}

u32 internal_vastai_logsys_addcore_tocorenode_ofuser(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_pci_die_core_env *i_pcore)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode =
		io_puser->pcore_head;
	while (pcorenode) {
		if (pcorenode->pcore == i_pcore) {
			SIMPLE_DEBUG_LOG;
			return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		}
		pcorenode = pcorenode->pnext;
	}
	pcorenode = kzalloc(sizeof(struct vastai_logsys_pci_die_pcore_node),
			    GFP_KERNEL);
	pcorenode->pcore = i_pcore;
	if (io_puser->pcore_head == NULL) {
		pcorenode->ppre = pcorenode->pnext = NULL;
		io_puser->pcore_head = io_puser->pcore_tail = pcorenode;
		return 0;
	}
	pcorenode->ppre = io_puser->pcore_tail;
	pcorenode->pnext = NULL;
	io_puser->pcore_tail->pnext = pcorenode;
	io_puser->pcore_tail = pcorenode;
	return 0;
}

u32 internal_vastai_logsys_deletecore_fromcorenode_ofuser(
	struct vastai_logsys_user *io_puser,
	struct vastai_logsys_pci_die_core_env *i_pcore)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode =
		io_puser->pcore_head;
	struct vastai_logsys_pci_die_pcore_node *pcorenodedel = NULL;
	while (pcorenode) {
		if (pcorenode->pcore == i_pcore) {
			pcorenodedel = pcorenode;
			if (pcorenode->ppre != NULL) {
				pcorenode->ppre->pnext = pcorenode->pnext;
			} else {
				io_puser->pcore_head = pcorenode->pnext;
			}
			if (pcorenode->pnext != NULL) {
				pcorenode->pnext->ppre = pcorenode->ppre;
			} else {
				io_puser->pcore_tail = pcorenode->ppre;
			}
			kfree(pcorenode);
			return 0;
		}
		pcorenode = pcorenode->pnext;
	}
	return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
}

void internal_vastai_logsys_deleteallcore_fromcorenode_ofuser(
	struct vastai_logsys_user *io_puser)
{
	struct vastai_logsys_pci_die_pcore_node *pcorenode =
		io_puser->pcore_head;
	struct vastai_logsys_pci_die_pcore_node *pcorenodedel = NULL;
	while (pcorenode) {
		pcorenodedel = pcorenode;
		pcorenode = pcorenode->pnext;
		kfree(pcorenode);
	}
}

u32 internal_vastai_logsys_refreshinfobuffer(struct vastai_logsys_user *io_puser)
{
	u32 ret = 0;
	u32 retsub = 0;
	struct vastai_logsys_user_mode_info *pinfo = NULL;
	struct vastai_logsys_pci_env *ppci = NULL;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	char *pbuffer = NULL;
	u32 sizeleft = 0;
	u32 corei = 0;

	retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
	if (retsub > 0) {
		return retsub;
	}
	if (io_puser->bindinfo.mode != VASTAI_LOGSYS_MODE_INFO) {
		mutex_unlock(&io_puser->mutex_user);
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
	}
	pinfo = &io_puser->bindinfo.user_mode_info;
	pbuffer = io_puser->infobuffer;
	sizeleft = VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE;
	io_puser->infobuffertotalsize = 0; // back to default 0
	mutex_unlock(&io_puser->mutex_user);

	/*
	Because the user of info mode may not be fixed user of the core, so we should add 
	pci mutex to ensure the pci exist.
	*/
	mutex_lock(&io_puser->penv->mutex_pci_list);
	if (pinfo->pci_dev_id == -1) {
		SIMPLE_DEBUG_LOG;
		ppci = io_puser->penv->ppci_head;
		while (ppci) {
			ret = internal_vastai_logsys_getpciinfotobuffer(
				io_puser, &pbuffer, &sizeleft, ppci);
			if (ret > 0) {
				goto retlabel;
			}
			ppci = ppci->pnext;
		}
	} else {
		ppci = internal_vastai_logsys_get_pci_by_pcidevid_withnolock(
			io_puser->penv, pinfo->pci_dev_id);
		if (ppci == NULL) {
			SIMPLE_KERNEL_LOG;
			ret = VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE;
			goto retlabel;
		} else {
			if (pinfo->die_index == -1) {
				ret = internal_vastai_logsys_getpciinfotobuffer(
					io_puser, &pbuffer, &sizeleft, ppci);
				goto retlabel;
			}
			if (pinfo->die_index >= ppci->die_count) {
				SIMPLE_KERNEL_LOG;
				ret = VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE;
				goto retlabel;
			}
			pdie = &ppci->parray_die_env[pinfo->die_index];
			for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT;
			     corei++) {
				if (pinfo->parray_bcore[corei] == 1) {
					pcore = &pdie->parray_core_env[corei];
					ret = internal_vastai_logsys_getcoreinfotobuffer(
						io_puser, &pbuffer, &sizeleft,
						pcore);
					if (ret > 0) {
						goto retlabel;
					}
				}
			}
			if (sizeleft == VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE) {
				ret = VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE;
				goto retlabel;
			}
		}
	}
retlabel:
	if (ret == VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE) {
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	} else if (ret ==
		   VASTAI_LOGSYS_USER_ERROR_LOG_READ_OPER_INFOMODE_CANNOTFINDANYCORE) {
		mutex_unlock(&io_puser->penv->mutex_pci_list);
		return ret;
	} else if (ret ==
		   VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH) {
		/*
		Set info buffer size.
		Need retry enter user mutex.
		*/
		retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
		if (retsub > 0) {
			mutex_unlock(&io_puser->penv->mutex_pci_list);
			return retsub;
		}
		io_puser->infobuffertotalsize =
			VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE - sizeleft;
		io_puser->infobuffer[io_puser->infobuffertotalsize] = '\0';
		io_puser->infobuffertotalsize++;
		mutex_unlock(&io_puser->mutex_user);
	} else if (ret == 0) {
		/*
		Set info buffer size.
		Need retry enter user mutex.
		*/
		retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
		if (retsub > 0) {
			mutex_unlock(&io_puser->penv->mutex_pci_list);
			return retsub;
		}
		io_puser->infobuffertotalsize =
			VASTAI_LOGSYS_INFO_BUFFER_MAXSIZE - sizeleft;
		io_puser->infobuffer[io_puser->infobuffertotalsize] = '\0';
		io_puser->infobuffertotalsize++;
		mutex_unlock(&io_puser->mutex_user);
	} else {
		ret = VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE;
		VASTAI_LOGSYS_ENV_ERROR_RECORD(
			io_puser->penv,
			VASTAI_LOGSYS_ENV_ERROR_INNERUSE_UNEXPECTED_RUNHERE);
	}
	mutex_unlock(&io_puser->penv->mutex_pci_list);
	return ret;
}

u32 internal_vastai_logsys_getpciinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_env *i_ppci)
{
	u32 ret = 0;
	u32 diei = 0;
	u32 diecount = i_ppci->die_count;
	struct vastai_logsys_pci_die_env *pdie = NULL;
	for (diei = 0; diei < diecount; diei++) {
		pdie = &i_ppci->parray_die_env[diei];
		ret = internal_vastai_logsys_getdieinfotobuffer(
			io_puser, io_ppbuffer, io_psizeleft, pdie);
		if (ret > 0) {
			return ret;
		}
	}
	return 0;
}

u32 internal_vastai_logsys_getdieinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_die_env *i_pdie)
{
	u32 ret = 0;
	u32 retsub = 0;
	u32 corei = 0;
	struct vastai_logsys_pci_die_core_env *pcore = NULL;
	for (corei = 0; corei < VASTAI_LOGSYS_CORECOUNT; corei++) {
		pcore = &i_pdie->parray_core_env[corei];
		retsub = VASTAI_LOGSYS_USER_LOCK(io_puser);
		if (retsub > 0) {
			return retsub;
		}
		mutex_lock(&pcore->mutex_core);
		ret = internal_vastai_logsys_getcoreinfotobuffer(
			io_puser, io_ppbuffer, io_psizeleft, pcore);
		if (ret > 0) {
			mutex_unlock(&pcore->mutex_core);
			mutex_unlock(&io_puser->mutex_user);
			return ret;
		}
		mutex_unlock(&pcore->mutex_core);
		mutex_unlock(&io_puser->mutex_user);
	}
	return 0;
}

u32 internal_vastai_logsys_getcoreinfotobuffer(
	struct vastai_logsys_user *io_puser, char **io_ppbuffer,
	u32 *io_psizeleft, struct vastai_logsys_pci_die_core_env *i_pcore)
{
	char coreinfodscr[256] = 0;
	u32 bytecount = 0;
	bytecount = sprintf(
		coreinfodscr,
		"[pci_%d][die_%d-%d][core_%d]:[TOTAL_%lld][CLEAR_%lld][CURR_%lld]\n",
		i_pcore->pci_dev_id, i_pcore->die_index,
		i_pcore->die_index_global, i_pcore->core_index,
		i_pcore->totalbytesum, i_pcore->clearbytesum,
		i_pcore->currbytesum);
	if (bytecount >= *io_psizeleft) {
		return VASTAI_LOGSYS_ENV_ERROR_INNERUSE_INFOBUFFER_NOTENOUGH;
	}
	*io_psizeleft = *io_psizeleft - bytecount;
	memcpy(*io_ppbuffer, coreinfodscr, bytecount);
	*io_ppbuffer = *io_ppbuffer + bytecount;
	return 0;
}

void internal_vastai_logsys_env_error_record(struct vastai_logsys_env *io_penv,
					     u32 i_errorindex,
					     const char *i_pfunc, u32 i_linenum)
{
	if (io_penv->errorindex != VASTAI_LOGSYS_ENV_ERROR_NOERROR) {
		//pr_err(VASTAI_LOGSYS_PR_HEAD "Previous error[%u][env]:func[%s][%u]\n", io_penv->errorindex, io_penv->errordetails.function, io_penv->errordetails.linenumber);
		return;
	}
	pr_err(VASTAI_LOGSYS_PR_HEAD "Current error[%u][env]:func[%s][%u]\n",
	       i_errorindex, i_pfunc, i_linenum);
	io_penv->errorindex = i_errorindex;
	strcpy(io_penv->errordetails.function, i_pfunc);
	io_penv->errordetails.linenumber = i_linenum;
}

void internal_vastai_logsys_user_error_record(
	struct vastai_logsys_user *io_puser, u32 i_errorindex,
	const char *i_pfunc, u32 i_linenum)
{
	if (io_puser == NULL) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "internal_vastai_logsys_user_error_record io_puser is NULL ERROR!\n");
		return;
	}
	if (io_puser->penv == NULL) {
		if (io_puser->errorindex != VASTAI_LOGSYS_USER_ERROR_NOERROR) {
			/*
			When the current penv is NULL and the errorindex is not NOERROR, do nothing but
			output the previous error.
			*/
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "Previous error[%u][user]:func[%s][%u]\n",
			       io_puser->errorindex,
			       io_puser->errordetails.function,
			       io_puser->errordetails.linenumber);
			return;
		} else {
			/*
			When the current penv is NULL and the errorindex is NOERROR, record the current 
			error.
			*/
		}
	}
	io_puser->penv = NULL;
	io_puser->errorindex = i_errorindex;
	strcpy(io_puser->errordetails.function, i_pfunc);
	io_puser->errordetails.linenumber = i_linenum;
	pr_err(VASTAI_LOGSYS_PR_HEAD "Current error[%u][user]:func[%s][%u]\n",
	       io_puser->errorindex, io_puser->errordetails.function,
	       io_puser->errordetails.linenumber);
	return;
}

int internal_vastai_logsys_env_check(struct vastai_logsys_env *i_penv)
{
	int ret = 0;
	if (i_penv == NULL) {
		pr_err(VASTAI_LOGSYS_PR_HEAD "penv is NULL\n");
		ret = -ENOSPC;
		return ret;
	}
	if (i_penv->errorindex != VASTAI_LOGSYS_ENV_ERROR_NOERROR) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "Previous error[%u][env]:func[%s][%u]\n",
		       i_penv->errorindex, i_penv->errordetails.function,
		       i_penv->errordetails.linenumber);
		ret = i_penv->errorindex;
		ret = -ret;
		return ret;
	}
	return 0;
}

int internal_vastai_logsys_env_user_check(struct vastai_logsys_env *i_penv,
					  struct vastai_logsys_user *io_puser,
					  u32 i_bignorerecoverable,
					  const char *i_pfunc, u32 i_linenum)
{
	int ret = 0;
	ret = internal_vastai_logsys_env_check(i_penv);
	if (ret < 0) {
		return ret;
	}
	if (io_puser->penv == NULL) {
		/*
		Not expected value!
		*/
		/*
		When already have error index, output previous error, when not, set the error.
		Already have error!
		*/
		if (io_puser->errorindex != VASTAI_LOGSYS_USER_ERROR_NOERROR) {
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "Previous error[%u][user]:func[%s][%u]\n",
			       io_puser->errorindex,
			       io_puser->errordetails.function,
			       io_puser->errordetails.linenumber);
		} else {
			internal_vastai_logsys_user_error_record(
				io_puser, VASTAI_LOGSYS_USER_ERROR_USERENV_NULL,
				i_pfunc, i_linenum);
		}
		ret = io_puser->errorindex;
		return -ret;
	}
	if (io_puser->penv != i_penv) {
		internal_vastai_logsys_user_error_record(
			io_puser, VASTAI_LOGSYS_USER_ERROR_USERENV_NOTMATCH,
			i_pfunc, i_linenum);
		ret = io_puser->errorindex;
		return -ret;
	}
	if (io_puser->errorindex == VASTAI_LOGSYS_USER_ERROR_NOERROR) {
		return 0;
	}
	/*
	Currently, we should not record the recoverable error down except 
	VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE. Check it.
	*/
	if (io_puser->errorindex < VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN ||
	    io_puser->errorindex > VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAX) {
		if (io_puser->errorindex !=
		    VASTAI_LOGSYS_USER_ERROR_LOG_NEED_REBIND_BYPCIREMOVE) {
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "Unexpected record previous error[%u][user]:func[%s][%u]\n",
			       io_puser->errorindex,
			       io_puser->errordetails.function,
			       io_puser->errordetails.linenumber);
			io_puser->errorindex =
				VASTAI_LOGSYS_USER_ERROR_UNEXPECTED_RECORD;
			ret = io_puser->errorindex;
			return -ret;
		}
	}
	if (i_bignorerecoverable == 0) {
		pr_err(VASTAI_LOGSYS_PR_HEAD
		       "Previous error[%u][user]:func[%s][%u]\n",
		       io_puser->errorindex, io_puser->errordetails.function,
		       io_puser->errordetails.linenumber);
		ret = io_puser->errorindex;
		return -ret;
	} else {
		if (io_puser->errorindex <
			    VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MIN ||
		    io_puser->errorindex >
			    VASTAI_LOGSYS_USER_ERROR_RECOVERABLE_MAX) {
			pr_err(VASTAI_LOGSYS_PR_HEAD
			       "Previous error[%u][user]:func[%s][%u]\n",
			       io_puser->errorindex,
			       io_puser->errordetails.function,
			       io_puser->errordetails.linenumber);
			ret = io_puser->errorindex;
			return -ret;
		}
	}
	return 0;
}
