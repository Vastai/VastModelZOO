#include <linux/proc_fs.h>
#include <linux/version.h>
#include <linux/uaccess.h>
#include "logsys.h"
#include "vastai_pci.h"
#include "../ep_driver/hw/va_dma_core.h"
#include "../ep_driver/hw/sdma.h"


struct vastai_dma_buf log_dma_buf;
static char g_proc_log_buf[LOGSYS_CORE_BUF*2];
static u32 g_proc_log_len = 0;
static u32 g_ret_len = 0;
static u32 g_log_rp = 0;
static u32 g_log_cnt = 0;
char *logsys_file_name[LOGSYS_CORE_COUNT] =
{
    "smcu_log",
    "cmcu_log",
    "omcu0_log",
    "omcu1_log",
    "gmcu0_log",
    "gmcu1_log",
    "gmcu2_log",
    "gmcu3_log",
    "vemcu0_log",
    "vemcu1_log",
    "vemcu2_log",
    "vemcu3_log",
    "odsp0_log",
    "odsp1_log",
    "vdsp0_log",
    "vdsp1_log",
    "pmcu_log"
};

static int logsys_read_log(struct vastai_pci_info *priv, u64 dev_addr, int log_len)
{
    struct vastai_dmadesc desc;
    union core_bitmap core_id = {.val = 0}; /* no core need be tirgger */
    int ret = 0;

    if (log_len > log_dma_buf.size)
    {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"The transfer data size cannot exceed %#X!\n", log_dma_buf.size);
        return -EINVAL;
    }

    desc.is_src_dma_addr        = 1;
    desc.is_host_to_dev         = 0;
    desc.is_src_not_user_mem    = 1;
    desc.host_addr.dma_addr     = log_dma_buf.dma_bus_addr;
    desc.host_addr.vir_addr     = log_dma_buf.vir;
    desc.dev_addr               = dev_addr;
    desc.dma_lenth              = log_len;
    ret = vastai_pci_dma_transfer_sync(priv, 0, core_id, &desc, 1, -1);
    if (ret) {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: dma transfer fail, ret = %d\n", __func__, ret);
        return -ENXIO;
    }

    return ret;
}

static ssize_t mcu_log_read(struct file *file, char __user *ubuf, size_t count, loff_t *ppos)
{
    int ret;
    int index;
    struct vastai_pci_info *priv;
    u32 ret_len = 0;
    u64 log_ddr_addr;
    logsys_header_t *log_header = NULL;
    u32 block_end_flag;
    char log_head_buf[128];
    u32 log_head_len;

    for (index = 0; index < LOGSYS_CORE_COUNT; index++)
    {
        if (!strncmp(file->f_path.dentry->d_iname, logsys_file_name[index], strlen(logsys_file_name[index])))
            break;
    }

    if (index >= LOGSYS_CORE_COUNT)
    {
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: index[%d]\n", __func__, index);
        return -EFAULT;
    }

    if (0 == g_log_rp)
    {
#if defined(RHEL_RELEASE_VERSION)
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(9, 3)
        priv = PDE_DATA(file_inode(file));
#else
        priv = pde_data(file_inode(file));
#endif
#elif KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
        priv = PDE_DATA(file_inode(file));
#else
        priv = pde_data(file_inode(file));
#endif
        log_ddr_addr = (u64)(LOGSYS_DDR_BASE_ADDR + index * LOGSYS_CORE_BUF);
        ret = logsys_read_log(priv, log_ddr_addr, LOGSYS_CORE_BUF);
        if (ret)
        {
            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: logsys_read_log fail\n", __func__);
            return -ENXIO;
        }

        while(1)
        {
            log_header = (logsys_header_t *)(log_dma_buf.vir + g_log_rp);
            if (log_header->head_flag == '#')
            {
                log_head_len = sprintf(log_head_buf, "[%d][%d]", g_log_cnt, log_header->timestamp);
                g_log_cnt++;
                memcpy((void *)(g_proc_log_buf + g_proc_log_len), (void *)log_head_buf, log_head_len);
                g_proc_log_len += log_head_len;
                memcpy((void *)(g_proc_log_buf + g_proc_log_len), (void *)(log_dma_buf.vir + g_log_rp + 8), log_header->msg_info.msg_len);
                g_proc_log_len += log_header->msg_info.msg_len;
                g_log_rp = g_log_rp + 8 + ((log_header->msg_info.msg_len + 3) / 4) * 4;
                if (g_log_rp >= LOGSYS_CORE_BUF)
                {
                    break;
                }
            }
            else
            {
                block_end_flag = *(u32 *)(log_dma_buf.vir + g_log_rp);
                if (block_end_flag == LOGSYS_BLOCKEND_NOLOG_TAG)
                {
                    g_log_rp = (g_log_rp / LOGSYS_CORE_BLOCK_SIZE + 1) * LOGSYS_CORE_BLOCK_SIZE;
                    if (g_log_rp >= LOGSYS_CORE_BUF)
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }

    if (g_ret_len < g_proc_log_len)
    {
        ret_len = g_proc_log_len - g_ret_len;
        ret_len = ret_len <= count ? ret_len : count;
        ret = copy_to_user(ubuf, g_proc_log_buf + g_ret_len, ret_len);
        if (ret)
        {
            VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID,"%s copy_to_user fail, ret[%d]\n", __func__, ret);
            return -EFAULT;
        }
        g_ret_len += ret_len;

        return ret_len;
    }

    g_proc_log_len  = 0;
    g_ret_len       = 0;
    g_log_rp        = 0;
    g_log_cnt       = 0;

    return 0;
}

#if KERNEL_VERSION(5, 6, 0) <= LINUX_VERSION_CODE
static struct proc_ops mcu_log_ops =
{
    .proc_read = mcu_log_read,
};
#else
static struct file_operations mcu_log_ops =
{
    .read = mcu_log_read,
};
#endif

static int mcu_proc_file_init(struct vastai_pci_info *priv)
{
    char mcu_log_name[64];

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_SMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_SMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_SMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_GMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_GMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_GMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_GMCU_1_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_GMCU_1_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_GMCU_1_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_GMCU_2_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_GMCU_2_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_GMCU_2_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_GMCU_3_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_GMCU_3_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_GMCU_3_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_CMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_CMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_CMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_OMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_OMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_OMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_OMCU_1_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_OMCU_1_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_OMCU_1_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_PMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_PMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_PMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VEMCU_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VEMCU_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VEMCU_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VEMCU_1_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VEMCU_1_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VEMCU_1_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VEMCU_2_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VEMCU_2_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VEMCU_2_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VEMCU_3_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VEMCU_3_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VEMCU_3_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_ODSP_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_ODSP_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_ODSP_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_ODSP_1_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_ODSP_1_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_ODSP_1_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VDSP_0_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VDSP_0_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VDSP_0_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    memset(mcu_log_name, 0, sizeof(mcu_log_name));
    snprintf(mcu_log_name, sizeof(mcu_log_name), "%s_%d", logsys_file_name[LOGSYS_VDSP_1_INDEX], priv->dev_id);
    priv->mcu_log_ent[LOGSYS_VDSP_1_INDEX] = proc_create_data(mcu_log_name, 0440, NULL, &mcu_log_ops, priv);
    if (!priv->mcu_log_ent[LOGSYS_VDSP_1_INDEX])
        VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s: fail!\n", __func__);

    return 0;
}



static int mcu_proc_file_deinit(struct vastai_pci_info *priv)
{
    proc_remove(priv->mcu_log_ent[LOGSYS_SMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_GMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_GMCU_1_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_GMCU_2_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_GMCU_3_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_CMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_OMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_OMCU_1_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_PMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VEMCU_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VEMCU_1_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VEMCU_2_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VEMCU_3_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_ODSP_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_ODSP_1_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VDSP_0_INDEX]);
    proc_remove(priv->mcu_log_ent[LOGSYS_VDSP_1_INDEX]);

    return 0;
}

int logsys_init(struct vastai_pci_info *priv)
{
    int ret;

    vastai_pci_malloc_udma_buf(priv, &log_dma_buf, LOGSYS_CORE_BUF);
    ret = mcu_proc_file_init(priv);

    return ret;
}

void logsys_deinit(struct vastai_pci_info *priv)
{
    mcu_proc_file_deinit(priv);
    vastai_pci_free_udma_buf(priv, &log_dma_buf);
}

