#ifndef _VASTAI_SG100_BBOX_H_
#define _VASTAI_SG100_BBOX_H_

//EVB card
#define EVB_GFX_GCLK        1400 
#define EVB_Video_ECLK      1050 
#define EVB_Video_DCLK      1100 
#define EVB_Video_VDSPCLK   1000
#define EVB_Video_VCLK      1000
#define EVB_DDR_RUCLK       800
#define EVB_DDR_LUCLK       800
#define EVB_SOC_CEDARCLK    700
#define EVB_SOC_LCCLK       1000
#define EVB_SOC_RCCLK       1000
#define EVB_SOC_BCCLK       1000
#define EVB_AI_OCLK         0     //0:disable 1:enable
#define EVB_AI_ODSPCLK      0     //0:disable 1:enable
#define EVB_DP_PIXCLK_DP    0     //0:disable 1:enable
#define EVB_POWER_VDD_GFX   900   //0.90v
#define EVB_POWER_VDD_VID   850   //0.85v
#define EVB_POWER_VDD_SOC   750   //0.75v

//AIC card
#define AIC_GFX_GCLK        1400 
#define AIC_Video_ECLK      1050 
#define AIC_Video_DCLK      1100 
#define AIC_Video_VDSPCLK   1000
#define AIC_Video_VCLK      1000
#define AIC_DDR_RUCLK       800
#define AIC_DDR_LUCLK       800
#define AIC_SOC_CEDARCLK    700
#define AIC_SOC_LCCLK       1000
#define AIC_SOC_RCCLK       1000
#define AIC_SOC_BCCLK       1000
#define AIC_AI_OCLK         0     //0:disable 1:enable
#define AIC_AI_ODSPCLK      0     //0:disable 1:enable
#define AIC_DP_PIXCLK_DP    0     //0:disable 1:enable
#define AIC_POWER_VDD_GFX   900   //0.90v
#define AIC_POWER_VDD_VID   850   //0.85v
#define AIC_POWER_VDD_SOC   750   //0.75v

//ZHAOGE card
#define ZHAOGE_GFX_GCLK        1400 
#define ZHAOGE_Video_ECLK      1050 
#define ZHAOGE_Video_DCLK      1100 
#define ZHAOGE_Video_VDSPCLK   1000
#define ZHAOGE_Video_VCLK      1000
#define ZHAOGE_DDR_RUCLK       800
#define ZHAOGE_DDR_LUCLK       800
#define ZHAOGE_SOC_CEDARCLK    700
#define ZHAOGE_SOC_LCCLK       1000
#define ZHAOGE_SOC_RCCLK       1000
#define ZHAOGE_SOC_BCCLK       1000
#define ZHAOGE_AI_OCLK         0     //0:disable 1:enable
#define ZHAOGE_AI_ODSPCLK      0     //0:disable 1:enable
#define ZHAOGE_DP_PIXCLK_DP    0     //0:disable 1:enable
#define ZHAOGE_POWER_VDD_GFX   900   //0.90v
#define ZHAOGE_POWER_VDD_VID   850   //0.85v
#define ZHAOGE_POWER_VDD_SOC   750   //0.75v


#endif
