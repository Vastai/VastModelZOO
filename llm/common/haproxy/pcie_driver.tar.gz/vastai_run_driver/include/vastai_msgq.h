#ifndef __VASTAI_MSGQ_H__
#define __VASTAI_MSGQ_H__
struct vastai_sv100_die;

enum VASTAI_MSGQ_OP {
	MSGQ_LOCK = 0,
	MSGQ_UNLOCK = 1,
	MSGQ_MAX_OP,
};

enum VASTAI_MSGQ_CMD {
	MSGQ_DMA = 0,
	MSGQ_CMD = 1,
	MSGQ_TYPE_MAX,
};

struct vastai_msgq {
	u32 end;
	u32 start;
	u32 wr;
	u32 rd;
};


struct msgq {
	struct vastai_msgq msgq_cache;
	u32 addr;
	spinlock_t msgq_lock;
	s32 msgq_id;
	bool overflow;
};

typedef int (*msgq_handler_t)(struct msgq *msgq, void *data, u32 data_size);

struct vmsgq {
	spinlock_t vmsgq_lock;
	unsigned long irq_flag;
	struct msgq *ptr;
	msgq_handler_t msgq_wr_hdl;
	msgq_handler_t msgq_spe_wr_hdl;
};

void vastai_die_msgq_init(struct vastai_sv100_die *die);
int vastai_pci_msgq_cache_update(struct msgq *msgq);
int vastai_pci_vmsgq_wr(struct vmsgq *msgq, void *data, u32 data_size);
int vastai_pci_vmsgq_wr_spe(struct vmsgq *msgq, void *data, u32 data_size);
int vastai_pci_msgq_wr(struct msgq *msgq, void *data, u32 data_size);
int vastai_pci_msgq_wr_spe(struct msgq *msgq, void *data, u32 data_size);
int vastai_pci_msgq_wr_sriov(struct msgq *msgq, void *data, u32 data_size);
int vastai_pci_msgq_wr_spe_sriov(struct msgq *msgq, void *data, u32 data_size);

#endif

