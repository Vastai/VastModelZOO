#ifndef _CONFIG_H_
#define _CONFIG_H_
//0:ATU 1:GART
#define D2H_BY_GART_OR_ATU       0
//0:not support,gpu access host ddr size 512GB 
//1:support,gpu access host ddr size 512GB/PF num
#define OUTBOUND_SURPORT_SRIOV   0
#endif
