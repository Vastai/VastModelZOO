/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_PCI_IOCTL_H__
#define __VASTAI_PCI_IOCTL_H__

#include "vastai_node_basic_dma.h"

#include "vastai_export_def_ext.h"
#ifdef __KERNEL__
#include <linux/cdev.h>
#include <linux/kernel.h>

#include "vastai_pci.h"
#include "vastai_export_api.h"

#ifdef CONFIG_VASTAI_PCI_BOOT
#include "vastai_pci_boot.h"
#endif


#define VASTAI_CMD_READ_LEN (4096)

#define VASTAI_TEST_PASS    (0)
#define VASTAI_TEST_FAILURE (-1)

//for normal, this is 0x40_0000
#define VASTAI_PCI_TLV_BUF_LEN (VASTAI_MAX_DMA_BUF)

enum VASTAI_PCI_ARG_INDEX {
	VASTAI_PCI_ARG_ADDR,
	VASTAI_PCI_ARG_VAL,
	VASTAI_PCI_ARG_LEN,
	VASTAI_PCI_ARG_BAR,
	VASTAI_PCI_ARG_RUN,
	VASTAI_PCI_ARG_OFFSET,
	VASTAI_PCI_ARG_VIR,
	VASTAI_PCI_ARG_REGION,
	VASTAI_PCI_ARG_MODE,
	VASTAI_PCI_ARG_CASE,
	VASTAI_PCI_ARG_USER_ADDR,
	VASTAI_PCI_ARG_DIE,
	VASTAI_PCI_ARG_DIR,
	VASTAI_PCI_ARG_MASKBIT,
	VASTAI_PCI_ARG_MMU,
	VASTAI_PCI_ARG_ADDR0,
	VASTAI_PCI_ARG_ADDR1,
	VASTAI_PCI_ARG_PID,
	VASTAI_PCI_ARG_PA_ADDR,
	VASTAI_PCI_ARG_VA_ADDR,
	VASTAI_PCI_ARG_PF,
	VASTAI_PCI_ARG_CHANNEL,
	VASTAI_PCI_ARG_CORE_POINT,
	VASTAI_PCI_ARG_LOG_LEVEL,
	VASTAI_PCI_ARG_MAX,
};

struct vastai_pci_arg_t {
	unsigned char id;
	unsigned char *name;
	unsigned long def;
};

struct char_drv_info {
	struct vastai_file_info file_info;
	struct vastai_pci_info *pcie_dev_info;
	struct vastai_dma_buf *dm;
	u32 valid_data_length;
	struct vastai_pci_arg_t args[VASTAI_PCI_ARG_MAX];
	struct pid_entry *pid_entry;
};


int vastai_pci_ioctl_init(struct vastai_pci_info *bus);
int vastai_pci_ioctl_deinit(struct vastai_pci_info *bus);
void vastai_global_echo_cmd_init(struct vastai_addr_info *addr_info);
int vastai_update_start(struct vastai_pci_info* priv, int die_id);
void vastai_update_done(struct vastai_pci_info* priv);
int vastai_dev_node_init(void);
void vastai_dev_node_deinit(void);



#endif

struct user_dma_desc {
	char cmd_str[8]; //"DMAW \0"
	union {
		struct {
			u32 is_host_to_dev : 1;
			u32 mode : 2;
			u32 ch : 3;
			u32 is_ep : 1;
			u32 die_id : 2;
		};
		u32 val;
	};
	u32 num;
	struct descriptor {
		u64 dev_addr;
		u64 host_addr;
		u32 length;
	} desc_tab[0];
};


#ifdef CONFIG_VASTAI_JENKINS_TEST
int vastai_pci_tc165(struct vastai_pci_info *priv, u32 test_size, u64 dev_addr);
int vastai_pci_tc166(struct vastai_pci_info *priv, u32 test_size, u64 dev_addr);
#endif
#ifdef __KERNEL__
int vastai_pci_dma_p2p(struct vastai_pci_info *pci_info, dma_node_p2p_cmd_t *dma_p2p_cmd);
int vastai_pci_dma_start(struct vastai_pci_info *pci_info, dma_node_start_cmd_t *dma_start_cmd);
int vastai_pci_dma_trans(struct vastai_pci_info *pci_info, dma_node_trans_cmd_t *dma_trans_cmd);
#endif

#endif /* end of __VASTAI_PCI_IOCTL_H__ */
