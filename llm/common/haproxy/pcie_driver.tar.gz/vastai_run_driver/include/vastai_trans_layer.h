#ifndef __VASTAI_TRANS_LAYER_H__
#define __VASTAI_TRANS_LAYER_H__


int vastai_pci_tl_write(struct vastai_pci_info *priv, unsigned int die_id,
				u64 dev_addr, void *data, size_t size);
int vastai_pci_tl_read(struct vastai_pci_info *priv, unsigned int die_id,
								u64 dev_addr, void *data, size_t size);

#endif
