#ifndef __VASTAI_AVFS_H__
#define __VASTAI_AVFS_H__

struct vastai_pci_info;
int avfg_set_die_avfs(struct vastai_pci_info *pci_info,unsigned char die_m);

#endif

