#ifndef __VASTAI_UTILS__
#define __VASTAI_UTILS__

unsigned long copy_to_user_compact(void __user *to, const void *from,
			      unsigned long n);
unsigned long copy_from_user_compact(void *to, const void __user *from,
				unsigned long n);

u32 vast_div_round_up(u64 numerator, u64 denominator);

#endif /* end of __VASTAI_UTILS__ */
