/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/04/13
 * Author: vincent.huang
 */

#ifndef __VASTAI_NODE_BASIC_DMA_H__
#define __VASTAI_NODE_BASIC_DMA_H__

typedef unsigned short		u16;
typedef unsigned int		u32;
typedef unsigned long long	u64;
typedef unsigned char		u8;

//#include "vastai_pci.h"
typedef struct dma_node_start_cmd {
	u32 is_dev_to_host;
	u32 dma_buf_fd;
	u64 axi_addr;
	u32 size;
	u32 die_index;
}__attribute__((packed)) dma_node_start_cmd_t;

typedef struct dma_node_trans_cmd{
	u32 is_dev_to_host;
	u64 vir_addr;
	u64 axi_addr;
	u32 length;
	u32 die_index;
	int pid;
}__attribute__((packed)) dma_node_trans_cmd_t;

typedef struct dma_node_p2p_cmd {
	u32 local_to_remote;
	u64 local_addr;
	u64 remote_bar_addr;
	u32 size;
	u32 die_index;
}__attribute__((packed)) dma_node_p2p_cmd_t;

#endif /* end of __VASTAI_NODE_BASIC_DMA_H__ */
