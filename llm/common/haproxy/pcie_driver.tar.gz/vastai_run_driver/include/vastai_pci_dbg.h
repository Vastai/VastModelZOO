/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_PCI_DBG_H__
#define __VASTAI_PCI_DBG_H__

#include <linux/printk.h>

#define VASTAI_PCI_DEBUG_PREFIX "vastai "
#define DUMMY_DIE_ID		0xff

#ifdef pr_fmt
#undef pr_fmt
#endif
#define pr_fmt(fmt) VASTAI_PCI_DEBUG_PREFIX fmt

#define VASTAI_PCI_NORMAL_LEVEL (0x01)
#define VASTAI_PCI_DEBUG_LEVEL	(0x02)
#define VASTAI_PCI_DATA_LEVEL	(0x04)
#define VASTAI_PCI_PERF_LEVEL	(0x08)
#ifndef CONFIG_VASTAI_KUNIT
#define VASTAI_GET_PCI_NAME(pcie)                                              \
	({                                                                     \
		struct vastai_pci_info *__priv = pcie;                         \
		(__priv ? pci_name((__priv)->dev) : "NULL");                   \
	})
#else
#define VASTAI_GET_PCI_NAME(pcie)                                              \
        ({                                                                     \
                ("fake-pci-name");                   \
        })
#endif

u32 vastai_pci_get_die_index(void *pci_info, u32 die_id);
#define VASTAI_GET_DIE_INDEX(pcie, die_id)                                     \
	({                                                                     \
		vastai_pci_get_die_index(pcie, die_id);			       \
	})

extern unsigned char vastai_pci_log_level;

/* vastai_pci_log_level = 0, printing pr_err information */
#define VASTAI_PCI_ERR(pcie, die_id, fmt, args...)                             \
	do {                                                                   \
		if(pcie == NULL)                                               \
			pr_err("ERROR " fmt, ##args);                          \
		else                                                           \
			pr_err("ERROR %s:%02x:%07x: " fmt, VASTAI_GET_PCI_NAME(pcie),  \
			       die_id, VASTAI_GET_DIE_INDEX(pcie, die_id), ##args);    \
	} while (0)

#define VASTAI_PCI_ERR_RATELIMIT(fmt, args...)                                 \
	do {                                                                   \
		pr_err_ratelimited("ERROR " fmt, ##args);                      \
	} while (0)

/* VASTAI_PCI_NORMAL_LEVEL, printing pr_info information */
#define VASTAI_PCI_INFO(pcie, die_id, fmt, args...)                            \
	do {                                                                   \
		struct vastai_pci_info *__priv = pcie;                         \
		if (vastai_pci_log_level & VASTAI_PCI_NORMAL_LEVEL) {          \
			if (pcie == NULL)                                      \
				pr_info("INFO " fmt, ##args);                  \
			else if (die_id >= __priv->die_num)                    \
				pr_info("INFO %s: " fmt,                       \
					VASTAI_GET_PCI_NAME(pcie), ##args);    \
			else                                                   \
				pr_info("INFO %s:%02x:%07x: " fmt,             \
					VASTAI_GET_PCI_NAME(pcie), die_id,     \
					VASTAI_GET_DIE_INDEX(pcie, die_id),    \
					##args);                               \
		}                                                              \
	} while (0)

#define VASTAI_PCI_INFO_RATELIMIT(fmt, args...)                                \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_NORMAL_LEVEL) {          \
			pr_info_ratelimited("INFO " fmt, ##args);              \
		}                                                              \
	} while (0)

/* VASTAI_PCI_DEBUG_LEVEL, printing debug information */
#define VASTAI_PCI_DBG(pcie, die_id, fmt, args...)                             \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {           \
			if (pcie == NULL)                                      \
				pr_info("DEBUG " fmt, ##args);                 \
			else if (die_id == 0xff)                               \
				pr_info("DEBUG %s: " fmt,                      \
					VASTAI_GET_PCI_NAME(pcie), ##args);    \
			else                                                   \
				pr_info("DEBUG %s:%02x:%07x: " fmt,            \
					VASTAI_GET_PCI_NAME(pcie), die_id,     \
					VASTAI_GET_DIE_INDEX(pcie, die_id),    \
					##args);                               \
		}                                                              \
	} while (0)

#define VASTAI_PCI_DBG_RATELIMIT(fmt, args...)                                 \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {           \
			pr_info_ratelimited("DEBUG " fmt, ##args);             \
		}                                                              \
	} while (0)

/* VASTAI_PCI_DATA_LEVEL, printing data or dump information */
#define VASTAI_PCI_HEX_DUMP(level, prefix_str, prefix_type, rowsize,           \
			    groupsize, buf, len, ascii)                        \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DATA_LEVEL)              \
			print_hex_dump(level, prefix_str, prefix_type,         \
				       rowsize, groupsize, buf, len, ascii);   \
	} while (0)

/* VASTAI_PCI_PERF_LEVEL, printing perf information */
#define VASTAI_PCI_PERF(fmt, args...)                                          \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_PERF_LEVEL)              \
			trace_printk(" DEBUG: " fmt, ##args);                  \
	} while (0)

#if 0
#define VASTAI_PCI_FUNC_ENTERY                                                 \
	VASTAI_PCI_INFO_RATELIMIT("%s entry!\n", __func__)
#define VASTAI_PCI_FUNC_EXIT VASTAI_PCI_INFO_RATELIMIT("%s done!\n", __func__)
#endif
#define VASTAI_PCI_FUNC_ENTERY
#define VASTAI_PCI_FUNC_EXIT

#endif /* end of __VASTAI_PCI_DBG_H__ */
