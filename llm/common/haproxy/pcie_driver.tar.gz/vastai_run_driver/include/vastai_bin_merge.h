/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/04/6
 * Author: vincent.huang
 */

#ifndef __VASTAI_BIN_MERGE_H__
#define __VASTAI_BIN_MERGE_H__

#define vastai_common_boot_hexcode "../fw/common_boot.bin.hex"
#define vastai_reset_vector_hexcode "../fw/reset_vector.bin.hex"
#define VASTAI_COMMON_BOOT_HEX_SIZE  sizeof(vastai_common_boot_hex_buf)
#define VASTAI_RESET_VECTOR_HEX_SIZE sizeof(vastai_reset_vector_hex_buf)


struct _packet_header
{
	u32 image_type;
	u32 decrypt_addr;
	u32 image_length;
	u32 signature_len:16;
	u32 crc16:16;
};

typedef union {
	u32 val;
	struct {
		u32 core_offset:16;
		u32 sub_core:8;
		u32 core_type:4;
		u32 image_type:4;
	};
}sub_image_type;


struct _sub_header
{
	sub_image_type image_type;
	u32 image_addr;
	u32 image_length;
	u32 offset_len:16;
	u32 crc16:16;
};

int vastai_get_fw_data(struct vastai_pci_info *priv, u8 die_id, 
			const struct firmware **fw_entry, char *fw_name);
void vastai_set_sub_header(struct _sub_header *sh, int i, size_t fw_size);
int vastai_download_all_fw_bin(struct vastai_pci_info *priv, u8 die_id);
int vastai_pci_download_fw(struct vastai_pci_info *priv,
				  unsigned int die_id,
				  const unsigned char *fw_hex_buf, size_t fw_hex_size,
				  u64 fw_addr);
int vastai_is_file_exist(char *path);




#endif
