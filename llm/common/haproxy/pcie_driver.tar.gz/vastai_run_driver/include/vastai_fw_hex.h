/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef _VASTAI_FW_HEX_H
#define _VASTAI_FW_HEX_H

extern const unsigned char vastai_bl0_hex_buf[];
extern const unsigned char vastai_sg100_bl0_hex_buf[];
extern const unsigned char vastai_sg100_bl0_full_hex_buf[];
extern const unsigned char vastai_sg100_bl0_base_hex_buf[];
extern const unsigned char vastai_bl0_app_hex_buf[];
extern const unsigned char vastai_bl1_hex_buf[];
extern const unsigned char vastai_sg100_bl1_hex_buf[];
extern const unsigned char vastai_fw_hex_buf[];
extern const unsigned char vastai_sg100_fw_hex_buf[];
extern const unsigned char vastai_fw_ddrbw_hex_buf[];
extern const unsigned char vastai_bmcu_hex_buf[];
extern const unsigned char vastai_sg100_bmcu_hex_buf[];
extern const unsigned char vastai_common_boot_hex_buf[];
extern const unsigned char vastai_reset_vector_hex_buf[];


extern u32 VASTAI_BL0_HEX_SIZE;
extern u32 VASTAI_SG_BL0_HEX_SIZE;
extern u32 VASTAI_SG_BL0_FULL_HEX_SIZE;
extern u32 VASTAI_SG_BL0_BASE_HEX_SIZE;
extern u32 VASTAI_BL0_APP_HEX_SIZE;
extern u32 VASTAI_BMCU_HEX_TEST_SIZE;
#define VASTAI_BL1_HEX_SIZE	 sizeof(vastai_bl1_hex_buf)
#define VASTAI_SG_BL1_HEX_SIZE	 sizeof(vastai_sg100_bl1_hex_buf)
#define VASTAI_FW_HEX_SIZE	 sizeof(vastai_fw_hex_buf)
#define VASTAI_SG_FW_HEX_SIZE	 sizeof(vastai_sg100_fw_hex_buf)
#define VASTAI_FW_DDRBW_HEX_SIZE sizeof(vastai_fw_ddrbw_hex_buf)
#define VASTAI_BMCU_HEX_SIZE	 sizeof(vastai_bmcu_hex_buf)
#define VASTAI_SG_BMCU_HEX_SIZE	 sizeof(vastai_sg100_bmcu_hex_buf)


#define BL1_SV_PATH  "vastai/sv100/vastai_bl1.bin"
#define BL1_SG_PATH  "vastai/sg100/vastai_bl1.bin"
#define BMCU_SV_PATH "vastai/sv100/vastai_bmcu.bin"
#define BMCU_SG_PATH "vastai/sg100/vastai_bmcu.bin"
#define BL0_SV_PATH "vastai/sv100/vastai_bl0.bin"
#define BL0_SG_PATH "vastai/sg100/vastai_bl0.bin"
#define BL0_FULL_SG_PATH "vastai/sg100/vastai_bl0_full.bin"
#define BL0_BASE_SG_PATH "vastai/sg100/vastai_bl0_base.bin"
#define BL0_APP_PATH "vastai/sv100/vastai_bl0_app.bin"
#define FW_SV_PATH   "vastai/sv100/vastai_fw.bin"
#define FW_SG_PATH   "vastai/sg100/vastai_fw.bin"


#define BL0_BASE_TOTAL_SIZE	(0x20000)	// 128K
#define BL0_APP_TOTAL_SIZE	(0x19000)	// 100K



#endif /* _VASTAI_FW_HEX_H */
