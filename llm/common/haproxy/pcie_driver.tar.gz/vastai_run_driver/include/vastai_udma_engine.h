/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_UDMA_ENGINE_H__
#define __VASTAI_UDMA_ENGINE_H__

#include <linux/list.h>
#include <linux/semaphore.h>
#include <linux/spinlock_types.h>
#include "vastai_pci.h"
#include "vastai_dmabuf.h"
#include "vastai_fifo.h"
#include "vastai_pci_test.h"
#include "vastai_udma_struct.h"


/* maximum length transfer 2^24 bytes, i.e. 16M bytes. */
#define VASTAI_UDMA_LENGTH_MAX	(0x1000000)
#define VASTAI_UDMA_LENGTH_MASK (0xFFFFFF)
#define VASTAI_UDMA_MALLOC_MAX	(0x400000)

#define CPDREF_TEST_FAILURE 1
//#define CPDREF_FUNC_TIMEDOUT     0x05

#define UDMA_DATA_INVALID (1 << 0)

#define UDMA_DESC_SIZE (sizeof(PCIE_xd_desc))

#define VASTAI_DMA_HIGH_PRIORITY  VASTAI_MEM_POOL_MIN_NR / 2
#define VASTAI_DMA_LOW_PRIORITY	  1
#define VASTAI_DMA_DEFAULT_CREDIT VASTAI_DMA_HIGH_PRIORITY
#define VASTAI_VF_SRIOV_DMA_CREDIT_LIMIT      9
#define VASTAI_PF_SRIOV_DMA_CREDIT_LIMIT      2
#define VASTAI_DMA_CREDIT_LIMIT               10


#define VASTAI_DMA_SUBMIT_LIMIT	  4

static inline bool vastai_pci_dma_uaddr_linklist_on(int die_index)
{
	return vastai_module_para_uaddr_ll()?((die_index == VASTAI_DIE0)?true:false):false;
}

int vastai_pci_dma_transfer_sync_pid(struct vastai_pci_info *pci_info, int die_index,
				     union core_bitmap core_id,
				     struct vastai_dmadesc desc[], int desc_num,
				     int pid);
void vastai_global_dma_init(struct vastai_addr_info *addr_info);

int vastai_udma_init(struct vastai_sv100_die *die);
void vastai_udma_deinit(struct vastai_sv100_die *die);
int vastai_common_cut_dma_buf_new(struct vastai_pci_info *pci_info, void *dma_node, u32 size,
					struct vastai_dmadesc* desc, struct dma_buf *dmabuf, get_dev_host_addr_func pGetDevHostAddr,
					set_desc_func_new pSetDescFunc);
int vastai_dma_video(struct vastai_pci_info *pci_info, int die_index, union core_bitmap core_id,
		     struct vastai_channel_buf *channel_buf, int channel_num,
		     u64 dev_addr, int pid);
int vastai_pci_dma_common_mem_copy(bool is_host_to_dev, struct vastai_dmadesc *cur_desc,
						  struct vastai_dma_buf *buf,
						  void *pci_info,
						  int die_index);
int vastai_dev2dev_sdma_sync_pid(void *priv, int die_index, u64 src_addr, u64 dst_addr,
						u32 length, int pid);



#define GET_UDMA_CHN(dir, is_rc) (dir + is_rc * 2)
u64 vastai_udma_push_desc_with_trans(struct vastai_pci_info *pci_info,
	unsigned int die_index, unsigned int dma_chn, u32 trans_addr,
	u64 sys_addr, u64 ext_addr, u32 length, u8 ctr_byte);


extern const struct vastai_udma_config vastai_udma_config[VASTAI_DMA_CHN];
int vastai_sdma_transfer_sync_pid(struct vastai_pci_info *pci_info, int die_index,
				     union core_bitmap core_id,
				     struct vastai_dmadesc desc[], int desc_num,
				     int pid);
int vastai_hdma_transfer_sync_pid(void *priv, int die_index,
				 union core_bitmap core_id,
				 struct vastai_dmadesc desc[], int desc_num, int pid);

#endif /* end of __VASTAI_UDMA_ENGINE_H__ */
