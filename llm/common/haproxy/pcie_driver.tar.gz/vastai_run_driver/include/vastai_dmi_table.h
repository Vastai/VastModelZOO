/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_DMI_TABLE_H__
#define __VASTAI_DMI_TABLE_H__

#include "vastai_pci.h"

struct dmi_info {
	const char *sys_vendor;
	const char *product_name;
	u32 id;
	u32 hash;
};

extern struct dmi_info host_dmi_info;

void dmi_info_init(void);
int dmi_set_device(struct vastai_pci_info *pci_info);
void vastai_test_cal_dmi_sha256(void);
#endif
