/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/12/07
 * Author: vincent.huang
 */

#ifndef __VASTAI_UDMA_STRUCT_H__
#define __VASTAI_UDMA_STRUCT_H__

#include <linux/list.h>
#include <linux/semaphore.h>
#include <linux/spinlock_types.h>
#include "vastai_common_pci_api.h"


struct vastai_pid_entry {
	struct list_head list;
	int pid;
};

struct vastai_credit {
	struct semaphore credit_sem;
};

struct vastai_udma_chn {
	struct vastai_udma_config udma_config;
	struct vastai_fifo dma_desc_fifo;
	struct vastai_fifo trans_info_fifo;
	struct list_head head;
	struct mutex trans_mutex;
	atomic_t ongoing_count;
};


#endif /* end of __VASTAI_UDMA_STRUCT_H__ */
