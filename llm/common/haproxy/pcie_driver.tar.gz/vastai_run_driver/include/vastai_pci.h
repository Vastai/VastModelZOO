/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_PCI_H__
#define __VASTAI_PCI_H__

#include <linux/list.h>
#include <linux/pci.h>
#include <linux/cdev.h>
#include <linux/dma-buf.h>
#include "vastai_udma_struct.h"
#include "vastai_pci_api.h"
#include "vastai_pci_dbg.h"
#include "vastai_sv100_reg.h"
#include "vastai_fifo.h"
#include "vastai_msgq.h"

#include "vastai_pci_vf.h"
#include "vastai_node_basic_dma.h"
#include "msgq_struct_share.h"
#include "sg100_pcie_resource.h"
#include "vastai_export_def_ext.h"
#include "va_dma_core.h"

#include "vastai_ras.h"
#include "vastai_utils.h"

#define VASTAI_CHIP_SYNC  0
#define VASTAI_CHIP_ASYN  1

#define VASTAI_PCI_DRIVER_PREFIX "vastai"
#define VASTAI_VER_COMMON_LEN	 (64)
#define VASTAI_VER_BMCU_XSPI_LEN (32)

#define PCI_VENDOR_ID_VASTAI	 (0x1EC6)

#define PCI_VENDOR_ID_DAOCLOUD	 (0x1F4F)
#define PCI_DEVICE_ID_DAOCLOUD	 (0x0100)
#define PCI_SUBDEVICE_ID_DAOCLOUD	(0x0010)

#define PCI_VENDOR_ID_ALIBABA    (0x1DED)
#define PCI_ALIBABA_FPGA_DEVICE_ID     (0x7005)

#define SV100_BOARD_DEVICE_ID   0x0100
#define SG100_BOARD_DEVICE_ID   0x0200

#define BOARD_DEVICE_ID_MASK    0x0f00


#define SV100_PF_DEVICE_ID   (SV100_BOARD_DEVICE_ID | 0x0)
#define SV100_VF_DEVICE_ID   (SV100_BOARD_DEVICE_ID | 0x1)



//PCI_VENDOR_ID_VASTAI
#define PF_DEVICE_ID         (SG100_BOARD_DEVICE_ID | 0x00)
#define VF_DEVICE_ID         (SG100_BOARD_DEVICE_ID | 0x03)  // need be removed if BL0 is updated by zouyang in Jun 2023
#define VF_DEVICE_ID2        (SG100_BOARD_DEVICE_ID | 0x0f)

#define GFX_PF_DEVICE_ID     (SG100_BOARD_DEVICE_ID | 0x04)
#define AUD_PF_DEVICE_ID     (SG100_BOARD_DEVICE_ID | 0xff) //0x0205  // disable Audio probe


#define VASTAI_SV100_MAX_DIE_NUM (4)

#define VASTAI_VAL_DW_MASK (0xFFFFFFFF)

#define VASTAI_DIR_IN  (0)
#define VASTAI_DIR_OUT (1)

#define VASTAI_PCIE_MSI_NUM (32)
/* Support up to 128 msi-x interrupts. */
#define VASTAI_PCIE_MSIX_SV100_NUM (128)
#define VASTAI_PCIE_MSIX_SG100_NUM (16)
/*#define VASTAI_PCIE_MSIX_NUM_PER_DIE                                           \
	(VASTAI_PCIE_MSIX_NUM / VASTAI_SV100_MAX_DIE_NUM) //should modify */

#define VASTAI_PCIE_WAIT_SMCU_MSG1_TIME (4000)
#define VASTAI_PCIE_WAIT_XSPI_MSG1_TIME (30000)

#define VASTAI_PCIE_TRANS_NUM (256)

#define VASTAI_MAX_DMA_BUF SZ_4M
#define VASTAI_MAX_DMA_PAYLOAD SZ_16M
#define VASTAI_MAX_MEMSET_BUF SZ_4M

#define SN_LEN (16 + 1)
#define TYPE_LEN (16 + 1)

#define VASTAI_BMCU_UPDATE_MAX_WAIT_TIME (60000)

#ifndef MIN
#define MIN(a, b)  ((a) < (b) ? (a):(b))
#endif
#define SIZE_16G 0x400000000ULL
#define product_len 96
#define sn_offset 60
#define card_type_offset 4

enum VASTAI_DMA_TYPE {
	VASTAI_DMA_TYPE_UDMA = 0,
	VASTAI_DMA_TYPE_SDMA,
	VASTAI_DMA_TYPE_HDMA,
};

#define VASTAI_FILE_MODE 0666

/* s, watch dog is 4s, we need one more sec to protact noc-bus is empty */
#define VASTAI_WAITING_RESET 5

//define core num
#define		CORE_POINT_SMCU				(0)
#define		CORE_POINT_CMCU				(1)
#define		CORE_POINT_LMCU0			(2)
#define		CORE_POINT_LMCU1			(3)
#define		CORE_POINT_LMCU2			(4)
#define		CORE_POINT_LMCU3			(5)
#define		CORE_POINT_LMCU4			(6)
#define		CORE_POINT_LMCU5			(7)
#define		CORE_POINT_LMCU6			(8)
#define		CORE_POINT_LMCU7			(9)
#define		CORE_POINT_ODSP0			(10)
#define		CORE_POINT_ODSP1			(11)
#define		CORE_POINT_ODSP2			(12)
#define		CORE_POINT_ODSP3			(13)
#define		CORE_POINT_ODSP4			(14)
#define		CORE_POINT_ODSP5			(15)
#define		CORE_POINT_ODSP6			(16)
#define		CORE_POINT_ODSP7			(17)
#define		CORE_POINT_VDMCU0			(18)
#define		CORE_POINT_VDMCU1			(19)
#define		CORE_POINT_VDMCU2			(20)
#define		CORE_POINT_VEMCU0			(21)
#define		CORE_POINT_VEMCU1			(22)
#define		CORE_POINT_VEMCU2			(23)
#define		CORE_POINT_VEMCU3			(24)
#define		CORE_POINT_VDSP0			(25)
#define		CORE_POINT_VDSP1			(26)
#define		CORE_POINT_VDSP2			(27)
#define		CORE_POINT_VDSP3			(28)
#define		CORE_TOTAL_NUM				(29)

#define MSGQ_DMA 0
#define MSGQ_CMD 1

#define VASTAI_HARVEST_ALL_DLC_ENABLE 	(0)
#define VASTAI_HARVEST_TYPE1 		(1) // all oaks or odsps invalid
#define VASTAI_HARVEST_ALL_DLC_DISABLED (2)
#define VASTAI_HARVEST_ALL_DLC_AND_ODSP_DISABLED (3)
#define VASTAI_HARVEST_TYPE2 		(4) // 4 oaks valid

#define VASTAI_CMD_BUF_LEN 0x220
#define VASTAI_CMD_BUF_NR  5

#define VASTAI_CANCEL_CMD_BUF_LEN 0x160
#define VASTAI_CANCEL_CMD_BUF_NR  1

#define VASTAI_MAX_DIE_NUM_IN_HOST 64

#define VASTAI_MIX_CARD_IRQ_NR 32

enum VASTAI_MSGQ_ID {
       MSGQ_ID_0 = 0,
       MSGQ_ID_1 = 1,
};

enum VASTAI_DIE_NUM {
	VASTAI_SINGLE_DIE = 1,
	VASTAI_TWO_DIE = 2,
	VASTAI_FOUR_DIE = 4
};

enum VASTAI_DIE_ID {
	VASTAI_DIE0,
	VASTAI_DIE1,
	VASTAI_DIE2,
	VASTAI_DIE3,
	VASTAI_DIE_ID_MAX
};

enum VASTAI_PKG_ID {
	VASTAI_PKG0,
	VASTAI_PKG1,
	VASTAI_PKG_ID_MAX
};

enum VASTAI_FN_ID {
	VASTAI_FN0,
	VASTAI_FN1,
	VASTAI_FN2,
	VASTAI_FN3,
	VASTAI_FN4,
	VASTAI_FN5,
	VASTAI_FN6,
	VASTAI_FN7,
	VASTAI_FN_ID_MAX
};

enum VASTAI_PCI_GEN_SEL {
	VASTAI_PCI_GEN1 = 1,
	VASTAI_PCI_GEN2,
	VASTAI_PCI_GEN3,
	VASTAI_PCI_GEN4
};

typedef enum {
	VASTAI_CARD_VA16 = 0x22,
	VASTAI_CARD_VA1M = 0x40,
	VASTAI_CARD_VA1U = 0x41,
	VASTAI_CARD_VAM = 0x50,
}VASTAI_CARD_TYPE;

struct vastai_pci_chn_info {
	struct chn_ops *ops[32];
	// NTD
};

// struct __attribute__((packed)) cmcu_model_info {
// 	u64 msg_seq_id;
// 	u64 model_cfg_addr;
// 	u64 input_output_addr;
// };

// struct __attribute__((packed)) vdsp_cmd_info {
// 	u32 dev;
// 	/* cmd id */
// 	u32 cmd;
// 	u32 image_id;
// 	/* dev soc entry addr */
// 	u32 stream_addr;
// 	/* dev soc addr */
// 	u64 input_addr;
// 	u32 resvd;
// };

struct __attribute__((packed)) pcie_transfer_cmd {
	union
	{
		struct
		{
			unsigned int optcode	: 8;
			unsigned int rev0	: 8;
			unsigned int rev1	: 8;
			unsigned int rev2	: 8;
		}s_data0;
		unsigned int data0;
	} w0;

	union
	{
		struct
		{
			unsigned int rev0	: 8;
			unsigned int rev1	: 8;
			unsigned int rev2	: 8;
			unsigned int rev3	: 8;
		}s_data1;
		unsigned int data1;
	} w1;

	union
	{
		struct
		{
			unsigned int rev0	: 8;
			unsigned int rev1	: 8;
			unsigned int rev2	: 8;
			unsigned int rev3	: 8;
		}s_data2;
		unsigned int data2;
	} w2;

	union
	{
		struct
		{
			unsigned int rev0	: 8;
			unsigned int rev1	: 8;
			unsigned int rev2	: 8;
			unsigned int rev3	: 8;
		}s_data3;
		unsigned int data3;
	} w3;
};


struct __attribute__((packed)) vdmcu_msg_head {
	/* rd msg num */
	u32 rd;
	/* wr msg num */
	u32 wr;
	/* max msg num */
	u32 elem_count;
	/* every msg element size */
	u32 elem_size;
	u8 buf[0];
};

struct region_info{
	u64 fn_base_addr;
	u64 noc_addr;
	u64 region_size;
	u64 bar_offset;
	u8 *region_vmem;
};


struct bar_info {
	resource_size_t mmio_start;
	resource_size_t mmio_end;
	resource_size_t mmio_len;
	unsigned long mmio_flags;
	/* inbound pcie to axi address translation */
	unsigned long at_addr;
	unsigned char *mem;
	unsigned char *vmem;
	u64 map_in_addr;
	u64 map_out_addr;
	bool minish_bar_size;
	/* inbound pcie to axi address translation */
	u64 noc_addr;
	u64 fn_base_addr;
	unsigned long region_cnt;
	struct region_info regions[6];          // BAR 2/3 supports the most region number.
};

struct msi_x_table {
	unsigned int msg_addr;
	unsigned int msg_upper_addr;
	unsigned int msg_data;
	unsigned int vector_control;
};

typedef int (*vastai_intr_handle)(void *pci_dev, u32 die_index, int irq,
				  void *ctxt, /* for user keep private data */
				  void *out); /* for out_desc */

typedef void (*va_host_irq_callback_t)(void *arg, struct host_irq_msg *msg);


typedef enum
{
	RESET_START,
	RESET_END
} reset_event;

typedef int (*vastai_reset_handle)(u32 die_index, u32 core_bit,
						reset_event event);


struct vastai_time {
	unsigned char sec : 6;
	unsigned char min : 6;
	unsigned char hour : 5;
	unsigned char day : 5;
	unsigned char mon : 4;
	unsigned year : 11;
};

enum vastai_reset_type {
	VASTAI_RESET_MSG_TRIGER =
		1 << 1, /* host send msg_irq to triger fw reset */
	VASTAI_RESET_BOOT_DEV = 1 << 2 /* reboot dev, fw download and ... */
};

struct vastai_fw_bmcu_xspi_version {
	union {
		u8 bmcu_ver[VASTAI_VER_COMMON_LEN];
		struct {
			u8 bmcu_sub_ver[VASTAI_VER_BMCU_XSPI_LEN];
			u8 xspi_sub_ver[VASTAI_VER_BMCU_XSPI_LEN];
		};
	};
};

struct vastai_fw_version {
	u8 ver[VASTAI_VER_COMMON_LEN];
	u8 smcu_ver[VASTAI_VER_COMMON_LEN];
	u8 bmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 vdmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 vemcu_ver[VASTAI_VER_COMMON_LEN];
	u8 vdsp_ver[VASTAI_VER_COMMON_LEN];
	u8 cmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 lmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 odsp_ver[VASTAI_VER_COMMON_LEN];
	u8 driver_ver[VASTAI_VER_COMMON_LEN];
	u8 phy_ver[VASTAI_VER_COMMON_LEN];
	u8 bmcu_backup_ver[VASTAI_VER_COMMON_LEN];
};

struct vastai_fw_version_sg {
	u8 ver[VASTAI_VER_COMMON_LEN];
	u8 smcu_ver[VASTAI_VER_COMMON_LEN];
	u8 cmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 omcu_ver[VASTAI_VER_COMMON_LEN];
	u8 gmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 vemcu_ver[VASTAI_VER_COMMON_LEN];
	u8 odsp_ver[VASTAI_VER_COMMON_LEN];
	u8 vdsp_ver[VASTAI_VER_COMMON_LEN];
	u8 pmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 vdmcu_ver[VASTAI_VER_COMMON_LEN];
	u8 ver_bk[VASTAI_VER_COMMON_LEN];
	u8 bl0_ver[VASTAI_VER_COMMON_LEN];
	u8 bl0_ver_bk[VASTAI_VER_COMMON_LEN];
	u8 driver_ver[VASTAI_VER_COMMON_LEN];
	u8 phy_ver[VASTAI_VER_COMMON_LEN];
};


struct heartbeat_die {
	unsigned long cores_status; /* bit map: 0 - alive, 1 - hang */
	u32 last_counts[HEARTBEAT_MAX_CNT][SV_HEARTBEAT_CNT_REG_NUM];
	int tail;
	int head;
};

struct heartbeat_monitor {
	unsigned long dies_status; /* bit map: 0 - alive, 1 - hang */
	unsigned long timeout_threshold; /* unit: jiffies */
	struct delayed_work heartbeat_work;
	struct heartbeat_die dies[VASTAI_SV100_MAX_DIE_NUM];
};

union die_index_data {
	u32 val;
	struct {
		u32 die_id : 8;
		u32 dev_id : 16;
		u32 seq_num : 8;
	};
};

enum vastai_dev_type {
	VASTAI_PROCESSING_ACCELERATORS_DEVICE,
};

enum vastai_dev_cap {
	VASTAI_DEV_CAP_DEFAULT,
	VASTAI_DEV_CAP_VIDEO_ONLY,
	VASTAI_DEV_CAP_AI_ONLY,
	VASTAI_DEV_CAP_VIDEO_AI,
};

struct vastai_dev_info {
	u8 dev_type;
	u8 dev_cap;
};


struct ctrl_cmd_list {
	atomic_t ctrl_seq_id;
	spinlock_t ctrl_cmd_list_lock;
	struct ctrl_cmd_entry {
		u8 seq_id;
		struct list_head list;
		struct completion msg_comp;

		/* 4Byte */
		union completion_info_st {
			struct smcu_to_host_msg1 smcu_to_host;
			struct {
				u8 type;
				u8 seq_id;
				u16 ret_val;
			} ret_st;
		} completion_info;
	} ctrl_cmd_head;
};
struct pci_link_monitor {
	pid_t pid;
	struct timer_list timer;
	unsigned long dma_bus_addr;
	void *dma_vir;
	u32 cnt;
	struct work_struct work;
	struct workqueue_struct *wq;
	int reset_count;
	u32 saved_config_space[16];
	atomic_t is_reseting;
	bool bypass;
};

struct bbox_info {
	union {
		u32 val;
		struct {
			u8 card_type;//	0: VA1, 1: VA1V, 2: VA1A,3: VA10, 4: VE1
			u8 reserved1;
			u8 bbox_type;
			u8 reserved2;
		};
	};
	spinlock_t bbox_lock;
};

struct efuse_harvest_info{
	u8 type;
	u16 dlc_cores;
};

struct vastai_dma_buf {
	void *vir;
	unsigned long dma_bus_addr;
	phys_addr_t phy;
	int size;
	struct page 			**pages;
	u8 				*pages_order;
	struct sg_table 		sg_table;
	unsigned int			num_pages;
	struct vastai_pci_info *pci_info;
	bool is_from_pool_ex;
};

#define SV100_MAX_VDSP_NUM          4
#define SV100_MAX_VDMCU_NUM         3
#define SV100_MAX_VEMCU_NUM         4



struct intrrupt_info {
	int is_out_as_stream; /* is we need malloc out buf each time ? */
	struct out_desc out;
	u32 padding[256];
	void *private_data; /* for user keep private data */
	vastai_intr_handle intr_handle;
};

#if 0
struct vastai_die_irq {
	u32 die_irq;
	void *parent; /* vastai_core*/
	u8 index; /* for get parent struct: vastai_core */
};
#endif

struct vastai_core_work {
	u32 *irq_idx;
	struct workqueue_struct *wq;
	struct work_struct work;
	struct vastai_sv100_die *die;
	void (*handler_function)(void *);
};

struct vastai_core {
	struct core_info_entry *cores_info_ref; /* 业务运行时固定不变 */

	u32 irq_idx[2];
	struct vastai_sv100_die *die;
	u32 core_bit;
	spinlock_t rd_ring_buf_lock;
	spinlock_t wr_ring_buf_lock;
	u32 pcie_tx_core_count;
	u32 pcie_rx_core_count;
	bool is_exception;
	struct work_struct exception_work;
	struct work_struct exception_work_new;
	u32 event_type;
	struct vastai_core_work core_work[2];
	struct vastai_fifo *push_cache[2];
	struct vastai_fifo *pop_cache[2];
	u32 log_cache_rp;
	u32 log_last_rp;
};


/* *
 * vastai_sv100_die have those function:
 * 1. distribute irq
 * 2. udma_chn manager
 * 3. two msgq (1. for dma, 2. for ctrl cmd)
 * 4. vastai_fifo config
 * 5. log completion
 * 6. ecc completion
 * 7. core sync
 * 8. fw_version
 * 9. work around for vdmcu_pre_addr
 * */

struct vastai_sv100_die {
	struct vastai_pci_info *pci_info;
	u32 die_index;
	u32 render_id;
	u32 card_id;
	struct intrrupt_info ivt[32];
	struct mutex cedar_lock;
	struct vmsgq vmsgq[2];
	struct msgq msgq[2];
	u32 boot_mode;
	struct completion log_comp;
	struct completion ecc_2bit_err;
	struct completion rw_xspi;
	atomic_t xspi_flag;
	u32 rw_xspi_msg;
	struct vastai_core core[CORE_TOTAL_NUM];
	u32 dev_freq;
	u32 pcie_nls[3]; /* pcie_nls[0] H2D , pcie_nls[1] D2D,  pcie_nls[2] Pkg2Pkg negotiated_link_speed */
	u32 pcie_nlw[3]; /* pcie_nlw[0] H2D , pcie_nlw[1] D2D,  pcie_nls[2] Pkg2Pkg negotiated_link_width */
	u32 pcie_mls;
	u32 pcie_mlw;
	struct semaphore credit_sem;
	struct ctrl_cmd_list ctrl_cmd_list;
	u8 core_sync_result[VASTAI_CORE_SYNC_TOTAL_NUM * 8];
	struct vastai_fw_version fw_ver;
	u64 vdmcu_pre_addr_table[3];
	u32 smi_ack_msg[2]; /*smi ack from smcu*/
	struct completion smi_ack[2]; /*smi ack from smcu*/
	struct completion core_time_sync_ack; /*core time sync ack from smcu*/
	/* udma */
	struct vastai_udma_chn udma_chn[VASTAI_DMA_CHN];
	struct mutex done_lock;
	struct work_struct dma_done;
	struct workqueue_struct *udma_wq;

	struct work_struct exception_work_new;
	struct completion reset_comp;
	struct completion ai_reset_done;
	u32 heartbeat_mask;
	bool ai_sys_reset;
	bool vf_in_use;
#ifdef CONFIG_TOOLS_V2
	struct mutex tools_die_mutex; /* tools die mutex */
#endif
	unsigned long dma_log_addr;
	void *dma_log_vir;
	struct mutex get_dlc_mutex;
	struct completion get_dlc_core_done;
	struct vastai_dma_buf *test_dm_sg;
	struct vastai_dma_buf *vatool_dm_sg;
	struct vastai_dma_buf test_dm;
	struct vastai_dma_buf vatool_dm;
	u32 max_smi_h;
	u32 max_smi_l;
	u16 read_addr_h;
	u16 read_addr_l;
	struct efuse_harvest_info harvest_info;
	struct kmem_cache *data_struct_slab;
	u32 core_bit;
	u32 event_type;
	struct pci_link_monitor pci_link_stat;
#ifdef CONFIG_VASTAI_RAS
	bool ras_enabled;
	u32 ras_evt_cnt;                         /* Num of RAS events after insmod */
	struct ras_event_head ras_evt;           /* ras events to be processed */
	struct ras_event_head ras_evt_afterboot; /* ras events happend after insmod */
	struct work_struct ras_work;
	struct workqueue_struct *ras_wq;
#endif
	atomic_t inventory_cached_flag;
	u8 inventory[4096];
	struct completion stop_bw_done;
	u32 get_dlc_info_cnt;
	struct completion wait_dn_ack;
	struct workqueue_struct *ai_msix_wq;
	struct workqueue_struct *enc_msix_wq;
	struct workqueue_struct *dec_msix_wq;
	struct workqueue_struct *vdsp_msix_wq;
	struct work_struct d2d_work;
};

enum IRQ_TYPE {
	VASTAI_INVALID_IRQ = 0,
	VASTAI_LEGACY_IRQ  = 1,
	VASTAI_MSI_IRQ     = 2,
	VASTAI_MSIX_IRQ    = 3
};

enum CMD_BUF_OBJ{
	CMD_BUF_DMA_RD_CH_LO,
	CMD_BUF_DMA_WR_CH_LO,
	CMD_BUF_DMA_HI,
	CMD_BUF_AI,
	CMD_BUF_SMCU,
	CMD_BUF_VEMCU,
	CMD_BUF_GMCU_MSGQ_TRIGER,
	CMD_BUF_MAX,
};


typedef enum ONLY_1PF_RING_BUF_OBJ{
	ONLY_1PF_HOST_TO_SMCU_CMD_BUF,
	ONLY_1PF_HOST_TO_CMCU_CMD_BUF,
	ONLY_1PF_HOST_TO_VEMCU0_CMD_BUF,
	ONLY_1PF_HOST_TO_VEMCU1_CMD_BUF,
	ONLY_1PF_HOST_TO_VEMCU2_CMD_BUF,
	ONLY_1PF_HOST_TO_VEMCU3_CMD_BUF,
	ONLY_1PF_HOST_TO_VDSP0_CMD_BUF,
	ONLY_1PF_HOST_TO_VDSP1_CMD_BUF,
	ONLY_1PF_HOST_TO_ODSP0_CMD_BUF,
	ONLY_1PF_HOST_TO_ODSP1_CMD_BUF,
	ONLY_1PF_HOST_TO_VDMCU0_CMD_BUF,
	ONLY_1PF_HOST_TO_VDMCU1_CMD_BUF,
	ONLY_1PF_HOST_TO_GMCU1_CMD_BUF,
	ONLY_1PF_HOST_TO_GMCU3_CMD_BUF,
	ONLY_1PF_SMCU_TO_HOST_INFO_BUF,
	ONLY_1PF_CMCU_TO_HOST_INFO_BUF,
	ONLY_1PF_VEMCU0_TO_HOST_INFO_BUF,
	ONLY_1PF_VEMCU1_TO_HOST_INFO_BUF,
	ONLY_1PF_VEMCU2_TO_HOST_INFO_BUF,
	ONLY_1PF_VEMCU3_TO_HOST_INFO_BUF,
	ONLY_1PF_VDSP0_TO_HOST_INFO_BUF,
	ONLY_1PF_VDSP1_TO_HOST_INFO_BUF,
	ONLY_1PF_ODSP0_TO_HOST_INFO_BUF,
	ONLY_1PF_ODSP1_TO_HOST_INFO_BUF,
	ONLY_1PF_VDMCU0_TO_HOST_INFO_BUF,
	ONLY_1PF_VDMCU1_TO_HOST_INFO_BUF,
	ONLY_1PF_GMCU1_TO_HOST_INFO_BUF,
	ONLY_1PF_GMCU3_TO_HOST_INFO_BUF,
	ONLY_1PF_DISPLAY_H2D_BUF,
	ONLY_1PF_DISPLAY_D2H_BUF,
	ONLY_1PF_RING_BUF_MAX,
}only_1pf_ring_buf_index;

typedef enum ONLY_2PF_RING_BUF_OBJ{
	ONLY_2PF_HOST_TO_SMCU_CMD_BUF,
	ONLY_2PF_HOST_TO_CMCU_CMD_BUF,
	ONLY_2PF_HOST_TO_1ST_VEMCU_CMD_BUF,
	ONLY_2PF_HOST_TO_2ND_VEMCU_CMD_BUF,
	ONLY_2PF_HOST_TO_1ST_VDSP_CMD_BUF,
	ONLY_2PF_HOST_TO_2ND_VDSP_CMD_BUF,
	ONLY_2PF_HOST_TO_VDMCU_CMD_BUF,
	ONLY_2PF_HOST_TO_GMCU_CMD_BUF,
	ONLY_2PF_SMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_CMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_1ST_VEMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_2ND_VEMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_1ST_VDSP_TO_HOST_INFO_BUF,
	ONLY_2PF_2ND_VDSP_TO_HOST_INFO_BUF,
	ONLY_2PF_VDMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_GMCU_TO_HOST_INFO_BUF,
	ONLY_2PF_DISPLAY_H2D_BUF,
	ONLY_2PF_DISPLAY_D2H_BUF,
	ONLY_2PF_RING_BUF_MAX,
}only_2pf_ring_buf_index;

typedef enum COMMON_RING_BUF_OBJ{
	COMMON_HOST_TO_SMCU_CMD_BUF,
	COMMON_HOST_TO_CMCU_CMD_BUF,
	COMMON_HOST_TO_VEMCU_CMD_BUF,
	COMMON_HOST_TO_VDSP_CMD_BUF,
	COMMON_HOST_TO_VDMCU_CMD_BUF,
	COMMON_HOST_TO_GMCU_CMD_BUF,
	COMMON_SMCU_TO_HOST_INFO_BUF,
	COMMON_CMCU_TO_HOST_INFO_BUF,
	COMMON_VEMCU_TO_HOST_INFO_BUF,
	COMMON_VDSP_TO_HOST_INFO_BUF,
	COMMON_VDMCU_TO_HOST_INFO_BUF,
	COMMON_GMCU_TO_HOST_INFO_BUF,
	COMMON_RING_BUF_MAX,
}common_ring_buf_index;

typedef enum rdma_memory_type {
    rdmaDevMem  = 0,
    rdmaHostMem = 1
} rdma_mem_type_t;

/* *
 * 1. manager power
 * 2. manager bar
 * 3. manager irq
 * */

struct vastai_minor_info {
	struct list_head dev_list;
	u32 minor;
};

struct vastai_seq_list {
	unsigned char seq_size;
	u8 seqId;
};

typedef int(*get_dev_host_addr_func)(int, struct dma_buf*, u64*, u64*, void*,u32);
typedef int(*set_desc_func_new)(struct vastai_dmadesc*,
					void*,
					u64*, u32,
					u64*);

struct vastai_interrupt_handle {
	void (*handler_function)(void *);
	void *arg;
};

struct va_dma_table {
	spinlock_t lock;
	struct list_head head;
};

typedef void (*va_host_irq_callback_t)(void *arg, struct host_irq_msg *msg);
struct va_host_irq {
	va_host_irq_callback_t callback;
	void *arg;
};


typedef uint64_t (*alloc_physmem_by_ddk) (void *dev_node, int ui32MemSize, int pid);
typedef void (*free_physmem_by_ddk) (void *dev_node, uint64_t DevPhysAddr);
#define VASTAI_LOG_MAX_CORE 17

#ifdef CONFIG_VASTAI_TOOLS_SUITE
struct tools_info_s {
	u32 smi_ack_msg[2]; /*smi ack from smcu*/
	struct completion smi_ack[2]; /*smi ack from smcu*/
	struct completion core_time_sync_ack; /*core time sync ack from smcu*/
	struct mutex tools_dev_mutex; /* tools device mutex */
	struct mutex tools_die_mutex; /* tools die mutex */
	struct completion log_comp;
	u32 pcie_tx_vdsp_count[4];
	u32 pcie_rx_vdsp_count[4];
	u32 ddr_bw_test;
};
#endif
struct vastai_pci_info;

#define ADDR(priv, mem) ((priv)->addr->mem)

struct vastai_addr_info {
	u32 HEARTBEAT_CNT_REG_NUM;
	u64 VASTAI_SMCU_BOOT_STAGE_REG;
	u64 VASTAI_HOST_BOOT_STAGE_REG;
	u64 VASTAI_BL1_DL_ADDR;
	u64 VSERSION_INFO_BASE;
	u64 INFO_LOG_ADDR;
	const u8 *bl1_hex_buf;
	const u8 *fw_hex_buf;
	const u8 *bmcu_hex_buf;
	u8  *BL1_PATH;
	u8  *BMCU_PATH;
	size_t bl1_size;
	size_t cmd_size;
	struct vastai_pci_test_info *test_info;
	char *FW_PATH;
	size_t fw_size;
	size_t bmcu_size;
	u64    DDR_BASE_ADDR;
	u64    VASTAI_FW_DL_OFFSET;
	u8  die_config_tab_size;
	struct vastai_die_cfg *die_cfg;
	struct vastai_stage_mapping *boot_process;
	int boot_size;
	u8 VASTAI_PCIE_MSIX_NUM;
	u32 dma_type;
	int *dma_desc_credit;
	u64 (*p_trans_addr)(struct vastai_pci_info *priv, int die_id,
					u64 rel_addr, u64 abs_addr);
	int (*p_select_bar)(struct vastai_pci_info *priv, int die_id,
					u64 addr, int *bar, u64 *offset);
	int (*p_probe_pre_check)(struct pci_dev *pdev, const struct pci_device_id *id);
	void (*p_probe_entery_print)(struct pci_dev *pdev, const struct pci_device_id *id);
	void (*p_probe_init_mem)(struct vastai_pci_info *priv);
	int (*p_alloc_ob_addr)(struct vastai_pci_info *priv);
	void (*p_excetion_init)(struct vastai_pci_info *priv);
	void (*p_set_payload_work)(struct vastai_pci_info *priv);
	void (*p_cancel_payload_work)(struct vastai_pci_info *priv);
	void (*p_free_ob_addr)(struct vastai_pci_info *priv);
	int (*p_vacc_init)(void *pcie_dev, unsigned int die_index);
	void (*p_vacc_exit)(void *pcie_dev);
	int (*p_video_init)(void *pcie_dev, unsigned int die_id, unsigned int* render_id);
	void (*p_video_exit)(struct vastai_pci_info *pcie_dev);
	int (*p_tools_init)(void *priv);
	void (*p_tools_exit)(void *priv);
	int (*is_vastai_mempool_rich)(struct vastai_pci_info *pci_info);
	int (*p_dma_transfer_sync)(struct vastai_pci_info *pci_info, int die_index,
				 union core_bitmap core_id,
				 struct vastai_dmadesc desc[], int desc_num, int pid);
};

struct vastai_stage_mapping {
	u32 smcu_polling_stage;
	int (*p_func)(struct vastai_pci_info *priv, u8 die_id, int *next_state);
	void (*p_func_polling_failed)(struct vastai_pci_info *priv, u8 die_id);
};

struct fn_tree_node {
	struct list_head parent_node;
	struct list_head internal_node;
	struct vastai_die_info *die_info; /* parent */
	struct vastai_pci_info *priv;
};

struct vastai_pci_info {
	struct list_head dev_list;
	char dev_id;
	bool dev_id_flag;
	u8 is_pf:1;
	u8 is_vf:1;
	struct pci_dev *dev;
	struct char_drv_info *p_char;
	struct vastai_version_file *version_file;
	struct vastai_version_file *device_info_file;
	struct vastai_ctl_file *ctl_file;
	unsigned char irq_type;
	unsigned int irq;
	int irq_num;
	unsigned char die_num;
	unsigned char die_num_in_fn;
	unsigned char pf_num_per_card;
	unsigned char boot_stage;
	unsigned char bar_num;
	unsigned long long ddr_attr;
	unsigned long long ddr_min_addr;
	unsigned long long ddr_max_addr;
	char sn[SN_LEN];
	char card_type[TYPE_LEN];
	spinlock_t msgq_1_lock; /* need move to die */
	struct completion set_bar_done;
	struct msix_entry msix[VASTAI_PCIE_MSIX_SV100_NUM];
	struct msi_x_table msix_table[VASTAI_PCIE_MSIX_SV100_NUM];
	struct bar_info bar[VASTAI_PCI_BAR_NUM];
	struct vastai_dev_info vadev;
	struct vastai_sv100_die dies[VASTAI_SV100_MAX_DIE_NUM];
	struct heartbeat_monitor heartbeat; /* need move to die */
	struct list_head vacc_dev_head; // the head of vastai_cdev list
	u8 disable;
	bool ddr_bw_test;
	struct vastai_mem_pool *vastai_pool;
	struct vastai_mem_pool_ex *vastai_pool_ex;
	atomic_t pci_state;
	bool iommu_en;
	struct list_head render_head;
	struct timer_list pci_timer; /* run each 10s */
	struct bbox_info bbox_info;
	struct vastai_addr_info *addr;

	struct timer_list vf_timer;
	bool is_physfn;
	bool is_virtfn;
	u32 vf_bdf;
	struct vf_fifo_info vf_fifo;
	struct completion activate_vf_done;
	struct completion deactivate_vf_done;
	struct completion get_dlc_core_done;

	struct pci_link_monitor pci_link_stat;
	unsigned long dma_log_addr;
	unsigned long dma_log_vir;
	u32 max_dma_node_size;
	get_dev_host_addr_func pDmaStartGetDevHostAddr;
	set_desc_func_new pDmaStartSetDescFunc;

	struct vastai_mem_pool *vccl_pool;

	spinlock_t file_lock;           /* lock for open files */
	struct list_head file_list;     /* list of open files */
	struct delayed_work bmcu_timeout_work;
	u64 bmcu_dl_addr;
	u64 bl0_dl_addr;
	u64 bl0_read_addr;

	atomic_t is_fw_updating;
	const struct pci_device_id *id;
	struct completion tc_type_comp;  //transcoding
	int tc_type;                     //transcoding type

	struct mutex trans_mutex;
	struct mutex mmio_read_mutex;
	struct mutex mmio_write_mutex;
	spinlock_t mmio_read_spin_lock;
	spinlock_t mmio_write_spin_lock;
	spinlock_t trans_lock;
	spinlock_t swtich_atu_lock;
	spinlock_t ring_buf_lock;
	struct completion swtich_atu_done;
	struct completion read_csr_by_smcu_done;
	struct completion write_csr_by_smcu_done;
	struct completion rw_xspi;
	struct completion pcie_monitor_done;
	struct completion ddr_monitor_done;
	struct completion send_reinit_rst_done;
	struct delayed_work payload_work;
	struct va_dma_table dma_table;

	struct priv_hw_cfg *priv_hw_cfg;
	u8 pkg_id;
	u8 fn_mode;
#if CONFIG_D2H_BY_GART_OR_ATU
	bool hasInitGfxMemAlloc;
	void *heapPtr;
	u64  (*AllocMemFromGfxHeap)(void *heapPtr, int size);
	void (*FreeMemToGfxHeap)(void *heapPtr, u64 addr);
#endif
	struct vastai_interrupt_handle irq_handles[VASTAI_PCIE_MSIX_SV100_NUM];
	struct hw_msgq *to_host_msgq;
	struct ring_buf_info   *ring_buf[ONLY_1PF_RING_BUF_MAX];
	struct vastai_cmd_entry *cmd_entrys[CMD_BUF_MAX];
	struct va_host_irq *host_irqs[HOST_IRQ_MAX];
	struct platform_device *gfx_card_dev;
	struct platform_device *nulldisp_dev;
	struct smmu_info *vastai_smmu_info;

#ifdef CONFIG_VASTAI_TOOLS_SUITE
	struct tools_info_s tools_info;
#endif

	alloc_physmem_by_ddk alloc; /*mem alloc api of ddk*/
	free_physmem_by_ddk free;   /*mem free api of ddk*/
	void *ddk_node;   /*ddk pvr dev node*/
	u32 read_csr_value_by_smcu;
	struct proc_dir_entry *mcu_log_ent[VASTAI_LOG_MAX_CORE];
#ifdef CONFIG_PVP_HASH_CMP_EN
	struct mutex cedar_lock;
#endif
	u32 rw_xspi_msg;
	u32 waiting_cmcu_comback;
	void *vacc_dev;
	u32 core_status_bitmap;
	struct work_struct exception_work;
	board_type_e board_type;
	struct completion switch_atu_comp;
	struct ai_info   *vastai_ai_info;
	int (*p_select_bar)(struct vastai_pci_info *priv, int die_id,
					u64 addr, int *bar, u64 *offset);
	u64 (*p_trans_addr)(struct vastai_pci_info *priv, int die_id,
					u64 rel_addr, u64 abs_addr);
	struct vastai_fw_version_sg fw_ver;
	struct completion bmcu_update_comp;
	int bmcu_return_val;
	bool boot_failed_flag;
	struct mutex set_bar_lock;
	struct semaphore credit_sem;
	void *dma_dev;
	struct list_head fn_node;
	struct list_head fn_node_list;
	bool probe_done;
	u16 bitmap_dl_support;
	bool is_super_pf;
	bool force_single_die;
	struct semaphore mempool_sem;
	struct work_struct boot_work;
	bool is_in_vm;
	bool flr_is_en;
	struct list_head tools_dev_list;
	bool not_hotreset;
	bool ai_video_workqueue_enable;
	u64 vatool_ddr_mem_wrtest_size;
	u64 vatool_ddr_mem_wrtest_addr;
};

typedef union vastai_pci_bdf_info {
	u64 whole;
	struct {
		u64 fn_id: 4;
		u64 dev_id: 8;
		u64 bus_id: 8;
		u64 domain_id: 32;
		u64 reserved: 12;
	};
} vastai_pci_bdf_info_t;


struct vastai_die_info {
	struct list_head die_node;
	spinlock_t fn_info_list_lock;
	struct list_head vastai_fn_info_list;
	u8 die_id_in_card;
	struct list_head fn_parent_list_node;
	struct vastai_pkg_info *pkg_info; /*parent*/
};

struct vastai_pkg_info {
	struct list_head pkg_node;
	spinlock_t die_info_list_lock;
	struct list_head vastai_die_info_list;
	u8 pkg_id;
	struct vastai_card_info *card_info; /*parent*/
};

struct vastai_card_info {
	struct list_head card_node;
	struct list_head vastai_pkg_info_list;
	atomic_t pci_state;
	board_type_e board_type;
	vastai_pci_bdf_info_t bdf_info;
	u8 sn_info[SN_LEN];
	u8 die_num_in_card;
	u8 pkg_num_in_card;
	atomic_t inventory_cached_flag;
	u8 inventory[4096];
	u8 card_id;
	char dev_id_base;
	char dev_id_set_flag;
	u8 fn_num;
};

enum DEVICE_STATE {
	VASTAI_NO_RUN_STATE = 0,
	VASTAI_NORMAL_STATE = 1,
	VASTAI_UPDATE_STATE = 2,
	VASTAI_BOOT_STATE = 3,
	VASTAI_EXIT_STATE = 4,
	VASTAI_ERROR_STATE = 5,
	VASTAI_RESET_STATE = 6,
	VASTAI_DEBUG_STATE = 7,
	VASTAI_HOTP_STATE = 8,
};

enum BW_TYPE {
	BW_H_WITH_D_TYPE     = 0,
	BW_D_WITH_D_TYPE     = 1,
	BW_PKG_WITH_PKG_TYPE = 2,
};


struct inbound_reg {
	unsigned int type; /* region contril 1 ;0:mem, 2:i/o 4:cfg */
	unsigned int en; /* region contril 2 [10:8]:BAR_NUM, */
	unsigned int lower_base_addr;
	unsigned int upper_base_addr;
	unsigned int limit;
	unsigned int lower_target_addr;
	unsigned int upper_target_addr;
} __packed;

struct outbound_reg {
	unsigned int type;
	unsigned int en;
	unsigned int lower_base_addr;
	unsigned int upper_base_addr;
	unsigned int limit;
	unsigned int lower_target_addr;
	unsigned int upper_target_addr;
} __packed;



// command number used in FW
#define CMD_RUN_MODEL	  0x40185602
#define CMD_RUN_STREAM	  0x40185603
#define CMD_LOAD_MODEL	  0x40185604
#define CMD_DESTROY_MODEL 0x40185605
#define CMD_LOAD_VDSP_OPERATOR 0x40185606
#define CMD_LOAD_ODSP_OPERATOR 0x40185607
#define CMD_RUN_KERENL	  0x40185608
#define CMD_LOAD_OPERATOR 0x40185609
#define CMD_CANCEL_KENREL 0x4018560A


int vastai_pci_get_sriov_numvfs(char dev_id);

struct vastai_pci_info *get_vastai_pci_device_info(char dev_id);
#ifdef CONFIG_VASTAI_TOOLS_SUITE
int get_vastai_pci_device_number(void);
int vatools_fw_config_smi(struct vastai_pci_info *priv, int die_index);
int vatools_device_event_callback(u32 die_index, u32 core_bit, u32 event);
#endif
int vastai_pci_reset_bus(struct vastai_pci_info *pcie_dev);
void vastai_pci_set_vdsp_depth(struct vastai_pci_info *priv, u32 die_id,
			       u32 elem_count, u32 flag);
void vastai_pci_set_vdsp_2st_depth(struct vastai_pci_info *priv, u32 die_id,
			       u32 elem_count, u32 flag);
void vastai_pci_set_odsp_depth(struct vastai_pci_info *priv, u32 die_id,
					 u32 elem_count);
void vastai_pci_set_cmcu_depth(struct vastai_pci_info *priv, u32 die_id, u32 elem_count);
void vastai_pci_init_bar_at(struct vastai_pci_info *priv, int bar);
void vastai_pci_init_all_die(struct vastai_pci_info *priv);
int vastai_pci_config_read(struct vastai_pci_info *pcie_dev, int offset,
			   char *buf, int len);
int vastai_pci_config_write(struct vastai_pci_info *pcie_dev, int offset,
			    char *buf, int len);
int vastai_pci_mem_read(struct vastai_pci_info *pcie_dev, int die_index,
			u64 relative_addr, void *buf, unsigned int len);
int vastai_pci_mem_write(struct vastai_pci_info *pcie_dev, int die_index,
			 u64 relative_addr, const void *buf, unsigned int len);
int vastai_pci_mmio_read(struct vastai_pci_info *priv, int bar,
				 u64 offset, void *buf, unsigned int len);
int vastai_pci_mmio_write(struct vastai_pci_info *priv, int bar,
				u64 offset, void *buf,  unsigned int len);
int vastai_pci_generation_sel(struct vastai_pci_info *pcie_dev, u8 gen);
int vastai_pci_generation_sel_slave_die(struct vastai_pci_info *pcie_dev,
					u8 gen, u32 die_id);
int vastai_pci_malloc_udma_buf(struct vastai_pci_info *pcie_dev,
			       struct vastai_dma_buf *dm, u32 len);
int vastai_pci_free_udma_buf(struct vastai_pci_info *pcie_dev,
			     struct vastai_dma_buf *dm);
void vastai_clear_fifo(void *pci_info, int die_index, int core_idx);
int va_register_pcie_interrupt(struct vastai_pci_info *priv,
				  u32 interrupt_id,
				  void (*handler_function)(void *),
				  void *arg);
int va_unregister_pcie_interrupt(struct vastai_pci_info *priv,
				 u32 interrupt_id);
struct vastai_card_info *vastai_get_card_info(struct vastai_pci_info *priv);
struct vastai_die_info *vastai_get_die_info(struct vastai_pci_info *priv, u8 die_id_in_fn);
struct vastai_pkg_info *vastai_get_pkg_info(struct vastai_pci_info *priv, u8 die_id_in_fn);
int vastai_is_slave_die(struct vastai_pci_info *priv, u8 die_id_in_fn, bool *slave_en);
bool vastai_is_super_pf(struct vastai_pci_info *priv);



/* This function will be used intead of vastai_pci_transfer_reg and
 * vastai_pci_transfer_reg_vd (declarate at vastai_pci_api.h).
 * For now if you call vastai_irq_register and
 * vastai_pci_transfer_reg/vastai_pci_transfer_reg_vd at the same time,
 * vastai_pci_transfer_reg/vastai_pci_transfer_reg_vd will take effect.
 */
int vastai_irq_register(struct vastai_pci_info *pcie_dev, /* which pcie_group */
			int die_index,
			int irq, /* reference vastai_sv100_reg.h +272 */
			vastai_intr_handle handle,
			void *private_data); /* for user keep self data */
int vastai_irq_unregister(struct vastai_pci_info *pcie_dev, int die_index,
			  int irq);

int vastai_pci_get_die_id(struct vastai_pci_info *pcie_dev, u32 die_index);
int get_vastai_die_info(struct vastai_pci_info *priv, int die_index[],
			int *die_num);

/* ========================api for dev_id version ============================*/
static inline int vastai_pci_info_get_dev_id(struct vastai_pci_info *pcie_dev)
{
	return pcie_dev->dev_id;
}

static inline int vastai_pci_info_get_die_num(struct vastai_pci_info *pcie_dev)
{
	return pcie_dev->die_num_in_fn;
}

/* This function returns the attributes of the DDR used by each DIE in each PCIE device:
 * e.g.
 * return 0x1_0000_0000 means ddr density is 4GB;
 * return 0x2_0000_0000 means ddr density is 8GB;
 * return 0x4_0000_0000 means ddr density is 16GB.
 */
static inline u64 vastai_pci_info_get_ddr_attr(struct vastai_pci_info *pcie_dev)
{
	return pcie_dev->ddr_attr;
}

extern bool uaddr_linklist_en;
extern int dma_desc_credit;
static inline bool vastai_module_para_uaddr_ll(void)
{
	return uaddr_linklist_en;
}

static inline int vastai_module_para_dma_desc_credit(void)
{
	return dma_desc_credit;
}

int is_vastai_mempool_rich_sg(struct vastai_pci_info *pci_info);


typedef struct PCIE_cbits_s {
	/** Control bits */
	uint8_t control_bits;
} PCIE_cbits;

/** uDMA transfer size and control byte */
typedef struct PCIE_sz_ctrl_s {
	/** Number of bytes to be transferred.  For max bulk transfer size, set
	 * to zero */
	uint32_t size : 24;
	/** Control byte */
	PCIE_cbits ctrl_bits;
} PCIE_sz_ctrl;

/** uDMA status bytes */
typedef struct PCIE_sbytes_s {
	/** System (local) bus status */
	uint8_t sys_status;
	/** External (remote) bus status */
	uint8_t ext_status;
	/** uDMA channel status */
	uint8_t chnl_status;
	/** Reserved */
	uint8_t reserved_0;
} PCIE_sbytes;

/** uDMA Descriptor structure */
struct PCIE_xd_desc_s {
	/** Low 32 bits of system address */
	uint32_t sys_lo_addr;
	/** High 32 bits of system address */
	uint32_t sys_hi_addr;
	/** Access attributes for system bus */
	uint32_t sys_attr;
	/** Low 32 bits of external address */
	uint32_t ext_lo_addr;
	/** High 32 bits of external address */
	uint32_t ext_hi_addr;
	/** Access attributes for external bus */
	uint32_t ext_attr;
	/** High 32 bits of access attributes for external bus */
	uint32_t ext_attr_hi;
	/** Transfer size and control byte */
	PCIE_sz_ctrl size_and_ctrl;
	/** Transfer status.  This word is written by uDMA engine, and can be
	 * read to determine status. */
	PCIE_sbytes status;
	/** Low 32bits of pointer to next descriptor in linked list */
	uint32_t next;
	/** High 32bits of pointer to next descriptor in linked list */
	uint32_t next_hi_addr;
	uint32_t trans_info_addr;
};

typedef struct PCIE_xd_desc_s PCIE_xd_desc;
unsigned long vastai_pci_copy_to_user(void __user *to, const void *from, unsigned long n);
unsigned long vastai_pci_copy_from_user(void *to, const void __user *from, unsigned long n);
struct dma_buf *vastai_alloc_dma_buf(struct vastai_pci_info *pci_dev, int size);
struct dma_buf *vastai_alloc_dma_buf_sg(struct vastai_pci_info *pci_info, int size);
struct dma_buf *vastai_alloc_vccl_buf(struct vastai_pci_info *pci_info, int size, u64 *addr);
struct dma_buf *vastai_alloc_dma_buf_with_addr(struct vastai_pci_info *pci_info, int size, u64 *addr);
struct dma_buf *vastai_rdma_dmabuf_export(struct vastai_pci_info *pci_info,
						u32 die_index,
						u64 size,
						u64 *addr,
						rdma_mem_type_t mem_type);
int vastai_rdma_hostbuf_get(int fd, u32* buf_num, u64* buf_list);
struct vastai_dma_buf *get_vastai_dma_buf(struct dma_buf *dma_buf, u32 index);
int vastai_device_reset(struct vastai_pci_info *priv, u32 flags);
int vastai_send_pcie_cmd(struct vastai_pci_info *priv, u32 die_index,
			 u32 sub_cmd, u64 paras);
bool vastai_dev_not_ready(struct vastai_pci_info *priv);
int vastai_get_seqnum(struct vastai_pci_info *pdev, unsigned int die_id);

u32 vastai_get_dlc_cores_info(struct vastai_pci_info *pcie_info, u32 die_index);

void vastai_set_desc_link(struct vastai_pci_info *priv, unsigned int die_index,
			  u64 *desc_tab, int num);
int vastai_pci_data_movement(void *pcie_dev, int die_index, u64 local_addr,
			     u64 remote_addr, u32 len, bool is_local_2_remote);
void vastai_pci_get_fw_ver(struct vastai_pci_info *priv, u32 mask, bool origin_addr);
void vastai_pci_get_fw_ver_sg(struct vastai_pci_info *pci_info, u32 mask);
int vastai_wait_ecc_2_bit(struct vastai_pci_info *pdev,
			  union die_index_data die_index);
int vastai_pci_dma_transfer_memset(void *pci_info,
			int die_index,
			union core_bitmap core_id,
			dma_addr_t dma_handle,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size);

int vastai_pci_dma_transfer_sg(struct vastai_pci_info *pci_info, int die_index,
			union core_bitmap core_id,
			struct vastai_dma_buf *dm,
			u32 is_src_dma_addr,
			u32 is_host_to_dev,
			u32 is_src_not_user_mem,
			u64 axi_addr,
			u32 size);
int vastai_pci_dma_transfer_sg_start(struct vastai_pci_info *pci_info, void *dma_node,
			union core_bitmap core_id,
			struct dma_buf *dmabuf);
int vastai_pci_dma_transfer_by_uaddr(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u32 is_host_to_dev,
			u64 axi_addr,
			u64 user_addr,
			u32 size);
int vastai_pci_dma_transfer_by_uaddr_new(struct vastai_pci_info *pci_info,
					 union core_bitmap core_id,
					 dma_node_trans_cmd_t *dma_trans_cmd);

int vastai_dma_sg_set_desc(struct vastai_dmadesc* desc,
					u64 dma_len,
					u64 host_addr,
					u64 axi_addr,
					u32 is_host_to_dev,
					u32 is_src_not_user_mem,
					u32 is_src_dma_addr);
int va_get_card_info(struct char_drv_info *dev, struct vastai_pci_info *priv);
int vastai_sdma_fill_data(struct vastai_pci_info *pci_info,
			int die_index,
			union core_bitmap core_id,
			u64 axi_addr,
			u64 data,
			u32 size);



struct ecc_entry {
	u32 addr_1;
	u32 addr_h;
	u32 axi_id;
	u32 axi_data_l;
	u32 axi_data_h;
	u32 errbit;
};


struct vastai_file_info {
	char file_name[32];
	dev_t dev_num;
	struct cdev dev;
	struct class *class;
	struct device *device;
	struct vastai_pci_info *priv;
};

struct vastai_version_file {
	struct vastai_file_info file_info;
	struct vastai_pci_info *pci_info;
};

struct pid_entry {
	struct pid *pid;
	struct list_head node;          /* entry in list of open files */
	int refcount;
};

struct vastai_ctl_file {
	struct vastai_file_info file_info;
	struct vastai_pci_info *pci_info;
	struct pid_entry *pid_entry;
};

u64 vastai_get_pci_bdf_info(struct vastai_pci_info *pdev);
int vastai_get_pci_dev_count(void);

int vastai_file_create(struct vastai_file_info *file_info,
		       struct vastai_pci_info *pci_info,
		       const struct file_operations *fop, const char *fmt, ...);
void vastai_file_destroy(struct vastai_file_info *file_info);
#define to_vastai_file_info(ptr) container_of(ptr, struct vastai_file_info, dev)
dev_t vastai_file_get_major_minor(struct vastai_file_info *file_info);
int vastai_get_render_id(struct vastai_pci_info *pdev, u32 die_index);
int vastai_get_card_id(struct vastai_pci_info *pdev, u32 die_index);
int vastai_get_vacc_id(struct vastai_pci_info *pdev, u32 die_index);
int vastai_get_seq_num(struct vastai_pci_info *pdev, u32 die_id);
int vastai_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
			 u32 core_bit_map, u64 info);
void vastai_ctrl_cmd_compeletion(struct vastai_pci_info *pci_info,
				 u32 die_index, struct smcu_to_host_msg1 *msg);
u64 vastai_get_host_time_ns(void);
u32 vastai_pci_gen_die_index(void *pci_info, u32 die_id);
u32 vastai_pci_gen_die_index_parallel_die(struct vastai_pci_info *pci_info, u32 die_id);
int vastai_pci_mem_read_direct(struct vastai_pci_info *priv, int die_index,
			u64 relative_addr, void *buf, unsigned int len);
int vastai_pci_mem_bar2_read(struct vastai_pci_info *priv, int die_index, u64 absolute_addr,
				 void *buf, unsigned int len);
int vastai_pci_mem_bar2_write(struct vastai_pci_info *priv, int die_index, u64 absolute_addr,
				const void *buf, unsigned int len);
int vastai_pci_mem_write_direct(struct vastai_pci_info *priv, int die_index,
			 u64 relative_addr, const void *buf, unsigned int len);
int vastai_device_send_reset(struct vastai_pci_info *priv);
void vastai_pci_reset_bar_at(struct vastai_pci_info *priv, int die_index);

int vastai_bbox_set(struct vastai_pci_info *priv, u32 bbox);
u32 vastai_bbox_get(struct vastai_pci_info *priv);

void vastai_pci_link_monitor_init(struct vastai_pci_info *pci_info);
void vastai_pci_link_monitor_uninit(struct vastai_pci_info *pci_info);
void vastai_enable_pcie_link_monitor(struct vastai_pci_info *pci_info, bool enable);

int vastai_get_msgq_id(struct vastai_pci_info *priv, int type);
int vastai_mempool_ex_init(struct vastai_pci_info *pci_info);
void vastai_mempool_ex_deinit(struct vastai_pci_info *pci_info);
void vastai_show_mempool_ex(struct vastai_pci_info *pci_info);
void vastai_reset_mempool_ex(struct vastai_pci_info *pci_info);
int vastai_pci_receive_msg(void *pcie_dev, int die_index, int index, void *elem);
void * vastai_pci_mmio_kva_get(struct vastai_pci_info *priv,
					u32 die_index,
					u64 relative_addr,
					u32 len);
int vastai_read_by_smcu(struct vastai_pci_info *priv, u64 noc_addr, unsigned int len ,void *buf);
int vastai_write_4byte_by_smcu(struct vastai_pci_info *priv, u64 noc_addr, u32 val);

int vastai_pci_send_msg(void *pcie_dev,
			int die_index,
			int index,
			void *msg_buf, /* what's user want pcie send to device */
			u32 msg_len);
int vastai_version_file_init(struct vastai_pci_info *pci_info);
void vastai_version_file_deinit(struct vastai_pci_info *pci_info);

int vastai_device_info_init(struct vastai_pci_info *pci_info);
void vastai_device_info_deinit(struct vastai_pci_info *pci_info);
int vastai_global_device_info_init(void);
void vastai_global_device_info_deinit(void);



void vastai_reset_handle_reg(vastai_reset_handle handle);
void vastai_video_reset_handle_reg(vastai_reset_handle handle);

int vastai_pci_modify_reg32(struct vastai_pci_info *priv,u64 addr,u32 mask_bit,u32 mode);
int vastai_smcu_modify_reg32(struct vastai_pci_info *priv,u64 addr,u32 mask_bit,u32 mode);

int vastai_ddr_to_bar(struct vastai_pci_info *priv, int die_index, u64 ddr_addr, u64 *bar_addr);

int vastai_pci_flr(struct vastai_pci_info *priv);

void dump_bar_addr_map(struct vastai_pci_info *priv);

void dump_pf_vf_map_kchar(struct vastai_pci_info *priv);

int vastai_slave_config_read(struct vastai_pci_info *priv, u64 offset, void *buf,  unsigned int len);

int vastai_slave_config_write(struct vastai_pci_info *priv, u64 offset, void *buf,  unsigned int len);

int vastai_pci_mem_fread(struct vastai_pci_info *priv,
						u64 fn_addr,
						void *buf,
						unsigned int len);
int vastai_pci_mem_fwrite(struct vastai_pci_info *priv,
						u64 fn_addr,
						void *buf,
						unsigned int len);

int translate_fn_addr(struct vastai_pci_info *priv,
							u64 fn_addr,
							int *bar,
							u64 *bar_offset,
							int *region_num);
int vastai_cii_set(struct vastai_pci_info *priv, u32 ch, u32 addr, u32 pf);
u64 vastai_pci_cal_absolute_addr(struct vastai_pci_info *priv, int die_id,
					u64 rel_addr, u64 abs_addr);


int vastai_dev_cedar_send_cmd(void *pci_info, void *cedar_info, int dev_id, int die_id, void *hash_output);


void event_notify(struct vastai_pci_info *priv, u32 die_index, u32 core_bit, reset_event event);
void vastai_clear_exception_status(struct vastai_pci_info *priv);

int vastai_qurik_init(struct vastai_pci_info *priv);

void vastai_pci_set_dma_irq_agg(
				struct vastai_pci_info *priv,
				u32 agg_num,
				u32 agg_time_ms);

int vastai_get_upstream_pcie_bw(struct vastai_pci_info *priv, u32 die_id_in_fn, int type, u64 *upstream_count);

int vastai_get_downstream_pcie_bw(struct vastai_pci_info *priv, u32 die_id_in_fn, int type, u64 *downstream_count);

bool vastai_pci_compare_pcie_link_in_dies(struct vastai_pci_info *priv);

u32 vatsai_pci_reset_type(struct vastai_pci_info *priv);

int vastai_get_share_mem_bank_num(struct vastai_pci_info *priv);

int vastai_get_share_mem_bank_info(struct vastai_pci_info *priv,
					int bank_idx, u64  *start, u64 *end);
int vastai_get_model_mem_num(struct vastai_pci_info *priv);

int vastai_get_model_mem_info(struct vastai_pci_info *priv,
					int model_idx, u64  *start, u64 *len);
int vastai_get_model_mem_offset		(struct vastai_pci_info *priv, int model_idx, u64 *offset);

int vastai_get_model_entry_addr		(struct vastai_pci_info *priv, int model_idx,	u64  *start);

int vastai_get_odsp_op_info(struct vastai_pci_info *priv, int odsp_idx,
						u64  *start, u64 *len);

void vastai_remove_hotplug_handle(struct vastai_pci_info *priv);
int vastai_del_file(struct vastai_pci_info *pci_info);
#endif /* end of __VASTAI_PCI_H__ */
