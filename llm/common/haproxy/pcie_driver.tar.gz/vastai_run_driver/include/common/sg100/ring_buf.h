#ifdef SG100_USED
#ifndef     __RING_BUF_H__
#define     __RING_BUF_H__

#include <stdio.h>
#include <xtensa/xtensa-types.h>
#include "sg100_type.h"
#define USE_FULL_ASSERT 0

#if USE_FULL_ASSERT
    #define assert_param(expr) ((expr) ? (void)0 : assert_failed((unsigned char*)__FILENAME__, __LINE__))
#else
    #define assert_param(expr) ((void)0)
#endif

#if USE_FULL_ASSERT
void assert_failed(unsigned char* file, u32 line);
#endif

typedef struct ring_buf_struct
{
   volatile u32 rd;
   volatile u32 wr;
   volatile u32 elem_count;
   volatile u32 elem_size;
#ifndef _WIN32
   volatile u8  buf[0]; /* this will not be used at host driver */
#endif
} ring_buf_t;

static inline u8 ring_buf_is_full(volatile ring_buf_t *fifo)
{
    return ((fifo->wr + 1) % (fifo->elem_count) == (fifo->rd));
}

static inline u8 ring_buf_is_empty(volatile ring_buf_t *fifo)
{
    return ((fifo->wr) == (fifo->rd));
}

#if 1
//currently unused ring buf api.
static inline u32 ring_buf_wr_pre_fetch(volatile ring_buf_t *fifo)
{
    return ((u32)(fifo->buf) + fifo->elem_size * fifo->wr);
}

static inline u32 ring_buf_wr_next(volatile ring_buf_t *fifo)
{
    u32 ret = (u32)(fifo->buf) + fifo->elem_size * fifo->wr;
    fifo->wr = (fifo->wr + 1) % (fifo->elem_count);
    return ret;
}

static inline u32 ring_buf_rd_pre_fetch(volatile ring_buf_t *fifo)
{
    return ((u32)(fifo->buf) + fifo->elem_size * fifo->rd);
}

static inline u32 ring_buf_rd_next(volatile ring_buf_t *fifo)
{
    u32 ret = (u32)(fifo->buf) + fifo->elem_size * fifo->rd;
    fifo->rd = (fifo->rd + 1) % (fifo->elem_count);
    return ret;
}
#endif

/***********************************************************************************************************************
*   Description:    return The number of elements in the ring buffer
*   parameter:      ring_buf          [OUT]             ...
*   return:         none
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
static inline uint32_t ring_buf_elem_num(volatile ring_buf_t *fifo)
{
    return ((fifo->wr + fifo->elem_count - fifo->rd) % (fifo->elem_count));
}



#if 0
struct vastai_fifo {
    u32 rd;
    u32 wr;
    u32 elem_count;
    u32 elem_size;
#ifndef _WIN32
    u8 buf[0]; /* this will not be used at host driver */
#endif
};

static inline int vastai_fifo_len(volatile struct vastai_fifo *fifo)
{    
    return fifo->rd < fifo->wr ? fifo->wr - fifo->rd : fifo->rd - fifo->wr;
}

/* Return zero: fifo is ok.
   Return no-zero: fifo is not ok */
static inline int vastai_fifo_check(volatile struct vastai_fifo *fifo)
{
    if ((fifo->rd >= fifo->elem_count) || (fifo->wr >= fifo->elem_count)) {
        return -1;
    }
    return 0;
}

static inline u8 vastai_fifo_is_full(volatile struct vastai_fifo *fifo)
{
    return ((fifo->wr + 1) % (fifo->elem_count) == (fifo->rd));
}

static inline u8 vastai_fifo_is_empty(volatile struct vastai_fifo *fifo)
{
    return ((fifo->wr) == (fifo->rd));
}

static inline u32 vastai_fifo_wr_pre_fetch(volatile struct vastai_fifo *fifo)
{
    return ((u32)(fifo->buf) + fifo->elem_size * fifo->wr);
}

static inline u32 vastai_fifo_wr_next(volatile struct vastai_fifo *fifo)
{
    u32 ret = (u32)(fifo->buf) + fifo->elem_size * fifo->wr;
    fifo->wr = (fifo->wr + 1) % (fifo->elem_count);
    return ret;
}

static inline u32 vastai_fifo_rd_pre_fetch(volatile struct vastai_fifo *fifo)
{
    return ((u32)(fifo->buf) + fifo->elem_size * fifo->rd);
}

static inline u32 vastai_fifo_rd_next(volatile struct vastai_fifo *fifo)
{
    u32 ret = (u32)(fifo->buf) + fifo->elem_size * fifo->rd;
    fifo->rd = (fifo->rd + 1) % (fifo->elem_count);
    return ret;
}
#endif

//can be changed to enum all error, not only ring buf error. @rui.zhong
typedef enum ring_buf_err_enum {
    ERR_NONE = 0,
    ERR_RING_BUF_FULL,
    ERR_RING_BUF_EMPTY,
    ERR_RING_BUF_ELEM_SIZE_NOT_MATCH,
    ERR_BUTT
} ring_buf_err_t;

void ring_buf_init(volatile ring_buf_t *ring_buf, uint32_t elem_count, uint32_t elem_size);
void ring_buf_deinit(volatile ring_buf_t *ring_buf);
void ring_buf_read_flush(volatile ring_buf_t *ring_buf);
ring_buf_err_t ring_buf_enqueue(volatile ring_buf_t *ring_buf, void *elem, size_t elem_size);
ring_buf_err_t ring_buf_dequeue(volatile ring_buf_t *ring_buf, void *elem, size_t *elem_size);

#endif // end of this file
#endif /* SG100_USED */
