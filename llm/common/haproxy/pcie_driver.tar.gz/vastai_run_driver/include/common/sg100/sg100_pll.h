#ifdef SG100_USED
 /*
 * vastai_pll.h
 *
 *  Created on:
 *      Author: zy
 */

#ifndef __VASTAI_PLL_H__
#define __VASTAI_PLL_H__
#include 	"sg100_type.h"
#include 	"hw_config.h"

/****************************************************************************************/
#define 	VDSP_VCLK_DCLK_ALL_IN_LEFT_PLL2   	0

#define		KHz				(1000UL)
#define		MHz				(1000*1000ULL)
#define		GHz				(1000*1000*1000ULL)

#define		DEF_PCLK		(200*1000*1000U)	//pclk default is 200MHz
#define		DEF_REF_CLK25M	(25*1000*1000U)
#define		DEF_REF_CLK100M	(100*1000*1000U)	//default ref clk is 100Mhz or 25Mhz

#define		SMU_CLK_FREQ				(SMU_BASE_ADDR +160*4)		//RO	0-100M,1--25m

#define LEFT_PLL0_PIN0		(SMU_LEFT_PLL_ADDR + 1*4)
#define LEFT_PLL0_PIN1		(SMU_LEFT_PLL_ADDR + 2*4)
#define LEFT_PLL0_PIN3		(SMU_LEFT_PLL_ADDR + 4*4)

#define LEFT_PLL1_PIN0		(SMU_LEFT_PLL_ADDR + 5*4)
#define LEFT_PLL1_PIN1		(SMU_LEFT_PLL_ADDR + 6*4)
#define LEFT_PLL1_PIN3		(SMU_LEFT_PLL_ADDR + 8*4)

#define LEFT_PLL2_PIN0		(SMU_LEFT_PLL_ADDR + 9*4)
#define LEFT_PLL2_PIN1		(SMU_LEFT_PLL_ADDR + 10*4)
#define LEFT_PLL2_PIN3		(SMU_LEFT_PLL_ADDR + 12*4)

#define BOTTOM_PLL0_PIN0	(SMU_BOTTOM_PLL_ADDR + 1*4)
#define BOTTOM_PLL0_PIN1	(SMU_BOTTOM_PLL_ADDR + 2*4)
#define BOTTOM_PLL0_PIN3	(SMU_BOTTOM_PLL_ADDR + 4*4)

#define BOTTOM_PLL1_PIN0	(SMU_BOTTOM_PLL_ADDR + 5*4)
#define BOTTOM_PLL1_PIN1	(SMU_BOTTOM_PLL_ADDR + 6*4)
#define BOTTOM_PLL1_PIN3	(SMU_BOTTOM_PLL_ADDR + 8*4)

#define BOTTOM_PLL2_PIN0	(SMU_BOTTOM_PLL_ADDR + 9*4)
#define BOTTOM_PLL2_PIN1	(SMU_BOTTOM_PLL_ADDR + 10*4)
#define BOTTOM_PLL2_PIN3	(SMU_BOTTOM_PLL_ADDR + 12*4)


#define RIGHT_PLL0_PIN0		(SMU_RIGHT_PLL_ADDR + 1*4)
#define RIGHT_PLL0_PIN1		(SMU_RIGHT_PLL_ADDR + 2*4)
#define RIGHT_PLL0_PIN3		(SMU_RIGHT_PLL_ADDR + 4*4)

#define RIGHT_PLL1_PIN0		(SMU_RIGHT_PLL_ADDR + 5*4)
#define RIGHT_PLL1_PIN1		(SMU_RIGHT_PLL_ADDR + 6*4)
#define RIGHT_PLL1_PIN3		(SMU_RIGHT_PLL_ADDR + 8*4)

#define RIGHT_PLL2_PIN0		(SMU_RIGHT_PLL_ADDR + 9*4)
#define RIGHT_PLL2_PIN1		(SMU_RIGHT_PLL_ADDR + 10*4)
#define RIGHT_PLL2_PIN3		(SMU_RIGHT_PLL_ADDR + 12*4)

#define RIGHT_PLL3_PIN0		(SMU_RIGHT_PLL_ADDR + 13*4)
#define RIGHT_PLL3_PIN1		(SMU_RIGHT_PLL_ADDR + 14*4)
#define RIGHT_PLL3_PIN3		(SMU_RIGHT_PLL_ADDR + 16*4)

#define RIGHT_PLL4_PIN0		(SMU_RIGHT_PLL_ADDR + 17*4)
#define RIGHT_PLL4_PIN1		(SMU_RIGHT_PLL_ADDR + 18*4)
#define RIGHT_PLL4_PIN3		(SMU_RIGHT_PLL_ADDR + 20*4)

/****************************************************************/
typedef enum
{
	COM_SUCCESS = 0x0,
	COM_NOT_FIND_FILE,
	COM_UNKNOW_DEV,
	COM_UNKNOW_CMD,
	COM_UNKNOW_PARA,
	COM_PARA0_ERR,
	COM_PARA1_ERR,
	COM_PARA2_ERR,
	COM_RUN_BACK_ERROR,
	COM_TIMEROUT,
	COM_BREAK,
	COM_RUN1_ERR,
	COM_RUN2_ERR,
	COM_ERROR = -1,
} COMMON_TYPE;

typedef enum
{
	TABLE_MODE =0,
	INTER_MODE,
	FRAC_MODE,
	RE_CALC_MODE,
}PLL_CALC_MODE;
//5/7/8 have two pll out at the same time
typedef enum {
	LEFT_PLL0 = 0,			//oclk	//ssram+oak+odma+dap_noc
	LEFT_PLL1,				//odsp	//odsp+omcu+dap_noc
	LEFT_PLL2,				//vmcu+vedio_noc
	BOTTOM_PLL0,			//venc+video_noc
	BOTTOM_PLL1,			//vdec+video_noc
	BOTTOM_PLL2,			//vdsp+dsp_noc //+pll-xphy
	RIGHT_PLL0,				//lpddr
	RIGHT_PLL1,				//pllf-v3d+dsp_noc //+pll-periph
	RIGHT_PLL2,				//main_noc+//cedar+rom
	RIGHT_PLL3,				//main_noc+//cedar+rom
	RIGHT_PLL4,			//main_noc+//cedar+rom
	PLL_NUM
} PLL_ID;

typedef enum {
	SEL_REF 	= 0,
	SEL_PLLOUT  = 1<<0,
	SEL_PLLOUTF = 1<<1,
	SEL_PLLOUTG = 1<<2,
	SEL_TRIPLE = 0x7,
} SEL_CLK;


typedef enum {
	RESET 	= 0,
	RELEASE = !RESET,
} PLL_RST;

struct current_clk
{
	u8 pll_sel;	// 0-pll_outf,1--pll_out
	u32 pll_out;	//Mhz
	u32 pll_outf;	//Mhz
};

struct PLL_MUX_BIT{
	u32 b0:1 ;
	u32 b1:1 ;
	u32 b2:1 ;
	u32 mux_rev:29;
};

struct clk_table
{
	u64 pll_vco;	//Mhz
	u32 pll_out;	//Mhz
	u32 pll_outf;	//Mhz
	u32 pll_outg;	//MHz

	u32 pin0;
	u32 pin1;
	u32 pin2;
	u32 pin3;

	struct PLL_MUX_BIT mux0;       //b0:for pllout0 b1:for pllout1 b2:for pllout2
	struct PLL_MUX_BIT mux1;
};

struct pll_clock_set
{
	u32 ref_clk;	//input ref_clk
	struct clk_table pclkT;
}__attribute__((packed));

/****************************************
 * PLLx register define
 *//////////////////////////////////////
struct SG100_PLL_CSR
{
	union{
		struct csr0
			{
				u32 newdiv:1;
				u32 divr_o:7;
				u32 divfi_o:10;
				u32 range:3;
				u32 res:11;
			}s;
			u32 u;
	}r0;

	union{
		struct csr1
			{
				u32 divq_o:8;
				u32 divqf_o:8;
				u32 divqg_o:8;
				u32 res:8;
			}s;
			u32 u;
	}r1;

	//register2 :not user current
	union{
		struct csr2
			{
				u32 ssds:1;
				u32 sse:1;
				u32 ssmd:3;
				u32 ssmf:4;
				u32 res:23;
			}s;
			u32 u;
	}r2;

	union{
		struct csr3{
				u32 divff:24;
				u32 lock:1;
				u32 divack:1;
				u32 res:6;
		}s;
		u32 u;
	}r3;

	union{
		struct PLL_MUX_BIT mux0;
		u32 m0;
	}pll_mux_s0;

	union{
		struct PLL_MUX_BIT mux1;
		u32 m1;
	}pll_mux_s1;

};



struct PLL_CF
{
	u32 	valid;			//0--refclk, 1-pll_out, 2-pll_outf, 4-pll_outg

	u64 pll_vco;
	u32 pll_out;		//user set
	u32 pll_outf;		//user set
	u32 pll_outg;		//user set
	struct SG100_PLL_CSR  pll_reg;
}__attribute__((packed));


struct  vastai_misc_info_flash
{
	u32 fbl_sel_flag;
	u32 fbl_dgb_flag;
	u32	gfx_mode;
	u32 vf_num;
	u32 revision_id;
	u32 sub_vendor_id;
	u32 sub_sys_id;
	u32 ddr_mode;
	u32 p2p_pcie_speed;
	u32 host_pcie_speed;
	u32 host_pcie_width;
	u32 ddr_bar_size;
	u32 bbox_type;
};

struct PMU_CB_ST
{
    u8 (* Initialize)(u8);
    u8 (* GetPowerVol)(u8, u32*);
    u8 (* SetPowerVol)(u8, u32);
};

struct _SYS_MODULE_ST_
{
	union{
		struct
			{
				u32 ecc_status:1;
				u32 dpm_enable:1;
				u32 dpm_mode:1;//only dpm enable valid,1-performance mode 0-balance mode
				u32	auto_sleep:1;

				u32	cedar_dma_en:1;	//0-smcu can/t user cedar dma
				u32	boot_select:3;
				//8bit for info
				//u32 info_reserved:8;
				u32 irq_delay:8;	//task will run
				//
				u32 avfs_paras_valid:4; //for 4 die avfs flash valid
				u32 avfs_paras_ready:4; //for 4 die avfs paras flag

				u32	auto_freq:1;
				u32	power_module_st:1;	//1-power module init sucess, 0- power module can't use
				u32 oc_req:1;
				u32 ot_req:1;
				//u32 irq_delay:2;	//task will run
				u32 info_reserved:2;
				u32 protect_mode:2; //over temperture &over current ;reduce -freq done
				//u32 reserved:1;
			}s;
			u32 u;
	}ctrl;
	u32	irq_req[2];
};

struct sys_cfg
{
	u8 		video_status; // VID
	u8 		ai_status;	 // SOC
	u8 		gfx_status;	 // GXF
	u8 		pvt_vaild;	 // 3'b111, VID, SOC, GFX
	u8 		auto_freq;
	u8		ecc_status;
	u8		oc_status;
	u8 		ot_status;
	u8		boot_status;
	u8		smi_req_status;
	u8		oc_req;
	u8		reduce_freq_req;

	u8		task_sel;

	u8 		sriov_enable;

	struct  vastai_misc_info_flash vastai_info;
	struct _SYS_MODULE_ST_ sys_module;
	u32		core_id;

	u32		osc_clk;	//ref_clk
	u32		sys_clk;	//main noc	 clk
	u32		pclk;		//peripheral  clk
	//frab para
	u8 		frab_max;		//frab mode max divr
	u8 		frab_min;		//frab mode min divr
	u16 	common_delay_cyc;
	u64 	vco_max;

	u32 	pll_valid;		//two valid bit for select bit1 -- pll_out,bit0 -- pll_outf
	u32		pll_select;		//00 -ref_clk,01-pll_out,10--pll_outf,11-pll_outf+pll_out
	u8      pll_inited[11];

	u8	clk_idx;
	struct PLL_CF 	pll_clk[11];		//LEFT PLL(PLL0/PLL1/PLL2) BOTTOM PLL(PLL3/PLL4/PLL5) RIGHT PLL(PLL6/7/8/9/10)
	struct PLL_CF 	pll_clk_pre[11];	//
	struct PLL_CF 	pll_clk_check[11];	//
    struct boot_hw_cfg hw_info;

	u32 	original_freq[12];
	u8		card_type;
	u16		flash_mdid;		// flash Manufacturer and Device ID
	u8		bl0_update_flag;
	u32 	bl0_header_addr;
	u32 	smcu_ding_alarm;
	u16 	pinvolt_set[18];
	u8 		pinvolt_num;
	struct PMU_CB_ST pmu_fun_cb;
	struct
	{
		u8		product_info_valid : 1;	//0 --unvaild ;1-valid
#define		V1			1
#define		V2			2
#define		V3			3
		u8		product_info_version :3; //0--v1,....
		u8		user_info_valid	: 1;	//0--unvaild
		u8		FlashType : 2;	//0 --spi ;1-eeprom
		u8		IsFlashSts:	1;
	}info_i;
	u16 	reduce_pll_sel;
	u8 cedar_int_flag;
};

struct pll_info
{
	u8  current_pll_num;
	u16 delay_num;
	u32 ref_clk;

	struct S_PLL_CSR	*pcsr;

	u32 pre_freq;
	u32 next_freq;
	u32 current_freq;	//current work frequency
	u32 save_freq;		//frequency switch before
};

struct Table_Reduce_freq
{
	u8	pll_num;
	u16	vco;	//is fix value
	u16	switch_cnt;	//count
	u32 normal_freq;
	u32	under_freq;	//reduce 50%
	u32 reg0;
	u32 reg1;
	u32 reg2;
	u8	table_value[8];
};
//u8 	vastai_pll_setting(u8 pll_id,u32 freq);
void vastai_pll_pm_handler(char percent);
void vastai_reduce_pll(u8 percent);
COMMON_TYPE vastai_pll_cfg(u32 clk_idx);
#endif /* vastai_pll */

#endif /* SG100_USED */
