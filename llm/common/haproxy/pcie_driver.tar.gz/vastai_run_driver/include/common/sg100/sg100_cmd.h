#ifdef SG100_USED
#ifndef __SG100_CMD_H__
#define __SG100_CMD_H__

/* host send cmd to smcu */
#define SMCU_READ_CMD						0x20
#define SMCU_WRITE_CMD						0x21
#define HOST_READ_CSR_BY_SMCU				0x22
#define HOST_WRITE_CSR_BY_SMCU				0x23
#define DUMP_GLOBAL_HW_CFG					0x24
#define DUMP_CURRENT_FN_HW_CFG				0x25
#define SMCU_DUMP_PC						0x26
#define SMCU_VSYNC_TIMER_EN					0x27
#define SMCU_VSYNC_TIMER_DIS				0x28
#define SMCU_CONFIG_ENTRY					0x29
#define DIAG_SLIDE_WINDOW					0x30
#define SMCU_TRIGER_MSI_IRQ					0x31
#define SMCU_SMI_CMD_REQ					0x32
#define SMCU_XSPI_FW_FLASH					0x33
#define SMCU_XSPI_FW_READ					0x34
#define SMCU_XSPI_FW_FLAG					0x35
#define SMCU_SWITCH_LOG_LEVEL				0x36
#define SMCU_MONITOR_PCIE_PERF				0x37
#define SMCU_MONITOR_PCIE_PERF_ACK			0x38
#define SMCU_CII_SET						0x39
#define SMCU_CMD_REINIT_RST_PKG				0x3A
#define SMCU_CMD_REINIT_RST_PKG_ACK			0x3B
#define SMCU_CMD_P2P_RETRAIN				0x3C
#define SMCU_MONITOR_DDR_PERF				0x3D
#define SMCU_MONITOR_DDR_PERF_ACK			0x3E
#define SMCU_DMI_FLASH						0x3F
#define SMCU_SMMU_STE_ENTRY					0x5A
#define SMCU_BMCU_FW_FLASH					0x5E
#define SMCU_BMCU_FW_SWITCH					0x5F
#define SMCU_PCIE_SUB_CORE_RESET			0x60
#define SMCU_CEDAR_CMD_REQ					0x61
#define SG100_VASTAI_PCIE_SUB_CORE_RESET			0x62



/* smcu send msix to host */
#define SWITCH_ATU_DONE						0x50
#define SMCU_RET_VALUE						0x51
#define SMCU_WRITE_VALUE_DONE				0x52
#define SMCU_VSYNC_TIMER_INT				0x53
#define SMCU_SMI_CMD_ACK					0x54
#define SMCU_XSPI_RW_ACK					0x55
/* pmcu --> smcu --> host */
#define FREQ_REDUCE_BY_TEMP					0x56
#define FREQ_REDUCE_BY_VOLT					0x57
#define FREQ_RECOVER_NORMAL_BY_TEMP			0x58
#define FREQ_RECOVER_NORMAL_BY_VOLT			0x59
#define FREQ_POWER_DOEN_REQ					0x5A
#define SMCU_TO_HOST_LOG_READ				0x5B
#define SMCU_TO_HOST_MPU_OUT_OF_BOUND		0x5C
#define SMCU_BMCU_CMD_ACK					0x5D
#define VASTAI_PCIE_MSG1_VIDEO_EXCEPTION_SG	0x5E
#define VASTAI_PCIE_MSG1_EXCEPTION_SG			0x5F
#define VASTAI_PCIE_MSG1_CORE_EXCEPTION_SG		0x60
#define VASTAI_PCIE_MSG1_CORE_RESET_ACK_SG		0x61

/*mpu sub cmd*/
#define SMMU_MPU_OUT_OF_BOUND				0x0
#define GFX_MPU_OUT_OF_BOUND				0x1
#define ENCODER_MPU_OUT_OF_BOUND			0x2
#define DECODER_MPU_OUT_OF_BOUND			0x3

#define MPU_READ							0
#define MPU_WRITE							1

/* host send cmd to gmcu */
#define GMCU_READ_CMD					0x20
#define GMCU_WRITE_CMD					0x21
#define GMCU_DUMP_PC					0x26
#define GMCU_OPEN_DDR_BW_TEST				0x27
#define GMCU_CLOSE_DDR_BW_TEST				0x28
#define GMCU_OPEN_PCIE_BW_TEST				0x29
#define GMCU_CLOSE_PCIE_BW_TEST				0x2A
#define GMCU_SWITCH_LOG_LEVEL				0x36

enum enum_core_2_core_exception_subcmd {
	CORE_2_CORE_EXCEPTION_SUBCMD = 1,
};


#endif
#endif /* SG100_USED */
