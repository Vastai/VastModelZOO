#ifdef SG100_USED
#ifndef __SG100_UTL_H__
#define __SG100_UTL_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "sg100_type.h"

#define LOCK_VAL                0xF1F11F1F
#define UNLOCK_VAL              0x1F1FF1F1
#define LOCK_INIT_DOWN          0x3184CD1F
#define LOCK_ADDR_BASE          0x8e3800
#define LOCK_ADDR_LIMIT         0x8e3c00
typedef int va_lock_t;

#define SET                     1
#define CLEAR                   0

#define readb(addr)             (*(volatile u8 *)(addr))
#define writeb(b,addr)          ((*(volatile u8 *) (addr)) = (b))
#if !defined(__BIG_ENDIAN)
#define readw(addr)             (*(volatile u16 *) (addr))
#define readl(addr)             (*(volatile u32 *) (addr))
#define writew(b,addr)          ((*(volatile u16 *) (addr)) = (b))
#define writel(b,addr)          ((*(volatile u32 *) (addr)) = (b))
#else
#define readw(addr)             in_le16((volatile u16 *)(addr))
#define readl(addr)             in_le32((volatile u32 *)(addr))
#define writew(b,addr)          out_le16((volatile u16 *)(addr),(b))
#define writel(b,addr)          out_le32((volatile u32 *)(addr),(b))
#endif

#define write_reg32(addr,value) writel(value,addr)
#define read_reg32(addr)        readl(addr)

#define BIT(x)                  (1u << (x))
#define OFFSET(x)               ((x) % 32)
#define SET_BIT(REG, BIT)       ((REG) |= (BIT))

#define CLEAR_BIT(REG, BIT)     ((REG) &= ~(BIT))

#define READ_BIT(REG, BIT)      ((REG) & (BIT))

#define CLEAR_REG(REG)          ((REG) = (0x0))
#define WRITE_REG(REG, VAL)     (*(volatile u32 *)(REG) = (VAL))
#define READ_REG(REG)           (*(volatile u32 *)(REG))
#define MODIFY_REG(REG, CLEARMASK, SETMASK)  WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))

#define BITS_PER_LONG 32
#define BIT_MASK(nr)            (1UL << ((nr) % BITS_PER_LONG))

void va_lock_init(va_lock_t **lock, int lock_addr);
void va_lock(va_lock_t *lock);
void va_unlock(va_lock_t *lock);
void modify_reg32(u32 addr,u32 mask_bit,u32 mode);

#ifdef __cplusplus
}
#endif /* __cplusplus */
    
#endif /* __SG100_UTL_H__ */
#endif /* SG100_USED */
