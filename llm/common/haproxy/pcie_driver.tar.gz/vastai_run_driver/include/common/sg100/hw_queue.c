#ifdef SG100_USED
#include "config.h"
#include "hw_queue.h"

#if defined(__GMCU__) || defined(__SMCU__)
#include "sg100_type.h"
#define min(a, b) ((a) < (b) ? (a) : (b))
#else
#include "vastai_pci.h"
#define hw_queue_dbg(fmt, ...) VASTAI_PCI_DBG(NULL, DUMMY_DIE_ID, fmt, ##__VA_ARGS__)
#endif

#if defined(__GMCU__) 
#include "logsys.h"
#define hw_queue_dbg log_dbg
#endif

static inline int is_power_2(u32 n)
{
    return (n != 0 && ((n & (n - 1)) == 0));
}

int hw_msgq_init(struct hw_msgq *msgq, char *name, u64 ctrl_reg_addr,
        u64 data_addr, u32 size, u32 esize,
        void *priv)
{
    size /= esize;

    if (!is_power_2(size))
        return -1;

#if !defined(__GMCU__) && !defined(__SMCU__)
    if (!priv)
        return -2;
#endif
    msgq->priv = priv;
#if defined(__GMCU__) || defined(__SMCU__)
    msgq->reg_base = (void *)((u32)ctrl_reg_addr);
#else
    msgq->reg_base = (void *)ctrl_reg_addr;
#endif
    snprintf(msgq->name, VA_HW_MSGQ_NAME_LEN_MAX, "%s", name);

    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, int_ctrl, 0x1F);
    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, wr, 0);
    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, rd, 0);
    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, int_ctrl, 0x17);

    msgq->esize = esize;
#if defined(__GMCU__) || defined(__SMCU__)
    msgq->data = (void *)((u32)data_addr);
#else
    msgq->data = (void *)data_addr;
#endif

    if (size < 2) {
        msgq->mask = 0;
        return -3;
    }

    msgq->mask = size -1;
    return 0;
}

static void msgq_copy_in(struct hw_msgq *msgq, const void *src,
            u32 len, u32 off)
{
    u32 size = msgq->mask + 1;
    u32 esize = msgq->esize;
    u32 l;

    off &= msgq->mask;
    if (esize != 1) {
        off *= esize;
        size *= esize;
        len *= esize;
    }
    l = min(len, size - off);

    msgq_copy_mem_to_dev(msgq, msgq->data + off, src, l);
    msgq_copy_mem_to_dev(msgq, msgq->data, src + l, len - l);
}

int msgq_ptr_in_entriely(struct hw_msgq *msgq, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = (msgq->mask + 1) - (wr - rd);

    if (len > l)
        return -1;

    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, wr, wr + len);

    return len;
}

int msgq_in_entriely(struct hw_msgq *msgq,
        const void *buf, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = (msgq->mask + 1) - (wr - rd);

    if (len > l)
        return -1;

    msgq_copy_in(msgq, buf, len, wr);
    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, wr, wr + len);

    return len;
}

int msgq_in(struct hw_msgq *msgq,
        const void *buf, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = (msgq->mask + 1) - (wr - rd);

    if (len > l)
        len = l;

    msgq_copy_in(msgq, buf, len, wr);
    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, wr, wr + len);

    return len;
}

static void __msgq_copy_out_ptr(struct hw_msgq *msgq, void **dst,
        u32 len, u32 off)
{
    u32 size = msgq->mask + 1;
    u32 esize = msgq->esize;
    u32 l;
    u32 i;

    off &= msgq->mask;

    l = min(len, size - off);

    for (i = 0; i < l; i++) {
        *(dst + i) = msgq->data + off * esize + i * esize;
    }

    for (i = 0; i < len - l; i++) {
        *(dst + l + i) = msgq->data + i * esize;
    }
}

int msgq_dry_out(struct hw_msgq *msgq, u32 len,
         void **buf_p)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = wr - rd;
    if (len > l)
        len = l;

    __msgq_copy_out_ptr(msgq, buf_p, len, rd);

    return len;
}

int msgq_ptr_out_entriely(struct hw_msgq *msgq, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = wr - rd;
    if (len > l)
        return -1;

    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, rd, rd + len);
    return len;
}

static void __msgq_copy_out(struct hw_msgq *msgq, void *dst,
        u32 len, u32 off)
{
    u32 size = msgq->mask + 1;
    u32 esize = msgq->esize;
    u32 l;

    off &= msgq->mask;
    if (esize != 1) {
        off *= esize;
        size *= esize;
        len *= esize;
    }
    l = min(len, size - off);

    msgq_copy_dev_to_mem(msgq, dst, msgq->data + off, l);
    msgq_copy_dev_to_mem(msgq, dst + l, msgq->data, len - l);
}

int msgq_copy_out(struct hw_msgq *msgq,
        void *buf, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = wr - rd;
    if (len > l)
        len = l;

    __msgq_copy_out(msgq, buf, len, rd);

    return len;
}

int msgq_out(struct hw_msgq *msgq,
        void *buf, u32 len)
{
    u32 l;
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    l = wr - rd;
    if (len > l)
        len = l;

    __msgq_copy_out(msgq, buf, len, rd);

    msgq_reg_write32(msgq, struct hw_msgq_ctrl_reg, rd, rd + len);
    return len;
}
#endif /* SG100_USED */
