#ifdef SG100_USED
#ifndef __SG100_SDMA_H__
#define __SG100_SDMA_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SDMA_CHL_CNT 32

#define REG_SDMA_CHN_EN(X)                         ((X) * 8 * 4 + 0x00)
#define REG_SDMA_CHN_LL_ADDRL(X)                   ((X) * 8 * 4 + 0x04)
#define REG_SDMA_CHN_LL_ADDRH(X)                   ((X) * 8 * 4 + 0x08)
#define REG_SDMA_CHN_LL_QUEUE(X)                   ((X) * 8 * 4 + 0x0C)
#define REG_SDMA_CHN_QOS(X)                        ((X) * 8 * 4 + 0x10)
#define REG_SDMA_CHN_DSCP_CNT(X)                   ((X) * 8 * 4 + 0x14)
#define REG_SDMA_CHN_ATTR(X)                       ((X) * 8 * 4 + 0x18)
#define REG_SDMA_CHN_DSCP_ATTR(X)                  ((X) * 8 * 4 + 0x1C)
#define REG_SDMA_OUTSTAND                          (256 * 4)
#define REG_SDMA_AXI_ATTR                          (257 * 4)
#define REG_SDMA_CHN_STOP_STATUS                   (258 * 4)   /* 0: STOP DONE; 1: NOT DONE. Each bit presents one chl. */
#define REG_SDMA_TRANS_LEN                         (259 * 4)   /* Max transfer len */
#define REG_SDMA_MONITOR0_PARA                     (260 * 4)
#define REG_SDMA_MONITOR0_TIME1                    (261 * 4)
#define REG_SDMA_MONITOR0_TIME2                    (262 * 4)
#define REG_SDMA_MONITOR0_TIME3                    (263 * 4)
#define REG_SDMA_MONITOR0_TIME4                    (264 * 4)
#define REG_SDMA_MONITOR0_BANDWIDTH_SET            (265 * 4)
#define REG_SDMA_MONITOR0_OPERAND_SET              (266 * 4)
#define REG_SDMA_MONITOR0_LATENCY_WID              (267 * 4)
#define REG_SDMA_MONITOR0_LATENCY_RID              (268 * 4)
#define REG_SDMA_MONITOR0_SPADDR_WRRANGE0          (269 * 4)
#define REG_SDMA_MONITOR0_SPADDR_WRRANGE1          (270 * 4)
#define REG_SDMA_MONITOR0_SPADDR_WRRANGE2          (271 * 4)
#define REG_SDMA_MONITOR0_SPADDR_WRRANGE3          (272 * 4)
#define REG_SDMA_MONITOR0_SPADDR_RDRANGE0          (273 * 4)
#define REG_SDMA_MONITOR0_SPADDR_RDRANGE1          (274 * 4)
#define REG_SDMA_MONITOR0_SPADDR_RDRANGE2          (275 * 4)
#define REG_SDMA_MONITOR0_SPADDR_RDRANGE3          (276 * 4)
#define REG_SDMA_MONITOR0_RESULT_SELSCT            (277 * 4)
#define REG_SDMA_MONITOR0_RESULT0                  (278 * 4)
#define REG_SDMA_MONITOR0_RESULT1                  (279 * 4)
#define REG_SDMA_MISC                              (280 * 4)
#define REG_SDMA_INT                               (283 * 4)   /* Each bit presents one descriptor process done interrupt in chl_X */
#define REG_SDMA_INT_MSK0                          (284 * 4)
#define REG_SDMA_INT_MSK1                          (285 * 4)
#define REG_SDMA_INT_MSK2                          (286 * 4)
#define REG_SDMA_INT_MSK3                          (287 * 4)
#define REG_SDMA_INT_MSK4                          (288 * 4)
#define REG_SDMA_INT_MSK5                          (289 * 4)
#define REG_SDMA_INT_MSK6                          (290 * 4) 
#define REG_SDMA_INT_MSK7                          (291 * 4) 
#define REG_SDMA_INT_MSK8                          (292 * 4) 
#define REG_SDMA_INT_MSK9                          (293 * 4) 
#define REG_SDMA_INT_MSK10                         (294 * 4) 
#define REG_SDMA_INT_MSK11                         (295 * 4) 
#define REG_SDMA_INT_MSK12                         (296 * 4)
#define REG_SDMA_INT_MSK13                         (297 * 4)
#define REG_SDMA_INT_MSK14                         (298 * 4) 
#define REG_SDMA_INT_MSK15                         (299 * 4)
#define REG_SDMA_FATAL_ERR_INT                     (300 * 4)
#define REG_SDMA_FATAL_ERR_INT_MSK                 (301 * 4)
#define REG_SDMA_NONFATAL_ERR_INT                  (302 * 4)
#define REG_SDMA_NONFATAL_ERR_INT_MSK              (303 * 4)
#define REG_SDMA_MEM_CSR                           (304 * 4) 
#define REG_SDMA_DEBUG_SEL                         (305 * 4)
#define REG_SDMA_DEBUG_OUT                         (306 * 4)
#define REG_SDMA_FATAL_ERR_STREAM_ID               (307 * 4)
#define REG_SDMA_DSCP_FATAL_ERR_STREAM_ID          (308 * 4)
#define REG_SDMA_NONFATAL_ERR_STREAM_ID            (309 * 4)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SG100_SDMA_H__ */
#endif /* SG100_USED */
