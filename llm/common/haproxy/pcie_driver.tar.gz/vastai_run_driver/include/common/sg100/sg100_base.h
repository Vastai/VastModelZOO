#ifdef SG100_USED
#ifndef __VAST_SG100_REG_H__
#define __VAST_SG100_REG_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ddr_partition.h"
#include "csram_partition.h"
#include "sg100_gmcu.h"
#include "sg100_type.h"

#define MASTER_PKG                  0
#define SLAVE_PKG                   1

#define SG100_CORE_COUNT            17
/* CORE ID */
#define SMCU_0_COREID               0x3C0
#define CMCU_0_COREID               0x0
#define OMCU_0_COREID               0x40
#define OMCU_1_COREID               0x41
#define GMCU_0_COREID               0x1000
#define GMCU_1_COREID               0x1001
#define GMCU_2_COREID               0x1002
#define GMCU_3_COREID               0x1003
#define VEMCU_0_COREID              0x2C0
#define VEMCU_1_COREID              0x2C1
#define VEMCU_2_COREID              0x2C2
#define VEMCU_3_COREID              0x2C3
#define ODSP_0_COREID               0x80
#define ODSP_1_COREID               0x81
#define VDSP_0_COREID               0x200
#define VDSP_1_COREID               0x201
#define PMCU_0_COREID               0x1004

#define SG_CSRAM_BASE_ADDR     0x00800000
/* bl1 download address: CSRAM */
#define VASTAI_SG_BL1_DL_ADDR          (SG_CSRAM_BASE_ADDR)
/* firmware download address: DDR */
#define VASTAI_FW_DL_OFFSET_SG      (0x38000000UL)
#define VASTAI_FW_DL_ADDR_SG        (SG_DDR_BASE_ADDR + VASTAI_FW_DL_OFFSET_SG)


/* define for peripheral baseaddr */
#define REG_PWM0_BASE_ADDR          0x14000
#define REG_PWM1_BASE_ADDR          0x14400
#define REG_PWM2_BASE_ADDR          0x14800
#define REG_UART0_BASE_ADDR         0x14C00
#define REG_UART1_BASE_ADDR         0x15000
#define REG_UART2_BASE_ADDR         0x15400
#define REG_IIC0_BASE_ADDR          0x15800
#define REG_IIC1_BASE_ADDR          0x15C00
#define REG_IIC2_BASE_ADDR          0x16000
#define REG_IIC3_BASE_ADDR          0x16400
#define REG_AVS0_BASE_ADDR          0x16800
#define REG_AVS1_BASE_ADDR          0x16C00
#define REG_GPIO0_BASE_ADDR         0x17000
#define REG_GPIO1_BASE_ADDR         0x17400 //vastai gpio
#define REG_VASTAI_SPI_BASE_ADDR    0x17800
#define REG_VASTAI_QSPI_BASE_ADDR   0x17C00
#define REG_CDNS_SPI0_BASE_ADDR     0x18000
#define REG_CDNS_SPI1_BASE_ADDR     0x1C000
#define REG_CDNS_xSPI_BASE_ADDR     0x20000

/* gpio */
#define CDN_GPIO_BASE_ADDR          REG_GPIO0_BASE_ADDR     // GPIO0 CDN CSR. main function pad by default
#define VASTAI_GPIO_BASE_ADDR       REG_GPIO1_BASE_ADDR     // GPIO1 VAS CSR. main function pad by default

/* others */
#define SG_LOG_CTRL_INFO               (SG_CSRAM_BASE_ADDR + 0x000E1400)      /* 512 bytes */
#define SMCU_2_HOST_LOG_MSG_ADDR    (SG_LOG_CTRL_INFO + 512 - 4)


struct _pkg_info
{
    u8 pkg_cnt;
    u8 current_pkg_id;      // 0: master, 1:slave
    u8 pkg_pf_cnt;          // pf_cnt in current pkg
    u8 pcie_vf_num;         // VF num per PF
    u8 dp_enabled;
    u8 gfx_mode;            // see GFX_MODE_TYPE definition
    u8 card_type;           // 0:EVB  1:AIC-ANYI 2:AIC_ZHAOGE
    u8 bar4_5_ddr_sz;       // 0:2GB  1:4GB  2:8GB  3:16GB  4:32GB 5:64GB
    u64 ddr_sz;             // total ddr size(Byte) on current board
};

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VAST_SG100_REG_H__ */
#endif /* SG100_USED */
