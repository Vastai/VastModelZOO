#ifdef SG100_USED
#ifndef __VASTAI_SG100_SMU_H__
#define __VASTAI_SG100_SMU_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define EFUSE_SRAM_BASE_ADDR        0x10000             /* efuse sram space 16KB */
#define SMU_LEFT_PLL_ADDR           0x200000
#define SMU_RIGHT_PLL_ADDR          0x200800
#define SMU_BOTTOM_PLL_ADDR         0x201000

#define BOOTROM_BASE_ADDR           0x0
#define SMU_BASE_ADDR               0x208000             /* 32KB */
#define SMU_CC_BASE_ADDR            0x900000             /* 256KB */
#define SMU_CC_HALF_BASE_ADDR       0x920000             /* 128KB */
#define SMU_INT_BASE_ADDR           SMU_CC_BASE_ADDR

#define VFn_SMU_INT_CSR_BASE(p, v)  (SMU_CC_HALF_BASE_ADDR + p*(0x8000) + v*0x1000)

/* smu.pad_ring_group0/1/2 for storing gpio values temporarily */
#define SMU_PAD_RING_GROUP0         (SMU_BASE_ADDR + 155 * 4)   /* 0x20826C */
#define SMU_PAD_RING_GROUP1         (SMU_BASE_ADDR + 156 * 4)
#define SMU_PAD_RING_GROUP2         (SMU_BASE_ADDR + 157 * 4)
#define SMU_PAD_RING_G0             SMU_PAD_RING_GROUP0
#define SMU_PAD_RING_G1             SMU_PAD_RING_GROUP1
#define SMU_PAD_RING_G2             SMU_PAD_RING_GROUP2
#define SMU_PHERPH_RST              (SMU_BASE_ADDR + 10*4)
#define PHERPH_BIT_CDNSGPIO_RST     (0)
#define PHERPH_BIT_CDNSI2C0_RST     (1)
#define PHERPH_BIT_CDNSPWM0_RST     (4)
#define PHERPH_BIT_CDNSSPI0_RST     (6)
#define PHERPH_BIT_CDNSUART0_RST    (8)
#define PHERPH_BIT_CDNSXSPI_RST     (10)
#define PHERPH_BIT_VASTAVS0_RST     (11)
#define PHERPH_BIT_VASTGPIO_RST     (13)
#define PHERPH_BIT_VASTI2C_RST      (14)
#define PHERPH_BIT_VASTPWM_RST      (15)
#define PHERPH_BIT_VASTSPI_RST      (16)
#define PHERPH_BIT_VASTUART_RST     (17)
#define PHERPH_BIT_VASTQSPI_RST     (18)

/* smu_int.csv */
#define SMU_INT_HUB1				(SMU_INT_BASE_ADDR + 2554 * 4)   // 0x9027E8, RO, 32bits for each periph
#define SMU_INT_HUB1_PERIPH_STA		SMU_INT_HUB1
#define SMU_INT_HUB1_MSK			(SMU_INT_BASE_ADDR + 2555 * 4)   // 0x9027EC, RW
#define SMU_INT_HUB1_PERIPH_MSK		SMU_INT_HUB1_MSK

#define SMU_INT_HUB2_STATUS         (SMU_CC_BASE_ADDR + 2556 * 4)    // 0x9027F0, RO
#define BITS_PCIE_EP_HOT_RESET_OUT               5
#define BITS_PCIE_EP_HOT_RESET_EARLY_OUT         6

#define SMU_INT_HUB2_MSK            (SMU_CC_BASE_ADDR + 2557 * 4)    // 0x9027F4, RW
#define BITS_INTM_PCIE_EP_HOT_RESET_OUT          5
#define BITS_INTM_PCIE_EP_HOT_RESET_EARLY_OUT    6
#define BITS_INTM_I2S0_IRQ                      26
#define BITS_INTM_I2S1_IRQ                      28

#define SMU_INT_HUB5                (SMU_INT_BASE_ADDR + 2562 * 4)   // 0x902808, RO
#define SMU_INT_HUB5_PF_FLR_STA     SMU_INT_HUB5                     // Bit20: pcie_ep_flr_pf, 8'h0
#define SMU_INT_HUB5_MSK            (SMU_INT_BASE_ADDR + 2563 * 4)   // 0x90280C, RW
#define SMU_INT_HUB5_PF_FLR_MSK     SMU_INT_HUB5_MSK                 // Bit20: pcie_ep_flr_pf, 8'h0

#define SMU_INT_HUB6                (SMU_INT_BASE_ADDR + 2564 * 4)   /* 0x902810, RO, 32bits for each VF */
#define SMU_INT_HUB6_VF_FLR_STA     SMU_INT_HUB6
#define SMU_INT_HUB6_MSK            (SMU_INT_BASE_ADDR + 2565 * 4)   /* 0x902814, RW */
#define SMU_INT_HUB6_VF_FLR_MSK     SMU_INT_HUB6_MSK

#define BOOT_JUMP_ADDR              (SMU_INT_BASE_ADDR + 2571*4)     /* 0x90282C */

/* Reset MCUs */
#define SMU_NODE0_RST               (SMU_BASE_ADDR + 6*4)
#define NODE0_BIT_LMCU0_RST         2
#define NODE0_BIT_LMCU1_RST         3
#define NODE0_BIT_ODSP0_RST         4
#define NODE0_BIT_ODSP1_RST         5
#define NODE0_BIT_VDSP0_RST         6
#define NODE0_BIT_VDSP1_RST         7
#define NODE0_BIT_PMCU_RST          11

#define SMU_NODE1_RST               (SMU_BASE_ADDR + 7*4)     // 0x20801C
#define NODE1_BIT_VDEC0_RST         0
#define NODE1_BIT_VDEC1_RST         1
#define NODE1_BIT_VENC0_RST         2
#define NODE1_BIT_VENC1_RST         3
#define NODE1_BIT_VENC2_RST         4
#define NODE1_BIT_VENC3_RST         5
#define NODE1_BIT_VEMCU0_RST        6
#define NODE1_BIT_VEMCU1_RST        7
#define NODE1_BIT_VEMCU2_RST        8
#define NODE1_BIT_VEMCU3_RST        9

#define SMU_NODE2_RST               (SMU_BASE_ADDR + 8*4)
#define NODE2_BIT_GPU0_RST          0
#define NODE2_BIT_GPU1_RST          1
#define NODE2_BIT_GPU2_RST          2
#define NODE2_BIT_GPU3_RST          3
#define NODE2_BIT_GMCU0_RST         4
#define NODE2_BIT_GMCU1_RST         5
#define NODE2_BIT_GMCU2_RST         6
#define NODE2_BIT_GMCU3_RST         7

#define SMU_NODE5_RST               (SMU_BASE_ADDR + 11*4)
#define NODE5_BIT_SMCU_RST          11
#define NODE5_BIT_CMCU_RST          12
#define NODE5_BIT_MMU_RST           20      /* 0:Reset mmu controller near soc 1: rst mmu */
#define NODE5_BIT_SDMA0_RST         21      /* 0:Reset sdma0 controller near soc 1: rst sdma0 */
#define NODE5_BIT_SDMA1_RST         22

/* Reset vector for each MCU */
#define SMU_CMCU_VECTOR             (SMU_BASE_ADDR + 95*4)
#define SMU_CMCU_DEF_H              (SMU_BASE_ADDR + 96*4)
#define SMU_SMCU_VECTOR             (SMU_BASE_ADDR + 97*4)    /* smcu resect vector */
#define SMU_SMCU_DEF_H              (SMU_BASE_ADDR + 98*4)    /* smcu resect default high bits */
#define SMU_PMCU_VECTOR             (SMU_BASE_ADDR + 99*4)
#define SMU_PMCU_DEF_H              (SMU_BASE_ADDR + 100*4)
#define SMU_GMCU0_VECTOR            (SMU_BASE_ADDR + 101*4)
#define SMU_GMCU0_DEF_H             (SMU_BASE_ADDR + 102*4)
#define SMU_GMCU1_VECTOR            (SMU_BASE_ADDR + 103*4)
#define SMU_GMCU1_DEF_H             (SMU_BASE_ADDR + 104*4)
#define SMU_GMCU2_VECTOR            (SMU_BASE_ADDR + 105*4)
#define SMU_GMCU2_DEF_H             (SMU_BASE_ADDR + 106*4)
#define SMU_GMCU3_VECTOR            (SMU_BASE_ADDR + 107*4)
#define SMU_GMCU3_DEF_H             (SMU_BASE_ADDR + 108*4)
#define SMU_LMCU0_VECTOR            (SMU_BASE_ADDR + 109*4)
#define SMU_LMCU0_DEF_H             (SMU_BASE_ADDR + 110*4)
#define SMU_LMCU1_VECTOR            (SMU_BASE_ADDR + 111*4)
#define SMU_LMCU1_DEF_H             (SMU_BASE_ADDR + 112*4)
#define SMU_VEMCU0_VECTOR           (SMU_BASE_ADDR + 113*4)
#define SMU_VEMCU0_DEF_H            (SMU_BASE_ADDR + 114*4)
#define SMU_VEMCU1_VECTOR           (SMU_BASE_ADDR + 115*4)
#define SMU_VEMCU1_DEF_H            (SMU_BASE_ADDR + 116*4)
#define SMU_VEMCU2_VECTOR           (SMU_BASE_ADDR + 117*4)
#define SMU_VEMCU2_DEF_H            (SMU_BASE_ADDR + 118*4)
#define SMU_VEMCU3_VECTOR           (SMU_BASE_ADDR + 119*4)
#define SMU_VEMCU3_DEF_H            (SMU_BASE_ADDR + 120*4)
#define SMU_ODSP0_VECTOR            (SMU_BASE_ADDR + 121*4)
#define SMU_ODSP0_DEF_H             (SMU_BASE_ADDR + 122*4)
#define SMU_ODSP1_VECTOR            (SMU_BASE_ADDR + 123*4)
#define SMU_ODSP1_DEF_H             (SMU_BASE_ADDR + 124*4)
#define SMU_VDSP0_VECTOR            (SMU_BASE_ADDR + 125*4)
#define SMU_VDSP0_DEF_H             (SMU_BASE_ADDR + 126*4)
#define SMU_VDSP1_VECTOR            (SMU_BASE_ADDR + 127*4)
#define SMU_VDSP1_DEF_H             (SMU_BASE_ADDR + 128*4)

/* int */
#define SMU_GIR_MASK                (SMU_BASE_ADDR + 14*4)
#define SMU_REINIT_RST              (SMU_BASE_ADDR + 223*4)  // 0x20837C   

/* b31: Hardware auto assert re-initial reset when hot reset coming. */
/* b30: Hardware auto assert rc node reset when hot reset coming. */
#define    SMU_HARD_REINIT         (SMU_BASE_ADDR + 220*4)  // 0x208370

// smu err int
#define SMU_FATAL_ERR_REG3           (SMU_BASE_ADDR + 18*4)
#define SMU_FATAL_ERR_MASK3          (SMU_BASE_ADDR + 22*4)
#define SMU_NON_FATAL_ERR_REG3       (SMU_BASE_ADDR + 26*4)
#define SMU_NON_FATAL_ERR_MASK3      (SMU_BASE_ADDR + 30*4)
#define SDMA_ERR_MASK                (BIT(15)|BIT(16))
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VASTAI_SG100_SMU_H__ */
#endif /* SG100_USED */
