#ifdef SG100_USED
#include "xtensa/tie/xt_core.h"
#include "sg100_utl.h"

extern void XT_GETEX(int r);
extern int  XT_L32EX(const int * p);
extern void XT_S32EX(int r, int * p);
extern void XT_CLREX(void);

void va_lock_init(va_lock_t **lock, int lock_addr)
{
    int lock_t;
    int temp;
    int ret;
    int lock_tail = lock_addr + 4;

    lock_t = LOCK_INIT_DOWN;
    temp = XT_L32EX((int*)lock_tail);

    *lock = (int*)lock_addr;
    if (LOCK_INIT_DOWN == temp)
    {
        return;
    }
    else
    {
        XT_S32EX(lock_t, (int*)lock_tail);
        XT_GETEX(ret);
    }

    if (lock_addr > LOCK_ADDR_LIMIT || lock_addr < LOCK_ADDR_BASE)
    {
        **lock = LOCK_VAL;
        return;
    }
    **lock = UNLOCK_VAL;
}

void va_lock(va_lock_t *lock)
{
    int lock_t;
    int ret = 0;
    int temp;

    do
    {
        lock_t = LOCK_VAL;
        temp = XT_L32EX((int*)lock);
        if (UNLOCK_VAL == temp)
        {
            XT_S32EX(lock_t, (int*)lock);
            XT_GETEX(ret);
        }
    }while(!ret);

}

void va_unlock(va_lock_t *lock)
{
    int unlock_t;
    int ret = 0;
    int temp;

    do
    {
        unlock_t = UNLOCK_VAL;
        temp = XT_L32EX((int*)lock);
        if (LOCK_VAL == temp)
        {
            XT_S32EX(unlock_t, (int*)lock);
            XT_GETEX(ret);
        }
    }while(!ret);

}

void modify_reg32(u32 addr,u32 mask_bit,u32 mode)
{
    u32 tmp_reg = readl(addr);
    tmp_reg = (mode)?(tmp_reg|(mask_bit)):(tmp_reg&(~mask_bit));
    writel(tmp_reg,addr);
}

u8 is_bits_setted(u32 value,u32 bits)
{
    u8 ret =0;
    if(bits == (value &bits))
        return 1;
    return 0;
}

u8 is_bits_cleared(u32 value,u32 bits)
{
    u8 ret =0;
    if(0 == (value &bits))
        return 1;
    return 0;
}
#endif /* SG100_USED */
