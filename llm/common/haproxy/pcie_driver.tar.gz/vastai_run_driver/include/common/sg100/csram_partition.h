#ifdef SG100_USED
#ifndef __CSRAM_PARTITION_H__
#define __CSRAM_PARTITION_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SG_CSRAM_BASE_ADDR     0x00800000
#define CSRAM_MEM_LEN       (1024*1024)

/* For each PF (pf=0,1,2,3) & VF (vf=0,1,2,3,4,5,6,7), Total: PF x 4 = (28KB x 8VF = 224KB) x 4 = 896KB. */
#define ADDR_CSRAM_SIZE_PER_PF          (0x38000)                                       /* 224KB */
#define PFn_CSRAM_BASE(p)               (CSRAM_BASE_ADDR + (p)*ADDR_CSRAM_SIZE_PER_PF)
#define ADDR_CSRAM_SIZE_PER_VF          (0x7000)                                        /* 28KB */
#define ADDR_SMU_SIZE_PER_VF            (0x1000)                                        /* 4KB  */
#define ADDR_GFX_SIZE_PER_VF            (0x10000)                                       /* 64KB */
#define ADDR_BAR_RSVD_SIZE_PER_VF       (0x8000)                                        /* 32KB */

#define VFn_CSRAM_BASE(p, v)            (PFn_CSRAM_BASE(p) + (v)*ADDR_CSRAM_SIZE_PER_VF)

#define CFG_INFO_PER_VF(p, v)           (VFn_CSRAM_BASE(p, v) + 0)       /* size 1KB */
#define AI_PIPELINE_INFO_PER_VF(p, v)   (VFn_CSRAM_BASE(p, v) + 0x400)   /* size 4KB */
#define SDMA_DESCIPTOR_PER_VF(p, v)     (VFn_CSRAM_BASE(p, v) + 0x1400)  /* size 8KB */
#define MSGQ_PER_VF(p, v)               (VFn_CSRAM_BASE(p, v) + 0x3400)  /* size 2KB */
#define MTO_PER_VF(p, v)                (VFn_CSRAM_BASE(p, v) + 0x3C00)  /* size 2.5KB */
#define MSIX_PER_VF(p, v)               (VFn_CSRAM_BASE(p, v) + 0x4600)  /* size 3.5KB */
#define RESERVED_3KB_PER_VF(p, v)       (VFn_CSRAM_BASE(p, v) + 0x5400)  /* size 3KB */


/* For one to one MSG, between MCUS and DSPS */
#define SG_LOCAL_MSG_BASE_ADDR             (CSRAM_BASE_ADDR + 0x000C0000)

/* TODO */
#define MSG_CMCU_TO_SMCU                (CSRAM_BASE_ADDR + 0x0003C000)
#define MSG_VDMCU0_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003C400)
#define MSG_VDMCU1_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003C800)
#define MSG_VDMCU2_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003CC00)
#define MSG_VEMCU0_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003D000)
#define MSG_VEMCU1_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003D400)
#define MSG_VEMCU2_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003D800)
#define MSG_VEMCU3_TO_SMCU              (CSRAM_BASE_ADDR + 0x0003DC00)

#define MSG_SMCU_TO_VDMCU0              (CSRAM_BASE_ADDR + 0x0003E000)
#define MSG_VDSP0_TO_VDMCU0             (CSRAM_BASE_ADDR + 0x0003E400)
#define MSG_VDSP1_TO_VDMCU0             (CSRAM_BASE_ADDR + 0x0003E800)
#define MSG_VEMCU0_TO_VDMCU0            (CSRAM_BASE_ADDR + 0x0003EC00)
#define MSG_VEMCU1_TO_VDMCU0            (CSRAM_BASE_ADDR + 0x0003F000)
#define MSG_SMCU_TO_VDMCU1              (CSRAM_BASE_ADDR + 0x0003F400)
#define MSG_VDSP1_TO_VDMCU1             (CSRAM_BASE_ADDR + 0x0003F800)
#define MSG_VDSP2_TO_VDMCU1             (CSRAM_BASE_ADDR + 0x0003FC00)
#define MSG_VEMCU1_TO_VDMCU1            (CSRAM_BASE_ADDR + 0x00040000)
#define MSG_VEMCU2_TO_VDMCU1            (CSRAM_BASE_ADDR + 0x00040400)
#define MSG_SMCU_TO_VDMCU2              (CSRAM_BASE_ADDR + 0x00040800)
#define MSG_VDSP2_TO_VDMCU2             (CSRAM_BASE_ADDR + 0x00040C00)
#define MSG_VDSP3_TO_VDMCU2             (CSRAM_BASE_ADDR + 0x00041000)
#define MSG_VEMCU2_TO_VDMCU2            (CSRAM_BASE_ADDR + 0x00041400)
#define MSG_VEMCU3_TO_VDMCU2            (CSRAM_BASE_ADDR + 0x00041800)

#define MSG_SMCU_TO_VEMCU0              (CSRAM_BASE_ADDR + 0x00041C00)
#define MSG_VDSP0_TO_VEMCU0             (CSRAM_BASE_ADDR + 0x00042000)
#define MSG_VDMCU0_TO_VEMCU0            (CSRAM_BASE_ADDR + 0x00042400)
#define MSG_SMCU_TO_VEMCU1              (CSRAM_BASE_ADDR + 0x00042800)
#define MSG_VDSP1_TO_VEMCU1             (CSRAM_BASE_ADDR + 0x00042C00)
#define MSG_VDMCU0_TO_VEMCU1            (CSRAM_BASE_ADDR + 0x00043000)
#define MSG_VDMCU1_TO_VEMCU1            (CSRAM_BASE_ADDR + 0x00043400)
#define MSG_SMCU_TO_VEMCU2              (CSRAM_BASE_ADDR + 0x00043800)
#define MSG_VDSP2_TO_VEMCU2             (CSRAM_BASE_ADDR + 0x00043C00)
#define MSG_VDMCU1_TO_VEMCU2            (CSRAM_BASE_ADDR + 0x00044000)
#define MSG_VDMCU2_TO_VEMCU2            (CSRAM_BASE_ADDR + 0x00044400)
#define MSG_SMCU_TO_VEMCU3              (CSRAM_BASE_ADDR + 0x00044800)
#define MSG_VDSP3_TO_VEMCU3             (CSRAM_BASE_ADDR + 0x00044C00)
#define MSG_VDMCU2_TO_VEMCU3            (CSRAM_BASE_ADDR + 0x00045000)

#define MSG_CMCU_TO_VDSP0               (CSRAM_BASE_ADDR + 0x00045400)
#define MSG_VEMCU0_TO_VDSP0             (CSRAM_BASE_ADDR + 0x00045800)
#define MSG_VDMCU0_TO_VDSP0             (CSRAM_BASE_ADDR + 0x00045C00)
#define MSG_CMCU_TO_VDSP1               (CSRAM_BASE_ADDR + 0x00046000)
#define MSG_VEMCU1_TO_VDSP1             (CSRAM_BASE_ADDR + 0x00046400)
#define MSG_VDMCU0_TO_VDSP1             (CSRAM_BASE_ADDR + 0x00046800)
#define MSG_VDMCU1_TO_VDSP1             (CSRAM_BASE_ADDR + 0x00046C00)
#define MSG_CMCU_TO_VDSP2               (CSRAM_BASE_ADDR + 0x00047000)
#define MSG_VEMCU2_TO_VDSP2             (CSRAM_BASE_ADDR + 0x00047400)
#define MSG_VDMCU1_TO_VDSP2             (CSRAM_BASE_ADDR + 0x00047800)
#define MSG_VDMCU2_TO_VDSP2             (CSRAM_BASE_ADDR + 0x00047C00)
#define MSG_CMCU_TO_VDSP3               (CSRAM_BASE_ADDR + 0x00048000)
#define MSG_VEMCU3_TO_VDSP3             (CSRAM_BASE_ADDR + 0x00048400)
#define MSG_VDMCU2_TO_VDSP3             (CSRAM_BASE_ADDR + 0x00048800)

#define MSG_RESERGE_0                   (CSRAM_BASE_ADDR + 0x00048C00)
#define MSG_PCIE_TO_CMCU                (CSRAM_BASE_ADDR + 0x00048C00)
#define MSG_SMCU_TO_CMCU                (CSRAM_BASE_ADDR + 0x00049000)
#define MSG_VDSP0_TO_CMCU               (CSRAM_BASE_ADDR + 0x00049400)
#define MSG_VDSP1_TO_CMCU               (CSRAM_BASE_ADDR + 0x00049800)
#define MSG_VDSP2_TO_CMCU               (CSRAM_BASE_ADDR + 0x00049C00)
#define MSG_VDSP3_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004A000)
#ifdef CONFIG_VASTAI_SG100_ENABLE
#define MSG_LMCU0_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004A400)
#define MSG_LMCU1_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004A600)
#define MSG_LMCU2_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004A800)
#define MSG_LMCU3_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004AA00)
#define MSG_LMCU4_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004AC00)
#define MSG_LMCU5_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004AE00)
#define MSG_LMCU6_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004B000)
#define MSG_LMCU7_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004B200)
#define MSG_ODSP0_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004B400)
#define MSG_ODSP1_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004B600)
#define MSG_ODSP2_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004B800)
#define MSG_ODSP3_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004BA00)
#define MSG_ODSP4_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004BC00)
#define MSG_ODSP5_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004BE00)
#define MSG_ODSP6_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004C000)
#define MSG_ODSP7_TO_CMCU               (CSRAM_BASE_ADDR + 0x0004C200)

#define MSG_RESERGE_1                   (CSRAM_BASE_ADDR + 0x0004C400)
#define MSG_CMCU_TO_PCIE                (CSRAM_BASE_ADDR + 0x0004C400)
#define MSG_CMCU_TO_LMCU0               (CSRAM_BASE_ADDR + 0x0004C800)
#define MSG_CMCU_TO_LMCU1               (CSRAM_BASE_ADDR + 0x0004CA00)
#define MSG_CMCU_TO_LMCU2               (CSRAM_BASE_ADDR + 0x0004CC00)
#define MSG_CMCU_TO_LMCU3               (CSRAM_BASE_ADDR + 0x0004CE00)
#define MSG_CMCU_TO_LMCU4               (CSRAM_BASE_ADDR + 0x0004D000)
#define MSG_CMCU_TO_LMCU5               (CSRAM_BASE_ADDR + 0x0004D200)
#define MSG_CMCU_TO_LMCU6               (CSRAM_BASE_ADDR + 0x0004D400)
#define MSG_CMCU_TO_LMCU7               (CSRAM_BASE_ADDR + 0x0004D600)
#endif
#define MSG_CMCU_TO_ODSP0               (CSRAM_BASE_ADDR + 0x0004D800)
#define MSG_CMCU_TO_ODSP1               (CSRAM_BASE_ADDR + 0x0004DA00)
#define MSG_CMCU_TO_ODSP2               (CSRAM_BASE_ADDR + 0x0004DC00)
#define MSG_CMCU_TO_ODSP3               (CSRAM_BASE_ADDR + 0x0004DE00)
#define MSG_CMCU_TO_ODSP4               (CSRAM_BASE_ADDR + 0x0004E000)
#define MSG_CMCU_TO_ODSP5               (CSRAM_BASE_ADDR + 0x0004E200)
#define MSG_CMCU_TO_ODSP6               (CSRAM_BASE_ADDR + 0x0004E400)
#define MSG_CMCU_TO_ODSP7               (CSRAM_BASE_ADDR + 0x0004E600)

#define MSG_CMCU_TO_LMCU_ODSP           (CSRAM_BASE_ADDR + 0x0004E800)

/* For queue msg, between host and vdmcus, vemcus, vdsps */
#define CEDAR_SVC_INFO                  (CSRAM_BASE_ADDR + 0x00051000)
#define CEDAR_RING_BUFFER_INFO          (CSRAM_BASE_ADDR + 0x00051000)
#define CEDAR_SVC_RNG_SYM_INFO          (CSRAM_BASE_ADDR + 0x00051400) /* 512BYTE */
#define CEDAR_SVC_TASK_DONE             (CSRAM_BASE_ADDR + 0x00051400) /* 512BYTE */
#define CEDAR_SVC_HASH_RES              (CSRAM_BASE_ADDR + 0x00051600)
#define CEDAR_SVC_STS_RES               (CSRAM_BASE_ADDR + 0x000517E0)
#define CEDAR_SVC_DONE_FLAG             (CSRAM_BASE_ADDR + 0x000517E4)
#define CSRAM_CEDAR_SYM_RES             (CSRAM_BASE_ADDR + 0x000517F0)
#define CSRAM_CEDAR_SYM_DONEFLAG        (CSRAM_BASE_ADDR + 0x000517F4)
#define CSRAM_CEDAR_ASY_RES             (CSRAM_BASE_ADDR + 0x000517F8)
#define CSRAM_CEDAR_ASY_DONEFLAG        (CSRAM_BASE_ADDR + 0x000517Fc)

#define QUEUE_MSG_BASE                  (CSRAM_BASE_ADDR + 0X00052000)

#define MSG_SMCUQ0_TO_PCIE              (CSRAM_BASE_ADDR + 0x00051800)
#define MSG_SMCUQ1_TO_PCIE              (CSRAM_BASE_ADDR + 0x00051C00)
#define MSG_VDMCU0_TO_PCIE              (CSRAM_BASE_ADDR + 0x00052000)
#define MSG_VDMCU1_TO_PCIE              (CSRAM_BASE_ADDR + 0x00052400)
#define MSG_VDMCU2_TO_PCIE              (CSRAM_BASE_ADDR + 0x00052800)
#define MSG_VEMCU0_TO_PCIE              (CSRAM_BASE_ADDR + 0x00052C00)
#define MSG_VEMCU1_TO_PCIE              (CSRAM_BASE_ADDR + 0x00053000)
#define MSG_VEMCU2_TO_PCIE              (CSRAM_BASE_ADDR + 0x00053400)
#define MSG_VEMCU3_TO_PCIE              (CSRAM_BASE_ADDR + 0x00053800)
#define MSG_VDSP0_TO_PCIE               (CSRAM_BASE_ADDR + 0x00053C00)
#define MSG_VDSP1_TO_PCIE               (CSRAM_BASE_ADDR + 0x00054000)
#define MSG_VDSP2_TO_PCIE               (CSRAM_BASE_ADDR + 0x00054400)
#define MSG_VDSP3_TO_PCIE               (CSRAM_BASE_ADDR + 0x00054800)

#define MSG_PCIE_TO_SMCUQ0              (CSRAM_BASE_ADDR + 0x00054C00)
#define MSG_PCIE_TO_SMCUQ1              (CSRAM_BASE_ADDR + 0x00055000)
#define MSG_PCIE_TO_VDMCU0              (CSRAM_BASE_ADDR + 0x00055400)
#define MSG_PCIE_TO_VDMCU1              (CSRAM_BASE_ADDR + 0x00055800)
#define MSG_PCIE_TO_VDMCU2              (CSRAM_BASE_ADDR + 0x00055C00)
#define MSG_PCIE_TO_VEMCU0              (CSRAM_BASE_ADDR + 0x00056000)
#define MSG_PCIE_TO_VEMCU1              (CSRAM_BASE_ADDR + 0x00056400)
#define MSG_PCIE_TO_VEMCU2              (CSRAM_BASE_ADDR + 0x00056800)
#define MSG_PCIE_TO_VEMCU3              (CSRAM_BASE_ADDR + 0x00056C00)
#define MSG_PCIE_TO_VDSP0               (CSRAM_BASE_ADDR + 0x00057000)
#define MSG_PCIE_TO_VDSP1               (CSRAM_BASE_ADDR + 0x00057400)
#define MSG_PCIE_TO_VDSP2               (CSRAM_BASE_ADDR + 0x00057800)
#define MSG_PCIE_TO_VDSP3               (CSRAM_BASE_ADDR + 0x00057C00)

#define MODULE_INFO_BASE                (CSRAM_BASE_ADDR + 0x00058000)     /* 510k */
#define CHN_INFO_BASE                   (CSRAM_BASE_ADDR + 0x000D7800)     /* 100k */
#define VDMCU_CSR_BASE                  (CSRAM_BASE_ADDR + 0x000F0800)     /* 10k */

/* Total 1024 bytes for version */
#define SG_VSERSION_INFO_BASE              (SG_CSRAM_BASE_ADDR + 0x000E1000)     /* total 1024 bytes */
#define SG_FW_VERSION                      (SG_CSRAM_BASE_ADDR + 0x000E1000)     /* 64 bytes */
#define SG_SMCU_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E1040)     /* 64 bytes */
#define SG_CMCU_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E1080)     /* 64 bytes */
#define OMCU_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E10C0)     /* 64 bytes */
#define GMCU_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E1100)     /* 64 bytes */
#define SG_VEMCU_VERSION                   (SG_CSRAM_BASE_ADDR + 0x000E1140)     /* 64 bytes */
#define SG_ODSP_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E1180)     /* 64 bytes */
#define SG_VDSP_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E11C0)     /* 64 bytes */
#define PMCU_VERSION                    (SG_CSRAM_BASE_ADDR + 0x000E1200)     /* 64 bytes */
#define SG_VDMCU_VERSION                   (SG_CSRAM_BASE_ADDR + 0x000E1240)     /* 64 bytes */

/* smi of tools */
#define SG_SMI_INFO_ADDR                   (CSRAM_BASE_ADDR + 0x000E1600) /* 2KB + 512B */

/* profiler of tools; total 2KB */
#define SG_PERFORMANCE_AI_BASE             (CSRAM_BASE_ADDR + 0x000E2000)      // 256 bytes
#define SG_PERFORMANCE_AI_CMCU             (CSRAM_BASE_ADDR + 0x000E2000)      // 8 bytes
#define PERFORMANCE_AI_OMCU0            (CSRAM_BASE_ADDR + 0x000E2008)      // 8 bytes
#define PERFORMANCE_AI_OMCU1            (CSRAM_BASE_ADDR + 0x000E2010)      // 8 bytes
#define PERFORMANCE_AI_GMCU0            (CSRAM_BASE_ADDR + 0x000E2018)      // 8 bytes
#define PERFORMANCE_AI_GMCU1            (CSRAM_BASE_ADDR + 0x000E2020)      // 8 bytes
#define PERFORMANCE_AI_GMCU2            (CSRAM_BASE_ADDR + 0x000E2028)      // 8 bytes
#define PERFORMANCE_AI_GMCU3            (CSRAM_BASE_ADDR + 0x000E2030)      // 8 bytes
#define SG_PERFORMANCE_AI_VEMCU0        (CSRAM_BASE_ADDR + 0x000E2038)      // 8 bytes
#define SG_PERFORMANCE_AI_VEMCU1        (CSRAM_BASE_ADDR + 0x000E2040)      // 8 bytes
#define SG_PERFORMANCE_AI_VEMCU2        (CSRAM_BASE_ADDR + 0x000E2048)      // 8 bytes
#define SG_PERFORMANCE_AI_VEMCU3        (CSRAM_BASE_ADDR + 0x000E2050)      // 8 bytes
#define SG_PERFORMANCE_AI_ODSP0         (CSRAM_BASE_ADDR + 0x000E2058)      // 8 bytes
#define SG_PERFORMANCE_AI_ODSP1         (CSRAM_BASE_ADDR + 0x000E2060)      // 8 bytes
#define SG_PERFORMANCE_AI_VDSP0         (CSRAM_BASE_ADDR + 0x000E2068)      // 12 bytes
#define SG_PERFORMANCE_AI_VDSP1         (CSRAM_BASE_ADDR + 0x000E2074)      // 12 bytes
#define PERFORMANCE_AI_PMCU             (CSRAM_BASE_ADDR + 0x000E2080)      // 8 bytes
#define PERFORMANCE_AI_SMCU             (CSRAM_BASE_ADDR + 0x000E2088)      // 8 bytes
#define SG_PCIE_BANDWIDTH_UPSTREAM      (CSRAM_BASE_ADDR + 0x000E2090)      // 8 bytes
#define SG_PCIE_BANDWIDTH_DOWNSTREAM    (CSRAM_BASE_ADDR + 0x000E2098)      // 8 bytes
// fw mcu cycle count, for host compute time diff
#define SG_PERFORMANCE_AI_CMCU_CYCLE    (CSRAM_BASE_ADDR + 0x000E20A0)      // 4 bytes
#define SG_PERFORMANCE_AI_VDSP0_CYCLE   (CSRAM_BASE_ADDR + 0x000E20A4)      // 4 bytes
#define SG_PERFORMANCE_AI_VDSP1_CYCLE   (CSRAM_BASE_ADDR + 0x000E20A8)      // 4 bytes
#define DDR_BANDWIDTH_UPSTREAM          (CSRAM_BASE_ADDR + 0x000E20AC)      // 8 bytes
#define DDR_BANDWIDTH_DOWNSTREAM        (CSRAM_BASE_ADDR + 0x000E20B4)      // 8 bytes

/* debugger of tools; total 4KB */
#define DEBUGGER_INFO_ADDR              (CSRAM_BASE_ADDR + 0x000E2800)      /* 4KB */

#define SG_CSRAM_RESEREVE2                 (CSRAM_BASE_ADDR + 0x000F4000)      /* 12K */

/* msix table VF0 -- VF7, 32k bytes */
#define SG_PCIE_MSIX_VF_TABLE              (CSRAM_BASE_ADDR + 0x000F7000)      /* 32K */


/* PF, msix table */
#define PCIE_MSIX_PF_PENDING_TABLE      (CSRAM_BASE_ADDR + 0x000FF000)      /* 2K */
#define PCIE_MSIX_PF_TABLE              (CSRAM_BASE_ADDR + 0x000FF800)      /* 2K */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __CSRAM_PARTITION_H__ */
#endif /* SG100_USED */
