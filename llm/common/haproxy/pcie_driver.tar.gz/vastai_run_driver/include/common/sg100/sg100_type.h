#ifdef SG100_USED
#ifndef __SG100_TYPE_H__
#define __SG100_TYPE_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "config.h"

#if defined(__SMCU__) || defined(__GMCU__)
#include <stdio.h>
#include <string.h>

typedef volatile unsigned int    __io;
typedef unsigned int            size_t;
typedef char                    bool;
#endif

typedef signed char             s8;
typedef unsigned char           u8;
typedef unsigned char           byte;
typedef unsigned char           uint8_t;
typedef signed short            s16;
typedef unsigned short          u16;
typedef unsigned short          uint16_t;
typedef signed int              s32;
typedef unsigned int            u32;
typedef unsigned int            uint32_t;
typedef signed long long        s64;
typedef unsigned long long      u64;
typedef unsigned long long      uint64_t;

#ifndef _WIN32
#define FALSE                   (0U)
#define TRUE                    (1U)
#endif

#define SUCCESS                 (0)
#define FAIL                    (-1)

#define DISABLE                 (0U)
#define ENABLE                  (1U)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SG100_TYPE_H__ */
#endif /* SG100_USED */
