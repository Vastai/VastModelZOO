#ifdef SG100_USED
#ifndef __DDR_PARTITION_H__
#define __DDR_PARTITION_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SG_DDR_BASE_ADDR 0x1000000000ULL          /* 64GB */

/* MCU, DSP CODE AREA TOTAL 128M Bytes, Reset vector */
#define SMCU_RESET_VECTOR_VALUE             (SG_DDR_BASE_ADDR + 0x00000000)    /* size 2M 0x10_00000000 */
#define CMCU_RESET_VECTOR_VALUE             (SG_DDR_BASE_ADDR + 0x00200000)    /* size 2M 0x10_00200000 */
#define LMCU0_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x00400000)    /* size 2M */
#define LMCU1_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x00600000)    /* size 2M */
#define GMCU0_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x00800000)    /* size 4M 0x10_00800000 */
#define GMCU1_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x00C00000)    /* size 4M 0x10_00C00000 */
#define GMCU2_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x01000000)    /* size 4M 0x10_01000000 */
#define GMCU3_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x01400000)    /* size 4M 0x10_01400000 */
#define VEMCU0_RESET_VECTOR_VALUE           (SG_DDR_BASE_ADDR + 0x01800000)    /* size 8M 0x10_01800000 */
#define VEMCU1_RESET_VECTOR_VALUE           (SG_DDR_BASE_ADDR + 0x02000000)    /* size 8M */
#define VEMCU2_RESET_VECTOR_VALUE           (SG_DDR_BASE_ADDR + 0x02800000)    /* size 8M */
#define VEMCU3_RESET_VECTOR_VALUE           (SG_DDR_BASE_ADDR + 0x03000000)    /* size 8M */
#define ODSP0_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x03800000)    /* size 8M */
#define ODSP1_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x04000000)    /* size 8M */
#define VDSP0_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x04800000)    /* size 8M */
#define VDSP1_RESET_VECTOR_VALUE            (SG_DDR_BASE_ADDR + 0x05000000)    /* size 8M */
#define ODSP_SHARE_DATA_BASE_SG                (SG_DDR_BASE_ADDR + 0x05800000)    /* size 16M */
#define PMCU_RESET_VECTOR_VALUE             (SG_DDR_BASE_ADDR + 0x06800000)    /* size 8M 0x10_06800000 */
#define CODE_RESERVER_BASE_SG               (SG_DDR_BASE_ADDR + 0x06A00000)    /* size 22M */

#define PF_COMMON_BASE                      (SG_DDR_BASE_ADDR + 0x38000000)    /* size 128MB. For PF management/debug/reset 128MB/encrypted fw on boot. */

/* For each PF (pf=0,1,2,3), Total: PF x 4= (7GB + 768MB) x 4 = 31GB */
#define ADDR_DDR_SIZE_PER_PF                (0x01F0000000ULL)               /* (0x1_C000_0000 7GB + 0x3000_0000 768MB) */
#define PFn_DDR_BASE(p,per_pf_ddr_sz)       (0x1040000000ULL + (p)*per_pf_ddr_sz)
#define VF_MANAGEMENT_OFFSET                (0)                             /* size 94MB */
#define META_FIRMWARE_OFFSET                (0x5E00000)                     /* (0x10_45E0_0000 - 0x10_4000_0000) size 2MB */
#define VF_MANAGEMENT_PER_PF(p)             (PFn_DDR_BASE(p) + VF_MANAGEMENT_OFFSET)     /* size 94MB */
#define META_FIRMWARE_PER_PF(p)             (PFn_DDR_BASE(p) + META_FIRMWARE_OFFSET)     /* size 2MB */

/* For each VF in each PF, VFn=1,2,3,4,5,6,7, required 16MB align.  VF0 is not needed. */
#define ADDR_DDR_SIZE_PER_VF                (0x46000000ULL)                 /* 1GB 0x4000_0000+ 96MB 0x600_0000 */
#define VFn_DDR_BASE(p, v,per_pf_ddr_sz,per_vf_ddr_sz)      \
                                            (PFn_DDR_BASE(p,per_pf_ddr_sz) + 0x6000000 + (v-1) * per_vf_ddr_sz)
/* Share to host 256MB in each VF */
#define VIDEO_16M_IN_VF_OFFSET              (0)                             /* size 1MB */
#define DYNAMIC_MALLOC_IN_VF_OFFSET         (0x01000000)                    /* 0x10_4700_0000 - 0x10_4600_0000 */
/* Dynamic alloc */
#define CHN_MODEL_SHARE_BUFFER_OFFSET       (0x11000000)                    /* 0x10_5700_0000 - 0x10_4600_0000 */

#define SHARE_TO_HOST_VIDEO_16M_PER_VF(p, v)           (VFn_DDR_BASE(p, v) + VIDEO_16M_IN_VF_OFFSET)
#define SHARE_TO_DYNAMIC_MALLOC_PER_VF(p, v)           (VFn_DDR_BASE(p, v) + DYNAMIC_MALLOC_IN_VF_OFFSET)
#define DYN_ALLOC_CHN_MODEL_SHARE_BUFFER_PER_VF(p, v)  (VFn_DDR_BASE(p, v) + CHN_MODEL_SHARE_BUFFER_OFFSET)

/* The local share data, include local msg and log buf on ddr, total 64M */
#define LOCAL_SHARE_BASE_SG                 (SG_DDR_BASE_ADDR    + 0x30000000) /* size 1M */
#define MSG_TO_SMCU_SG                      (LOCAL_SHARE_BASE_SG + 0x00000000) /* size 1M */
#define MSG_TO_CMCU_SG                      (LOCAL_SHARE_BASE_SG + 0x00100000) /* size 1M */


/* each core's log buf is 1M Bytes. */
#define LOG_BUF_BASE_SG                        (LOCAL_SHARE_BASE_SG + 0x02000000)
#define SMCU_LOG_BASE_SG                       (LOG_BUF_BASE_SG + 0x00000000)
#define CMCU_LOG_BASE_SG                    (LOG_BUF_BASE_SG + 0x00100000)

#define OMCU0_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00200000)
#define OMCU1_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00300000)
#define GMCU0_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00400000)
#define GMCU1_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00500000)
#define GMCU2_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00600000)
#define GMCU3_LOG_BASE                      (LOG_BUF_BASE_SG + 0x00700000)

#define SG_VEMCU0_LOG_BASE                  (LOG_BUF_BASE_SG + 0x00800000)
#define SG_VEMCU1_LOG_BASE                  (LOG_BUF_BASE_SG + 0x00900000)
#define SG_VEMCU2_LOG_BASE                  (LOG_BUF_BASE_SG + 0x00a00000)
#define SG_VEMCU3_LOG_BASE                  (LOG_BUF_BASE_SG + 0x00b00000)
#define SG_ODSP0_LOG_BASE                   (LOG_BUF_BASE_SG + 0x00c00000)
#define SG_ODSP1_LOG_BASE                   (LOG_BUF_BASE_SG + 0x00d00000)
#define SG_VDSP0_LOG_BASE                   (LOG_BUF_BASE_SG + 0x00e00000)
#define SG_VDSP1_LOG_BASE                   (LOG_BUF_BASE_SG + 0x00f00000)
#define PMCU_LOG_BASE                       (LOG_BUF_BASE_SG + 0x01000000)


// TBD, by keye

/* Include pcie dma config, chn info, moduel info and sr-iov reserved.
 * This is a backup for csram space not enough.
 *  2M * 4die = 64M
 */
#define SG_SHARE_TO_HOST_BASE                  (SG_DDR_BASE_ADDR + 0x14000000)
#define ENCODER_DATA_BASE_SG                (SG_SHARE_TO_HOST_BASE + 0x00000000) /* size 16M */
#define DECODER_DATA_BASE_SG                (SG_SHARE_TO_HOST_BASE + 0x01000000) /* size 1M */
#define SG_SR_IOV_BASE_ADDR                 (SG_SHARE_TO_HOST_BASE + 0x01100000) /* size 15M */

/* The partition is a temporay allocation, Total 736M,
 * subsequent encoders need to optimize the heap size. 
 */
#define SG_ENCODER_HEAP_BASE                (SG_DDR_BASE_ADDR + 0x16000000)
#define SG_ENCODER_RESERVED                 (SG_ENCODER_HEAP_BASE + 0x00000000) /* size 32M */
#define SG_ENCODER_CMD_BUF                  (SG_ENCODER_HEAP_BASE + 0x02000000) /* size 64M */
#define SG_VEMCU0_HEAP_BASE                 (SG_ENCODER_HEAP_BASE + 0x06000000) /* size 160M */
#define SG_VEMCU1_HEAP_BASE                 (SG_ENCODER_HEAP_BASE + 0x10000000) /* size 160M */
#define SG_VEMCU2_HEAP_BASE                 (SG_ENCODER_HEAP_BASE + 0x1A000000) /* size 160M */
#define SG_VEMCU3_HEAP_BASE                 (SG_ENCODER_HEAP_BASE + 0x24000000) /* size 160M */

#define DDR_DYNAMIC_ALLOC_BASE_SG           (SG_DDR_BASE_ADDR + 0x44000000)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DDR_PARTITION_H__ */
#endif /* SG100_USED */
