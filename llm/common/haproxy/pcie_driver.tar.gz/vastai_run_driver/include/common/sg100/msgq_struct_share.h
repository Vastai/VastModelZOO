#ifdef SG100_USED
#ifndef __MSGQ_STRUCT_SHARE_H__
#define __MSGQ_STRUCT_SHARE_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#include "config.h"
#if defined(__GMCU__) || defined(__SMCU__)
#include "sg100_type.h"
#endif
#define PCIE2_DMA_WR_DEV_TO_MEM 0
#define PCIE2_DMA_RD_MEM_TO_DEV 1

enum host_irq_num {
	PCIE2_HDMA0_IRQ = 0,
	PCIE2_HDMA1_IRQ = 8,
	PCIE2_HDMA2_IRQ = 16,
	PCIE2_HDMA3_IRQ = 24,
	VASTAI_SMMU_IRQ = 32,
	HOST_IRQ_MAX    = 33
};

struct pcie_transmit_stat
{
	u32 ctrl_flag;
	u64 tx_tlp_cnt;
	u64 tx_payload_cnt;
	u64 rx_tlp_cnt;
	u64 rx_payload_cnt;
} __attribute__((packed));

struct host_irq_pcie2_dma_msg {
	u32 dir: 1;
	u32 loc: 1;
	u32 reserve: 14;
	u32 done_nums: 16;
};

struct host_irq_msg {
	u32 irq_num;
	union {
		struct host_irq_pcie2_dma_msg pcie2_dma;
	} msg;
} __attribute__((packed));

struct vdm_irq_data {
	u32 irq_source;
	u32 reg_value;
	u32 hpd_status;
} __attribute__((packed));

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MSGQ_STRUCT_SHARE_H__ */
#endif /* SG100_USED */
