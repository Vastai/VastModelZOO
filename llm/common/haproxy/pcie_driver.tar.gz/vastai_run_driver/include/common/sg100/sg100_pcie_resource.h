#ifdef SG100_USED
#ifndef __SG100_PCIE_RESOURCE_H__
#define __SG100_PCIE_RESOURCE_H__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "sg100_type.h"

#define PKG_PF_CNT_1                    1
#define PKG_PF_CNT_2                    2
#define PKG_PF_CNT_4                    4

#define REGION_UNIT5                    5

#define SLAVE_PF0_BAR0_REGION_ID        251
#define DSU_REGION_ID                   252
#define DP_REGION_ID                    253

#define REGION_NUM_1                    1
#define REGION_NUM_2                    2
#define REGION_NUM_4                    4
#define REGION_NUM_32                   32

#define PCIE_WRAPPER_ADDR               0x942000
#define PWRAP_COMMON_LOCK0_VAL          0x1

#define SPACE_SIZE_512G                 0x8000000000ULL     /* 512GB */
#define SPACE_SIZE_256G                 0x4000000000ULL     /* 256GB */
#define SPACE_SIZE_128G                 0x2000000000ULL     /* 128GB */
#define SPACE_SIZE_16G                  0x0400000000ULL     /* 16GB  */
#define SPACE_SIZE_128G                 0x2000000000ULL     /* 128G  */
#define SPACE_SIZE_64G                  0x1000000000ULL     /* 64G   */
#define SPACE_SIZE_4G                   0x100000000ULL      /* 4G    */
#define SPACE_SIZE_2G                   0x80000000          /* 2G    */
#define SPACE_SIZE_1G                   0x40000000ULL       /* 1G    */
#define SPACE_SIZE_256M                 0x10000000ULL       /* 256M  */
#define SPACE_SIZE_32M                  0x2000000           /* 32M   */
#define SPACE_SIZE_96M                  0x6000000           /* 96M   */
#define SPACE_SIZE_2M                   0x0000200000        /* 2M    */
#define SPACE_SIZE_1M                   0x0000100000        /* 1M    */
#define SPACE_SIZE_4K                   0x0000001000        /* 4K    */
#define SPACE_SIZE_8K                   0x0000002000        /* 8K    */
#define SPACE_SIZE_12K                  0x0000003000        /* 12K    */
#define SPACE_SIZE_32K                  0x0000008000        /* 32K   */
#define SPACE_SIZE_64K                  0x0000010000        /* 64K   */
#define SPACE_SIZE_128K                 0x0000020000        /* 128K  */
#define SPACE_SIZE_192K                 0x0000030000        /* 192K  */
#define SPACE_SIZE_224K                 0x0000038000        /* 224K  */
#define SPACE_SIZE_448K                 0x0000070000        /* 448K  */
#define SPACE_SIZE_512K                 0x0000080000        /* 512K  */
#define SPACE_SIZE_820K                 0x00000CD000        /* 820K  */
#define SPACE_SIZE_1012K                0x00000FD000        /* 1012K */

/* match with BIT_WRAP_COMM51_DDR_BAR_SZ definition. 
 * b[9:7] ddr_bar_size, 0:2GB  1:4GB 2:8GB 3:16GB 4:32GB 5:64GB
 *
**/
enum DDR_BAR4_5_SZ_ID {
    DDR_BAR_SZ_ID_02GB  = 0,
    DDR_BAR_SZ_ID_04GB  = 1,
    DDR_BAR_SZ_ID_08GB  = 2,
    DDR_BAR_SZ_ID_16GB  = 3,
    DDR_BAR_SZ_ID_32GB  = 4,
    DDR_BAR_SZ_ID_64GB  = 5,
    DDR_BAR_SZ_ID_MAXGB = 6
};

#define REGION_SIZE_CSRAM_PER_PF        ADDR_CSRAM_SIZE_PER_PF         /* 224KB */
#define REGION_SIZE_SMU_CSR_PER_PF      0x8000                         /* 32KB */
#define REGION_SIZE_GFX_CSR_PER_PF      0x80000                        /* 512KB */
#define REGION_SIZE_SMCU_CSRAM          0x8000                         /* 32KB */
#define REGION_SIZE_DP_CSR_PER_PF       0x100000                       /* 1MB */
#define REGION_SIZE_DSU_CSR_PER_PF      0x20000                        /* 128K */
#define REGION_SIZE_GFX_CSR_PER_VF      0x10000                        /* 512KB */

#define VFn_GFX_CSR_BASE(p, v)          (SG100_GFX0_REG_BASE + p*REGION_SIZE_GFX_CSR_PER_PF + v*REGION_SIZE_GFX_CSR_PER_VF)

#define REGION_SIZE_DDR_PER_PF          0x1f0000000ULL                 /* 7GB + 768MB */
#define LARGE_BAR_DDR_PER_PF_64GB       0xFC0000000ULL                 /* 63GB*/
#define LARGE_BAR_DDR_PER_PF_32GB       0x7E0000000ULL                 /* 32256MB = 31GB + 512MB */
#define LARGE_BAR_DDR_PER_PF_16GB       0x3F0000000ULL                 /* 16128MB = 15GB + 768MB */
#define LARGE_BAR_DDR_PER_PF_8GB        0x1f0000000ULL                 /* 7GB + 768MB */
#define LARGE_BAR_DDR_PER_PF_4GB        0xF0000000ULL                  /* 3840MB  = 3GB + 768MB */
#define REGION_SIZE_DDR_PER_VF          0x10000000                     /* 256M */
#define REGION_ADDR_DDR_PER_VF          0x46000000                     /* 1GB + 96MB */

/* Romcode stage Bar mapping */
#define VASTAI_PCI_BAR0_ADDR            (0)                             /* PF0: 256KB/8KB/64 KB, default 8KB; PF1-7: 8KB */
#define VASTAI_PCI_BAR2_ADDR            (CSRAM_BASE_ADDR)
#define VASTAI_PCI_BAR4_ADDR_R          (SG_DDR_BASE_ADDR + 0x38000000)    /* romcode for PF0-7, 0x1038000000 */
#define VASTAI_PCI_BAR4_ADDR_F          (SG_DDR_BASE_ADDR + 0x40000000)    /* boot finish for PF0-3 */    

/* multi-pkg boot slave pkg stage */
#define VASTAI_PKG1_BASE                        0x2000000000ULL              /* 128G */
#define MASTER_PKG_EP_BAR1_PCIE_WRAPPER_ADDR    0x2000942000ULL 
#define BAR2_BOOTS_CSRAM_SZ                     0xFD000                      /* 1M -12K */
#define BAR2_BOOTS_4K_CONFIG_SZ                 0x01000                      /* 4K */
#define BAR2_BOOTS_4K_CONFIG_ADDR(p)            (0x30000000 + ((p) % 4) * 0x1000)
#define BAR2_DP_CSR_ADDR                        0x280000                     /* only for PF0 & dp enabled */
#define BAR2_DP_CSR_1M_SZ                       0x100000                     /* 1M */
#define BAR2_DSU_CSR_ADDR                       0xA80000                     /* only for PF0 & dp enabled */
#define BAR2_DSU_CSR_128K_SZ                    0x20000                      /* 128K */
#define BAR2_BOOTS_RESERVED_ADDR                0xAA0000                     /* 1M + 896K, only for PF0 & dp enabled */
#define BAR4_DDR_2G_ADDR_F(p, sp)              (SPACE_SIZE_4G + (p-sp)*SPACE_SIZE_4G) /* for each PF */ //need remove.

/* multi-pkg boot finish stage */
#define BAR2_SLAVE_PKG_BAR23_ADDR(p, sp)       (0x40000000 + (p-sp)*SPACE_SIZE_2M)
#define BAR2_SLAVE_PKG_BAR0_ADDR           0x40800000                            /* only PF4 have the region mapping to BAR0 of Slave pkg */
#define BAR2_SLAVE_PKG_BAR23_SZ_PF4        0xCD000                          // need remove.

#define BAR2_COMM_PCIE_WRAPPER_SZ          0x2000                                /* 8K, map to maser pkg pcie wrapper for communication with SMCU */
#define BAR2_SLAVE_PKG_CFG_SPACE_ADDR(p, sp)   (0x30000000 + (p-sp)*SPACE_SIZE_4K)    /* map to slave pkg config space 4K */
#define BAR2_SLAVE_PKG_CFG_SPACE_SZ        0x1000

// #define BAR4_DDR_2G_ADDR_F(p, sp)              (SPACE_SIZE_4G + (p-sp)*SPACE_SIZE_4G)/* for each PF */
#define BAR4_DDR_2G_SZ                     SPACE_SIZE_2G

typedef union atu_match_cfg {
    // bar match mode
    struct atu_bar_match_cfg {
       // Only PF0 can config ATU. ipf is always 0.
        u32 ipf;
        u32 bar_id;
        u32 region_id;
        u64 target_addr;
    }bar_match;

    // address match mode
    struct atu_addr_match_cfg {
        u32 ipf;
        u32 bar_id;
        u32 region_id;
        u64 target_addr;
        u64 base_addr;
        u64 region_size;
    }addr_match;
}atu_cfg_param;

extern void pcie_ATU_inbound_bar_match(int ipf, int bar_num, u64 target_addr, int in_region_num);
extern void disable_atu_region(int ipf, int region_num);
#ifdef __cplusplus
}
#endif

#endif
#endif /* SG100_USED */
