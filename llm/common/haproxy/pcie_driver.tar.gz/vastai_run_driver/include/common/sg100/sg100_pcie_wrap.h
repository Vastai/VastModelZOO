#ifdef SG100_USED
#ifndef __SG100_PCIE_WRAP_H__
#define __SG100_PCIE_WRAP_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define PCIE_EP_VASTAI_PHY_BASE_ADDR                    0x940000
#define PCIE_RC_VASTAI_PHY_BASE_ADDR                    0x960000
#define PCIE_WRAPPER_BASE                               0x940000

// interrupt source from "clean Hot-Rst event" issued by host
#define PCIE_WRAPPER_SII_LINKRSTS                       (PCIE_EP_VASTAI_PHY_BASE_ADDR+519*4)  // 0x94081C 
#define BIT_LD_HOT_RST_INT                              1                                     // W1C
#define BIT_HOT_RST_EARLY_INT                           5                                     // W1C

#define BIT_SLAVE_SMCU_STAGE_ALLCORE_READY              (6<<24)
#define SMCU_SLAVE_DIE_BOOT_DONE                        (1<<0)
#define BIT_MASTER_ATU_BOOT_SLAVE_BAR_READY             (1<<20)

// 32’d1: hot reset issued Reinit-Reset, 32’d2: PF FLR issued,32’3: conditional trigger from SW,32’4: unconditional trigger from SW
#define    PCIE_WRAPPER_REINIT_RST_SOURCE_HOST_ONLY    (PCIE_EP_VASTAI_PHY_BASE_ADDR+2050*4) // 0x942008, RO,
#define    PCIE_WRAPPER_REINIT_RST_HOST                (PCIE_EP_VASTAI_PHY_BASE_ADDR+2048*4) // 0x942000, host reset soc.
#define    PCIE_WRAPPER_HOST_RW_BOOT_STATUS            (PCIE_EP_VASTAI_PHY_BASE_ADDR+2049*4) // 0x942004, host notifies smu.  specific bits.
#define    PCIE_WRAPPER_HOST_RD_SMCU_STATUS            (PCIE_EP_VASTAI_PHY_BASE_ADDR+2051*4) // 0x94200C, only available to host. same value with PCIE_WRAPPER_SMCU_WR_BOOT_STATUS
#define    PCIE_WRAPPER_SMCU_WR_BOOT_STATUS            (PCIE_EP_VASTAI_PHY_BASE_ADDR+1488*4) // 0x941740, smu notifies host

/*
 * PCIE_WRAPPER_HOST_RW_BOOT_STATUS
 * bit[31:30]: current die id.
 *            2'h0:die0, 2'h1:die1, 2'h2:die2, 2'h3:die3
 * bit[26:24]: host boot stage.
 *             3'h0: initial state
 *             3'h1: bl1 download finish
 *             3'h2: fw download finish
 *             3'h3: all dies download finish, host ready
 *             3'h4: Recv smcu notice that fw boot up successfully
 *             3'h5: Recv smcu notice that current die pcie init finish
 *             3'h6: Recv smcu notice that all mcu and dsp of current die init finish
 */
#define VASTAI_SG_HOST_BOOT_STAGE_REG      PCIE_WRAPPER_HOST_RW_BOOT_STATUS
#define PCIE_HOST_BOOT_STATUS           PCIE_WRAPPER_HOST_RW_BOOT_STATUS        /* FW use it. */

/*
 * PCIE_WRAPPER_HOST_RD_SMCU_STATUS
 * bit[31:29]: die config, refer to struct vastai_die_cfg table
 * bit[28]: current die ep and front die or host  rc link up flag
 * bit[27]: current die rc and next die ep link up flag
 * bit[26:24]: smcu boot stage.
 *             3'h0: initial state
 *             3'h1: wait for downloading bl1 (bootloader1)
 *             3'h2: bl1 verify pass
 *             3'h3: wait for downloading fw (firmware)
 *             3'h4: fw verify pass 
 *             3'h5: fw boot up successfully
 *             3'h6: current die pcie init finish
 *             3'h7: all mcu and dsp of current die init finish
 */
#define VASTAI_SG_SMCU_BOOT_STAGE_REG        PCIE_WRAPPER_HOST_RD_SMCU_STATUS
#define PCIE_SMCU_BOOT_STATUS             PCIE_WRAPPER_SMCU_WR_BOOT_STATUS          /* FW use it. */


/* PCIe Wrapper */
#define PWRAP_COMMON_LOCK0                (PCIE_WRAPPER_BASE + 2054*4)    /* 0x2018, boot lock */

/* Core Sync */
#define PWRAP_COMMON16_COSYNC_SMCU        (PCIE_WRAPPER_BASE + 2070*4)    /* 0x942058, core sync, SMCU */
#define PWRAP_COMMON17_COSYNC_PMCU        (PCIE_WRAPPER_BASE + 2071*4)    /* 0x94205C, core sync, PMCU */
#define PWRAP_COMMON18_COSYNC_GMCU0       (PCIE_WRAPPER_BASE + 2072*4)    /* 0x942060, core sync, GMCU0 */
#define PWRAP_COMMON19_COSYNC_GMCU1       (PCIE_WRAPPER_BASE + 2073*4)    /* 0x942064, core sync, GMCU1 */
#define PWRAP_COMMON20_COSYNC_GMCU2       (PCIE_WRAPPER_BASE + 2074*4)    /* 0x942068, core sync, GMCU2 */
#define PWRAP_COMMON21_COSYNC_GMCU3       (PCIE_WRAPPER_BASE + 2075*4)    /* 0x94206C, core sync, GMCU3 */
#define PWRAP_COMMON22_COSYNC_VDSP0       (PCIE_WRAPPER_BASE + 2076*4)    /* 0x942070, core sync, VDSP0 */
#define PWRAP_COMMON23_COSYNC_VDSP1       (PCIE_WRAPPER_BASE + 2077*4)    /* 0x942074, core sync, VDSP1 */
#define PWRAP_COMMON24_COSYNC_CMCU        (PCIE_WRAPPER_BASE + 2078*4)    /* 0x942078, core sync, CMCU */
#define PWRAP_COMMON25_COSYNC_OMCU0       (PCIE_WRAPPER_BASE + 2079*4)    /* 0x94207C, core sync, OMCU0 */
#define PWRAP_COMMON26_COSYNC_OMCU1       (PCIE_WRAPPER_BASE + 2080*4)    /* 0x942080, core sync, OMCU1 */
#define PWRAP_COMMON27_COSYNC_ODSP0       (PCIE_WRAPPER_BASE + 2081*4)    /* 0x942084, core sync, ODSP0 */
#define PWRAP_COMMON28_COSYNC_ODSP1       (PCIE_WRAPPER_BASE + 2082*4)    /* 0x942088, core sync, ODSP1 */
#define PWRAP_COMMON29_COSYNC_VEMCU0      (PCIE_WRAPPER_BASE + 2083*4)    /* 0x94208C, core sync, VEMCU0 */
#define PWRAP_COMMON30_COSYNC_VEMCU1      (PCIE_WRAPPER_BASE + 2084*4)    /* 0x942090, core sync, VEMCU1 */
#define PWRAP_COMMON31_COSYNC_VEMCU2      (PCIE_WRAPPER_BASE + 2085*4)    /* 0x942094, core sync, VEMCU2 */
#define PWRAP_COMMON32_COSYNC_VEMCU3      (PCIE_WRAPPER_BASE + 2086*4)    /* 0x942098, core sync, VEMCU3 */

/* Heart Beat */
#define PWRAP_COMMON33                    (PCIE_WRAPPER_BASE + 2087*4)    /* 0x209C, SMCU heartbeat */
#define PWRAP_COMMON34                    (PCIE_WRAPPER_BASE + 2088*4)    /* 0x20A0, PMCU heartbeat */
#define PWRAP_COMMON35                    (PCIE_WRAPPER_BASE + 2089*4)    /* 0x20A4, CMCU heartbeat */
#define PWRAP_COMMON36                    (PCIE_WRAPPER_BASE + 2090*4)    /* 0x20A8, OMCU0 heartbeat */
#define PWRAP_COMMON37                    (PCIE_WRAPPER_BASE + 2091*4)    /* 0x20AC, OMCU1 heartbeat */
#define PWRAP_COMMON38                    (PCIE_WRAPPER_BASE + 2092*4)    /* 0x20B0, GMCU0 heartbeat */
#define PWRAP_COMMON39                    (PCIE_WRAPPER_BASE + 2093*4)    /* 0x20B4, GMCU1 heartbeat */
#define PWRAP_COMMON40                    (PCIE_WRAPPER_BASE + 2094*4)    /* 0x20B8, GMCU2 heartbeat */
#define PWRAP_COMMON41                    (PCIE_WRAPPER_BASE + 2095*4)    /* 0x20BC, GMCU3 heartbeat */
#define PWRAP_COMMON42                    (PCIE_WRAPPER_BASE + 2096*4)    /* 0x20C0, VEMCU0 heartbeat */
#define PWRAP_COMMON43                    (PCIE_WRAPPER_BASE + 2097*4)    /* 0x20C4, VEMCU1 heartbeat */
#define PWRAP_COMMON44                    (PCIE_WRAPPER_BASE + 2098*4)    /* 0x20C8, VEMCU2 heartbeat */
#define PWRAP_COMMON45                    (PCIE_WRAPPER_BASE + 2099*4)    /* 0x20CC, VEMCU3 heartbeat */
#define PWRAP_COMMON46                    (PCIE_WRAPPER_BASE + 2100*4)    /* 0x20D0, ODSP0 heartbeat */
#define PWRAP_COMMON47                    (PCIE_WRAPPER_BASE + 2101*4)    /* 0x20D4, ODSP1 heartbeat */
#define PWRAP_COMMON48                    (PCIE_WRAPPER_BASE + 2102*4)    /* 0x20D8, VDSP0 heartbeat */
#define PWRAP_COMMON49                    (PCIE_WRAPPER_BASE + 2103*4)    /* 0x20DC, VDSP1 heartbeat */
#define PWRAP_COMMON50                    (PCIE_WRAPPER_BASE + 2104*4)    /* 0x20E0, gfx mode */
#define PWRAP_COMMON51                    (PCIE_WRAPPER_BASE + 2105*4)    /* 0x20E4, DDR status */
#define PWRAP_COMMON77                    (PCIE_WRAPPER_BASE + 2131*4)    /* 0x214c, ddr mode/card type/bl1_flag/fw_flag */
#define PWRAP_COMMON_HOST_ONLY0           (PCIE_WRAPPER_BASE + 2134*4)    /* 0x2158, master/slave package communication, SMCU write msg to PF4 driver */
#define PWRAP_COMMON_HOST_ONLY1           (PCIE_WRAPPER_BASE + 2135*4)    /* 0x215C, master/slave package communication, SMCU write msg to PF5 driver */
#define PWRAP_COMMON_HOST_ONLY2           (PCIE_WRAPPER_BASE + 2136*4)    /* 0x2160, master/slave package communication, SMCU write msg to PF6 driver */
#define PWRAP_COMMON_HOST_ONLY3           (PCIE_WRAPPER_BASE + 2137*4)    /* 0x2164, master/slave package communication, SMCU write msg to PF7 driver */
#define PWRAP_COMMON_HOST_ONLY4           (PCIE_WRAPPER_BASE + 2138*4)    /* 0x2168, master/slave package communication, PF4 ack */
#define PWRAP_COMMON_HOST_ONLY5           (PCIE_WRAPPER_BASE + 2139*4)    /* 0x216C, master/slave package communication, PF5 ack */
#define PWRAP_COMMON_HOST_ONLY6           (PCIE_WRAPPER_BASE + 2140*4)    /* 0x2170, master/slave package communication, PF6 ack */
#define PWRAP_COMMON_HOST_ONLY7           (PCIE_WRAPPER_BASE + 2141*4)    /* 0x2174, master/slave package communication, PF7 ack */

#define SG_HEART_BEAT_CNT                    (PWRAP_COMMON33)                /* 68 bytes */

/*
 * b[6:3] ddr training status, 0: Passed, non_zero: failed
 * b[9:7] ddr_bar_size, 0:2GB  1:4GB 2:8GB 3:16GB 4:32GB 5:64GB. Check definition of enum DDR_BAR4_5_SZ_ID.
 *
**/
#define PWRAP_COMMON51_DDR_BAR_SZ         PWRAP_COMMON51
#define BIT_WRAP_COMM51_DDR_BAR_SZ        7


/*
 * b[15: 0] tag_tail
 * b[19:16] error
 * b[23:20] main_tag
 * b[25:24] ddr size:  0:32GB  1: 16GB      2:8GB  3:64GB
 * b[27:26] card type: 0:EVB   1:AIC-ANYI   2:AIC_ZHAOGE
 * b[31:28] boot step: b28:bl1 flag;  b29:fw flag
**/
#define BIT_WRAP_COMM77_DDR_MODE          24
#define BIT_WRAP_COMM77_CARD_TYPE         26
#define BIT_WRAP_COMM77_BL1_BOOT_FLAG     28
#define BIT_WRAP_COMM77_FW_BOOT_FLAG      29
#define PWRAP_COMMON77_DDR_CARD           PWRAP_COMMON77
//pcie fatal error and non fatal error int & mask
#define PWRAP_SII_GMR2                    (PCIE_WRAPPER_BASE + 512*4)
#define PWRAP_SII_IER                     (PCIE_WRAPPER_BASE + 550*4)
#define PWRAP_LOCAL_INT0                  (PCIE_WRAPPER_BASE + 638*4)
#define PWRAP_LOCAL_INT1                  (PCIE_WRAPPER_BASE + 639*4)
#define PWRAP_LOCAL_INT2                  (PCIE_WRAPPER_BASE + 640*4)
#define PWRAP_LOCAL_INT3                  (PCIE_WRAPPER_BASE + 641*4)
#define PWRAP_LOCAL_INT4                  (PCIE_WRAPPER_BASE + 642*4)
// PF & VF FLR
#define PWRAP_PF_FLR0                     (PCIE_WRAPPER_BASE + 540*4)     // 0x940870
#define PWRAP_PF_FLR_ACTIVE_INT_MSK       PWRAP_PF_FLR0                   // RW, 8'hff
#define PWRAP_PF_FLR_ACTIVE_INT_STAT      PWRAP_PF_FLR0                   // W1C, 1'h0, PF0~PF7, indicate which PF receive the FLR
#define PWRAP_PF_APP_FLR_DONE             PWRAP_PF_FLR0                   // RWV, 1'h0, PF0~PF7, fw set it to 1 to notify controller which func is ready to do FLR

#define PWRAP_VF_FLR1                     (PCIE_WRAPPER_BASE + 541*4)     // 0x940874
#define PWRAP_VF_FLR_ACTIVE_INT_MSK       PWRAP_VF_FLR1                   // RW, 32'hffffffff

#define PWRAP_VF_FLR2                     (PCIE_WRAPPER_BASE + 542*4)     // 0x940878
#define PWRAP_VF_FLR_ACTIVE_INT_STAT      PWRAP_VF_FLR2                   // W1C, 1'h0, VF0~VF31, indicate which VF receive the FLR

#define PWRAP_VF_FLR3                     (PCIE_WRAPPER_BASE + 543*4)     // 0x94087C
#define PWRAP_VF_APP_FLR_DONE             PWRAP_VF_FLR3                   // RWV, 1'h0, VF0~VF31, fw set it to 1 to notify controller which func is ready to do FLR

#define PWRAP_PF_FLR5                     (PCIE_WRAPPER_BASE + 591*4)     // 0x94093C
#define PWRAP_PF_FLR_DONE_HW_EN           PWRAP_PF_FLR5                   // RW, 8'hff, PF0~PF7, a CSR-mode bit to default enable HW to assert app_flr_pf_done automaticllay for PFs, rather than let FW assert these signals. 
                                                                          // (each pf has one bit), need to reset to 1 when reinitial reset happens. Romcode wirte to 1 always. 
#define PWRAP_VF_FLR6                     (PCIE_WRAPPER_BASE + 592*4)     // 0x940940
#define PWRAP_VF_FLR_DONE_HW_EN           PWRAP_VF_FLR6                   // RWV, 32'hffffffff, VF0~VF31, a CSR-mode bit to default enable HW to assert app_flr_vf_done automaticllay for Vfs, rather than let FW assert these signals. (each vf has one bit)

// PF FLR generate Reinitial Reset
#define PWRAP_PFLR_REINIT_RST_MSK         (PCIE_WRAPPER_BASE + 1486*4)    // 0x941738, 8'hff, RW
#define PWRAP_REINIT_RST_PFLR_TO_SMU_REQ  (PCIE_WRAPPER_BASE + 1486*4)    // 0x941738, 1'h0,  W1C,  hardware (PF FLR) gen reinit rst req to smu, wr 1 to clear 
#define PWRAP_REINIT_RST_STS              (PCIE_WRAPPER_BASE + 1487*4)    // 0x94173C, 32'h0, RWV�� Status

// pcie 1/64 csr, u preseent userbit
#define CFG_RD_MISC_SET_0(u)                (PCIE_WRAPPER_BASE + 700*4 + u * 16)
#define CFG_RD_MISC_SET_1(u)                (PCIE_WRAPPER_BASE + 701*4 + u * 16)
#define CFG_RD_MISC_SET_2(u)                (PCIE_WRAPPER_BASE + 702*4 + u * 16)
#define CFG_RD_MISC_SET_3(u)                (PCIE_WRAPPER_BASE + 703*4 + u * 16)

#define CFG_WR_MISC_SET_0(u)                (PCIE_WRAPPER_BASE + 956*4 + u * 16)
#define CFG_WR_MISC_SET_1(u)                (PCIE_WRAPPER_BASE + 957*4 + u * 16)
#define CFG_WR_MISC_SET_2(u)                (PCIE_WRAPPER_BASE + 958*4 + u * 16)
#define CFG_WR_MISC_SET_3(u)                (PCIE_WRAPPER_BASE + 959*4 + u * 16)

#define REQUEST_ID_VALUE(pf,vf,vf_active)  (pf<<6|vf<<1|vf_active) 

// CII Monitor n: 0~7
#define PWRAP_CII_INT                           (PCIE_WRAPPER_BASE + 669 * 4)                // 0x940A74,  8 x 1`h0, W1C
#define PWRAP_CII0                              (PCIE_WRAPPER_BASE + 670 * 4)
#define PWRAP_CII1                              (PCIE_WRAPPER_BASE + 671 * 4)
#define PWRAP_CII2                              (PCIE_WRAPPER_BASE + 672 * 4)
#define PWRAP_CII3                              (PCIE_WRAPPER_BASE + 673 * 4)
#define PWRAP_CII4                              (PCIE_WRAPPER_BASE + 674 * 4)
#define PWRAP_CII_SET(n)                        (PCIE_WRAPPER_BASE + 675 * 4 + n * 2 * 4)   // from: 0x940A8C
#define PWRAP_CII_MSK(n)                        (PCIE_WRAPPER_BASE + 676 * 4 + n * 2 * 4)   // from: 0x940A90

/* PCIE MONITOR */
#define PWRAP_PCIE_MST_MONITOR_PARA             (PCIE_WRAPPER_BASE + 0 * 4)
#define PWRAP_PCIE_MST_MONITOR_TIME1            (PCIE_WRAPPER_BASE + 1 * 4)
#define PWRAP_PCIE_MST_MONITOR_TIME2            (PCIE_WRAPPER_BASE + 2 * 4)
#define PWRAP_PCIE_MST_MONITOR_TIME3            (PCIE_WRAPPER_BASE + 3 * 4)
#define PWRAP_PCIE_MST_MONITOR_TIME4            (PCIE_WRAPPER_BASE + 4 * 4)
#define PWRAP_PCIE_MST_MONITOR_BANDWIDTH_SET    (PCIE_WRAPPER_BASE + 5 * 4)
#define PWRAP_PCIE_MST_MONITOR_OPERAND_SET      (PCIE_WRAPPER_BASE + 6 * 4)
#define PWRAP_PCIE_MST_MONITOR_LATENCY_WID      (PCIE_WRAPPER_BASE + 7 * 4)
#define PWRAP_PCIE_MST_MONITOR_LATENCY_RID      (PCIE_WRAPPER_BASE + 8 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_WRRANG0   (PCIE_WRAPPER_BASE + 9 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_WRRANG1   (PCIE_WRAPPER_BASE + 10 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_WRRANG2   (PCIE_WRAPPER_BASE + 11 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_WRRANG3   (PCIE_WRAPPER_BASE + 12 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_RDRANG0   (PCIE_WRAPPER_BASE + 13 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_RDRANG1   (PCIE_WRAPPER_BASE + 14 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_RDRANG2   (PCIE_WRAPPER_BASE + 15 * 4)
#define PWRAP_PCIE_MST_MONITOR_SPADDR_RDRANG3   (PCIE_WRAPPER_BASE + 16 * 4)
#define PWRAP_PCIE_MST_MONITOR_RESULT_SELSCT    (PCIE_WRAPPER_BASE + 17 * 4)
#define PWRAP_PCIE_MST_MONITOR_RESULT0          (PCIE_WRAPPER_BASE + 18 * 4)
#define PWRAP_PCIE_MST_MONITOR_RESULT1          (PCIE_WRAPPER_BASE + 19 * 4)
#define PWRAP_PCIE_SLV_MONITOR_PARA             (PCIE_WRAPPER_BASE + 20 * 4)
#define PWRAP_PCIE_SLV_MONITOR_TIME1            (PCIE_WRAPPER_BASE + 21 * 4)
#define PWRAP_PCIE_SLV_MONITOR_TIME2            (PCIE_WRAPPER_BASE + 22 * 4)
#define PWRAP_PCIE_SLV_MONITOR_TIME3            (PCIE_WRAPPER_BASE + 23 * 4)
#define PWRAP_PCIE_SLV_MONITOR_TIME4            (PCIE_WRAPPER_BASE + 24 * 4)
#define PWRAP_PCIE_SLV_MONITOR_BANDWIDTH_SET    (PCIE_WRAPPER_BASE + 25 * 4)
#define PWRAP_PCIE_SLV_MONITOR_OPERAND_SET      (PCIE_WRAPPER_BASE + 26 * 4)
#define PWRAP_PCIE_SLV_MONITOR_LATENCY_WID      (PCIE_WRAPPER_BASE + 27 * 4)
#define PWRAP_PCIE_SLV_MONITOR_LATENCY_RID      (PCIE_WRAPPER_BASE + 28 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_WRRANG0   (PCIE_WRAPPER_BASE + 29 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_WRRANG1   (PCIE_WRAPPER_BASE + 30 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_WRRANG2   (PCIE_WRAPPER_BASE + 31 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_WRRANG3   (PCIE_WRAPPER_BASE + 32 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_RDRANG0   (PCIE_WRAPPER_BASE + 33 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_RDRANG1   (PCIE_WRAPPER_BASE + 34 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_RDRANG2   (PCIE_WRAPPER_BASE + 35 * 4)
#define PWRAP_PCIE_SLV_MONITOR_SPADDR_RDRANG3   (PCIE_WRAPPER_BASE + 36 * 4)
#define PWRAP_PCIE_SLV_MONITOR_RESULT_SELSCT    (PCIE_WRAPPER_BASE + 37 * 4)
#define PWRAP_PCIE_SLV_MONITOR_RESULT0          (PCIE_WRAPPER_BASE + 38 * 4)
#define PWRAP_PCIE_SLV_MONITOR_RESULT1          (PCIE_WRAPPER_BASE + 39 * 4)


#ifdef __cplusplus
}
#endif
#endif
#endif /* SG100_USED */
