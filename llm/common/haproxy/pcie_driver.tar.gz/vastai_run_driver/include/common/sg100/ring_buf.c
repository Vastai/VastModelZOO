#ifdef SG100_USED
#include "ring_buf.h"
#include <xtensa/hal-certified.h>
#include <xtensa/tie/xt_sync.h>

#if USE_FULL_ASSERT
void assert_failed(unsigned char* file, u32 line)
{
    log_err("Wrong parameters value: file %s on line %d", file, line);
    while (1)
        ;
}
#endif

/*================================== extern =================================*/
extern void XT_MEMW(void);

/*================================== macro ==================================*/
#define RING_RD_ELEM(ring_buf)     (uint8_t*)(&ring_buf->buf[ ring_buf->rd * ring_buf->elem_size ])
#define RING_WR_ELEM(ring_buf)     (uint8_t*)(&ring_buf->buf[ ring_buf->wr * ring_buf->elem_size ])
#define RING_NEXT(ring_buf, index) ((index + 1) % ring_buf->elem_count)

//internal use inline function
//ring_buf ---> elem_out
void ring_buf_elem_copy_to(volatile ring_buf_t* ring_buf, void* elem_out, size_t* elem_size)
{
    memcpy(elem_out, RING_RD_ELEM(ring_buf), ring_buf->elem_size);
    if (elem_size) {
        *elem_size = ring_buf->elem_size;
    }
}

//src: elem_in , dst:ring_buf
//ring_buf <-- elem_in
void ring_buf_elem_copy_from(volatile ring_buf_t* ring_buf, void* elem_in)
{
    memcpy(RING_WR_ELEM(ring_buf), elem_in, ring_buf->elem_size);
}

void ring_buf_elem_increase(volatile ring_buf_t* ring_buf)
{
    ring_buf->wr = RING_NEXT(ring_buf, ring_buf->wr);
}

void ring_buf_elem_decrease(volatile ring_buf_t* ring_buf)
{
    ring_buf->rd = RING_NEXT(ring_buf, ring_buf->rd);
}

/***********************************************************************************************************************
*   Description:    init ring buffer by the writer side
*   parameter:      ring_buf              [OUT]            ...
*                   elem_count            [IN]            ...
*                   elem_size           [IN]            ...
*   return:         none
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
void ring_buf_init(volatile ring_buf_t* ring_buf, uint32_t elem_count, uint32_t elem_size)
{
    assert_param(ring_buf);

    ring_buf->wr = 0u;
    ring_buf->rd = 0u;

    ring_buf->elem_size  = elem_size;
    ring_buf->elem_count = elem_count;

    //LOG_DEBUG("ring buf init: addr 0x%x, elem_size %d, elem_count %d.\n", ring_buf, elem_size, elem_count);
}

/***********************************************************************************************************************
*   Description:    deinit ring buffer by the writer side
*   parameter:      ring_buf          [OUT]             ...
*   return:         none
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
void ring_buf_deinit(volatile ring_buf_t* ring_buf)
{
    assert_param(ring_buf);

    ring_buf->wr = 0u;
    ring_buf->rd = 0u;

    ring_buf->elem_size  = 0u;
    ring_buf->elem_count = 0u;
}

/***********************************************************************************************************************
*   Description:    ring buffer read flush by reader side. may be used in ring buf full senario.
*   parameter:      ring_buf          [OUT]             ...
*   return:         none
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
void ring_buf_read_flush(volatile ring_buf_t* ring_buf)
{
    uint32_t elem_num;
    assert_param(ring_buf);
    //to do, has problem
    elem_num = ring_buf_elem_num(ring_buf);

    //LOG_DEBUG("vdsp ring buf read flush: the remaining %d elements are abandoned.", elem_num);

    //ring_buf->wr        = 0u;
    //ring_buf->rd        = 0u;
    ring_buf->rd = ring_buf->wr;
}

/***********************************************************************************************************************
*   Description:    enqueue an element into the ring queue.
*   parameter:      ring_buf        [IN]   pointer to the handler of the ring queue.
*                   elem            [IN]   the element to be enqueued.
*                   elem_size       [IN]   size of the element(should be consistent with the elem_size when init ring buf)
*   return:         errcode
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
ring_buf_err_t ring_buf_enqueue(volatile ring_buf_t* ring_buf, void* elem, size_t elem_size)
{
    assert_param(ring_buf);
    assert_param(elem);

    if (elem_size != ring_buf->elem_size) {
        return ERR_RING_BUF_ELEM_SIZE_NOT_MATCH;
    }

    if (ring_buf_is_full(ring_buf)) {
        return ERR_RING_BUF_FULL;
    }

    ring_buf_elem_copy_from(ring_buf, elem);
    ring_buf_elem_increase(ring_buf);

    XT_MEMW();

    return ERR_NONE;
}

/***********************************************************************************************************************
*   Description:    dequeue an element from the ring queue.
*   parameter:      ring_buf        [IN]   pointer to the handler of the ring queue.
*                   elem            [IN]   buffer to hold the element dequeued
*                   elem_size       [IN]   size of the element dequeued(should be consistent with the elem_size of input data).
*   return:         errcode
*   History:        2021.07.01      rui.zhong       create
***********************************************************************************************************************/
ring_buf_err_t ring_buf_dequeue(volatile ring_buf_t* ring_buf, void* elem, size_t* elem_size)
{
    assert_param(ring_buf);
    assert_param(elem);

    if (ring_buf_is_empty(ring_buf)) {
        return ERR_RING_BUF_EMPTY;
    }

    ring_buf_elem_copy_to(ring_buf, elem, elem_size);
    ring_buf_elem_decrease(ring_buf);

    XT_MEMW(); //to_be_removed, too conservative, need stress  test.

    return ERR_NONE;
}
#endif /* SG100_USED */
