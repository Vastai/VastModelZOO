#ifdef SG100_USED
#ifndef __SMCU_H__
#define __SMCU_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*
 * PCIE_WRAPPER_HOST_RW_BOOT_STATUS
 * bit[31:30]: current die id.
 *            2'h0:die0, 2'h1:die1, 2'h2:die2, 2'h3:die3
 * bit[26:24]: host boot stage.
 *             3'h0: initial state
 *             3'h1: bl1 download finish
 *             3'h2: fw download finish
 *             3'h3: Recv smcu notice that fw boot up successfully
 *             3'h4: Recv smcu notice that current die pcie init finish
 *             3'h5: Recv smcu notice that all mcu and dsp of current die init finish
 *             3'h6: all dies download finish, host ready
 */
/* VASTAI_SG_HOST_BOOT_STAGE_REG */
#define VASTAI_HOST_BOOT_STAGE_INIT                     (0)
#define VASTAI_HOST_BOOT_STAGE_BL1_DONE                 (1)
#define VASTAI_HOST_BOOT_STAGE_FW_DONE                  (2)
#define VASTAI_HOST_BOOT_STAGE_RCV_FW_BOOT_UP_ACK       (3)
#define VASTAI_HOST_BOOT_STAGE_RCV_PCIE_INIT_READY_ACK  (4)
#define VASTAI_HOST_BOOT_STAGE_RCV_ALLCORE_READY_ACK    (5)
#define VASTAI_HOST_BOOT_STAGE_READY                    (6)
#define VASTAI_HOST_BOOT_STAGE_SW_BOOT_SLAVE_BAR        (100)    /* only for drv flag */

union host_boot_stage {
    u32 val;
    struct {
        u32 smcu_rsvd           : 24;
        u32 stage               : 3;
        u32 host_rsvd           : 2;
        u32 force_single_die    : 1;
        u32 die_id              : 2;
    } bit;
};

/* smcu boot stage define */
/*
 * PCIE_WRAPPER_HOST_RD_SMCU_STATUS
 * bit[31:29]: die config, refer to struct vastai_die_cfg table
 * bit[28]: current die ep and front die or host rc link up flag
 * bit[27]: current die rc and next die ep link up flag
 * bit[26:24]: smcu boot stage.
 *             3'h0: initial state
 *             3'h1: wait for downloading bl1 (bootloader1)
 *             3'h2: bl1 verify pass
 *             3'h3: wait for downloading fw (firmware)
 *             3'h4: fw verify pass 
 *             3'h5: fw boot up successfully
 *             3'h6: current die pcie init finish
 *             3'h7: all mcu and dsp of current die init finish
 */
/* VASTAI_SG_SMCU_BOOT_STAGE_REG */
#define VASTAI_SMCU_BOOT_STAGE_INIT             (0)
#define VASTAI_SMCU_BOOT_STAGE_BL1_READY        (1)
#define VASTAI_SMCU_BOOT_STAGE_BL1_DONE         (2)
#define VASTAI_SMCU_BOOT_STAGE_FW_READY         (3)
#define VASTAI_SMCU_BOOT_STAGE_FW_DONE          (4)
#define VASTAI_SMCU_BOOT_STAGE_FW_BOOT_UP       (5)
#define VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY  (6)
#define VASTAI_SMCU_BOOT_STAGE_ALLCORE_READY    (7)

#define VASTAI_SMCU_BOOT_STAGE_IMAGE_MASK       (~(7<<24))
#define VASTAI_SMCU_BOOT_DIE_CFG_MASK           (~(7<<29))

union smcu_boot_stage {
    u32 val;
    struct {
        u32 smcu_rsvd       : 24;
        u32 stage           : 3;
        u32 rc_link_sts     : 1;
        u32 ep_link_sts     : 1;
        u32 die_cfg         : 3;
    } bit;
};

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SMCU_H__ */
#endif /* SG100_USED */
