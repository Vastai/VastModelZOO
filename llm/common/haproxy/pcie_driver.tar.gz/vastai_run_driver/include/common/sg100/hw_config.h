#ifdef SG100_USED
#ifndef __SG100_HW_CONFIG_H__
#define __SG100_HW_CONFIG_H__

#ifndef __MCU__
    #include "config.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#if defined(__MCU__) || defined(__SMCU__) || defined(__GMCU__) 

#ifndef NULL
#define NULL (void *)0
#endif


#define hw_readl(addr)             (*(volatile unsigned int *) (addr))
#define hw_writel(b,addr)          ((*(volatile unsigned int *) (addr)) = (b))


#else

#ifndef _WIN32
#include <linux/stddef.h>
#include <linux/string.h>
#endif
#include "vastai_pci.h"
#include "vastai_fifo.h"
#define hw_cfg_dbg(fmt, ...) VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, fmt, ##__VA_ARGS__)

#endif

#define GLOBAL_HW_CFG_BASE                        0X8E3C00
#define GLOBAL_HW_CFG_SIZE                        0X400         //1KB

#define BOOT_HW_CFG_ADDR  0x8F0000
#define DEVICE_2_HOST_DDR_BY_ATU      0
#define DEVICE_2_HOST_DDR_BY_GART     1

#define OUTBOUND_NOT_SURPPORE_SRIOV      0
#define OUTBOUND_SURPPORE_SRIOV          1
enum card_type {
    EVB_CARD,
    AIC_CARD,
    ZHAOGE_CARD,
    RESERED_TYPE,
};
struct GFX_CLK_CFG{
    unsigned int GCLK;
};

struct Video_CLK_CFG{
    unsigned int ECLK;
    unsigned int DCLK;
    unsigned int VDSPCLK;
    unsigned int VCLK;
};

struct DDR_CLK_CFG{
    unsigned int RUCLK;
    unsigned int LUCLK;
};

struct SOC_CLK_CFG{
    unsigned int CEDARCLK;
    unsigned int LCCLK;
    unsigned int RCCLK;
    unsigned int BCCLK;
};

struct AI_CLK_CFG{
    unsigned char OCLK;
    unsigned char ODSPCLK;
    unsigned char reserved0;
    unsigned char reserved1;
};
struct DP_CLK_CFG{
    unsigned int PIXCLK_DP;
};

struct POWER_RAIL_CFG{
    unsigned int VDD_GFX;
    unsigned int VDD_VID;
    unsigned int VDD_SOC;
};

struct POWER_CLK_CFG{
    struct GFX_CLK_CFG      gfx;
    struct Video_CLK_CFG    video;
    struct DDR_CLK_CFG      ddr;
    struct SOC_CLK_CFG      soc;
    struct AI_CLK_CFG       ai;
    struct DP_CLK_CFG       dp;
    struct POWER_RAIL_CFG   power_rail;
};


struct boot_hw_cfg
{   
    unsigned int power_cfg;
    unsigned int bar4_5_size_cfg;
    //0:atu 1:gart
    unsigned int d2h_by_atu_or_gart;  
    //0:not support,gpu access host ddr size 512GB 
    //1:support,gpu access host ddr size 512GB/PF num
    unsigned int outbound_supprt_sriov;    
    struct POWER_CLK_CFG power_clk[RESERED_TYPE];
};


/**********************s<----ddr layout--------->s******************/
#define GMCU_LOG_BUF_SIZE                         0x100000
#define SMCU_LOG_BUF_BASE                         0x1032000000
#define CMCU_LOG_BUF_BASE                         0x1032100000

#define OMCU0_LOG_BUF_BASE                        0x1032200000
#define OMCU1_LOG_BUF_BASE                        0x1032300000

#define GMCU0_LOG_BUF_BASE                        0x1032400000
#define GMCU1_LOG_BUF_BASE                        0x1032500000
#define GMCU2_LOG_BUF_BASE                        0x1032600000
#define GMCU3_LOG_BUF_BASE                        0x1032700000
       

/**********************e<----ddr layout--------->e******************/
#define SMCU_2_PMCU_BUF_BASE                      0x008E8000    //size 512 byte
#define SMCU_2_GMCU0_BUF_BASE                     0x008E8200    //size 512 byte
#define SMCU_2_GMCU1_BUF_BASE                     0x008E8400    //size 512 byte
#define SMCU_2_GMCU2_BUF_BASE                     0x008E8600    //size 512 byte
#define SMCU_2_GMCU3_BUF_BASE                     0x008E8800    //size 512 byte
#define SMCU_2_VEMCU0_BUF_BASE                    0x008E8A00    //size 512 byte
#define SMCU_2_VEMCU1_BUF_BASE                    0x008E8C00    //size 512 byte
#define SMCU_2_VEMCU2_BUF_BASE                    0x008E8E00    //size 512 byte
#define SMCU_2_VEMCU3_BUF_BASE                    0x008E9000    //size 512 byte
#define SMCU_2_VDSP0_BUF_BASE                     0x008E9200    //size 512 byte
#define SMCU_2_VDSP1_BUF_BASE                     0x008E9400    //size 512 byte
#define SMCU_2_CMCU_BUF_BASE                      0x008E9600    //size 512 byte
#define SMCU_2_OMCU0_BUF_BASE                     0x008E9800    //size 512 byte
#define SMCU_2_ODSP0_BUF_BASE                     0x008E9C00    //size 512 byte
#define SMCU_2_ODSP1_BUF_BASE                     0x008E9E00    //size 512 byte

#define MCUS_2_SMCU_BUF_SIZE                      512 
#define PMCU_2_SMCU_BUF_BASE                      0x008EA000    //size 512 byte
#define GMCU0_2_SMCU_BUF_BASE                     0x008EA200    //size 512 byte
#define GMCU1_2_SMCU_BUF_BASE                     0x008EA400    //size 512 byte
#define GMCU2_2_SMCU_BUF_BASE                     0x008EA600    //size 512 byte
#define GMCU3_2_SMCU_BUF_BASE                     0x008EA800    //size 512 byte
#define VEMCU0_2_SMCU_BUF_BASE                    0x008EAA00    //size 512 byte
#define VEMCU1_2_SMCU_BUF_BASE                    0x008EAC00    //size 512 byte
#define VEMCU2_2_SMCU_BUF_BASE                    0x008EAE00    //size 512 byte
#define VEMCU3_2_SMCU_BUF_BASE                    0x008EB000    //size 512 byte
#define VDSP0_2_SMCU_BUF_BASE                     0x008EB200    //size 512 byte
#define VDSP0_2_CMCU_BUF_BASE                     0x008EB400    //size 1024 byte
#define VDSP1_2_SMCU_BUF_BASE                     0x008EB800    //size 512 byte
#define VDSP1_2_CMCU_BUF_BASE                     0x008EBA00    //size 1024 byte
#define CMCU_2_SMCU_BUF_BASE                      0x008EBE00    //size 512 byte
#define CMCU_2_VDSP0_BUF_BASE                     0x008EC000    //size 1024 byte 
#define CMCU_2_VDSP1_BUF_BASE                     0x008EC400    //size 1024 byte
#define CMCU_2_OMCU0_BUF_BASE                     0x008EC800    //size 512 byte    
#define CMCU_2_OMCU1_BUF_BASE                     0x008ECA00    //size 512 byte
#define CMCU_2_ODSP0_BUF_BASE                     0x008ECC00    //size 512 byte
#define CMCU_2_ODSP1_BUF_BASE                     0x008ECE00    //size 512 byte
#define OMCU0_2_CMCU_BUF_BASE                     0x008ED000    //size 512 byte
#define OMCU1_2_CMCU_BUF_BASE                     0x008ED200    //size 512 byte
#define ODSP0_2_SMCU_BUF_BASE                     0x008ED400    //size 512 byte
#define ODSP0_2_CMCU_BUF_BASE                     0x008ED600    //size 512 byte
#define ODSP1_2_SMCU_BUF_BASE                     0x008EDA00    //size 512 byte
#define OMCU_AND_ODSP_2_CMCU_BUF_BASE             0x008EDC00    //size 512 byte

//only for pipeline mode
#define VDSP0_2_VEMCU0_BUF_BASE                   0x008F0000    //size 2048 byte
#define VDSP0_2_VEMCU1_BUF_BASE                   0x008F0800    //size 2048 byte
#define VDSP0_2_VEMCU2_BUF_BASE                   0x008F1000    //size 2048 byte
#define VDSP0_2_VEMCU3_BUF_BASE                   0x008F1800    //size 2048 byte
#define VDSP1_2_VEMCU0_BUF_BASE                   0x008F2000    //size 2048 byte
#define VDSP1_2_VEMCU1_BUF_BASE                   0x008F2800    //size 2048 byte
#define VDSP1_2_VEMCU2_BUF_BASE                   0x008F3000    //size 2048 byte
#define VDSP1_2_VEMCU3_BUF_BASE                   0x008F3800    //size 2048 byte
#define VEMCU0_2_VDSP0_BUF_BASE                   0x008F4000    //size 2048 byte
#define VEMCU0_2_VDSP1_BUF_BASE                   0x008F4800    //size 2048 byte
#define VEMCU1_2_VDSP0_BUF_BASE                   0x008F5000    //size 2048 byte
#define VEMCU1_2_VDSP1_BUF_BASE                   0x008F5800    //size 2048 byte
#define VEMCU2_2_VDSP0_BUF_BASE                   0x008F6000    //size 2048 byte
#define VEMCU2_2_VDSP1_BUF_BASE                   0x008F6800    //size 2048 byte
#define VEMCU3_2_VDSP0_BUF_BASE                   0x008F7000    //size 2048 byte
#define VEMCU3_2_VDSP1_BUF_BASE                   0x008F7800    //size 2048 byte
#define VF_MAGIC_NUM                              0x55AA
#define MSGQ_CTRLS_SIZE                           20
#define CMD_BUF_NAME_LONG                         16
/* pf~vf cfg */
#define ONLY_1_PF                                 0
#define ONLY_2_PF                                 1
#define ONLY_4_PF                                 2
#define PF_4_VF_28                                3

/*vdmcu en or disable*/
#define DECODER_ENABLE                            1
#define DECODER_DISABLE                           0

#define GFX_TO_HOST_BY_ATU                        0
#define GFX_TO_HOST_BY_GART                       1

/* trigger mode */
#define  M2O_INT_INFO_MCU                        0
#define  MSGQ_INT_INFO_MCU                       1
#define  MSIX_INT_INFO_HOST                      2

/*PKG ID*/
#define  HW_MASTER_PKGID                         0
#define  HW_SLAVE_PKGID                          1

/*config bar 4_5 size*/
#define  HWCFG_BAR4_5_NORMAL                     0
#define  HWCFG_BAR4_5_2GB                        2
#define  HWCFG_BAR4_5_4GB                        4
#define  HWCFG_BAR4_5_8GB                        8
#define  HWCFG_BAR4_5_16GB                       16
#define  HWCFG_BAR4_5_32GB                       32
#define  HWCFG_BAR4_5_64GB                       64
//ONLY_1_PF 
#define ONLY_1_PF_MSIX_SMCU_AND_CMCU_VECTOR      0
#define ONLY_1_PF_MSIX_GFX_VECTOR                1
#define ONLY_1_PF_MSIX_GMCU_1_VECTOR             2
#define ONLY_1_PF_MSIX_GMCU_3_VECTOR             3
#define ONLY_1_PF_MSIX_VDMCU_0_VECTOR            4
#define ONLY_1_PF_MSIX_VDMCU_1_VECTOR            5
#define ONLY_1_PF_MSIX_VEMCU_0_VECTOR            6
#define ONLY_1_PF_MSIX_VEMCU_1_VECTOR            7
#define ONLY_1_PF_MSIX_VEMCU_2_VECTOR            8
#define ONLY_1_PF_MSIX_VEMCU_3_VECTOR            9
#define ONLY_1_PF_MSIX_VDSP_0_VECTOR             10
#define ONLY_1_PF_MSIX_VDSP_1_VECTOR             11
#define ONLY_1_PF_MSIX_ODSP_0_VECTOR             12
#define ONLY_1_PF_MSIX_ODSP_1_VECTOR             13
#define ONLY_1_PF_MSIX_DSU_VECTOR                14
#define ONLY_1_PF_MSIX_SMMU_ERR_VECTOR           15

//ONLY_2_PF 
#define ONLY_2_PF_MSIX_SMCU_AND_CMCU_VECTOR      0
#define ONLY_2_PF_MSIX_GFX_VECTOR                1
#define ONLY_2_PF_MSIX_GMCU_VECTOR               2
#define ONLY_2_PF_MSIX_VDMCU_VECTOR              3
#define ONLY_2_PF_MSIX_VEMCU_0_VECTOR            4
#define ONLY_2_PF_MSIX_VEMCU_1_VECTOR            5
#define ONLY_2_PF_MSIX_VDSP_0_VECTOR             6
#define ONLY_2_PF_MSIX_VDSP_1_VECTOR             7
#define ONLY_2_PF_MSIX_DSU_VECTOR                8
#define ONLY_2_PF_MSIX_SMMU_ERR_VECTOR           15

//ONLY_4_PF or PF4_VF_28
#define COMMON_MSIX_SMCU_AND_CMCU_VECTOR         0
#define COMMON_MSIX_GFX_VECTOR                   1
#define COMMON_MSIX_GMCU_VECTOR                  2
#define COMMON_MSIX_VDMCU_VECTOR                 3
#define COMMON_MSIX_VEMCU_VECTOR                 4
#define COMMON_MSIX_VDSP_VECTOR                  5
#define COMMON_MSIX_SMMU_ERR_VECTOR              15


#define  NOT_VALID_INFO                      0xFFFFFFFF

/*only 1 pf hw cfg name */
#define  ONLY_1_PF_AI_PIPE_LINE_INFO_NAME              "ai_pipe_buf___"
#define  ONLY_1_PF_GMCU1_HIGH_PRIORITY_SDMA_ELEM_NAME  "gmcu1_hsdma_el"
#define  ONLY_1_PF_GMCU1_LOW_PRIORITY_SDMA_ELEM_NAME   "gmcu1_lsdma_el"
#define  ONLY_1_PF_GMCU3_HIGH_PRIORITY_SDMA_ELEM_NAME  "gmcu3_hsdma_el"
#define  ONLY_1_PF_GMCU3_LOW_PRIORITY_SDMA_ELEM_NAME   "gmcu3_lsdma_el"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_SMCU_RD_NAME        "smcu_cmd_buf__"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_CMCU_RD_NAME        "cmcu_cmd_buf__"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU0_RD_NAME      "1pf_vemcu0_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU1_RD_NAME      "1pf_vemcu1_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU2_RD_NAME      "1pf_vemcu2_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU3_RD_NAME      "1pf_vemcu3_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VDSP0_RD_NAME       "1pf_vdsp0_cmd_"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VDSP1_RD_NAME       "1pf_vdsp1_cmd_"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_ODSP0_RD_NAME       "1pf_odsp0_cmd_"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_ODSP1_RD_NAME       "1pf_odsp1_cmd_"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU0_RD_NAME      "1pf_vdmcu0_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU1_RD_NAME      "1pf_vdmcu1_cmd"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_GMCU1_RD_NAME       "1pf_gmcu1_cmd_"
#define  ONLY_1_PF_HOST_WR_M2O_CMD_GMCU3_RD_NAME       "1pf_gmcu3_cmd_"
#define  ONLY_1_PF_GMCU1_HIGH_PRIORITY_MSGQ_INFO_NAME  "1pf_gmcu1_hmsg"
#define  ONLY_1_PF_GMCU1_LOW_PRIORITY_MSGQ_INFO_NAME   "1pf_gmcu1_lmsg"
#define  ONLY_1_PF_GMCU3_HIGH_PRIORITY_MSGQ_INFO_NAME  "1pf_gmcu3_hmsg"
#define  ONLY_1_PF_GMCU3_LOW_PRIORITY_MSGQ_INFO_NAME   "1pf_gmcu3_lmsg"
#define  ONLY_1_PF_SMCU_WR_MSIX_INFO_HOST_RD_NAME      "smcu_msix_buf_"
#define  ONLY_1_PF_CMCU_WR_MSIX_INFO_HOST_RD_NAME      "cmcu_msix_buf_"
#define  ONLY_1_PF_VEMCU0_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vemcu0_msi"
#define  ONLY_1_PF_VEMCU1_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vemcu1_msi"
#define  ONLY_1_PF_VEMCU2_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vemcu2_msi"
#define  ONLY_1_PF_VEMCU3_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vemcu3_msi"
#define  ONLY_1_PF_VDSP0_WR_MSIX_INFO_HOST_RD_NAME     "1pf_vdsp0_msi_"
#define  ONLY_1_PF_VDSP1_WR_MSIX_INFO_HOST_RD_NAME     "1pf_vdsp1_msi_"
#define  ONLY_1_PF_ODSP0_WR_MSIX_INFO_HOST_RD_NAME     "1pf_odsp0_msi_"
#define  ONLY_1_PF_ODSP1_WR_MSIX_INFO_HOST_RD_NAME     "1pf_odsp1_msi_"
#define  ONLY_1_PF_VDMCU0_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vdmcu0_msi"
#define  ONLY_1_PF_VDMCU1_WR_MSIX_INFO_HOST_RD_NAME    "1pf_vdmcu1_msi"
#define  ONLY_1_PF_GMCU1_WR_MSIX_INFO_HOST_RD_NAME     "1pf_gmcu1_msi_"
#define  ONLY_1_PF_GMCU3_WR_MSIX_INFO_HOST_RD_NAME     "1pf_gmcu3_msi_"
#define  ONLY_1_PF_TOOLS_NAME                          "tools_buf_____"
#define  ONLY_1_PF_DISPLAY_H2D_NAME                    "display_h2d___"
#define  ONLY_1_PF_DISPLAY_D2H_NAME                    "display_d2h___"
#define  ONLY_1_PF_RESERVED_CSRAM_NAME                 "reserved_csram"


/*only 2 pf hw cfg name */
#define  ONLY_2_PF_AI_PIPE_LINE_INFO_NAME              "ai_pipe_buf___"
#define  ONLY_2_PF_HIGH_PRIORITY_SDMA_ELEM_NAME        "high_sdma_elem"
#define  ONLY_2_PF_LOW_PRIORITY_SDMA_ELEM_NAME         "low_sdma_elem_"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_SMCU_RD_NAME        "smcu_cmd_buf__"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_CMCU_RD_NAME        "cmcu_cmd_buf__"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VEMCU_RD_NAME   "2pf_1st_vemcu_"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VEMCU_RD_NAME   "2pf_2nd_vemcu_"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VDSP_RD_NAME    "2pf_1st_vdsp__"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VDSP_RD_NAME    "2pf_2nd_vdsp__"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_VDMCU_RD_NAME       "2pf_vdmcu_cmd_"
#define  ONLY_2_PF_HOST_WR_M2O_CMD_GMCU_RD_NAME        "gmcu_cmd_buf__"
#define  ONLY_2_PF_GMCU_HIGH_PRIORITY_MSGQ_INFO_NAME   "high_sdma_msgq"
#define  ONLY_2_PF_GMCU_LOW_PRIORITY_MSGQ_INFO_NAME    "low_sdma_msgq_"
#define  ONLY_2_PF_SMCU_WR_MSIX_INFO_HOST_RD_NAME      "smcu_msix_buf_"
#define  ONLY_2_PF_CMCU_WR_MSIX_INFO_HOST_RD_NAME      "cmcu_msix_buf_"
#define  ONLY_2_PF_1ST_VEMCU_WR_MSIX_INFO_HOST_RD_NAME "2pf_1_vem_msix"
#define  ONLY_2_PF_2ND_VEMCU_WR_MSIX_INFO_HOST_RD_NAME "2pf_2_vem_msix"
#define  ONLY_2_PF_1ST_VDSP_WR_MSIX_INFO_HOST_RD_NAME  "2pf_1_dsp_msix"    
#define  ONLY_2_PF_2ND_VDSP_WR_MSIX_INFO_HOST_RD_NAME  "2pf_2_dsp_msix" 
#define  ONLY_2_PF_VDMCU_WR_MSIX_INFO_HOST_RD_NAME     "2pf_vdmcu_msix" 
#define  ONLY_2_PF_GMCU_WR_MSIX_INFO_HOST_RD_NAME      "gmcu_msix_buf_" 
#define  ONLY_2_PF_TOOLS_NAME                          "tools_buf_____"
#define  ONLY_2_PF_DISPLAY_D2H_NAME                    "display_d2h___"
#define  ONLY_2_PF_DISPLAY_H2D_NAME                    "display_h2d___"
#define  ONLY_2_PF_RESERVED_CSRAM_NAME                 "reserved_csram" 

/* only_4_pf/pf_4_vf_28/ common hw cfg name  */
#define  COMMON_AI_PIPE_LINE_INFO_NAME                  "ai_pipe_buf___"
#define  COMMON_PCIE_DMA_WRITE_NAME                     "dma_write_____"
#define  COMMON_PCIE_DMA_READ_NAME                      "dma_read______"
#define  COMMON_HIGH_PRIORITY_SDMA_ELEM_NAME            "high_sdma_elem"
#define  COMMON_LOW_PRIORITY_SDMA_ELEM_NAME             "low_sdma_elem_"
#define  COMMON_HIGH_PRIORITY_MSGQ_NAME                 "high_sdma_msgq"
#define  COMMON_LOW_PRIORITY_MSGQ_NAME                  "low_sdma_msgq_"
#define  COMMON_HOST_WR_M2O_CMD_SMCU_RD_NAME            "smcu_cmd_buf__"
#define  COMMON_HOST_WR_M2O_CMD_CMCU_RD_NAME            "cmcu_cmd_buf__"
#define  COMMON_HOST_WR_M2O_CMD_VEMCU_RD_NAME           "vemcu_cmd_buf_"
#define  COMMON_HOST_WR_M2O_CMD_VDSP_RD_NAME            "vdsp_cmd_buf__"
#define  COMMON_HOST_WR_M2O_CMD_VDMCU_RD_NAME           "vdmcu_cmd_buf_"
#define  COMMON_HOST_WR_M2O_CMD_GMCU_RD_NAME            "gmcu_cmd_buf__"
#define  COMMON_SMCU_WR_MSIX_INFO_HOST_RD_NAME          "smcu_msix_buf_"
#define  COMMON_CMCU_WR_MSIX_INFO_HOST_RD_NAME          "cmcu_msix_buf_"
#define  COMMON_VEMCU_WR_MSIX_INFO_HOST_RD_NAME         "vemcu_msix_buf"
#define  COMMON_VDSP_WR_MSIX_INFO_HOST_RD_NAME          "vdsp_msix_buf_"
#define  COMMON_VDMCU_WR_MSIX_INFO_HOST_RD_NAME         "vdmcu_msix_buf"
#define  COMMON_GMCU_WR_MSIX_INFO_HOST_RD_NAME          "gmcu_msix_buf_"
#define  COMMON_TOOLS_NAME                              "tools_buf_____"
#define  COMMON_RESERVED_CSRAM_NAME                     "reserved_csram"



/* From efuse
0: 4x(1+0); 1: 3x(1+0);     2: 2x(1+0),     3: 1x(1+0),         --  Havest case: 1PF, NO 6.
4: 2x(1+1), 5: 1x(1+3),     6:1x(1+2)(RSV). 7:1x(1+1)(RSV).
This filed combine with pkg-index can decide the PF number for current pkg.
(slave_pkg have same config with master_pkg but half PF number).
this field should be copied into pcie-revision-id csr.
*/
enum GFX_MODE_TYPE{
    GFX_MODE_4X_1_PLUS_0         = 0, 
    GFX_MODE_3X_1_PLUS_0         = 1,
    GFX_MODE_2X_1_PLUS_0         = 2,
    GFX_MODE_1X_1_PLUS_0         = 3,
    GFX_MODE_2X_1_PLUS_1         = 4,
    GFX_MODE_1X_1_PLUS_3         = 5,
    GFX_MODE_1X_1_PLUS_2_RSV     = 6,
    GFX_MODE_1X_1_PLUS_1_RSV     = 7,
    GFX_MODE_MAX,
};

//hwcfg ptr
#define  CFG_INFO_BASE(p,v)          (0x00800000 + (p)*0x38000 + (v) * 0x7000)

#pragma pack(1)
enum VASTAI_MCU_NUM {
    GMCU0,
    GMCU1,
    GMCU2,
    GMCU3,
    CMCU,
    SMCU,
    LMCU0,
    LMCU1,
    ODSP0,
    ODSP1,
    VDSP0,
    VDSP1,
    VEMCU0,
    VEMCU1,
    VEMCU2,
    VEMCU3,
};

struct sg100_vf_ddr_layout {
    unsigned long long gmcu0_log_buf_base;
    unsigned long long gmcu1_log_buf_base;
    unsigned long long gmcu2_log_buf_base;
    unsigned long long gmcu3_log_buf_base;
    unsigned int gmcu_log_buf_size;
};

struct csram_layout {
    unsigned int cfg_info_base; 
    unsigned int cfg_info_size;

    unsigned int ai_pipe_line_info_base;
    unsigned int ai_pipe_line_info_size;

    unsigned int sdma_descriptor_base;
    unsigned int sdma_descriptor_size;

    unsigned int wr_msgq_base;
    unsigned int wr_msgq_size;

    unsigned int rd_msgq_base;
    unsigned int rd_msgq_size;

    unsigned int m2o_gmcu_cmd_buf_base;
    unsigned int m2o_gmcu_cmd_buf_size;

    unsigned int m2o_vdsp_cmd_buf_base;
    unsigned int m2o_vdsp_cmd_buf_size;

    unsigned int m2o_vemcu_cmd_buf_base;
    unsigned int m2o_vemcu_cmd_buf_size;

    unsigned int m2o_cmcu_cmd_buf_base;
    unsigned int m2o_cmcu_cmd_buf_size;

    unsigned int m2o_smcu_cmd_buf_base;
    unsigned int m2o_smcu_cmd_buf_size;

    unsigned int msix_gmcu_cmd_buf_base;
    unsigned int msix_gmcu_cmd_buf_size;

    unsigned int msix_vdsp_cmd_buf_base;
    unsigned int msix_vdsp_cmd_buf_size;

    unsigned int msix_vemcu_cmd_buf_base;
    unsigned int msix_vemcu_cmd_buf_size;


    unsigned int msix_cmcu_cmd_buf_base;
    unsigned int msix_cmcu_cmd_buf_size;

    unsigned int msix_smcu_cmd_buf_base;
    unsigned int msix_smcu_cmd_buf_size;

    unsigned int tools_buf_base;
    unsigned int tools_buf_size;

    unsigned int reserved_buf_base;
    unsigned int reserved_buf_size;

};

struct only_1_pf_csram_layout {
    unsigned int cfg_info_base; 
    unsigned int cfg_info_size;

    unsigned int ai_pipe_line_info_base;
    unsigned int ai_pipe_line_info_size;

    unsigned int sdma_descriptor_base;
    unsigned int sdma_descriptor_size;

    unsigned int m2o_smcu_cmd_buf_base;
    unsigned int m2o_smcu_cmd_buf_size;

    unsigned int m2o_cmcu_cmd_buf_base;
    unsigned int m2o_cmcu_cmd_buf_size;

    unsigned int m2o_vemcu0_cmd_buf_base;
    unsigned int m2o_vemcu0_cmd_buf_size;

    unsigned int m2o_vemcu1_cmd_buf_base;
    unsigned int m2o_vemcu1_cmd_buf_size;

    unsigned int m2o_vemcu2_cmd_buf_base;
    unsigned int m2o_vemcu2_cmd_buf_size;

    unsigned int m2o_vemcu3_cmd_buf_base;
    unsigned int m2o_vemcu3_cmd_buf_size;

    unsigned int m2o_vdsp0_cmd_buf_base;
    unsigned int m2o_vdsp0_cmd_buf_size;

    unsigned int m2o_vdsp1_cmd_buf_base;
    unsigned int m2o_vdsp1_cmd_buf_size;

    unsigned int m2o_odsp0_cmd_buf_base;
    unsigned int m2o_odsp0_cmd_buf_size;

    unsigned int m2o_odsp1_cmd_buf_base;
    unsigned int m2o_odsp1_cmd_buf_size;

    unsigned int m2o_vdmcu0_cmd_buf_base;
    unsigned int m2o_vdmcu0_cmd_buf_size;

    unsigned int m2o_vdmcu1_cmd_buf_base;
    unsigned int m2o_vdmcu1_cmd_buf_size;

    unsigned int m2o_gmcu1_cmd_buf_base;
    unsigned int m2o_gmcu1_cmd_buf_size;

    unsigned int m2o_gmcu3_cmd_buf_base;
    unsigned int m2o_gmcu3_cmd_buf_size;

    unsigned int gmcu1_wr_msgq_base;
    unsigned int gmcu1_wr_msgq_size;

    unsigned int gmcu1_rd_msgq_base;
    unsigned int gmcu1_rd_msgq_size;

    unsigned int gmcu3_wr_msgq_base;
    unsigned int gmcu3_wr_msgq_size;

    unsigned int gmcu3_rd_msgq_base;
    unsigned int gmcu3_rd_msgq_size;

    unsigned int msix_smcu_cmd_buf_base;
    unsigned int msix_smcu_cmd_buf_size;

    unsigned int msix_cmcu_cmd_buf_base;
    unsigned int msix_cmcu_cmd_buf_size;

    unsigned int msix_vemcu0_cmd_buf_base;
    unsigned int msix_vemcu0_cmd_buf_size;

    unsigned int msix_vemcu1_cmd_buf_base;
    unsigned int msix_vemcu1_cmd_buf_size;

    unsigned int msix_vemcu2_cmd_buf_base;
    unsigned int msix_vemcu2_cmd_buf_size;

    unsigned int msix_vemcu3_cmd_buf_base;
    unsigned int msix_vemcu3_cmd_buf_size;

    unsigned int msix_vdsp0_cmd_buf_base;
    unsigned int msix_vdsp0_cmd_buf_size;

    unsigned int msix_vdsp1_cmd_buf_base;
    unsigned int msix_vdsp1_cmd_buf_size;

    unsigned int msix_odsp0_cmd_buf_base;
    unsigned int msix_odsp0_cmd_buf_size;

    unsigned int msix_odsp1_cmd_buf_base;
    unsigned int msix_odsp1_cmd_buf_size;

    unsigned int msix_vdmcu0_cmd_buf_base;
    unsigned int msix_vdmcu0_cmd_buf_size;

    unsigned int msix_vdmcu1_cmd_buf_base;
    unsigned int msix_vdmcu1_cmd_buf_size;

    unsigned int msix_gmcu1_cmd_buf_base;
    unsigned int msix_gmcu1_cmd_buf_size;

    unsigned int msix_gmcu3_cmd_buf_base;
    unsigned int msix_gmcu3_cmd_buf_size;

    unsigned int tools_buf_base;
    unsigned int tools_buf_size;

    unsigned int display_h2d_buf_base;
    unsigned int display_h2d_buf_size;

    unsigned int display_d2h_buf_base;
    unsigned int display_d2h_buf_size;

    unsigned int reserved_buf_base;
    unsigned int reserved_buf_size;

};




enum only_1_pf_ring_buf_index{
    ONLY_1_PF_AI_PIPE_LINE_INFO,
    ONLY_1_PF_GMCU1_HIGH_SDMA_DESCRIPTER,
    ONLY_1_PF_GMCU1_LOW_SDMA_DESCRIPTER,
    ONLY_1_PF_GMCU3_HIGH_SDMA_DESCRIPTER,
    ONLY_1_PF_GMCU3_LOW_SDMA_DESCRIPTER,
    ONLY_1_PF_HOST_WR_M2O_CMD_SMCU_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_CMCU_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU0_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU1_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU2_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU3_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VDSP0_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VDSP1_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_ODSP0_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_ODSP1_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU0_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU1_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_GMCU1_RD,
    ONLY_1_PF_HOST_WR_M2O_CMD_GMCU3_RD,
    ONLY_1_PF_GMCU1_HIGH_PRIORITY_MSGQ_INFO,
    ONLY_1_PF_GMCU1_LOW_PRIORITY_MSGQ_INFO,
    ONLY_1_PF_GMCU3_HIGH_PRIORITY_MSGQ_INFO,
    ONLY_1_PF_GMCU3_LOW_PRIORITY_MSGQ_INFO,
    ONLY_1_PF_SMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_CMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VEMCU0_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VEMCU1_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VEMCU2_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VEMCU3_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VDSP0_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VDSP1_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_ODSP0_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_ODSP1_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VDMCU0_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_VDMCU1_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_GMCU1_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_GMCU3_WR_MSIX_INFO_HOST_RD,
    ONLY_1_PF_TOOLS,
    ONLY_1_PF_DISPLAY_H2D,
    ONLY_1_PF_DISPLAY_D2H,
    ONLY_1_PF_RESERVED,
    ONLY_1_PF_HW_CFG_ENTRY_MAX,
};





enum only_2_pf_ring_buf_index{
    ONLY_2_PF_AI_PIPE_LINE_INFO,
    ONLY_2_PF_GMCU_HIGH_SDMA_DESCRIPTER,
    ONLY_2_PF_GMCU_LOW_SDMA_DESCRIPTER,
    ONLY_2_PF_HOST_WR_M2O_CMD_SMCU_RD,
    ONLY_2_PF_HOST_WR_M2O_CMD_CMCU_RD,
    ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VEMCU_RD,
    ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VEMCU_RD,
    ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VDSP_RD,  //vdsp
    ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VDSP_RD,  //odsp
    ONLY_2_PF_HOST_WR_M2O_CMD_VDMCU_RD,
    ONLY_2_PF_HOST_WR_M2O_CMD_GMCU_RD,
    ONLY_2_PF_GMCU_HIGH_PRIORITY_MSGQ_INFO,
    ONLY_2_PF_GMCU_LOW_PRIORITY_MSGQ_INFO,
    ONLY_2_PF_SMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_CMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_1ST_VEMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_2ND_VEMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_1ST_VDSP_WR_MSIX_INFO_HOST_RD,  //vdsp
    ONLY_2_PF_2ND_VDSP_WR_MSIX_INFO_HOST_RD,  //odsp
    ONLY_2_PF_VDMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_GMCU_WR_MSIX_INFO_HOST_RD,
    ONLY_2_PF_TOOLS,
    ONLY_2_PF_DISPLAY_H2D,
    ONLY_2_PF_DISPLAY_D2H,
    ONLY_2_PF_RESERVED,
    ONLY_2_PF_HW_CFG_ENTRY_MAX,
};

struct only_2_pf_csram_layout {
    unsigned int cfg_info_base; 
    unsigned int cfg_info_size;

    unsigned int ai_pipe_line_info_base;
    unsigned int ai_pipe_line_info_size;

    unsigned int sdma_descriptor_base;
    unsigned int sdma_descriptor_size;

    unsigned int m2o_smcu_cmd_buf_base;
    unsigned int m2o_smcu_cmd_buf_size;

    unsigned int m2o_cmcu_cmd_buf_base;
    unsigned int m2o_cmcu_cmd_buf_size;

    unsigned int m2o_vemcu0_cmd_buf_base;
    unsigned int m2o_vemcu0_cmd_buf_size;

    unsigned int m2o_vemcu1_cmd_buf_base;
    unsigned int m2o_vemcu1_cmd_buf_size;


    unsigned int m2o_vdsp0_cmd_buf_base;
    unsigned int m2o_vdsp0_cmd_buf_size;

    unsigned int m2o_vdsp1_cmd_buf_base;
    unsigned int m2o_vdsp1_cmd_buf_size;


    unsigned int m2o_vdmcu_cmd_buf_base;
    unsigned int m2o_vdmcu_cmd_buf_size;

    unsigned int m2o_gmcu_cmd_buf_base;
    unsigned int m2o_gmcu_cmd_buf_size;


    unsigned int gmcu_wr_msgq_base;
    unsigned int gmcu_wr_msgq_size;

    unsigned int gmcu_rd_msgq_base;
    unsigned int gmcu_rd_msgq_size;

    unsigned int msix_smcu_cmd_buf_base;
    unsigned int msix_smcu_cmd_buf_size;

    unsigned int msix_cmcu_cmd_buf_base;
    unsigned int msix_cmcu_cmd_buf_size;

    unsigned int msix_vemcu0_cmd_buf_base;
    unsigned int msix_vemcu0_cmd_buf_size;

    unsigned int msix_vemcu1_cmd_buf_base;
    unsigned int msix_vemcu1_cmd_buf_size;

    unsigned int msix_vdsp0_cmd_buf_base;
    unsigned int msix_vdsp0_cmd_buf_size;

    unsigned int msix_vdsp1_cmd_buf_base;
    unsigned int msix_vdsp1_cmd_buf_size;

    unsigned int msix_vdmcu_cmd_buf_base;
    unsigned int msix_vdmcu_cmd_buf_size;

    unsigned int msix_gmcu_cmd_buf_base;
    unsigned int msix_gmcu_cmd_buf_size;

    unsigned int tools_buf_base;
    unsigned int tools_buf_size;

    unsigned int display_h2d_buf_base;
    unsigned int display_h2d_buf_size;

    unsigned int display_d2h_buf_base;
    unsigned int display_d2h_buf_size;

    unsigned int reserved_buf_base;
    unsigned int reserved_buf_size;

};

/* per hw_msgq_ctrl_reg element size is 20byte */
enum msgq_index{
    AI_PIPE_LINE_INFO,
    PCIE_DMA_WRITE,
    PCIE_DMA_READ,
    HIGH_PRIORITY_SDMA_ELEM,
    LOW_PRIORITY_SDMA_ELEM,
    HIGH_PRIORITY_MSGQ,
    LOW_PRIORITY_MSGQ,
    HOST_WR_M2O_CMD_GMCU_RD,
    HOST_WR_M2O_CMD_VDMCU_RD,
    HOST_WR_M2O_CMD_VDSP_RD,
    HOST_WR_M2O_CMD_VEMCU_RD,
    HOST_WR_M2O_CMD_CMCU_RD,
    HOST_WR_M2O_CMD_SMCU_RD,    
    GMCU_WR_MSIX_INFO_HOST_RD,
    VDMCU_WR_MSIX_INFO_HOST_RD,
    VDSP_WR_MSIX_INFO_HOST_RD,
    VEMCU_WR_MSIX_INFO_HOST_RD,
    CMCU_WR_MSIX_INFO_HOST_RD,
    SMCU_WR_MSIX_INFO_HOST_RD,
    TOOLS,
    COMMON_RESERVED,
    HW_CFG_ENTRY_MAX,
};

enum msgq_ctrls{
    GMCU_WR_MSIX_INFO_HOST_RD_CTRL0,
    HIGH_PRIORITY_MSGQ_CTRL0,
    LOW_PRIORITY_MSGQ_CTRL0,
    GMCU_WR_MSIX_INFO_HOST_RD_CTRL1,
    HIGH_PRIORITY_MSGQ_CTRL1,
    LOW_PRIORITY_MSGQ_CTRL1,
    MSGQ_CTRL_MAX,
};



#if defined(__SMCU__)     
/*SMCU  is 8 fun num*/
enum FUN_NUM{
    PF0,
    PF0_VF0,
    PF0_VF1,
    PF0_VF2,
    PF0_VF3,
    PF0_VF4,
    PF0_VF5,
    PF0_VF6,
    PF1,
    PF1_VF0,
    PF1_VF1,
    PF1_VF2,
    PF1_VF3,
    PF1_VF4,
    PF1_VF5,
    PF1_VF6,
    PF2,
    PF2_VF0,
    PF2_VF1,
    PF2_VF2,
    PF2_VF3,
    PF2_VF4,
    PF2_VF5,
    PF2_VF6,
    PF3,
    PF3_VF0,
    PF3_VF1,
    PF3_VF2,
    PF3_VF3,
    PF3_VF4,
    PF3_VF5,
    PF3_VF6,
    VF_MAX,
};
#endif

#if defined(__GMCU__)     
/*every GMCU is 8 fun num*/
enum FUN_NUM{
    PF0,
    PF0_VF0,
    PF0_VF1,
    PF0_VF2,
    PF0_VF3,
    PF0_VF4,
    PF0_VF5,
    PF0_VF6,
    VF_MAX,
};
#endif

struct msgq_hw_cfg{
    unsigned int vf_wr_ch_msgq_ctrl_reg_base;
    unsigned int vf_rd_ch_msgq_ctrl_reg_base;
    unsigned int vf_msgql_to_msgqh_interval;
    unsigned int vf_msgq_ctrl_0_reg_base;
    unsigned int vf_msgq_ctrl_1_reg_base;
    unsigned int vf_msgq_ctrl_2_reg_base;
    unsigned int vf_msgq_ctrl_3_reg_base;
    unsigned int vf_msgq_ctrl_4_reg_base;
    unsigned int vf_msgq_ctrl_5_reg_base;
    unsigned int vf_msgq_ctrl_6_reg_base;
    unsigned int vf_msgq_ctrl_7_reg_base;
};

struct ring_buf_entry {
    char     name[CMD_BUF_NAME_LONG];
    unsigned int      ring_buf_base;
    unsigned int      ring_buf_size;
    unsigned int      msgq_ctrl_reg_base;
    unsigned int      m2o_reg_base;
};


/*
 *csram_base:per vf or per pf have independent csram,the csram_base is base address of csram
 *csram_size:per vf or per pf have independent csram,the csram_size is size of csram
 */
struct hw_cfg_header {
    unsigned int    magic_num;
    unsigned int    total_cfg_entry;
    unsigned int    csram_base;  
    unsigned int    csram_size;
    unsigned int    smu_csr_base;
    unsigned int    smu_csr_size;
    unsigned int    gfx_csr_base;
    unsigned int    gfx_csr_size;
    unsigned int    lo32_ddr_base;
    unsigned int    hi32_ddr_base;      
    unsigned int    mmio_ddr_size;      //host access ddr size by mmio 
    unsigned int    lo32_ddr_size;      //mcu/sdma access ddr size  (low32 bit)
    unsigned int    hi32_ddr_size;      //mcu/sdma access ddr size  (high32 bit)
    unsigned int    dp_csr_base;
    unsigned int    dp_csr_size;
    unsigned int    dp_csr_mmio_off;
    unsigned int    dsu_csr_base;
    unsigned int    dsu_csr_size;
    unsigned int    dsu_csr_mmio_off;
};

struct system_cfg {
	unsigned char      devfn;
	unsigned char      pfn;
	unsigned char      vfn;
	unsigned char      vf_active;
	unsigned char      stream_id;
	unsigned char      gfx_mpu_en;
	//0: display disable 1:display enable
	unsigned char      dp_en;
	unsigned char      gfx_mode;
	//0:master pkg, 1: slave pkg
	unsigned char      pkg_id;
	//0:ATU 1:GART
	unsigned char      atu_or_gart;
	unsigned char      fn_mode;
	unsigned char      is_super_pf;
	unsigned char      is_admin_pf;
	//bar4_5_cfg_size 0:normal cfg,vf-256MB PF-2GB
	//1:1GB 2:2GB 4:4GB 8:8GB 16:16GB 32:32GB 64:64GB
	unsigned char      bar4_5_cfg_size;
	//0:EVB  1:AIC-ANYI 2:AIC_ZHAOGE
	unsigned char      card_type;
	//16:16GB 32:32GB 64:64GB
	unsigned char      sum_ddr_sz;
	unsigned int       smmu_sync_01;
	unsigned int       smmu_sync_02;
	unsigned int       smmu_sync_03;
	unsigned int       smmu_sync_04;
	unsigned int       reserved32_01;
	unsigned int       reserved32_02;
	unsigned int       reserved32_03;
	unsigned int       reserved32_04;
};

struct dsp_entry {    
    unsigned int        dsp_addr;
    unsigned int        lo32_soc_addr;
    unsigned int        hi32_soc_addr;
    unsigned int        size;     
};
struct dsp_cfg {    
    unsigned char      vdsp_num;
    unsigned char      valid_entry_num;
    unsigned char      reserved01;
    unsigned char      reserved02;
    struct dsp_entry   vdsp_entry[4];  
};



struct hw_msgq_ctrl{
    unsigned int full_addr;
    unsigned int empty_addr;
    unsigned int wr;
    unsigned int rd;
    unsigned int int_ctrl;
};

struct priv_hw_cfg {
    struct  hw_cfg_header    header;
    struct  system_cfg       sys_cfg;
    struct  dsp_cfg          vdsp_cfg;
    struct  hw_msgq_ctrl     msgq_ctrls[MSGQ_CTRL_MAX];
    struct  ring_buf_entry   ring_buf_entry[];
};


struct global_cfg_entry {
    unsigned char         devfn;                //The current function number on pci bus
    unsigned char         pfn;                  //The current pf number 
    unsigned char         vfn;                  //The current vf number           
    unsigned char         vf_active;            //The current function is pf or vf, 0:pf 1:vf 
    unsigned int          lo32_ddr_base;        //ddr base (low32 bit)     
    unsigned int          hi32_ddr_base;        //ddr base (high32 bit)  
    unsigned int          lo32_mmio_ddr_size;   //host access ddr size by mmio (low32 bit)
    unsigned int          hi32_mmio_ddr_size;   //host access ddr size by mmio (high32 bit)
    unsigned int          lo32_ddr_size;        //mcu access ddr size  (low32 bit)
    unsigned int          hi32_ddr_size;        //mcu access ddr size  (high32 bit)
    struct priv_hw_cfg*   priv_hw_cfg_ptr;      //point to hw config info
};

struct global_hw_cfg {
    unsigned int                magic_num;                //check num
    unsigned char               total_fn;                 //current soc have total_fn function (include all pf and  all vf)
    unsigned char               num_pfs;                  //current soc have num_pfs pf
    unsigned char               num_vfs;                  //current soc per pf have num_vfs vf
    unsigned char               pkg_id;                   //0:master-pkg 1:slave-pkg
    unsigned char               gfx_mode;
    unsigned char               fn_mode;
    unsigned char               decoder_en;
    unsigned char               reserved02;
    unsigned int                lo32_sum_ddr_size;        //mcu access ddr size  (low32 bit)
    unsigned int                hi32_sum_ddr_size;        //mcu access ddr size  (high32 bit)
    struct global_cfg_entry     g_cfg_entry[];            //dynamic g_cfg_entry array 
};
#pragma pack()

#if defined(__GMCU__) || defined(__SMCU__) || defined(__MCU__)
struct ring_buf_entry   *find_hw_cfg_acord_name(struct priv_hw_cfg *priv_hw_cfg, char *hw_cfg_name);
void pcie_triger_msi_irq(unsigned char pf,
             unsigned char vf, unsigned char vf_active,
             unsigned char vector);
struct global_hw_cfg    *get_global_hw_cfg_ptr(void);
#else
int get_hw_config(struct vastai_pci_info *priv);
struct ring_buf_entry *find_hw_cfg_acord_name(struct vastai_pci_info *priv, char *hw_cfg_name);
void dump_current_fn_hw_cfg_info(struct vastai_pci_info *priv);
#endif


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SG100_HW_CONFIG_H__ */
#endif /* SG100_USED */
