#ifdef SG100_USED
#ifndef __HW_QUEUE_H__
#define __HW_QUEUE_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "config.h"

#if defined(__GMCU__) || defined(__SMCU__)
#include "sg100_type.h"

#define msgq_reg_read32(__msgq, __type, __member)        \
    ((__type *)(__msgq->reg_base))->__member
#define msgq_reg_write32(__msgq, __type, __member, __val)    \
    ((__type *)(__msgq->reg_base))->__member = __val

#define msgq_copy_mem_to_dev(__msgq, dest, src, len)        \
    memcpy(dest, src, len)
#define msgq_copy_dev_to_mem(__msgq, dest, src, len)        \
    memcpy(dest, src, len)
#else
#include <linux/stddef.h>
#include <linux/string.h>
#include "vastai_pci.h"

static inline void _msgq_copy_mem_to_dev(void* dest, const void *src, u32 len)
{
    u32 l;

    if ((u64)dest & 0x7) {
        l = 0x8 - ((u64)dest & 0x7);
        l = l > len ? len : l;
        memcpy_toio(dest, src, l);
        src += l;
        dest += l;
        len -= l;
    }
    while (len >= 8) {
        writeq(*((u64 *)src), dest);
        src += 8;
        dest += 8;
        len -= 8;
    }
    if (len >= 4) {
        writel(*((u32 *)src), dest);
        src += 4;
        dest += 4;
        len -= 4;
    }
    if (len) {
        memcpy_toio(dest, src, len);
    }
}

static inline void _msgq_copy_dev_to_mem(void* dest, void *src, u32 len)
{
    u32 l;

    if ((u64)src & 0x7) {
        l = 0x8 - ((u64)src & 0x7);
        l = l > len ? len : l;
        memcpy_fromio(dest, src, l);
        src += l;
        dest += l;
        len -= l;
    }
    while (len >= 8) {
        *((u64 *)dest) = readq(src);
        src += 8;
        dest += 8;
        len -= 8;
    }
    if (len >= 4) {
        *((u32 *)dest) = readl(src);
        src += 4;
        dest += 4;
        len -= 4;
    }
    if (len) {
        memcpy_fromio(dest, src, len);
    }
}

#define msgq_reg_read32(__msgq, __type, __member)        \
    readl(__msgq->reg_base + offsetof(__type, __member))
#define msgq_reg_write32(__msgq, __type, __member, __val)    \
    writel(__val, __msgq->reg_base + offsetof(__type, __member))

#define msgq_copy_mem_to_dev(__msgq, __dest, __src, __len)    \
    _msgq_copy_mem_to_dev(__dest, __src, __len)
#define msgq_copy_dev_to_mem(__msgq, __dest, __src, __len)    \
    _msgq_copy_dev_to_mem(__dest, __src, __len)

#endif

#define VA_HW_MSGQ_NAME_LEN_MAX 32

struct hw_msgq {
    char name[VA_HW_MSGQ_NAME_LEN_MAX];
    void *reg_base;
    u32 mask;
    u32 esize;
    void *data;
    void *priv;
};

struct hw_msgq_ctrl_reg {
    u32 full_addr;
    u32 empty_addr;
    u32 wr;
    u32 rd;
    u32 int_ctrl;
};

static inline u32 msgq_size(struct hw_msgq *msgq)
{
    return msgq->mask + 1;
}

static inline u32 msgq_len(struct hw_msgq *msgq)
{
    return (msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr)
         - msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd));
}

static inline unsigned int msgq_unused(struct hw_msgq *msgq)
{
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);
    u32 rd = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, rd);

    return (msgq->mask + 1) - (wr - rd);
}

static inline unsigned int msgq_wr(struct hw_msgq *msgq)
{
    u32 wr = msgq_reg_read32(msgq, struct hw_msgq_ctrl_reg, wr);

    return msgq->mask & wr;
}

int hw_msgq_init(struct hw_msgq *msgq, char *name, u64 ctrl_reg_addr,
        u64 data_addr, u32 size, u32 esize,
        void *priv);

int msgq_in(struct hw_msgq *msgq,
        const void *buf, u32 len);
int msgq_in_entriely(struct hw_msgq *msgq,
        const void *buf, u32 len);

int msgq_ptr_in_entriely(struct hw_msgq *msgq, u32 len);

int msgq_dry_out(struct hw_msgq *msgq, u32 len,
         void **buf_p);
int msgq_ptr_out_entriely(struct hw_msgq *msgq, u32 len);

int msgq_copy_out(struct hw_msgq *msgq,
        void *buf, u32 len);
int msgq_out(struct hw_msgq *msgq,
        void *buf, u32 len);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __HW_QUEUE_H__ */
#endif /* SG100_USED */
