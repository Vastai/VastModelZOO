#ifdef SG100_USED
#ifndef __SG100_GMCU_H__
#define __SG100_GMCU_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "csram_partition.h"

/*
 * sg100 memory map:
 * csram:  0x00_0080_0000 1MB
 * ddr:    0x10_0000_0000 8GB
 * sdma0:  32KB
 * sdma1:  32KB
 * SMU_CSR: 32KB
 */

#define SG100_CSRAM_BASE            0x0000800000
#define SG100_GFX_REG_OFFSET        0x00040000
#define SG100_GFX0_REG_BASE         0x0000c00000
#define SG100_GFX1_REG_BASE         0x0000d00000
#define SG100_GFX2_REG_BASE         0x0000e00000
#define SG100_GFX3_REG_BASE         0x0000f00000
#define SG100_GFX_REG_SIZE          0x000080000     /* 512KB */
#define SG100_PCIE_EP_SLAVE         0x0010000000

#define SG100_DDR_BASE              0x1000000000
#define SG100_SDMA0_CSR_BASE        0x0000aa0000     /* 32KB */
#define SG100_SDMA1_CSR_BASE        0x0000aa8000
#define SG100_SMU_CSR_BASE          0x208000         /* 32KB */


#define H2D_M2O_CMD_MSGQ_CTRL_REG_BASE      0x00000100
#define LOG_BUF_MSGQ_CTRL_REG_BASE          0x00000200
#define GMCU_2_HOST_MSGQ0_CTRL_REG_BASE     0x00000300
#define GMCU_PCIE_TRANSMIT_STAT_REG_BASE    0x00000400
#define PCIE_DMA0_RD_MSGQ_CTRL_REG_BASE     0x00000500
#define PCIE_DMA0_WR_MSGQ_CTRL_REG_BASE     0x00000600
#define GMCU_RW_REG_BASE                    0x00000700

#define GMCU_2_HOST_MSGQ0_BUF_BASE          0x00000800
#define GMCU_2_HOST_MSGQ0_BUF_SIZE          (8 * 128)
#define LOG_BUF_MSGQ_DATA_BUF_BASE          0x00010000
#define LOG_BUF_MSGQ_DATA_BUF_SIZE          (0x1000)


#define PCIE_DMA0_RD_MSGQ_DATA_BUF_BASE     0x00010000
#define PCIE_DMA0_RD_MSGQ_DATA_BUF_SIZE     (24 * 1024 * 2)
#define PCIE_DMA0_WR_MSGQ_DATA_BUF_BASE     0x00020000
#define PCIE_DMA0_WR_MSGQ_DATA_BUF_SIZE     (24 * 1024 * 2)

#define PCIE_SDMA0_RD_MSGQ_DATA_BUF_BASE    0x00001400
#define PCIE_SDMA0_RD_MSGQ_DATA_BUF_SIZE    (8 * 1024)

#define GMCU_H2D_M2O_CMD_BUF_BASE           0X3D000
#define GMCU_H2D_MSGQ_CMD_BUF_BASE          0X3E000
#define GMCU_CSRAM_CMD_BUF_SIZE             (3 * 512)

#define GMCU_CSRAM_EACH_FUN_BUF_LEN         0X40000

/* sizeof(struct hw_msgq_ctrl_reg) = 20B */
/* log buf in GMCUx entry map */
#define GMCU_ENTRY_LOG_BUF_MSGQ_DATA_BUF_BASE(g)    AI_PIPELINE_INFO_PER_VF(g, 0)
#define GMCU_LOG_BUF_MSGQ_CTRL_REG_BASE(g)          RESERVED_3KB_PER_VF(g, 0)

/* pcie ep slave map */
#define PCIE_EP_SLAVE_MSIX_DOORBELL_TRIGER          (0x00000000 + SG100_PCIE_EP_SLAVE)

/*
 * gmcu0: rst:8000_0000
 * gmcu1: rst:8000_0004
 * gmcu2: rst:8000_0008
 * gmcu3: rst:8000_000C
 * def_rst_rw_addr: 4_6FFC
 */
#define GMCU0_CODE_BASE                0x1180000000
#define GMCU1_CODE_BASE                0x1180100000
#define GMCU2_CODE_BASE                0x1180200000
#define GMCU3_CODE_BASE                0x1180300000

#define SG100_DDR_GFX_BAR              4
#define SG100_DISPLAY_CSR_SZ_1MB       0x100000
#define BAR2_SMCU_CSRAM_32KB           (32*1024)
#define SG100_DSU_CSR_SZ_128KB         (128*1024)
#define BAR2_RESERVED_SZ_1M_896KB      (0x100000+896*1024)
#define DISPLAY_NOC_ADDR                0x280000
#define DSU_NOC_ADDR                    0xA80000
#define SG100_DDR_GFX0_BASE             0x104A000000 
#define SG100_DDR_GFX1_BASE             0x104A000000
#define SG100_DDR_GFX2_BASE             0x104A000000
#define SG100_DDR_GFX3_BASE             0x104A000000

#ifdef DIAG_TEST_DDK
#define SG100_GFX_HEAP_BAR_OFFSET       0x000A000000
#define SG100_GFX_HEAP_DEV_OFFSET       0x0000000000
#define SG100_GFX_HEAP_SIZE             0x50000000  /* 1.25GB */
#define SG100_DISP_HEAP_BAR_OFFSET      0x005A000000
#define SG100_DISP_HEAP_DEV_OFFSET      0x50000000
#define SG100_DISP_HEAP_SIZE            0x10000000 /* 256MB */
#else
#define SG100_GFX_HEAP_BAR_OFFSET       0x000A000000
#define SG100_GFX_HEAP_DEV_OFFSET       0x0000000000
#define SG100_GFX_HEAP_SIZE             0x0060000000 /* 1GB + 512MB */
#define SG100_DISP_HEAP_BAR_OFFSET      0x006A000000
#define SG100_DISP_HEAP_DEV_OFFSET      0x0060000000
#define SG100_DISP_HEAP_SIZE            0x0010000000 /* 512MB */
#endif


#define SG100_4GB_GFX_HEAP_BAR_OFFSET  0x000A000000
#define SG100_4GB_GFX_HEAP_DEV_OFFSET  0x0000000000
#define SG100_4GB_GFX_HEAP_SIZE        0x00D6000000
#define SG100_4GB_DISP_HEAP_BAR_OFFSET 0x00E0000000
#define SG100_4GB_DISP_HEAP_DEV_OFFSET 0x00D6000000
#define SG100_4GB_DISP_HEAP_SIZE       0x0010000000 /* 256MB */

#define VF_GFX_HEAP_BAR_OFFSET          0x0004000000
#define VF_GFX_HEAP_DEV_OFFSET          0x0000000000
#define VF_GFX_HEAP_SIZE                0x0008000000 /* 128MB */
#define VF_DISP_HEAP_BAR_OFFSET         0x000c000000 
#define VF_DISP_HEAP_DEV_OFFSET         0x0008000000
#define VF_DISP_HEAP_SIZE               0x0004000000 /* 64MB */

/*
 * gpu inturrept map:
 * mcu int_num 16...23 map to gpu int_num 0...7
 */
#define GFX0_INTERRUPT_0            XCHAL_EXTINT25_NUM
//#define GFX0_INTERRUPT_1            XCHAL_EXTINT26_NUM
//#define GFX0_INTERRUPT_2            XCHAL_EXTINT27_NUM
//#define GFX0_INTERRUPT_3            XCHAL_EXTINT28_NUM
//#define GFX0_INTERRUPT_4            XCHAL_EXTINT29_NUM
//#define GFX0_INTERRUPT_5            XCHAL_EXTINT30_NUM
//#define GFX0_INTERRUPT_6            XCHAL_EXTINT31_NUM
//#define GFX0_INTERRUPT_7            XCHAL_EXTINT32_NUM

/*
 * pcie dma interrupt map
 */
#define PCIE_DMA_INT_RD_CH3         XCHAL_EXTINT2_NUM
#define PCIE_DMA_INT_WR_CH0         XCHAL_EXTINT12_NUM
#define PCIE_DMA_INT_WR_CH1         XCHAL_EXTINT13_NUM
#define PCIE_DMA_INT_WR_CH2         XCHAL_EXTINT14_NUM
#define PCIE_DMA_INT_WR_CH3         XCHAL_EXTINT15_NUM
#define PCIE_DMA_INT_RD_CH0         XCHAL_EXTINT16_NUM
#define PCIE_DMA_INT_RD_CH1         XCHAL_EXTINT17_NUM
#define PCIE_DMA_INT_RD_CH2         XCHAL_EXTINT18_NUM

#define SDMA0_INT                   PCIE_DMA_INT_RD_CH1
#define SDMA1_INT                   PCIE_DMA_INT_RD_CH2

/* SKX-Add-S-20220607 */
#define SG100_INT_CTRL_REG_BASE                      0X900000
/********************S<-------msgq control register------->S*************************/
#define GMCU0_MSGQ_CTRL_REG_OFFSET                   (32768*4)   /* 0x20000 */
#define GMCU1_MSGQ_CTRL_REG_OFFSET                   (40960*4)   /* 0x28000 */
#define GMCU2_MSGQ_CTRL_REG_OFFSET                   (49152*4)   /* 0x30000 */
#define GMCU3_MSGQ_CTRL_REG_OFFSET                   (57344*4)   /* 0x38000 */
#define SG100_MSGQ_TO_MSGQ_DISTANCE                  (4*8)
#define GMCU_TO_MSGQ_CTRL_LEN                        0x8000

#define GMCU0_MSGQ_CTRL_BASE              SG100_INT_CTRL_REG_BASE + GMCU0_MSGQ_CTRL_REG_OFFSET   /* 0X920000 */
#define GMCU1_MSGQ_CTRL_BASE              SG100_INT_CTRL_REG_BASE + GMCU1_MSGQ_CTRL_REG_OFFSET
#define GMCU2_MSGQ_CTRL_BASE              SG100_INT_CTRL_REG_BASE + GMCU2_MSGQ_CTRL_REG_OFFSET
#define GMCU3_MSGQ_CTRL_BASE              SG100_INT_CTRL_REG_BASE + GMCU3_MSGQ_CTRL_REG_OFFSET

#define GMCU0_VF0_L_MSGQ_AFULL                       (32768*4)    /* 0x20000 */
#define GMCU0_VF1_L_MSGQ_AFULL                       (33792*4)    /* 0x21000 */
#define GMCU0_VF2_L_MSGQ_AFULL                       (34816*4)    /* 0x22000 */
#define GMCU0_VF3_L_MSGQ_AFULL                       (35840*4)    /* 0x23000 */
#define GMCU0_VF4_L_MSGQ_AFULL                       (36864*4)    /* 0x24000 */
#define GMCU0_VF5_L_MSGQ_AFULL                       (37888*4)    /* 0x25000 */
#define GMCU0_VF6_L_MSGQ_AFULL                       (38912*4)    /* 0x26000 */
#define GMCU0_VF7_L_MSGQ_AFULL                       (39936*4)    /* 0x27000 */

#define GMCU1_VF8_L_MSGQ_AFULL                       (40960*4)    /* 0x28000 */
#define GMCU1_VF9_L_MSGQ_AFULL                       (41984*4)    /* 0x29000 */

#define GMCU2_VF16_L_MSGQ_AFULL                      (49152*4)    /* 0x30000 */
#define GMCU2_VF17_L_MSGQ_AFULL                      (50176*4)    /* 0x31000 */

#define GMCU3_VF24_L_MSGQ_AFULL                      (57344*4)    /* 0x38000 */
#define GMCU3_VF25_L_MSGQ_AFULL                      (58368*4)    /* 0x39000 */

#define SG100_INT_MSGQ_AFULL_WATER_LEVEL_REG_OFFSET  0          /* msgq_afull_water_level */
#define SG100_INT_MSGQ_AEMPTY_WATER_LEVEL_REG_OFFSET 4           /* msgq_aempty_water_level */
#define SG100_INT_MSGQ_WR_REG_OFFSET                 8           /* msgq_wr */
#define SG100_INT_MSGQ_RD_REG_OFFSET                 12          /* msgq_rd  */
#define SG100_INT_MSGQ_MASK_STATUS_REG_OFFSET        16          /* msgq_int_mask_status */

/* msgq interrupt status */
#define FULL_INT         (1<<8) 
#define AFULL_INT        (1<<9) 
#define EMPTY_INT        (1<<10)  
#define NEMPTY_INT       (1<<11)
#define AEMPTY_INT       (1<<12)
/********************E<-------msgq control register------->E*************************/


/********************S<-------m2o control register------->S*************************/
/* gmcu0 m2o interrupt register offset */
#define SG100_INT_GMCU0_M2O_0_REG_OFFSET        (344*4)  /* 0x560 */
#define SG100_INT_GMCU0_M2O_1_REG_OFFSET        (360*4)  
#define SG100_INT_GMCU0_M2O_2_REG_OFFSET        (376*4)  
#define SG100_INT_GMCU0_M2O_3_REG_OFFSET        (392*4) 

/* gmcu1 m2o interrupt register offset */
#define SG100_INT_GMCU1_M2O_0_REG_OFFSET        (408*4)  
#define SG100_INT_GMCU1_M2O_1_REG_OFFSET        (424*4)  
#define SG100_INT_GMCU1_M2O_2_REG_OFFSET        (440*4)  
#define SG100_INT_GMCU1_M2O_3_REG_OFFSET        (456*4)

/* gmcu2 m2o interrupt register offset */
#define SG100_INT_GMCU2_M2O_0_REG_OFFSET        (472*4)  
#define SG100_INT_GMCU2_M2O_1_REG_OFFSET        (488*4)  
#define SG100_INT_GMCU2_M2O_2_REG_OFFSET        (504*4)  
#define SG100_INT_GMCU2_M2O_3_REG_OFFSET        (520*4)

/* gmcu3 m2o interrupt register offset */
#define SG100_INT_GMCU3_M2O_0_REG_OFFSET        (536*4)  
#define SG100_INT_GMCU3_M2O_1_REG_OFFSET        (552*4)  
#define SG100_INT_GMCU3_M2O_2_REG_OFFSET        (568*4)  
#define SG100_INT_GMCU3_M2O_3_REG_OFFSET        (584*4)

/* per group register offset is 16,per group include gmcu_m2o_int_grp,gmcu_m2o_int_sts and gmcu_m2o_int_clr */
#define SG100_INT_GMCU_M2O_PER_GROUP_REG_offset  (16*4)

/* per GMCU has 4 group register, per group register offset is 16*4 */
#define SG100_INT_GMCU_M2O_SUM_REG_LEN          (16*4*4)

#define PF0_CMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2756*4
#define PF0_CMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2757*4  
#define PF0_SMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2764*4
#define PF0_SMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2765*4  
#define PF0_GMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2772*4
#define PF0_GMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2773*4  
#define PF0_VEMCU_M2O_INT_STS                        SG100_INT_CTRL_REG_BASE+2780*4
#define PF0_VEMCU_M2O_INT_CLR                        SG100_INT_CTRL_REG_BASE+2781*4  
#define PF0_DSP_M2O_INT_STS                          SG100_INT_CTRL_REG_BASE+2788*4
#define PF0_DSP_M2O_INT_CLR                          SG100_INT_CTRL_REG_BASE+2789*4  

#define PF1_CMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2796*4
#define PF1_CMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2797*4  
#define PF1_SMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2804*4
#define PF1_SMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2805*4  
#define PF1_GMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2812*4
#define PF1_GMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2813*4  
#define PF1_VEMCU_M2O_INT_STS                        SG100_INT_CTRL_REG_BASE+2820*4
#define PF1_VEMCU_M2O_INT_CLR                        SG100_INT_CTRL_REG_BASE+2821*4  
#define PF1_DSP_M2O_INT_STS                          SG100_INT_CTRL_REG_BASE+2828*4
#define PF1_DSP_M2O_INT_CLR                          SG100_INT_CTRL_REG_BASE+2829*4  

#define PF2_CMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2836*4
#define PF2_CMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2837*4  
#define PF2_SMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2844*4
#define PF2_SMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2845*4  
#define PF2_GMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2852*4
#define PF2_GMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2853*4  
#define PF2_VEMCU_M2O_INT_STS                        SG100_INT_CTRL_REG_BASE+2860*4
#define PF2_VEMCU_M2O_INT_CLR                        SG100_INT_CTRL_REG_BASE+2861*4  
#define PF2_DSP_M2O_INT_STS                          SG100_INT_CTRL_REG_BASE+2868*4
#define PF2_DSP_M2O_INT_CLR                          SG100_INT_CTRL_REG_BASE+2869*4  

#define PF3_CMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2876*4
#define PF3_CMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2877*4  
#define PF3_SMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2884*4
#define PF3_SMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2885*4  
#define PF3_GMCU_M2O_INT_STS                         SG100_INT_CTRL_REG_BASE+2892*4
#define PF3_GMCU_M2O_INT_CLR                         SG100_INT_CTRL_REG_BASE+2893*4  
#define PF3_VEMCU_M2O_INT_STS                        SG100_INT_CTRL_REG_BASE+2900*4
#define PF3_VEMCU_M2O_INT_CLR                        SG100_INT_CTRL_REG_BASE+2901*4  
#define PF3_DSP_M2O_INT_STS                          SG100_INT_CTRL_REG_BASE+2908*4
#define PF3_DSP_M2O_INT_CLR                          SG100_INT_CTRL_REG_BASE+2909*4  

#define M2O_REG_CTRL_PF_TO_PF_DISTANCE                (40*4)

#define VF_CMCU_M2O_INT_OFFSET                        (24*4)
#define VF_SMCU_M2O_INT_OFFSET                        (25*4) 
#define VF_VEMCU_M2O_INT_OFFSET                       (26*4)   
#define VF_GMCU_M2O_INT_OFFSET                        (27*4)  
#define VF_VDSP_M2O_INT_OFFSET                        (28*4) 

#define PF_M2O_HAPPEN                                 (1<<0)
#define PF_VF0_M2O_HAPPEN                             (1<<1)
#define PF_VF1_M2O_HAPPEN                             (1<<2)   
#define PF_VF2_M2O_HAPPEN                             (1<<3)  
#define PF_VF3_M2O_HAPPEN                             (1<<4)  
#define PF_VF4_M2O_HAPPEN                             (1<<5)
#define PF_VF5_M2O_HAPPEN                             (1<<6)
#define PF_VF6_M2O_HAPPEN                             (1<<7)   

#define GMCU0_M2O_CTRL_REG_BASE   SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU0_M2O_0_REG_OFFSET
#define GMCU1_M2O_CTRL_REG_BASE   SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU1_M2O_0_REG_OFFSET
#define GMCU2_M2O_CTRL_REG_BASE   SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU2_M2O_0_REG_OFFSET
#define GMCU3_M2O_CTRL_REG_BASE   SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU3_M2O_0_REG_OFFSET

#define SG100_INT_GMCU_M2O_REG_GRP_OFFSET        (0)    /* gmcu_m2o_int_grp */
#define SG100_INT_GMCU_M2O_REG_STS_OFFSET        (32)   /* gmcu_m2o_int_sts */
#define SG100_INT_GMCU_M2O_REG_CLR_OFFSET        (36)   /* gmcu_m2o_int_clr */
/********************E<-------m2o control register------->E*************************/


/********************S<-------o2o control register------->S*************************/
//gmcu o2o interrupt register
#define SG100_INT_GMCU0_O2O_REG_OFFSET       (24*4)
#define SG100_INT_GMCU1_O2O_REG_OFFSET       (32*4)
#define SG100_INT_GMCU2_O2O_REG_OFFSET       (40*4)
#define SG100_INT_GMCU3_O2O_REG_OFFSET       (48*4)

#define GMCU0_O2O_CTRL_REG_BASE          SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU0_O2O_REG_OFFSET
#define GMCU1_O2O_CTRL_REG_BASE          SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU1_O2O_REG_OFFSET
#define GMCU2_O2O_CTRL_REG_BASE          SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU2_O2O_REG_OFFSET
#define GMCU3_O2O_CTRL_REG_BASE          SG100_INT_CTRL_REG_BASE + SG100_INT_GMCU3_O2O_REG_OFFSET

#define SG100_INT_GMCU_O2O_REG_BASE          (SG100_INT_CTRL_REG_BASE+SG100_INT_GMCU0_O2O_REG_OFFSET)
#define SG100_INT_GMCU_O2O_REG_LEN           (4*8)
/********************E<-------o2o control register------->E*************************/


/********************S<-------o2m control register------->S*************************/
//gmcu o2m interrupt register
#define O2M_INT_0_REG_BASE      (SG100_INT_CTRL_REG_BASE+1408*4)
#define O2M_INT_1_REG_BASE      (SG100_INT_CTRL_REG_BASE+1416*4)
#define O2M_INT_2_REG_BASE      (SG100_INT_CTRL_REG_BASE+1424*4)
#define O2M_INT_3_REG_BASE      (SG100_INT_CTRL_REG_BASE+1440*4)
/********************E<-------o2m control register------->E*************************/

/*SKX-Add-E-20220607*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SG100_GMCU_H__ */
#endif /* SG100_USED */
