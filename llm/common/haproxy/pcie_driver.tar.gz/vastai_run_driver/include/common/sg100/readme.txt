+2022/07/19
1. support single pkg official boot flow.
2. fix PCIe read error due to resource conflict.
3. Need enable __GMCU__ macro in hw_queue.h when compiling FW in Xtensa Windows.

+emulator version: lsc
+2022/3/14
sg100 common code between host driver and fw
2021/11/5
