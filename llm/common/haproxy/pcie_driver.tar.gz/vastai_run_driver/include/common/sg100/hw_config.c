#ifdef SG100_USED
#include "hw_config.h"

#if defined(__MCU__) || defined(__SMCU__) || defined(__GMCU__) 
static int custom_strcmp(const char* str1, const char* str2)
{
    while (*str1 && *str2 && !(*str1 - *str2)) {
        str1++;
        str2++;
    }
    return *str1 - *str2;
}

static unsigned int cur_pkg_1st_pfn = 0; 
struct ring_buf_entry *find_hw_cfg_acord_name(struct priv_hw_cfg *priv_hw_cfg,
                                        char *hw_cfg_name)
{
    unsigned int total_entry_num;
    struct ring_buf_entry *entry;
    int i;

    if(NULL == priv_hw_cfg){
        return NULL;
    }

    total_entry_num = priv_hw_cfg->header.total_cfg_entry;
    
    for(i=0;i<total_entry_num;i++){
        if (custom_strcmp(priv_hw_cfg->ring_buf_entry[i].name, hw_cfg_name) == 0){
            entry = (struct ring_buf_entry*)&priv_hw_cfg->ring_buf_entry[i];
            return entry;
        }
    }
    return NULL;
    
}


struct global_hw_cfg *get_global_hw_cfg_ptr(void)
{
    struct global_hw_cfg *ptr = (struct global_hw_cfg *)GLOBAL_HW_CFG_BASE;
    if(VF_MAGIC_NUM != ptr->magic_num) {
        return NULL;
    }

    if(HW_SLAVE_PKGID == ptr->pkg_id) {
        switch (ptr->fn_mode) {
        case ONLY_1_PF:
            cur_pkg_1st_pfn = 1;
            break;
        
        case ONLY_2_PF:
            cur_pkg_1st_pfn = 2;
            break;
        
        case ONLY_4_PF:
        case PF_4_VF_28:
            cur_pkg_1st_pfn = 4;
        default:
            break;
        }
    } else {
        cur_pkg_1st_pfn = 0;
    }
    return ptr;
}

/**
 * MSIX DOORBELL reg
 * PF: 28:24
 * VF: 23:16
 * VF_ACTIVE: 0:PF, 1:VF
 * TC: 14:12
 * Vector: 10:0
 */
void pcie_triger_msi_irq(unsigned char pf,
             unsigned char vf, unsigned char vf_active,
             unsigned char vector)
{
    unsigned int reg_val;
    pf = pf + cur_pkg_1st_pfn;
    reg_val = (pf << 24) | (vf_active ? (1 << 15 | vf << 16) : 0) | vector;

    hw_writel(reg_val, 0x0010000000);
}


#else


int get_hw_config(struct vastai_pci_info *priv)
{
    struct priv_hw_cfg *priv_hw_cfg=NULL;
    struct hw_cfg_header cfg_header;
    int ret=0;
    u32 total_hw_cfg_size = 0;
    ret = vastai_pci_mmio_read(priv, VASTAI_PCI_BAR2, 0, &cfg_header, sizeof(struct hw_cfg_header));
    if(ret){
        return ret;
    }

    total_hw_cfg_size = sizeof(struct hw_cfg_header) + sizeof(struct  system_cfg) + sizeof(struct dsp_cfg) +
                        sizeof(struct hw_msgq_ctrl) * MSGQ_CTRL_MAX + sizeof(struct  ring_buf_entry) * cfg_header.total_cfg_entry;
    
    priv_hw_cfg = kzalloc(total_hw_cfg_size, GFP_KERNEL);

    ret = vastai_pci_mmio_read(priv, VASTAI_PCI_BAR2, 0, priv_hw_cfg, total_hw_cfg_size);
    if(ret){
        return ret;
    }

    //[SKX]to do free vf_hw_cfg
    priv->priv_hw_cfg=priv_hw_cfg;


    if(VF_MAGIC_NUM!=priv->priv_hw_cfg->header.magic_num){
        priv->priv_hw_cfg = NULL;
        hw_cfg_dbg("get_hw_config fail\n");
        return -1;
    }
    hw_cfg_dbg("----hw cfg info---->S\n");
    switch (priv_hw_cfg->sys_cfg.card_type) {
        case 0:
            hw_cfg_dbg("[EVB-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;
        case 1:
            hw_cfg_dbg("[AIC_ANYI-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;
        case 2:
            hw_cfg_dbg("[AIC_ZHAOGE-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;        
        default:
            break;
    }

    if(0 == priv_hw_cfg->sys_cfg.pkg_id){
        hw_cfg_dbg("[master-pkg]\n");
    } else if(1 == priv_hw_cfg->sys_cfg.pkg_id){
        hw_cfg_dbg("[slave-pkg]\n");
    }

    switch (priv_hw_cfg->sys_cfg.fn_mode){
        case ONLY_1_PF:
            hw_cfg_dbg("[GFX 1+3 mode]\n");
            hw_cfg_dbg("[ONLY_1_PF]\n");
            break;
        case ONLY_2_PF:
            hw_cfg_dbg("[GFX 1+1 mode]\n");
            hw_cfg_dbg("[ONLY_2_PF]\n");
            break;
        case ONLY_4_PF:
            hw_cfg_dbg("[GFX standalone]\n");
            hw_cfg_dbg("[ONLY_4_PF]\n");
            break;
        case PF_4_VF_28:
            hw_cfg_dbg("[GFX standalone]\n");
            hw_cfg_dbg("[PF_4_WITH_SRIOV]\n");
            break;
        
        default:
            break;
    }

    if(1 == priv_hw_cfg->sys_cfg.dp_en){
        hw_cfg_dbg("[Display Enable]\n");
    } else if(0 == priv_hw_cfg->sys_cfg.dp_en){
        hw_cfg_dbg("[Display Disable]\n");
    }

    if(priv_hw_cfg->sys_cfg.bar4_5_cfg_size>0){
        hw_cfg_dbg("bar4_5_cfg    = %dGB\n",  priv_hw_cfg->sys_cfg.bar4_5_cfg_size);
    } else {
        hw_cfg_dbg("bar4_5_cfg is normal cfg pf is 2GB,vf is 256MB");
    }
    
    hw_cfg_dbg("hw_cfg size   = 0x%x\n",total_hw_cfg_size);
    hw_cfg_dbg("csram_base    = 0x%x\n",priv->priv_hw_cfg->header.csram_base);
    hw_cfg_dbg("csram_size    = 0x%x\n",priv->priv_hw_cfg->header.csram_size);
    hw_cfg_dbg("smu_csr_base  = 0x%x\n",priv->priv_hw_cfg->header.smu_csr_base);
    hw_cfg_dbg("smu_csr_size  = 0x%x\n",priv->priv_hw_cfg->header.smu_csr_size);
    hw_cfg_dbg("gfx_csr_base  = 0x%x\n",priv->priv_hw_cfg->header.gfx_csr_base);
    hw_cfg_dbg("gfx_csr_size  = 0x%x\n",priv->priv_hw_cfg->header.gfx_csr_size);
    hw_cfg_dbg("pkg_id        = 0x%x\n",priv->priv_hw_cfg->sys_cfg.pkg_id);
    hw_cfg_dbg("fn_mode       = 0x%x\n",priv->priv_hw_cfg->sys_cfg.fn_mode);
    hw_cfg_dbg("devfn    =%d  pf=%d vf=%d  isvf=%d\n",priv->priv_hw_cfg->sys_cfg.devfn,
                                                      priv->priv_hw_cfg->sys_cfg.pfn,
                                                      priv->priv_hw_cfg->sys_cfg.vfn,
                                                      priv->priv_hw_cfg->sys_cfg.vf_active);
    hw_cfg_dbg("stream_id     =%d\n",priv->priv_hw_cfg->sys_cfg.stream_id);
    hw_cfg_dbg("ddr_base      =0x%llx\n",(u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base<<32)|
                                            priv->priv_hw_cfg->header.lo32_ddr_base);
    hw_cfg_dbg("mmio_ddr_size =0x%llx\n",(u64)priv->priv_hw_cfg->header.mmio_ddr_size<<12);
    hw_cfg_dbg("ddr_size      =0x%llx\n",(u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_size<<32)|
                                            priv->priv_hw_cfg->header.lo32_ddr_size);
    hw_cfg_dbg("----hw cfg info---->E\n");
    return 0;
}



struct ring_buf_entry *find_hw_cfg_acord_name(struct vastai_pci_info *priv,
                                        char *hw_cfg_name)
{
    u32 total_entry_num;
    struct ring_buf_entry *entry;
    int i;
    if(NULL == priv->priv_hw_cfg){
        return NULL;
    }
    total_entry_num = priv->priv_hw_cfg->header.total_cfg_entry;
    for(i=0;i<total_entry_num;i++){
        if (strcmp(priv->priv_hw_cfg->ring_buf_entry[i].name, hw_cfg_name) == 0){
            entry = (struct ring_buf_entry*)&priv->priv_hw_cfg->ring_buf_entry[i];
            return entry;
        }        
    }

    hw_cfg_dbg("not find %s entry\n",hw_cfg_name);
    return NULL;
    
}

void dump_current_fn_hw_cfg_info(struct vastai_pci_info *priv)
{
    int i;
    int ret;
    struct vastai_fifo  ring_buf_header;
    struct hw_msgq_ctrl msgq_header;
    struct priv_hw_cfg *priv_hw_cfg = priv->priv_hw_cfg;
    u32    total_hw_cfg_size;

    u32 *wr = kzalloc(priv_hw_cfg->header.total_cfg_entry*4, GFP_KERNEL);
    u32 *rd = kzalloc(priv_hw_cfg->header.total_cfg_entry*4, GFP_KERNEL);

    if(VF_MAGIC_NUM != priv_hw_cfg->header.magic_num) {
        hw_cfg_dbg("not match priv_hw_cfg\n");
        return;
    }

    for(i=0;i<priv_hw_cfg->header.total_cfg_entry;i++) {
        if(0 == priv_hw_cfg->ring_buf_entry[i].ring_buf_base){
            continue;
        }
        if( NOT_VALID_INFO == priv_hw_cfg->ring_buf_entry[i].msgq_ctrl_reg_base){
            ret = vastai_pci_mem_read(priv,0, priv_hw_cfg->ring_buf_entry[i].ring_buf_base, 
							&ring_buf_header,sizeof(struct vastai_fifo));
            if(ret) {
                hw_cfg_dbg("read ring_buf_header error\n");
            } else {
                wr[i] = ring_buf_header.wr;
                rd[i] = ring_buf_header.rd;
            }
            
            
        } else {
            ret = vastai_pci_mem_read(priv,0, priv_hw_cfg->ring_buf_entry[i].msgq_ctrl_reg_base, 
							&msgq_header,sizeof(struct hw_msgq_ctrl));
            if(ret) {
                hw_cfg_dbg("read msgq_header error\n");
            } else {
                wr[i] = msgq_header.wr;
                rd[i] = msgq_header.rd;
            }
        }       
    }

    hw_cfg_dbg("S<=============hw_cfg_info fn:%d===========>S\n",priv->dev->devfn);
    switch (priv_hw_cfg->sys_cfg.card_type) {
        case 0:
            hw_cfg_dbg("[EVB-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;
        case 1:
            hw_cfg_dbg("[AIC_ANYI-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;
        case 2:
            hw_cfg_dbg("[AIC_ZHAOGE-%dGB]\n",priv_hw_cfg->sys_cfg.sum_ddr_sz);
            break;        
        default:
            break;
    }

    if(0 == priv_hw_cfg->sys_cfg.pkg_id){
        hw_cfg_dbg("[master-pkg]\n");
    } else if(1 == priv_hw_cfg->sys_cfg.pkg_id){
        hw_cfg_dbg("[slave-pkg]\n");
    }

    switch (priv_hw_cfg->sys_cfg.fn_mode){
        case ONLY_1_PF:
            hw_cfg_dbg("[GFX 1+3 mode]\n");
            hw_cfg_dbg("[ONLY_1_PF]\n");
            break;
        case ONLY_2_PF:
            hw_cfg_dbg("[GFX 1+1 mode]\n");
            hw_cfg_dbg("[ONLY_2_PF]\n");
            break;
        case ONLY_4_PF:
            hw_cfg_dbg("[GFX standalone]\n");
            hw_cfg_dbg("[ONLY_4_PF]\n");
            break;
        case PF_4_VF_28:
            hw_cfg_dbg("[GFX standalone]\n");
            hw_cfg_dbg("[PF_4_WITH_SRIOV]\n");
            break;
        
        default:
            break;
    }

    if(1 == priv_hw_cfg->sys_cfg.dp_en){
        hw_cfg_dbg("[Display Enable]\n");
    } else if(0 == priv_hw_cfg->sys_cfg.dp_en){
        hw_cfg_dbg("[Display Disable]\n");
    }

    if(priv_hw_cfg->sys_cfg.bar4_5_cfg_size>0){
        hw_cfg_dbg("bar4_5_cfg    = %dGB\n",  priv_hw_cfg->sys_cfg.bar4_5_cfg_size);
    } else {
        hw_cfg_dbg("bar4_5_cfg is normal cfg pf is 2GB,vf is 256MB");
    }

    total_hw_cfg_size = sizeof(struct hw_cfg_header) + sizeof(struct  system_cfg) + sizeof(struct dsp_cfg) +
                        sizeof(struct hw_msgq_ctrl) * MSGQ_CTRL_MAX + sizeof(struct  ring_buf_entry) * priv_hw_cfg->header.total_cfg_entry;
    hw_cfg_dbg("hw_cfg size   = 0x%x\n",  total_hw_cfg_size);
    hw_cfg_dbg("csram_base    = 0x%x\n" , priv_hw_cfg->header.csram_base);
    hw_cfg_dbg("csram_size    = 0x%x\n" , priv_hw_cfg->header.csram_size);
    hw_cfg_dbg("smu_csr_base  = 0x%x\n" , priv_hw_cfg->header.smu_csr_base);
    hw_cfg_dbg("smu_csr_size  = 0x%x\n" , priv_hw_cfg->header.smu_csr_size);
    hw_cfg_dbg("gfx_csr_base  = 0x%x\n" , priv_hw_cfg->header.gfx_csr_base);
    hw_cfg_dbg("gfx_csr_size  = 0x%x\n" , priv_hw_cfg->header.gfx_csr_size);
    hw_cfg_dbg("ddr_base      = 0x%llx\n",(u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_base<<32)|
                                           priv->priv_hw_cfg->header.lo32_ddr_base);
    hw_cfg_dbg("mmio_ddr_size = 0x%llx(%lldMB)\n" , (u64)priv_hw_cfg->header.mmio_ddr_size<<12,
                                          ((u64)priv_hw_cfg->header.mmio_ddr_size<<12)/1024/1024);
    hw_cfg_dbg("ddr_size      = 0x%llx(%lldMB)\n",(u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_size<<32)|
                                           priv->priv_hw_cfg->header.lo32_ddr_size,
                                           ((u64)((u64)priv->priv_hw_cfg->header.hi32_ddr_size<<32)|
                                           priv->priv_hw_cfg->header.lo32_ddr_size)/1024/1024);
    
    hw_cfg_dbg("total_ringbuf = %d\n" ,   priv_hw_cfg->header.total_cfg_entry);
    hw_cfg_dbg("devfn         = %d\n" ,   priv_hw_cfg->sys_cfg.devfn);
    hw_cfg_dbg("pfn           = %d\n" ,   priv_hw_cfg->sys_cfg.pfn);
    hw_cfg_dbg("vfn           = %d\n" ,   priv_hw_cfg->sys_cfg.vfn);
    hw_cfg_dbg("vf_active     = %d\n" ,   priv_hw_cfg->sys_cfg.vf_active);
    hw_cfg_dbg("gfx_mode      = %d\n" ,   priv_hw_cfg->sys_cfg.gfx_mode);
    hw_cfg_dbg("pkg_id        = %d\n" ,   priv_hw_cfg->sys_cfg.pkg_id);
    hw_cfg_dbg("vdsp_num      = %d\n" ,   priv_hw_cfg->vdsp_cfg.vdsp_num);
    hw_cfg_dbg("vdsp_entry    = %d\n" ,   priv_hw_cfg->vdsp_cfg.valid_entry_num);
    for(i=0;i<priv_hw_cfg->vdsp_cfg.valid_entry_num;i++){
        hw_cfg_dbg("vdsp_entry[%d]  dsp_addr[0x%08x] noc_addr[0x%010llx] size[0x%08x]\n",i, priv_hw_cfg->vdsp_cfg.vdsp_entry[i].dsp_addr,
                                                    (u64)((u64)priv_hw_cfg->vdsp_cfg.vdsp_entry[i].hi32_soc_addr<<32)|
                                                    priv_hw_cfg->vdsp_cfg.vdsp_entry[i].lo32_soc_addr,
                                                    priv_hw_cfg->vdsp_cfg.vdsp_entry[i].size);
    }
    hw_cfg_dbg("===============ring_buf info fn:%d==============\n",priv->dev->devfn);

    for(i=0;i<priv_hw_cfg->header.total_cfg_entry;i++) {
        if(0 == priv_hw_cfg->ring_buf_entry[i].ring_buf_base){
            continue;
        }
        hw_cfg_dbg("ring_buf[%02d]%s base=0x%06x size=0x%06x ctrl=0x%08x vf_m2o=0x%08x wr[%06d] rd[%06d]\n" , 
                                                            i,priv_hw_cfg->ring_buf_entry[i].name,
                                                            priv_hw_cfg->ring_buf_entry[i].ring_buf_base,
                                                            priv_hw_cfg->ring_buf_entry[i].ring_buf_size,
                                                            priv_hw_cfg->ring_buf_entry[i].msgq_ctrl_reg_base,
                                                            priv_hw_cfg->ring_buf_entry[i].m2o_reg_base,
                                                            wr[i],rd[i]);
        
    }

    kfree(wr);
    kfree(rd);
    hw_cfg_dbg("E<==============hw_cfg_info fn:%d===========>E\n",priv->dev->devfn);
    return;
}



#endif 
#endif /* SG100_USED */
