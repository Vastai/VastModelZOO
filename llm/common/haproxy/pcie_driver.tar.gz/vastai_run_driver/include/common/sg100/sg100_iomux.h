#ifdef SG100_USED
#ifndef __SG100_IO_MUX__//config pin mux
#define __SG100_IO_MUX__
#include "sg100_base.h"

#define REG_SMU_PIN_MUX_BASE_ADDR     REG_GPIO1_BASE_ADDR
#define OF_SMU_PADRING_CONFIG_0        (0x40U)
#define OF_SMU_PADRING_CONFIG_1        (0x44U)
#define OF_SMU_PADRING_CONFIG_2        (0x48U)
#define OF_SMU_PADRING_CONFIG_3        (0x4cU)
#define OF_SMU_PADRING_CONFIG_4        (0x50U)
#define OF_SMU_PADRING_CONFIG_5        (0x54U)
#define OF_SMU_PADRING_CONFIG_6        (0x58U)
#define OF_SMU_PADRING_CONFIG_7        (0x5cU)
#define OF_SMU_PADRING_CONFIG_8        (0x60U)
#define OF_SMU_PADRING_CONFIG_9        (0x64U)
#define OF_SMU_PADRING_CONFIG_10       (0x68U)
#define OF_SMU_PADRING_CONFIG_11       (0x6cU)
#define OF_SMU_PADRING_CONFIG_12       (0x70U)
#define OF_SMU_PADRING_CONFIG_13       (0x74U)
#define OF_SMU_PADRING_CONFIG_14       (0x78U)
#define OF_SMU_PADRING_CONFIG_15       (0x7cU)
#define OF_SMU_PADRING_CONFIG_16       (0x80U)
#define OF_SMU_PADRING_CONFIG_17       (0x84U)
#define OF_SMU_PADRING_CONFIG_18       (0x88U)
#define OF_SMU_PADRING_CONFIG_19       (0x8cU)
#define OF_SMU_PADRING_CONFIG_20       (0x90U)
#define OF_SMU_PADRING_CONFIG_21       (0x94U)
#define OF_SMU_PADRING_CONFIG_22       (0x98U)
#define OF_SMU_PADRING_CONFIG_23       (0x9cU)
#define OF_SMU_PADRING_CONFIG_24       (0xa0U)
#define OF_SMU_PADRING_CONFIG_25       (0xa4U)
#define OF_SMU_PADRING_CONFIG_26       (0xa8U)
#define OF_SMU_PADRING_CONFIG_27       (0xacU)
#define OF_SMU_PADRING_CONFIG_28       (0xb0U)
#define OF_SMU_PADRING_CONFIG_29       (0xb4U)
#define OF_SMU_PADRING_CONFIG_30       (0xb8U)
#define OF_SMU_PADRING_CONFIG_31       (0xbcU)
#define OF_SMU_PADRING_CONFIG_32       (0xc0U)
#define OF_SMU_PADRING_CONFIG_33       (0xc4U)
#define OF_SMU_PADRING_CONFIG_34       (0xc8U)
#define OF_SMU_PADRING_CONFIG_35       (0xccU)
#define OF_SMU_PADRING_CONFIG_36       (0xd0U)
#define OF_SMU_PADRING_CONFIG_37       (0xd4U)
#define OF_SMU_PADRING_CONFIG_38        (0xd8U)

#define BIT_SMU_PADRING_CONFIG        (10U)
#define SMU_PADRING_CFG_MAIN        (1U)
#define SMU_PADRING_CFG_FUN1        (2U)
#define SMU_PADRING_CFG_FUN2        (4U)

#endif
#endif /* SG100_USED */
