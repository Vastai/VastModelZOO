#ifndef _VATOOL_ADDR_PARTITION_H_
#define _VATOOL_ADDR_PARTITION_H_

#define DEFAULT_ADDR 0X0
#define SMU_PBOOT_ADDR 0x1002B0
#define EFUSE_SRAM44_ADDR 0x3FF000B0
#define EFUSE_SRAM5_ADDR 0x3FF00014
#define EFUSE_SRAM6_ADDR 0x3FF00018
#define EFUSE_SRAM37_ADDR 0x3FF00094
#define EFUSE_SRAM38_ADDR 0x3FF00098
#define ECC_1BIT_ERR_STORE_ADDR 0x8CFC000
#define ECC_2BIT_ERR_STORE_ADDR 0x8CFC400
#define DDR_CONTROL1_ADDR 0x3003A0
#define DDR_CONTROL2_ADDR 0x4003A0
#define DDR_CONTROL3_ADDR 0x5003A0
#define DDR_CONTROL4_ADDR 0x6003A0
#define VALID_ADDR 0x3FF000E0
#define AIVI_DIS_ADDR 0x3FF00004
#define AIVID_FAIL_ADDR 0x3FF00008
#define SOC_REPAIR_ADDR 0x3FF002C8
#define VID_REPAIR_ADDR 0x3FF00338
#define DLC0_REPAIR_ADDR 0x3FF004A0
#define DLC1_REPAIR_ADDR 0x3FF00850
#define SMU_DONE_ADDR 0x10027C
#define PCIE_EP_LINK_ADDR 0x8F000D0
#define PCIE_EP_ERR0_ADDR 0x8F00110
#define PCIE_EP_ERR1_ADDR 0x8F00308
#define PCIE_RC_LINK_ADDR 0x98000D0
#define PCIE_RC_ERR0_ADDR 0x9800110
#define PCIE_RC_ERR1_ADDR 0x9800308
#define APP_VER_ADDR 0xCFC0
#define V2_VER_ADDR 0x5FC0
#define DDR_MEM_CODE_ADDR 0x800000000
#define DDR_MEM_WRTEST_ADDR 0x860000000
#define DDR_MEM_MAX_ADDR 0x9D8000000
#define GPIO_TEST_ADDR 0x1200010
#define CSRAM_MEM_RESERVED_3K 0x08CF6400

typedef enum {
	smu_pboot_addr = 0,
	efuse_sram44_addr,
	efuse_sram5_addr,
	efuse_sram6_addr,
	efuse_sram37_addr,
	efuse_sram38_addr,
	ecc_1bit_err_store_addr,
	ecc_2bit_err_store_addr,
	ddr_control1_addr,
	ddr_control2_addr,
	ddr_control3_addr,
	ddr_control4_addr,
	valid_addr,
	aivi_dis_addr,
	aivid_fail_addr,
	soc_repair_addr,
	vid_repair_addr,
	dlc0_repair_addr,
	dlc1_repair_addr,
	smu_done_addr,
	pcie_ep_link_addr,
	pcie_ep_err0_addr,
	pcie_ep_err1_addr,
	pcie_rc_link_addr,
	pcie_rc_err0_addr,
	pcie_rc_err1_addr,
	app_ver_addr,
	v2_ver_addr,
	ddr_mem_code_addr,
	ddr_mem_wrtest_addr,
	ddr_mem_max_addr,
	gpio_test_addr,
	csram_mem_reserved_3k,
	vatool_address_count // 地址数量
} AddressEnum;

#endif

