/*
 * vastai_common_pci_vf.h
 * This file includes the definitions used by both pcie driver and smcu fw
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/02/14
 * Author: xiangming.yang
 */

#ifndef __COMMON_PCIE_VF_H__
#define __COMMON_PCIE_VF_H__

/* VF Bar size */
#define VASTAI_PCIE_VF_BAR0_SIZE		(0x100000UL)	//1MB
#define VASTAI_PCIE_VF_BAR1_SIZE		(0x100000UL)	//1MB
#define VASTAI_PCIE_VF_BAR2_SIZE		(0x2000000UL)	//32MB
#define VASTAI_PCIE_VF_BAR4_SIZE		(0x2000000UL)	//32MB

#define VASTAI_PCIE_VF_BAR_RESERVED (0x00000000ULL)

/* VF ATU */
#define VASTAI_PCIE_VF_BAR0_AXI_ADDR (0x08B00000ULL)
#define VASTAI_PCIE_VF_BAR1_AXI_ADDR (0x08C00000ULL)
#define VASTAI_PCIE_VF_BAR2_AXI_ADDR (0x0814000000ULL)
#define VASTAI_PCIE_VF_BAR4_AXI_ADDR (0x00000000ULL)

#define MAX_SUPPORT_VF	(4)

#define HOST_GUEST_NOTIFY_INT 31

enum VASTAI_PCI_VF_BAR_ID {
	VASTAI_PCI_VF_BAR0 = 0,
	VASTAI_PCI_VF_BAR1 = 1,
	VASTAI_PCI_VF_BAR2 = 2,
	VASTAI_PCI_VF_BAR3 = 3,
	VASTAI_PCI_VF_BAR4 = 4,
	VASTAI_PCI_VF_BAR5 = 5,
	VASTAI_PCI_VF_BAR_NUM = 6,
};

enum VASTAI_PCI_FN_ID {
	VASTAI_PCI_PF_ID = 0,
	VASTAI_PCI_VF_ID_1 = 1,
	VASTAI_PCI_VF_ID_2 = 2,
	VASTAI_PCI_VF_ID_3 = 3,
	VASTAI_PCI_VF_ID_4 = 4,
};

enum VASTAI_BOOT_MODE {
	BOOT_PF_NORMAL,          // param from XSPI/FW boot_mode
	BOOT_PF_SRIOV,           // according to XSPI/FW boot_mode
	BOOT_VF_SRIOV,           // according to device id 0x101
	BOOT_MODE_MAX,
};

enum VASTAI_VF_STATUS {
	VF_DEACTIVATED = 0,
	VF_ACTIVATED = 1,
	VF_RUNNING = 2,
	VF_STATUS_INVALID,
};

typedef struct __attribute__((packed)) sriov_info_s {
	unsigned int magic;
	unsigned int boot_mode;
	union {
		unsigned int bdf;
		struct {
			unsigned int fn_id: 3;
			unsigned int dev_id: 5;
			unsigned int bus_id: 8;
		};
	} vf;

	unsigned int vf_status;
	unsigned int msix_addr_l[MAX_SUPPORT_VF];
	unsigned int msix_addr_h[MAX_SUPPORT_VF];
	unsigned int update_msix_ob_flag;
	/* other need to do */
} sriov_info_t;

#endif
