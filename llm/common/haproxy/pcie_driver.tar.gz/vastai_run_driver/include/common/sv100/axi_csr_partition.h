#ifndef _AXI_CSR_PARTITION_H_
#define _AXI_CSR_PARTITION_H_

#define VASTAI_AXI_CSR_BASE_ADDR	(0x08BC0000UL)

#define CMCU_GRP12_WR (96 * 4) // 0x180

#define CMCU_MSGQ_GRP0_AFULL_OFFSET  (110 * 4) // 0x1B8
#define CMCU_MSGQ_GRP0_AEMPTY_OFFSET (111 * 4) // 0x1BC
#define CMCU_MSGQ_GRP0_WR_OFFSET     (112 * 4) // 0x1C0
#define CMCU_MSGQ_GRP0_RD_OFFSET     (113 * 4) // 0x1C4

/*
 * CMCU_MSGQ_GRP0_INT_OFFSET
 * bit0:full_msk
 * bit1:afull_msk
 * bit2:empty_msk
 * bit3:nempty_msk
 * bit4:aempty_msk
 * bit5~7:reserved
 * bit8:full_int
 * bit9:afull_int
 * bit10:empty_int
 * bit11:nempty_int
 * bit12:aempty_int
 */
#define CMCU_MSGQ_GRP0_INT_OFFSET    (114 * 4) // 0x1C8
#define CMCU_MSGQ_GRP1_AFULL_OFFSET  (115 * 4) // 0x1CC
#define CMCU_MSGQ_GRP1_AEMPTY_OFFSET (116 * 4) // 0x1D0
#define CMCU_MSGQ_GRP1_WR_OFFSET     (117 * 4) // 0x1D4
#define CMCU_MSGQ_GRP1_RD_OFFSET     (118 * 4) // 0x1D8

/*
 * CMCU_MSGQ_GRP1_INT_OFFSET
 * bit0:full_msk
 * bit1:afull_msk
 * bit2:empty_msk
 * bit3:nempty_msk
 * bit4:aempty_msk
 * bit5~7:reserved
 * bit8:full_int
 * bit9:afull_int
 * bit10:empty_int
 * bit11:nempty_int
 * bit12:aempty_int
 */
#define CMCU_MSGQ_GRP1_INT_OFFSET (119 * 4) // 0x1DC
#define VDSP0_GRP5_WR		  (398 * 4) // 0x638
#define VDSP1_GRP5_WR		  (400 * 4) // 0x640
#define VDSP2_GRP5_WR		  (402 * 4) // 0x648
#define VDSP3_GRP5_WR		  (404 * 4) // 0x650
#define VDMCU0_GRP5_WR		  (414 * 4) // 0x678
#define VDMCU1_GRP4_WR		  (394 * 4) // 0x628
#define VDMCU2_GRP5_WR		  (418 * 4) // 0x688


/* AXI CSR */
#define VASTAI_SV_HOST_BOOT_STAGE_REG (VASTAI_AXI_CSR_BASE_ADDR + 0x6E0)
#define VASTAI_SV_SMCU_BOOT_STAGE_REG (VASTAI_AXI_CSR_BASE_ADDR + 0x6E4)
#define VASTAI_MCU_DSP_STATUS_REG  (VASTAI_AXI_CSR_BASE_ADDR + 0x6E8)

#define CMCU_GRP12_WR_REG (VASTAI_AXI_CSR_BASE_ADDR + CMCU_GRP12_WR)
#define CMCU_MSGQ_GRP0_AFULL_REG                                               \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP0_AFULL_OFFSET)
#define CMCU_MSGQ_GRP0_AEMPTY_REG                                              \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP0_AEMPTY_OFFSET)
#define CMCU_MSGQ_GRP0_WR_REG                                                  \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP0_WR_OFFSET)
#define CMCU_MSGQ_GRP0_RD_REG                                                  \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP0_RD_OFFSET)
#define CMCU_MSGQ_GRP0_INT_REG                                                 \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP0_INT_OFFSET)
#define CMCU_MSGQ_GRP1_AFULL_REG                                               \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP1_AFULL_OFFSET)
#define CMCU_MSGQ_GRP1_AEMPTY_REG                                              \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP1_AEMPTY_OFFSET)
#define CMCU_MSGQ_GRP1_WR_REG                                                  \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP1_WR_OFFSET)
#define CMCU_MSGQ_GRP1_RD_REG                                                  \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP1_RD_OFFSET)
#define CMCU_MSGQ_GRP1_INT_REG                                                 \
	(VASTAI_AXI_CSR_BASE_ADDR + CMCU_MSGQ_GRP1_INT_OFFSET)
#define VDSP0_GRP5_WR_REG  (VASTAI_AXI_CSR_BASE_ADDR + VDSP0_GRP5_WR)
#define VDSP1_GRP5_WR_REG  (VASTAI_AXI_CSR_BASE_ADDR + VDSP1_GRP5_WR)
#define VDSP2_GRP5_WR_REG  (VASTAI_AXI_CSR_BASE_ADDR + VDSP2_GRP5_WR)
#define VDSP3_GRP5_WR_REG  (VASTAI_AXI_CSR_BASE_ADDR + VDSP3_GRP5_WR)
#define VDMCU0_GRP5_WR_REG (VASTAI_AXI_CSR_BASE_ADDR + VDMCU0_GRP5_WR)
#define VDMCU1_GRP4_WR_REG (VASTAI_AXI_CSR_BASE_ADDR + VDMCU1_GRP4_WR)
#define VDMCU2_GRP5_WR_REG (VASTAI_AXI_CSR_BASE_ADDR + VDMCU2_GRP5_WR)

#define DEFAULT_CARD_TYPE (VASTAI_AXI_CSR_BASE_ADDR + 0x744)
#define DEFAULT_LOG_LEVEL (VASTAI_AXI_CSR_BASE_ADDR + 0x74C)

#endif /* _AXI_CSR_PARTITION_H_ */
