/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/02/02
 * Author: vincent.huang
 */

#ifndef __VASTAI_COMMON_PCI_API_H__
#define __VASTAI_COMMON_PCI_API_H__

/*
 * VASTAI_HOST_BOOT_STAGE_REG, 0x6E0
 * bit[31:30]: current die id.
 * 	       2'h0:die0, 2'h1:die1, 2'h2:die2, 2'h3:die3
 * bit[26:24]: host boot stage.
 *             3'h0: initial state
 *             3'h1: bl1 download finish
 *             3'h2: fw download finish
 *             3'h3: all dies download finish, host ready
 */
#define VASTAI_HOST_BOOT_STAGE_INIT	      (0)
#define VASTAI_HOST_BOOT_STAGE_BL1_DONE	      (1)
#define VASTAI_HOST_BOOT_STAGE_FW_DONE	      (2)
#define VASTAI_HOST_BOOT_STAGE_READY	      (3)            /*SV100*/
#define VASTAI_HOST_BOOT_STAGE_RCV_FW_BOOT_UP_ACK       (3)  /*SG100*/
#define VASTAI_HOST_BOOT_STAGE_SET_BAR_PHASE1 (4)            /*SV100*/
#define VASTAI_HOST_BOOT_STAGE_RCV_PCIE_INIT_READY_ACK  (4)  /*SG100*/
#define VASTAI_HOST_BOOT_STAGE_STATUS_NORMAL  (5)
#define VASTAI_HOST_BOOT_STAGE_SET_BAR_PHASE3 (6)            /*SV100*/
#define VASTAI_HOST_BOOT_STAGE_READY_SG       (6)            /*SG100*/



enum VASTAI_PCIE_SUBCMD {
	VASTAI_PCIE_SUB_RESET, /* send msg_irq to triger dev reset */
	VASTAI_PCIE_SUB_HANG_SMCU, /* hang smcu timer of feed wdg for test heartbeat*/
	VASTAI_PCIE_SUB_HANG_SMCU_THREAD, /* hang smcu thread for test heartbeat*/
	VASTAI_PCIE_SUB_OPEN_DMA_CALLBACK, /* open smcu dma callback function */
	VASTAI_PCIE_SUB_CLOSE_DMA_CALLBACK, /* close smcu dma callback function */
	VASTAI_PCIE_SUB_FLASH_XSPI, /* send msg_irq to flash xspi */
	VASTAI_PCIE_SUB_READ_XSPI, /* send msg_irq to read xspi */
	VASTAI_PCIE_SUB_SET_BAR, /* set bar address translation */
	VASTAI_PCIE_SUB_CEDAR_SYM_ALG, /* cedar synchronization test */
	VASTAI_PCIE_SUB_CEDAR_ASYM_ALG, /* cedar asynchronization test */
	VASTAI_PCIE_SUB_POWERON, /* power on video module */
	VASTAI_PCIE_SUB_CEDAR_SVC, /* cedar svc */
	VASTAI_PCIE_SUB_BMCU_UPGRADE, /* upgrade BMCU */
	VASTAI_PCIE_SUB_BMCU_DEGRADE, /* degrade BMCU */
	VASTAI_PCIE_SUB_FLASH_BMCU, /* flash BMCU by PCIE port */
	VASTAI_PCIE_SUB_POWEROFF, /* power off video module */
	VASTAI_PCIE_SUB_MSI_TEST, /* a test command */
	VASTAI_PCIE_SUB_DMI_FLASH, /* flash dmi info */
	VASTAI_PCIE_SUB_TIME_SYNC, /* timer sync */
	VASTAI_PCIE_SUB_AI_SYS_RESET, /* reset ai system by PCIE cmd */
	VASTAI_PCIE_SUB_CORE_RESET, /* reset core cmd */
	VASTAI_PCIE_SUB_TRI_EXP_TEST, /* trigger exception test */
	VASTAI_PCIE_SUB_SET_MACHINE_STATE, /* set smcu machine_state */
	VASTAI_PCIE_SUB_REQUEST_BMCU_POWEROFF, /* request bmcu to power off soc */
	VASTAI_PCIE_SUB_FLASH_BASE_XSPI, /* send msg_irq to flash base full xspi */
	VASTAI_PCIE_SUB_READ_BASE_XSPI, /* send msg_irq to read base full xspi */
	VASTAI_PCIE_SUB_FLAG_BASE_XSPI, /* send msg_irq to update base full xspi flag */
	VASTAI_PCIE_SUB_FLAG_XSPI, /* send msg_irq to update xspi flag */
	VASTAI_PCIE_SUB_FLASH_WPEN, /* send msg_irq to enable flash write protect */
	VASTAI_PCIE_SUB_FLASH_WPDIS, /* send msg_irq to disable flash write protect */
	VASTAI_PCIE_SUB_SET_BBOX, /* host set bbox */
	VASTAI_PCIE_SUB_ENABLE_HB, /*enable heartbeat check*/
	VASTAI_PCIE_SUB_DISABLE_HB, /*disable heartbeat check*/
	VASTAI_PCIE_SUB_GET_DLC_CORE, /* send msg_irq to get dlc cores info */
	VASTAI_PCIE_SUB_ACTIVATE_VF, /* activate VF */
	VASTAI_PCIE_SUB_DEACTIVATE_VF, /* deactivate VF */
	VASTAI_PCIE_SUB_CONFIG_VF_MSIX_ATU, /* config die0 ep ob region for vf msix */
	VASTAI_PCIE_SUB_BAR2_ATU, /* set bar2 ATU */
	VASTAI_PCIE_SUB_BAR4_ATU, /* set bar4 ATU */
	VASTAI_PCIE_SUB_GET_MAX_SMI_CNT,
	VASTAI_PCIE_SUB_SET_DDR_BW_TEST,
	VASTAI_PCIE_SUB_SET_PCIE_BW_TEST,
        VASTAI_PCIE_SUB_RESUME_BW_TEST,
	VASTAI_PCIE_SUB_STOP_BW_TEST,
	VASTAI_PCIE_SUB_SEND_DMA_ADDR,
	VASTAI_PCIE_SUB_DPM_EVENT,
	VASTAI_PCIE_SUB_SET_DMA_AGGREGATION,
	VASTAI_PCIE_SUB_RAS,
	VASTAI_PCIE_SUB_D2D_LINK_ACK,
	VASTAI_PCIE_SUB_SET_CEDAR_DMA,
	VASTAI_PCIE_SUB_GET_LOG_LEVEL,
	VASTAI_PCIE_SUB_SET_LOG_LEVEL,
	VASTAI_PCIE_SUB_READ_ADDR,
	VASTAI_PCIE_SUB_WRITE_ADDR,
	VASTAI_PCIE_SUB_PEER_DIE_DN,
};

enum VASTAI_PCIE_MSG1_TYPE {
	VASTAI_PCIE_MSG1_LOG_READ,
	VASTAI_PCIE_MSG1_ECC_2BIT_ERR,
	VASTAI_PCIE_MSG1_SET_BAR_DONE,
	VASTAI_PCIE_MSG1_ECC_1BIT_ERR,
	VASTAI_PCIE_MSG1_ECC_2BIT_FROM_FLASH,
	VASTAI_PCIE_MSG1_FREQ_REDUCE_BY_TEMP,
	VASTAI_PCIE_MSG1_FREQ_REDUCE_BY_VOLT,
	VASTAI_PCIE_MSG1_PCIE_ERR,
	VASTAI_PCIE_MSG1_RW_XSPI,
	VASTAI_PCIE_MSG1_CTRL_COMPLETION,
	VASTAI_PCIE_MSG1_DMA_LIST_BROKEN,
	VASTAI_PCIE_MSG1_POWER_DOWN_BY_BMCU,
	VASTAI_PCIE_MSG1_BMCU_XSPI_FINISH,
	VASTAI_PCIE_MSG1_SMI_ACK,
	VASTAI_PCIE_MSG1_CORE_TIME_SYNC_ACK,
	VASTAI_PCIE_MSG1_EXCEPTION,
	VASTAI_PCIE_MSG1_CORE_EXCEPTION,
	VASTAI_PCIE_MSG1_CORE_RESET_ACK,
	VASTAI_PCIE_MSG1_SYNC_BBOX, /* ep sync bbox status*/
	VASTAI_PCIE_MSG1_VE1_FAN_WARN,
	VASTAI_PCIE_MSG1_VIDEO_EXCEPTION,
	VASTAI_PCIE_MSG1_GET_DLC_CORE_DONE,
	VASTAI_PCIE_MSG1_ACTIVATE_VF,
	VASTAI_PCIE_MSG1_DEACTIVATE_VF,
	VASTAI_PCIE_MSG1_MAX_SMI_H,
	VASTAI_PCIE_MSG1_MAX_SMI_L,
	VASTAI_PCIE_MSG1_DPM_EVENT,
	VASTAI_PCIE_MSG1_BMCU_NEW_PATH_CONFIRM,
	VASTAI_PCIE_MSG1_TRANSCODING_TYPE,
	VASTAI_PCIE_SW_ATU_DONE,
	VASTAI_PCIE_MSG1_DL_WITH_SERVICE,
	VASTAI_PCIE_MSG1_GET_HARV_ERRCODE,
	VASTAI_PCIE_MSG1_RAS_ERR,
	VASTAI_PCIE_MSG1_D2D_LINK,
	VASTAI_PCIE_MSG1_STOP_BW_DONE,
	VASTAI_PCIE_MSG1_READ_ADDR_H,
	VASTAI_PCIE_MSG1_READ_ADDR_L,
	VASTAI_PCIE_MSG1_PEER_DIE_DN_ACK,
};

enum VASTAI_TRANSFER_TYPE {
	/* type: 0: ai normal DMA transfer (initiated by Host) */
	VASTAI_AI_NML = 0,
	/* type: 1: ai normal DMA transfer (initiated by Device) */
	VASTAI_AI_EXP = 1,
	/* type: 2: ai cmd */
	VASTAI_AI_CMD = 2,
	VASTAI_SMI = 3,
	VASTAI_PCIE = 4,
	VASTAI_PCIE_CTRL_QUEUE = 5,
	VASTAI_SMCU_CMD = 6,
	VASTAI_DMA_CMD = 7,
	VASTAI_PEER_CMD = 8,
	VASTAI_MSGQ_CTRL = 9,
	/* type: 32: video normal */
	VASTAI_VD_NML = 32,
	/* type: 33: video message */
	VASTAI_VD_MSG = 33,
};

enum VASTAI_XSPI_ERR_TYPE
{
	VASTAI_XSPI_SUCCESS,
	VASTAI_XSPI_ERASE_ERR,
	VASTAI_XSPI_READ_ERR,
	VASTAI_XSPI_WRITE_ERR,
	VASTAI_XSPI_UNLOCK_ERR,
	VASTAI_XSPI_LOCK_ERR,
	VASTAI_XSPI_BIN_CHKSUM_ERR,
	VASTAI_XSPI_FALG_ERR,
	VASTAI_XSPI_SET_WP_ERR,
	VASTAI_XSPI_TYPE_ERR,
};

enum VASTAI_SMCU_SUBCMD {
	VASTAI_SMCU_SUB_SET_AVFS,
	VASTAI_SMCU_SUB_NEW_BMCU_PATH,
	VASTAI_SMCU_SUB_QUERY_TC_TYPE,
	VASTAI_SMCU_SUB_DL_WITH_SERVICE_ACK
};

enum VASTAI_PCI_BAR {
	VASTAI_PCI_BAR0,
	VASTAI_PCI_BAR1,
	VASTAI_PCI_BAR2,
	VASTAI_PCI_BAR3,
	VASTAI_PCI_BAR4,
	VASTAI_PCI_BAR5,
	VASTAI_PCI_ROMBAR,
	VASTAI_PCI_BAR_NUM
};

enum VASTAI_CORE_TYPE {
	SMCU_TYPE = 0,
	CMCU_TYPE,
	LMCU_TYPE,
	ODSP_TYPE,
	VDMCU_TYPE,
	VEMCU_TYPE,
	VDSP_TYPE
};


struct smcu_to_host_msg1 {
	union {
		u32 val;
		struct {
			u8 type;
			u8 info[3];
		};
	};
};

enum enum_core_2_core_clr_dma_err_subcmd {
	CORE_2_CORE_CLR_DMA_ITR_REQ_SUBCMD = 0,
	CORE_2_CORE_CLR_DMA_ITR_RESP_SUBCMD,
};

enum enum_core_2_core_cmd {
	VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD = 1, // vatools command req
	CORE_2_CORE_RESET_CMD,
        EM_SMCU_CMD_DLC_Idle2Run =3,
	EM_SMCU_CMD_DLC_Idle2RunDone,
	EM_SMCU_CMD_VID_Idle2Run =5,
	EM_SMCU_CMD_Utilization =6,
	CORE_2_CORE_EXCEPTION_CMD,
	EM_SMCU_CMD_Cedar,
	VATOOLS_INTER_CORE_CMD_TIMESYNC_REQ = 9, // vatools timesync req
	EM_SMCU_CMD_RAS_CORE_TEST,
	EM_SMCU_CMD_RAS_CORE_EXCEPTION,
	EM_SMCU_CMD_SET_CORE_LOGLEVEL,
	CORE_2_CORE_CLR_DMA_ERR_ITR_ERR,
};

enum enum_core_2_core_reset_subcmd {
	CORE_2_CORE_RESET_AI_SYS_HANG_SUBCMD = 0,
	CORE_2_CORE_RESET_AI_ACK_SUBCMD,
	CORE_2_CORE_RESET_AI_RESET_SUBCMD,
	CORE_2_CORE_RESET_AI_FINISH_SUBCMD,
	CORE_2_CORE_RESET_CORE_SYS_HANG_SUBCMD,
	CORE_2_CORE_RESET_VDSP_HANG_SUBCMD,
	CORE_2_CORE_RESET_VDSP_RESET_SUBCMD,
	CORE_2_CORE_RESET_VDSP_ACK_SUBCMD,
	CORE_2_CORE_RESET_VDSP_FINISH_SUBCMD,
	CORE_2_CORE_RESET_AI_FINISH_ACK_SUBCMD,
	CORE_2_CORE_RESET_VDSP_FINISH_ACK_SUBCMD,
	CORE_2_CORE_UTILELATION_SUBCMD_ModifyWindow,
	CORE_2_CORE_UTILELATION_SUBCMD_ModifyWindowAck,
	CORE_2_CORE_CEDAR_SUBCMD_switch,
	CORE_2_CORE_CEDAR_SUBCMD_switchAck,
	VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD_ACK=15, // vatools command ack
	VATOOLS_INTER_CORE_CMD_TIMESYNC_ACK=16,	  // vatools timesync ack
};

enum VASTAI_PCIE_TRANSCODING_TYPE {
	VASTAI_PCIE_NONE_TRANSCODING,
	VASTAI_PCIE_TRANSCODING,
	VASTAI_PCIE_UNKNOW
};

#define		CORE_TOTAL_NUM				(29)

#pragma pack(1)
struct pcie_transfer_info {
	/* refer to VASTAI_TRANSFER_TYPE
	 * type: 0:ai model; 1:video
	 */
	u32 type : 8;
	/* dir: refer to VASTAI_TRANSFER_DIR, the direction of data transfer is
	 * defined based on the host side.
	 * 0: host write to device, or device read from host.
	 * 1: host read from device, or device write to host.
	 */
	u32 dir : 1;
	u32 is_vf : 1;
	u32 chn_sel : 1;
	u32 failed : 1;
	u32 padding_rsvd : 4;
	/* transfer number */
	u32 num : 8;
	u32 is_rc : 8;
	/* channel id, refer to VASTAI_TX_CHN_ID and VASTAI_RX_CHN_ID */
	u32 chn;
	/* data_type: 0:normal process, 1:only copy */
	u32 pcie_config_addr;
	union {
		struct {
			u32 data_l;
			u32 data_h;
		} __attribute__((packed)) data;
		u64 data_struct_addr;
		struct data_struct *data_struct;
	};
	u32 vdmcu_dma_msg_dst;
	u32 vdmcu_dma_msg_len;

	u32 time_of_dma_run;
	u32 time_of_dma_finish;
#if 0
	struct {
		/* For not completing the completion, as data_struct expired */
		u8 data_expired;
		/* For dma desc error status report */
		u8 err_sts;
		u8 pads[2];
	} dma_exception;
#endif
};

struct msgq_header {
	u8 type;
	u8 overflow;
	u8 paddings[2];
};
#pragma pack()

struct vastai_fifo {
	u32 rd;
	u32 wr;
	u32 elem_count;
	u32 elem_size;
#ifndef _WIN32
	u8 buf[0]; /* this will not be used at host driver */
#endif
};

struct vastai_outbound {
	u32 hb_cnt;
	u32 log_info;
	u32 log_infoword1;
	u32 log_wp;
	u32 log_rp;
	u32 d2d_link_enable;
	u32 dpm_enable;
};

struct sv100_system_cfg {
	u8 pkg_id;
	u8 pkg_num;
	u8 die_id;
	u8 die_num_in_fn;
	u8 mb_sn[16];  /*master board sn*/
	u8 pkg_sn[16];
	struct {
		u32 is_super_pf     :  1;
		u32 padding_rsvd    : 23;
		u32 die_num_in_card :  8;
	}__attribute__((packed)) bitmap;
};


struct core_info_entry {
	u8 core_name[8];
	u64 pop_fifo_addr[2];
	u64 push_fifo_addr[2];
	u64 interrupt_addr; /* for push fifo */
	u32 is_use_ring_buf; /* for push fifo */
	u16 die_irq[2];
	u16 core_type; /*for vdsp as odsp or odsp as vdsp*/
};

struct vastai_udma_config {
	u64 trans_info_fifo_addr;
	u64 dma_desc_fifo_addr;
};

#define VASTAI_DMA_CHN 4

#define VASTAI_DMA_TRANS_INFO_FIFO_SIZE (0x21C)
#define VASTAI_DMA_TRANS_INFO_VF_OFFSET (VASTAI_DMA_TRANS_INFO_FIFO_SIZE / 4)

#define VASTAI_DMA_DESC_FIFO_SIZE (0x1C20)
#define VASTAI_DMA_DESC_VF_OFFSET (VASTAI_DMA_DESC_FIFO_SIZE / 4)

struct sv100_hw_cfg {
	struct sv100_system_cfg sys_cfg;
	struct core_info_entry  core_cfg[CORE_TOTAL_NUM];
	struct vastai_udma_config udma_config[VASTAI_DMA_CHN];
};



#define VASTAI_BMCU_BL0_NEW_PATH_IDENTIFY 0xfe

#define VASTAI_SMCU_LOACL_SHARE_OFFSET (0x1100000U)
#define VASTAI_BMCU_NEW_SIZE_ADDR     (0x810000000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET)
#define VASTAI_BMCU_NEW_PATH_ADDR     (0x810080000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET) //128k: 0x8_1008_0000 ~ 0x8_100A_0000
#define VASTAI_BL0_NEW_SIZE_ADDR      (0x810012000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET)
#define VASTAI_BL0_NEW_PATH_ADDR      (0x810013000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET) //200k: 0x8_1001_3000 ~ 0x8_1004_5000
#define VASTAI_BL0_READ_SIZE_ADDR     (0x810045000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET)
#define VASTAI_BL0_READ_BASE_ADDR     (0x810046000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET) //200k: 0x8_1004_6000 ~ 0x8_1007_8000
#define VASTAI_MB_INVENTORY_ADDR      (0x810078000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET) //4k: 0x8_1007_8000 ~ 0x8_1007_9000
#define VASTAI_PKG_INVENTORY_ADDR     (0x810079000ULL + VASTAI_SMCU_LOACL_SHARE_OFFSET) //4k: 0x8_1007_9000 ~ 0x8_1007_a000

#define DSP_HEAP_SIZE (192*1024*1024)

#define VASTAI_OB_HB_SIZE  (4*1024)
#define VASTAI_OB_LOG_SIZE (4*1024*1024)

#define VASTAI_DL_WITH_SERVICE_IDENTIFY 0xf3

enum enum_dl_with_service {
	SUPPORT_BMCU,
	SUPPORT_BL0,
	SUPPORT_PMCU
};



#endif /* end of __VASTAI_COMMON_PCI_API_H__ */
