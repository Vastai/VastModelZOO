/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_UDMA_TEST_H__
#define __VASTAI_UDMA_TEST_H__

#include "vastai_pci.h"

#define VASTAI_UDMA_TEST_LEN (0x400)
#define VASTAI_UDMA_TEST_VAL (0x12)

#define VASTAI_CSRAM_DESCRIPTOR_OFFSET (0x80000)

int vastai_udma_start_bulk_transfer(struct vastai_pci_info *priv, u8 die_id,
				    uint32_t obDirection, uint32_t len,
				    uintptr_t localAddr, uintptr_t remoteAddr);
void vastai_udma_trigger(struct vastai_pci_info *priv, unsigned int die_index,
			 unsigned int dma_chn, unsigned int is_host_to_dev,
			 u64 *desc_tab, int num);
u64 vastai_udma_push_desc(struct vastai_pci_info *priv, unsigned int die_index,
			  unsigned int dma_chn, u64 sys_addr, u64 ext_addr,
			  u32 length, u8 ctr_byte);
int vastai_udma_polling_done(struct vastai_pci_info *priv,
			     unsigned int die_index, unsigned int dma_chn,
			     u64 *desc_tab, int num);

enum VASTAI_DMA_MODE {
	VASTAI_DMA_MODE_BULK,
	VASTAI_DMA_MODE_SCATTER,
	VASTAI_DMA_MODE_GATHER,
};

u8 vastai_udma_ctr_byte(int i, int sum, enum VASTAI_DMA_MODE mode);

#endif /* end of __VASTAI_UDMA_TEST_H__ */
