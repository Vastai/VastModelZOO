/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/07/19
 * Author: vincent.huang
 */

#ifndef __VASTAI_DOWNLOAD_FW_H__
#define __VASTAI_DOWNLOAD_FW_H__
#include "vastai_trans_layer.h"

int vastai_process_download_request(struct vastai_pci_info *pci_info,
						u8 die_id, u8 *path_name, const u8 *data,
						size_t size, u64 fw_addr);
int vastai_download_fw_packets(struct vastai_pci_info *priv, u8 die_id);
void vastai_global_download_init(struct vastai_addr_info *vastai_global_addr_info);
u64 vastai_get_bl0_read_base_addr(struct vastai_pci_info *priv);
u64 vastai_get_bl0_read_size_addr(struct vastai_pci_info *priv);
u64 vastai_get_bl0_download_addr(struct vastai_pci_info *priv);






#endif
