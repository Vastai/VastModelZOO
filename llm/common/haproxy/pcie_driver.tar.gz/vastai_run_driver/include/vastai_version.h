/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2021/07/20
 * Author: adan.xue
 */

#ifndef __VASTAI_VERSION_H__
#define __VASTAI_VERSION_H__

/* Rules for defining version numbers:
 * major_ver . minor_ver . revision_ver . compiled_ver
 * version numbers will be modified automatically by script mk_package.sh,
 * when run mk_package.sh to make rpm/deb package
 */
#define VASTAI_PCI_DRIVER_VERSION ("00.25.07.01")
#define VASTAI_PCI_DRIVER_COPYRIGHT                                            \
	("Copyright (C) 2024 Vastai Technologies All Rights Reserved.")

#define VASTAI_PCI_GIT_BRANCH_NAME ("d3_3_v2_7_a3_0")
#define VASTAI_PCI_GIT_COMMIT_HASH ("eb7878c")
#define VASTAI_PCI_GIT_COMMIT_MSG  "unknown"
#define VASTAI_PCI_MKPACKAGE_TIME ("20250701")
#define VASTAI_PCI_COMMON_INCLUDE_COMMIT_HASH "9935d94"

/* Release Version: DriverVersion_VideoVersion_AIVersion_customerid_year_month */
#define VASTAI_VERSION "DriverV3.3.0_VideoV2.7.2_AIV3.0.0_01_25_06"

#endif
