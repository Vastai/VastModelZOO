#ifndef __VASTAI_AI_INFO_H__
#define __VASTAI_AI_INFO_H__
#include "vastai_pci.h"
#include "hw_config.h"
#include "sg100_pcie_resource.h"
#define AI_DECODER_SIZE_16M               0X1000000ULL
#define AI_MODULE_SIZE_16M                0X1000000ULL
#define PF_AI_DECODER_OFFSET              0x6000000ULL
#define PF_AI_MODULE_OFFSET               PF_AI_DECODER_OFFSET+AI_DECODER_SIZE_16M
#define PF_DYNAMIC_BUF_OFFSET             0x80000000ULL
#define PF_DDR_MMIO_SIZE                  0x80000000ULL
#define VF_DDR_MMIO_SIZE                  0x10000000ULL
#define VF_MANAGEMENT_SIZE_64M            0x4000000
#define META_FW_SIZE_32M                  0x2000000
#define ENC_AND_DEC_BUF_SIZE_16M          0x1000000
#define AI_MODLE_AND_OPCODE_SIZE_16M      0x1000000
#define SMMU_CD_TABLE_SIZE_1M             0x100000
#define BAR_RESERVED_SIZE_31M             0x1F00000
#define PF_USED_SIZE                      (VF_MANAGEMENT_SIZE_64M + \
                                          META_FW_SIZE_32M + \
                                          ENC_AND_DEC_BUF_SIZE_16M + \
                                          AI_MODLE_AND_OPCODE_SIZE_16M + \
                                          SMMU_CD_TABLE_SIZE_1M + \
                                          BAR_RESERVED_SIZE_31M)
#define VF_USED_SIZE                      (ENC_AND_DEC_BUF_SIZE_16M + \
                                          AI_MODLE_AND_OPCODE_SIZE_16M + \
                                          SMMU_CD_TABLE_SIZE_1M + \
                                          BAR_RESERVED_SIZE_31M)
#define DEV_DDR_SIZE_256MB                      0x10000000     /* 256MB */
#define DEV_DDR_SIZE_3G                         (0xC0000000ULL)
#define DEV_DDR_SIZE_6G                         (0x180000000ULL)
#define DEV_DDR_SIZE_12G                        (0x300000000ULL)
#define DEV_DDR_SIZE_24G                        (0x600000000ULL)
#define DEV_DDR_SIZE_48G                        (0xC00000000ULL)
#define LARGE_BAR_RUN_TIME_SIZE                 DEV_DDR_SIZE_6G

#define LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE      (DEV_DDR_SIZE_48G/4)
#define LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE      (DEV_DDR_SIZE_24G/4)
#define LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE      (DEV_DDR_SIZE_12G/4)           
#define LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE       (DEV_DDR_SIZE_6G/4)  
#define LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE       (DEV_DDR_SIZE_3G/4)

#define BAR_SIZE_2G                             (0x80000000ULL)
#define VF_AI_DECODER_OFFSET                    0
#define VF_AI_MODULE_OFFSET                     (VF_AI_DECODER_OFFSET+AI_DECODER_SIZE_16M)
#define VF_DYNAMIC_BUF_OFFSET                   0x10000000ULL
#define VA_DDR_BASE_ADDR                        0x1040000000ULL

#define LARGE_BAR_4GB_DDR_SIZE                  (0xF0000000ULL)
#define LARGE_BAR_4GB_DISP_HEAP_SIZE            0x0020000000 /* 512MB */
#define LARGE_BAR_4GB_GFX_HEAP_BAR_OFFSET       (LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE + PF_USED_SIZE)
#define LARGE_BAR_4GB_GFX_HEAP_DEV_OFFSET       (LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE)
#define LARGE_BAR_4GB_GFX_HEAP_SIZE             (LARGE_BAR_4GB_DDR_SIZE - LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE \
                                                - PF_USED_SIZE - LARGE_BAR_4GB_DISP_HEAP_SIZE)
#define LARGE_BAR_4GB_DISP_HEAP_BAR_OFFSET      (LARGE_BAR_4GB_DDR_SIZE - LARGE_BAR_4GB_DISP_HEAP_SIZE)
#define LARGE_BAR_4GB_DISP_HEAP_DEV_OFFSET      (LARGE_BAR_4GB_PER_PF_RUN_TIME_SIZE + LARGE_BAR_4GB_GFX_HEAP_SIZE)

#define LARGE_BAR_8GB_DDR_SIZE                  (0x01F0000000ULL)
#define LARGE_BAR_8GB_DISP_HEAP_SIZE            0x0080000000 /* 2GB */
#define LARGE_BAR_8GB_GFX_HEAP_BAR_OFFSET       (LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE + PF_USED_SIZE)
#define LARGE_BAR_8GB_GFX_HEAP_DEV_OFFSET       (LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE)
#define LARGE_BAR_8GB_GFX_HEAP_SIZE             (LARGE_BAR_8GB_DDR_SIZE - LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE \
                                                - PF_USED_SIZE - LARGE_BAR_8GB_DISP_HEAP_SIZE)
#define LARGE_BAR_8GB_DISP_HEAP_BAR_OFFSET      (LARGE_BAR_8GB_DDR_SIZE - LARGE_BAR_8GB_DISP_HEAP_SIZE)
#define LARGE_BAR_8GB_DISP_HEAP_DEV_OFFSET      (LARGE_BAR_8GB_PER_PF_RUN_TIME_SIZE + LARGE_BAR_8GB_GFX_HEAP_SIZE)

#define LARGE_BAR_16GB_DDR_SIZE                 (LARGE_BAR_DDR_PER_PF_16GB)
#define LARGE_BAR_16GB_DISP_HEAP_SIZE           0x0100000000 /* 4GB */
#define LARGE_BAR_16GB_GFX_HEAP_BAR_OFFSET      (LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE + PF_USED_SIZE)
#define LARGE_BAR_16GB_GFX_HEAP_DEV_OFFSET      (LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE)
#define LARGE_BAR_16GB_GFX_HEAP_SIZE            (LARGE_BAR_16GB_DDR_SIZE - LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE \
                                                - PF_USED_SIZE - LARGE_BAR_16GB_DISP_HEAP_SIZE)
#define LARGE_BAR_16GB_DISP_HEAP_BAR_OFFSET     (LARGE_BAR_16GB_DDR_SIZE - LARGE_BAR_16GB_DISP_HEAP_SIZE)
#define LARGE_BAR_16GB_DISP_HEAP_DEV_OFFSET     (LARGE_BAR_16GB_PER_PF_RUN_TIME_SIZE + LARGE_BAR_16GB_GFX_HEAP_SIZE)

#define LARGE_BAR_32GB_DDR_SIZE                 (LARGE_BAR_DDR_PER_PF_32GB)
#define LARGE_BAR_32GB_DISP_HEAP_SIZE           0x0200000000 /* 8GB */
#define LARGE_BAR_32GB_GFX_HEAP_BAR_OFFSET      (LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE + PF_USED_SIZE)
#define LARGE_BAR_32GB_GFX_HEAP_DEV_OFFSET      (LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE)
#define LARGE_BAR_32GB_GFX_HEAP_SIZE            (LARGE_BAR_32GB_DDR_SIZE - LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE \
                                                - PF_USED_SIZE - LARGE_BAR_32GB_DISP_HEAP_SIZE)
#define LARGE_BAR_32GB_DISP_HEAP_BAR_OFFSET     (LARGE_BAR_32GB_DDR_SIZE - LARGE_BAR_32GB_DISP_HEAP_SIZE)
#define LARGE_BAR_32GB_DISP_HEAP_DEV_OFFSET     (LARGE_BAR_32GB_PER_PF_RUN_TIME_SIZE + LARGE_BAR_32GB_GFX_HEAP_SIZE)

#define LARGE_BAR_64GB_DDR_SIZE                 (LARGE_BAR_DDR_PER_PF_64GB)
#define LARGE_BAR_64GB_DISP_HEAP_SIZE           0x0400000000 /* 16GB */
#define LARGE_BAR_64GB_GFX_HEAP_BAR_OFFSET      (LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE + PF_USED_SIZE)
#define LARGE_BAR_64GB_GFX_HEAP_DEV_OFFSET      (LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE)
#define LARGE_BAR_64GB_GFX_HEAP_SIZE            (LARGE_BAR_64GB_DDR_SIZE - LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE \
                                                - PF_USED_SIZE - LARGE_BAR_64GB_DISP_HEAP_SIZE)
#define LARGE_BAR_64GB_DISP_HEAP_BAR_OFFSET     (LARGE_BAR_64GB_DDR_SIZE - LARGE_BAR_64GB_DISP_HEAP_SIZE)
#define LARGE_BAR_64GB_DISP_HEAP_DEV_OFFSET     (LARGE_BAR_64GB_PER_PF_RUN_TIME_SIZE + LARGE_BAR_64GB_GFX_HEAP_SIZE)

              

struct ai_info
{
   //csram addr base and size
   u32 ai_csram_buf_base;
   u32 ai_csram_buf_size;

   //encoder decoder cmd buffer 16M
   u64 decoder_buf_fn_addr;
   u64 decoder_buf_host_phy_addr;
   u32 decoder_buf_size;

   //ai module/opcode 16M
   u64 ai_mod_buf_fn_addr;
   u64 ai_mod_buf_host_phy_addr;
   u32 ai_mod_buf_size;

   //ai dynamic allocate buf
   u64 ai_dyn_buf_fn_addr;
   u64 ai_dyn_buf_size;

   struct  dsp_cfg   vdsp_cfg;

   u64 ddr_total_sz;
   u64 fn_ddr_total_sz;

};

void init_ai_info(struct vastai_pci_info *priv);
void free_ai_info(struct vastai_pci_info *priv);

#endif
