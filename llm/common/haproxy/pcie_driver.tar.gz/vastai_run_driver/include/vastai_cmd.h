#ifndef __VASTAI_CMD__
#define __VASTAI_CMD__
#include "hw_queue.h"

#define GMCU_NUM(num)		GMCU##num


struct vastai_cmd_entry{
	struct ring_buf_info	*ring_buf_info;
	struct mutex			msgq_lock;
	uint32_t				cmd_element_size;
	struct hw_msgq			*hw_msgq;
};

struct ring_buf_info{
	spinlock_t				wr_ring_buf_lock;
	spinlock_t				rd_ring_buf_lock;
	uint32_t				ring_buf_base;
	uint32_t				ring_buf_size;
	uint32_t				vf_m2o_reg_base;
	uint32_t				ring_buf_fn_base;
};

int init_all_ring_buf(struct vastai_pci_info *priv);
int h2d_cmd_buf_deinit(struct vastai_pci_info *priv);
int smcu_to_host_msix_init(struct vastai_pci_info *priv);

void host_triger_m2o_int_mcu(struct vastai_pci_info *priv, int index);
struct vastai_cmd_entry *get_cmd_entry(struct vastai_pci_info *priv, int cmd_buf_type);
int vastai_send_cmd_to_mcu(struct vastai_pci_info *priv, struct pcie_transfer_cmd *cmd, struct vastai_cmd_entry *cmd_entry);
int dsu_to_host_msix_init(struct vastai_pci_info *priv);

#endif