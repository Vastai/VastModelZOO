/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_PCI_BOOT_H__
#define __VASTAI_PCI_BOOT_H__

#include "vastai_pci.h"

#define VASTAI_BOOT_RETRY_CNT_MAX   (3)
#define VASTAI_BOOT_WQ_DELAYED_MS   (0)
#define VASTAI_BOOT_POLL_SLEEP_MS   (1)
#define VASTAI_DIE_CONFIG_TABLE_NUM (7)

#define VASTAI_BOOT_POLL_SLEEP_CNT          (100000)  // 15000
#define VASTAI_BOOT_LOCK_POLL_SLEEP_CNT     (200000)  // 200s


enum vastai_hw_type {
	VASTAI_HW_TYPE_DEFAULT,
	VASTAI_HW_TYPE_VIDEO_ONLY,
	VASTAI_HW_TYPE_AI_ONLY,
	VASTAI_HW_TYPE_VIDEO_AI
};

enum vastai_env_type {
	VASTAI_SILICON,
	VASTAI_EMU,
};

union host_boot_stage {
	u32 val;
	struct {
		u32 smcu_rsvd : 20;
		u32 host_set_hw_type : 1;
		u32 hw_type : 3;
		u32 stage : 3;
		u32 cus_type : 2;
		u32 force_single_die : 1;
		u32 env_type : 2;
	} bit;
	struct {
		u32 smcu_rsvd           : 24;
		u32 stage               : 3;
		u32 host_rsvd           : 2;
		u32 force_single_die    : 1;
		u32 die_id              : 2;
	} sg_bit;
};

/*
 * VASTAI_SMCU_BOOT_STAGE_REG, 0x6E4
 * bit[31:29]: die config, refer to struct vastai_die_cfg table
 * bit[28]: current die ep and front die or host  rc link up flag
 * bit[27]: current die rc and next die ep link up flag
 * bit[26:24]: smcu boot stage.
 *             3'h0: initial state
 *             3'h1: wait for downloading bl1 (bootloader1)
 *             3'h2: bl1 verify pass
 *             3'h3: wait for downloading fw (firmware)
 *             3'h4: fw verify pass
 *             3'h5: current die pcie init finish
 *             3'h6: all mcu and dsp of current die init finish
 */
#define VASTAI_SMCU_BOOT_STAGE_INIT	 (0)
#define VASTAI_SMCU_BOOT_STAGE_BL1_READY (1)
#define VASTAI_SMCU_BOOT_STAGE_BL1_DONE	 (2)
#define VASTAI_SMCU_BOOT_STAGE_FW_READY	 (3)
#define VASTAI_SMCU_BOOT_STAGE_FW_DONE	 (4)
#define VASTAI_SMCU_BOOT_STAGE_DIE_DONE	 (5)  /*SV100*/
#define VASTAI_SMCU_BOOT_STAGE_FW_BOOT_UP (5) /*SG100*/
#define VASTAI_SMCU_BOOT_STAGE_BOOT_DONE (6)        /*SV100*/
#define VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY  (6) /*SG100*/
#define VASTAI_SMCU_BOOT_STAGE_WHILE_1	 (7)
#define VASTAI_SMCU_BOOT_STAGE_ALLCORE_READY (7)


#define VASTAI_SMCU_STAGE_END            (-1)


#define VASTAI_LOGSYS_CTRL_STARTADDR_PATH     0x8CF3290


union smcu_boot_stage {
	u32 val;
	struct {
		u32 smcu_rsvd : 21;
		u32 d2d_link_retry_cnt : 3;
		u32 stage : 3;
		u32 rc_link_sts : 1;
		u32 ep_link_sts : 1;
		u32 die_cfg : 3;
	} bit;
};

union link_control_status_reg {
	u32 val;
	struct {
		u32 unused0 : 16;
		u32 negotiated_link_speed : 4;
		u32 negotiated_link_width : 6;
		u32 unused1 : 6;
	} bit;
};

union link_control_cap_reg {
	u32 val;
	struct {
		u32 max_link_speed : 4;
		u32 max_link_width : 6;
		u32 unused1 : 22;
	} bit;
};

union mcu_dsp_status {
	u32 val;
	struct {
		u32 smcu_img : 1;
		u32 cmcu_img : 1;
		u32 lmcu0_img : 1;
		u32 lmcu1_img : 1;
		u32 lmcu2_img : 1;
		u32 lmcu3_img : 1;
		u32 lmcu4_img : 1;
		u32 lmcu5_img : 1;
		u32 lmcu6_img : 1;
		u32 lmcu7_img : 1;
		u32 odsp0_img : 1;
		u32 odsp1_img : 1;
		u32 odsp2_img : 1;
		u32 odsp3_img : 1;
		u32 odsp4_img : 1;
		u32 odsp5_img : 1;
		u32 odsp6_img : 1;
		u32 odsp7_img : 1;
		u32 vdmcu0_img : 1;
		u32 vdmcu1_img : 1;
		u32 vdmcu2_img : 1;
		u32 vemcu0_img : 1;
		u32 vemcu1_img : 1;
		u32 vemcu2_img : 1;
		u32 vemcu3_img : 1;
		u32 vdsp0_img : 1;
		u32 vdsp1_img : 1;
		u32 vdsp2_img : 1;
		u32 vdsp3_img : 1;
		u32 ddr_attr : 3;
	} bit;
};

struct vastai_die_cfg {
	u8 val;
	u8 die_num;
	u8 die_id;
	u8 pkg_id;
	u8 fn_id[8];
};

struct vastai_core_sync {
	u8 index;
	u8 str[8];
};

struct vastai_fw {
	const u8 *data;
	size_t size;
	u64 addr;
	const void *priv;
};

void vastai_pci_show_fw_ver(struct vastai_pci_info *priv, u32 mask);
int vastai_pci_flash_xspi(struct vastai_pci_info *priv, u32 die_id, char *path_name,
				const char *i_buf, size_t buf_size, u8 partition);

int vastai_pci_flash_xspi_bin(struct vastai_pci_info *priv, u32 die_id,
			      u8 *path_name, const void *bin_buf,
			      size_t buf_size, u8 is_base_partition);
int vastai_pci_flash_bmcu(struct vastai_pci_info *priv, u32 die_id);
int vastai_pci_flash_bmcu_bin(struct vastai_pci_info *priv, u32 die_id,
			      u8 *path_name, const void *bin_buf, size_t buf_size);
int vastai_pci_update_flag_xspi(struct vastai_pci_info *priv, u32 die_id,
				u8 partition);
int vastai_pci_set_flash_wp(struct vastai_pci_info *priv, u32 die_id,
			struct char_drv_info *dev, u32 cfg);
int vastai_pci_read_xspi(struct vastai_pci_info *priv, u32 die_id,
			 unsigned long addr, void *buf, u32 len,
			 u8 partition, bool origin_addr);
int vastai_pci_boot(struct vastai_pci_info *priv);
u8 vastai_pci_read_die_num(struct vastai_pci_info *priv, u8 die_id);
int vastai_pci_get_pf_num_per_card(struct vastai_pci_info *priv);
int vastai_send_pcie_cmd_spe(struct vastai_pci_info *priv, u32 die_index,
					u32 sub_cmd, u64 paras);
int vastai_send_smcu_cmd(struct vastai_pci_info *pci_info, int die_index,
				u32 sub_cmd, u64 paras);
void vastai_pci_deinit_smcu_log(struct vastai_pci_info *priv, u8 die_id);
int vastai_pci_new_bmcu_path_confirm(struct vastai_pci_info *priv);
int vastai_poll_stage_bl1_ready(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int vastai_poll_stage_fw_ready_sv(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int vastai_poll_stage_fw_ready_sg(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int vastai_poll_stage_die_done(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int vastai_poll_stage_boot_done(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int vastai_poll_stage_boot_up(struct vastai_pci_info *priv, u8 die_id, int *next_state);
int send_xspi_flash_cmd(struct vastai_pci_info *priv, u32 die_id,
				enum VASTAI_PCIE_SUBCMD cmd, u32 buf_size);
int send_xspi_flash_cmd_sg100(struct vastai_pci_info *priv, struct pcie_transfer_cmd *ptrans);
int vastai_pci_poll_smcu_stage(struct vastai_pci_info *priv, u8 die_id,
				      u32 smcu_bootstage);
int vastai_pci_set_host_stage(struct vastai_pci_info *priv, u8 die_id,
						u32 host_bootstage);
void vastai_polling_smcu_failed_proc(struct vastai_pci_info *priv, u8 die_id);
int vastai_get_system_hw_config(struct vastai_sv100_die *die);
int vastai_create_card_info_tree(struct vastai_pci_info *priv, struct vastai_card_info **card_info, struct sv100_system_cfg *sys_config);
struct vastai_pci_info *vastai_get_peer_priv(struct vastai_pci_info *priv, u8 *die_id_in_fn);




#endif /* end of __VASTAI_PCI_BOOT_H__ */
