/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_DMABUF_H__
#define __VASTAI_DMABUF_H__

#include "vastai_pci.h"
#define VASTAI_MEM_POOL_BUF_SIZE VASTAI_MAX_DMA_BUF
#define VASTAI_MEM_POOL_MIN_NR	 16
int vastai_udma_malloc(struct vastai_pci_info *pci_info,
		       struct vastai_dma_buf *dm, int size);
int vastai_udma_free(struct vastai_pci_info *pci_info,
		     struct vastai_dma_buf *dm);
int vastai_mempool_init(struct vastai_pci_info *pci_info);
void vastai_mempool_deinit(struct vastai_pci_info *pci_info);
struct vastai_dma_buf *vastai_mempool_get(struct vastai_pci_info *pci_info,
					  size_t size);
void vastai_mempool_put(struct vastai_pci_info *pci_info,
			struct vastai_dma_buf *dm);
int vastai_dmabuf_init(struct vastai_pci_info *pci_info);
void vastai_dmabuf_deinit(struct vastai_pci_info *pci_info);
int is_vastai_mempool_rich(struct vastai_pci_info *pci_info);
bool iommu_is_enable(struct vastai_pci_info *pci_info);
struct vastai_dma_buf *vastai_dma_buf_sg_get(
			struct vastai_pci_info *pci_info,
			size_t size);
void vastai_dma_buf_sg_put(
			struct vastai_pci_info *pci_info,
			struct vastai_dma_buf *dm);

void vastai_udma_sg_free(struct vastai_pci_info *pci_info,
				struct vastai_dma_buf *dm);
struct vastai_dma_buf *
vastai_dma_buf_create(struct vastai_pci_info *pci_info, size_t size,
		      gfp_t gfp_mask);
void vastai_dma_buf_destroy(struct vastai_dma_buf *dm);
struct vastai_dma_buf *vastai_mempool_ex_get(struct vastai_pci_info *pci_info,
					  size_t size);
void vastai_mempool_ex_put(struct vastai_pci_info *pci_info,
		  struct vastai_dma_buf *dm);
int vastai_dma_sg_start_get_host_addr(int i, struct dma_buf *dmabuf, u64 *host_addr, u64 *dev_addr, void *dma_node, u32 done_size);
int vastai_dma_sg_set_desc_start(struct vastai_dmadesc* desc,
					void *dma_node,
					u64 *dev_addr,
					u32 dma_len,
					u64 *host_addr);
int vastai_dma_start_get_host_addr(int i, struct dma_buf *dmabuf, u64 *host_addr, u64 *dev_addr, void *dma_node, u32 done_size);
int vastai_ioctl_dma_start_set_desc_new(struct vastai_dmadesc* desc, 
							void *dma_node,
							u64 *dev_addr, u32 temp_size,
							u64 *host_addr);
bool vastai_is_find_pci_info(struct vastai_pci_info *pci_info);





#endif
