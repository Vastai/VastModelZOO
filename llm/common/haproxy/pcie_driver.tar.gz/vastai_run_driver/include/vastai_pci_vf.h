/*
 * vastai_pci_vf
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/10/13
 * Author: xiangming.yang
 */

#ifndef __VASTAI_PCI_VF_H__
#define __VASTAI_PCI_VF_H__

#include "vastai_common_pci_vf.h"

struct vastai_pci_info;

/*
 0x08cfd800:  VF_INFO                (size 0x200)
 0x08cfda00:  VF_FIFO  (HOST -> VM)  (size 0x300)
 0x08cfdd00:  VF_FIFO  (VM -> HOST)  (size 0x300)
*/

#define VF_INFO_REGION_SIZE     (0x800)
#define VF_INFO_OFFSET			(0x000fd800UL)
#define VF_INFO_BASE            (0x08cfd800UL)
#define VF_INFO_MAX_SIZE        (0x200)
#define VF_INFO_MAP_BAR			(1)

#define VF_FIFO_OFFSET          (VF_INFO_OFFSET + VF_INFO_MAX_SIZE)
#define VF_FIFO_BASE            (VASTAI_PCIE_VF_BAR1_AXI_ADDR + VF_FIFO_OFFSET)
#define VF_FIFO_SIZE            ((VF_INFO_REGION_SIZE - VF_INFO_MAX_SIZE) / 2)

#define OS_MSG_SIZE             ()

struct vastai_os_msg {
	u32 type;
	u32 cmd;
	union {
		u32 msg_32[2];
		u8 msg_8[8];
	};
};

struct vf_fifo_info {
	u32 local_addr;
	u32 peer_addr;
	spinlock_t vf_msg_lock;
};

/* make sure vf_info occupies less than 512Bytes */
_Static_assert( (sizeof(sriov_info_t) <= VF_INFO_MAX_SIZE), "size of VF_INTO_T overflowed");

void vastai_proc_peer_msg(void *i_die);
void vastai_send_msg_to_peer_test(struct vastai_pci_info* priv, int die_id);
void vastai_pci_config_vf_bar_at(struct vastai_pci_info *priv, int bar);
void vastai_vf_timer_init(struct vastai_pci_info *pciv);
int vastai_pci_vf_init(struct vastai_pci_info *priv);
int vastai_pci_vf_activate(struct vastai_pci_info *pci_info, int num_vfs);
int vastai_pci_vf_deactivate(struct vastai_pci_info *pci_info);
void vastai_vf_os_fifo_init(struct vastai_sv100_die *die);
int vastai_get_die_boot_mode(struct vastai_sv100_die *die);

#endif

