/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_FIFO_H__
#define __VASTAI_FIFO_H__

#include "vastai_pci.h"

enum VASTAI_FIFO_TYPE {
	NORMAL_FIFO = 0,
	SPE_FIFO
};

static inline u8 vastai_fifo_is_full(struct vastai_fifo *fifo)
{
	return ((fifo->wr + 1) % (fifo->elem_count) == (fifo->rd));
}

static inline u8 vastai_fifo_is_empty(struct vastai_fifo *fifo)
{
	return ((fifo->wr) == (fifo->rd));
}

static inline u32 vastai_fifo_wr_pre_fetch(struct vastai_fifo *fifo)
{
	return ((u32)offsetof(struct vastai_fifo, buf) +
		fifo->elem_size * fifo->wr);
}

static inline u32 vastai_fifo_wr_get_front(struct vastai_fifo *fifo,
					   u64 fifo_addr)
{
	if (fifo->wr == 0)
		return fifo_addr + sizeof(*fifo)
			+ (fifo->elem_size * (fifo->elem_count - 1));
	else
		return fifo_addr + sizeof(*fifo)
			+ (fifo->elem_size * (fifo->wr - 1));
}

static inline u32 vastai_fifo_wr_next(struct vastai_fifo *fifo)
{
	u32 ret = (u32)offsetof(struct vastai_fifo, buf) +
		  fifo->elem_size * fifo->wr;
	fifo->wr = (fifo->wr + 1) % (fifo->elem_count);
	return ret;
}

static inline u32 vastai_fifo_rd_pre_fetch(struct vastai_fifo *fifo)
{
	return ((u32)offsetof(struct vastai_fifo, buf) +
		fifo->elem_size * fifo->rd);
}

static inline u32 vastai_fifo_rd_get_front(struct vastai_fifo *fifo,
					   u64 fifo_addr)
{
	if (fifo->rd == 0)
		return fifo_addr + sizeof(*fifo)
			+ (fifo->elem_size * (fifo->elem_count - 1));
	else
		return fifo_addr + sizeof(*fifo)
			+ (fifo->elem_size * (fifo->rd - 1));
}

static inline u32 vastai_fifo_rd_next(struct vastai_fifo *fifo)
{
	u32 ret = (u32)offsetof(struct vastai_fifo, buf) +
		  fifo->elem_size * fifo->rd;
	fifo->rd = (fifo->rd + 1) % (fifo->elem_count);
	return ret;
}

static inline void vastai_fifo_init_arg(struct vastai_fifo *fifo, u32 elem_size,
					u32 buf_size)
{
	fifo->elem_size = elem_size;
	fifo->elem_count =
		(buf_size - sizeof(struct vastai_fifo)) / (fifo->elem_size);
	fifo->rd = 0;
	fifo->wr = 0;
}

static inline int vastai_is_fifo_valid(struct vastai_fifo *fifo)
{
	return ((fifo->rd < fifo->elem_count) && (fifo->wr < fifo->elem_count));
}
static inline int vastai_fifo_is_break(struct vastai_fifo *fifo)
{
	return (fifo->rd == 0xffffffff || fifo->wr == 0xffffffff ||
		fifo->elem_count == 0xffffffff || fifo->elem_size == 0xffffffff ||
		fifo->elem_count == 0);
}

int vastai_fifo_push_elem(void *pci_info, int die_index, u64 fifo_addr,
			  void *elem, struct vastai_fifo *fifo);
int vastai_fifo_pop_elem(void *pci_info, int die_index, u64 fifo_addr,
			 void *elem, struct vastai_fifo *fifo, u8 fifo_type);
int vastai_fifo_push_elem_local_fifo(void *pci_info, int die_index, u64 elem_start_addr,
						struct vastai_fifo *fifo, void *elem);
int vastai_fifo_pop_elem_local_fifo(void *pci_info, int die_index, u64 elem_start_addr,
						struct vastai_fifo *fifo, void *elem);



#endif
