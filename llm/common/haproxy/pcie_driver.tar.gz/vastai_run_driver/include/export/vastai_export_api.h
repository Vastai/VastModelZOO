/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/06/06
 * Author: vincent.huang
 */

#ifndef __VASTAI_EXPORT_H__
#define __VASTAI_EXPORT_H__

#include "vastai_pci.h"
#include "vastai_export_def_ext.h"

board_type_e vastai_get_board_type(struct vastai_pci_info *priv);
int vastai_get_transcoding_type(struct vastai_pci_info *priv, u32 *type);
int vastai_read_heartbeat(struct vastai_pci_info *priv, u32 die_id,
			  u32 last_sec, u32 *hb_count);
int vastai_pci_numa_cpu_info(struct vastai_pci_info *pci_info,
			     char *numa_cpu_info_item, int len);
int vastai_pci_numa_cpu_info_all(char *buf, int len);
u32 vastai_get_vdsp_cnt(struct vastai_pci_info *priv, int die_id, u32 vdsp, int dir);
bool is_vastai_probe_done(struct vastai_pci_info *priv);
int is_support_download_fw_with_service(struct vastai_pci_info *priv, u16 *bitmap_dl_support);
u32 vastai_get_speed_cap(struct vastai_pci_info *priv);
u32 vastai_get_width_cap(struct vastai_pci_info *priv);
u32 vastai_get_speed_sta(struct vastai_pci_info *priv);
u32 vastai_get_width_sta(struct vastai_pci_info *priv);



#endif /* end of __VASTAI_EXPORT_H__ */
