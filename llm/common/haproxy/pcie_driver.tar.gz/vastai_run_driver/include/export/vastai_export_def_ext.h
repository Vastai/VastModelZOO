/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2023/06/06
 * Author: vincent.huang
 */

#ifndef __VASTAI_EXPORT_ENUM_DEFINE_H__
#define __VASTAI_EXPORT_ENUM_DEFINE_H__

#include "vastai_node_basic_dma.h"


typedef enum
{
	SV100,
	SG100,
	TYPE_UNKNOWN
} board_type_e;

#define VASTAI_PCI_IOCTL_ALLOC		 0
#define VASTAI_PCI_IOCTL_DMA_START	 1
#define VASTAI_PCI_IOCTL_DMA_TRANS	 3
#define VASTAI_PCI_IOCTL_DMA_TRANS_SG	 4
#define VASTAI_PCI_IOCTL_RESET_NOTIFY	 5
#define VASTAI_PCI_IOCTL_DMA_FILL	 0x106
#define VASTAI_PCI_IOCTL_MEMSET          7
#define VASTAI_PCI_IOCTL_P2P_START       8
#define VASTAI_PCI_IOCTL_DMA_CLOSE       0x108
#define VASTAI_PCI_IOCTL_DMA_D2D         0x109
#define VASTAI_PCI_IOCTL_GET_BAR         9
#define VASTAI_PCI_IOCTL_POLL_LOG	 0xa
#define VASTAI_PCI_IOCTL_RENDER		 0xB
#define VASTAI_PCI_IOCTL_PORT		 0xC
#define VASTAI_PCI_IOCTL_GET_PERFORMANCE 0xD
#define VASTAI_PCI_IOCTL_PCI_ID		 0XE
#define VASTAI_PCI_IOCTL_PCI_SUB_ID	 0XF
#define VASTAI_PCI_IOCTL_MAJOR_MINOR	 0X10
#define VASTAI_PCI_IOCTL_CEDAR_CMD	 0X20
#ifdef CONFIG_VASTAI_JENKINS_TEST
#define VASTAI_PCI_IOCTL_DMA_TEST	 0X30
#endif
#define VASTAI_PCI_IOCTL_BOARD_TYPE	 0X40
#define VASTAI_PCI_IOCTL_DIE2DIE_TEST	 0X50


#define VASTAI_PCI_IOCTL_DMA_D2D				0x109
#define VASTAI_PCI_IOCTL_DMA_TRANS_BY_VA		0x112
#define VASTAI_PCI_IOCTL_PCIE_DMA_TRANS			0x133
#define VASTAI_PCI_IOCTL_PCIE_DMA_RAW_TRANS		0x132
#define VASTAI_PCI_IOCTL_DMA_S2M				0x134
#define VASTAI_PCI_IOCTL_MMIO_WRITE				0x141
#define VASTAI_PCI_IOCTL_MMIO_READ				0x142

typedef enum
{
	RESET_NOTIFY_STOP,
	RESET_STOP_COMPLETION,
	RESET_AI_SYS_DONE
} reset_msg;

typedef enum cedar_svc_type {
	SHA2_224 = 0u,
	SHA2_224_UPDATE,
	SHA2_224_IMG_1080,
	SHA2_224_IMG_1088,
	SHA2_256,
	SHA2_256_UPDATE,
	SHA2_256_IMG_1080,
	SHA2_256_IMG_1088,
	SHA2_384,
	SHA2_384_UPDATE,
	SHA2_384_IMG_1080,
	SHA2_384_IMG_1088,
	SHA2_512,
	SHA2_512_UPDATE,
	SHA2_512_IMG_1080,
	SHA2_512_IMG_1088,
	SM3,
	SM3_UPDATE,
	SM3_IMG_1080,
	SM3_IMG_1088,
	SHA3_224,
	SHA3_224_UPDATE,
	SHA3_224_IMG_1080,
	SHA3_224_IMG_1088,
	AES_ECB_ENC,
	AES_ECB_DEC,
	AES_CBC_ENC,
	AES_CBC_DEC,
	AES_CTR_ENC,
	AES_CTR_DEC,
	AES_GCM_ENC,
	AES_GCM_DEC,
	SM4_ECB_ENC,
	SM4_ECB_DEC,
	SM4_CBC_ENC,
	SM4_CBC_DEC,
	SM4_CTR_ENC,
	SM4_CTR_DEC,
	SM4_GCM_ENC,
	SM4_GCM_DEC,
	DES_ECB_ENC,
	DES_ECB_DEC,
	DES_CBC_ENC,
	DES_CBC_DEC,
	ECC_ENC,
	ECC_DEC,
	ECC_SIGN,
	ECC_VERIFY,
	SM2_ENC,
	SM2_DEC,
	SM2_SIGN,
	SM2_VERIFY,
	RSA_ENC,
	RSA_DEC,
	RSA_SIGN,
	RSA_VERIFY,
	RNG,
} svc_t;

typedef struct __attribute__((packed)) vastai_cedar_img_info {
	u64 input_addr;
	u64 output_addr;
	svc_t alg_type;
	u32 blen;
	u64 key;
	u64 iv;
	u64 msg;
	u64 tag;
	u32 keyblen;
	u32 ivblen;
	u32 msgblen;
	u32 tblen;
	u64 random;
	u64 pubkey;
	u64 prikey;
	u64 sign;
	u32 pkaMode;
	u32 config;
	u32 width;
	u32 height;
	u32 rngmode;
	u32 symmode;// mask or normal mode
}vastai_cedar_img_info_t;


struct vastai_channel_buf {
	u64 user_buf;
	u32 width;
	u32 high;
	u32 src_width_offset;
	u32 src_high_offset;
	u32 dst_width_offset;
	u32 dst_high_offset;
}__attribute__((packed));

struct kchar_cmd {
	union {
		struct {
			u32 size;
			int dma_buf_fd;
			u64 dma_addr_t;
		}__attribute__((packed)) alloc_cmd;

		dma_node_start_cmd_t dma_start_cmd;
		dma_node_trans_cmd_t dma_trans_cmd;
		struct {
			u32 is_dev_to_host;
			u64 axi_addr;
			u32 length;
			u32 die_index;
			char val;
		}__attribute__((packed)) dma_memset_cmd;
		struct {
			int fd;
			char val;
			int size;
		}__attribute__((packed)) dma_memset_cmd_sg;
		struct {
			u32 is_dev_to_host;
			u32 die_index;
			u64 axi_addr;
			u64 channel_buf;
			int channel_num;
			int pid;
		}__attribute__((packed)) dma_trans_sg_cmd;
		struct {
			u32 die_index;
			u32 timeout_water;
			u32 is_timeout;
			void *log_ring_ctl;
		}__attribute__((packed)) log_poll_cmd;
		char port_name[16];
		struct {
			u32 die_index;
			char file_name[16];
		}__attribute__((packed)) get_render_name;
		struct {
			u32 die_index;
			u32 pcie_tx_vdsp_count[4];
			u32 pcie_rx_vdsp_count[4];
		}__attribute__((packed)) get_die_performance;
		struct {
			u32 pci_id;
		}__attribute__((packed)) get_pci_id;
		struct {
			u32 pci_sub_id;
		}__attribute__((packed)) get_pci_sub_id;
		struct {
			u32 major_minor;
		}__attribute__((packed)) get_major_minor;
		struct {
			struct vastai_cedar_img_info cedar_info;
			struct {
				u32 done_flag;
				u32 cedar_res;
				u32 hash[16];
			}__attribute__((packed)) cedar_res_info;
			u32 die_id;
		}__attribute__((packed)) cedar_ioctl;

		struct {
			reset_msg mode;
			u32 die_id;
			u32 mcu_monitor;
			u32 mcu_status;
		}__attribute__((packed)) reset_mode;
		struct {
			u32 local_to_remote;
			u64 local_addr;
			u64 remote_addr;
			u32 size;
			u32 die_index;
		}__attribute__((packed)) p2p_start_cmd;
		struct {
			u32 bar_id;
			u64 bar_address;
			u64 bar_size;
		}__attribute__((packed)) get_bar_info_cmd;
		struct {
			board_type_e type;
		}__attribute__((packed)) board_type;
		struct {
			int dma_buf_fd;
			void *vir_addr;
			u64 axi_addr;
			u32 length;
			u32 die_index;
			int pid;
		}__attribute__((packed)) mmio_trans_cmd;
		struct {
			u64 src_addr;
			u64 dst_addr;
			u32 length;
			u32 direction;
		}__attribute__((packed)) dma_s2m_cmd;
		struct {
			u64 axi_addr;
			u64 data;
			u32 length;
			u32 die_index;
		}__attribute__((packed)) dma_fill_cmd;
		struct {
			u64 src_addr;
			u64 dst_addr;
			u32 length;
			u32 pid;
			u32 die_index;
		}__attribute__((packed)) dma_d2d_cmd;
		struct {
			int dma_buf_fd;
		}__attribute__((packed)) dma_close_cmd;
		struct {
			u32 local_die;
			u32 remote_die;
			u64 local_address ;
			u64 remote_address ;
			u32 is_local_2_remote ;
			u32 len;
			u32 die_index;
		} __attribute__((packed)) dma_die2die_cmd;
	};
};

enum VASTAI_PCI_TEST_CASE {
	VASTAI_PCI_CHECK_BAR2_AFTER_PROBE,
	VASTAI_PCI_CHECK_BMCU_DOWNLOAD,
#ifdef CONFIG_VASTAI_JENKINS_TEST
	VASTAI_PCI_CHECK_DMA_DDR_MAX_ADDR,
#endif
	VASTAI_PCI_CHECK_EXCEPTION,
	VASTAI_PCI_CHECK_AI_SYS_EXCEPTION,
	VASTAI_PCI_CHECK_VEMCU_EXCEPTION,
	VASTAI_PCI_CHECK_VDMCU_EXCEPTION,
	VASTAI_PCI_TEST_CASE_MAX,
};

enum VASTAI_PCI_FLASH_BL0_TYPE {
	VASTAI_PCI_FLASH_VBIOS = 1,
	VASTAI_PCI_FLASH_BL0,
	VASTAI_PCI_FLASH_BASE,
	VASTAI_PCI_FLASH_FULL,
	VASTAI_PCI_FLASH_BL0_MAX
};


#endif /* end of __VASTAI_EXPORT_ENUM_DEFINE_H__ */
