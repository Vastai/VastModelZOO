/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#ifndef __VASTAI_PCI_API_H__
#define __VASTAI_PCI_API_H__

#include <linux/completion.h>
#include "vastai_common_pci_api.h"




enum VASTAI_TX_CHN_ID {
	/* host to vdmcu0 */
	VASTAI_TX_CHN0,
	VASTAI_TX_CHN1,
	VASTAI_TX_CHN2,
	VASTAI_TX_CHN3,
	VASTAI_TX_CHN4,
	VASTAI_TX_CHN5,
	VASTAI_TX_CHN6,
	VASTAI_TX_CHN7,
	VASTAI_TX_CHN8,
	VASTAI_TX_CHN9,
	VASTAI_TX_CHN10,
	VASTAI_TX_CHN11,
	VASTAI_TX_CHN12,
	VASTAI_TX_CHN13,
	VASTAI_TX_CHN14,
	VASTAI_TX_CHN15,
	/* host to vdmcu1 */
	VASTAI_TX_CHN16,
	VASTAI_TX_CHN17,
	VASTAI_TX_CHN18,
	VASTAI_TX_CHN19,
	VASTAI_TX_CHN20,
	VASTAI_TX_CHN21,
	VASTAI_TX_CHN22,
	VASTAI_TX_CHN23,
	VASTAI_TX_CHN24,
	VASTAI_TX_CHN25,
	VASTAI_TX_CHN26,
	VASTAI_TX_CHN27,
	VASTAI_TX_CHN28,
	VASTAI_TX_CHN29,
	VASTAI_TX_CHN30,
	VASTAI_TX_CHN31,
	/* host to vdmcu2 */
	VASTAI_TX_CHN32,
	VASTAI_TX_CHN33,
	VASTAI_TX_CHN34,
	VASTAI_TX_CHN35,
	VASTAI_TX_CHN36,
	VASTAI_TX_CHN37,
	VASTAI_TX_CHN38,
	VASTAI_TX_CHN39,
	VASTAI_TX_CHN40,
	VASTAI_TX_CHN41,
	VASTAI_TX_CHN42,
	VASTAI_TX_CHN43,
	VASTAI_TX_CHN44,
	VASTAI_TX_CHN45,
	VASTAI_TX_CHN46,
	VASTAI_TX_CHN47
};

enum VASTAI_RX_CHN_ID {
	/* vemcu0 to host */
	VASTAI_RX_CHN0,
	VASTAI_RX_CHN1,
	VASTAI_RX_CHN2,
	VASTAI_RX_CHN3,
	VASTAI_RX_CHN4,
	VASTAI_RX_CHN5,
	VASTAI_RX_CHN6,
	VASTAI_RX_CHN7,
	VASTAI_RX_CHN8,
	VASTAI_RX_CHN9,
	VASTAI_RX_CHN10,
	VASTAI_RX_CHN11,
	/* vemcu1 to host */
	VASTAI_RX_CHN12,
	VASTAI_RX_CHN13,
	VASTAI_RX_CHN14,
	VASTAI_RX_CHN15,
	VASTAI_RX_CHN16,
	VASTAI_RX_CHN17,
	VASTAI_RX_CHN18,
	VASTAI_RX_CHN19,
	VASTAI_RX_CHN20,
	VASTAI_RX_CHN21,
	VASTAI_RX_CHN22,
	VASTAI_RX_CHN23,
	/* vemcu2 to host */
	VASTAI_RX_CHN24,
	VASTAI_RX_CHN25,
	VASTAI_RX_CHN26,
	VASTAI_RX_CHN27,
	VASTAI_RX_CHN28,
	VASTAI_RX_CHN29,
	VASTAI_RX_CHN30,
	VASTAI_RX_CHN31,
	VASTAI_RX_CHN32,
	VASTAI_RX_CHN33,
	VASTAI_RX_CHN34,
	VASTAI_RX_CHN35,
	/* vemcu3 to host */
	VASTAI_RX_CHN36,
	VASTAI_RX_CHN37,
	VASTAI_RX_CHN38,
	VASTAI_RX_CHN39,
	VASTAI_RX_CHN40,
	VASTAI_RX_CHN41,
	VASTAI_RX_CHN42,
	VASTAI_RX_CHN43,
	VASTAI_RX_CHN44,
	VASTAI_RX_CHN45,
	VASTAI_RX_CHN46,
	VASTAI_RX_CHN47
};

enum VASTAI_TRANSFER_DIR {
	/* The direction of data transfer is defined based on the host side. */
	/* 0: host write to device, or device read from host. */
	VASTAI_DIR_HOST_OUT,
	/* 1: host read from device, or device write to host. */
	VASTAI_DIR_HOST_IN
};


enum VASTAI_TRANSFER_SUBTYPE {
	VASTAI_SUB_NUL,
	/* type = 1; buf haved cmd */
	VASTAI_SUB_CMD,
	/* type = 1; buf haved data */
	VASTAI_SUB_DATA,
	VASTAI_SUB_NAL,
	VASTAI_SUB_VCL,
	// NTD
};


enum VASTAI_PCIE_ERR_TYPE {
	PCIE_LOCAL_ERROR = 0xFA,
	PCIE_LINK_ERROR,
	PCIE_DMA_ERROR,
};

union buf_data {
	struct {
		/* cmd id */
		u32 dev : 32;
		u32 pid : 32;
		u64 model_id : 64;
		/* reserved 32bit */
		u32 : 32;
		u32 cmd : 32;
		u64 data_id : 64;
		/* dev soc entry addr */
		u64 model_addr : 64;
		u64 inout_addr : 64;
	} __attribute__((packed)) cmd_model_desc;
	struct {
		/* cmd id */
		u32 dev : 32;
		u32 pid : 32;
		u64 operator_id : 64;
		/* cmcu2odsp for odsp operator refresh cache, consider harvest */
		u32 odsp_core_flag : 8;
		u32 : 24;
		u32 cmd : 32;
		u64 data_id : 64;
		/* dev soc entry addr */
		u64 operator_addr : 64;
		u64 operator_size : 64;
	} __attribute__((packed)) cmd_operator_desc;
	struct {
		/* cmd id */
		u32 dev : 32;
		u32 pid : 32;
		u64 stream_id : 64;
		/* reserved 32bit */
		u32 : 32;
		u32 cmd : 32;
		u64 data_id : 64;
		/* dev soc entry addr */
		u64 stream_addr : 64;
		/* reserved 64bit */
		u64 : 64;
	} __attribute__((packed)) cmd_stream_desc;
	struct { 
		u32 dev;
		u32 pid;
		u64 stream_id : 64;
		u32 work_size : 16;
		u32 work_group_id : 16;
		u32 cmd;
		u64 data_id ;
		u32 kernel_addr;
		u32 args_addr;
		u32 engine_type : 16;
		u32  : 16;	
		u32 : 32;
	}__attribute__((packed)) cmd_kernel_desc;
	struct { 
		u32 dev;
		u32 pid;
		u64  : 64;
		u32  : 16;
		u32 engine_type : 16;
		u32 cmd;
		u64 data_id : 64;
		u64 op_addr : 64;
		u64 op_size : 64;
	}__attribute__((packed)) cmd_kernel_op_desc;
	struct { 
		u32 dev;
		u32 pid;
		u64  : 64;
		u32  : 32;
		u32 cmd;
		u64  : 64;
		u64  : 64;
		u64  : 64;
	}__attribute__((packed)) cmd_kernel_cancel_desc;
	struct {
		/* refer to VASTAI_TRANSFER_SUBTYPE */
		u32 handshake;
		/* transfer source address */
		u64 sys_addr;
		/* transfer destination address */
		u64 ext_addr;
		/* transfer length */
		u32 len;
		/* reserved */
		u32 rsvd_0;
		/* reserved */
		u32 rsvd_1;
		u32 user_data[4];
	} __attribute__((packed)) data_desc;
#ifdef CONFIG_VASTAI_TOOLS_SUITE
	struct { //vadbg
		/* cmd id */
		u32 debug_cmd : 32;
		u32 mcu_index : 32;
		u32 break_ctrl : 32;
		u32 break_flag : 32;
		u32 model_index : 32;
		u32 ioctl_cmd : 32; // ioctl命令. debug下发的是 0x0000A18x
		u32 layer_index : 32;
		u32 opcode_index : 32;
		u32 sub_break_ctrl;
		u32 : 32;
		u64 : 64;
	} __attribute__((packed)) debug_desc;
#endif
};

struct buf_desc {
	union buf_data data;
	struct list_head node;
};

struct __attribute__((packed)) out_desc {
	/* refer to VASTAI_TRANSFER_SUBTYPE */
	u32 dev : 32;
	u32 pid : 32;
	u64 stream_id : 64;
	u64 data_id : 64;
	/* dev soc entry addr */
	u64 stream_addr : 64;
	u32 context_id : 32;
	/* error code */
	u32 error_code;
	/* reserved 64bit */
	u64 : 64;
	// struct list_head node;
	// struct work_struct dma_work;
	// void *ctxt;
};

/* ai/video kmd -> pcie/dma driver */
struct data_struct {
	struct completion dma_comp;
	struct list_head head;
	/*dma profiler info*/
	u64 time_of_driver_recv_dma_req;
	u64 time_of_host_trigger_dma;
	u32 time_of_dma_run;
	u32 time_of_dma_finish;
	pid_t pid;
	struct pcie_transfer_info trans;
	u32 trans_addr;
	u32 retry_cnt : 8;
	u32 status : 8;
	u32 rsvd : 16;
};

struct vastai_dmadesc {
	/* is_src_dma_addr == 0: api will alloc a phy_buf, and copy vir_addr -> phy_buf,
	 * is_src_dma_addr == 1: api will just use host_addr.dma_addr for dma */
	u32 is_src_dma_addr : 1;
	u32 is_host_to_dev : 1; /* dir */
	u32 is_src_not_user_mem : 1;
	u32 RSVD : 29;
	struct {
		dma_addr_t dma_addr; /* used only when is_src_dma_addr == 1 */
		void *vir_addr;
	} host_addr;
	loff_t dev_addr;
	u32 dma_lenth;
	u32 user_prive[4]; /* this data struct will be transf to fw */
};
struct vastai_sg_gather_info {
	struct scatterlist * cur_sg;
	u32 cur_sg_index;
	u64 cur_sg_remain_len;
	u32 sg_len;
	dma_addr_t gather_addr;
	u64 gather_len;
};
typedef int (*vastai_dma_callback)(void *pcie_dev, int die_id, u32 core_id,
				   struct vastai_dmadesc *desc, int desc_num);
/* channel id, refer to VASTAI_TX_CHN_ID and VASTAI_RX_CHN_ID */
/* if you need trigger vdsp_2: core_bitmap.vdsp = BIT(2) */
/* if you want __NOT__ trigger any mcu_core： core_bitmap.val = 0 */
union core_bitmap {
	struct {
		u32 cmcu : 8;
		u32 vdsp : 8;
		u32 encode : 4;
		u32 odsp0_3: 4;
		u32 decode : 4;
		u32 odsp4_7: 4;
	};
	u32 val;
};

struct vastai_pci_info;

/* for new common dma transfer api  */
int vastai_pcie_dma_transfer_sync(
	struct vastai_pci_info *pci_info, int die_id, union core_bitmap core_id,
	struct vastai_dmadesc desc[], /* a local val is ok */
	int desc_num);

int vastai_pci_dma_transfer_sync(
	struct vastai_pci_info *pcie_dev, int die_id, union core_bitmap core_id,
	struct vastai_dmadesc desc[], /* a local val is ok */
	int desc_num, int pid);

int vastai_pci_dma_transfer_sync_pid(struct vastai_pci_info *pci_info, int die_index,
				     union core_bitmap core_id,
				     struct vastai_dmadesc desc[], int desc_num,
				     int pid);

int vastai_pci_send_msg_sv(void *pcie_dev, int die_index,
			union core_bitmap core_id,
			void *msg_buf, /* what's user want pcie send to device */
			u32 msg_len);

int vastai_pci_send_msg_pid(void *pcie_dev, int die_index,
			    union core_bitmap core_id, void *msg_buf,
			    u32 msg_len, pid_t pid);

int vastai_pci_send_cmdbuf_pid(void *pcie_dev, int die_index,
			u32 buf_index, void *msg_buf, u32 msg_len, pid_t pid);

void vastai_clear_fifo(void *pci_info, int die_index, int core_idx);


struct vastai_pcie_link_err {
	u32 error_type; //bit[3:0]*8 -- error list :0:no error ;1 -ecc error ;2-- pcie error ;3 --mcu error
	struct {
		u32 sub_err_type : 16;
		u32 addr_h : 16;
		union {
			u32 Addr_l;
			u32 ErrSt;
		} AddrLOrErrSt;
		u32 error_timestamp;

	} err_list[8];
};

#endif /* end of __VASTAI_PCI_API_H__ */
