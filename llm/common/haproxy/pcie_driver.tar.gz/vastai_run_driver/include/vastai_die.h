#ifndef __VASTAI_DIE_H__
#define __VASTAI_DIE_H__
#include "vastai_pci.h"

static inline u32 vastai_die_get_die_index(struct vastai_sv100_die *die)
{
	if (!die)
		return UINT_MAX;
	return die->die_index;
}

int vastai_die_init(struct vastai_sv100_die *die, struct vastai_pci_info *pci_info, u32 die_id);
void vastai_die_deinit(struct vastai_sv100_die *die);
void vastai_global_die_init(struct vastai_addr_info *vastai_global_addr_info);

int vastai_die_get_pcie_attr(struct vastai_sv100_die *die);
void event_notify_per_core(struct vastai_core *core, u32 event);


#endif
