/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/delay.h>
#include <linux/workqueue.h>
#include <linux/firmware.h>

#include "vastai_pci_boot.h"
#include "vastai_pci_test.h"
#include "vastai_dmi_table.h"
#define CONFIG_VASTAI_DOWNLOAD_FW_FROM_HEX
#ifdef CONFIG_VASTAI_DOWNLOAD_FW_FROM_HEX
#include "vastai_fw_hex.h"
#endif
#include "vastai_version.h"
#include "vastai_udma_engine.h"
#include "vastai_die.h"
#include "vastai_avfs.h"
#include "vastai_state.h"
#include "vastai_bin_merge.h"
#include "sg100_pcie_wrap.h"
#include "sg100_base.h"
#include "vastai_sg100_bbox.h"
#include "hw_config.h"
#include "vastai_download_fw.h"
#include "sg100_cmd.h"
#include "vatools.h"
#include "vatools_driver.h"





struct vastai_core_sync core_sync[VASTAI_CORE_SYNC_TOTAL_NUM] = {
	{ 0, "smcu "},
	{ 1, "cmcu "},
	{ 2, "lmcu0 "},
	{ 3, "lmcu1 "},
	{ 4, "lmcu2 "},
	{ 5, "lmcu3 "},
	{ 6, "lmcu4 "},
	{ 7, "lmcu5 "},
	{ 8, "lmcu6 "},
	{ 9, "lmcu7 "},
	{ 10, "odsp0 "},
	{ 11, "odsp1 "},
	{ 12, "odsp2 "},
	{ 13, "odsp3 "},
	{ 14, "odsp4 "},
	{ 15, "odsp5 "},
	{ 16, "odsp6 "},
	{ 17, "odsp7 "},
	{ 18, "vdmcu0 "},
	{ 19, "vdmcu1 "},
	{ 20, "vdmcu2 "},
	{ 21, "vemcu0 "},
	{ 22, "vemcu1 "},
	{ 23, "vemcu2 "},
	{ 24, "vemcu3 "},
	{ 25, "vdsp0 "},
	{ 26, "vdsp1 "},
	{ 27, "vdsp2 "},
	{ 28, "vdsp3 "},
	{ 29, "fwtotal"}
};
extern struct mutex vastai_card_info_list_lock;
extern struct list_head vastai_card_info_list;
extern bool parallel_load;

bool is_find_pkg_info(u8 pkg_id,
				struct vastai_card_info **card_info, struct vastai_pkg_info **pkg_info, u8 *sn)
{
	bool isfind = false;
	struct vastai_card_info *card_loop = NULL;

	list_for_each_entry(card_loop, &vastai_card_info_list, card_node) {
		if(!strcmp(sn, card_loop->sn_info)) {
			struct vastai_pkg_info *pkg_loop = NULL;

			*card_info = card_loop;
			list_for_each_entry(pkg_loop, &card_loop->vastai_pkg_info_list, pkg_node) {
				if(pkg_loop->pkg_id == pkg_id) {
					*pkg_info = pkg_loop;
					isfind = true;
					break;
				}
			}
			break;
		}
	}

	return isfind;
}

bool is_find_die_info(u8 pkg_id, u8 die_id_in_card, struct vastai_die_info **die_info, u8 *sn)
{
	bool isfind = false;
	struct vastai_die_info *die_loop   = NULL;
	struct vastai_pkg_info *pkg_info   = NULL;
	struct vastai_card_info *card_info = NULL;

	if(is_find_pkg_info(pkg_id, &card_info, &pkg_info, sn)) {
		list_for_each_entry(die_loop, &pkg_info->vastai_die_info_list, die_node) {
			if(die_loop->die_id_in_card == die_id_in_card) {
				*die_info = die_loop;
				isfind = true;
				break;
			}
		}
	}

	return isfind;
}

bool is_find_fn_info(struct vastai_die_info *die_info, struct vastai_pci_info *priv)
{
	bool isfind = false;
	struct fn_tree_node *fn_node = NULL;

	list_for_each_entry(fn_node, &die_info->vastai_fn_info_list, parent_node) {
		if(fn_node->priv == priv) {
			isfind = true;
			break;
		}
	}

	return isfind;
}


int vastai_create_pkg_info_tree(u8 pkg_id, struct vastai_pkg_info **pkg_info, u8 *sn)
{
	struct vastai_card_info *card_info = NULL;

	if(is_find_pkg_info(pkg_id, &card_info, pkg_info, sn))
		return 0;

	if(!card_info) {
		VASTAI_PCI_ERR(
			NULL, DUMMY_DIE_ID,
			"%s card_info is NULL.\n",
			__func__);
		return -ENOMEM;
	}

	*pkg_info = kzalloc(sizeof(struct vastai_pkg_info), GFP_KERNEL);
	if (!*pkg_info) {
		VASTAI_PCI_ERR(
			NULL, DUMMY_DIE_ID,
			"%s NOMEM.\n",
			__func__);
		return -ENOMEM;
	}

	(*pkg_info)->pkg_id = pkg_id;
	(*pkg_info)->card_info = card_info;
	INIT_LIST_HEAD(&(*pkg_info)->vastai_die_info_list);
	spin_lock_init(&(*pkg_info)->die_info_list_lock);

	list_add_tail(&((*pkg_info)->pkg_node), &(card_info->vastai_pkg_info_list));

	return 0;
}

int vastai_create_die_info_tree(u8 pkg_id, u8 die_id_in_card, struct vastai_die_info **die_info, u8 *sn)
{
	int ret = 0;
	struct vastai_pkg_info  *pkg_info  = NULL;
	struct vastai_card_info *card_info = NULL;
	unsigned long flags = 0;

	if(is_find_pkg_info(pkg_id, &card_info, &pkg_info, sn)) {
		if(!pkg_info) {
			VASTAI_PCI_ERR(
				NULL, DUMMY_DIE_ID,
				"%s card_info is NULL.\n",
				__func__);
			return -ENOMEM;
		}

		if(is_find_die_info(pkg_id, die_id_in_card, die_info, sn))
			return 0;
	} else {
		ret = vastai_create_pkg_info_tree(pkg_id, &pkg_info, sn);
		if(ret)
			return ret;
	}

	*die_info = kzalloc(sizeof(struct vastai_die_info), GFP_KERNEL);
	if (!(*die_info)) {
		VASTAI_PCI_ERR(
			NULL, DUMMY_DIE_ID,
			"%s NOMEM.\n",
			__func__);
		return -ENOMEM;
	}

	(*die_info)->die_id_in_card = die_id_in_card;
	(*die_info)->pkg_info = pkg_info;
	INIT_LIST_HEAD(&(*die_info)->vastai_fn_info_list);
	spin_lock_init(&(*die_info)->fn_info_list_lock);

	spin_lock_irqsave(&pkg_info->die_info_list_lock, flags);
	list_add_tail(&((*die_info)->die_node), &(pkg_info->vastai_die_info_list));
	spin_unlock_irqrestore(&pkg_info->die_info_list_lock, flags);

	return 0;
}

extern int vastai_create_fn_info_tree(struct vastai_pci_info *priv, u8 *sn, u8 pkg_id, u8 die_id_in_card);

u8 vastai_pci_read_die_num(struct vastai_pci_info *priv, u8 die_id)
{
	int die_num = VASTAI_SINGLE_DIE;
#ifndef CONFIG_VASTAI_PCI_ONLY_DOWNLOAD_BL1
	union smcu_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	u32 i;

	vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr, &(reg.val), 4);
	VASTAI_PCI_DBG_RATELIMIT("%s [read] addr=0x%llx, len=4, val=0x%08x\n",
				 __func__, reg_addr, reg.val);
	/*
	 * VASTAI_SMCU_BOOT_STAGE_REG, 0x6E4
	 * bit[31:29]: die config, refer to struct vastai_die_cfg table
	 */
	for (i = 0; i < priv->addr->die_config_tab_size; i++) {
		if (priv->addr->die_cfg[i].val == reg.bit.die_cfg) {
			int j = 0;

			die_num = priv->addr->die_cfg[i].die_num;
			for(j=0; j<8; j++) {
				if(priv->addr->die_cfg[i].fn_id[j] == (priv->dev->devfn & 0x7)) {
					/* TODO: consider sg100, should use sn */
					/*vastai_create_fn_info_tree(priv->dev, priv->addr->die_cfg[i].pkg_id,
									priv->addr->die_cfg[i].die_id,
									priv->addr->die_cfg[i].fn_id[j],
									priv);
					*/
					break;
				}
			}
			break;
		}
	}
	if (i == priv->addr->die_config_tab_size) {
		die_num = VASTAI_SINGLE_DIE;
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"%s cfg=%d not in the cfg tbl, set to single-die.\n",
			__func__, reg.bit.die_cfg);
	}
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s=%d, cfg=%d\n", __func__,
			die_num, reg.bit.die_cfg);
#endif
	return die_num;
}

int vastai_pci_get_pf_num_per_card(struct vastai_pci_info *priv)
{
	priv->pf_num_per_card = 1;
#ifndef CONFIG_VASTAI_PCI_ONLY_DOWNLOAD_BL1

	//priv->pf_num_per_card = priv->priv_hw_cfg->sys_cfg.total_pf_per_card;
#endif
	return 0;
}


/**
 * @brief gen a string include fw version information
 *
 * @param pci_info: vastai sv100 pci base struct.
 * @param mask: bitmap for which mcu's version need print
 * @return char point: string buffer. It's need free after used.
 */
void vastai_pci_show_fw_ver(struct vastai_pci_info *pci_info, u32 mask)
{
	if (mask & 0x1)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.ver);
	if (mask & 0x2)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.smcu_ver);
	if (mask & 0x4) {
		struct vastai_fw_bmcu_xspi_version bmcu_xspi_ver;

		memcpy(bmcu_xspi_ver.bmcu_ver,
		       pci_info->dies[0].fw_ver.bmcu_ver,
		       VASTAI_VER_COMMON_LEN);
		bmcu_xspi_ver.bmcu_sub_ver[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;

		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [active]\n",
				bmcu_xspi_ver.bmcu_sub_ver);

		memcpy(bmcu_xspi_ver.bmcu_ver,
		       &(pci_info->dies[0].fw_ver.bmcu_backup_ver),
		       VASTAI_VER_COMMON_LEN);
		bmcu_xspi_ver.bmcu_sub_ver[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;

		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [backup]\n",
				bmcu_xspi_ver.bmcu_sub_ver);
	}
	if ((mask & 0x8) &&
		(strlen(pci_info->dies[0].fw_ver.vdmcu_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.vdmcu_ver);
	if ((mask & 0x10) &&
		(strlen(pci_info->dies[0].fw_ver.vemcu_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.vemcu_ver);
	if ((mask & 0x20) &&
		(strlen(pci_info->dies[0].fw_ver.vdsp_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.vdsp_ver);
	if ((mask & 0x40) &&
		(strlen(pci_info->dies[0].fw_ver.cmcu_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.cmcu_ver);
	if ((mask & 0x80) &&
		(strlen(pci_info->dies[0].fw_ver.lmcu_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.lmcu_ver);
	if ((mask & 0x100) &&
		(strlen(pci_info->dies[0].fw_ver.odsp_ver) != 0))
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.odsp_ver);
	if (mask & 0x200)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.driver_ver);

	if (mask & 0x400) {
		int i = 0;
		for (i = 0; i < pci_info->die_num_in_fn; i++) {
			struct vastai_fw_bmcu_xspi_version *bmcu_xspi_ver;
			bmcu_xspi_ver = (struct vastai_fw_bmcu_xspi_version *)
					pci_info->dies[i].fw_ver.bmcu_ver;

			VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
					"[die %d] [%s] [active]\n",
					i, bmcu_xspi_ver->xspi_sub_ver);

			bmcu_xspi_ver = (struct vastai_fw_bmcu_xspi_version *)
				pci_info->dies[i].fw_ver.bmcu_backup_ver;
			VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID,
					"[die %d] [%s] [backup]\n",
					i, bmcu_xspi_ver->xspi_sub_ver);
		}
	}
	if (mask & 0x800) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->dies[0].fw_ver.phy_ver);
	}
}

void vastai_pci_get_fw_ver(struct vastai_pci_info *pci_info, u32 mask, bool origin_addr)
{
	int ret = 0;
	int i;

	for (i = 0; i < pci_info->die_num_in_fn; i++) {
		unsigned int die_index = pci_info->dies[i].die_index;
		struct vastai_sv100_die *die = &(pci_info->dies[i]);

		ret = vastai_pci_mem_write(pci_info, die_index, ADDR(pci_info, VSERSION_INFO_BASE),
					   VASTAI_VERSION, VASTAI_VER_COMMON_LEN);
		if (ret < 0) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				       "%s write version error:%d\n",
				       __func__, ret);
			break;
		}

		ret = vastai_pci_mem_read(pci_info, die_index, ADDR(pci_info, VSERSION_INFO_BASE),
					  &die->fw_ver,
					  sizeof(struct vastai_fw_version));
		if (ret < 0) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				       "%s read firmware version error:%d\n",
				       __func__, ret);
			break;
		}

		ret = vastai_pci_mem_read(pci_info, die_index, STORE_INFO_ADDR_BMCU_BK,
					  die->fw_ver.bmcu_backup_ver,
					  sizeof(struct vastai_fw_bmcu_xspi_version ));
		if (ret < 0) {
			VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
				       "%s read bmcu backup firmware version error:%d\n",
				       __func__, ret);
			break;
		}

		die->fw_ver.ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.smcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.bmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.vdmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.vemcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.vdsp_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.cmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.lmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		die->fw_ver.odsp_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
		snprintf(die->fw_ver.driver_ver, VASTAI_VER_COMMON_LEN,
			 "Driver: %s %s %s %s", VASTAI_PCI_DRIVER_VERSION,
			 VASTAI_PCI_GIT_BRANCH_NAME, VASTAI_PCI_GIT_COMMIT_HASH,
			 VASTAI_PCI_MKPACKAGE_TIME);
		/* pcie_phy version info not in csram */
		/* pcie_hpy version in xspiflash 0xd000 */
		/* we read from app partition, relative position */
#ifndef CONFIG_VASTAI_AI_EMU
		vastai_pci_read_xspi(pci_info, i, 0x6000, die->fw_ver.phy_ver,
					sizeof(die->fw_ver.phy_ver), VASTAI_PCI_FLASH_BL0, origin_addr);
#endif
		if (die->fw_ver.phy_ver[0] == 0xFF)
			strcpy(die->fw_ver.phy_ver, "no pcie phy version");
	}
	if (!ret) {
		vastai_pci_show_fw_ver(pci_info, mask);
	}
}

void vastai_pci_show_fw_ver_sg(struct vastai_pci_info *pci_info, u32 mask)
{
	if (mask & 0x1)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.smcu_ver);
	if (mask & 0x2)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.cmcu_ver);
	if (mask & 0x4)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.omcu_ver);
	if (mask & 0x8)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.gmcu_ver);
	if (mask & 0x10)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.vemcu_ver);
	if (mask & 0x20)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.odsp_ver);
	if (mask & 0x40)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.vdsp_ver);
	if (mask & 0x80)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.pmcu_ver);
	if (mask & 0x100)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.vdmcu_ver);
	if (mask & 0x200)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [active]\n",
				pci_info->fw_ver.ver);
	if (mask & 0x400)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [backup]\n",
				pci_info->fw_ver.ver_bk);
	if (mask & 0x800)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [active]\n",
				pci_info->fw_ver.bl0_ver);
	if (mask & 0x1000)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s] [backup]\n",
				pci_info->fw_ver.bl0_ver_bk);
	if (mask & 0x2000)
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.driver_ver);
	if (mask & 0x4000) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "[%s]\n",
				pci_info->fw_ver.phy_ver);
	}
}


void vastai_pci_get_fw_ver_sg(struct vastai_pci_info *pci_info, u32 mask)
{
	int ret = 0;

	ret = vastai_pci_mem_read_direct(pci_info, 0, ADDR(pci_info, VSERSION_INFO_BASE),
				  &pci_info->fw_ver,
				  sizeof(struct vastai_fw_version_sg));
	if (ret < 0) {
		VASTAI_PCI_ERR(pci_info, DUMMY_DIE_ID,
			       "%s read firmware version error:%d\n",
			       __func__, ret);
		return;
	}

	pci_info->fw_ver.ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.smcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.cmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.omcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.gmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.vemcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.odsp_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.vdsp_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.pmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.vdmcu_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.ver_bk[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.bl0_ver[VASTAI_VER_COMMON_LEN - 1] = 0;
	pci_info->fw_ver.bl0_ver_bk[VASTAI_VER_COMMON_LEN - 1] = 0;
	snprintf(pci_info->fw_ver.driver_ver, VASTAI_VER_COMMON_LEN,
		 "Driver: %s %s %s %s", VASTAI_PCI_DRIVER_VERSION,
		 VASTAI_PCI_GIT_BRANCH_NAME, VASTAI_PCI_GIT_COMMIT_HASH,
		 VASTAI_PCI_MKPACKAGE_TIME);
	/* pcie_phy version info not in csram */
	/* pcie_hpy version in xspiflash 0xd000 */
#if 0
	/* we read from app partition, relative position */
	vastai_pci_read_xspi(pci_info, i, 0x6000, die->fw_ver.phy_ver,
				sizeof(die->fw_ver.phy_ver), 0);
	if (die->fw_ver.phy_ver[0] == 0xFF)
		strcpy(die->fw_ver.phy_ver, "no pcie phy version");
#endif

	if (!ret) {
		vastai_pci_show_fw_ver_sg(pci_info, mask);
	}
}


void printf_bootfail_log(struct vastai_pci_info *priv, u8 die_id,u8 fail_fw_stage)
{
        int ret;
        u32 log_point_addr =0;
        int i,j;
        int list = 0;
        char *print_log_buf = NULL;
        char *log_raw =NULL;
        u32 log_info_addr;
        u32 log_info_val[5];

        log_point_addr = ADDR(priv, INFO_LOG_ADDR);
        ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
					log_point_addr, &(log_info_addr), 4);
		log_info_addr = (log_info_addr>>2)<<2;
        VASTAI_PCI_INFO(priv, die_id,
				"%s log info addr[%x] = [0x%x]",
				__func__, log_point_addr,log_info_addr);
		if( ((log_info_addr&0x8c00000) != 0x8c00000) || (log_info_addr==0xffffffff) )
                return;
        ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
                    log_info_addr, &(log_info_val[0]), 16);
        VASTAI_PCI_INFO(priv, die_id,
                    "%s log info[%x] = [0x%x-0x%x-0x%x-0x%x]",
                    __func__, log_point_addr,log_info_val[0],log_info_val[1],log_info_val[2],log_info_val[3]);
        print_log_buf = vmalloc(1024);
        log_raw = vmalloc(log_info_val[2]);
        ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
                    log_info_val[0], log_raw, log_info_val[2]);
        if (fail_fw_stage <= VASTAI_SMCU_BOOT_STAGE_FW_DONE) {
                j=0;
                for(i =0;i< log_info_val[2];){
                        print_log_buf[j] = log_raw[i++];
                        if(print_log_buf[j++] == 0){//str end
                                if(print_log_buf[0] != 0){
                                        VASTAI_PCI_INFO(priv, die_id,
                                               "[ %d ]: %s \n",list++,
                                               print_log_buf);
                                }

                                j = 0;
                        }
                }
        }
        vfree(print_log_buf);
        vfree(log_raw);
}

int vastai_pci_poll_smcu_stage(struct vastai_pci_info *priv, u8 die_id,
				      u32 smcu_bootstage)
{
	int ret;
	union smcu_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	u64 tm_begin = ktime_to_ms(ktime_get()), tm_end, tm_total_ms;

	do {
		ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
						 reg_addr, &(reg.val), 4);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx, len=4, error:%d\n",
				       __func__, reg_addr, ret);
			break;
		}
		VASTAI_PCI_DBG_RATELIMIT("%s [read] addr=0x%llx, len=4, "
					 "val=0x%08x, poll die%d stage%d\n",
					 __func__, reg_addr, reg.val, die_id,
					 smcu_bootstage);
		/*
		 * VASTAI_SMCU_BOOT_STAGE_REG, 0x6E4
		 * bit[26:24]: smcu boot stage.
		 *             3'h0: initial state
		 *             3'h1: wait for downloading bl1
		 *             3'h2: bl1 verify pass
		 *             3'h3: wait for downloading fw
		 *             3'h4: fw verify pass
		 */
		if (smcu_bootstage < VASTAI_SMCU_BOOT_STAGE_DIE_DONE) {
			if (reg.bit.stage == smcu_bootstage) {
				VASTAI_PCI_DBG(priv, die_id,
					       "%s smcu.bootstage=0x%x, ready "
					       "to download. "
					       "(1:bl1_ready,2:bl1_done,"
					       "3:fw_ready,4:fw_done)",
					       __func__, reg.bit.stage);
				break;
			}
		} else {
			if (reg.bit.stage >= smcu_bootstage) {
				if(smcu_bootstage==VASTAI_SMCU_BOOT_STAGE_WHILE_1)
					VASTAI_PCI_INFO(priv, die_id,
					       "%s SMCU_BOOT_STAGE_REG[0x%x]",
					       __func__, reg.val);
				VASTAI_PCI_DBG(priv, die_id,
					       "%s smcu.bootstage=0x%x, ready "
					       "to download. "
					       "(1:bl1_ready,2:bl1_done,"
					       "3:fw_ready,4:fw_done)",
					       __func__, reg.bit.stage);
				break;
			}
		}

		tm_end = ktime_to_ms(ktime_get());
		tm_total_ms = tm_end - tm_begin;
		if (tm_total_ms > CONFIG_VASTAI_POLL_BOOT_STAGE_MS) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s poll stage%d, but stage is %d, %ds timeout!\n",
				__func__, smcu_bootstage, reg.bit.stage,
				(CONFIG_VASTAI_POLL_BOOT_STAGE_MS / 1000));
				if(0xffffffff == reg.val)
					VASTAI_PCI_ERR(
						priv, die_id,
						"%s reg is 0xffffffff\n",
						__func__);
			//printf BL1 log from CSRAM
            printf_bootfail_log(priv,die_id,reg.bit.stage);
			if (reg.bit.stage == VASTAI_SMCU_BOOT_STAGE_BL1_READY)
				return -EAGAIN;
			else
				return -ETIMEDOUT;
		}
		msleep(VASTAI_BOOT_POLL_SLEEP_MS);
	} while (1);

	return ret;
}

static int vastai_pci_poll_die_linkup(struct vastai_pci_info *priv, u8 die_id)
{
	int ret;
	union smcu_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	u64 tm_begin = ktime_to_ms(ktime_get()), tm_end, tm_total_ms;

	do {
		ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
					  reg_addr, &(reg.val), 4);
		if (ret < 0)
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx, len=4, error:%d\n",
				       __func__, reg_addr, ret);
		VASTAI_PCI_DBG_RATELIMIT("%s [read] addr=0x%llx, len=4, "
					 "val=0x%08x, poll die%d linkup\n",
					 __func__, reg_addr, reg.val, die_id);
		/*
		 * VASTAI_SMCU_BOOT_STAGE_REG, 0x6E4
		 * bit[28]: rc_link_sts:
		 *          current die ep and front die or host  rc link up
		 * flag bit[27]: ep_link_sts: current die rc and next die ep
		 * link up flag
		 */
		if (reg.bit.rc_link_sts == 1) {
			if (reg.bit.d2d_link_retry_cnt != 0)
				VASTAI_PCI_INFO(priv, die_id,
						"%s die%d retry %d times "
						"to linkup",
						__func__, (die_id + 1),
						reg.bit.d2d_link_retry_cnt);
			else
				VASTAI_PCI_INFO(priv, die_id,
						"%s die%d linkup",
						__func__, (die_id + 1));
			break;
		}

		tm_end = ktime_to_ms(ktime_get());
		tm_total_ms = tm_end - tm_begin;
		if (tm_total_ms > CONFIG_VASTAI_POLL_BOOT_STAGE_MS) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s poll linkup, but link status is %d,"
				       "retry %d times, %ds timeout!\n",
				       __func__, reg.bit.rc_link_sts,
				       reg.bit.d2d_link_retry_cnt,
				       (CONFIG_VASTAI_POLL_BOOT_STAGE_MS / 1000));
			return -ETIMEDOUT;
		}
		msleep(VASTAI_BOOT_POLL_SLEEP_MS);
	} while (1);

	return ret;
}


#if 0 /* This action (set bar4 size to 256GB) has been moved to smcu side. */
static int vastai_pci_set_bar4_size_256g(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;
	u32 reg_val;
	u64 reg_addr;

	reg_addr = VASTAI_PCI_CDN_PHY_FUNC_BAR_CFG_REG1;
	ret = vastai_pci_mem_read(priv, vastai_pci_get_die_index(priv, die_id), reg_addr, &reg_val, 4);
	/* bar4: 64bit memory BAR, prefetchable, 256GB */
	reg_val = ((reg_val & 0xFFFF0000) | 0x05FF);
	ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id), reg_addr, &reg_val, 4);
	/* Add delay to solve atu configuration not work issue. */
	mdelay(10);

	return ret;
}
#endif

int vastai_switch_die0_atu(struct vastai_pci_info *priv, u32 sub_cmd, u64 addr);

static int vastai_pci_refresh_msix_table(struct vastai_pci_info *priv)
{
	int ret = 0; //, i;

#ifndef CONFIG_TRAP_MSIX_ACCESS
	ret = vastai_pci_mem_read_direct(
		priv, vastai_pci_get_die_index(priv, 0), PCIE_MSIX_PF_TABLE,
		&priv->msix_table,
		(priv->irq_num * sizeof(struct msi_x_table)));
#else
	unsigned long saved_atu_addr = priv->bar[VASTAI_PCI_BAR2].at_addr;

	ret |= vastai_pci_mem_bar2_read(priv, -1, PCIE_MSIX_PF_TABLE, priv->msix_table,
					(priv->irq_num * sizeof(struct msi_x_table)));

	ret |= vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, saved_atu_addr);
	if(ret) {
		return ret;
	}
#endif

#if 0
	/* Caution:
	 * [2021/5/31]
	 * On the Zebu platform, the host updates the MSI-X table by means of
	 * PCIE memwr, which causes the emulated environment to assume that
	 * the attributes of the MSI-X are being updated at the same time,
	 * resulting in failure to receive subsequent interrupts.
	 */
	/* The first 32 items in the MSI-X table are refreshed with the new
	 * value (add address base 0x7000_0000) of HOST, and the parameters
	 * need to be fetched starting from the 33rd item for mcu.
	 */
	ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id), (VASTAI_PCIE_MSIX_TABLE + (VASTAI_PCIE_MSIX_NUM_PER_DIE * sizeof(struct msi_x_table))), &priv->msix_table[0], sizeof(struct msi_x_table));
#endif
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"%s msg_addr:0x%x 0x%x, msg_data:0x%x,"
			" vector_control:0x%x\n",
			__func__, priv->msix_table[0].msg_addr,
			priv->msix_table[0].msg_upper_addr,
			priv->msix_table[0].msg_data,
			priv->msix_table[0].vector_control);
#if 0
	/* mcu write address 0x7000_0000, will be routed to address 0 to
	 * PCIe ep master via NoC. */
	for (i = 0; i < VASTAI_PCIE_MSIX_NUM; i++)
		priv->msix_table[i].msg_addr = (priv->msix_table[i].msg_addr & 0x0FFFFFFF) | VASTAI_PCIE_EP_SLAVE_BASE;
	ret = vastai_pci_mem_write(priv, vastai_pci_get_die_index(priv, die_id), VASTAI_PCIE_MSIX_TABLE, &priv->msix_table[0], (VASTAI_PCIE_MSIX_NUM_PER_DIE * sizeof(struct msi_x_table)));
#endif
	return ret;
}

static int vastai_pci_die_enumeration(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;
	u32 reg_val;
	u64 reg_addr;

	/* config bar0 ~ bar5 */
	if (priv->bar[VASTAI_PCI_BAR0].minish_bar_size)
		reg_val = VASTAI_PCIE_BAR0_PCIE_ADDR_8MB;
	else
		reg_val = VASTAI_PCIE_BAR0_PCIE_ADDR_32MB;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR0;
	ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);
	reg_val = VASTAI_PCIE_BAR1_PCIE_ADDR_32MB;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR1;
	ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);
	if (priv->bar[VASTAI_PCI_BAR2].minish_bar_size || (priv->bar[VASTAI_PCI_BAR2].mmio_len == (1024 * 1024 * 1024)))
		reg_val = VASTAI_PCIE_BAR2_PCIE_ADDR_32MB & VASTAI_VAL_DW_MASK;
	else
		reg_val = VASTAI_PCIE_BAR2_PCIE_ADDR_32GB & VASTAI_VAL_DW_MASK;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR2;
	ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);
	if (priv->bar[VASTAI_PCI_BAR2].minish_bar_size)
		reg_val = (VASTAI_PCIE_BAR2_PCIE_ADDR_32MB >> 32) &
			  VASTAI_VAL_DW_MASK;
	else
		reg_val = (VASTAI_PCIE_BAR2_PCIE_ADDR_32GB >> 32) &
			  VASTAI_VAL_DW_MASK;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR3;
	ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);
	reg_val = VASTAI_PCIE_BAR4_PCIE_ADDR_256GB & VASTAI_VAL_DW_MASK;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR4;
	ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);
	reg_val = (VASTAI_PCIE_BAR4_PCIE_ADDR_256GB >> 32) & VASTAI_VAL_DW_MASK;
	reg_addr = VASTAI_PCIE_EP_CONFIG_BAR5;
	ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);

	/* enable mem-space */
	reg_val = 0x00100507;
	reg_addr = VASTAI_PCIE_EP_CONFIG_CMD_STATUS;
	ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &reg_val, 4);

#if 0 /* This action (set bar4 size to 256GB) has been moved to smcu side. */
	if (priv->minish_bar_size == 0)
		vastai_pci_set_bar4_size_256g(priv, die_id);
#endif

	/* enable msi */
	if (priv->irq_type == VASTAI_MSI_IRQ) {
		reg_addr = VASTAI_PCIE_EP_CONFIG_MSI_CTRL;
		ret |= vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
					  reg_addr, &reg_val, 4);
		reg_val |= 0x10000;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
		reg_val = VASTAI_MULTI_DIE_MSI_ADDR & VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_MSI_MSG_L;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
		reg_val =
			(VASTAI_MULTI_DIE_MSI_ADDR >> 32) & VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_MSI_MSG_H;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
	}

#ifndef CONFIG_TRAP_MSIX_ACCESS
	/* enable msi-x and write msix table */
	if (priv->irq_type == VASTAI_MSIX_IRQ) {
		reg_addr = VASTAI_PCIE_EP_CONFIG_MSIX_CTRL;
		ret |= vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
					  reg_addr, &reg_val, 4);
		reg_val |= 0x80000000;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
		ret |= vastai_pci_mem_write_direct(
			priv, vastai_pci_get_die_index(priv, die_id), PCIE_MSIX_PF_TABLE,
			&priv->msix_table[(VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM) * die_id],
			((VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM) *
			 sizeof(struct msi_x_table)));
	}
#endif

	return ret;
}

/* bh = bottom half */
static int vastai_pci_die_enumeration_bh(struct vastai_pci_info *priv,
					 u8 die_id)
{
	int ret = 0;
	u32 reg_val;
	u64 reg_addr;

	/* config bar0 ~ bar5 */
	if (priv->bar[VASTAI_PCI_BAR0].minish_bar_size) {
		reg_val = VASTAI_PCIE_BAR0_PCIE_ADDR_256MB;
		reg_addr = VASTAI_PCIE_EP_CONFIG_BAR0;
		ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
	}

	if (priv->bar[VASTAI_PCI_BAR2].minish_bar_size) {
		reg_val = VASTAI_PCIE_BAR2_PCIE_ADDR_256GB & VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_BAR2;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
		reg_val = (VASTAI_PCIE_BAR2_PCIE_ADDR_256GB >> 32) &
			  VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_BAR3;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
	} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (64 * 1024 * 1024 * 1024ULL) || \
		  priv->bar[VASTAI_PCI_BAR4].mmio_len == (4 * 1024 * 1024 * 1024ULL)) {
		reg_val = VASTAI_PCIE_BAR4_PCIE_ADDR_64GB & VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_BAR2;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
		reg_val = (VASTAI_PCIE_BAR4_PCIE_ADDR_64GB >> 32) &
			  VASTAI_VAL_DW_MASK;
		reg_addr = VASTAI_PCIE_EP_CONFIG_BAR3;
		ret |= vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id),
					   reg_addr, &reg_val, 4);
	}

	return ret;
}

static int vastai_pci_poll_host_stage(struct vastai_pci_info *priv, u8 die_id,
				      u32 host_bootstage)
{
	int ret;
	union host_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_HOST_BOOT_STAGE_REG);
	u64 tm_begin = ktime_to_ms(ktime_get()), tm_end, tm_total_ms;

	do {
		ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
					  reg_addr, &(reg.val), 4);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx, len=4, error:%d\n",
				       __func__, reg_addr, ret);
			break;
		}
		VASTAI_PCI_DBG_RATELIMIT("%s [read] addr=0x%llx, len=4, "
					 "val=0x%08x, poll die%d stage%d\n",
					 __func__, reg_addr, reg.val, die_id,
					 host_bootstage);
		if (reg.bit.stage == host_bootstage) {
			VASTAI_PCI_DBG(priv, die_id, "%s host.bootstage=0x%x",
				       __func__, reg.bit.stage);
			break;
		}

		tm_end = ktime_to_ms(ktime_get());
		tm_total_ms = tm_end - tm_begin;
		if (tm_total_ms > CONFIG_VASTAI_POLL_BOOT_STAGE_MS) {
			VASTAI_PCI_ERR(
				priv, die_id,
				"%s poll stage%d, but stage is %d, %ds timeout!\n",
				__func__, host_bootstage, reg.bit.stage,
				(CONFIG_VASTAI_POLL_BOOT_STAGE_MS / 1000));
			return -ETIMEDOUT;
		}
		msleep(VASTAI_BOOT_POLL_SLEEP_MS);
	} while (1);

	return ret;
}

int vastai_pci_set_host_stage(struct vastai_pci_info *priv, u8 die_id,
						u32 host_bootstage)
{
	int ret;
	union host_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_HOST_BOOT_STAGE_REG);

	ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				  &(reg.val), 4);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [read] 0x%llx, len=4, error:%d\n", __func__,
			       reg_addr, ret);
	/*
	 * VASTAI_HOST_BOOT_STAGE_REG, 0x6E0
	 * bit[26:24]: host boot stage.
	 *             3'h0: initial state
	 *             3'h1: bl1 download finish
	 *             3'h2: fw download finish
	 *             3'h3: all dies download finish, host ready
	 */
	reg.bit.stage = host_bootstage;
	ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &(reg.val), 4);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [write] 0x%llx, len=4, val=0x%x, error:%d\n",
			       __func__, reg_addr, reg.val, ret);

	return ret;
}

static int vastai_pci_set_current_die(struct vastai_pci_info *priv, u8 die_id)
{
	int ret;
	union host_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_HOST_BOOT_STAGE_REG);

	ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
					 &(reg.val), 4);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [read] 0x%llx, len=4, error:%d\n", __func__,
			       reg_addr, ret);
	if(vastai_get_board_type(priv) == SV100) {
		priv->vadev.dev_type = VASTAI_PROCESSING_ACCELERATORS_DEVICE;
		reg.bit.hw_type = priv->vadev.dev_cap;
#ifdef CONFIG_VASTAI_HW_TYPE_BY_HOST
		reg.bit.host_set_hw_type = 1;
		if (die_id == VASTAI_DIE0)
			VASTAI_PCI_INFO(priv, die_id, "Host set hw type=%d.\n",
					reg.bit.hw_type);
#else
		reg.bit.host_set_hw_type = 0;
#endif

#ifdef CONFIG_VASTAI_CUS_TYPE
		reg.bit.cus_type = CONFIG_VASTAI_CUS_TYPE;
		if (die_id == VASTAI_DIE0)
			VASTAI_PCI_INFO(priv, die_id, "Host set customer type=%d.\n",
					reg.bit.cus_type);
#else
		reg.bit.cus_type = 0;
#endif

#ifdef CONFIG_VASTAI_AI_EMU
		reg.bit.env_type = VASTAI_EMU;
		VASTAI_PCI_INFO(priv, die_id, "This is emulation environment.\n");
#else
		reg.bit.env_type = VASTAI_SILICON;
#endif
		if (priv->force_single_die) {
			reg.bit.force_single_die = 1;
			VASTAI_PCI_INFO(priv, die_id, "This is forced single die.\n");
		} else {
			if ((priv->bar[VASTAI_PCI_BAR0].mmio_len == (2 * 1024 * 1024)) &&
				(priv->bar[VASTAI_PCI_BAR4].mmio_len == (128 * 1024 * 1024)))
				reg.bit.force_single_die = 1;
			else
				reg.bit.force_single_die = 0;
		}
		if (priv->ddr_bw_test) {
			reg.bit.hw_type = VASTAI_HW_TYPE_DEFAULT;
		}
	} else if(vastai_get_board_type(priv) == SG100) {
		reg.sg_bit.die_id = die_id;
		if (priv->force_single_die)
			reg.sg_bit.force_single_die = 1;
		else
			reg.sg_bit.force_single_die = 0;
	}
	ret = vastai_pci_mem_write_direct(priv, vastai_pci_get_die_index(priv, die_id), reg_addr,
				   &(reg.val), 4);
	if (ret < 0)
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [write] 0x%llx, len=4, val=0x%x, error:%d\n",
			       __func__, reg_addr, reg.val, ret);

	return ret;
}

static int vastai_wait_rw_xspi(struct vastai_pci_info *priv, u32 die_id)
{
	struct vastai_sv100_die *die;
	int ret = 0;

	if (!priv || (priv->die_num_in_fn <= die_id)) {
		return -EINVAL;
	}

	die = &(priv->dies[die_id]);

	/* wait completion int from smcu */
	atomic_set(&(die->xspi_flag), 1);
	if(wait_for_completion_timeout(&(die->rw_xspi),
					msecs_to_jiffies(VASTAI_PCIE_WAIT_XSPI_MSG1_TIME)) <=0) {
		VASTAI_PCI_ERR(priv, die_id,
				"%s completion_timeout\n", __func__);
		return -9;
	}
	if(VASTAI_HOTP_STATE == atomic_read(&priv->pci_state)) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"rw xspi err, hot plug happened \n");
		return -9;
	}
	reinit_completion(&(die->rw_xspi));
	if (die->rw_xspi_msg != VASTAI_XSPI_SUCCESS) {
		VASTAI_PCI_ERR(
			priv, die_id,
			"rw xspi result is 0x%x (1: erase err; 2: read err; 3: write err; 4: unlock err; 5: lock err; 6: chksum err; 7: flag err; 8: wp err; 9: type err)\n",
			die->rw_xspi_msg);
		return -(die->rw_xspi_msg);
	}

	return ret;
}

static int vastai_wait_rw_xspi_sg100(struct vastai_pci_info *priv)
{
	int ret;
	int i;

	/* wait completion int from smcu */
	ret = wait_for_completion_interruptible(&(priv->rw_xspi));
	reinit_completion(&(priv->rw_xspi));
	if (priv->rw_xspi_msg != 0) {
		/* get error index */
		for (i = 0; i < 32; i++) {
			if ((priv->rw_xspi_msg >> i) & 0x1)
				break;
		}
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"rw xspi result is 0x%x (1: erase err; 2: read err; 3: write err; 4: unlock err; 5: lock err; 6: para err; 7: chksum err; 8: chktype err)\n",
			i+1);
		return -(i+1);
	}

	return ret;
}


int send_xspi_flash_cmd(struct vastai_pci_info *priv, u32 die_id,
				enum VASTAI_PCIE_SUBCMD cmd, u32 buf_size)
{
	int ret;

	/* send read xspi cmd to smcu */
	ret = vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index, cmd, buf_size);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "%s send xspi flash cmd failed %d\n",
				__func__, ret);
		return ret;
	}
	ret = vastai_wait_rw_xspi(priv, die_id);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id, "%s wait flash compltion failed %d\n",
				__func__, ret);
	}
	return ret;
}

int send_xspi_flash_cmd_sg100(struct vastai_pci_info *priv, struct pcie_transfer_cmd *ptrans)
{
	int ret;

	ret = vastai_pci_send_msg(priv, 0, COMMON_HOST_TO_SMCU_CMD_BUF, ptrans, 0);
	if (ret != 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s (2/5) write flash cmd err=%d\n",
			       __func__, ret);
		return ret;
	}

	ret = vastai_wait_rw_xspi_sg100(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s wait flash compltion failed %d\n",
				__func__, ret);
	}
	return ret;
}


int vastai_pci_read_xspi(struct vastai_pci_info *priv, u32 die_id,
			 unsigned long addr, void *buf, u32 len,
			 u8 partition, bool origin_addr)
{
	int ret = 0;

	if(vastai_get_board_type(priv) == SV100) {
		if (addr >= BL0_BASE_TOTAL_SIZE ||
			(addr + len) > BL0_BASE_TOTAL_SIZE) {
			VASTAI_PCI_ERR(priv, die_id,
					"%s flash read failed with error ddr. addr 0x%lx len 0x%x",
					__func__, addr, len);
			return -EFAULT;
		}

		/* base and full is same in sv100 -----confirm with Apple.Li */
		if (VASTAI_PCI_FLASH_BASE == partition || VASTAI_PCI_FLASH_FULL == partition)
			ret = send_xspi_flash_cmd(priv, die_id,
						VASTAI_PCIE_SUB_READ_BASE_XSPI,
						BL0_BASE_TOTAL_SIZE);
		else if (partition == VASTAI_PCI_FLASH_BL0)
			ret = send_xspi_flash_cmd(priv, die_id,
						VASTAI_PCIE_SUB_READ_XSPI,
						BL0_APP_TOTAL_SIZE);
		else {
			VASTAI_PCI_ERR(priv, die_id,
					"%s unsupported cmd[%d]\n",
					__func__, partition);
			return -1;
		}
		if (ret) {
			VASTAI_PCI_ERR(priv, die_id, "%s send cmd failed%d\n",
					__func__, ret);
			return ret;
		}

		if(origin_addr)
			ret = vastai_pci_mem_read(priv, priv->dies[die_id].die_index,
						  addr + XSPI_READ_BASE, buf, len);
		else {
			ret = vastai_pci_tl_read(priv, die_id,
						 addr + vastai_get_bl0_read_base_addr(priv),
						 buf, len);
		}
		if (ret < 0)
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s [read] 0x%lx, len=%d, error:%d\n", __func__,
				       addr, len, ret);
	}

	if(vastai_get_board_type(priv) == SG100) {
		size_t bytes = 0;
		size_t offset = 0;
		struct pcie_transfer_cmd trans;
		size_t __size_bk = len;

		while (offset < len) {
			bytes = MIN(len-offset, XSPI_RW_UNIT);
			/* send read xspi cmd to smcu */
			trans.w0.s_data0.optcode = SMCU_XSPI_FW_READ;
			trans.w0.s_data0.rev0 = partition;
			trans.w1.data1 = bytes;
			trans.w2.data2 = offset;
			trans.w3.data3 = __size_bk;

			ret = send_xspi_flash_cmd_sg100(priv, &trans);
			if (ret != 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s send cmd failed%d\n",
					__func__, ret);
				return ret;
			}

			ret = vastai_pci_tl_read(priv, die_id, XSPI_FW_DDR_DL_ADDR, (void*)(buf+offset), bytes);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
						"%s [read] 0x%lx, len=%ld, error:%d\n", __func__,
						offset, bytes, ret);
				return ret;
			}

			/* prepare for the next read */
			offset += bytes;
		}
	}

	return ret;
}

static void vastai_bmcu_timeout_work(struct work_struct *work)
{
	struct vastai_pci_info *priv = NULL;

	priv = container_of(work, struct vastai_pci_info, bmcu_timeout_work.work);

	if(0 == priv->bmcu_dl_addr) {
		priv->bmcu_dl_addr = VASTAI_BMCU_DL_ADDR;
		priv->bl0_dl_addr  = VASTAI_XSPI_DL_ADDR;
		priv->bl0_read_addr = XSPI_READ_BASE;
	}
}


int vastai_pci_new_bmcu_path_confirm(struct vastai_pci_info *priv)
{
	int ret = 0;

	if(vastai_get_board_type(priv) == SV100) {
		int die_id = 0;
		unsigned long timeout_threshold = msecs_to_jiffies(3000); /* 3s */

		if(!priv->bmcu_dl_addr) {
			INIT_DELAYED_WORK(&priv->bmcu_timeout_work, vastai_bmcu_timeout_work);
			schedule_delayed_work(&priv->bmcu_timeout_work,
						timeout_threshold);
		}

		for (die_id = 0; die_id < priv->die_num_in_fn; die_id++)
			ret = vastai_send_smcu_cmd(priv, vastai_pci_get_die_index(priv, die_id),
					VASTAI_SMCU_SUB_NEW_BMCU_PATH, 0);
	}

	if(vastai_get_board_type(priv) == SG100)
		priv->bmcu_dl_addr = BMCU_FW_DDR_DL_ADDR;

	return ret;
}


int vastai_pci_update_flag_xspi(struct vastai_pci_info *priv, u32 die_id,
					u8 partition)
{
	int ret;

	if(vastai_get_board_type(priv) == SV100) {
		/* send read xspi cmd to smcu */
		/* base and full is same in sv100 -----confirm with Apple.Li */
		if (VASTAI_PCI_FLASH_BASE == partition || VASTAI_PCI_FLASH_FULL == partition)
			ret = send_xspi_flash_cmd(priv, die_id,
				     VASTAI_PCIE_SUB_FLAG_BASE_XSPI,
				     BL0_BASE_TOTAL_SIZE);
		else if (partition == VASTAI_PCI_FLASH_BL0)
			ret = send_xspi_flash_cmd(priv, die_id,
				     VASTAI_PCIE_SUB_FLAG_XSPI,
				     BL0_APP_TOTAL_SIZE);
		else {
			VASTAI_PCI_ERR(priv, die_id,
					"%s unsupported cmd[%d]\n",
					__func__, partition);
			return -1;
		}
		if (ret) {

			VASTAI_PCI_ERR(priv, die_id, "%s send cmd failed%d\n",
					__func__, ret);
			return ret;
		}
	}

	if(vastai_get_board_type(priv) == SG100) {
		struct pcie_transfer_cmd trans;

		/* send update xspi flag cmd to smcu */
		trans.w0.s_data0.optcode = SMCU_XSPI_FW_FLAG;
		trans.w0.s_data0.rev0 = partition;

		ret = send_xspi_flash_cmd_sg100(priv, &trans);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s send cmd failed%d\n",
					__func__, ret);
		}
	}

	return ret;
}

int vastai_pci_update_flash_wp(struct vastai_pci_info *priv, u32 die_id,
			 struct char_drv_info *dev, u32 protect_cfg)
{
	int ret;

	if (protect_cfg == 0)
		vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
			     VASTAI_PCIE_SUB_FLASH_WPDIS, 0);
	else
		vastai_send_pcie_cmd(priv, priv->dies[die_id].die_index,
			     VASTAI_PCIE_SUB_FLASH_WPEN, 0);

	ret = vastai_wait_rw_xspi(priv, die_id);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s die%d failed!\n", __func__,
			       die_id);
		return ret;
	}
	return ret;
}

int vastai_pci_set_flash_wp(struct vastai_pci_info *priv, u32 die_id, struct char_drv_info *dev, u32 cfg)
{
	int ret = 0;

	ret = vastai_pci_update_flash_wp(priv, die_id, dev, cfg);
	if (ret < 0) {
		if (cfg == 0)
			VASTAI_PCI_ERR(priv, die_id,
			    "%s die%d disable flash write protect err=%d\n",
			        __func__, die_id, ret);
		else
			VASTAI_PCI_ERR(priv, die_id,
			    "%s die%d enable flash write protect err=%d\n",
			        __func__, die_id, ret);
		return ret;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s die%d update flash write protect successfully!\n",
			__func__, die_id);

	return ret;
}
 extern bool dpm;
int vastai_pci_init_smcu_log(struct vastai_pci_info *priv, u8 die_id)
{
	u32 path = 0;

	vastai_pci_mem_read_direct(priv, die_id,
			     VASTAI_LOGSYS_CTRL_STARTADDR_PATH, &path,
			     sizeof(path));
	path = path & 0xffffff00;
#ifdef CONFIG_VASTAI_SMCU_OB_LOG
	path = path | 0x2;
#else
	path = path | 1;
#endif
	if(priv->not_hotreset)
		path = path | 0x4;
	vastai_pci_mem_write_direct(priv, die_id,
			     VASTAI_LOGSYS_CTRL_STARTADDR_PATH, &path,
			     sizeof(path));

#ifdef CONFIG_VASTAI_SMCU_OB_LOG
	priv->dies[die_id].dma_log_vir = dma_alloc_coherent(&(priv->dev->dev), VASTAI_OB_LOG_SIZE,
							(dma_addr_t *)(&priv->dies[die_id].dma_log_addr),
							GFP_DMA32 | GFP_KERNEL);

	VASTAI_PCI_INFO(priv, die_id, "dma_log_vir[0x%p]\n", priv->dies[die_id].dma_log_vir);
	vastai_pci_mem_write_direct(priv, die_id,
				  OB_LOG_HOST_ADDR, &priv->dies[die_id].dma_log_addr,
				  sizeof(priv->dies[die_id].dma_log_addr));

#endif
	{
		struct vastai_outbound *pOb = NULL;
		priv->dies[die_id].pci_link_stat.dma_vir = (u8*)priv->pci_link_stat.dma_vir +
							VASTAI_OB_HB_SIZE/VASTAI_SV100_MAX_DIE_NUM*die_id;
		pOb = (struct vastai_outbound *)((u8*)priv->pci_link_stat.dma_vir + die_id*1024);
#ifdef CONFIG_VASTAI_PCI_D2D_LINK_ENABLE
		pOb->d2d_link_enable = 1;
#else
		pOb->d2d_link_enable = 0;
#endif

#ifdef CONFIG_VASTAI_PCI_DPM_DISABLE
		if (dpm)
			pOb->dpm_enable = 0; //dpm name is Opposite
		else
			pOb->dpm_enable = 1;
#else
		pOb->dpm_enable = 0;
#endif
		VASTAI_PCI_INFO(priv, die_id, "dpm is %s\n", pOb->dpm_enable ? "disable" : "enable");
	}
	vastai_pci_mem_write_direct(priv, die_id,
					LOG_CTRL_INFO, &priv->pci_link_stat.dma_bus_addr,
					sizeof(priv->pci_link_stat.dma_bus_addr));

	return 0;
}

void vastai_pci_deinit_smcu_log(struct vastai_pci_info *priv, u8 die_id)
{
#ifdef CONFIG_VASTAI_SMCU_OB_LOG
	struct vastai_sv100_die *die = &priv->dies[die_id];

	dma_free_coherent(&priv->dev->dev, VASTAI_OB_LOG_SIZE,
					die->dma_log_vir, (dma_addr_t)die->dma_log_addr);
#endif
}

int vastai_check_ddr(struct vastai_pci_info *priv)
{
	int ret = 0;
	u32 reg_val;

	/* check ddr training status */
	ret = vastai_pci_mem_read_direct(priv, -1, PWRAP_COMMON51, &reg_val, 4);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s read PWRAP_COMMON51 failed.\n", __func__);
		return ret;
	}
	if (0 != (reg_val & 0b1111000)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "DDR training failed, reg addr=%#X, reg val=%#X\n", PWRAP_COMMON51, reg_val);
		return -EIO;
	}

	return ret;
}

extern int vastai_pci_bar_write(struct vastai_pci_info *priv, int bar,
				u64 offset, const void *buf, unsigned int len);
extern void vastai_complete_atu(void *priv);

void vastai_polling_smcu_failed_proc(struct vastai_pci_info *priv, u8 die_id)
{
	u32 reg_addr = SMCU_BOOT_POS_INFO;
	u32 reg_val;

	if (vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
			reg_addr, &reg_val, 4)) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [read] 0x%x, len=4\n",
			       __func__, reg_addr);
		return;
	}
	VASTAI_PCI_ERR(priv, die_id, "%s boot pos is:%d\n",
		       __func__, reg_val);

	return;
}
int wait_bl1_running(struct vastai_pci_info *priv, u8 die_id,int timeout_ms)
{
	int ret = 0;
	union smcu_boot_stage reg;
	u64 reg_addr = ADDR(priv, VASTAI_SMCU_BOOT_STAGE_REG);
	int time_cnt = 0;
	do{
			might_sleep_if(1);
			ret = vastai_pci_mem_read_direct(priv, vastai_pci_get_die_index(priv, die_id),
											reg_addr, &(reg.val), 4);
			if (ret < 0) {
					VASTAI_PCI_ERR(priv, die_id,
											"%s [read] 0x%llx, len=4, error:%d\n",
											__func__, reg_addr, ret);
					break;
			}
			if (reg.bit.stage >= VASTAI_SMCU_BOOT_STAGE_BL1_DONE) {
					break;
			}
			if(time_cnt++ > timeout_ms*1000){
					ret =1;
					break;
			}
	}while(1);
	return ret;
}

int vastai_poll_stage_bl1_ready(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	int ret = 0;
	u32 default_log_level = CONFIG_DEF_LOG_LEVEL;
	u32 reg_val = 0;
	ret = vastai_pci_set_current_die(priv, die_id);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s set current die error\n",
			       __func__);
		return ret;
	}

	if(vastai_get_board_type(priv) == SG100) {
		ret = vastai_check_ddr(priv);
		if(ret)
			return ret;
	} else if(vastai_get_board_type(priv) == SV100) {
		ret = va_register_pcie_interrupt(priv, SMCU_2_HOST_INT2 + die_id*(VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM),
						 vastai_complete_atu, priv);
		if(ret)
			return ret;
	}

	/* download bl1 code to csram. */
	ret = vastai_process_download_request(priv, die_id,
					      ADDR(priv, BL1_PATH), priv->addr->bl1_hex_buf,
					      priv->addr->bl1_size, ADDR(priv, VASTAI_BL1_DL_ADDR));
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s download bl1 error, size=%ld, addr=%lld\n",
			       __func__, priv->addr->bl1_size,
			       ADDR(priv, VASTAI_BL1_DL_ADDR));
		return ret;
	}
	/* PCIe host driver set host.bootstage=1 and addr of bl1 run. */
	ret = vastai_pci_set_host_stage(priv, die_id,
					VASTAI_HOST_BOOT_STAGE_BL1_DONE);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s set host stage[%d] error\n",
			       __func__, VASTAI_HOST_BOOT_STAGE_BL1_DONE);
		return ret;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s%d bl1 download finish!\n", __func__,
			die_id);
	if(wait_bl1_running(priv, die_id,10)){
			VASTAI_PCI_ERR(priv, die_id, "%s bl1 start timeout\n",
					__func__);
	}

	/* print 0x8bc074c reg value in dmesg before it is overwritten */
	ret = vastai_pci_mem_read_direct(priv, die_id, DEFAULT_LOG_LEVEL, &reg_val, 4);
	if (ret) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s [read] 0x%08x, len=4\n",
			       __func__, (u32)DEFAULT_LOG_LEVEL);
		return ret;
	}
	VASTAI_PCI_INFO(priv, die_id, "%s rCHIP_INFO2=0x%08x\n", __func__,reg_val);

	*next_state = VASTAI_SMCU_BOOT_STAGE_FW_READY;
	vastai_pci_mem_write_direct(priv,die_id,
					DEFAULT_LOG_LEVEL,&default_log_level,sizeof(u32));

	return ret;
}

int vastai_poll_stage_fw_ready_sg(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	int ret = 0;

	struct boot_hw_cfg *boot_hw_cfg  = kzalloc(sizeof(struct boot_hw_cfg), GFP_ATOMIC);;

#ifdef CONFIG_POWER_CFG
	boot_hw_cfg->power_cfg = CONFIG_POWER_CFG;
#else
	boot_hw_cfg->power_cfg = 0;
#endif

#ifdef CONFIG_D2H_BY_GART_OR_ATU
	boot_hw_cfg->d2h_by_atu_or_gart = CONFIG_D2H_BY_GART_OR_ATU;
#else
	boot_hw_cfg->d2h_by_atu_or_gart = 0;
#endif
	boot_hw_cfg->outbound_supprt_sriov   = OUTBOUND_SURPORT_SRIOV;
	boot_hw_cfg->power_clk[EVB_CARD].gfx.GCLK   		=  EVB_GFX_GCLK;
	boot_hw_cfg->power_clk[EVB_CARD].video.ECLK 		=  EVB_Video_ECLK;
	boot_hw_cfg->power_clk[EVB_CARD].video.DCLK 		=  EVB_Video_DCLK;
	boot_hw_cfg->power_clk[EVB_CARD].video.VDSPCLK 		=  EVB_Video_VDSPCLK;
	boot_hw_cfg->power_clk[EVB_CARD].video.VCLK	 	=  EVB_Video_VCLK;
	boot_hw_cfg->power_clk[EVB_CARD].ddr.RUCLK	 	=  EVB_DDR_RUCLK;
	boot_hw_cfg->power_clk[EVB_CARD].ddr.LUCLK	 	=  EVB_DDR_LUCLK;
	boot_hw_cfg->power_clk[EVB_CARD].soc.CEDARCLK		=  EVB_SOC_CEDARCLK;
	boot_hw_cfg->power_clk[EVB_CARD].soc.LCCLK	    	=  EVB_SOC_LCCLK;
	boot_hw_cfg->power_clk[EVB_CARD].soc.RCCLK	    	=  EVB_SOC_RCCLK;
	boot_hw_cfg->power_clk[EVB_CARD].soc.BCCLK	    	=  EVB_SOC_BCCLK;
	boot_hw_cfg->power_clk[EVB_CARD].ai.OCLK	    	=  EVB_AI_OCLK;
	boot_hw_cfg->power_clk[EVB_CARD].ai.ODSPCLK	    	=  EVB_AI_ODSPCLK;
	boot_hw_cfg->power_clk[EVB_CARD].dp.PIXCLK_DP		=  EVB_DP_PIXCLK_DP;
	boot_hw_cfg->power_clk[EVB_CARD].power_rail.VDD_GFX	=  EVB_POWER_VDD_GFX;
	boot_hw_cfg->power_clk[EVB_CARD].power_rail.VDD_VID	=  EVB_POWER_VDD_VID;
	boot_hw_cfg->power_clk[EVB_CARD].power_rail.VDD_SOC	=  EVB_POWER_VDD_SOC;

	boot_hw_cfg->power_clk[AIC_CARD].gfx.GCLK   		=  AIC_GFX_GCLK;
	boot_hw_cfg->power_clk[AIC_CARD].video.ECLK 		=  AIC_Video_ECLK;
	boot_hw_cfg->power_clk[AIC_CARD].video.DCLK 		=  AIC_Video_DCLK;
	boot_hw_cfg->power_clk[AIC_CARD].video.VDSPCLK 		=  AIC_Video_VDSPCLK;
	boot_hw_cfg->power_clk[AIC_CARD].video.VCLK	 	=  AIC_Video_VCLK;
	boot_hw_cfg->power_clk[AIC_CARD].ddr.RUCLK	 	=  AIC_DDR_RUCLK;
	boot_hw_cfg->power_clk[AIC_CARD].ddr.LUCLK	 	=  AIC_DDR_LUCLK;
	boot_hw_cfg->power_clk[AIC_CARD].soc.CEDARCLK		=  AIC_SOC_CEDARCLK;
	boot_hw_cfg->power_clk[AIC_CARD].soc.LCCLK	    	=  AIC_SOC_LCCLK;
	boot_hw_cfg->power_clk[AIC_CARD].soc.RCCLK	    	=  AIC_SOC_RCCLK;
	boot_hw_cfg->power_clk[AIC_CARD].soc.BCCLK	    	=  AIC_SOC_BCCLK;
	boot_hw_cfg->power_clk[AIC_CARD].ai.OCLK	    	=  AIC_AI_OCLK;
	boot_hw_cfg->power_clk[AIC_CARD].ai.ODSPCLK	    	=  AIC_AI_ODSPCLK;
	boot_hw_cfg->power_clk[AIC_CARD].dp.PIXCLK_DP		=  AIC_DP_PIXCLK_DP;
	boot_hw_cfg->power_clk[AIC_CARD].power_rail.VDD_GFX	=  AIC_POWER_VDD_GFX;
	boot_hw_cfg->power_clk[AIC_CARD].power_rail.VDD_VID	=  AIC_POWER_VDD_VID;
	boot_hw_cfg->power_clk[AIC_CARD].power_rail.VDD_SOC	=  AIC_POWER_VDD_SOC;

	boot_hw_cfg->power_clk[ZHAOGE_CARD].gfx.GCLK   		=  ZHAOGE_GFX_GCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].video.ECLK 		=  ZHAOGE_Video_ECLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].video.DCLK 		=  ZHAOGE_Video_DCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].video.VDSPCLK 	=  ZHAOGE_Video_VDSPCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].video.VCLK	 	=  ZHAOGE_Video_VCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].ddr.RUCLK	 	=  ZHAOGE_DDR_RUCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].ddr.LUCLK	 	=  ZHAOGE_DDR_LUCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].soc.CEDARCLK	=  ZHAOGE_SOC_CEDARCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].soc.LCCLK	    	=  ZHAOGE_SOC_LCCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].soc.RCCLK	    	=  ZHAOGE_SOC_RCCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].soc.BCCLK	    	=  ZHAOGE_SOC_BCCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].ai.OCLK	    	=  ZHAOGE_AI_OCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].ai.ODSPCLK	    	=  ZHAOGE_AI_ODSPCLK;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].dp.PIXCLK_DP	=  ZHAOGE_DP_PIXCLK_DP;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].power_rail.VDD_GFX	=  ZHAOGE_POWER_VDD_GFX;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].power_rail.VDD_VID	=  ZHAOGE_POWER_VDD_VID;
	boot_hw_cfg->power_clk[ZHAOGE_CARD].power_rail.VDD_SOC	=  ZHAOGE_POWER_VDD_SOC;

	VASTAI_PCI_DBG(priv, 0,"%s boot_hw_cfg->power_cfg=%d\n",__func__,boot_hw_cfg->power_cfg);
	VASTAI_PCI_DBG(priv, 0,"%s boot_hw_cfg->bar4_5_size_cfg=%d\n",__func__,boot_hw_cfg->bar4_5_size_cfg);
	VASTAI_PCI_DBG(priv, 0,"%s boot_hw_cfg->d2h_by_atu_or_gart=%d\n",__func__,boot_hw_cfg->d2h_by_atu_or_gart);
	/* BOOT_HW_CFG_ADDR应该是放错地方了，应该放在0x8e3c00 by xiaodong */
	ret = vastai_pci_bar_write(priv, VASTAI_PCI_BAR2, (BOOT_HW_CFG_ADDR - 0x800000), boot_hw_cfg, sizeof(struct boot_hw_cfg));
	if (ret < 0)
		VASTAI_PCI_ERR(priv, die_id,
				"%s [write] 0x%x, len=%ld, error:%d\n",
				__func__,(BOOT_HW_CFG_ADDR - 0x800000) , sizeof(struct boot_hw_cfg), ret);
	kfree(boot_hw_cfg);

#ifdef CONFIG_VASTAI_PCI_ONLY_DOWNLOAD_BL1
	*next_state = VASTAI_SMCU_STAGE_END;
	return ret;
#endif

	/* download all fw packets. */
	ret = vastai_download_fw_packets(priv, die_id);
	if (ret < 0)
		return ret;

	/* PCIe host driver set host.bootstage=2 and addr of fw download. */
	ret = vastai_pci_set_host_stage(priv, die_id,
					VASTAI_HOST_BOOT_STAGE_FW_DONE);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s set host stage[%d] error\n",
			       __func__, VASTAI_HOST_BOOT_STAGE_FW_DONE);
		return ret;
	}

	*next_state = VASTAI_SMCU_BOOT_STAGE_FW_BOOT_UP;

	return ret;
}

int vastai_poll_stage_fw_ready_sv(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	int ret = 0;
	u32 card_type;
	extern u32 cardtype;
	u32 direct_connec_host = 0;

	if (cardtype != UINT_MAX)
		card_type = cardtype;
	else
		card_type = CONFIG_CARD_TYPE;

#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
	if (atomic_read(&priv->pci_state) == VASTAI_BOOT_STATE && die_id == 1 &&
		atomic_read(&(priv->pci_link_stat.is_reseting))) {
		memcpy(priv->dev->saved_config_space, priv->pci_link_stat.saved_config_space,
			sizeof(priv->pci_link_stat.saved_config_space));
		vastai_pci_config_write(priv, 4*8, (char *)&priv->pci_link_stat.saved_config_space[8], 4);
		vastai_pci_config_write(priv, 4*9, (char *)&priv->pci_link_stat.saved_config_space[9], 4);
		msleep(1);
	}
#endif

#ifdef CONFIG_VASTAI_PCI_ONLY_DOWNLOAD_BL1
	*next_state = VASTAI_SMCU_STAGE_END;
	return ret;
#endif

	/* download all fw packets. */
	ret = vastai_download_fw_packets(priv, die_id);
	if (ret < 0)
		return ret;

	vastai_pci_init_smcu_log(priv, die_id);
	vastai_pci_mem_write_direct(priv, die_id,
					DEFAULT_CARD_TYPE, &card_type, sizeof(u32));

	if(die_id == 0)
		direct_connec_host = 1;
	ret = vastai_pci_mem_write_direct(priv, die_id,
						SMCU_DIRECT_CONNEC_HOST, &direct_connec_host, sizeof(u32));
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s write SMCU_DIRECT_CONNEC_HOST err\n",
			       __func__);
		return ret;
	}

	/* PCIe host driver set host.bootstage=2 and addr of fw download. */
	ret = vastai_pci_set_host_stage(priv, die_id,
					VASTAI_HOST_BOOT_STAGE_FW_DONE);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id, "%s set host stage[%d] error\n",
			       __func__, VASTAI_HOST_BOOT_STAGE_FW_DONE);
		return ret;
	}

	*next_state = VASTAI_SMCU_BOOT_STAGE_DIE_DONE;

	return ret;
}

int vastai_poll_stage_die_done(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	VASTAI_PCI_INFO(priv, die_id, "%s%d fw download finish!\n", __func__,
				die_id);

	if(priv->not_hotreset) {
		priv->die_num       = 1;
		priv->die_num_in_fn = 1;
		*next_state = VASTAI_SMCU_STAGE_END;
	} else
		*next_state = VASTAI_SMCU_BOOT_STAGE_BOOT_DONE;

	return 0;
}

int vastai_get_system_hw_config(struct vastai_sv100_die *die)
{
	int ret = 0;
	struct sv100_system_cfg sys_config;
	u32 size = sizeof(struct sv100_system_cfg);
	struct vastai_pci_info *priv = die->pci_info;
	struct vastai_card_info *card_info = NULL;
	u64 hw_addr = (priv->is_physfn) ? SV100_HW_CONFIG : SV100_HW_VF_CONFIG;

	ret = vastai_pci_mem_read_direct(priv, die->die_index,
					 hw_addr+offsetof(struct sv100_hw_cfg, sys_cfg),
					 &sys_config, size);
	if(ret)
		return ret;
	priv->is_super_pf = sys_config.bitmap.is_super_pf;

	ret = vastai_create_card_info_tree(priv, &card_info, &sys_config);
	if (ret)
		return ret;

	ret = vastai_create_fn_info_tree(priv, sys_config.mb_sn, sys_config.pkg_id,
					 sys_config.die_id);
	if (ret)
		return ret;
	VASTAI_PCI_INFO(priv, vastai_pci_get_die_id(priv, die->die_index),
			"%s pkg_id[0x%x](max range is [0-3]) %s die\n", __func__, sys_config.pkg_id, (sys_config.die_id%2) ? "slave":"master");
	card_info = vastai_get_card_info(priv);
	if(sys_config.die_num_in_fn != 8) {
		priv->die_num = sys_config.die_num_in_fn;
		priv->die_num_in_fn = sys_config.die_num_in_fn;
	} else {
		priv->die_num = 1;
		priv->die_num_in_fn = 1;
	}
	card_info->die_num_in_card = sys_config.bitmap.die_num_in_card;
	card_info->pkg_num_in_card = sys_config.pkg_num;

	vatools_fct_die_num(priv, priv->die_num);

	return ret;
}
extern struct mutex vastai_pci_info_list_lock;
int vastai_get_dev_id_base(struct vastai_pci_info *priv)
{
	struct vastai_pci_info *ploop = NULL;
	char devId = -1;

	if(priv->dev_id_flag)
		return priv->dev_id;
	/* TODO: consider hot-plug */
	mutex_lock(&vastai_pci_info_list_lock);
	list_for_each_entry(ploop, &vastai_pci_info_list, dev_list) {
		if(vastai_get_card_info(ploop) == vastai_get_card_info(priv))
			continue;
		if(ploop->dev_id >= devId) {
			devId = ploop->dev_id;
		}
	}
	mutex_unlock(&vastai_pci_info_list_lock);

	return devId + 1;
}

bool is_first_fn(struct vastai_pci_info *priv)
{
	/* lock? */
	struct vastai_pci_info *first_priv = NULL;
	first_priv = list_first_entry(&(vastai_pci_info_list), struct vastai_pci_info, dev_list);
	return first_priv == priv;
}

struct vastai_card_info *vastai_get_pre_card_info(struct vastai_pci_info *priv)
{
	struct vastai_pci_info *pre_priv = priv;
	struct vastai_pci_info *this_priv = priv;
	struct vastai_card_info *card_info = NULL;
	struct vastai_card_info *pre_fn_card_info = NULL;
	int max_fn_num_in_card = 8;
	u64 tm_begin, tm_end, tm_total_ms;

	card_info = vastai_get_card_info(priv);
	if(!card_info) {
		VASTAI_PCI_ERR(priv, 0,
			"%s get card info err\n", __func__);
		return NULL;
	}

	while(max_fn_num_in_card) {
		msleep(1);
		mutex_lock(&vastai_pci_info_list_lock);
		if(is_first_fn(this_priv)) {
			mutex_unlock(&vastai_pci_info_list_lock);
			return vastai_get_card_info(this_priv);
		}
		mutex_unlock(&vastai_pci_info_list_lock);
		tm_begin = ktime_to_ms(ktime_get());
		do {
			mutex_lock(&vastai_pci_info_list_lock);
			if(!is_first_fn(this_priv))
				pre_priv = list_prev_entry(this_priv, dev_list); /* pre_priv maybe boot fail */
			else
				pre_priv = this_priv;
			if(pre_priv->boot_failed_flag) {
				/* va1 and va16 is diff */
				pre_fn_card_info = vastai_get_card_info(pre_priv);
				if(pre_fn_card_info) {
					if(pre_fn_card_info != card_info) {
						mutex_unlock(&vastai_pci_info_list_lock);
						return pre_fn_card_info;
					}
				}
				//mutex_unlock(&vastai_pci_info_list_lock);
				//max_fn_num_in_card--;
				break;
			}

			pre_fn_card_info = vastai_get_card_info(pre_priv); /* performance issue, maybe get fail*/
			if(pre_fn_card_info) {
				break;
			}

			tm_end = ktime_to_ms(ktime_get());
			tm_total_ms = tm_end - tm_begin;
			if (tm_total_ms > CONFIG_VASTAI_POLL_BOOT_STAGE_MS) {
				this_priv = pre_priv;
				mutex_unlock(&vastai_pci_info_list_lock);
				/* pre_card is blocked */
				VASTAI_PCI_ERR(priv, 0, "%s pre_card maybe block\n", __func__);
				return NULL;
			}
			mutex_unlock(&vastai_pci_info_list_lock);
			msleep(VASTAI_BOOT_POLL_SLEEP_MS);
		} while(1);

		if((pre_fn_card_info != card_info) && (NULL != pre_fn_card_info)) {
			mutex_unlock(&vastai_pci_info_list_lock);
			return pre_fn_card_info;
		}
		mutex_unlock(&vastai_pci_info_list_lock);
		this_priv = pre_priv;
		max_fn_num_in_card--;
	}

	return NULL;
}

/* consider va16/va100 maybe remove some function, we should re_calc base dev_id */
u8 vastai_re_calc_base_dev_id(struct vastai_pci_info *priv)
{
	struct vastai_card_info *pre_card_info = NULL;
	u32 retry_cnt = 15;

	pre_card_info = vastai_get_pre_card_info(priv);
	if(!pre_card_info)
		return -1;

	if(pre_card_info == vastai_get_card_info(priv)) /* first card */
		return 0;
	/* TODO: set pre_card_info->dev_id_base */
	retry_cnt = 20000 * priv->dev_id;
	while(1) {
		if(pre_card_info->dev_id_set_flag)
			break;
		retry_cnt--;
		if(retry_cnt == 0) {
			VASTAI_PCI_ERR(priv, 0,
					"%s get dev_id_set_flag failed\n",
					__func__);
			/* consider how to handle err */
			return -1;
		}
		msleep(1);
	}
	return pre_card_info->dev_id_base + pre_card_info->fn_num;
}

int vastai_poll_stage_boot_done(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	u32 pcie_nls, pcie_nlw;
	int ret = vastai_die_init(&(priv->dies[die_id]), priv, die_id);
	struct vastai_card_info *card_info = NULL;
	struct vastai_die_info *die_info = NULL;
	char dev_id_base = 0;

	if(ret)
		return ret;

	ret = vastai_get_system_hw_config(&(priv->dies[die_id]));
	if(ret) {
		VASTAI_PCI_ERR(priv, die_id,
			"%s ret[%d]\n",
			__func__, ret);
		return ret;
	}
	card_info = vastai_get_card_info(priv);
	die_info  = vastai_get_die_info(priv, die_id);
	if((card_info->die_num_in_card != priv->die_num_in_fn || parallel_load) && !priv->dev_id_flag) {
		dev_id_base = vastai_re_calc_base_dev_id(priv);
		if(dev_id_base == -1) {
			VASTAI_PCI_ERR(priv, die_id,
					"%s calc_base_dev_id err\n",
					__func__);
			return -1;
		}
		card_info->dev_id_base = dev_id_base;
		card_info->dev_id_set_flag = true;
		if(1) {
			mutex_lock(&vastai_pci_info_list_lock);
			priv->dev_id = dev_id_base + die_info->die_id_in_card;
			mutex_unlock(&vastai_pci_info_list_lock);
		}
		priv->dies[die_id].die_index = vastai_pci_gen_die_index_parallel_die(priv, die_id);
		priv->dev_id_flag = true;
		VASTAI_PCI_INFO(priv, die_id,
			       "%s after die_index[0x%x]\n",
			       __func__, priv->dies[die_id].die_index);
	} else if((card_info->die_num_in_card != priv->die_num_in_fn || parallel_load) && priv->dev_id_flag) {
		priv->dies[die_id].die_index = vastai_pci_gen_die_index_parallel_die(priv, die_id);
		VASTAI_PCI_INFO(priv, die_id,
			       "%s after die_index[0x%x]\n",
			       __func__, priv->dies[die_id].die_index);
	}
	ret = vastai_die_get_pcie_attr(&(priv->dies[die_id]));
	if(ret) {
		VASTAI_PCI_ERR(priv, die_id,
			"%s ret[%d]\n",
			__func__, ret);
		return ret;
	}
	if (die_id == 0) {
		pcie_nls = priv->dies[die_id].pcie_nls[0];
		pcie_nlw = priv->dies[die_id].pcie_nlw[0];
	} else {
		if (die_id % 2) {
			pcie_nls = priv->dies[die_id].pcie_nls[1];
			pcie_nlw = priv->dies[die_id].pcie_nlw[1];
		} else {
			pcie_nls = priv->dies[die_id].pcie_nls[2];
			pcie_nlw = priv->dies[die_id].pcie_nlw[2];
		}
	}

	VASTAI_PCI_INFO(priv, die_id,
			"%s dev%d-die%d(%d/%d) GEN%dx%d boot finish!\n",
			__func__, priv->dev_id,
			die_id, (die_id + 1), priv->die_num_in_fn,
			pcie_nls, pcie_nlw);
	*next_state = VASTAI_SMCU_STAGE_END;

	return ret;
}

int vastai_poll_stage_boot_up(struct vastai_pci_info *priv, u8 die_id, int *next_state)
{
	int ret = 0;

	/* PCIe host driver set host.bootstage and addr of fw download */
	ret = vastai_pci_set_host_stage(priv, die_id, VASTAI_HOST_BOOT_STAGE_RCV_FW_BOOT_UP_ACK);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, die_id,
			       "%s set host stage[%d] error\n",
			       __func__, VASTAI_HOST_BOOT_STAGE_RCV_FW_BOOT_UP_ACK);
		return ret;
	}

	VASTAI_PCI_INFO(priv, die_id, "%s PKG[%d]: all the FW downloaded & booted up.\n", __func__, die_id);

	*next_state = VASTAI_SMCU_STAGE_END;

	return ret;
}

int vastai_loop_smcu_stage(struct vastai_pci_info *priv, u8 die_id, int start_state, int *next_state)
{
	int ret = 0;
	int i = 0;

	for(i=0; i<priv->addr->boot_size; i++) {
		if(start_state == priv->addr->boot_process[i].smcu_polling_stage) {
			ret = vastai_pci_poll_smcu_stage(priv, die_id,
							 priv->addr->boot_process[i].smcu_polling_stage);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, die_id, "%s poll smcu stage[%d] error\n",
					       __func__, priv->addr->boot_process[i].smcu_polling_stage);
				if(priv->addr->boot_process[i].p_func_polling_failed)
					priv->addr->boot_process[i].p_func_polling_failed(priv, die_id);
				return ret;
			}

			ret = priv->addr->boot_process[i].p_func(priv, die_id, next_state);
			if(ret) {
				VASTAI_PCI_ERR(priv, die_id, "%s poll smcu stage[%d] mapping function error\n",
						__func__, priv->addr->boot_process[i].smcu_polling_stage);
				return ret;
			}
			break;
		}
	}

	return ret;
}

int vastai_pci_boot_die(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;
	int next_state = 0;
	int start_state = VASTAI_SMCU_BOOT_STAGE_BL1_READY;

	VASTAI_PCI_DBG(priv, die_id, "%s To download SW FW, for die_id=%d\n", __func__, die_id);

	while(next_state != VASTAI_SMCU_STAGE_END) {
		ret = vastai_loop_smcu_stage(priv, die_id, start_state ,&next_state);
		if(ret < 0) {
			return ret;
		}
		start_state = next_state;
	}

	return ret;
}

int vastai_device_send_reset(struct vastai_pci_info *priv)
{
	int ret = 0;
	int die_id = 0;
	struct vastai_pci_info *peer = NULL;

	for (die_id = priv->die_num_in_fn - 1; die_id >= 0; die_id--) {
		u8 peer_die_id = die_id;
		if(priv->die_num_in_fn == 1) {
			peer = vastai_get_peer_priv(priv, &peer_die_id);
			if(peer) {
				vastai_send_pcie_cmd_spe(peer, priv->dies[peer_die_id].die_index,
								VASTAI_PCIE_SUB_PEER_DIE_DN, 0);
				if(wait_for_completion_timeout(&(peer->dies[peer_die_id].wait_dn_ack),
						msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <=0) {
					VASTAI_PCI_ERR(peer, peer_die_id,
							"%s completion_timeout\n", __func__);
				}
				reinit_completion(&(peer->dies[peer_die_id].wait_dn_ack));
			}
		}
		ret = vastai_send_pcie_cmd(priv,
				vastai_pci_get_die_index(priv, die_id),
				VASTAI_PCIE_SUB_RESET, 0);
	}
	return ret;
}

int vastai_device_reset(struct vastai_pci_info *priv, u32 flags)
{
	int ret = 0;
	int die_id = 0;

	if (priv->is_virtfn) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "Resets unsupported by VF\n");
		return ret;
	}
	if (is_vastai_probe_done(priv)) {
		vastai_del_file(priv);
		vastai_remove_hotplug_handle(priv);
	}
	if (flags & VASTAI_RESET_MSG_TRIGER
		&& atomic_read(&priv->pci_state) != VASTAI_RESET_STATE) {
		u32 host_boot_stage;
		int count = 200;

#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
		vastai_enable_pcie_link_monitor(priv, false);
#endif

		/* reset cmd need smcu response. It only can work in
			VASTAI_NORMAL_STATE. Will try to reset when state is
			VASTAI_ERROR_STATE, but not sure will be success */
		/* if reset is success, pcie_state will turn to
			VASTAI_NO_RUNNING_STATE */
		if ((atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE)
			&& (atomic_read(&priv->pci_state) != VASTAI_ERROR_STATE)
			&& (atomic_read(&priv->pci_state) != VASTAI_DEBUG_STATE)) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s: reset from %s is Unexpected\n", __func__,
				state_name(vastai_get_pci_state(priv)));
			ret = -EIO;
			goto failed;
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"%s: triger device reset by msg\n", __func__);
		ret = vastai_device_send_reset(priv);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: send reset msg error, %d\n",
				       __func__, ret);
		}
#if 0
		atomic_set(&priv->pci_state, VASTAI_RESET_STATE);
#else
		vastai_pci_state_reset_start(priv);
#endif
		ssleep(VASTAI_WAITING_RESET);
		do {
			msleep(100);
			vastai_pci_mem_read_direct(priv, priv->dies[0].die_index,
						   ADDR(priv, VASTAI_HOST_BOOT_STAGE_REG),
						   &host_boot_stage, 4);
		} while ((host_boot_stage != 0) && count--);

		if (count > 0) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "reset success\n");
#if 0
			atomic_set(&priv->pci_state, VASTAI_NO_RUN_STATE);
#else
			vastai_pci_state_reset_done(priv);
#endif
		} else {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "reset failed\n");
			ret = -EIO;
			goto failed;
		}
	}

	/* clear all completion and workqueue */
	/* TODO: kill all task */
	/* re-initial data */

	// vastai_pci_resource_recycling(priv);
	if (flags & VASTAI_RESET_BOOT_DEV) {
		int i;
		u8 peer_die_id = die_id;
		struct vastai_pci_info *peer = NULL;
		if (vastai_get_pci_state(priv) != VASTAI_NO_RUN_STATE) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s: current device state is %s, can't boot again\n",
				__func__, state_name(vastai_get_pci_state(priv)));
			return -EPERM;
		}
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s: reboot device\n",
				__func__);
		memset(priv->pci_link_stat.dma_vir, 0, VASTAI_OB_HB_SIZE);
#ifdef CONFIG_VASTAI_PCI_BOOT
		/* move to reset section */
		for (i = 0; i < VASTAI_PCI_BAR_NUM; i++) {
			int flag = pci_resource_flags(priv->dev, i);
			if (!(flag & IORESOURCE_MEM))
				continue;
			vastai_pci_init_bar_at(priv, i);
		}
		/* remove this */
		ret = vastai_pci_poll_smcu_stage(priv, VASTAI_DIE0,
					 VASTAI_SMCU_BOOT_STAGE_BL1_READY);
		if (ret) {
			VASTAI_PCI_ERR(priv, VASTAI_DIE0,
				       "%s poll stage[%d] error, %d\n", __func__,
				       VASTAI_SMCU_BOOT_STAGE_BL1_READY, ret);
			return -EIO;
		}
		ret = vastai_pci_boot(priv);
		if (ret) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s: reboot device error, %d\n",
				       __func__, ret);
			goto failed;
		}

		if(priv->die_num_in_fn == 1) {
			peer = vastai_get_peer_priv(priv, &peer_die_id);
			if(peer && (atomic_read(&peer->pci_state) == VASTAI_NORMAL_STATE)) {
				vastai_send_pcie_cmd(peer,
					vastai_pci_get_die_index(peer, peer_die_id),
					VASTAI_PCIE_SUB_PEER_DIE_DN, 1);
				if(wait_for_completion_timeout(&(peer->dies[peer_die_id].wait_dn_ack),
						msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <=0) {
					VASTAI_PCI_ERR(peer, peer_die_id,
							"%s completion_timeout\n", __func__);
				}
				reinit_completion(&(peer->dies[peer_die_id].wait_dn_ack));
			}
		}
#endif
#ifdef CONFIG_VASTAI_PCI_LINK_MONITOR
		if (atomic_read(&priv->pci_state) == VASTAI_NORMAL_STATE &&
			priv->ddr_bw_test == 0)
			vastai_enable_pcie_link_monitor(priv, true);
#endif
	}

	if (is_vastai_probe_done(priv)) {
		for (die_id = 0; die_id < priv->die_num_in_fn; die_id++) {
			event_notify(priv,
			priv->dies[die_id].die_index,
			CORE_TOTAL_NUM, RESET_START);
		}
		vastai_clear_exception_status(priv);
	}
	return 0;

failed:
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s: disable device\n", __func__);

	return ret;
}

bool is_old_driver_version(struct vastai_pci_info *pci_info)
{
	int ret;
	u64 hw_addr = (pci_info->is_physfn) ? SV100_HW_CONFIG : SV100_HW_VF_CONFIG;
	struct sv100_system_cfg sys_config = {0};
	u32 size = sizeof(struct sv100_system_cfg);

	ret = vastai_pci_mem_read_direct(pci_info, 0,
					 hw_addr+offsetof(struct sv100_hw_cfg, sys_cfg),
					 &sys_config, size);
	if(ret)
		return ret;

	if((sys_config.die_id>=8) || (sys_config.die_num_in_fn>4) || (sys_config.pkg_id>=4) || (sys_config.pkg_num>4) ||
		(sys_config.die_num_in_fn==0) || (sys_config.pkg_num==0)) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s:origin driver is old ver\n",
			__FUNCTION__);
		return true;
	} else {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s:origin driver is new ver.\n",
			__FUNCTION__);
		return false;
	}
}

void vastai_pci_reinit(struct vastai_pci_info *pci_info)
{
	int ret;
	union smcu_boot_stage smcu_reg;
	int i;

	ret = vastai_pci_mem_read_direct(pci_info, -1, ADDR(pci_info, VASTAI_SMCU_BOOT_STAGE_REG),
					&(smcu_reg.val), 4);
	if (ret) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s:can not read smcu stage.\n",
			__FUNCTION__);
		return;
	}

	if (smcu_reg.bit.stage != VASTAI_SMCU_BOOT_STAGE_WHILE_1 &&
		(smcu_reg.bit.stage != VASTAI_SMCU_BOOT_STAGE_BOOT_DONE)) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s:stage is not 6/7, do not need to reset\n",
			__FUNCTION__);
		return;
	}

	vastai_pci_state_boot_done(pci_info);

	pci_info->dies[0].pci_info = pci_info;
	if(is_old_driver_version(pci_info)) {
		int die_id = 0;
		pci_info->die_num = vastai_pci_read_die_num(pci_info, 0);
		pci_info->die_num_in_fn = pci_info->die_num;
		pci_info->is_physfn = true;
		for(die_id=0; die_id<pci_info->die_num_in_fn; die_id++) {
			pci_info->dies[die_id].pci_info = pci_info;
			pci_info->dies[die_id].die_index = die_id; /* this is fake */
			vastai_die_msgq_init(&(pci_info->dies[die_id]));
		}
	} else {
		vastai_get_system_hw_config(&pci_info->dies[0]);
		vastai_pci_init_all_die(pci_info);
	}

	ret = vastai_device_reset(pci_info, VASTAI_RESET_MSG_TRIGER);
	if (ret) {
		VASTAI_PCI_INFO(pci_info, DUMMY_DIE_ID, "%s:reset failed.\n",
			__FUNCTION__);
		return;
	}
	for (i = 0; i < VASTAI_PCI_BAR_NUM; i++) {
		int flag = pci_resource_flags(pci_info->dev, i);
		if (!(flag & IORESOURCE_MEM))
			continue;
		vastai_pci_init_bar_at(pci_info, i);
	}
}

#ifdef CONFIG_TRAP_MSIX_ACCESS
int vastai_set_die_msix_table(struct vastai_pci_info *priv, u32 die_id)
{
	u32 reg_val;
	u64 reg_addr;
	int ret = 0;
	u32 die_index = VASTAI_GET_DIE_INDEX(priv, die_id);
	unsigned long saved_atu_addr = priv->bar[VASTAI_PCI_BAR2].at_addr;

	reg_addr = VASTAI_PCIE_EP_CONFIG_MSIX_CTRL;
	ret = vastai_pci_mem_read_direct(priv, die_index,
					 reg_addr, &reg_val, 4);
	reg_val |= 0x80000000;
	ret |= vastai_pci_mem_write_direct(priv, die_index,
					  reg_addr, &reg_val, 4);
	ret |= vastai_pci_mem_write_direct(priv, die_index, PCIE_MSIX_PF_TABLE,
					  &priv->msix_table[(VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM) * die_id],
					  ((VASTAI_PCIE_MSIX_SV100_NUM / VASTAI_SV100_MAX_DIE_NUM) * sizeof(struct msi_x_table)));

	/*switch back bar2*/
	ret |= vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, saved_atu_addr);

	return ret;
}
#endif

int vastai_switch_die0_atu(struct vastai_pci_info *priv, u32 sub_cmd, u64 addr)
{
	int ret = 0;
	int bar = (sub_cmd == VASTAI_PCIE_SUB_BAR2_ATU) ? VASTAI_PCI_BAR2 : VASTAI_PCI_BAR4;

	init_completion(&priv->switch_atu_comp);
	ret = vastai_send_pcie_cmd_spe(priv,
			vastai_pci_get_die_index(priv, VASTAI_DIE0),
			sub_cmd, addr);
	if(ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s sub_cmd[%u] atu error ret[%d]\n",
			       __func__, sub_cmd, ret);
		return ret;
	}
	if(wait_for_completion_timeout(&priv->switch_atu_comp,
					msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <=0) {
		VASTAI_PCI_ERR(priv,
			       DUMMY_DIE_ID,
			       "%s bar sub_cmd[%u] wait_for_completion error %d\n",
			       __FUNCTION__, sub_cmd, ret);
	}

	priv->bar[bar].at_addr = addr;

	return ret;
}

// To get the boot lock named PWRAP_COMMON_LOCK0 for current PF. If non 0, succeed to get the lock. otherwise 0: failed.
static int vastai_poll_boot_lock(struct vastai_pci_info *priv)
{
	int ret = 0, poll_cnt = 0;
	u32 val = 0;
	u64 reg_addr  = PWRAP_COMMON_LOCK0;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "host boot drv stage:%d. PF[%d] will try getting the common boot lock.\n",  priv->boot_stage, priv->dev->devfn);

	do {
		ret = vastai_pci_mmio_read(priv, VASTAI_PCI_BAR1, (PWRAP_COMMON_LOCK0 - PCIE_WRAPPER_ADDR), &val, 4);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				       "%s [read] 0x%llx, len=4, error:%d, failed to get the COMMON_LOCK0.\n",
				       __func__, reg_addr, ret);
			break;
		}

		if (val > 0) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%ds later, PF%d gets the common boot lock successfully. lock val=%#x\n", (poll_cnt / 1000), priv->dev->devfn, val);
			break;
		}

		if (poll_cnt++ > VASTAI_BOOT_LOCK_POLL_SLEEP_CNT) {
			VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s poll common lock0[%#llx], but lock still %d. %ds timeout!\n",
				__func__, reg_addr, val,
				(VASTAI_BOOT_POLL_SLEEP_CNT / 1000));
			return -ETIMEDOUT;
		}

		msleep(VASTAI_BOOT_POLL_SLEEP_MS);
	} while (1);

	return ret;
}

// To release the common boot lock by writing a initial val to the lock.
// Make sure current PF gets the boot lock before calling the func.
static int vastai_release_boot_lock(struct vastai_pci_info *priv)
{
	int ret = 0;
	u32 reg_val  = PWRAP_COMMON_LOCK0_VAL;

	ret = vastai_pci_mmio_write(priv, VASTAI_PCI_BAR1, (PWRAP_COMMON_LOCK0 - PCIE_WRAPPER_ADDR), &reg_val, 4);

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s ret:%d\n", __func__, ret);

	return ret;
}

// Func: poll SMCU FW of master pkg whether switching boot slave bar atu is ready.
//       From Bar2
static int vastai_pci_poll_master_atu_state(struct vastai_pci_info *priv, u8 die_id)
{
	int ret, poll_cnt = 0;
	u32 val = 0;
	u64 reg_addr  = PWRAP_COMMON_HOST_ONLY4;
	u32 atu_stage = BIT_MASTER_ATU_BOOT_SLAVE_BAR_READY;
	u32 bar2_pwrap_offset = SPACE_SIZE_1M - SPACE_SIZE_12K + SPACE_SIZE_4K;

	VASTAI_PCI_DBG(priv, die_id, "%s die_id=%d\n", __func__, die_id);

	do {
		ret = vastai_pci_mmio_read(priv, VASTAI_PCI_BAR2, bar2_pwrap_offset + (PWRAP_COMMON_HOST_ONLY4 - PCIE_WRAPPER_ADDR), &val, 4);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, die_id,
				       "%s [read] 0x%llx, len=4, error:%d\n",
				       __func__, reg_addr, ret);
			break;
		}

		if (val == atu_stage) {
			VASTAI_PCI_INFO(priv, die_id, "%s %ds later, atu_stage=0x%x ready.\n", __func__, (poll_cnt / 1000), atu_stage);
			break;
		}

		if (poll_cnt++ > VASTAI_BOOT_POLL_SLEEP_CNT) {
			VASTAI_PCI_ERR(priv, die_id,
				"%s poll stage=%#x, but value=%#x, %ds timeout!\n",
				__func__, atu_stage, val,
				(VASTAI_BOOT_POLL_SLEEP_CNT / 1000));
			return -ETIMEDOUT;
		}
		msleep(VASTAI_BOOT_POLL_SLEEP_MS);

	} while (1);

	return ret;
}

// Func: signal the master pkg in FW that slave pkg is init done.
//       From Bar2
static int vastai_pci_notify_master(struct vastai_pci_info *priv, u8 die_id)
{
	int ret = 0;
	u32 reg_val = 0;
	u32 bar2_pwrap_offset = SPACE_SIZE_1M - SPACE_SIZE_12K + SPACE_SIZE_4K;

	reg_val = SMCU_SLAVE_DIE_BOOT_DONE;
	ret = vastai_pci_mmio_write(priv, VASTAI_PCI_BAR2, bar2_pwrap_offset + (PWRAP_COMMON_HOST_ONLY0 - PCIE_WRAPPER_ADDR), &reg_val, 4);

	VASTAI_PCI_INFO(priv, die_id, "%s: die_id=%d, reg_val=%#x\n", __func__, die_id, reg_val);

	return ret;
}


int vastai_pci_boot(struct vastai_pci_info *priv)
{
	u8 i = 0, pre_die;
	int ret;
	struct priv_hw_cfg *priv_hw_cfg = NULL;

	VASTAI_PCI_FUNC_ENTERY;
	vastai_pci_reinit(priv);

	ret = vastai_pci_state_boot_start(priv);
	if (ret != VASTAI_STATE_TRANSIT_SUCCESS) return ret;

	if(vastai_get_board_type(priv) == SG100)
		vastai_poll_boot_lock(priv);

	if(vastai_get_board_type(priv) == SV100)
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "reset type:%d\n",
			vatsai_pci_reset_type(priv));
	/* boot die0 */
	ret = vastai_pci_boot_die(priv, VASTAI_DIE0);
	if (ret) {
		VASTAI_PCI_ERR(priv, VASTAI_DIE0,
			       "%s dev%d-die%d boot error\n",
			       __func__, priv->dev_id, VASTAI_DIE0);
		return ret;
	}
	if(priv->not_hotreset)
		return ret;

	/* get die number from die0 */
	if(vastai_get_board_type(priv) == SG100) {
		priv->die_num_in_fn = vastai_pci_read_die_num(priv, 0);
		if(priv->die_num_in_fn == 1) {
			goto OUT;
		}
		// only boot slave pkg when reinit rst slave
		if(priv->priv_hw_cfg != NULL) {
			priv_hw_cfg = priv->priv_hw_cfg;
			if(priv_hw_cfg->sys_cfg.pkg_id == SLAVE_PKG) {
				VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s\n", "Boot slavepkg separately...");
				goto OUT;
			}
		}

		if (priv->force_single_die) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "Force Single Die Mode\n");
			goto OUT;
		}
	}

#ifndef CONFIG_TRAP_MSIX_ACCESS
	if(vastai_get_board_type(priv) == SV100)
		if (priv->irq_type == VASTAI_MSIX_IRQ)
			vastai_pci_refresh_msix_table(priv);
#endif
	/* boot other dies */
	for (i = VASTAI_DIE1; i < priv->die_num_in_fn; i++) {
		pre_die = i - 1;

		if(vastai_get_board_type(priv) == SV100) {
			ret = vastai_pci_poll_die_linkup(priv, pre_die);
			if (ret < 0)
				return ret;
			/* set master die bar2 atu to 0x10_0800_0000, 0x20_0800_0000, 0x30_0800_0000 */
			if(priv->bar[VASTAI_PCI_BAR2].minish_bar_size == 1) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, VASTAI_PCIE_EP_IO_SPACE_ADDR(i));
				if(ret) {
					return ret;
				}
			}
			if(priv->bar[VASTAI_PCI_BAR4].minish_bar_size == 1) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, VASTAI_DDR_FW_DL_ADDR(i));
				if(ret) {
					return ret;
				}
			} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (128*1024*1024*1024ULL)) {
				u64 addr = 0;
				addr = 0x2000000000;
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, addr);
				if(ret) {
					return ret;
				}
			} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (64*1024*1024*1024ULL)) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, 0x4000000000);
				if(ret) {
					return ret;
				}
			} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (4*1024*1024*1024ULL)) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, 0x4000000000);
				if(ret) {
					return ret;
				}
			} else {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, VASTAI_DDR_FW_DL_ADDR2(i));
				if(ret) {
					return ret;
				}
			}

			ret = vastai_pci_die_enumeration(priv, i);
			if (ret) {
				VASTAI_PCI_ERR(priv, i,
					       "%s dev%d-die%d enumeration error\n",
					       __func__, priv->dev_id, i);
				return ret;
			}

			if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (128*1024*1024*1024ULL) || \
				priv->bar[VASTAI_PCI_BAR4].mmio_len == (64*1024*1024*1024ULL)) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, VASTAI_DDR_FW_DL_ADDR2(i));
				if(ret) {
					return ret;
				}
			} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (4*1024*1024*1024ULL)) {
				ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, VASTAI_DDR_FW_DL_ADDR(i));
				if(ret) {
					return ret;
				}
			}
		}else if(vastai_get_board_type(priv) == SG100) {
#ifdef CONFIG_ENV_EMULATOR
			// poll master pkg linkup info with host RC
			vastai_pci_poll_die_linkup(priv, pre_die);
#endif

#ifdef CONFIG_ENV_SILICON
			msleep(2000);
#endif
			// poll SMCU FW of master pkg whether switching boot slave bar atu is ready.
			ret = vastai_pci_poll_master_atu_state(priv, pre_die);
			if (ret) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
					       "%s failed to boot slave PKG[%d] due to getting master pkg switch boot slave ATU TIMEOUT.\n", __func__, i);
				return ret;
			}
		}

		ret = vastai_pci_boot_die(priv, i);
		if (ret) {
			VASTAI_PCI_ERR(priv, i,
				       "%s dev%d-die%d boot error\n",
				       __func__, priv->dev_id, i);
			return ret;
		}

		if(vastai_get_board_type(priv) == SV100) {
#ifdef CONFIG_TRAP_MSIX_ACCESS
			/* To switch BAR 2/3, sw resources need to be ready */
			if (priv->irq_type == VASTAI_MSIX_IRQ) {
				msleep(2); // smcu may not reset bar2 and bar4's addr immediately, wait for while
				vastai_pci_refresh_msix_table(priv);
				vastai_set_die_msix_table(priv, i);
			}
#endif

			init_completion(&priv->switch_atu_comp);
			/* set slave die atu */
			vastai_pci_set_host_stage(
				priv, i, VASTAI_HOST_BOOT_STAGE_SET_BAR_PHASE1);
			if(wait_for_completion_timeout(&priv->switch_atu_comp,
							msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <=0) {
				VASTAI_PCI_ERR(priv,
					       DUMMY_DIE_ID,
					       "%s die_id[%d] wait_for_completion error %d\n",
					       __FUNCTION__, i, ret);
			}

			vastai_pci_die_enumeration_bh(priv, i);
			ret = vastai_pci_poll_host_stage(
				priv, i, VASTAI_HOST_BOOT_STAGE_INIT);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, i,
					       "%s set slave die atu fail!\n",
					       __func__);
				return ret;
			}
		}else if(vastai_get_board_type(priv) == SG100) {
			VASTAI_PCI_DBG(priv, DUMMY_DIE_ID, "%s wait for PKG[%d] VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY!!!!\n", __func__, i);
			/* wait & check Slave PKG smcu PCIe init done */
			ret = vastai_pci_poll_smcu_stage(priv, i, VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, pre_die, "%s poll PKG[%d] smcu stage[%d] error\n", __func__, i, VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY);
			}
			// notifiy slave die: ACK
			vastai_pci_set_host_stage(priv, i,  VASTAI_HOST_BOOT_STAGE_RCV_PCIE_INIT_READY_ACK);

			// notify master SMCU that slave pkg init done.  //FIXME: To check here.
			vastai_pci_notify_master(priv, pre_die);
		}
	}

	if(vastai_get_board_type(priv) ==SV100) {
		/* init software manage source */
#ifndef CONFIG_VASTAI_AI_EMU
		if(priv->die_num_in_fn > 1) {
			ret = avfg_set_die_avfs(priv,0);
			if(priv->die_num_in_fn > 3) {
				ret = avfg_set_die_avfs(priv,2);
			}
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s:set die avfs is fail %d\n",
				pci_name(priv->dev), ret);
			}
		}
#endif
		if(priv->bar[VASTAI_PCI_BAR2].minish_bar_size == 1) {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, VASTAI_PCIE_BAR2_AXI_ADDR_32MB_2);
			if(ret) {
				return ret;
			}
		} else {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR2_ATU, VASTAI_PCIE_BAR2_AXI_ADDR_32GB);
			if(ret) {
				return ret;
			}
		}
		if(priv->bar[VASTAI_PCI_BAR4].minish_bar_size == 1) {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, VASTAI_PCIE_BAR4_AXI_ADDR_128MB_2);
			if(ret) {
				return ret;
			}
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (64*1024*1024*1024ULL)) {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, 0x4000000000);
			if(ret) {
				return ret;
			}
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (128*1024*1024*1024ULL)) {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, 0x2000000000);
			if(ret) {
				return ret;
			}
		} else if(priv->bar[VASTAI_PCI_BAR4].mmio_len == (4*1024*1024*1024ULL)) {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, 0x4000000000);
			if(ret) {
				return ret;
			}
		} else {
			ret = vastai_switch_die0_atu(priv, VASTAI_PCIE_SUB_BAR4_ATU, VASTAI_PCIE_BAR4_BASEX_32G_OUT);
			if(ret) {
				return ret;
			}
		}
		/* boot finish, set host boot stage */
		for (i = VASTAI_DIE0; i < priv->die_num_in_fn; i++)
			vastai_pci_set_host_stage(priv, i,
						  VASTAI_HOST_BOOT_STAGE_READY);

		for (i = VASTAI_DIE0; i < priv->die_num_in_fn; i++) {
			ret = vastai_pci_poll_smcu_stage(priv, i,
							 VASTAI_SMCU_BOOT_STAGE_WHILE_1);
			if (ret < 0) {
				VASTAI_PCI_ERR(priv, i, "%s poll smcu stage[%d] error\n",
					       __func__, VASTAI_SMCU_BOOT_STAGE_WHILE_1);
				return ret;
			}
		}
	}
	if(vastai_get_board_type(priv) ==SG100) {
OUT:
		// Be sure: msleep, Master die switch ATU to PCIE_INIT_READY done
		msleep(100);
		/* wait & check Mask PKG smcu PCIe init done */
		ret = vastai_pci_poll_smcu_stage(priv, VASTAI_DIE0, VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY);
		if (ret < 0) {
			VASTAI_PCI_ERR(priv, VASTAI_DIE0, "%s poll smcu stage[%d] error\n", __func__, VASTAI_SMCU_BOOT_STAGE_PCIE_INIT_READY);
			return ret;
		}

		vastai_pci_set_host_stage(priv, VASTAI_DIE0, VASTAI_HOST_BOOT_STAGE_RCV_PCIE_INIT_READY_ACK);

		/* TODO */
		priv->boot_stage = 6;

		// Release the boot lock for current PF
		vastai_release_boot_lock(priv);
	}
	vastai_pci_state_boot_done(priv);

	if(vastai_get_board_type(priv) ==SV100) {
		vastai_pci_get_fw_ver(priv, 0xFFF, true);
	}
	ret = vastai_pci_new_bmcu_path_confirm(priv);
	if (ret) {
		VASTAI_PCI_ERR(priv, VASTAI_DIE0,
			       "%s dev%d-die%d new_bmcu_path_confirm error\n",
			       __func__, priv->dev_id, VASTAI_DIE0);
		return ret;
	}

	VASTAI_PCI_FUNC_EXIT;
	return 0;
}

