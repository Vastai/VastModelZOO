#ifndef __VASTAI_RAS_H__
#define __VASTAI_RAS_H__
/*
 * vastai_ras.h
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/11/15
 * Author: xiangming.yang
 */

#define CSRAM_RAS_FIFO_BASE       (CSRAM_BASE_ADDR + 0x000FB000)
#define CSRAM_RAS_FIFO_SIZE       (0x2000)  //8KB

/* ras core exception buffer, 16 bytes for each core */
#define RAS_CORE_EXCEP_BUFFER     (CSRAM_BASE_ADDR + 0x000FD000)

#define XSPI_RAS_RECORD_BASE      (0x1C0000)
#define XSPI_RAS_RECORD_SIZE      (0x8000)
#define XSPI_RAS_RECORD_LIMIT     (XSPI_RAS_RECORD_BASE + XSPI_RAS_RECORD_SIZE)

#define XSPI_RAS_HEAD             (0x726173)  //ras

#define MAX_RAS_RECORD            (100)
#define VATOOLS_ERR_INFO_COUNT_MAX (MAX_RAS_RECORD)

/*
 * [0x08cfd800, 0x08cfda00), 0x200: VF_INFO_BASE
 * [0x08cfda00, 0x08cfdd00), 0x300: VF_FIFO_BASE
 * [0x08cfdd00, 0x08cfe000), 0x300: RAS_INFO_BASE
 */

#define RAS_INFO_BASE             (0x08cfdd00)
#define RAS_INFO_SIZE             (0x300)

#define RAS_INFO_MAGIC            (0x7261732e) /* ras. */

typedef struct __attribute__((packed)) ras_info {
	unsigned int magic;
	unsigned int enabled;
} ras_info_t;

enum vastai_ras_component {
	VASTAI_RAS_CORE     = 0,
	VASTAI_RAS_AI       = 1,
	VASTAI_RAS_VIDEO    = 2,
	/* 3 reserved for GFX */
	VASTAI_RAS_PVT      = 4,
	VASTAI_RAS_DDR      = 5,
	VASTAI_RAS_PCIE     = 6,
	VASTAI_RAS_DMA      = 7,
	VASTAI_RAS_OTHERS   = 8,
	VASTAI_RAS_SWITCH   = 9, /* used to switch on/off global or local ras modules */
	VASTAI_RAS_MAX,
};

/* it's same with core_bit_index, so we can use core_bit_index instead */
enum vastai_ras_core_sub_component {
	VASTAI_RAS_CORE_SMCU = 0,
	VASTAI_RAS_CORE_CMCU = 1,
	VASTAI_RAS_CORE_LMCU0 = 2,
	VASTAI_RAS_CORE_LMCU1 = 3,
	VASTAI_RAS_CORE_LMCU2 = 4,
	VASTAI_RAS_CORE_LMCU3 = 5,
	VASTAI_RAS_CORE_LMCU4 = 6,
	VASTAI_RAS_CORE_LMCU5 = 7,
	VASTAI_RAS_CORE_LMCU6 = 8,
	VASTAI_RAS_CORE_LMCU7 = 9,
	VASTAI_RAS_CORE_ODSP0 = 10,
	VASTAI_RAS_CORE_ODSP1 = 11,
	VASTAI_RAS_CORE_ODSP2 = 12,
	VASTAI_RAS_CORE_ODSP3 = 13,
	VASTAI_RAS_CORE_ODSP4 = 14,
	VASTAI_RAS_CORE_ODSP5 = 15,
	VASTAI_RAS_CORE_ODSP6 = 16,
	VASTAI_RAS_CORE_ODSP7 = 17,
	VASTAI_RAS_CORE_VDMCU0 = 18,
	VASTAI_RAS_CORE_VDMCU1 = 19,
	VASTAI_RAS_CORE_VDMCU2 = 20,
	VASTAI_RAS_CORE_VEMCU0 = 21,
	VASTAI_RAS_CORE_VEMCU1 = 22,
	VASTAI_RAS_CORE_VEMCU2 = 23,
	VASTAI_RAS_CORE_VEMCU3 = 24,
	VASTAI_RAS_CORE_VDSP0 = 25,
	VASTAI_RAS_CORE_VDSP1 = 26,
	VASTAI_RAS_CORE_VDSP2 = 27,
	VASTAI_RAS_CORE_VDSP3 = 28,
	/* gfx core */
	VASTAI_RAS_CORE_MAX,
};

enum vastai_ras_ddr_sub_component {
	VASTAI_RAS_DDR_ECC = 0,
	VASTAI_RAS_DDR_MAX,
};

enum vastai_ras_pvt_sub_component {
	VASTAI_RAS_PVT_BMCU = 0,
	VASTAI_RAS_PVT_SMCU = 1,
	VASTAI_RAS_PVT_MAX,
};

enum vastai_ras_others_sub_component {
	VASTAI_RAS_NOC = 0, //slave error
	VASTAI_RAS_EFUSE = 1,
	VASTAI_RAS_PERIPH = 2,
	VASTAI_RAS_CSRAM = 3, //ecc, parity
	VASTAI_RAS_CEDAR = 4,
	VASTAI_RAS_SYSTEM_RESET = 5,
	VASTAI_RAS_OTHERS_MAX,
};

enum vastai_ras_err_type {
	ERR_CORRECTABLE = 0,
	ERR_NONFATAL    = 1,
	ERR_FATAL       = 2,
};

enum vastai_ras_record_dest {
	RAS_RECORD_TO_NONE = (1 << 0),
	RAS_RECORD_TO_FLASH = (1 << 1),
};

enum vastai_ras_report_dest {
	RAS_REPORT_TO_NONE = (1 << 0),
	RAS_REPORT_TO_BMCU = (1 << 1),
	RAS_REPORT_TO_HOST_KMD = (1 << 2),
	RAS_REPORT_TO_HOST_UMD = (1 << 3),
};

enum vastai_ras_core_err_cause {
	ILLEGAL_INSTRUCTION_CAUSE = 0,
	SYSCALL_CAUSE = 1,
	INSTRUCTION_FETCH_ERROR_CAUSE = 2,
	LOAD_STORE_ERROR_CAUSE = 3,
	LEVEL1_INTERRUPT_CAUSE = 4,
	ALLOCA_CAUSE = 5,
	INTEGER_DIVIDE_BY_ZERO_CAUSE = 6,
	PC_VAULE_ERROR_CAUSE = 7,
	PRIVILEGED_CAUSE = 8,
	LOAD_STORE_ALIGNMENT_CAUSE = 9,
	EXTERNAL_REG_PRIVILEGE_CAUSE = 10,
	EXCLUSIVE_ERROR_CAUSE = 11,
	INSTR_PIF_DATA_ERROR_CAUSE = 12,
	LOAD_STORE_PIF_DATA_ERROR_CAUSE = 13,
	INSTR_PIF_ADDR_ERROR_CAUSE = 14,
	LOAD_STORE_PIF_ADDR_ERROR_CAUSE = 15,
	INST_TLB_MISS_CAUSE = 16,
	INST_TLB_MULTI_HIT_CAUSE = 17,
	INST_FETCH_PRIVILEGE_CAUSE = 18,
	/* 19 is reserved for Cadense */
	INST_FETCH_PROHIBITED_CAUSE = 20,
	/* 21..23 is reserved for Cadense */
	LOAD_STORE_TLB_MISS_CAUSE = 24,
	LOAD_STORE_TLB_MULTI_HIT_CAUSE = 25,
	LOAD_STORE_PRIVILEGE_CAUSE = 26,
	/* 27 is reserved for Cadense */
	LOAD_PROHIBITED_CAUSE = 28,
	STORE_PROHIBITED_CAUSE = 29,
	/* 30..31 is reserved for Cadense */
	COPROCESSOR_0_DISABLED = 32,
	COPROCESSOR_1_DISABLED = 33,
	COPROCESSOR_2_DISABLED = 34,
	COPROCESSOR_3_DISABLED = 35,
	COPROCESSOR_4_DISABLED = 36,
	COPROCESSOR_5_DISABLED = 37,
	COPROCESSOR_6_DISABLED = 38,
	COPROCESSOR_7_DISABLED = 39,
	/* 40..63 is reserved for Cadense */
};

enum vastai_ras_ddr_err_cause {
	ECC_SINGLE_BIT_ERR = 0,
	ECC_DOUBLE_BIT_ERR = 1,
};

enum vastai_ras_pvt_err_cause {
	BMCU_POWERDOWN = 0,
	BMCU_CORE_EXCEPTION = 1,
	BMCU_LINK_EXCEPTION = 2,
	SMCU_OVERTEMP_PROTECTION = 3,
	SMCU_OVERCURRENT_PROTECTION = 4,
};

enum vastai_ras_ai_err_cause {
    /* fatal err */
    WDDMA_AXI_SLV = 0,
    WDDMA_AXI_DEC = 1,
    WDDMA_ECC_DBE = 2,
    CTRANS_AXI_SLV = 3,
    CTRANS_AXI_DEC = 4,
    CTRANS_FIFI_UNDERFLOW = 5,
    SEP_LUT_ECC_DBE = 6,
    SEP_SCALE_ECC_DBE = 7,
    DATA_EXP_AXI_SLV = 8,
    DATA_EXP_AXI_DEC = 9,
    DATA_EXP_OVERFLOW = 10,
    DEC_RD = 11,
    SLV_RD = 12,
    PARIRY_RD = 13,
    DEC_WR = 14,
    SLV_WR = 15,
    PARITY_WR = 16,
    /* nonfatal err */
    WDDMA_ECC_SBE = 17,
    SEP_LUT_ECC_SBE = 18,
    SEP_SCALE_ECC_SBE = 19,
    AI_ERR_CAUSE_MAX,
};

enum vastai_ras_ai_sub_component {
    VASTAI_RAS_AI_OAK0 = 0,
    VASTAI_RAS_AI_OAK1 = 1,
    VASTAI_RAS_AI_OAK2 = 2,
    VASTAI_RAS_AI_OAK3 = 3,
    VASTAI_RAS_AI_OAK4 = 4,
    VASTAI_RAS_AI_OAK5 = 5,
    VASTAI_RAS_AI_OAK6 = 6,
    VASTAI_RAS_AI_OAK7 = 7,
    VASTAI_RAS_AI_ODMA0 = 8,
    VASTAI_RAS_AI_ODMA1 = 9,
    VASTAI_RAS_AI_CORE_MAX,
};

enum enum_video_exception_list {
    _VCENC_EXCEPTION_ERROR = 11,
    _VCENC_EXCEPTION_NULL_ARGUMENT = 12,                  /**ERROR Null argument**/
    _VCENC_EXCEPTION_INVALID_ARGUMENT = 13,               /**ERROR Invalid argument*/
    _VCENC_EXCEPTION_INVALID_STATUS = 14,                 /*VCEncStrmEncode: ERROR Invalid status*/
    _VCENC_EXCEPTION_INVALID_GOPSIZE = 15,                /*VCEncStrmEncode: ERROR Invalid gopSize*/
    _VCENC_EXCEPTION_NOTCODED_FRAME = 16,                 /*VCEncStrmEncode: ERROR Invalid coding type*/
    _VCENC_EXCEPTION_STREAM_BUFFER = 17,                  /*VCEncStrmEncode: ERROR Invalid output stream buffer*/
    _VCENC_EXCEPTION_TOO_SMALL_OUTPUT_STREAM_BUFFER = 18, /*VCEncStrmEncode: ERROR Too small output stream buffer*/
    _VCENC_EXCEPTION_NOT_SUPPORT_MULTI_CORE = 19,         /*VCEncStrmEncode: multi-segment not support multi-core*/
    _VCENC_EXCEPTION_INVALID_BASELINE_PROFILE = 20,       /*VCEncSetCodingCtrl: ERROR Invalid frame type for baseline profile*/
    _VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAV = 21,      /*VCEncStrmEncode: ERROR Invalid input busChromaV*/
    _VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAU = 22,      /*VCEncStrmEncode: ERROR Invalid input busChromaU*/
    _VCENC_EXCEPTION_INVALID_INPUT_BUSLUMA = 23,          /*VCEncStrmEncode: ERROR Invalid input busLuma*/
    _VCENC_EXCEPTION_INVALID_INPUT_FORMAT = 24,           /*VCEncStrmEncodeExt: ERROR Invalid input format*/
    _VCENC_EXCEPTION_INVALID_INPUT_BUSLUMASTAB = 25,      /*VCEncStrmEncodeExt: ERROR Invalid input busLumaStab*/
    _VCENC_EXCEPTION_MEMORY_ERROR = 26,                   /**ERROR Memery error*/
    _VCENC_EXCEPTION_EWL_ERROR = 27,                      /**ERROR Invalid argument*/
    _VCENC_EXCEPTION_EWL_MEMORY_ERROR = 28,               /**ERROR Ewl Memery error*/
    _VCENC_EXCEPTION_OUTPUT_BUFFER_OVERFLOW = 29,         /**ERROR Revert FrameNum Update on output buffer overflow*/
    _VCENC_EXCEPTION_HW_BUS_ERROR = 30,                   /**ERROR Hardware bus error*/
    _VCENC_EXCEPTION_HW_DATA_ERROR = 31,                  /**ERROR Hardware data error*/
    _VCENC_EXCEPTION_HW_TIMEOUT = 32,                     /**ERROR hardware timeout*/
    _VCENC_EXCEPTION_HW_RESERVED = 33,                    /**ERROR Hardware reserved*/
    _VCENC_EXCEPTION_SYSTEM_ERROR = 34,                   /**ERROR System error*/
    _VCENC_EXCEPTION_INSTANCE_ERROR = 35,                 /**ERROR Instance error*/
    _VCENC_EXCEPTION_HRD_ERROR = 36,                      /**ERROR Hrd error*/
    _VCENC_EXCEPTION_HW_RESET = 37,                       /**ERROR Hardware reset*/
    _VCENC_EXCEPTION_HASH_LEN_MISMATCH = 38,              /**ERROR Hash len mismatch*/
    _VCENC_EXCEPTION_FW_RESET = 39,                       /**ERROR FW reset*/
    _VCENC_EXCEPTION_INSATANCE_CHECK_MISMATCH = 40,       /**ERROR Instance check mismatch*/
    _VCENC_EXCEPTION_IM_RESET = 41,                       /**ERROR hantrovcmd_isr failed. im reset dev->hwregs */
    _VCENC_EXCEPTION_ENCODE_EXT_MCU_V2 = 42,              /**ERROR VCEncStrmEncodeExt_mcu_V2*/
    _VCENC_EXCEPTION_HANDLE_ENCODER_ISR = 43,             /**ERROR HandleEncoderIsr failed*/
    _VCENC_EXCEPTION_HANG_HANTRO_RESET_ISR_FAILED = 44,   /**FAILED hang reset hantrovcmd_isr failed irq*/
    _VCENC_EXCEPTION_HANTRO_VCMD_ISR_TIMEOUT = 45,        /**ERROR hantrovcmd_isr error timeout */
    _VCENC_EXCEPTION_HALT_MODE_TIME_OUT = 46,             /**ERROR vemcu halt mode time out*/
    _VCENC_EXCEPTION_NOT_RECV_IRQ = 47,                   /**error vemcu not recv irq*/
    _VCDEC_EXCEPTION_RESERVED = 61,                       /**ERROR decoder reserved*/
    _VCDEC_EXCEPTION_SMCU_START_DEC_TIMEOUT = 62,         /**ERROR smcu start decoder timeout*/
    _VCDEC_EXCEPTION_DECODER_INIT_FAILED = 63,            /**ERROR decoder init failed*/
    _VCDEC_EXCEPTION_DECODER_RINGBUFF_ADDRESS_NULL = 64,  /**ERROR ring buf address is null*/
    _VCDEC_EXCEPTION_DECODER_RINGBUFF_FULL = 65,          /**ERROR ring buffer full*/
    _VCDEC_EXCEPTION_DECODER_RECV_ERROR_DATA = 66,        /**ERROR decoder recv error data*/
    _VCDEC_EXCEPTION_DECODER_NULL_PARAM = 67,             /**ERROR decoder null param*/
    _VCDEC_EXCEPTION_DECODER_HANDLE_EXCEPTION = 68,       /**ERROR decoder dma handle exception*/
    _VCDEC_EXCEPTION_DECODER_RESET = 69,                  /**ERROR decoder reset*/
    _VCDEC_EXCEPTION_DECODER_RINGBUFF_EMPTY = 70,         /**ERROR decoder ring buffer empty*/
};

enum vastai_ras_video_core_sub_component {

	VASTAI_RAS_VIDEO_CORE_VDMCU0 = 18,
	VASTAI_RAS_VIDEO_CORE_VDMCU1 = 19,
	VASTAI_RAS_VIDEO_CORE_VDMCU2 = 20,
	VASTAI_RAS_VIDEO_CORE_VEMCU0 = 21,
	VASTAI_RAS_VIDEO_CORE_VEMCU1 = 22,
	VASTAI_RAS_VIDEO_CORE_VEMCU2 = 23,
	VASTAI_RAS_VIDEO_CORE_VEMCU3 = 24,
	VASTAI_RAS_VIDEO_CORE_MAX,
};

struct __attribute__((packed)) vastai_ras_err_head {
	u32 timestamp;
	u32 entry_size: 8;
	u32 err_severity: 4;
	u32 err_reason: 8;
	u32 sub_component: 8;
	u32 component: 4;
};

/* RAS PCIe error structure*/
struct pcie_err_entry {
	u32 ep_or_rc:8;	  /* EP or RC err status reg */
	u32 err_type:8;	  /* Correctable or Uncorrectable */
	u32 err_idx:8; 	  /* Which bit of the error */
	u32 rsvd:8;       /* If aer already injected and not handled */
};

/* RAS DMA error structure*/
struct dma_err_entry {
	u32 cor_cnt;
	u32 uncor_cnt;
};

struct dma_err_param {
	u32 ep_or_rc : 8; /* EP or RC selection                      */
	u32 need_inj : 8; /* Inject the dma desc err to next trans   */
	u32 die_sel  : 8; /* Which die to inject (0 ~ 3)             */
	u32 rsvd     : 8; /* If aer already injected and not handled */
};

struct ddr_err_entry {
	u32 addr_1;
	u32 addr_h;
	u32 axi_id;
	u32 axi_data_l;
	u32 axi_data_h;
	u32 errbit;
};

struct core_err_entry {
	u32 pc;
	u32 ps;
};

struct pvt_err_entry {
	u32 reason;  /* over-current or over-temperature */
	u32 percent;
};

enum ras_video_handle {
	RAS_VIDEO_NOTHING = 0,
	RAS_VIDEO_RESET_VIDEO_SYS = 1,
	RAS_VIDEO_RESET_VEMCU_SUB_SYS = 2,
	RAS_VIDEO_RESET_VDMCU_SUB_SYS = 3,
};

enum ras_video_handle_status {
	RAS_VIDEO_UNKNOWN = 0,
	RAS_VIDEO_RESET_START = 1,
	RAS_VIDEO_RESET_END = 2,
	RAS_VIDEO_RESET_FAILE = 3,
};

struct video_err_entry {
	u32 video_event;
	u32 status;
};

enum ras_other_event {
	RAS_OTHER_EVENT_RST = 0,
	RAS_OTHER_EVENT_TEMP = 1,
	RAS_OTHER_EVENT_VOLT = 2,
	RAS_OTHER_EVENT_BMCU = 3,
};

typedef union {
	struct ddr_err_entry ddr_ecc;
	struct core_err_entry core;
	struct pcie_err_entry pcie;
	struct dma_err_entry dma;
	struct video_err_entry video;
	struct pvt_err_entry pvt;
} __attribute__ ((aligned (4))) ras_entry_t;

#define MAX_RAS_U32_SIZE (sizeof(ras_entry_t) / sizeof(u32))
struct __attribute__((packed)) vastai_ras_err_info {
	struct vastai_ras_err_head head;
	/* sizeof(ras_entry) should be equal to sizeof(entry_paddings) */
	union {
		ras_entry_t ras_entry;
		u32 entry_paddings[MAX_RAS_U32_SIZE];
	};
};

#define VASTAI_RAS_VERSION 0

struct __attribute__((packed)) vatools_err_info_t {
/* input param */
	u32 read_pos;            // error num offset to read
	u8 err_info_count_max;   // refer to MACRO VATOOLS_ERR_INFO_COUNT_MAX
	u8 err_info_type;        // 0 for insmod, and 1 for history

/* output param */
	u8 err_info_count_read;  // The actual read count
	u8 ras_version;          // RAS err version
	u8 ras_elem_size;        // sizeof RAS err structure
	u8 file_crc;             // RAS checksum
	u8 file_read_finished;   // please refer to err_info_count_read
	u8 pads[1];              // for 4-bytes alignment
	u64 buffer;            // where to put RAS errors
};

#define VASTAI_RAS_GET_INSMOD  (0)
#define VASTAI_RAS_GET_HIST    (1)

struct ras_event_head {
	struct list_head head;
	struct mutex ras_lock;
	spinlock_t ras_evt_lock;
};

struct ras_other_event_info {
	spinlock_t rst_evnt_lock;
	struct list_head list;
	u64 timestamp;
	u32 type;
	u32 info[3];
};

struct ras_event_info {
	struct list_head list;
	struct vastai_ras_err_info err;
};

enum ras_cmd2smcu {
	RAS_CMD_READ_XSPI = 0,
	RAS_CMD_CLEAR_XSPI = 1,
	RAS_CMD_SWITCH = 2,
	RAS_CMD_TEST = 3,
	RAS_CMD_MAX,
};

union ras_cmd_data {
	u64 whole;
	struct __attribute__((packed)) {
		union {
			struct __attribute__((packed)) {
				u32 addr;
				u32 len: 24;
			} rw;
			struct __attribute__((packed)) {
				u32 data;
				u32 reason: 8;
				u32 sub_component: 8;
				u32 component: 4;
				u32 rsvd: 4;
			} test;
		};
		u8 type: 4;
		u8 die: 2;
		u8 rsvd: 2;
	};
};
_Static_assert((sizeof(union ras_cmd_data) == sizeof(u64)),
					"Size of ras_cmd_data must be 8 Bytes");

typedef struct ras_record_info {
	u32 head;
	u32 fatal_cnt;
	u32 nonfatal_cnt;
	u32 next_offset;
} ras_record_info_t;

#define VASTAI_RAS_FILE     "/var/log/vastai_ras_dev%d_die%d.log"
#define VASTAI_RAS_RAW_FILE "/var/log/vastai_ras_dev%d_die%d.raw"

void vastai_ras_init(struct vastai_pci_info *pci_info);
void vastai_ras_deinit(struct vastai_pci_info *pci_info);

int vastai_ras_read_record_insmod(struct vastai_sv100_die *die, void* buf,
	int block_cnt);
int vastai_ras_read_raw_hist(struct vastai_sv100_die *die, void* buf,
		int block_cnt, loff_t* fpos);
void vastai_ras_err_vatools_read(struct vastai_sv100_die* die, struct vatools_err_info_t* info);
void vastai_ras_write_str_file(struct vastai_sv100_die *die, char *buf, u32 size);
void vastai_ras_get_timestamp(u32 sec, char *out);

void ras_add_other_event(u32 evt_type, int args_num, ...);
void ras_add_kern_event(struct vastai_sv100_die *die,
		struct vastai_ras_err_head err_head, int args_num, ...);

int vastai_pci_do_ras_cmd(void* dev, u32 die_id, union ras_cmd_data *cmd);

#endif
