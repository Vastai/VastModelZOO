/*
 * vastai_ras.c
 * Copyright (C) 2022 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2022/11/15
 * Author: xiangming.yang
 */

#include "vastai_pci.h"
#include "vastai_pci_api.h"
#include "vastai_pci_test.h"

#include "vastai_ras.h"

#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/rtc.h>

static int vastai_pci_ras_read(struct char_drv_info *cdev, u32 die_id, union ras_cmd_data *cmd)
{
	int ret = 0;
	int i = 0;
	int print_flag = 1;
	unsigned char print_str[64];
	struct vastai_pci_info *priv;

	if (!cdev || !cmd || cmd->type != RAS_CMD_READ_XSPI)
		return -EINVAL;

	if (cmd->rw.addr < XSPI_RAS_RECORD_BASE || (cmd->rw.addr + cmd->rw.len) > XSPI_RAS_RECORD_LIMIT)
		return -EINVAL;

	priv = cdev->pcie_dev_info;
	ret = vastai_send_pcie_cmd(priv, die_id, VASTAI_PCIE_SUB_RAS, cmd->whole);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: send cmd(%d) failed%d\n",
				__func__, VASTAI_PCIE_SUB_RAS, ret);
		return ret;
	}

	/* wait completion int from smcu */
	if (wait_for_completion_timeout(
			&(priv->dies[die_id].rw_xspi),
			msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s: wait rw_xspi timeout\n", __func__);
		return -ETIMEDOUT;
	}
	reinit_completion(&(priv->dies[die_id].rw_xspi));
	if (priv->dies[die_id].rw_xspi_msg != VASTAI_XSPI_SUCCESS) {
		VASTAI_PCI_ERR(
			priv, DUMMY_DIE_ID,
			"%s: failed to read RAS record from xspi, %d\n",
			__func__, -(priv->dies[die_id].rw_xspi_msg));
		return -(priv->dies[die_id].rw_xspi_msg);
	}

	ret = vastai_pci_mem_read(priv, priv->dies[die_id].die_index,
				MODULE_INFO_BASE, cdev->dm->vir, cmd->rw.len);
	if (ret < 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s [read] 0x%x, len=%d, error: %d\n", __func__,
			       MODULE_INFO_BASE, cmd->rw.len, ret);
		return ret;
	}

	if (print_flag == 1) {
		for (i = 0; i < cmd->rw.len; i += 16) {
			sprintf(print_str,
				"%s [read] xspi 0x%010x: ", VASTAI_PCI_DEBUG_PREFIX, cmd->rw.addr + i);
			VASTAI_PCI_HEX_DUMP(KERN_WARNING, print_str,
					    DUMP_PREFIX_NONE, 16, 4,
					    cdev->dm->vir + i, 16, true);
		}
	}

	return 0;
}

static int vastai_pci_ras_clear(struct char_drv_info *cdev, u32 die_id, union ras_cmd_data *cmd)
{
	int ret = 0;
	struct vastai_pci_info *priv;

	if (!cdev || !cmd || cmd->type != RAS_CMD_CLEAR_XSPI)
		return -EINVAL;

	priv = cdev->pcie_dev_info;
	ret = vastai_send_pcie_cmd(priv, die_id, VASTAI_PCIE_SUB_RAS, cmd->whole);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: send cmd(%d) failed%d\n",
				__func__, VASTAI_PCIE_SUB_RAS, ret);
		return ret;
	}

	/* wait completion int from smcu */
	if (wait_for_completion_timeout(
			&(priv->dies[die_id].rw_xspi),
			msecs_to_jiffies(VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s: wait rw_xspi timeout\n", __func__);
		return -ETIMEDOUT;
	}
	reinit_completion(&(priv->dies[die_id].rw_xspi));
	if (priv->dies[die_id].rw_xspi_msg != VASTAI_XSPI_SUCCESS) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			"%s: failed to clear RAS on xspi, %d\n",
			__func__, -(priv->dies[die_id].rw_xspi_msg));
		return -(priv->dies[die_id].rw_xspi_msg);
	}

	return 0;
}

static int vastai_pci_ras_switch(struct char_drv_info *cdev, u32 die_id, union ras_cmd_data *cmd)
{
	int ret = 0;
	struct vastai_pci_info *priv;

	if (!cdev || !cmd || cmd->type != RAS_CMD_SWITCH)
		return -EINVAL;

	priv = cdev->pcie_dev_info;
	ret = vastai_send_pcie_cmd(priv, die_id, VASTAI_PCIE_SUB_RAS, cmd->whole);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: send cmd(%d) failed%d\n",
				__func__, VASTAI_PCIE_SUB_RAS, ret);
		return ret;
	}
	return 0;
}

extern int vastai_pci_test_case(struct vastai_pci_info *priv,
				struct char_drv_info *dev, u32 case_no);

static int vastai_pci_ras_test(struct char_drv_info *cdev, u32 die_id, union ras_cmd_data *cmd)
{
	int ret = 0;
	struct vastai_pci_info *priv;

	if (!cdev || !cmd || cmd->type != RAS_CMD_TEST)
		return -EINVAL;

	priv = cdev->pcie_dev_info;
	ret = vastai_send_pcie_cmd(priv, die_id, VASTAI_PCIE_SUB_RAS, cmd->whole);
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: send cmd(%d) failed, data 0x%llx\n",
				__func__, VASTAI_PCIE_SUB_RAS, cmd->whole);
		return ret;
	}

	if (cmd->test.component == VASTAI_RAS_DMA) {
		ret = vastai_pci_test_case(priv, cdev, 156);
		if (ret != VASTAI_TEST_PASS) {
			VASTAI_PCI_ERR(priv, die_id, "RAS_DMA_TEST tc156 failed\n");
		}
		return ret;
	}
	return 0;
}

typedef int (*ras_test_func)(struct char_drv_info *, u32, union ras_cmd_data *);

static ras_test_func ras_test_cmds[] = {
	[RAS_CMD_READ_XSPI]  = vastai_pci_ras_read,
	[RAS_CMD_CLEAR_XSPI] = vastai_pci_ras_clear,
	[RAS_CMD_SWITCH]     = vastai_pci_ras_switch,
	[RAS_CMD_TEST]       = vastai_pci_ras_test,
};

int vastai_pci_do_ras_cmd(void* cdev, u32 die_id, union ras_cmd_data *cmd)
{
	u8 type;
	struct char_drv_info *info = cdev;

	if (!info || !info->pcie_dev_info || !cmd)
		return -EINVAL;

	type = cmd->type;
	if (type < ARRAY_SIZE(ras_test_cmds) && ras_test_cmds[type]) {
		return ras_test_cmds[type](info, die_id, cmd);
	} else {
		VASTAI_PCI_ERR(info->pcie_dev_info, die_id,
			"%s: invalid mode param %d\n", __func__, type);
		return -EINVAL;
	}
}

void vastai_ras_get_timestamp(u32 sec, char *out)
{
	time64_t time;
	struct rtc_time rtc_tm;

	if (!out)
		return;

	time = (time64_t)sec;
	rtc_time64_to_tm(time, &rtc_tm);
	sprintf(out, "%04d-%02d-%02d %02d:%02d:%02d",
			rtc_tm.tm_year + 1900, rtc_tm.tm_mon + 1, rtc_tm.tm_mday,
			rtc_tm.tm_hour + 8, rtc_tm.tm_min, rtc_tm.tm_sec);
}

int vastai_ras_read_record_insmod(struct vastai_sv100_die *die, void* buf,
	int block_cnt)
{
	struct ras_event_info *event, *next_event;
	u32 offset = 0;
	int ret = 0;
	int need;

	need = (block_cnt < MAX_RAS_RECORD) ? block_cnt : MAX_RAS_RECORD;

	/* empty not processed events */
	spin_lock(&die->ras_evt_afterboot.ras_evt_lock);
	list_for_each_entry_safe(event, next_event, &die->ras_evt_afterboot.head, list) {
		memcpy(buf + offset, &event->err, sizeof(struct vastai_ras_err_info));
		offset += sizeof(struct vastai_ras_err_info);
		ret++;

		if (ret >= need) break;
	}
	spin_unlock(&die->ras_evt_afterboot.ras_evt_lock);

	return ret;
}

void vastai_ras_err_vatools_read(struct vastai_sv100_die* die,
		struct vatools_err_info_t* info)
{
	int elem_size = sizeof(struct vastai_ras_err_info);
	loff_t fpos = elem_size * info->read_pos;

	if (info->err_info_type == VASTAI_RAS_GET_INSMOD) {
		info->err_info_count_read = vastai_ras_read_record_insmod(die,
									(void *)info->buffer, info->err_info_count_max);

	} else if (info->err_info_type == VASTAI_RAS_GET_HIST) {
		info->err_info_count_read = vastai_ras_read_raw_hist(die,
									(void *)info->buffer, info->err_info_count_max, &fpos);
	} else {
		info->err_info_count_read = -EINVAL;
	}

	info->ras_version = VASTAI_RAS_VERSION;
	info->ras_elem_size = elem_size;
}

int vastai_ras_read_raw_hist(struct vastai_sv100_die *die, void* buf,
	int block_cnt, loff_t* fpos)
{
	struct file *fp;
	//loff_t fpos = 0;
	char file_name[64] = {0};
	int dev_id, die_id;
	int block_size = sizeof(struct vastai_ras_err_info);
	u32 size;
	int ret;

	if (die == NULL || die->pci_info == NULL) {
		return -EINVAL;
	}

	if (buf == NULL || block_size == 0 || block_cnt == 0) {
		return -EINVAL;
	}

	dev_id = die->pci_info->dev_id;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	sprintf(file_name, VASTAI_RAS_RAW_FILE, dev_id, die_id);
	fp = filp_open(file_name, O_RDONLY, 0664);
	if (IS_ERR(fp)) {
		VASTAI_PCI_ERR(die->pci_info, die_id, "%s: open %s failed\n",
				__func__, file_name);
		return -ENOENT;
	}

	size = block_size * block_cnt;

	mutex_lock(&die->ras_evt_afterboot.ras_lock);
	ret = kernel_read(fp, buf, size, fpos);
	mutex_unlock(&die->ras_evt_afterboot.ras_lock);

	if (ret > 0) {
		ret = ret / block_size;
	}

	filp_close(fp, NULL);

	return ret;
}

void vastai_ras_write_raw_file(struct vastai_sv100_die *die, void *buf, u32 size)
{
	struct file *fp;
	loff_t fpos = 0;
	char file_name[64] = {0};
	int dev_id, die_id;

	if (die == NULL || die->pci_info == NULL)
		return;

	if (buf == NULL || size == 0)
		return;

	dev_id = die->pci_info->dev_id;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	sprintf(file_name, VASTAI_RAS_RAW_FILE, dev_id, die_id);
	fp = filp_open(file_name, O_CREAT | O_RDWR | O_APPEND, 0664);
	if (IS_ERR(fp)) {
		VASTAI_PCI_ERR(die->pci_info, die_id, "%s: open %s failed\n",
				__func__, file_name);
		return;
	}

	mutex_lock(&die->ras_evt_afterboot.ras_lock);
	kernel_write(fp, buf, size, &fpos);
	mutex_unlock(&die->ras_evt_afterboot.ras_lock);

	VASTAI_PCI_DBG(die->pci_info, die_id, "wrote %d bytes to %s, loff_t: 0x%llx\n",
				size, file_name, fpos);

	filp_close(fp, NULL);
}

void vastai_ras_write_str_file(struct vastai_sv100_die *die, char *buf, u32 size)
{
	struct file *fp;
	loff_t fpos = 0;
	char file_name[64] = {0};
	int dev_id, die_id;

	if (die == NULL || die->pci_info == NULL)
		return;

	if (buf == NULL || size == 0)
		return;

	dev_id = die->pci_info->dev_id;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	sprintf(file_name, VASTAI_RAS_FILE, dev_id, die_id);
	fp = filp_open(file_name, O_CREAT | O_RDWR | O_APPEND, 0664);
	if (IS_ERR(fp)) {
		VASTAI_PCI_ERR(die->pci_info, die_id, "%s: open %s failed\n",
				__func__, file_name);
		return;
	}

	mutex_lock(&die->ras_evt.ras_lock);
	kernel_write(fp, buf, size, &fpos);
	mutex_unlock(&die->ras_evt.ras_lock);

	VASTAI_PCI_INFO(die->pci_info, die_id, "wrote %d bytes to %s\n",
				size, file_name);

	filp_close(fp, NULL);
}

const char *ras_core_name[] = {
	[VASTAI_RAS_CORE_SMCU] = "SMCU",
	[VASTAI_RAS_CORE_CMCU] = "CMCU",
	[VASTAI_RAS_CORE_LMCU0] = "LMCU0",
	[VASTAI_RAS_CORE_LMCU1] = "LMCU1",
	[VASTAI_RAS_CORE_LMCU2] = "LMCU2",
	[VASTAI_RAS_CORE_LMCU3] = "LMCU3",
	[VASTAI_RAS_CORE_LMCU4] = "LMCU4",
	[VASTAI_RAS_CORE_LMCU5] = "LMCU5",
	[VASTAI_RAS_CORE_LMCU6] = "LMCU6",
	[VASTAI_RAS_CORE_LMCU7] = "LMCU7",
	[VASTAI_RAS_CORE_ODSP0] = "ODSP0",
	[VASTAI_RAS_CORE_ODSP1] = "ODSP1",
	[VASTAI_RAS_CORE_ODSP2] = "ODSP2",
	[VASTAI_RAS_CORE_ODSP3] = "ODSP3",
	[VASTAI_RAS_CORE_ODSP4] = "ODSP4",
	[VASTAI_RAS_CORE_ODSP5] = "ODSP5",
	[VASTAI_RAS_CORE_ODSP6] = "ODSP6",
	[VASTAI_RAS_CORE_ODSP7] = "ODSP7",
	[VASTAI_RAS_CORE_VDMCU0] = "VDMCU0",
	[VASTAI_RAS_CORE_VDMCU1] = "VDMCU1",
	[VASTAI_RAS_CORE_VDMCU2] = "VDMCU2",
	[VASTAI_RAS_CORE_VEMCU0] = "VEMCU0",
	[VASTAI_RAS_CORE_VEMCU1] = "VEMCU1",
	[VASTAI_RAS_CORE_VEMCU2] = "VEMCU2",
	[VASTAI_RAS_CORE_VEMCU3] = "VEMCU3",
	[VASTAI_RAS_CORE_VDSP0] = "VDSP0",
	[VASTAI_RAS_CORE_VDSP1] = "VDSP1",
	[VASTAI_RAS_CORE_VDSP2] = "VDSP2",
	[VASTAI_RAS_CORE_VDSP3] = "VDSP3",
};

static char *vastai_ras_core_exccause(u8 reason)
{
	switch(reason) {
	case ILLEGAL_INSTRUCTION_CAUSE:
		return "ILLEGAL_INSTRUCTION_CAUSE";
	case SYSCALL_CAUSE:
		return "SYSCALL_CAUSE";
	case INSTRUCTION_FETCH_ERROR_CAUSE:
		return "INSTRUCTION_FETCH_ERROR_CAUSE";
	case LOAD_STORE_ERROR_CAUSE:
		return "LOAD_STORE_ERROR_CAUSE";
	case LEVEL1_INTERRUPT_CAUSE:
		return "LEVEL1_INTERRUPT_CAUSE";
	case ALLOCA_CAUSE:
		return "ALLOCA_CAUSE";
	case INTEGER_DIVIDE_BY_ZERO_CAUSE:
		return "INTEGER_DIVIDE_BY_ZERO_CAUSE";
	case PC_VAULE_ERROR_CAUSE:
		return "PC_VAULE_ERROR_CAUSE";
	case PRIVILEGED_CAUSE:
		return "PRIVILEGED_CAUSE";
	case LOAD_STORE_ALIGNMENT_CAUSE:
		return "LOAD_STORE_ALIGNMENT_CAUSE";
	case EXTERNAL_REG_PRIVILEGE_CAUSE:
		return "EXTERNAL_REG_PRIVILEGE_CAUSE";
	case EXCLUSIVE_ERROR_CAUSE:
		return "EXCLUSIVE_ERROR_CAUSE";
	case INSTR_PIF_DATA_ERROR_CAUSE:
		return "INSTR_PIF_DATA_ERROR_CAUSE";
	case LOAD_STORE_PIF_DATA_ERROR_CAUSE:
		return "LOAD_STORE_PIF_DATA_ERROR_CAUSE";
	case INSTR_PIF_ADDR_ERROR_CAUSE:
		return "INSTR_PIF_ADDR_ERROR_CAUSE";
	case LOAD_STORE_PIF_ADDR_ERROR_CAUSE:
		return "LOAD_STORE_PIF_ADDR_ERROR_CAUSE";
	case INST_TLB_MISS_CAUSE:
		return "INST_TLB_MISS_CAUSE";
	case INST_TLB_MULTI_HIT_CAUSE:
		return "INST_TLB_MULTI_HIT_CAUSE";
	case INST_FETCH_PRIVILEGE_CAUSE:
		return "INST_FETCH_PRIVILEGE_CAUSE";
	case INST_FETCH_PROHIBITED_CAUSE:
		return "INST_FETCH_PROHIBITED_CAUSE";
	case LOAD_STORE_TLB_MISS_CAUSE:
		return "LOAD_STORE_TLB_MISS_CAUSE";
	case LOAD_STORE_TLB_MULTI_HIT_CAUSE:
		return "LOAD_STORE_TLB_MULTI_HIT_CAUSE";
	case LOAD_STORE_PRIVILEGE_CAUSE:
		return "LOAD_STORE_PRIVILEGE_CAUSE";
	case LOAD_PROHIBITED_CAUSE:
		return "LOAD_PROHIBITED_CAUSE";
	case STORE_PROHIBITED_CAUSE:
		return "STORE_PROHIBITED_CAUSE";
	case COPROCESSOR_0_DISABLED:
		return "COPROCESSOR_0_DISABLED";
	case COPROCESSOR_1_DISABLED:
		return "COPROCESSOR_1_DISABLED";
	case COPROCESSOR_2_DISABLED:
		return "COPROCESSOR_2_DISABLED";
	case COPROCESSOR_3_DISABLED:
		return "COPROCESSOR_3_DISABLED";
	case COPROCESSOR_4_DISABLED:
		return "COPROCESSOR_4_DISABLED";
	case COPROCESSOR_5_DISABLED:
		return "COPROCESSOR_5_DISABLED";
	case COPROCESSOR_6_DISABLED:
		return "COPROCESSOR_6_DISABLED";
	case COPROCESSOR_7_DISABLED:
		return "COPROCESSOR_7_DISABLED";
	default:
		return "INVALID CAUSE";
	}
}

static char *vastai_ras_ai_sub_component_str(u8 sub_component)
{
	switch(sub_component)
	{
	case VASTAI_RAS_AI_OAK0:
		return "OAK0";
	case VASTAI_RAS_AI_OAK1:
		return "OAK1";
	case VASTAI_RAS_AI_OAK2:
		return "OAK2";
	case VASTAI_RAS_AI_OAK3:
		return "OAK3";
	case VASTAI_RAS_AI_OAK4:
		return "OAK4";
	case VASTAI_RAS_AI_OAK5:
		return "OAK5";
	case VASTAI_RAS_AI_OAK6:
		return "OAK6";
	case VASTAI_RAS_AI_OAK7:
		return "OAK7";
	case VASTAI_RAS_AI_ODMA0:
		return "ODMA0";
	case VASTAI_RAS_AI_ODMA1:
		return "ODMA1";
	default:
		return "Unknown core";
	}
}

static char *vastai_ras_ai_err_cause_str(u8 err_cause)
{
	switch(err_cause)
	{
	case WDDMA_AXI_SLV:
		return "WDDMA_AXI_SLV";
	case WDDMA_AXI_DEC:
		return "WDDMA_AXI_DEC";
	case WDDMA_ECC_DBE:
		return "WDDMA_ECC_DBE";
	case CTRANS_AXI_SLV:
		return "CTRANS_AXI_SLV";
	case CTRANS_AXI_DEC:
		return "CTRANS_AXI_DEC";
	case CTRANS_FIFI_UNDERFLOW:
		return "CTRANS_FIFI_UNDERFLOW";
	case SEP_LUT_ECC_DBE:
		return "SEP_LUT_ECC_DBE";
	case SEP_SCALE_ECC_DBE:
		return "SEP_SCALE_ECC_DBE";
	case DATA_EXP_AXI_SLV:
		return "DATA_EXP_AXI_SLV";
	case DATA_EXP_AXI_DEC:
		return "DATA_EXP_AXI_DEC";
	case DATA_EXP_OVERFLOW:
		return "DATA_EXP_OVERFLOW";
	case DEC_RD:
		return "DEC_RD";
	case SLV_RD:
		return "SLV_RD";
	case PARIRY_RD:
		return "PARIRY_RD";
	case DEC_WR:
		return "DEC_WR";
	case SLV_WR:
		return "SLV_WR";
	case PARITY_WR:
		return "PARITY_WR";
	case WDDMA_ECC_SBE:
		return "WDDMA_ECC_SBE";
	case SEP_LUT_ECC_SBE:
		return "SEP_LUT_ECC_SBE";
	case SEP_SCALE_ECC_SBE:
		return "SEP_SCALE_ECC_SBE";
	default:
		return "Unknown err";
	}
}

char *vastai_ras_video_err_cause_str(u8 err_cause)
{
	switch(err_cause)
	{
	case _VCENC_EXCEPTION_NULL_ARGUMENT:
		return "VCENC_EXCEPTION_NULL_ARGUMENT";
	case _VCENC_EXCEPTION_INVALID_ARGUMENT:
		return "VCENC_EXCEPTION_INVALID_ARGUMENT";
	case _VCENC_EXCEPTION_INVALID_STATUS:
		return "VCENC_EXCEPTION_INVALID_STATUS";
	case _VCENC_EXCEPTION_INVALID_GOPSIZE:
		return "VCENC_EXCEPTION_INVALID_GOPSIZE";
	case _VCENC_EXCEPTION_NOTCODED_FRAME:
		return "VCENC_EXCEPTION_NOTCODED_FRAME";
	case _VCENC_EXCEPTION_STREAM_BUFFER:
		return "VCENC_EXCEPTION_STREAM_BUFFER";
	case _VCENC_EXCEPTION_TOO_SMALL_OUTPUT_STREAM_BUFFER:
		return "VCENC_EXCEPTION_TOO_SMALL_OUTPUT_STREAM_BUFFER";
	case _VCENC_EXCEPTION_NOT_SUPPORT_MULTI_CORE:
		return "VCENC_EXCEPTION_NOT_SUPPORT_MULTI_CORE";
	case _VCENC_EXCEPTION_INVALID_BASELINE_PROFILE:
		return "VCENC_EXCEPTION_INVALID_BASELINE_PROFILE";
	case _VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAV:
		return "VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAV";
	case _VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAU:
		return "VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAU";
	case _VCENC_EXCEPTION_INVALID_INPUT_BUSLUMA:
		return "VCENC_EXCEPTION_INVALID_INPUT_BUSLUMA";
	case _VCENC_EXCEPTION_INVALID_INPUT_FORMAT:
		return "VCENC_EXCEPTION_INVALID_INPUT_FORMAT";
	case _VCENC_EXCEPTION_INVALID_INPUT_BUSLUMASTAB:
		return "VCENC_EXCEPTION_INVALID_INPUT_BUSLUMASTAB";
	case _VCENC_EXCEPTION_MEMORY_ERROR:
		return "VCENC_EXCEPTION_MEMORY_ERROR";
	case _VCENC_EXCEPTION_EWL_ERROR:
		return "VCENC_EXCEPTION_EWL_ERROR";
	case _VCENC_EXCEPTION_EWL_MEMORY_ERROR:
		return "VCENC_EXCEPTION_EWL_MEMORY_ERROR";
	case _VCENC_EXCEPTION_OUTPUT_BUFFER_OVERFLOW:
		return "VCENC_EXCEPTION_OUTPUT_BUFFER_OVERFLOW";
	case _VCENC_EXCEPTION_HW_BUS_ERROR:
		return "VCENC_EXCEPTION_HW_BUS_ERROR";
	case _VCENC_EXCEPTION_HW_DATA_ERROR:
		return "VCENC_EXCEPTION_HW_DATA_ERROR";
	case _VCENC_EXCEPTION_HW_TIMEOUT:
		return "VCENC_EXCEPTION_HW_TIMEOUT";
	case _VCENC_EXCEPTION_HW_RESERVED:
		return "VCENC_EXCEPTION_HW_RESERVED";
	case _VCENC_EXCEPTION_SYSTEM_ERROR:
		return "VCENC_EXCEPTION_SYSTEM_ERROR";
	case _VCENC_EXCEPTION_INSTANCE_ERROR:
		return "VCENC_EXCEPTION_INSTANCE_ERROR";
	case _VCENC_EXCEPTION_HRD_ERROR:
		return "VCENC_EXCEPTION_HRD_ERROR";
	case _VCENC_EXCEPTION_HW_RESET:
		return "VCENC_EXCEPTION_HW_RESET";
	case _VCENC_EXCEPTION_HASH_LEN_MISMATCH:
		return "VCENC_EXCEPTION_HASH_LEN_MISMATCH";
	case _VCENC_EXCEPTION_FW_RESET:
		return "VCENC_EXCEPTION_FW_RESET";
	case _VCENC_EXCEPTION_INSATANCE_CHECK_MISMATCH:
		return "VCENC_EXCEPTION_INSATANCE_CHECK_MISMATCH";
	case _VCENC_EXCEPTION_IM_RESET:
		return "VCENC_EXCEPTION_IM_RESET";
	case _VCENC_EXCEPTION_ENCODE_EXT_MCU_V2:
		return "VCENC_EXCEPTION_ENCODE_EXT_MCU_V2";
	case _VCENC_EXCEPTION_HANDLE_ENCODER_ISR:
		return "VCENC_EXCEPTION_HANDLE_ENCODER_ISR";
	case _VCENC_EXCEPTION_HANG_HANTRO_RESET_ISR_FAILED:
		return "VCENC_EXCEPTION_HANG_HANTRO_RESET_ISR_FAILED";
	case _VCENC_EXCEPTION_HANTRO_VCMD_ISR_TIMEOUT:
		return "VCENC_EXCEPTION_HANTRO_VCMD_ISR_TIMEOUT";
	case _VCENC_EXCEPTION_HALT_MODE_TIME_OUT:
		return "VCENC_EXCEPTION_HALT_MODE_TIME_OUT";
	case _VCENC_EXCEPTION_NOT_RECV_IRQ:
		return "VCENC_EXCEPTION_NOT_RECV_IRQ";
	case _VCDEC_EXCEPTION_RESERVED:
		return "VCDEC_EXCEPTION_RESERVED";
	case _VCDEC_EXCEPTION_SMCU_START_DEC_TIMEOUT:
		return "VCDEC_EXCEPTION_SMCU_START_DEC_TIMEOUT";
	case _VCDEC_EXCEPTION_DECODER_INIT_FAILED:
		return "VCDEC_EXCEPTION_DECODER_INIT_FAILED";
	case _VCDEC_EXCEPTION_DECODER_RINGBUFF_ADDRESS_NULL:
		return "VCDEC_EXCEPTION_DECODER_RINGBUFF_ADDRESS_NULL";
	case _VCDEC_EXCEPTION_DECODER_RINGBUFF_FULL:
		return "VCDEC_EXCEPTION_DECODER_RINGBUFF_FULL";
	case _VCDEC_EXCEPTION_DECODER_RECV_ERROR_DATA:
		return "VCDEC_EXCEPTION_DECODER_RECV_ERROR_DATA";
	case _VCDEC_EXCEPTION_DECODER_NULL_PARAM:
		return "VCDEC_EXCEPTION_DECODER_NULL_PARAM";
	case _VCDEC_EXCEPTION_DECODER_HANDLE_EXCEPTION:
		return "VCDEC_EXCEPTION_DECODER_HANDLE_EXCEPTION";
	case _VCDEC_EXCEPTION_DECODER_RESET:
		return "VCDEC_EXCEPTION_DECODER_RESET";
	case _VCDEC_EXCEPTION_DECODER_RINGBUFF_EMPTY:
		return "VCDEC_EXCEPTION_DECODER_RINGBUFF_EMPTY";
	default:
		return "Unknown err";
	}
}

char *vastai_ras_video_sub_component_str(u8 sub_component)
{
	switch(sub_component)
	{
	case VASTAI_RAS_VIDEO_CORE_VDMCU0:
		return "VDMCU0";
	case VASTAI_RAS_VIDEO_CORE_VDMCU1:
		return "VDMCU1";
	case VASTAI_RAS_VIDEO_CORE_VDMCU2:
		return "VDMCU2";
	case VASTAI_RAS_VIDEO_CORE_VEMCU0:
		return "VEMCU0";
	case VASTAI_RAS_VIDEO_CORE_VEMCU1:
		return "VEMCU1";
	case VASTAI_RAS_VIDEO_CORE_VEMCU2:
		return "VEMCU2";
	case VASTAI_RAS_VIDEO_CORE_VEMCU3:
		return "VEMCU3";
	default:
		return "Unknown core";
	}
}

char *vastai_ras_video_handle_str(u8 process)
{
	switch(process)
	{
	case RAS_VIDEO_NOTHING:
		return "NOTHING";
	case RAS_VIDEO_RESET_VIDEO_SYS:
		return "RESET_VIDEO_SYS";
	case RAS_VIDEO_RESET_VEMCU_SUB_SYS:
		return "RESET_VEMCU_SUB_SYS";
	case RAS_VIDEO_RESET_VDMCU_SUB_SYS:
		return "RESET_VDMCU_SUB_SYS";
	default:
		return "Unknown process";
	}
}

char *vastai_ras_video_handle_status_str(u8 status)
{
	switch(status)
	{
	case RAS_VIDEO_UNKNOWN:
		return "UNKNOWN";
	case RAS_VIDEO_RESET_START:
		return "RESET_START";
	case RAS_VIDEO_RESET_END:
		return "RESET_END";
	case RAS_VIDEO_RESET_FAILE:
		return "RESET_FAILE";
	default:
		return "Unknown status";
	}
}

int vastai_ras_video_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_VIDEO)
		return -EINVAL;

	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);
	if (err_info->head.err_reason == _VCENC_EXCEPTION_ERROR) {
		sprintf(ras_buf, "[CST %s] reset event, core: %s, status: %s\n",
			time_str,
			vastai_ras_video_sub_component_str(err_info->ras_entry.video.video_event),
			vastai_ras_video_handle_status_str(err_info->ras_entry.video.status));
	} else {
		if (err_info->head.err_severity == ERR_FATAL) {
			sprintf(ras_buf, "[CST %s] %s error, video %s err: %s, handle: %s\n",
				time_str,
				"fatal",
				vastai_ras_video_sub_component_str(err_info->head.sub_component),
				vastai_ras_video_err_cause_str(err_info->head.err_reason),
				vastai_ras_video_handle_str(err_info->ras_entry.video.video_event));
		} else {
			sprintf(ras_buf, "[CST %s] %s error, video %s err: %s\n",
				time_str,
				"non-fatal",
				vastai_ras_video_sub_component_str(err_info->head.sub_component),
				vastai_ras_video_err_cause_str(err_info->head.err_reason));
		}
	}

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

int vastai_ras_ai_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_AI)
		return -EINVAL;

	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);
	sprintf(ras_buf, "[CST %s] %s error, ai %s err: %s\n",
				time_str,
				err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
				vastai_ras_ai_sub_component_str(err_info->head.sub_component),
				vastai_ras_ai_err_cause_str(err_info->head.err_reason));

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

    return 0;
}

static int vastai_ras_core_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component, sub_component;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	sub_component = err_info->head.sub_component;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	if (component != VASTAI_RAS_CORE && sub_component >= VASTAI_RAS_CORE_MAX)
		return -EINVAL;

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);

	sprintf(ras_buf, "[CST %s] %s error, %s core exception: %s, PC 0x%x, PS 0x%x\n",
				time_str,
				err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
				ras_core_name[err_info->head.sub_component],
				vastai_ras_core_exccause(err_info->head.err_reason),
				err_info->ras_entry.core.pc, err_info->ras_entry.core.ps);

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

static char *vastai_ras_ddr_cause(u8 reason)
{
	switch(reason) {
	case ECC_SINGLE_BIT_ERR:
		return "ECC 1bit err";
	case ECC_DOUBLE_BIT_ERR:
		return "ECC 2bit err";
	default:
		return "unkonwn cause";
	}
}

static int vastai_ras_ddr_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;
	struct ddr_err_entry *entry;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_DDR)
		return -EINVAL;

	entry = &err_info->ras_entry.ddr_ecc;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);
	sprintf(ras_buf, "[CST %s] %s error, DDR %s: \
				addr_l 0x%x, addr_h 0x%x, axi_id 0x%x, \
				axi_data_l 0x%x, axi_data_h 0x%x, err_bit 0x%x\n",
				time_str,
				err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
				vastai_ras_ddr_cause(err_info->head.err_reason),
				entry->addr_1, entry->addr_h, entry->axi_id,
				entry->axi_data_l, entry->axi_data_h, entry->errbit);

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

static int vastai_ras_pcie_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;
	struct pcie_err_entry *entry;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_PCIE)
		return -EINVAL;

	entry = &err_info->ras_entry.pcie;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);
	sprintf(ras_buf, "[CST %s] %s error, PCIe err: ep_or_rc %d, err_type %d, err_idx %d\n",
			time_str, err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
			err_info->head.sub_component, err_info->head.err_severity, err_info->head.err_reason);

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

static int vastai_ras_dma_handler(struct vastai_sv100_die *die, struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;
	struct dma_err_entry *entry;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_DMA)
		return -EINVAL;

	entry = &err_info->ras_entry.dma;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);
	sprintf(ras_buf, "[CST %s] %s error, DMA err: cor_cnt %d, uncor_cnt %d\n",
				time_str,
				err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
				entry->cor_cnt, entry->uncor_cnt);

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

int vastai_ras_pvt_handler(struct vastai_sv100_die *die,
		struct vastai_ras_err_info *err_info)
{
	int die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	u8 component;
	struct pvt_err_entry *entry;

	if (die == NULL || die->pci_info == NULL || err_info == NULL)
		return -EINVAL;

	component = err_info->head.component;
	if (component != VASTAI_RAS_PVT)
		return -EINVAL;

	entry = &err_info->ras_entry.pvt;
	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	vastai_ras_get_timestamp(err_info->head.timestamp, time_str);

	sprintf(ras_buf, "[CST %s] %s error, PVT: Due to %d, freq reduces to %d%%\n",
			time_str, err_info->head.err_severity & ERR_FATAL ? "fatal" : "non-fatal",
			err_info->head.err_reason, entry->percent);

	VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

	vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));
	vastai_ras_write_raw_file(die, err_info, sizeof(*err_info));

	return 0;
}

static struct ras_other_event_info _rst_evnt = {
	.list = LIST_HEAD_INIT(_rst_evnt.list),
};

static void ras_init_event_manager(void)
{
	spin_lock_init(&_rst_evnt.rst_evnt_lock);
}

/* Function to add a new reset event to the linked list */
void ras_add_other_event(u32 evt_type, int args_num, ...)
{
	int i;
	u8 die_id;
	u16 dev_id;
	va_list valist;
	u32 info[3] = {0};
	struct ras_other_event_info *event = NULL;
	struct vastai_pci_info *pcie_info = NULL;

	event = kmalloc(sizeof(*event), GFP_KERNEL);
	INIT_LIST_HEAD(&event->list);
	event->timestamp = vastai_get_host_time_ns()/1000000000;
	event->type = evt_type;

	va_start(valist, args_num);
	for (i = 0; i < args_num; i++)
		info[i] = va_arg(valist, u32);
	va_end(valist);

	dev_id = (info[0] >> 8) & 0xff;
	pcie_info = get_vastai_pci_device_info(dev_id);
	die_id = vastai_pci_get_die_id(pcie_info, info[0]);

	memcpy(event->info, info, sizeof(event->info));

	spin_lock(&_rst_evnt.rst_evnt_lock);
	list_add_tail(&event->list, &_rst_evnt.list);
	spin_unlock(&_rst_evnt.rst_evnt_lock);

	queue_work(pcie_info->dies[die_id].ras_wq,
		&(pcie_info->dies[die_id].ras_work));
}

/* Used to add RAS event of any type in PCIE driver side */
void ras_add_kern_event(struct vastai_sv100_die *die,
	struct vastai_ras_err_head err_head, int args_num, ...)
{
	int i;
	u32 die_id;
	va_list valist;
	struct ras_event_info *event = NULL;
	struct vastai_pci_info *pcie_info = NULL;
	unsigned long flags;

	if (!die->ras_enabled) return;

	event = kzalloc(sizeof(*event), GFP_KERNEL);
	event->err.head = err_head;
	INIT_LIST_HEAD(&event->list);

	if (args_num > MAX_RAS_U32_SIZE) {
		VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "%s args_num:%d exceeds max:%d\n",
					   __func__, args_num, (int)MAX_RAS_U32_SIZE);
	}

	va_start(valist, args_num);
	for (i = 0; i < args_num; i++)
		event->err.entry_paddings[i] = va_arg(valist, u32);
	va_end(valist);

	pcie_info = die->pci_info;
	die_id = vastai_pci_get_die_id(pcie_info, die->die_index);

	spin_lock_irqsave(&die->ras_evt.ras_evt_lock, flags);
	list_add_tail(&event->list, &die->ras_evt.head);
	spin_unlock_irqrestore(&die->ras_evt.ras_evt_lock, flags);

	queue_work(pcie_info->dies[die_id].ras_wq, &(pcie_info->dies[die_id].ras_work));
}

#if 0
static void ras_record_events_to_file(struct vastai_sv100_die *die)
{
	u8 die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	struct ras_event_info *event, *next_event;

	if (die == NULL || die->pci_info == NULL)
		return;

	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	spin_lock(&_rst_evnt.rst_evnt_lock);
	list_for_each_entry_safe(event, next_event, &die->ras_evt.head, list) {
		vastai_ras_get_timestamp(event->timestamp, time_str);
		switch (event->type)
		{
		case RAS_OTHER_EVENT_RST:
			sprintf(ras_buf, "[CST %s] reset event, core %s, status: %s\n",
				time_str,
				ras_core_name[event->info[1]],
				event->info[2] == RESET_START ? "RESET_START" : "RESET_END");
			break;
		default:
			VASTAI_PCI_DBG(die->pci_info, die_id, "%s Undefined event types", __func__);
			break;
		}

		VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

		vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));

		/* delete the current element */
		list_del(&event->list);
		kfree(event);
	}
	spin_unlock(&_rst_evnt.rst_evnt_lock);
}
#endif

#if 0
static void ras_record_other_event_to_file(struct vastai_sv100_die *die)
{
	u8 die_id;
	char time_str[32] = {0};
	char ras_buf[256] = {0};
	struct ras_other_event_info *event, *next_event;

	if (die == NULL || die->pci_info == NULL)
		return;

	die_id = vastai_pci_get_die_id(die->pci_info, die->die_index);

	spin_lock(&_rst_evnt.rst_evnt_lock);
	list_for_each_entry_safe(event, next_event, &_rst_evnt.list, list) {
		vastai_ras_get_timestamp(event->timestamp, time_str);
		switch (event->type)
		{
		case RAS_OTHER_EVENT_RST:
			sprintf(ras_buf, "[CST %s] reset event, core %s, status: %s\n",
				time_str,
				ras_core_name[event->info[1]],
				event->info[2] == RESET_START ? "RESET_START" : "RESET_END");
			break;
/*
		case RAS_OTHER_EVENT_TEMP:
			sprintf(ras_buf, "[CST %s] over-temperature event, Frequency %s to %d%%\n",
				time_str,
				event->info[1] > event->info[2] ? "reduced" : "increased",
				event->info[2]);
			break;
		case RAS_OTHER_EVENT_VOLT:
			sprintf(ras_buf, "[CST %s] over-current event, Frequency %s to %d%%\n",
				time_str,
				event->info[1] > event->info[2] ? "reduced" : "increased",
				event->info[2]);
			break;
		case RAS_OTHER_EVENT_BMCU:
			sprintf(ras_buf, "[CST %s] bmcu event, bmcu power down alert occurs\n",
				time_str);
			break;
*/
		default:
			VASTAI_PCI_DBG(die->pci_info, die_id, "%s Undefined event types", __func__);
			break;
		}

		VASTAI_PCI_INFO(die->pci_info, die_id, "%s", ras_buf);

		vastai_ras_write_str_file(die, ras_buf, strlen(ras_buf));

		/* delete the current element */
		list_del(&event->list);
		kfree(event);
	}
	spin_unlock(&_rst_evnt.rst_evnt_lock);
}
#endif

/* Reset event list cleanup function */
void ras_cleanup_reset_event_list(struct vastai_sv100_die* die)
{
	struct ras_event_info *event, *next_event;
	unsigned long flags;

	/* empty not processed events */
	spin_lock_irqsave(&die->ras_evt.ras_evt_lock, flags);
	list_for_each_entry_safe(event, next_event, &die->ras_evt.head, list) {
		list_del(&event->list);
		kfree(event);
	}
	spin_unlock_irqrestore(&die->ras_evt.ras_evt_lock, flags);

	/* empty save events after insmod */
	spin_lock(&die->ras_evt_afterboot.ras_evt_lock);
		list_for_each_entry_safe(event, next_event, &die->ras_evt_afterboot.head, list) {
		list_del(&event->list);
		kfree(event);
	}
	spin_unlock(&die->ras_evt_afterboot.ras_evt_lock);
}

/* This function should only be called in each die's ras_work */
void vastai_ras_save_evt_after_insmod(struct vastai_sv100_die* die,
	struct ras_event_info* evt)
{
	struct ras_event_info* discard;
	struct list_head* head;
	struct list_head* next;

	spin_lock(&die->ras_evt_afterboot.ras_evt_lock);

	head = &die->ras_evt_afterboot.head;
	list_add_tail(&evt->list, head);
	die->ras_evt_cnt++;

	if (die->ras_evt_cnt > MAX_RAS_RECORD) {
		next = head->next;
		discard = container_of(next, struct ras_event_info, list);
		list_del(&discard->list);
		die->ras_evt_cnt--;
	}

	spin_unlock(&die->ras_evt_afterboot.ras_evt_lock);

	next = die->ras_evt_afterboot.head.next;
	discard = container_of(next, struct ras_event_info, list);
	//printk("add event addr: 0x%llx\n", (u64)discard);
	//VASTAI_PCI_HEX_DUMP(KERN_INFO, "ras add buf: ", DUMP_PREFIX_NONE, 32, 4, &discard->err, 0x20, false);
}

void vastai_ras_err_handle(struct vastai_sv100_die *die, struct ras_event_info* evt)
{
	switch (evt->err.head.component) {
		case VASTAI_RAS_CORE:
			vastai_ras_core_handler(die, &evt->err);
			break;
		case VASTAI_RAS_AI:
			vastai_ras_ai_handler(die, &evt->err);
			break;
		case VASTAI_RAS_VIDEO:
			vastai_ras_video_handler(die, &evt->err);
			break;
		case VASTAI_RAS_PVT:
			vastai_ras_pvt_handler(die, &evt->err);
			break;
		case VASTAI_RAS_DDR:
			vastai_ras_ddr_handler(die, &evt->err);
			break;
		case VASTAI_RAS_PCIE:
			vastai_ras_pcie_handler(die, &evt->err);
			break;
		case VASTAI_RAS_DMA:
			vastai_ras_dma_handler(die, &evt->err);
			break;
		case VASTAI_RAS_OTHERS:
			//vastai_ras_others_handler(die, err_info);
			break;
		default:
			VASTAI_PCI_ERR(die->pci_info,
				vastai_pci_get_die_id(die->pci_info, die->die_index),
				"%s: invalid component %d\n", __func__, evt->err.head.component);
			break;
	}

	vastai_ras_save_evt_after_insmod(die, evt);
}

void ras_handle_kern_evt(struct vastai_sv100_die* die)
{
	struct list_head* next;
	unsigned long flags;
	struct ras_event_info* info;

	while (!list_empty(&die->ras_evt.head)) {
		spin_lock_irqsave(&die->ras_evt.ras_evt_lock, flags);
		next = die->ras_evt.head.next;
		info = container_of(next, struct ras_event_info, list);
		list_del(&info->list);
		spin_unlock_irqrestore(&die->ras_evt.ras_evt_lock, flags);

		vastai_ras_err_handle(die, info);
	}
}

void vastai_ras_work(struct work_struct *work)
{
	struct vastai_ras_err_info err_info = {0};
	struct ras_event_info *event = NULL;
	u32 fifo_addr = CSRAM_RAS_FIFO_BASE;
	struct vastai_sv100_die *die;

	die = container_of(work, struct vastai_sv100_die, ras_work);
	if (die == NULL || die->pci_info == NULL || !die->ras_enabled)
		return;

	while (!vastai_fifo_pop_elem(die->pci_info, die->die_index,
				fifo_addr, &err_info, NULL, NORMAL_FIFO)) {
#if 0
		switch (err_info.head.component) {
			case VASTAI_RAS_CORE:
				vastai_ras_core_handler(die, &err_info);
				break;
			case VASTAI_RAS_AI:
				vastai_ras_ai_handler(die, &err_info);
				break;
			case VASTAI_RAS_VIDEO:
				vastai_ras_video_handler(die, &err_info);
				break;
			case VASTAI_RAS_PVT:
				break;
			case VASTAI_RAS_DDR:
				vastai_ras_ddr_handler(die, &err_info);
				break;
			case VASTAI_RAS_PCIE:
				vastai_ras_pcie_handler(die, &err_info);
				break;
			case VASTAI_RAS_DMA:
				vastai_ras_dma_handler(die, &err_info);
				break;
			case VASTAI_RAS_OTHERS:
				break;
			default:
				VASTAI_PCI_ERR(die->pci_info,
					vastai_pci_get_die_id(die->pci_info, die->die_index),
					"%s: invalid component %d\n", __func__, err_info.head.component);
				break;
		}
#else

		event = kmalloc(sizeof(*event), GFP_KERNEL);
		memcpy(&event->err, &err_info, sizeof(struct vastai_ras_err_info));
		vastai_ras_err_handle(die, event);
#endif
	}

#if 0
	if (!list_empty(&_rst_evnt.list)) {
		ras_record_other_event_to_file(die);
	}
#else
	ras_handle_kern_evt(die);
#endif
}

static int check_ras_magic(struct vastai_sv100_die *die)
{
	u32 addr = RAS_INFO_BASE;
	ras_info_t info = {0};
	int ret = 0;

	ret = vastai_pci_mem_read_direct(die->pci_info, die->die_index,
				addr, &info, sizeof(ras_info_t));
	VASTAI_PCI_INFO(die->pci_info, vastai_pci_get_die_id(die->pci_info, die->die_index),
					"fw RAS magic num: 0x%x\n", info.magic);
	if (ret != 0 || info.magic != RAS_INFO_MAGIC) {
		VASTAI_PCI_INFO(die->pci_info,
				vastai_pci_get_die_id(die->pci_info, die->die_index),
				"fw RAS feature not supported\n");
		ret = -EINVAL;
	} else {
		if (info.enabled) ret = 0;
		else ret = -EINVAL;
	}

	return ret;
}

void vastai_ras_init(struct vastai_pci_info * pci_info)
{
	int i;
	if (pci_info == NULL || pci_info->is_virtfn)
		return;

	for (i = 0; i < pci_info->die_num; i++)
	{
		struct vastai_sv100_die *die = &pci_info->dies[i];

		die->ras_enabled = false;
		if (!check_ras_magic(die)) die->ras_enabled = true;
		mutex_init(&die->ras_evt.ras_lock);
		mutex_init(&die->ras_evt_afterboot.ras_lock);
		spin_lock_init(&die->ras_evt.ras_evt_lock);
		spin_lock_init(&die->ras_evt_afterboot.ras_evt_lock);
		INIT_LIST_HEAD(&die->ras_evt.head);
		INIT_LIST_HEAD(&die->ras_evt_afterboot.head);
		INIT_WORK(&(die->ras_work), vastai_ras_work);
		die->ras_wq = alloc_workqueue("ras_wq",
				WQ_MEM_RECLAIM | WQ_UNBOUND | WQ_CPU_INTENSIVE, 1);
		if (die->ras_wq == NULL) {
			VASTAI_PCI_ERR(pci_info,
				vastai_pci_get_die_id(pci_info, die->die_index),
				"%s: alloc_workqueue failed\n",	__func__);
			break;
		}
	}

	ras_init_event_manager();
}

void vastai_ras_deinit(struct vastai_pci_info *pci_info)
{
	int i;

	if (pci_info == NULL || pci_info->is_virtfn)
		return;

	for (i = 0; i < pci_info->die_num; i++)
	{
		ras_cleanup_reset_event_list(&pci_info->dies[i]);
		flush_work(&(pci_info->dies[i].ras_work));
		destroy_workqueue(pci_info->dies[i].ras_wq);
	}
}
