#include "vatools.h"

#define CREATE_TRACE_POINTS
#include "vatools_log.h"

LIST_HEAD(g_nodes_list);

/*Write data to the CSRAM header during initialization*/
T_SMI_BLOCK_HEADER g_smi_block_header = {
	0x00000002,
	0xA1000002,
	{ SMI_CMD_BLOCK0_ADDR, SMI_CMD_BLOCK1_ADDR, SMI_CMD_BLOCK2_ADDR,
	  SMI_CMD_BLOCK3_ADDR, SMI_CMD_BLOCK4_ADDR, SMI_CMD_BLOCK5_ADDR,
	  SMI_CMD_BLOCK6_ADDR, SMI_CMD_BLOCK7_ADDR }
};

/*Save the block address and use the flag*/
T_SMI_BLOCK g_smi_blocks[SMI_BLOCK_ID_MAX] = {
	{ SMI_CMD_BLOCK_ID_0, SMI_CMD_BLOCK0_ADDR, SMI_CMD_BLOCK0_LEN,
	  SMI_CMD_BLOCK_IDLE, SMI_CMD_LOOP_TOTAL_COUNT, 100 },
	{ SMI_CMD_BLOCK_ID_1, SMI_CMD_BLOCK1_ADDR, SMI_CMD_BLOCK1_LEN,
	  SMI_CMD_BLOCK_IDLE, 50, 1 },
	{ SMI_CMD_BLOCK_ID_2, SMI_CMD_BLOCK2_ADDR, SMI_CMD_BLOCK2_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 },
	{ SMI_CMD_BLOCK_ID_3, SMI_CMD_BLOCK3_ADDR, SMI_CMD_BLOCK3_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 },
	{ SMI_CMD_BLOCK_ID_4, SMI_CMD_BLOCK4_ADDR, SMI_CMD_BLOCK4_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 },
	{ SMI_CMD_BLOCK_ID_5, SMI_CMD_BLOCK5_ADDR, SMI_CMD_BLOCK5_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 },
	{ SMI_CMD_BLOCK_ID_6, SMI_CMD_BLOCK6_ADDR, SMI_CMD_BLOCK6_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 },
	{ SMI_CMD_BLOCK_ID_7, SMI_CMD_BLOCK7_ADDR, SMI_CMD_BLOCK7_LEN,
	  SMI_CMD_BLOCK_IDLE, 0, 0 }
};

/*Use block_id*/
T_SMI_BLOCK *vatools_fw_smi_get_block(struct vastai_pci_info *priv,
				      unsigned int block_id)
{
#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		struct ring_buf_entry *entry = NULL;
		u8 fn_mode = priv->priv_hw_cfg->sys_cfg.fn_mode;
		u32 fn_addr = 0;

		switch (fn_mode) {
		case ONLY_1_PF:
			entry = find_hw_cfg_acord_name(priv,
						       ONLY_1_PF_TOOLS_NAME);
			break;
		case ONLY_2_PF:
			entry = find_hw_cfg_acord_name(priv,
						       ONLY_2_PF_TOOLS_NAME);
			break;
		case ONLY_4_PF:
		case PF_4_WITH_SRIOV:
			entry = find_hw_cfg_acord_name(priv, COMMON_TOOLS_NAME);
			break;
		default:
			VATOOLS_INFO(priv, DUMMY_DIE_ID,
				     "FATAL: unknown fn_mode=%d\n", fn_mode);
		}

		if (entry == NULL) {
			VATOOLS_INFO(
				priv, DUMMY_DIE_ID,
				"FATAL: find_hw_cfg_acord_name return NULL: fn_mode=%d\n",
				fn_mode);
			return NULL;
		}

		/*entry->ring_buf_base is noc address*/
		/*fn_addr is fa address*/
		fn_addr = entry->ring_buf_base -
			  priv->bar[VASTAI_PCI_BAR2]
				  .regions[0 /*BAR2_CSRAM_01*/]
				  .noc_addr +
			  0x800000;

		VATOOLS_DBG(
			priv, DUMMY_DIE_ID,
			"fn_mode=%d entry->ring_buf_base=0x%x ring_buf_size=%d fn_addr=0x%x msgq_ctrl_reg_base=0x%x m2o_reg_base=0x%x noc_addr=0x%llx\n",
			fn_mode, entry->ring_buf_base, entry->ring_buf_size,
			fn_addr, entry->msgq_ctrl_reg_base, entry->m2o_reg_base,
			priv->bar[VASTAI_PCI_BAR2]
				.regions[0 /*BAR2_CSRAM_01*/]
				.noc_addr);

		g_smi_blocks[0].block_address =
			entry->ring_buf_base; /*fn_addr*/
		g_smi_blocks[0].block_len = SMI_CMD_BLOCK0_LEN;
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
			    "block0_base_addr(smi_ring_buf)=0x%x size=%d\n",
			    g_smi_blocks[0].block_address,
			    g_smi_blocks[0].block_len);
		return &g_smi_blocks[0];

	} else
#endif
	{
		return &g_smi_blocks[block_id];
	}
}

T_SMI_BLOCK *
vatools_fw_smi_get_block_via_app_category(unsigned int app_category,
					  struct vastai_pci_info *priv)
{
	switch (app_category) {
	case VATOOLS_APP_DUMMY:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	case VATOOLS_APP_SMI:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	case VATOOLS_APP_PROFILER:
#ifdef VATOOLS_SV_SG_MERGE
		if (vastai_get_board_type(priv) == SG100) {
			return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		} else
#endif
		{
			return &g_smi_blocks[SMI_CMD_BLOCK_ID_1];
		}
		break;
	case VATOOLS_APP_DEBUGGER:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	case VATOOLS_APP_LOGGER:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	case VATOOLS_APP_MONITOR:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	case VATOOLS_APP_SHAREDMEM:
		return &g_smi_blocks[SMI_CMD_BLOCK_ID_0];
		break;
	}

	return &g_smi_blocks[app_category];
}

/*Smi csram initialization*/
int vatools_fw_config_smi(struct vastai_pci_info *priv, int die_index)
{
	int ret;
	u8 *dummy;
	u32 size = 1024 * 4;

	dummy = (u8 *)kvmalloc(size, GFP_KERNEL);
	if (dummy == NULL) {
		VATOOLS_ERR(priv, die_index, "kvmalloc error. size=%d\n", size);
		return -ENOMEM;
	}
	memset(dummy, 0, size);

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "smi init\n");
		ret = vatools_pci_mem_write_direct(priv, die_index,
						   SMI_DIE_ADDRESS_OFFSET_BASE,
						   (u8 *)dummy, 2560);
		VATOOLS_DUMP_BRIEF(
			"fw_config_smi header init: ", &g_smi_block_header,
			sizeof(T_SMI_BLOCK_HEADER));
		ret = vatools_pci_mem_write_direct(priv, die_index,
						   SMI_DIE_ADDRESS_OFFSET_BASE,
						   (u8 *)&g_smi_block_header,
						   sizeof(T_SMI_BLOCK_HEADER));
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "smi init done. ret=%d\n", ret);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "profiler init\n");
		ret = vatools_pci_mem_write_direct(priv, die_index,
						   PROFILER_CSRAM_ADDR,
						   (u8 *)dummy,
						   PROFILER_CSRAM_LEN);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "profiler init done. ret=%d\n",
			    ret);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "debugger init\n");
		ret = vatools_pci_mem_write_direct(priv, die_index,
						   VADBG_CSRAM_ADDR,
						   (u8 *)dummy,
						   VADBG_CSRAM_LEN);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "debugger init done. ret=%d\n",
			    ret);
		kvfree(dummy);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "vatools config/init done\n");
	} else
#endif
	{
		VATOOLS_DBG(priv, die_index, "smi init\n");
		ret = vastai_pci_mem_write_direct(priv, die_index,
						  SMI_DIE_ADDRESS_OFFSET_BASE,
						  (u8 *)dummy, 2560);
		VATOOLS_DUMP_BRIEF(
			"fw_config_smi header init: ", &g_smi_block_header,
			sizeof(T_SMI_BLOCK_HEADER));
		ret = vastai_pci_mem_write_direct(priv, die_index,
						  SMI_DIE_ADDRESS_OFFSET_BASE,
						  (u8 *)&g_smi_block_header,
						  sizeof(T_SMI_BLOCK_HEADER));
		VATOOLS_DBG(priv, die_index, "smi init done. ret=%d\n", ret);
		VATOOLS_DBG(priv, die_index, "profiler init\n");
		ret = vastai_pci_mem_write_direct(priv, die_index,
						  PROFILER_CSRAM_ADDR,
						  (u8 *)dummy,
						  PROFILER_CSRAM_LEN);
		VATOOLS_DBG(priv, die_index, "profiler init done. ret=%d\n",
			    ret);
		VATOOLS_DBG(priv, die_index, "debugger init\n");
		ret = vastai_pci_mem_write_direct(priv, die_index,
						  VADBG_CSRAM_ADDR, (u8 *)dummy,
						  VADBG_CSRAM_LEN);
		VATOOLS_DBG(priv, die_index, "debugger init done. ret=%d\n",
			    ret);
		kvfree(dummy);
		VATOOLS_DBG(priv, die_index, "vatools config/init done\n");
	}

	return ret;
}

/*pci driver function called encapsulation*/
int vatools_get_vastai_pci_device_number(void)
{
	return get_vastai_pci_device_number();
}

struct vastai_pci_info *vatools_get_vastai_pci_device_info(char dev_id)
{
	return get_vastai_pci_device_info(dev_id);
}

struct vastai_pci_info *
vatools_get_vastai_pci_device_info_by_die_index(u32 die_index)
{
	union die_index_data did;
	did.val = (u32)die_index;
	return get_vastai_pci_device_info(did.dev_id);
}

/*
bar size modified, encapsulation pcie vastai_pci_mem_read function,
If the address is beyond the scope of the bar,
    the size < = 128 bytes, use smi access;
	the size > 128 bytes, use dma

Die0 BAR0: [0x00_0880_0000,0x00_0900_0000) 8M
Die0 BAR1: [0x10_0A00_0000,0x10_0A80_0000) 8M
Die0 BAR2: [0x08_4000_0000,0x08_4200_0000) 32M
Die0 BAR4: [0x18_4000_0000,0x18_4800_0000) 128M

BAR0 ----> Die0 [0x00_0880_0000,0x00_0900_0000) 8M
BAR1 ----> Die1 [0x10_08B0_0000,0x10_08D0_0000) 2M
	    Die2 [0x20_08B0_0000,0x20_08D0_0000) 2M
	    Die3 [0x30_08B0_0000,0x30_08D0_0000) 2M
BAR2/3 ----> Die0 [0x08_1400_0000,0x08_1600_0000) 32M
BAR4/5 ----> Die1 [0x18_1400_0000,0x18_1600_0000) 32M
	    Die2 [0x28_1400_0000,0x28_1600_0000) 32M
	    Die3 [0x38_1400_0000,0x38_1600_0000) 32M
*/

vatools_bar_address_t vatools_die_check[4][2] = {
	{ { 0x08800000, 0x09000000 }, { 0x0814000000, 0x0816000000 } },
	{ { 0x08b00000, 0x08d00000 }, { 0x0814000000, 0x0816000000 } },
	{ { 0x08b00000, 0x08d00000 }, { 0x0814000000, 0x0816000000 } },
	{ { 0x08b00000, 0x08d00000 }, { 0x0814000000, 0x0816000000 } }
};

/*The return value: < 0, error;> 0 is successful, the number of data*/
/*read;Success = 0*/
int vatools_pci_mem_fread(struct vastai_pci_info *priv, int die_index,
			  u64 relative_addr, void *buf, unsigned int len)
{
	int i = 0;
	int die_id =
		(die_index > 0) ? vastai_pci_get_die_id(priv, die_index) : 0;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"die_id=%d, die_index=0x%x relative_addr=0x%llx buf=%p len=%d\n",
		die_id, die_index, relative_addr, buf, len);
	V_UNREFERENCE(i);
	/*TODO: use it when sv support fread*/
	/*return vastai_pci_mem_fread(priv, relative_addr, buf, len);*/
	return vastai_pci_mem_read(priv, die_index, relative_addr, buf, len);
}

/*The return value: < 0, error;> 0 is successful, the number of data*/
/*read;Success = 0*/
int vatools_pci_mem_fwrite(struct vastai_pci_info *priv, int die_index,
			   u64 relative_addr, const void *buf, unsigned int len)
{
	int i = 0;
	int die_id =
		(die_index != -1) ? vastai_pci_get_die_id(priv, die_index) : 0;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"die_id=%d, die_index=0x%x relative_addr=0x%llx buf=%p len=%d\n",
		die_id, die_index, relative_addr, buf, len);

	V_UNREFERENCE(i);
	/*TODO: use it when sv support fread*/
	/*return vastai_pci_mem_fwrite(priv, relative_addr, (void *)buf,
	 * len);*/
	return vastai_pci_mem_write(priv, die_index, relative_addr, (void *)buf,
				    len);
}

/*The return value: < 0, error;> 0 is successful, the number of data*/
/*read;Success = 0*/
int vatools_pci_mem_read(struct vastai_pci_info *priv, int die_index,
			 u64 relative_addr, void *buf, unsigned int len)
{
	int ret = 0;
	int die_id =
		(die_index > 0) ? vastai_pci_get_die_id(priv, die_index) : 0;

	VATOOLS_DBG(
		priv, die_index,
		"die_id=%d, die_index=0x%x relative_addr=0x%llx buf=%p len=%d\n",
		die_id, die_index, relative_addr, buf, len);

	//for (i = 0; i < 2; i++) {
	//	if ((relative_addr >= vatools_die_check[die_id][i].begin &&
	//	     relative_addr < vatools_die_check[die_id][i].end)) {
	//		VATOOLS_DBG(priv, die_index, "pci_mem_read by cpu\n");
	//		/*In the address bar to access it, use pcie*/
	//		/*vastai_pci_mem_read*/
	//		return vastai_pci_mem_read(priv, die_index,
	//					   relative_addr, buf, len);
	//	}
	//}

	ret = vastai_pci_mem_read(priv, die_index,
				   relative_addr, buf, len);
	if (ret < 0) {
		VATOOLS_DBG(
			priv, die_index,
			"vastai_pci_mem_read err, ret %d\n", ret);
		if (len <= VATOOLS_BAR_SMI_MAX_BYTES) {
			VATOOLS_DBG(priv, die_index, "pci_mem_read by smi\n");
			/*Len less than or equal to smi can visit one of the biggest*/
			/*single space, the use of smi to read data*/
			return vatools_fw_smcu_read(SMI_CMD_BLOCK_ID_0, priv, die_index,
						    relative_addr, buf, len);
		} else {
			VATOOLS_DBG(priv, die_index, "pci_mem_read by dma\n");
			/*TODO: use the pcie dma read data.Temporary unrealized*/
			return vastai_pci_mem_read(priv, die_index, relative_addr, buf,
						   len);
		}
	}
	return ret;
}

/*The return value: < 0, error;> 0 is successful, the number of data*/
/*read;Success = 0*/
int vatools_pci_mem_write(struct vastai_pci_info *priv, int die_index,
			  u64 relative_addr, const void *buf, unsigned int len)
{
	int ret = 0;
	int die_id =
		(die_index != -1) ? vastai_pci_get_die_id(priv, die_index) : 0;

	VATOOLS_DBG(
		priv, die_index,
		"die_id=%d, die_index=0x%x relative_addr=0x%llx buf=%p len=%d\n",
		die_id, die_index, relative_addr, buf, len);

	//for (i = 0; i < 2; i++) {
	//	if ((relative_addr >= vatools_die_check[die_id][i].begin &&
	//	     relative_addr < vatools_die_check[die_id][i].end)) {
	//		VATOOLS_DBG(priv, die_index, "pci_mem_write by cpu\n");
	//		/*In the address bar to access it, use pcie*/
	//		/*vastai_pci_mem_read*/
	//		return vastai_pci_mem_write(priv, die_index,
	//					    relative_addr, buf, len);
	//	}
	//}

	ret = vastai_pci_mem_write(priv, die_index,
						    relative_addr, buf, len);
	if (ret < 0) {
		VATOOLS_DBG(
			priv, die_index,
			"vastai_pci_mem_write err, ret %d\n", ret);
		if (len <= VATOOLS_BAR_SMI_MAX_BYTES) {
			VATOOLS_DBG(priv, die_index, "pci_mem_write by smi\n");
			/*Len less than or equal to smi can visit one of the biggest*/
			/*single space, the use of smi to read data*/
			return vatools_fw_smcu_write(SMI_CMD_BLOCK_ID_0, priv,
						     die_index, relative_addr, buf,
						     len);
		} else {
			VATOOLS_DBG(priv, die_index, "pci_mem_write by dma\n");
			/*TODO: use the pcie dma read data.Temporary unrealized*/
			return vastai_pci_mem_write(priv, die_index, relative_addr, buf,
						    len);
		}
	}
	return ret;
}

/*modifies u8 * buf command inside the flag of parameters, is changed to 0.*/
/*After the DDR data are written, is set to 1, then send to smcu*/
void vatools_driver_smi_set_flag(u8 *buf, u32 size, u8 flag)
{
	V_UNREFERENCE(size);
	*(buf + 6) = flag;
	VATOOLS_DUMP_BRIEF("driver_smi_set_flag: ", buf, size);
	return;
}
int vatools_get_vastai_die_info_via_device_id(char dev_id, int die_index[],
					      int *die_num)
{
	return get_vastai_die_info(vatools_get_vastai_pci_device_info(dev_id),
				   die_index, die_num);
}

u32 vatools_get_vastai_pci_die_index(char dev_id, int die_id)
{
	int ret;
#ifdef VATOOLS_SV_SG_MERGE
	vatools_die_index_data_t did = { 0 };
#endif
	struct vastai_pci_info *priv =
		vatools_get_vastai_pci_device_info(dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		return ret;
	}

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
				    VASTAI_DEBUG_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		did.dev_id = dev_id;
		did.die_id = priv->pkg_id;
		did.seq_num = 0;
		return did.val;
	} else
#endif
	{
		return priv->dies[die_id].die_index;
	}
}

/*/ dump smi block memory*/
int vatools_dump_smi_block_mem(struct vastai_pci_info *priv, int die_index,
			       u32 block_id, u32 len, int from, char *bak_buf,
			       int bak_buf_len)
{
	int ret = 0;
	void *buffer;
	T_SMI_BLOCK *psmi_block;
	u64 smi_die_address_offset;
	char title[100];

	memset(title, 0, 100);

	psmi_block = vatools_fw_smi_get_block(priv, block_id);
	smi_die_address_offset = psmi_block->block_address;

	buffer = kvmalloc(len, GFP_KERNEL);
	if (!buffer) {
		VATOOLS_ERR(priv, die_index, " kvmalloc error. size=%d\n", len);
		ret = -ENOMEM;
		goto out;
	}
	memset(buffer, 0x00, len);
	ret = vastai_pci_mem_read(priv, die_index, smi_die_address_offset,
				  buffer, len);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index, "vastai_pci_mem_read ret=%d\n",
			     ret);
		goto out_kfree;
	}

	if (bak_buf_len != 0) {
		memset(bak_buf, 0, bak_buf_len);
		memcpy(bak_buf, buffer, len);
	} else {
		memset(title, 0, 100);
		sprintf(title,
			"vastai DUMP [VATOOLS] [die_index=%08x block=0x%x addr=0x%llx from=%d] ",
			die_index, block_id, smi_die_address_offset, from);

		VATOOLS_DUMP_DATA(title, buffer, len);
	}

out_kfree:
	kvfree(buffer);
out:
	return ret;
}

int vatools_fw_send_interrupt(struct vastai_pci_info *priv, int die_index,
			      u32 type)
{
#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		int ret;
		struct pcie_transfer_cmd trans;
		u32 host_to_smcu_cmd_buf = COMMON_HOST_TO_SMCU_CMD_BUF;

		/*TODO: wait alloc a code for SMI*/
		trans.w0.s_data0.optcode = SMCU_SMI_CMD_REQ;
		trans.w0.s_data0.rev0 = 0;
		trans.w0.s_data0.rev1 = 0;
		trans.w0.s_data0.rev2 = 0;
		trans.w1.data1 = 0;
		trans.w2.data2 = 0;
		trans.w3.data3 = 0;
		VATOOLS_DBG(priv, die_index, "fn_mode=%d\n",
			    priv->priv_hw_cfg->sys_cfg.fn_mode);

		switch (priv->priv_hw_cfg->sys_cfg.fn_mode) {
		case ONLY_1_PF:
			host_to_smcu_cmd_buf = ONLY_1PF_HOST_TO_SMCU_CMD_BUF;
			break;
		case ONLY_2_PF:
			host_to_smcu_cmd_buf = ONLY_2PF_HOST_TO_SMCU_CMD_BUF;
			break;
		case ONLY_4_PF:
		case PF_4_WITH_SRIOV:
			host_to_smcu_cmd_buf = COMMON_HOST_TO_SMCU_CMD_BUF;
			break;
		default:
			VATOOLS_INFO(priv, die_index,
				     "FATAL: unknown fn_mode=%d.\n",
				     priv->priv_hw_cfg->sys_cfg.fn_mode);
		}

		ret = vastai_pci_send_msg(priv, 0, host_to_smcu_cmd_buf, &trans,
					  0);
		if (ret != 0) {
			VATOOLS_DBG(priv, die_index,
				    "vastai_pci_send_msg failed.\n");
		} else {
			VATOOLS_DBG(priv, die_index,
				    "vastai_pci_send_msg success.\n");
		}
		return 0;
	} else
#endif
	{
		struct pcie_transfer_info trans = { .type = type };
		u32 die_id = vastai_pci_get_die_id(priv, die_index);
		int ret;
		u32 msgq_id;

		msgq_id = vastai_get_msgq_id(priv, MSGQ_CMD);
		ret = vastai_pci_vmsgq_wr(&(priv->dies[die_id].vmsgq[msgq_id]),
					  &trans, sizeof(trans));

		if (ret)
			return -EINVAL;
		return 0;
	}
}

int vatools_fw_send_smi_interrupt(struct vastai_pci_info *priv, int die_index)
{
	VATOOLS_DBG(priv, die_index, "priv=%p, die_index=0x%x\n", priv,
		    die_index);

	return vatools_fw_send_interrupt(priv, die_index, VASTAI_SMI);
}

int vatools_wait_smi_ack(struct vastai_pci_info *priv, u32 die_index,
			 u32 block_id, int from, char *bak_buf, int bak_buf_len)
{
	struct vastai_sv100_die *die;
	int ret;
	u32 die_id;
	union die_index_data did;
	u32 msg = 0;
	u32 timeout_ms = SMI_CMD_ACK_WAIT_MS;

	did.val = (u32)die_index;
	die_id = did.die_id;

	VATOOLS_DBG(priv, die_index,
		    "priv=%p, die_index=0x%x die_id=%d wait start from=%d\n",
		    priv, die_index, die_id, from);

	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_index, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		return -EINVAL;
	}
	die = &(priv->dies[die_id]);

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		ret = wait_for_completion_interruptible_timeout(
			&(priv->tools_info.smi_ack[block_id]),
			msecs_to_jiffies(timeout_ms));
		msg = priv->tools_info.smi_ack_msg[block_id];
		reinit_completion(&(priv->tools_info.smi_ack[block_id]));
	} else
#endif
	{
		/*wait completion int from smcu*/
		/*if the user interrupt, need to be here to clear the last smi
		   ack response of commands, Otherwise each entry here, wait_for
		   will return directly, lead to wait and ack don't match*/
		/*reinit_completion(&(die->smi_ack[block_id]));*/
		ret = wait_for_completion_interruptible_timeout(
			&(die->smi_ack[block_id]),
			msecs_to_jiffies(timeout_ms));
		msg = die->smi_ack_msg[block_id];
		reinit_completion(&(die->smi_ack[block_id]));
	}
	VATOOLS_DBG(
		priv, die_index,
		"wait completion ret=%d msg=0x%x die_id=%d die_index=0x%x block_id=%d\n",
		ret, msg, die_id, die_index, block_id);
	if (ret == 0) {
		VATOOLS_DBG(priv, die_index, "timeout! (%d ms) ret=%d\n",
			    timeout_ms, ret);

		/*dump data for debug*/
		vatools_dump_smi_block_mem(priv, die_index, block_id, 128, from,
					   bak_buf, bak_buf_len);
		return -ETIMEDOUT;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(priv, die_index, "process be killed! ret=%d\n",
			    ret);
		return -EINTR;
	} else if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "Unknow err! ret=%d\n", ret);
		return -EIO;
	} else {
		VATOOLS_DBG(priv, die_index, "done. msg(flag)=0x%x\n", msg);
#ifdef VATOOLS_SV_SG_MERGE
		if (vastai_get_board_type(priv) == SG100) {
			return (msg & 0xFF);
		} else
#endif
		{
			return msg;
		}
	}
}

/*use smi accessed DDR and CSR through SMCU*/
int vatools_fw_smcu_read(u32 block_id, struct vastai_pci_info *priv,
			 int die_index, u64 relative_addr, void *buf,
			 unsigned int len)
{
	int ret;
	int ready = 0;
	void *get_buffer;
	T_SMI_BLOCK *psmi_block;
	u64 smi_die_address_offset;
	u32 loop;
	u32 interval;
	TS_SMI_CMD_REQ cmd;
	struct vastai_sv100_die *die;
	union die_index_data did;
	u32 die_id;

	VATOOLS_DBG(priv, die_index, "block_id=%d, priv=%p, die_index=0x%x\n",
		    block_id, priv, die_index);

	if (len % 4 != 0) {
		VATOOLS_DBG(priv, die_index, "len=%d, not align by 4 bytes\n",
			    len);
		ret = -EFAULT;
		goto out;
	}

	psmi_block = vatools_fw_smi_get_block(priv, block_id);
	smi_die_address_offset = psmi_block->block_address;
	loop = psmi_block->query_count;
	interval = psmi_block->query_interval;

	cmd.cmd = SMI_CMD_CODE_CTL_READ;
	cmd.flag = FLAG_APP_PREPARE;
	cmd.unit = VATOOLS_UINT32_MAX;
	cmd.data_len = (u16)len;
	cmd.rw_addr = relative_addr & 0xffffffffffffUL;

	VATOOLS_DUMP_BRIEF("fw_smcu_read write cmd: ", &cmd, sizeof(cmd));

	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset,
				   (u8 *)&cmd, sizeof(TS_SMI_CMD_REQ));
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out;
	}

	/*set flag to 1, write only 4 bytes , sync with fw*/
	cmd.flag = FLAG_APP_REQ;
	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset + 4,
				   ((u8 *)&cmd) + 4, sizeof(u32));
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out;
	}

	/*if the user interrupt, need to be here to clear the last smi
	   ack response of commands, Otherwise each entry here, wait_for
	   will return directly, lead to wait and ack don't match*/
	did.val = (u32)die_index;
	die_id = did.die_id;
	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_index, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		ret = -EINVAL;
		goto out;
	}
	die = &(priv->dies[die_id]);

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		reinit_completion(&(priv->tools_info.smi_ack[block_id]));
	} else
#endif
	{
		reinit_completion(&(die->smi_ack[block_id]));
	}

	ret = vatools_fw_send_smi_interrupt(priv, die_index);
	ret = vatools_wait_smi_ack(priv, die_index, block_id, 1, NULL, 0);
	if (ret < 0) {
		if (ret == -EINTR) {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d ret=%d(-EINTR)\n",
				die_index, block_id, ret);
			goto out;
		} else if (ret == -ETIMEDOUT) {
			VATOOLS_DBG(
				priv, die_index,
				"smiack: die_index=0x%x block_id=%d ret=%d(-ETIMEDOUT)\n",
				die_index, block_id, ret);
		} else {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d ret=%d\n",
				die_index, block_id, ret);
			goto out;
		}
	} else if (ret != FLAG_FW_DATA_READY) {
		ret = -ENXIO;
		goto out;
	}

	get_buffer = kzalloc(sizeof(TS_SMI_CMD_REQ) + len, GFP_KERNEL);

	memset(get_buffer, 0x00, sizeof(TS_SMI_CMD_REQ) + len);
	ret = vastai_pci_mem_read(priv, die_index, smi_die_address_offset,
				  get_buffer, sizeof(TS_SMI_CMD_REQ) + len);
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out_kfree;
	}

	VATOOLS_DUMP_BRIEF("fw_smcu_read read get_buffer: ", get_buffer,
			   sizeof(TS_SMI_CMD_REQ) + len);

	memcpy(&cmd, get_buffer, sizeof(TS_SMI_CMD_REQ));

	VATOOLS_DBG(priv, die_index, "read cmd.flag=%d\n", cmd.flag);

	if (cmd.flag == FLAG_FW_DATA_READY) {
		ready = 1;
		/*data ready*/
		memcpy(buf, ((u8 *)get_buffer) + sizeof(TS_SMI_CMD_REQ), len);
		ret = len;
		goto out_kfree;
	} else if (cmd.flag == FLAG_FW_ERROR_ABORT) {
		ret = -ENXIO;
		goto out_kfree;
	}

out_kfree:
	kvfree(get_buffer);
out:
	VATOOLS_DBG(priv, die_index, "done ret=%d\n", ret);

	return ret;
}

int vatools_fw_smcu_write(u32 block_id, struct vastai_pci_info *priv,
			  int die_index, u64 relative_addr, const void *buf,
			  unsigned int len)
{
	int ret;
	int ready = 0;
	void *get_buffer;
	TS_SMI_CMD_REQ cmd;
	void *set_buffer;
	T_SMI_BLOCK *psmi_block;
	u64 smi_die_address_offset;
	u32 loop;
	u32 interval;
	struct vastai_sv100_die *die;
	union die_index_data did;
	u32 die_id;

	VATOOLS_DBG(priv, die_index, "block_id=%d, priv=%p, die_index=0x%x\n",
		    block_id, priv, die_index);

	if (len % 4 != 0) {
		VATOOLS_DBG(priv, die_index, "len=%d, not align by 4 bytes\n",
			    len);
		ret = -EFAULT;
		goto out;
	}

	psmi_block = vatools_fw_smi_get_block(priv, block_id);
	smi_die_address_offset = psmi_block->block_address;
	loop = psmi_block->query_count;
	interval = psmi_block->query_interval;

	cmd.cmd = SMI_CMD_CODE_CTL_WRITE;
	cmd.flag = FLAG_APP_PREPARE;
	cmd.unit = 0;
	cmd.data_len = (u16)len;
	cmd.rw_addr = relative_addr & 0xffffffffffffUL;

	VATOOLS_DUMP_BRIEF("fw_smcu_write cmd: ", &cmd, sizeof(cmd));

	set_buffer = kzalloc(sizeof(TS_SMI_CMD_REQ) + cmd.data_len, GFP_KERNEL);

	memcpy(set_buffer, &cmd, sizeof(TS_SMI_CMD_REQ));
	memcpy(((u8 *)set_buffer) + sizeof(TS_SMI_CMD_REQ), buf, cmd.data_len);

	VATOOLS_DUMP_BRIEF("fw_smcu_write write_buffer: ", set_buffer,
			   sizeof(TS_SMI_CMD_REQ) + cmd.data_len);

	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset,
				   (void *)set_buffer,
				   sizeof(TS_SMI_CMD_REQ) + cmd.data_len);

	if (ret) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out_kfree;
	}

	/*set flag to 1, write only 4 bytes , sync with fw*/
	cmd.flag = FLAG_APP_REQ;
	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset + 4,
				   ((u8 *)&cmd) + 4, sizeof(u32));
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out_kfree;
	}

	/*if the user interrupt, need to be here to clear the last smi
	   ack response of commands, Otherwise each entry here, wait_for
	   will return directly, lead to wait and ack don't match*/
	did.val = (u32)die_index;
	die_id = did.die_id;
	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_index, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		ret = -EINVAL;
		goto out;
	}
	die = &(priv->dies[die_id]);
#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100)
		reinit_completion(&(priv->tools_info.smi_ack[block_id]));
	else
#endif
		reinit_completion(&(die->smi_ack[block_id]));

	ret = vatools_fw_send_smi_interrupt(priv, die_index);
	ret = vatools_wait_smi_ack(priv, die_index, block_id, 2, NULL, 0);
	if (ret < 0) {
		if (ret == -EINTR) {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d ret=%d(-EINTR)\n",
				die_index, block_id, ret);
			goto out;
		} else if (ret == -ETIMEDOUT) {
			VATOOLS_DBG(
				priv, die_index,
				"smiack: die_index=0x%x block_id=%d ret=%d(-ETIMEDOUT)\n",
				die_index, block_id, ret);
		} else {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d ret=%d\n",
				die_index, block_id, ret);
			goto out;
		}
	} else if (ret != FLAG_FW_DATA_READY) {
		ret = -ENXIO;
		goto out;
	}

	get_buffer = kzalloc(sizeof(TS_SMI_CMD_REQ) + len, GFP_KERNEL);

	memset(get_buffer, 0x00, sizeof(TS_SMI_CMD_REQ) + len);
	ret = vastai_pci_mem_read(priv, die_index, smi_die_address_offset,
				  get_buffer, sizeof(TS_SMI_CMD_REQ) + len);
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
		goto out_kfree;
	}

	VATOOLS_DUMP_BRIEF("fw_smcu_write read_buffer: ", get_buffer,
			   sizeof(TS_SMI_CMD_REQ) + len);

	memcpy(&cmd, get_buffer, sizeof(TS_SMI_CMD_REQ));

	VATOOLS_DBG(priv, die_index, "write cmd.flag=%d\n", cmd.flag);

	if (cmd.flag == FLAG_FW_DATA_READY) {
		ready = 1;
		ret = 0;
		goto out_kfree_get_buffer;
	} else if (cmd.flag == FLAG_FW_ERROR_ABORT) {
		ret = -ENXIO;
		goto out_kfree_get_buffer;
	}

out_kfree_get_buffer:
	kvfree(get_buffer);

out_kfree:
	kvfree(set_buffer);
out:
	VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);

	return ret;
}

/******************************************************************************/
/*smi cmd block end*/
/******************************************************************************/

struct vatools_node *vatools_file_get_node(struct file *filp)
{
	struct vatools_reader *reader =
		(struct vatools_reader *)filp->private_data;
	if (!reader) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "reader NULL\n");
		return NULL;
	}
	return reader->node;
}

struct vatools_reader *vatools_file_get_reader(struct file *filp)
{
	struct vatools_reader *reader =
		(struct vatools_reader *)filp->private_data;
	return reader;
}

#define VATOOLS_SMI_RETRY_COUNT (3)
#define VATOOLS_SMI_DUMP_SIZE	(128)

u16 vatools_get_smi_seq(void)
{
	static u16 seq = 0;
	seq++;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "smi current seq = %d\n", seq);
	return seq;
}

/*write first, then read, when check the flag*/
long vatools_driver_smi_fetch(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg)
{
	/*struct vatools_node*   node   = vatools_file_get_node( filp );*/
	/*struct vatools_reader* reader = vatools_file_get_reader( filp );*/

	long ret;
	void __user *argp = (void __user *)arg;
	int write_len = 0;
	int read_len = 0;

	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };
	TS_SMI_CMD_REQ smi_cmd = { 0 };
	TS_SMI_CMD_REQ *smi_cmd_p = NULL;

	struct vastai_pci_info *priv = NULL;
	u32 die_index = DUMMY_DIE_ID;
	void *write_buf = NULL;
	T_SMI_BLOCK *smi_block = NULL;
	u64 smi_die_address_offset = 0;
	int ready = 0;
	void *read_buf = NULL;
	int re_trigger_fw_count = VATOOLS_SMI_RETRY_COUNT;
	int ret2 = 0;
	struct vastai_sv100_die *die;
	union die_index_data did;
	u32 die_id;
	char title[100] = { 0 };
	char bak_buf[VATOOLS_SMI_RETRY_COUNT * VATOOLS_SMI_DUMP_SIZE] = { 0 };
	u8 temp_cmd = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl_cmd=0x%x\n", cmd);

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, (void __user *)argp, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_index = kdata.device.die_index;
	VATOOLS_DBG(priv, die_index,
		    "block_id=%d  device_id=%d  die_id=%d  flag=0x%x  addr= "
		    "0x%llx\n",
		    kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		    kdata.flag, kdata.address);
	VATOOLS_DBG(
		priv, die_index,
		"read_len=%d  read_buf=0x%llx  write_len=%d  write_buf=0x%llx\n",
		kdata.output_buf.buf_size, kdata.output_buf.buf_addr,
		kdata.input_buf.buf_size, kdata.input_buf.buf_addr);

	kdata.errcode = -0x70000;

	write_len = kdata.input_buf.buf_size;
	read_len = kdata.output_buf.buf_size;
	if ((read_len % 4 != 0) || (write_len % 4 != 0)) {
		VATOOLS_INFO(
			priv, die_index,
			"read_len=%d, write_len=%d, not align by 4 bytes\n",
			read_len, write_len);
		ret = -EFAULT;
		goto out;
	}

	priv = vatools_get_vastai_pci_device_info((char)kdata.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     kdata.device.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}
	/*die_index =*/
	/*vatools_get_vastai_pci_die_index((char)kdata.device.dev_id,*/
	/*					     kdata.device.die_id);*/
	/*if (die_index < 0) {*/
	/*	ret = -ENODEV;*/
	/*	goto out;*/
	/*}*/
	did.val = (u32)die_index;
	die_id = did.die_id;

	trace_smi_fetch_start(priv, did.die_id, did.dev_id, did.seq_num,
			      __func__);


	write_buf = kzalloc(kdata.input_buf.buf_size, GFP_KERNEL);
	if (write_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index, "kzalloc write_buf ret=%ld\n",
			    ret);
		goto out;
	}

	ret = copy_from_user_ex(write_buf,
				(void __user *)kdata.input_buf.buf_addr,
				kdata.input_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_write_buf;
	}

	VATOOLS_DUMP_BRIEF("driver_smi_fetch write_buf: ", write_buf,
			   kdata.input_buf.buf_size);

#ifdef CONFIG_TOOLS_V2
	/*Here you need to add mutex control for v2 ioctl. Compatible with v1 IOCTL, all SMIs that use the same resource, and mutex is required to read*/
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	/*Check the SMI command here, if is SMI_CMD_CODE_SPI_WRITE, remove*/
	/*dev_info cache*/
	smi_cmd_p = (TS_SMI_CMD_REQ *)write_buf;
	if (smi_cmd_p != NULL) {
		temp_cmd = smi_cmd_p->cmd;
	}

	/*set smi req seq*/
	smi_cmd_p->seq = vatools_get_smi_seq();
	smi_block = vatools_fw_smi_get_block(priv, kdata.block_id);
	smi_die_address_offset = smi_block->block_address;

	VATOOLS_DBG(priv, die_index, "smi_block->block_address=0x%08x\n",
		    smi_block->block_address);

	vatools_driver_smi_set_flag((u8 *)write_buf, kdata.input_buf.buf_size,
				    FLAG_APP_PREPARE); /*clear flag to 0*/

	ret = vatools_pci_mem_write(priv, die_index, smi_die_address_offset,
				    (u8 *)write_buf, kdata.input_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vatools_pci_mem_write flag=0 ret=%ld\n", ret);
		goto out_free_write_buf_lock;
	}

	/*set flag to 1, write only 4 bytes, sync with fw*/
	vatools_driver_smi_set_flag((u8 *)write_buf, kdata.input_buf.buf_size,
				    FLAG_APP_REQ);

	VATOOLS_DBG(
		priv, die_index,
		"smi req cmd=0x%x flag=0x%x unit=0x%08x datalen=%u rw_addr=0x%llx seq=%u\n",
		smi_cmd_p->cmd, smi_cmd_p->flag, smi_cmd_p->unit,
		smi_cmd_p->data_len, (u64)smi_cmd_p->rw_addr, smi_cmd_p->seq);

	ret = vatools_pci_mem_write(priv, die_index, smi_die_address_offset + 4,
				    ((u8 *)write_buf) + 4, sizeof(u32));

	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vatools_pci_mem_write flag=1 ret=%ld\n", ret);
		goto out_free_write_buf_lock;
	}

	read_buf = kzalloc(kdata.output_buf.buf_size, GFP_KERNEL);
	if (read_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index, "kzalloc read_buf=NULL ret=%ld\n",
			    ret);
		goto out_free_write_buf_lock;
	}

/*if the fw response, not send 3 times repeated requests.*/
re_trigger_fw:

	/*if the user interrupt, need to be here to clear the last smi
	   ack response of commands, Otherwise each entry here, wait_for
	   will return directly, lead to wait and ack don't match*/
	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_index, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		ret = -EINVAL;
		goto out_free_read_buf;
	}
	die = &(priv->dies[die_id]);
#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100)
		reinit_completion(&(priv->tools_info.smi_ack[kdata.block_id]));
	else
#endif
		reinit_completion(&(die->smi_ack[kdata.block_id]));

	ret = vatools_fw_send_smi_interrupt(priv, die_index);

	ret = vatools_wait_smi_ack(
		priv, die_index, kdata.block_id, 3,
		(bak_buf + (VATOOLS_SMI_DUMP_SIZE *
			    (VATOOLS_SMI_RETRY_COUNT - re_trigger_fw_count))),
		VATOOLS_SMI_DUMP_SIZE);
	if (ret < 0) {
		if (ret == -EINTR) {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld(-EINTR) re_trigger_fw_count=%d\n",
				die_index, kdata.block_id, ret,
				re_trigger_fw_count);
			goto out_free_read_buf;
		} else if (ret == -ETIMEDOUT) {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld(-ETIMEDOUT) re_trigger_fw_count=%d\n",
				die_index, kdata.block_id, ret,
				re_trigger_fw_count);
		} else {
			VATOOLS_DBG(
				priv, die_index,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld re_trigger_fw_count=%d\n",
				die_index, kdata.block_id, ret,
				re_trigger_fw_count);
			goto out_free_read_buf;
		}
	}

	memset(read_buf, 0x00, kdata.output_buf.buf_size);
	ret = vatools_pci_mem_read(priv, die_index, smi_die_address_offset,
				   read_buf, kdata.output_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index, "ret=%ld\n", ret);
		goto out_free_read_buf;
	}

	VATOOLS_DUMP_BRIEF("driver_smi_fetch read_buf: ", read_buf,
			   kdata.output_buf.buf_size);

	memcpy(&smi_cmd, read_buf, sizeof(TS_SMI_CMD_REQ));

	VATOOLS_DBG(
		priv, die_index,
		"smi rsp cmd=0x%x flag=0x%x unit=0x%08x datalen=%u rw_addr=0x%llx seq=%u\n",
		smi_cmd.cmd, smi_cmd.flag, smi_cmd.unit, smi_cmd.data_len,
		(u64)smi_cmd.rw_addr, smi_cmd.seq);

	/*check smi req and rsp sequence*/
	if (smi_cmd_p->seq != smi_cmd.seq) {
		VATOOLS_INFO(priv, die_index,
			     "smi warning: req.seq(%u) != rsp.seq(%u)\n",
			     smi_cmd_p->seq, smi_cmd.seq);
		VATOOLS_INFO(
			priv, die_index,
			"smi req cmd=0x%x flag=0x%x unit=0x%08x datalen=%u rw_addr=0x%llx seq=%u\n",
			smi_cmd_p->cmd, smi_cmd_p->flag, smi_cmd_p->unit,
			smi_cmd_p->data_len, (u64)smi_cmd_p->rw_addr,
			smi_cmd_p->seq);
		VATOOLS_INFO(
			priv, die_index,
			"smi rsp cmd=0x%x flag=0x%x unit=0x%08x datalen=%u rw_addr=0x%llx seq=%u\n",
			smi_cmd.cmd, smi_cmd.flag, smi_cmd.unit,
			smi_cmd.data_len, (u64)smi_cmd.rw_addr, smi_cmd.seq);
	}

	if (smi_cmd.flag == FLAG_FW_DATA_READY) {
		kdata.errcode = smi_cmd.flag | 0x1000;
	} else {
		kdata.errcode = -(smi_cmd.flag | 0x1000);
	}

	if (smi_cmd.flag == FLAG_APP_REQ) {
		/*fw is not responding, flag is request state, smcu did not*/
		/*have any processing and resend the request. Cycle ends at 3*/
		/*times*/
		VATOOLS_DBG(
			priv, die_index,
			"SMCU not responding: smi_cmd.flag == FLAG_APP_REQ(0x01): re_trigger_fw_count=%d\n",
			re_trigger_fw_count);
		/*Re_trigger_fw_count starting value is 3, begin to use. 3,
		 * 2,*/
		/*1 re - trigger execution*/
		if (re_trigger_fw_count > 1) {
			re_trigger_fw_count--;
			VATOOLS_DBG(
				priv, die_index,
				"SMCU not responding: smi_cmd.flag == FLAG_APP_REQ(0x01): re_trigger_fw_count=%d, re_trigger_fw now. \n",
				re_trigger_fw_count);
			goto re_trigger_fw;
		}
		sprintf(title,
			"vastai DUMP [VATOOLS] [die_index=%08x block=0x%x addr=0x%llx from=%d] ",
			die_index, kdata.block_id, smi_die_address_offset, 3);
		VATOOLS_DUMP_DATA(title, bak_buf,
				  VATOOLS_SMI_DUMP_SIZE *
					  VATOOLS_SMI_RETRY_COUNT);
	} else {
		/*if smcu reply, whatever the results, are no longer retry*/
		ready = 1;
		/*Data is ready*/
		VATOOLS_DBG(priv, die_index,
			    "READY: kdata.output_buf.buf_addr=0x%llx"
			    "kdata.output_buf.buf_size=%d\n",
			    kdata.output_buf.buf_addr,
			    kdata.output_buf.buf_size);

		ret = copy_to_user_ex((void __user *)kdata.output_buf.buf_addr,
				      read_buf, kdata.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_free_read_buf;
		}

		goto out_free_read_buf;
	}

	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_read_buf;
	}
	ret = -ETIME;
	goto out_free_read_buf;

out_free_read_buf:
	kvfree(read_buf);

out_free_write_buf_lock:
#ifdef CONFIG_TOOLS_V2
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

out_free_write_buf:
	kvfree(write_buf);


	if (temp_cmd == SMI_CMD_CODE_SPI_WRITE) {
		refresh_pcie_inventory_cache();
	}
out:
	if (kdata.errcode == -0x70000) {
		kdata.errcode = ret;
	}
	ret2 = copy_to_user_ex((void __user *)argp, &kdata, sizeof(kdata));
	if (ret2) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_index, "out: ret=%ld   ret2=%d\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	trace_smi_fetch_end(priv, did.die_id, did.dev_id, did.seq_num,
			    __func__);

	return ret2;
}

struct list_head *vatools_get_vastai_head(void)
{
	return &g_nodes_list;
}

#if (TOOLS_WIN == 1)
/*on windows*/

/*dma allocate memory*/
int vatools_ioctl_dma_alloc(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	struct dma_buf *dmabuf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.alloc_cmd.die_index;
	die_index = vcmd.cmd.alloc_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "priv is NULL, dev_id[%u]\n",
			     did.dev_id);
		return -ENODEV;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%x, size=%u\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.alloc_cmd.dma_buf_fd, vcmd.cmd.alloc_cmd.size);

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (iommu_is_enable(priv))
		dmabuf = vastai_alloc_dma_buf_sg(priv, vcmd.cmd.alloc_cmd.size);
	else
		dmabuf = vastai_alloc_dma_buf(priv, vcmd.cmd.alloc_cmd.size);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	if (dmabuf) {
		struct dma_buf *fd = dma_buf_fd(dmabuf, O_CLOEXEC);
		vcmd.cmd.alloc_cmd.dma_buf_fd = fd;
		vcmd.cmd.alloc_cmd.hostva = (u64)dmabuf->userva;
	} else {
		vcmd.cmd.alloc_cmd.dma_buf_fd = 0; /*-ENOMEM;*/
	}

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}
	return ret;
}

/*dma transfers*/
int vatools_ioctl_dma_start(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	union die_index_data did;
	/*struct dma_buf* dmabuf = NULL;*/
	/*struct vastai_dmadesc desc;*/
	union core_bitmap core_id = { .val = 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.dma_start_cmd.die_index;
	die_index = vcmd.cmd.dma_start_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "priv is NULL, dev_id[%u]\n",
			     did.dev_id);
		return -ENODEV;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%llx, size=%u, axi_addr=0x%llx, is_dev_to_host=%u.\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.dma_start_cmd.dma_buf_fd, vcmd.cmd.dma_start_cmd.size,
		vcmd.cmd.dma_start_cmd.axi_addr,
		vcmd.cmd.dma_start_cmd.is_dev_to_host);

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	enum VHAL_DMA_DIRECTION dir;
	if (vcmd.cmd.dma_start_cmd.is_dev_to_host) {
		dir = VHAL_DMA_DIRECTION_DEVTOHOST;
	} else {
		dir = VHAL_DMA_DIRECTION_HOSTTODEV;
	}
	ret = VHal_Dma_DmaStart(priv, vcmd.cmd.dma_start_cmd.dma_buf_fd,
				die_index, vcmd.cmd.dma_start_cmd.axi_addr, dir,
				core_id);

	return ret;
}

int vastai_ioctl_dma_trans_set_desc(struct vastai_dmadesc *desc,
				    struct dma_buf *dmabuf,
				    struct kchar_cmd *kcmd, int i,
				    u32 done_size, u32 temp_size,
				    struct vastai_pci_info *pci_info)
{
	int ret = 0;

	desc[i].is_host_to_dev = !kcmd->dma_trans_cmd.is_dev_to_host;
	desc[i].is_src_not_user_mem = 0;
	desc[i].is_src_dma_addr = 0;
	desc[i].dev_addr = kcmd->dma_trans_cmd.axi_addr + done_size;
	desc[i].dma_lenth = temp_size;
	desc[i].host_addr.vir_addr =
		(u8 *)kcmd->dma_trans_cmd.vir_addr + done_size;

	return ret;
}

/*the user space memory directly into the kernel, without dma alloc memory*/
/*before use*/
int vatools_ioctl_dma_trans(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL, *pci_info = NULL;
	int die_index = 0;
	union die_index_data did;
	union core_bitmap core_id = { .val = 0 };
	u32 entry_count;
	u32 size = 0;
	struct vastai_dmadesc *desc;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.dma_trans_cmd.die_index;
	die_index = vcmd.cmd.dma_trans_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "priv is NULL, dev_id[%u]\n",
			     did.dev_id);
		return -ENODEV;
	}

	pci_info = priv;
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	size = vcmd.cmd.dma_trans_cmd.length;
	if (iommu_is_enable(pci_info) &&
	    ((u64)vcmd.cmd.dma_trans_cmd.vir_addr % PAGE_SIZE == 0)) {
		ret = vastai_pci_dma_transfer_by_uaddr_new(
			pci_info, core_id, &vcmd.cmd.dma_trans_cmd);
	} else {
		entry_count =
			vast_div_round_up(size, pci_info->max_dma_node_size);
		desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
				GFP_KERNEL);

		vastai_common_cut_dma_buf_new(
			pci_info, &vcmd.cmd.dma_trans_cmd, size, desc, NULL,
			vastai_dma_trans_get_host_addr,
			vastai_ioctl_dma_trans_set_desc_new);

		/*confirm with Jingming, we can use sdma here*/
		ret = pci_info->addr->p_dma_transfer_sync(
			pci_info, vcmd.cmd.dma_trans_cmd.die_index, core_id,
			desc, entry_count, vcmd.cmd.dma_trans_cmd.pid);

		kvfree(desc);
	}

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}
	return 0;
}

/*The Dma free memory*/
int vatools_ioctl_dma_free(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	vastai_pci_info *priv = NULL;
	int die_index = 0;
	union die_index_data did;

	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.alloc_cmd.die_index;
	die_index = vcmd.cmd.alloc_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"start dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%llx, size=%u.\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.alloc_cmd.dma_buf_fd, vcmd.cmd.alloc_cmd.size);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (vastai_free_dma_buf(priv, vcmd.cmd.alloc_cmd.dma_buf_fd) < 0) {
		/*vcmd.cmd.alloc_cmd.dmabuffer = INVALID_HANDLE_VALUE;*/
		ret = STATUS_RTPM_PCR_READ_INCOMPLETE;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "vastai_free_dma_buf fail!\n");
	}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex is error\n");
		return -EIO;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"end dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%llx, size=%u.\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.alloc_cmd.dma_buf_fd, vcmd.cmd.alloc_cmd.size);

	VATOOLS_FUNC_EXIT;
	return ret;
}

#else /*platform*/
/*on linux*/
/*The dma allocate memory*/
int vatools_ioctl_dma_alloc(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	struct dma_buf *dmabuf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.alloc_cmd.die_index;
	die_index = vcmd.cmd.alloc_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		return -ENODEV;
	}

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	VATOOLS_DBG(
		priv, die_index,
		"dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%x, size=%u\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.alloc_cmd.dma_buf_fd, vcmd.cmd.alloc_cmd.size);

	if (iommu_is_enable(priv))
		dmabuf = vastai_alloc_dma_buf_sg(priv, vcmd.cmd.alloc_cmd.size);
	else
		dmabuf = vastai_alloc_dma_buf(priv, vcmd.cmd.alloc_cmd.size);
	if (dmabuf) {
		int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
		vcmd.cmd.alloc_cmd.dma_buf_fd = fd;
	} else {
		vcmd.cmd.alloc_cmd.dma_buf_fd = -ENOMEM;
	}

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}
	return ret;
}

/*Start dma transfers*/
int vatools_ioctl_dma_start(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	union die_index_data did;
	struct dma_buf *dmabuf = NULL;
	struct vastai_dmadesc desc;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.dma_start_cmd.die_index;
	die_index = vcmd.cmd.dma_start_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		return -ENODEV;
	}

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(
		priv, die_index,
		"dev_id=%u, die_id=%u, die_index=0x%x, dma_buf_fd=0x%x, size=%u, axi_addr=0x%llx, is_dev_to_host=%d\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.dma_start_cmd.dma_buf_fd, vcmd.cmd.dma_start_cmd.size,
		vcmd.cmd.dma_start_cmd.axi_addr,
		vcmd.cmd.dma_start_cmd.is_dev_to_host);

	dmabuf = dma_buf_get(vcmd.cmd.dma_start_cmd.dma_buf_fd);
	if (IS_ERR(dmabuf)) {
		VATOOLS_ERR(priv, DUMMY_DIE_ID, "%s dma buf fd is invalid\n",
			    __func__);
		return PTR_ERR(dmabuf);
	}
	if (iommu_is_enable(priv)) {
		union core_bitmap core_id = { .val = 0 };
		struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, 0);
		u32 is_src_dma_addr = 1;
		u32 is_src_not_user_mem = 1;
		if (vcmd.cmd.dma_start_cmd.size > dm->size) {
			ret = -EINVAL;
			goto free_buf;
		}

		ret = vastai_pci_dma_transfer_sg(
			priv, vcmd.cmd.dma_start_cmd.die_index, core_id, dm,
			is_src_dma_addr, !vcmd.cmd.dma_start_cmd.is_dev_to_host,
			is_src_not_user_mem, vcmd.cmd.dma_start_cmd.axi_addr,
			vcmd.cmd.dma_start_cmd.size);

	} else {
		ret = vastai_common_cut_dma_buf(
			vcmd.cmd.dma_start_cmd.size,
			(struct kchar_cmd *)&vcmd.cmd, &desc, priv, dmabuf,
			vastai_ioctl_dma_start_set_desc);
	}
free_buf:
	dma_buf_put(dmabuf);

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}
	return ret;
}
/*The user space memory directly into the kernel, without dma alloc memory*/
/*before use*/
int vatools_ioctl_dma_trans(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd = { 0 };
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL, *pci_info = NULL;
	int die_index = 0;
	union die_index_data did = { 0 };
	dma_node_trans_cmd_t dma_trans_cmd = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.dma_trans_cmd.die_index;
	die_index = vcmd.cmd.dma_trans_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "priv is NULL, dev_id[%u]\n",
			     did.dev_id);
		return -ENODEV;
	}

	pci_info = priv;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"dev_id=%d, die_id=%d, die_index=0x%x, is_dev_to_host %d, vir_addr 0x%llx, axi_addr 0x%llx, length 0x%x, pid %d\n",
		did.dev_id, did.die_id, die_index,
		vcmd.cmd.dma_trans_cmd.is_dev_to_host,
		vcmd.cmd.dma_trans_cmd.vir_addr,
		vcmd.cmd.dma_trans_cmd.axi_addr, vcmd.cmd.dma_trans_cmd.length,
		vcmd.cmd.dma_trans_cmd.pid);

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	dma_trans_cmd.is_dev_to_host = vcmd.cmd.dma_trans_cmd.is_dev_to_host;
	dma_trans_cmd.vir_addr = vcmd.cmd.dma_trans_cmd.vir_addr;
	dma_trans_cmd.axi_addr = vcmd.cmd.dma_trans_cmd.axi_addr;
	dma_trans_cmd.length = vcmd.cmd.dma_trans_cmd.length;
	dma_trans_cmd.die_index = vcmd.cmd.dma_trans_cmd.die_index;
	dma_trans_cmd.pid = vcmd.cmd.dma_trans_cmd.pid;

	ret = vastai_pci_dma_trans(pci_info, &dma_trans_cmd);
	if (ret) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "vastai_pci_dma_transis error, ret %d\n", ret);
		return -EIO;
	}

	ret = copy_to_user_ex((void *)arg, &vcmd, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}
	return 0;
}

/*The Dma free memory*/
int vatools_ioctl_dma_free(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	/*compitalbe with windows, must return OK.*/
	int ret = 0;
	VATOOLS_FUNC_ENTERY;
	VATOOLS_FUNC_EXIT;
	return ret;
}
#endif

/*Memory read data*/
int vatools_ioctl_read_reg_buf(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
{
	int ret;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	u8 *temp_buf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.access_mem_cmd.die_index;
	die_index = vcmd.cmd.access_mem_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(priv, die_index,
		    "die_index=0x%x, addr=0x%llx, buf=0x%llx, size=%d\n",
		    vcmd.cmd.access_mem_cmd.die_index,
		    vcmd.cmd.access_mem_cmd.addr, vcmd.cmd.access_mem_cmd.buf,
		    vcmd.cmd.access_mem_cmd.size);

	temp_buf = (u8 *)kvmalloc(vcmd.cmd.access_mem_cmd.size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_index, " kvmalloc error. size=%d\n",
			    vcmd.cmd.access_mem_cmd.size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, vcmd.cmd.access_mem_cmd.size);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_pci_mem_read(priv, die_index, vcmd.cmd.access_mem_cmd.addr,
				  temp_buf, vcmd.cmd.access_mem_cmd.size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vastai_pci_mem_read is error, ret=%d\n", ret);
		goto out_kvfree;
	}

	ret = copy_to_user_ex((void *)vcmd.cmd.access_mem_cmd.buf, temp_buf,
			      vcmd.cmd.access_mem_cmd.size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);

out:
	return ret;
}

/*Write memory data*/
int vatools_ioctl_write_reg_buf(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	u8 *temp_buf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.access_mem_cmd.die_index;
	die_index = vcmd.cmd.access_mem_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(priv, die_index,
		    "die_index=0x%x, addr=0x%llx, buf=0x%llx, size=%d\n",
		    vcmd.cmd.access_mem_cmd.die_index,
		    vcmd.cmd.access_mem_cmd.addr, vcmd.cmd.access_mem_cmd.buf,
		    vcmd.cmd.access_mem_cmd.size);

	temp_buf = (u8 *)kvmalloc(vcmd.cmd.access_mem_cmd.size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_index, " kvmalloc error. size=%d\n",
			    vcmd.cmd.access_mem_cmd.size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, vcmd.cmd.access_mem_cmd.size);
	ret = copy_from_user_ex(temp_buf, (void *)vcmd.cmd.access_mem_cmd.buf,
				vcmd.cmd.access_mem_cmd.size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_pci_mem_write(priv, die_index,
				   vcmd.cmd.access_mem_cmd.addr, temp_buf,
				   vcmd.cmd.access_mem_cmd.size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vastai_pci_mem_read is error, ret=%d\n", ret);
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);

out:
	return ret;
}

/*/ core time sync*/
#ifdef VATOOLS_CORE_TIME_SYNC_ENABLE
static int vatools_wait_core_time_sync_ack(struct vastai_pci_info *priv,
					   u32 die_index)
{
	struct vastai_sv100_die *die;
	int ret;
	u32 die_id;
	union die_index_data did;
	u32 timeout_ms = 100;

	did.val = (u32)die_index;
	die_id = did.die_id;

	VATOOLS_DBG(priv, die_index,
		    "priv=%p, die_index=0x%x die_id=%d wait start\n", priv,
		    die_index, die_id);

	if (!priv || (priv->die_num_in_fn <= die_id)) {
		return -EINVAL;
	}

	die = &(priv->dies[die_id]);

	/*wait completion int from smcu*/
	/*if the user interrupt, need to be here to clear the last smi
	   ack response of commands, Otherwise each entry here, wait_for
	   will return directly, lead to wait and ack don't match*/
#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		reinit_completion(&(priv->tools_info.core_time_sync_ack));
		ret = wait_for_completion_interruptible_timeout(
			&(priv->tools_info.core_time_sync_ack),
			msecs_to_jiffies(timeout_ms));
		reinit_completion(&(priv->tools_info.core_time_sync_ack));
	} else
#endif
	{
		ret = wait_for_completion_interruptible_timeout(
			&(die->core_time_sync_ack),
			msecs_to_jiffies(timeout_ms));
		reinit_completion(&(die->core_time_sync_ack));
	}
	VATOOLS_DBG(priv, die_index,
		    "wait completion ret=%d die_id=%d die_index=0x%x\n", ret,
		    die_id, die_index);
	if (ret == 0) {
		VATOOLS_INFO(priv, die_index, "timeout! (%d ms) ret=%d\n",
			     timeout_ms, ret);
		return -ETIMEDOUT;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(priv, die_index, "process be killed! ret=%d\n",
			    ret);
		return -EINTR;
	} else if (ret < 0) {
		VATOOLS_INFO(priv, die_index, "Unknow err! ret=%d\n", ret);
		return -EIO;
	} else {
		VATOOLS_DBG(priv, die_index, "done.\n");
		return 0;
	}
}
#endif

int vatools_ioctl_core_time_sync(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };
	struct vastai_pci_info *priv = NULL;
	u32 die_index = 0;
#ifdef VATOOLS_CORE_TIME_SYNC_ENABLE
	ring_buf_elem_t ring_buf_elem;
	u32 corebitmap;
	core_time_sync_data_t core_time_sync_data;
#endif
	VATOOLS_FUNC_ENTERY;

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, (void __user *)argp, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%d\n", ret);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_index,
		"block_id=0x%x  device_id=0x%x  die_id=0x%x  die_id=0x%x  flag=0x%x  addr= "
		"0x%llx\n",
		kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		kdata.device.die_index, kdata.flag, kdata.address);

	priv = vatools_get_vastai_pci_device_info((char)kdata.device.dev_id);
	die_index = kdata.device.die_index;

	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     kdata.device.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	VATOOLS_DBG(priv, die_index,
		    "cmd=0x%x  filp=0x%p  node=0x%p  reader=0x%p\n", cmd, filp,
		    node, reader);

	if (!node) {
		VATOOLS_INFO(priv, die_index, "node is NULL\n");
		ret = -EINVAL;
	}

	if (kdata.device.die_id >= priv->die_num_in_fn) {
		VATOOLS_DBG(priv, die_index, "priv->die_num=%d <= die_id=%u\n",
			    priv->die_num_in_fn, kdata.device.die_id);
		return -ENODEV;
	}

	/*die_index =*/
	/*vatools_get_vastai_pci_die_index((char)kdata.device.dev_id,*/
	/*					     kdata.device.die_id);*/
	/*if (die_index < 0) {*/
	/*	return -ENODEV;*/
	/*}*/

	switch (kdata.flag) {
#ifdef VATOOLS_CORE_TIME_SYNC_ENABLE
	case CORE_TIME_SYNC_MSG_STOP: {
		/*Send a message to the core*/
		memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

		ring_buf_elem.whole = 0;
		ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
		ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_USE_RINGBUF;
		ring_buf_elem.seq_no = 0;
		ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_CORE_TIME_STOP_SYNC;
		ring_buf_elem.val = CORE_TIME_SYNC_MSG_STOP;
		corebitmap = (0x1 << (CORE_SMCU)) & ((0x1 << CORE_NUMBER) - 1);

		VATOOLS_DBG(
			priv, die_index,
			"START: die_index=0x%x, corebitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
			kdata.device.die_index, corebitmap, kdata.flag,
			ring_buf_elem.whole);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		reinit_completion(
			&(priv->dies[kdata.device.die_id].core_time_sync_ack));
		/*Send the interrupt to smcu*/
		ret = vatools_send_ctrl_cmd(priv, kdata.device.die_index,
					    corebitmap, ring_buf_elem.whole);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		VATOOLS_DBG(priv, die_index, "send ctrl cmd return 0x%x\n",
			    ret);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "send ctrl cmd failed. ret=%d\n", ret);
			goto out;
		}
	} break;
	case CORE_TIME_SYNC_MSG_START: {
		/*Send a message to the core*/
		memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

		ring_buf_elem.whole = 0;
		ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
		ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_USE_RINGBUF;
		ring_buf_elem.seq_no = 0;
		ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_CORE_TIME_START_SYNC;
		ring_buf_elem.val = CORE_TIME_SYNC_MSG_START;
		corebitmap = (0x1 << (CORE_SMCU)) & ((0x1 << CORE_NUMBER) - 1);

		VATOOLS_DBG(
			priv, die_index,
			"START: die_index=0x%x, corebitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
			kdata.device.die_index, corebitmap, kdata.flag,
			ring_buf_elem.whole);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		reinit_completion(
			&(priv->dies[kdata.device.die_id].core_time_sync_ack));
		/*Send the interrupt to smcu*/
		ret = vatools_send_ctrl_cmd(priv, kdata.device.die_index,
					    corebitmap, ring_buf_elem.whole);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		VATOOLS_DBG(priv, die_index, "send ctrl cmd return 0x%x\n",
			    ret);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "send ctrl cmd failed. ret=%d\n", ret);
			goto out;
		}
	} break;
	case CORE_TIME_SYNC_MSG_READ: {
		u64 host_ns = 0;
		int c = 0;
		/*start core time sync*/
		memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

		ring_buf_elem.whole = 0;
		ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
		ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_USE_RINGBUF;
		ring_buf_elem.seq_no = 0;
		ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_CORE_TIME_START_SYNC;
		ring_buf_elem.val = CORE_TIME_SYNC_MSG_START;
		corebitmap = (0x1 << (CORE_SMCU)) & ((0x1 << CORE_NUMBER) - 1);

		VATOOLS_DBG(
			priv, die_index,
			"START: die_index=0x%x, corebitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
			kdata.device.die_index, corebitmap, kdata.flag,
			ring_buf_elem.whole);

		/*Send the interrupt to smcu*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_send_ctrl_cmd(priv, kdata.device.die_index,
					    corebitmap, ring_buf_elem.whole);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		VATOOLS_DBG(priv, die_index, "send ctrl cmd return 0x%x\n",
			    ret);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "send ctrl cmd failed. ret=%d\n", ret);
			goto out;
		}

		/*read time sync data*/
		memset(&core_time_sync_data, 0, sizeof(core_time_sync_data_t));
		host_ns = vastai_get_host_time_ns();
		for (c = 0; c < CORE_NUMBER; c++) {
			core_time_sync_data.host_time_ns[c] = host_ns;
		}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_wait_core_time_sync_ack(priv,
						      kdata.device.die_index);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		if (ret < 0) {
			if (ret == -EINTR) {
				VATOOLS_DBG(
					priv, die_index,
					"vatools_wait_core_time_sync_ack timeout ret=%d die_index=0x%x\n",
					ret, kdata.device.die_index);
			} else {
				VATOOLS_INFO(
					priv, die_index,
					"vatools_wait_core_time_sync_ack timeout ret=%d die_index=0x%x\n",
					ret, kdata.device.die_index);
			}
			goto out_stop;
		}

		/*TODO: change to wait ack interrupt later*/
		/*udelay(100);*/

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_pci_mem_read(
			priv, die_index, INTER_CORE_TIME_SYNC_ADDR,
			(u8 *)core_time_sync_data.core_time,
			sizeof(core_time_sync_data.core_time));

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		if (ret < 0) {
			VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
			goto out_stop;
		}
		VATOOLS_DUMP_BRIEF(
			"core_time_sync_data read: ", &core_time_sync_data,
			sizeof(core_time_sync_data));

		/*copy to user*/
		ret = copy_to_user_ex((void __user *)kdata.output_buf.buf_addr,
				      &core_time_sync_data,
				      sizeof(core_time_sync_data));
		if (ret) {
			VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%d\n",
				    ret);
			ret = -EFAULT;
			goto out_stop;
		}

	out_stop:
		/*stop core time sync*/
		memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

		ring_buf_elem.whole = 0;
		ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
		ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_NOT_USE_RINGBUF;
		ring_buf_elem.seq_no = 0;
		ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_CORE_TIME_STOP_SYNC;
		ring_buf_elem.val = CORE_TIME_SYNC_MSG_STOP;
		corebitmap = (0x1 << (CORE_SMCU)) & ((0x1 << CORE_NUMBER) - 1);

		VATOOLS_DBG(
			priv, die_index,
			"START: die_index=0x%x, corebitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
			kdata.device.die_index, corebitmap, kdata.flag,
			ring_buf_elem.whole);

		/*Send the interrupt to smcu*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_send_ctrl_cmd(priv, kdata.device.die_index,
					    corebitmap, ring_buf_elem.whole);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		VATOOLS_DBG(priv, die_index, "send ctrl cmd return 0x%x\n",
			    ret);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "send ctrl cmd failed. ret=%d\n", ret);
			goto out;
		}

	} break;
#endif
	case CORE_TIME_SYNC_MSG_MAX:
		ret = -EINVAL;
		break;
	default:
		ret = -EINVAL;
		break;
	}

out:
	return ret;
}

void vatools_get_current_time(struct rtc_time *tm)
{
#if (TOOLS_WIN == 1)
/*TODO:*/
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 0, 0)
	struct timex txc;
	/*GET UTC time*/
	do_gettimeofday(&(txc.time));
	/*convert UTC to localtime*/
	rtc_time_to_tm(txc.time.tv_sec, tm);
#else
	time64_t sec = 0;
	sec = ktime_to_ms(ktime_get());
	rtc_time64_to_tm(sec, tm);
#endif
#endif
}

extern int vastai_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
				u32 core_bit_map, u64 info);
/**
 * @brief send a ctrl cmd to smcu by msgqueue1, smcu will retransmit interrupt
 * to other mcu / vdsp.
 *
 * @param pci_info: vastai sv100 pci base struct.
 * @param die_index: the destination die.
 * @param core_bit_map: this is a __BIT_MAP__ smcu will trigger it one by one.
 * @param info: private data. low 8bit is invalied. (for seq_id)
 * @return int: zero is success.
*/
int vatools_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
			  u32 core_bit_map, u64 info)
{
	int ret = 0;

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(pci_info) == SG100) {
		struct pcie_transfer_cmd trans;
		u32 host_to_smcu_cmd_buf = COMMON_HOST_TO_SMCU_CMD_BUF;
		/*TODO: wait alloc a code for SMI*/
		trans.w0.s_data0.optcode = SMCU_SMI_CMD_REQ;
		trans.w0.s_data0.rev0 = 0;
		trans.w0.s_data0.rev1 = 0;
		trans.w0.s_data0.rev2 = 0;
		trans.w1.data1 = 0;
		trans.w2.data2 = 0;
		trans.w3.data3 = 0;

		switch (pci_info->priv_hw_cfg->sys_cfg.fn_mode) {
		case ONLY_1_PF:
			host_to_smcu_cmd_buf = ONLY_1PF_HOST_TO_SMCU_CMD_BUF;
			break;
		case ONLY_2_PF:
			host_to_smcu_cmd_buf = ONLY_2PF_HOST_TO_SMCU_CMD_BUF;
			break;
		case ONLY_4_PF:
		case PF_4_WITH_SRIOV:
			host_to_smcu_cmd_buf = COMMON_HOST_TO_SMCU_CMD_BUF;
			break;
		default:
			VATOOLS_INFO(pci_info, die_index,
				     "FATAL: unknown fn_mode=%d.\n",
				     pci_info->priv_hw_cfg->sys_cfg.fn_mode);
		}

		ret = vastai_pci_send_msg(pci_info, 0, host_to_smcu_cmd_buf,
					  &trans, 0);
		if (ret != 0) {
			VATOOLS_INFO(pci_info, die_index,
				     "vastai_pci_send_msg failed.\n");
		}
	} else
#endif
	{
		ret = vastai_send_ctrl_cmd(pci_info, die_index, core_bit_map,
					   info);
	}
	VATOOLS_DBG(
		pci_info, die_index,
		"call vastai_send_ctrl_cmd: pci_info=%p die_index=0x%x core_bit_map=0x%x "
		"info=0x%llx ret=%d (ERESTARTSYS -512)(EINTR -4)(ETIMEDOUT -110) \n",
		pci_info, die_index, core_bit_map, info, ret);
	return ret;
}

/*get sriov enable and number*/
int vatools_ioctl_get_sriov_number(struct file *filp, unsigned int cmd,
				   IOCTL_ARG_T arg)
{
	int ret = 0;
	struct sriov_number_s sriov_numb = { 0 };
	ret = copy_from_user_ex(&sriov_numb, (void __user *)arg,
				sizeof(struct sriov_number_s));
	if (ret) {
		return -EFAULT;
	}
	sriov_numb.sriov_num = vastai_pci_get_sriov_numvfs(sriov_numb.dev_id);
	ret = copy_to_user_ex((void __user *)arg, &sriov_numb,
			      sizeof(struct sriov_number_s));
	if (ret)
		return -EFAULT;
	return 0;
}

/*get bmcu and xspi version*/
int vatools_ioctl_get_bmcu_xspi_ver(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg)
{
	int ret;
	s32 buf_size = 0;
	struct bmcu_xspi_ver *ver = NULL;
	struct vastai_pci_info *priv = NULL;
	int i;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	if (get_user(buf_size, (int __user *)arg)) {
		return -EFAULT;
	}

	ver = (struct bmcu_xspi_ver *)kvmalloc(buf_size, GFP_KERNEL);
	ret = copy_from_user_ex(ver, (void __user *)arg, buf_size);
	if (ret) {
		kvfree(ver);
		return -EFAULT;
	}

	die_index = ver->die_index.val;
	priv = vatools_get_vastai_pci_device_info(ver->die_index.dev_id);
	if (!priv) {
		kvfree(ver);
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id[%u] \n",
			     ver->die_index.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		kvfree(ver);
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

#ifdef VATOOLS_SV_SG_MERGE
	if (vastai_get_board_type(priv) == SG100) {
		if ((atomic_read(&priv->is_fw_updating) != 0)) {
			kvfree(ver);
			VATOOLS_DBG(priv, die_index,
				    "priv->is_fw_updating=0x%x\n",
				    atomic_read(&priv->is_fw_updating));
			return -EACCES;
		}

		/*read version once again*/
		if (0 == priv->priv_hw_cfg->sys_cfg.devfn && priv->is_pf) {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_DIE);
#endif
			ret = vatools_pci_mem_read(
				priv, 0, SG_VSERSION_INFO_BASE, &priv->fw_ver,
				sizeof(struct vastai_fw_version));
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			domain_mutex_unlock(priv, die_index,
					    VATOOLS_IOCTL_DOMAIN_DIE);
#endif
			if (ret < 0) {
				VATOOLS_ERR(
					priv, die_index,
					"%s read firmware version error:%d\n",
					__func__, ret);
				return -ENODEV;
			}
		}

		memcpy(ver->bmcu_active, priv->fw_ver.ver,
		       VASTAI_VER_BMCU_XSPI_LEN);
		memcpy(ver->bmcu_backup, priv->fw_ver.ver_bk,
		       VASTAI_VER_BMCU_XSPI_LEN);
		ver->bmcu_active[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;
		ver->bmcu_backup[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;
		ver->die_num = priv->die_num_in_fn;

		/*for (i = 0; i < ver->die_num; i++)*/
		{
			char *xspi_ver = (char *)priv->fw_ver.bl0_ver;
			memcpy(ver->dies[0].xspi_ver, xspi_ver,
			       VASTAI_VER_BMCU_XSPI_LEN);
		}
	} else
#endif
	{
		memcpy(ver->bmcu_active, priv->dies[0].fw_ver.bmcu_ver,
		       VASTAI_VER_BMCU_XSPI_LEN);
		memcpy(ver->bmcu_backup, priv->dies[0].fw_ver.bmcu_backup_ver,
		       VASTAI_VER_BMCU_XSPI_LEN);
		ver->bmcu_active[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;
		ver->bmcu_backup[VASTAI_VER_BMCU_XSPI_LEN - 1] = 0;
		ver->die_num = priv->die_num_in_fn;

		for (i = 0; i < ver->die_num; i++) {
			char *xspi_ver = (char *)priv->dies[i].fw_ver.bmcu_ver +
					 VASTAI_VER_BMCU_XSPI_LEN;
			memcpy(ver->dies[i].xspi_ver, xspi_ver,
			       VASTAI_VER_BMCU_XSPI_LEN);
		}
	}

	ret = copy_to_user_ex((void __user *)arg, ver, buf_size);
	kvfree(ver);

	if (ret)
		ret = -EFAULT;
	return ret;
}

/*flash bmcu's version*/
int vatools_ioctl_flash_bmcu_fw(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg)
{
	int ret;
	struct flash_bmcu_xspi flash_arg;
	struct flash_bmcu_xspi *bin;
	struct vastai_pci_info *priv = NULL;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);

	ret = copy_from_user_ex(&flash_arg, (void __user *)arg,
				sizeof(flash_arg));
	if (ret) {
		return -EFAULT;
	}

	if (flash_arg.buf_size <= 0) {
		return -EINVAL;
	}

	die_index = flash_arg.die_index.val;
	priv = vatools_get_vastai_pci_device_info(flash_arg.die_index.dev_id);
	if (!priv) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     flash_arg.die_index.dev_id);
		return -ENODEV;
	}
	/*vastai_pci_flash_bmcu_bin need smcu to response. Therefore, to check
		pcie_state is VASTAI_NORMAL_STATE.*/
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -EBUSY;
	}
#ifdef VATOOLS_SV_SG_MERGE
	if ((atomic_read(&priv->is_fw_updating) != 0)) {
		VATOOLS_DBG(priv, die_index, "priv->is_fw_updating=0x%x\n",
			    atomic_read(&priv->is_fw_updating));
		return -EBUSY;
	}
#endif
	bin = (struct flash_bmcu_xspi *)kvmalloc(
		flash_arg.buf_size + sizeof(flash_arg), GFP_KERNEL);
	if (!bin) {
		return -ENOMEM;
	}

	ret = copy_from_user_ex(bin, (void __user *)arg,
				flash_arg.buf_size + sizeof(flash_arg));
	if (ret) {
		kvfree(bin);
		return -EFAULT;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_pci_flash_bmcu_bin(priv, 0, NULL, bin->buf,
					flash_arg.buf_size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	kvfree(bin);
	return ret;
}

/*flash xspi's flash*/
int vatools_ioctl_flash_xspi_fw(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg)
{
#if (TOOLS_WIN == 1)
	/*TODO: tobedone. use old method.*/
	int ret;
	struct flash_bmcu_xspi flash_arg;
	struct flash_bmcu_xspi *bin;
	struct vastai_pci_info *pci_info = NULL;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);

	ret = copy_from_user_ex(&flash_arg, (void __user *)arg,
				sizeof(flash_arg));
	if (ret) {
		return -EFAULT;
	}

	if (flash_arg.buf_size <= 0) {
		return -EINVAL;
	}

	pci_info =
		vatools_get_vastai_pci_device_info(flash_arg.die_index.dev_id);
	if (!pci_info) {
		return -ENODEV;
	}

	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1))
		return -EBUSY;

	bin = (struct flash_bmcu_xspi *)kvmalloc(
		flash_arg.buf_size + sizeof(flash_arg), GFP_KERNEL);
	if (!bin) {
		return -ENOMEM;
	}

	ret = copy_from_user_ex(bin, (void __user *)arg,
				flash_arg.buf_size + sizeof(flash_arg));
	if (ret) {
		kvfree(bin);
		return -EFAULT;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(pci_info, flash_arg.die_index,
			  VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_pci_flash_xspi_bin(pci_info, flash_arg.die_index.die_id,
					NULL, bin->buf, flash_arg.buf_size,
					VASTAI_PCI_FLASH_BL0);
	if (ret) {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(pci_info, flash_arg.die_index,
				    VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		kvfree(bin);
		return ret;
	}

	ret = vastai_pci_update_flag_xspi(pci_info, flash_arg.die_index.die_id,
					  VASTAI_PCI_FLASH_BL0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(pci_info, flash_arg.die_index,
			    VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	kvfree(bin);

	return ret;
#else
	/*new method*/
	int ret;
	struct flash_bmcu_xspi flash_arg;
	struct flash_bmcu_xspi *bin;
	struct vastai_pci_info *priv = NULL;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);

	ret = copy_from_user_ex(&flash_arg, (void __user *)arg,
				sizeof(flash_arg));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%d\n", ret);
		return -EFAULT;
	}

	if (flash_arg.buf_size <= 0) {
		return -EINVAL;
	}

	priv = vatools_get_vastai_pci_device_info(flash_arg.die_index.dev_id);
	die_index = flash_arg.die_index.val;

	if (!priv) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     flash_arg.die_index.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     flash_arg.die_index.dev_id);
		return -EBUSY;
	}

	bin = (struct flash_bmcu_xspi *)kvmalloc(
		flash_arg.buf_size + sizeof(flash_arg), GFP_KERNEL);
	if (!bin) {
		return -ENOMEM;
	}

	ret = copy_from_user_ex(bin, (void __user *)arg,
				flash_arg.buf_size + sizeof(flash_arg));
	if (ret) {
		kvfree(bin);
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%d\n", ret);
		return -EFAULT;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_pci_flash_xspi(priv, flash_arg.die_index.die_id, NULL,
				    bin->buf, flash_arg.buf_size,
				    VASTAI_PCI_FLASH_BL0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	kvfree(bin);
	return ret;
#endif
}

/*get bmcu or flash 's state*/
int vatools_ioctl_flash_sta(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	int ret;
	struct flash_state flash_state;
	struct vastai_pci_info *priv = NULL;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);

	ret = copy_from_user_ex(&flash_state, (void __user *)arg,
				sizeof(struct flash_state));
	if (ret) {
		return -EFAULT;
	}

	die_index = flash_state.die_index.val;
	priv = vatools_get_vastai_pci_device_info(flash_state.die_index.dev_id);

	if (!priv) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     flash_state.die_index.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index,
			    "priv->pci_state=%d is not normal.\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	if (atomic_read(&priv->is_fw_updating) != 0) {
		VATOOLS_DBG(priv, die_index,
			    "priv->is_fw_updating=%d is not normal.\n",
			    atomic_read(&priv->is_fw_updating));
		return -ENODEV;
	}

	flash_state.flash_state = 0;

	switch (flash_state.flash_type) {
	case 0:
#if (TOOLS_WIN == 1)
		/*TODO: tobedone. use old method.*/
		flash_state.flash_state =
			atomic_read(&(priv->pci_state)) == VASTAI_NORMAL_STATE;
#else
#ifdef VATOOLS_SV_SG_MERGE
		if (vastai_get_board_type(priv) == SG100) {
			flash_state.flash_state =
				atomic_read(&(priv->is_fw_updating)) == 0;
		} else
#endif
		{
			/*only compitable old tools*/
			flash_state.flash_state = 1;
		}
#endif
		break;
	case 1:
		/*flash always is done*/
		flash_state.flash_state = 1;
		break;
	default:
		break;
	}

	ret = copy_to_user_ex((void __user *)arg, &flash_state,
			      sizeof(struct flash_state));
	if (ret) {
		ret = -EFAULT;
	}
	return ret;
}

/*switch bmcu version*/
int vatools_ioctl_bmcu_switch(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vastai_pci_info *priv = NULL;
	union die_index_data did = { .val = (u32)arg };
	u32 die_index = did.val;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);

	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (!priv) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vastai_send_pcie_cmd(priv, did.val, VASTAI_PCIE_SUB_BMCU_DEGRADE,
				   0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	return ret;
}

/*
Traverse the fifo, do not change the rd wr pointer. The index range: [0, fifo
count). return 0 to traverse the end, it is necessary to the caller to judge and
exit the traversal cycle. Otherwise there will be illegal data.
*/
u32 vatools_fifo_iterate(struct vastai_fifo *fifo, u32 index)
{
	u32 ret = 0;

	if ((fifo->wr) == ((fifo->rd) % (fifo->elem_count))) {
		return 0;
	}

	if ((fifo->wr) == ((fifo->rd + index) % (fifo->elem_count))) {
		return 0;
	}
#if (TOOLS_WIN == 1)
	ret = (u32)sizeof(struct vastai_fifo) +
	      fifo->elem_size * ((fifo->rd + index) % (fifo->elem_count));
#else
	ret = (u32)offsetof(struct vastai_fifo, buf) +
	      fifo->elem_size * ((fifo->rd + index) % (fifo->elem_count));
#endif
	return ret;
}

/*
 the event event occurs, the current system acquisition time
 wait process needs to compare the event happened time and processes the current
 time, if the event is greater than the current time, the function returns true,
 wake up the process, identify the event and new can result
*/
static volatile u64 _g_event_callback_timestamp_ns = 0;

int vatools_event_wait_queue_condition_func(u64 local_timestamp_ns)
{
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"_g_event_callback_timestamp_ns=%lld  local_timestamp_ns=%lld\n",
		_g_event_callback_timestamp_ns, local_timestamp_ns);
	return (_g_event_callback_timestamp_ns > local_timestamp_ns);
}

/*The function called event producers, save to ringbuf event information*/
int vatools_device_event_callback(u32 die_index, u32 core_bit, u32 event)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vastai_fifo *fifo = NULL;
	u8 *fifo_p = NULL;
	device_event_t device_event;
	int locked;

	VATOOLS_DBG(NULL, die_index, "die_index=0x%x core_bit=%d event=%d\n",
		    die_index, core_bit, event);

	node = vatools_get_node();
	if (!node) {
		VATOOLS_INFO(NULL, die_index, "node is NULL\n");
		return -ENXIO;
	}

	fifo = (struct vastai_fifo *)node->event_ringbuf;
	if (fifo == NULL) {
		VATOOLS_DBG(NULL, die_index, "event fifo is NULL\n");
		return -EIO;
	}

	if (!vastai_is_fifo_valid(fifo)) {
		VATOOLS_INFO(NULL, die_index, "event fifo is not valid\n");
		return -EIO;
	}

	if (vastai_fifo_is_full(fifo)) {
		VATOOLS_DBG(NULL, die_index, "event fifo is full\n");
	}

	locked = mutex_trylock(&node->event_mutex);
	if (!locked) {
		VATOOLS_DBG(NULL, die_index, "event trylock fail=%d\n", locked);
		return -EIO;
	}

	device_event.core_index = core_bit;
	device_event.die_index = die_index;
	device_event.event = event;
	device_event.timestamp_ns = vastai_get_host_time_ns();

	fifo_p = (u8 *)fifo + vastai_fifo_wr_next(fifo);
	memcpy(fifo_p, &device_event, fifo->elem_size);
	mutex_unlock(&node->event_mutex);

	_g_event_callback_timestamp_ns = device_event.timestamp_ns;
	wake_up_interruptible_all(&node->event_wait_queue);

	return ret;
}

/*Access the event reset status
 Note: CORE_POINT_CMCU does not represent CMCU, represent the entire ai - sys,
 including the whole ai - sys SMCU no reset; Other on behalf of their respective
 core reset
*/
int vatools_ioctl_device_event(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
{
	int ret = 0;
	u32 timeout_ms = SMI_CMD_ACK_WAIT_MS;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	device_event_t *device_event_p = NULL;
	struct vastai_fifo *fifo = NULL;
	u32 i = 0;
	u32 it = 0;
	u32 event_count = 0;
	u64 local_timestamp_ns = 0;
	u32 die_index = 0;

	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(0);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n", 0);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	fifo = (struct vastai_fifo *)node->event_ringbuf;
	if (fifo == NULL) {
		VATOOLS_INFO(priv, die_index, "event fifo is NULL\n");
		return -EIO;
	}
	mutex_lock(&node->event_mutex);

	/*
	 First, iterate through the saved events and compare the timestamps of
	 the FD with the timestamps of the event.
	 Returns events whose event time is greater than the fd time
	*/
	for (i = 0; i < fifo->elem_count; i++) {
		it = vatools_fifo_iterate(fifo, i);
		if (it) {
			device_event_p = (device_event_t *)((u8 *)fifo + it);
			if (device_event_p) {
				if (device_event_p->timestamp_ns >
					    reader->event_timestamp_ns &&
				    (device_event_p->event == EVT_RESET_START ||
				     device_event_p->event == EVT_RESET_STOP)) {
					ret = copy_to_user_ex(
						(u8 *)argp + sizeof(u32) +
							event_count *
								sizeof(device_event_t),
						device_event_p,
						sizeof(device_event_t));
					if (ret) {
						mutex_unlock(
							&node->event_mutex);
						VATOOLS_ERR(
							priv, die_index,
							"copy_from_user_ex is error\n");
						ret = -EIO;
						goto out;
					}
					reader->event_timestamp_ns =
						device_event_p->timestamp_ns;
					event_count++;
				}
			}
		} else {
			break;
		}
	}
	mutex_unlock(&node->event_mutex);
	VATOOLS_DBG(priv, die_index, "before wait: event_count=%d\n",
		    event_count);

	/*There is already an event, go back directly*/
	if (event_count) {
		ret = copy_to_user_ex((void __user *)argp, &event_count,
				      sizeof(u32));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex is error\n");
			ret = -EIO;
			goto out;
		}
		ret = 0;
		goto out;
	}

	/*There is no event, enter and wait*/
	local_timestamp_ns = vastai_get_host_time_ns();
#if (TOOLS_WIN == 1)
	wait_event_interruptible_timeout(
		node->event_wait_queue,
		vatools_event_wait_queue_condition_func(local_timestamp_ns),
		HZ * timeout_ms / 1000, ret);
#else
	ret = wait_event_interruptible_timeout(
		node->event_wait_queue,
		vatools_event_wait_queue_condition_func(local_timestamp_ns),
		HZ * timeout_ms / 1000);
#endif
	if (ret == 0) {
		VATOOLS_DBG(priv, die_index, "timeout! (%d ms) ret=%d\n",
			    timeout_ms, ret);
		ret = -ETIMEDOUT;
		goto out;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(priv, die_index, "process be killed! ret=%d\n",
			    ret);
		ret = -EINTR;
		goto out;
	} else if (ret < 0) {
		VATOOLS_INFO(priv, die_index, "Unknow err! ret=%d\n", ret);
		ret = -EIO;
		goto out;
	}

	VATOOLS_DBG(priv, die_index, "wait event done. ret=%d\n", ret);

	/*
	 Compare the timestamp of the FD and the timestamp of the event.
	 Returns events whose event time is greater than the fd time
	*/
	mutex_lock(&node->event_mutex);
	for (i = 0; i < fifo->elem_count; i++) {
		it = vatools_fifo_iterate(fifo, i);
		if (it) {
			device_event_p = (device_event_t *)((u8 *)fifo + it);
			if (device_event_p) {
				if (device_event_p->timestamp_ns >
					    reader->event_timestamp_ns &&
				    (device_event_p->event == EVT_RESET_START ||
				     device_event_p->event == EVT_RESET_STOP)) {
					ret = copy_to_user_ex(
						(u8 *)argp + sizeof(u32) +
							event_count *
								sizeof(device_event_t),
						device_event_p,
						sizeof(device_event_t));
					if (ret) {
						mutex_unlock(
							&node->event_mutex);
						VATOOLS_ERR(
							priv, die_index,
							"copy_from_user_ex is error\n");
						ret = -EIO;
						goto out;
					}
					reader->event_timestamp_ns =
						device_event_p->timestamp_ns;
					event_count++;
				}
			}
		} else {
			break;
		}
	}
	mutex_unlock(&node->event_mutex);

	if (event_count) {
		ret = copy_to_user_ex((void __user *)argp, &event_count,
				      sizeof(u32));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex is error\n");
			ret = -EIO;
			goto out;
		}
		ret = 0;
		goto out;
	}

out:
	VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

int vatools_ioctl_device_event_select(struct file *filp, unsigned int cmd,
				      IOCTL_ARG_T arg)
{
	int ret = 0;
	u32 timeout_ms = SMI_CMD_ACK_WAIT_MS;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	device_event_t *device_event_p = NULL;
	struct vastai_fifo *fifo = NULL;
	u32 i = 0;
	u32 it = 0;
	u32 event_count = 0;
	u64 local_timestamp_ns = 0;
	u32 die_index = 0;

	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(0);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n", 0);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	fifo = (struct vastai_fifo *)node->event_ringbuf;
	if (fifo == NULL) {
		VATOOLS_INFO(priv, die_index, "event fifo is NULL\n");
		return -EIO;
	}
	mutex_lock(&node->event_mutex);

	/*
	 First, iterate through the saved events and compare the timestamps of
	 the FD with the timestamps of the event. Returns events whose event
	 time is greater than the fd time
	*/
	for (i = 0; i < fifo->elem_count; i++) {
		it = vatools_fifo_iterate(fifo, i);
		if (it) {
			device_event_p = (device_event_t *)((u8 *)fifo + it);
			if (device_event_p) {
				if (device_event_p->timestamp_ns >
				    reader->event_timestamp_ns) {
					ret = copy_to_user_ex(
						(u8 *)argp + sizeof(u32) +
							event_count *
								sizeof(device_event_t),
						device_event_p,
						sizeof(device_event_t));
					if (ret) {
						mutex_unlock(
							&node->event_mutex);
						VATOOLS_ERR(
							priv, die_index,
							"copy_from_user_ex is error\n");
						ret = -EIO;
						goto out;
					}
					reader->event_timestamp_ns =
						device_event_p->timestamp_ns;
					event_count++;
				}
			}
		} else {
			break;
		}
	}
	mutex_unlock(&node->event_mutex);
	VATOOLS_DBG(priv, die_index, "before wait: event_count=%d\n",
		    event_count);

	/*There is already an event, go back directly*/
	if (event_count) {
		ret = copy_to_user_ex((void __user *)argp, &event_count,
				      sizeof(u32));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex is error\n");
			ret = -EIO;
			goto out;
		}
		ret = 0;
		goto out;
	}

	/*There is no event, enter and wait*/
	local_timestamp_ns = vastai_get_host_time_ns();
#if (TOOLS_WIN == 1)
	wait_event_interruptible_timeout(
		node->event_wait_queue,
		vatools_event_wait_queue_condition_func(local_timestamp_ns),
		HZ * timeout_ms / 1000, ret);
#else
	ret = wait_event_interruptible_timeout(
		node->event_wait_queue,
		vatools_event_wait_queue_condition_func(local_timestamp_ns),
		HZ * timeout_ms / 1000);
#endif

	if (ret == 0) {
		VATOOLS_DBG(priv, die_index, "timeout! (%d ms) ret=%d\n",
			    timeout_ms, ret);
		ret = -ETIMEDOUT;
		goto out;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(priv, die_index, "process be killed! ret=%d\n",
			    ret);
		ret = -EINTR;
		goto out;
	} else if (ret < 0) {
		VATOOLS_INFO(priv, die_index, "Unknow err! ret=%d\n", ret);
		ret = -EIO;
		goto out;
	}

	VATOOLS_DBG(priv, die_index, "wait event done. ret=%d\n", ret);

	/*Compare the timestamp of the FD and the timestamp of the event.*/
	/*Returns events whose event time is greater than the fd time*/
	mutex_lock(&node->event_mutex);
	for (i = 0; i < fifo->elem_count; i++) {
		it = vatools_fifo_iterate(fifo, i);
		if (it) {
			device_event_p = (device_event_t *)((u8 *)fifo + it);
			if (device_event_p) {
				if (device_event_p->timestamp_ns >
				    reader->event_timestamp_ns) {
					ret = copy_to_user_ex(
						(u8 *)argp + sizeof(u32) +
							event_count *
								sizeof(device_event_t),
						device_event_p,
						sizeof(device_event_t));
					if (ret) {
						mutex_unlock(
							&node->event_mutex);
						VATOOLS_ERR(
							priv, die_index,
							"copy_from_user_ex is error\n");
						ret = -EIO;
						goto out;
					}
					reader->event_timestamp_ns =
						device_event_p->timestamp_ns;
					event_count++;
				}
			}
		} else {
			break;
		}
	}
	mutex_unlock(&node->event_mutex);

	if (event_count) {
		ret = copy_to_user_ex((void __user *)argp, &event_count,
				      sizeof(u32));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex is error\n");
			ret = -EIO;
			goto out;
		}
		ret = 0;
		goto out;
	}

out:
	VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

#ifdef CONFIG_TOOLS_V2

int vatools_get_spi_buf(u32 die_index, u32 unit, u64 address, u32 len,
			void *spi_buf)
{
	int ret = -EINVAL;
	T_SMI_BLOCK *p_smi_block = NULL;
	struct vastai_pci_info *priv = NULL;
	u8 *cmd_buf = NULL;
	TS_SMI_CMD_REQ *pcmd = NULL;

	VATOOLS_DBG(
		NULL, die_index,
		"die_index=0x%x spi len=%d unit=0x%x address=0x%llx spi_buf=%p\n",
		die_index, len, unit, address, spi_buf);

	if (len > SPI_BUF_LEN_MAX) {
		VATOOLS_DBG(NULL, die_index,
			    "die_index=0x%x spi len=%d larger than %d\n",
			    die_index, len, SPI_BUF_LEN_MAX);
		return ret;
	}

	priv = vatools_get_vastai_pci_device_info_by_die_index(die_index);
	if (priv == NULL) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "die_index=%d has no pci_info\n", die_index);
		ret = -ENODEV;
		goto out;
	}

	/*don't use vatools_check_pci_state to replace, pcie use it before
	 * pcie*/
	/*done*/
	if ((atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE) &&
	    (atomic_read(&priv->pci_state) != VASTAI_DEBUG_STATE)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}
	cmd_buf = (u8 *)vmalloc(SMI_CMD_BLOCK0_LEN);
	if (cmd_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index,
			    "alloc cmd_buf error. size=%d ret=%d\n",
			    SMI_CMD_BLOCK0_LEN, ret);
		goto out;
	}
	memset(cmd_buf, 0, SMI_CMD_BLOCK0_LEN);

	p_smi_block = vatools_fw_smi_get_block_via_app_category(VATOOLS_APP_SMI,
								priv);

	pcmd = (TS_SMI_CMD_REQ *)cmd_buf;
	pcmd->cmd = SMI_CMD_CODE_SPI_READ;
	pcmd->data_len = len;
	pcmd->unit = unit;
	pcmd->flag = FLAG_APP_REQ;
	pcmd->rw_addr = address & 0xffffffffffffUL;

	ret = vatools_driver_smi_cmd(p_smi_block->block_id, priv, die_index,
				     cmd_buf, SMI_CMD_BLOCK0_LEN);
	if (ret > 0) {
		memcpy(spi_buf, cmd_buf + SMI_CMD_HEADER_LEN, len);
	}
	vfree(cmd_buf);
out:
	return ret;
}
#endif

int vatools_pci_mem_read_direct(struct vastai_pci_info *pcie_dev, int die_index,
				u64 relative_addr, void *buf, unsigned int len)
{
	return vastai_pci_mem_read(pcie_dev, die_index, relative_addr, buf,
				   len);
}

int vatools_pci_mem_write_direct(struct vastai_pci_info *pcie_dev,
				 int die_index, u64 relative_addr,
				 const void *buf, unsigned int len)
{
	return vastai_pci_mem_write(pcie_dev, die_index, relative_addr, buf,
				    len);
}

int vatools_get_current_process_info(
	vatools_current_process_info_t *current_process_info)
{
	int ret = EINVAL;
#if (TOOLS_WIN == 1)
	pid_t pid = task_tgid_nr(current);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "current pid=%u current_process_info=%p\n", pid,
		    current_process_info);

	if (current_process_info == NULL) {
		return ret;
	}

	current_process_info->pid = pid;
	/*TODO: fixme later for docker on windows*/
	current_process_info->vpid = pid;
	current_process_info->ns = 0;
	current_process_info->level = 0;
	ret = 0;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "current pid=%d vpid=%d ns=%llu level=%u\n",
		    current_process_info->pid, current_process_info->vpid,
		    current_process_info->ns, current_process_info->level);
#else
	/*platform*/
	/*on linux*/
	pid_t pid = task_tgid_nr(current);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "current pid=%u current_process_info=%p\n", pid,
		    current_process_info);

	if (current_process_info == NULL) {
		return ret;
	}

	current_process_info->pid = pid;
	current_process_info->vpid = task_tgid_vnr(current);
	current_process_info->ns = (u64)task_active_pid_ns(current);
	current_process_info->level = (u32)task_active_pid_ns(current)->level;
	ret = 0;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "current pid=%d vpid=%d ns=%llu level=%u\n",
		    current_process_info->pid, current_process_info->vpid,
		    current_process_info->ns, current_process_info->level);
#endif
	return ret;
}

int vatools_pci_flash_xspi(struct vastai_pci_info *priv, u32 die_id,
			   struct char_drv_info *dev, u8 partition)
{
	return 0;
}
int vatools_pci_flash_xspi_bin(struct vastai_pci_info *priv, u32 die_id,
			       u8 *path_name, const void *bin_buf,
			       size_t buf_size, u8 partition, u8 *mode)
{
	return 0;
}
int vatools_pci_flash_xspi_fw(struct vastai_pci_info *priv, u32 die_id,
			      u8 *path_name, const void *bin_buf,
			      size_t buf_size, u8 partition)
{
	return 0;
}
int vatools_pci_flash_bmcu(struct vastai_pci_info *priv, u32 die_id)
{
	/*TODO:*/
	return 0;
}
int vatools_pci_flash_bmcu_bin(struct vastai_pci_info *priv, u32 die_id,
			       u8 *path_name, const void *bin_buf,
			       size_t buf_size)
{
	return 0;
}
int vatools_pci_update_flag_xspi(struct vastai_pci_info *priv, u32 die_id,
				 u8 partition, u8 mode)
{
	return 0;
}
int vatools_pci_set_flash_wp(struct vastai_pci_info *priv, u32 die_id,
			     struct char_drv_info *dev, u32 cfg)
{
	/*TODO:*/
	return 0;
}
int vatools_pci_read_xspi(struct vastai_pci_info *priv, u32 die_id,
			  unsigned long addr, void *buf, u32 len, u8 partition)
{
	/*return vastai_pci_read_xspi(priv, addr, buf, len, partition);*/
	return 0;
}
int vatools_pci_get_sriov_numvfs(char dev_id)
{
	return 0;
}
int vatools_send_pcie_cmd_paras(struct vastai_pci_info *priv, u32 die_index,
				u32 sub_cmd, u64 paras)
{
	return 0;
}

/*PLL frequence clk ID*/
/*
enum SMI_PLL_SUBCMD_e {
	PLL_LEFT_VCLK,
	PLL_LEFT_LCCLK,
	PLL_LEFT_VDSPCLK,
	PLL_LEFT_LUCLK,
	PLL_LEFT_DCLK,
	PLL_LEFT_LPVTCLK,
	PLL_RIGHT_RCCLK,
	PLL_RIGHT_ECLK,
	PLL_RIGHT_RUCLK,
	PLL_RIGHT_GCLK,
	PLL_RIGHT_RPVTCLK,
	PLL_BOTTOM_CEDARCLK,
	PLL_BOTTOM_BCCLK,
	PLL_BOTTOM_PERIPHCLK,
	PLL_BOTTOM_XPHYCLK,
	PLL_BOTTOM_BPVTCLK,
	PLL_BOTTOM_DPI2S0CLK,
	PLL_BOTTOM_DPI2S1CLK,
	PLL_BOTTOM_DPAUXCLK,
	PLL_BOTTOM_APBDPCLK,
	PLL_BOTTOM_DP_PHY_CLK,
	PLL_BOTTOM_PIXLCK_DP0,
	PLL_BOTTOM_OCLK,
	PLL_BOTTOM_PIXLCK_DP1,
	PLL_BOTTOM_ODSPCLK,
	PLL_MAX_COUNT
};
*/
/*
	freq_unit: frequency name enum
	freq_value: frequency value, Hz
return:
	0: success
	other: fail
sample:
	ret = vatools_api_setfreq(priv, PLL_BOTTOM_PIXLCK_DP0, 500);
	ret = vatools_api_setfreq(priv, PLL_BOTTOM_PIXLCK_DP1, 500);
*/
int vatools_api_setfreq(struct vastai_pci_info *priv, unsigned int freq_unit,
			unsigned int freq_value)
{
	int ret;
	T_SMI_BLOCK *p_smi_block = NULL;
	u8 *cmd_buf = NULL;
	TS_SMI_CMD_REQ *pcmd = NULL;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	/*priv = vatools_get_vastai_pci_device_info_by_die_index(die_index);*/
	if (priv == NULL) {
		VATOOLS_DBG(priv, die_index,
			    "api: priv=NULL has no pci_info\n");
		ret = -ENODEV;
		goto out;
	}

	cmd_buf = (u8 *)vmalloc(SMI_CMD_BLOCK0_LEN);
	if (cmd_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index,
			    "api: alloc cmd_buf error. size=%d ret=%d\n",
			    SMI_CMD_BLOCK0_LEN, ret);
		goto out;
	}

	memset(cmd_buf, 0, SMI_CMD_BLOCK0_LEN);
	p_smi_block = vatools_fw_smi_get_block_via_app_category(VATOOLS_APP_SMI,
								priv);
	if (p_smi_block == NULL) {
		VATOOLS_DBG(priv, die_index, "api: p_smi_block=NULL\n");
		ret = -ENODEV;
		goto out_free;
	}
	pcmd = (TS_SMI_CMD_REQ *)cmd_buf;
	pcmd->cmd = SMI_CMD_CODE_PLL_CLOCK_SET;
	pcmd->data_len = SMI_CMD_BLOCK0_LEN - SMI_CMD_HEADER_LEN;
	pcmd->unit = 1 << freq_unit;
	pcmd->flag = FLAG_APP_REQ;
	*(u32 *)(cmd_buf + sizeof(TS_SMI_CMD_REQ) +
		 sizeof(u32) * 2 * freq_unit) = freq_value;
	*(u32 *)(cmd_buf + sizeof(TS_SMI_CMD_REQ) +
		 sizeof(u32) * 2 * freq_unit + sizeof(u32)) = freq_value;

	ret = vatools_driver_smi_cmd(p_smi_block->block_id, priv, die_index,
				     cmd_buf, SMI_CMD_BLOCK0_LEN);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "api: vatools_driver_smi_cmd error. ret=%d\n",
			     ret);
	} else {
		ret = 0;
	}
out_free:
	vfree(cmd_buf);
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}
/*
	freq_unit: frequency name enum
	freq_value: frequency value
return:
	0: success
	other: fail
sample:
	ret = vatools_api_getfreq(priv, PLL_BOTTOM_PIXLCK_DP0, value_p);
	ret = vatools_api_getfreq(priv, PLL_BOTTOM_PIXLCK_DP1, value_p);
*/
int vatools_api_getfreq(struct vastai_pci_info *priv, unsigned int freq_unit,
			unsigned int *freq_value)
{
	int ret = -EINVAL;
	T_SMI_BLOCK *p_smi_block = NULL;
	u8 *cmd_buf = NULL;
	TS_SMI_CMD_REQ *pcmd = NULL;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	/*priv = vatools_get_vastai_pci_device_info_by_die_index(die_index);*/
	if (priv == NULL) {
		VATOOLS_DBG(priv, die_index,
			    "api: priv=NULL has no pci_info\n");
		ret = -ENODEV;
		goto out;
	}

	cmd_buf = (u8 *)vmalloc(SMI_CMD_BLOCK0_LEN);
	if (cmd_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index,
			    "api: alloc cmd_buf error. size=%d ret=%d\n",
			    SMI_CMD_BLOCK0_LEN, ret);
		goto out;
	}

	memset(cmd_buf, 0, SMI_CMD_BLOCK0_LEN);
	p_smi_block = vatools_fw_smi_get_block_via_app_category(VATOOLS_APP_SMI,
								priv);
	if (p_smi_block == NULL) {
		VATOOLS_DBG(priv, die_index, "api: p_smi_block=NULL\n");
		ret = -ENODEV;
		goto out_free;
	}
	pcmd = (TS_SMI_CMD_REQ *)cmd_buf;
	pcmd->cmd = SMI_CMD_CODE_PLL_CLOCK_GET;
	pcmd->data_len = SMI_CMD_BLOCK0_LEN - SMI_CMD_HEADER_LEN;
	pcmd->unit = 1 << freq_unit;
	pcmd->flag = FLAG_APP_REQ;
	ret = vatools_driver_smi_cmd(p_smi_block->block_id, priv, die_index,
				     cmd_buf, SMI_CMD_BLOCK0_LEN);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "api: vatools_driver_smi_cmd error. ret=%d\n",
			     ret);
		goto out_free;
	} else {
		ret = 0;
	}

	*freq_value = *(u32 *)(cmd_buf + sizeof(TS_SMI_CMD_REQ) +
			       sizeof(u32) * 2 * freq_unit);
	VATOOLS_DBG(priv, die_index, "api: freq_value=%d 0x%x\n", *freq_value,
		    *freq_value);
out_free:
	vfree(cmd_buf);
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}
EXPORT_SYMBOL(vatools_api_setfreq);
EXPORT_SYMBOL(vatools_api_getfreq);

void vatools_print_buffer_hex(const char *prefix_str, void *pBuff,
			      unsigned int nLen)
{
	unsigned int i = 0;
	const int nBytePerLine = 16;
	unsigned char *p = (unsigned char *)pBuff;
	char szHex[3 * 16 /*nBytePerLine*/ + 1] = { 0 };

	if (NULL == pBuff || 0 == nLen) {
		return;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"--------------------------------------------------------\n");
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s buf=0x%llx len=%d\n", prefix_str,
		    (u64)pBuff, nLen);
	for (i = 0; i < nLen; ++i) {
		int idx = 3 * (i % nBytePerLine);
		if (0 == idx) {
			memset(szHex, 0, sizeof(szHex));
		}
/*The buff length should be passed in by 1 byte more*/
#ifdef WIN32

		sprintf_s(&szHex[idx], 4, "%02x ", p[i]);
#else
		snprintf(&szHex[idx], 4, "%02x ", p[i]);
#endif

		/*Print in 16-byte lines*/
		if (0 == ((i + 1) % nBytePerLine)) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s\n", szHex);
		}
	}

	/*Print the last line of content that is less than 16 bytes*/
	if (0 != (nLen % nBytePerLine)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s\n", szHex);
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"--------------------------------------------------------\n");
}

/*Transport layer DMA reading, automatic 4K alignment*/
int vatools_pci_tl_read(struct vastai_pci_info *priv, unsigned int die_id,
			u64 dev_addr, void *data, size_t size)
{
	int ret;
	void *temp_buf_4k_align = 0;
	u64 dev_addr_4K = 0;
	u64 dev_size_offset = 0;

	if (dev_addr % PAGE_SIZE) {
		VATOOLS_DBG(priv, die_id,
			    "%s [read] 0x%llx not page size align\n", __func__,
			    dev_addr);
		dev_addr_4K = (dev_addr) & (~(PAGE_SIZE - 1));
		dev_size_offset = dev_addr - dev_addr_4K;
	} else {
		dev_addr_4K = dev_addr;
	}

	VATOOLS_DBG(
		priv, die_id,
		"%s [read] dev_addr=0x%llx dev_addr_4K=0x%llx dev_size_offset=%llu (0x%llx) size=%lu (0x%lx) PAGE_SIZE=0x%lx\n",
		__func__, dev_addr, dev_addr_4K, dev_size_offset,
		dev_size_offset, size, size, PAGE_SIZE);

	temp_buf_4k_align = vmalloc(size + dev_size_offset);
	if (!temp_buf_4k_align) {
		VATOOLS_ERR(priv, die_id, "%s: failed to vmalloc. size=%llu \n",
			    __func__, size + dev_size_offset);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf_4k_align, 0, size + dev_size_offset);
	ret = vastai_pci_tl_read(priv, die_id, dev_addr_4K, temp_buf_4k_align,
				 size + dev_size_offset);
	if (ret) {
		VATOOLS_ERR(priv, die_id, "%s: dma transfer fail, ret = %d\n",
			    __func__, ret);
		goto free_temp_buf_4k_align;
	}
	memcpy(data, temp_buf_4k_align + dev_size_offset, size);

free_temp_buf_4k_align:
	vfree(temp_buf_4k_align);

out:
	return ret;
}

/*Murmurhash algorithm*/
unsigned int vatools_murmur_hash32(const void *key, int len, unsigned int seed)
{
	const u32 m = 0x5bd1e995;
	const int r = 24;

	u32 h = seed ^ len;

	const u8 *data = (const u8 *)key;

	while (len >= 4) {
		u32 k = *(u32 *)data;
		k *= m;
		k ^= k >> r;
		k *= m;
		h *= m;
		h ^= k;
		data += 4;
		len -= 4;
	}

	switch (len) {
	case 3:
		h ^= data[2] << 16;
		h ^= data[1] << 8;
		h ^= data[0];
		h *= m;
		break;
	case 2:
		h ^= data[1] << 8;
		h ^= data[0];
		h *= m;
		break;
	case 1:
		h ^= data[0];
		h *= m;
		break;
	}

	h ^= h >> 13;
	h *= m;
	h ^= h >> 15;

	return h;
}

bool vatools_check_pci_state(struct vastai_pci_info *priv, ...)
{
	int val = 0;
	bool ret = true;
	va_list p_args;

	if (!is_vastai_probe_done(priv)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
			     "%s: pci not done, current state %d\n", __func__,
			     atomic_read(&priv->pci_state));
		return ret;
	}

	va_start(p_args, priv);
	val = va_arg(p_args, int);

	if (val == -1) {
		ret = false;
		goto out;
	}

	while (val != -1) {
		if (atomic_read(&priv->pci_state) != val && ret)
			ret = true;
		else
			ret = false;

		val = va_arg(p_args, int);
	}

out:
	va_end(p_args);

	return ret;
}

/*
Whether Flash queries support Flash background inductive upgrade (does not
affect business execution)
 1: support  0: not support <0: fail
*/
int vatools_flash_support_update_background(struct vastai_pci_info *priv,
					    u32 flash_type)
{
	int ret;
	u16 bitmap_dl_support = 0;

	ret = is_support_download_fw_with_service(priv, &bitmap_dl_support);
	if (ret < 0) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
			    "call is_support_download_fw_with_service ret=%d\n",
			    ret);
		return ret;
	}
	VATOOLS_DBG(priv, DUMMY_DIE_ID, "flash bitmap_dl_support=%d\n",
		    bitmap_dl_support);

	switch (flash_type) {
	case VATOOLS_FLASH_UPDATE_BMCU:
		ret = !!((bitmap_dl_support & (1 << SUPPORT_BMCU)));
		break;
	case VATOOLS_FLASH_UPDATE_BL0:
		ret = !!((bitmap_dl_support & (1 << SUPPORT_BL0)));
		break;
	case VATOOLS_FLASH_UPDATE_PMCU:
		ret = !!((bitmap_dl_support & (1 << SUPPORT_PMCU)));
		break;
	}
	return ret;
}

/*fn reads memory data*/
int vatools_ioctl_fnread_reg_buf(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	u8 *temp_buf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.access_mem_cmd.die_index;
	die_index = vcmd.cmd.access_mem_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id[%u] \n",
			     did.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(priv, die_index,
		    "die_index=0x%x, addr=0x%llx, buf=0x%llx, size=%d\n",
		    vcmd.cmd.access_mem_cmd.die_index,
		    vcmd.cmd.access_mem_cmd.addr, vcmd.cmd.access_mem_cmd.buf,
		    vcmd.cmd.access_mem_cmd.size);

	temp_buf = (u8 *)kvmalloc(vcmd.cmd.access_mem_cmd.size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_index, " kvmalloc error. size=%d\n",
			    vcmd.cmd.access_mem_cmd.size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, vcmd.cmd.access_mem_cmd.size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vatools_pci_mem_fread(priv, die_index,
				    vcmd.cmd.access_mem_cmd.addr, temp_buf,
				    vcmd.cmd.access_mem_cmd.size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vatools_pci_mem_fread is error, ret=%d\n", ret);
		goto out_kvfree;
	}

	ret = copy_to_user_ex(
		(void __user *)(void *)vcmd.cmd.access_mem_cmd.buf, temp_buf,
		vcmd.cmd.access_mem_cmd.size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);

out:
	return ret;
}

/*fn writes memory data*/
int vatools_ioctl_fnwrite_reg_buf(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	u8 *temp_buf = NULL;
	union die_index_data did;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		return -EIO;
	}

	did.val = (u32)vcmd.cmd.access_mem_cmd.die_index;
	die_index = vcmd.cmd.access_mem_cmd.die_index;
	priv = vatools_get_vastai_pci_device_info(did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id[%u] \n",
			     did.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(priv, die_index,
		    "die_index=0x%x, addr=0x%llx, buf=0x%llx, size=%d\n",
		    vcmd.cmd.access_mem_cmd.die_index,
		    vcmd.cmd.access_mem_cmd.addr, vcmd.cmd.access_mem_cmd.buf,
		    vcmd.cmd.access_mem_cmd.size);

	temp_buf = (u8 *)kvmalloc(vcmd.cmd.access_mem_cmd.size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_index, " kvmalloc error. size=%d\n",
			    vcmd.cmd.access_mem_cmd.size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, vcmd.cmd.access_mem_cmd.size);
	ret = copy_from_user_ex(temp_buf,
				(void __user *)vcmd.cmd.access_mem_cmd.buf,
				vcmd.cmd.access_mem_cmd.size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	ret = vatools_pci_mem_fwrite(priv, die_index,
				     vcmd.cmd.access_mem_cmd.addr, temp_buf,
				     vcmd.cmd.access_mem_cmd.size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vatools_pci_mem_fwrite is error, ret=%d\n", ret);
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);

out:
	return ret;
}

/*In order to log with a simple file name for easy debugging, only 2 characters
 * are taken*/
char *vatools_log_brief_filename(const char *in_fliename, const char *in_func,
				 char *out_filename)
{
	*(out_filename + 0) = *(in_fliename + 8);
	*(out_filename + 1) = *(in_fliename + 9);
	*(out_filename + 2) = 0;
	return out_filename;
}
