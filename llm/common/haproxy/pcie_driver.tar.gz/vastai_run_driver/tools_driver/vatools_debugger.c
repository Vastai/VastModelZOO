﻿#include "vatools.h"
#include "vatools_log.h"

/*
* debugger
*/
/*Set the basic information at initialization*/
static u64 g_break_rsp_addr;
static u64 g_break_req_addr;
static u64 g_break_cmd_addr;
static u64 g_dump_body_addr;

loff_t debugger_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);

	return 0;
}

ssize_t debugger_read(struct file *filp, char __user *buf, size_t size,
		      loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t debugger_write(struct file *filp, const char __user *buf, size_t size,
		       loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t debugger_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);

	return 0;
}

unsigned int debugger_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);
	return 0;
}

/*Poll the flag of the fw*/
int debugger_wait_flag(void *priv, u32 die_index, u64 addr, u8 flag[],
		       u32 flag_count, t_break_cmd *p_break_cmd)
{
	int ret = 0;
	u32 i = 0;
	int loop = VADBG_POLL_FLAG_TOTAL_COUNT;
	u32 interval = VADBG_POLL_FLAG_INTERVAL_START;

	VATOOLS_FUNC_ENTERY;

	while (--loop > 0) {
		memset(p_break_cmd, 0, sizeof(t_break_cmd));

		ret = vatools_pci_mem_read((struct vastai_pci_info *)priv,
					   die_index, addr, (u8 *)p_break_cmd,
					   sizeof(t_break_cmd));
		if (ret < 0) {
			VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);
			goto out;
		}
		VATOOLS_DUMP_BRIEF("debugger_ioctl_dump read: ", p_break_cmd,
				   sizeof(t_break_cmd));

		for (i = 0; i < flag_count; i++) {
			VATOOLS_DBG(priv, die_index,
				    "read dump flag=0x%x  need flag=0x%x\n",
				    p_break_cmd->break_flag.oper_flag, flag[i]);

			if (p_break_cmd->break_flag.oper_flag == flag[i]) {
				/*Data ready*/
				VATOOLS_DBG(priv, die_index,
					    "flag match. ret=%d\n", ret);
				goto out;
			}
		}

		/*Increase the polling interval*/
		mdelay(interval);
		if (loop > VADBG_POLL_FLAG_TOTAL_COUNT -
				   VADBG_POLL_FLAG_ADDING_COUNT) {
			interval += VADBG_POLL_FLAG_INTERVAL_ADDING;
		}
	}
	if (loop == 0) {
		ret = -ETIME;
		VATOOLS_DBG(priv, die_index, "loop timeout. ret=%d [-ETIME]\n",
			    ret);
		goto out;
	}
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

/*
When dumping data, the command is sent first, and then the data is read, and when the data exceeds 1k,
it is read in sections. Use oper_index to identify the first few blocks to read
Parameter description:
*/
int debugger_ioctl_dump(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg,
			t_break_cmd *p_host_break_cmd,
			struct S_HOST_ARG_VAL *p_host_cmd)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	/*void __user* argp = ( void __user* )arg;*/
	void *temp_buf = NULL;
	int length = 0;
	u8 wait_flag[2] = { 0 };
	t_break_cmd fw_break_cmd;
	struct vastai_pci_info *priv = NULL;

	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);
	VATOOLS_FUNC_ENTERY;

	memset(&fw_break_cmd, 0x00, sizeof(t_break_cmd));

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	/*2. Poll the data, check the flag*/

	/*check flag*/
	wait_flag[0] = VADBG_BP_FLAG_FW_DUMP_DONE;
	wait_flag[1] = VADBG_BP_FLAG_FW_DUMP_NEXT;

	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		goto ERR_MEM;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto ERR_MEM;
	}
	ret = debugger_wait_flag(priv, p_host_break_cmd->device.die_index,
				 g_break_cmd_addr, wait_flag,
				 sizeof(wait_flag) / sizeof(wait_flag[0]),
				 &fw_break_cmd);

	/*3. Return to host*/
	if (ret >= 0) {
		VATOOLS_DUMP_BRIEF("debugger_ioctl_dump &fw_break_cmd: ",
				   &fw_break_cmd, sizeof(t_break_cmd));
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"dump.buffer_len=%d  dump.buffer_addr=0x%llx  dump.dump_len=%d  dump.dump_addr=0x%llx\n",
			fw_break_cmd.sub.dump.buffer_len,
			fw_break_cmd.sub.dump.buffer_addr,
			fw_break_cmd.sub.dump.dump_len,
			fw_break_cmd.sub.dump.dump_addr);

		/*flag indicates that the sub.dump data is complete, and the data is copied to the user*/
		temp_buf = (void *)kvmalloc(fw_break_cmd.sub.dump.dump_len,
					    GFP_KERNEL);
		if (!temp_buf) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    " kvmalloc error. size=%d\n",
				    fw_break_cmd.sub.dump.dump_len);
			goto ERR_MEM;
		}

		memset(temp_buf, 0, fw_break_cmd.sub.dump.dump_len);

		ret = vatools_pci_mem_read((struct vastai_pci_info *)priv,
					   p_host_break_cmd->device.die_index,
					   g_dump_body_addr, (u8 *)temp_buf,
					   fw_break_cmd.sub.dump.dump_len);
		if (ret < 0) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID,
				     " vatools_pci_mem_read error. ret=%d\n",
				     ret);
			goto ERR_MEM_FREE;
		}

		/*copy to user*/
		length = min(p_host_break_cmd->sub.dump.buffer_len,
			     fw_break_cmd.sub.dump.dump_len);

		if (copy_to_user_ex(
			    (void *)p_host_break_cmd->sub.dump.buffer_addr,
			    temp_buf, length)) {
			ret = -EFAULT;
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex ret=%d\n", ret);
			goto ERR_MEM_FREE;
		}

		p_host_break_cmd->sub.dump.dump_len = length;
		memcpy(p_host_break_cmd, &fw_break_cmd, sizeof(t_break_cmd));
		if (copy_to_user_ex((void __user *)p_host_cmd->pcBuf,
				    p_host_break_cmd, sizeof(t_break_cmd))) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex error .\n");
			ret = -EFAULT;
		}

		VATOOLS_DUMP_BRIEF("debugger_ioctl_dump temp_buf: ", temp_buf,
				   p_host_break_cmd->sub.dump.dump_len);

		/*if ( copy_to_user_ex((void __user *) argp, p_host_cmd, sizeof( struct S_HOST_ARG_VAL ) ) )*/
		/*{*/
		/*  VATOOLS_ERR( "copy_to_user_ex error ." );*/
		/*  ret = -EFAULT;*/
		/*}*/
	ERR_MEM_FREE:
		kvfree(temp_buf);
	}

ERR_MEM:
	VATOOLS_FUNC_EXIT;
	return ret;
}

int debugger_ioctl_breakpoint_cmd(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg,
				  struct S_HOST_ARG_VAL *p_host_cmd)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	/*void __user*      argp = ( void __user* )arg;*/
	/*struct buf_desc         cmd_desc;*/
	union core_bitmap core_id;
	t_break_cmd host_break_cmd;
	struct vastai_pci_info *priv = NULL;
	ring_buf_elem_t ring_buf_elem;

	VATOOLS_FUNC_ENTERY;

	/*memset( &cmd_desc, 0x00, sizeof( struct buf_desc ) );*/
	memset(&core_id, 0x00, sizeof(union core_bitmap));
	memset(&host_break_cmd, 0x00, sizeof(t_break_cmd));

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}
	memset(&host_break_cmd, 0x0, sizeof(t_break_cmd));
	if (copy_from_user_ex(&host_break_cmd, p_host_cmd->pcBuf,
			      sizeof(t_break_cmd))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "copy_from_user_ex error. p_host_cmd->pcBuf=0x%p\n",
			    p_host_cmd->pcBuf);
		ret = -EFAULT;
		goto out;
	}
	VATOOLS_DUMP_BRIEF("copy_from_user_ex host_break_cmd: ",
			   &host_break_cmd, sizeof(t_break_cmd));

	/*command information in fw. VADBG_CSRAM_BREAK_CMD_ADDR*/
	ret = vatools_pci_mem_write(priv, host_break_cmd.device.die_index,
				    g_break_cmd_addr, (u8 *)&host_break_cmd,
				    sizeof(t_break_cmd));
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vatools_pci_mem_write ret=%d\n", ret);
		goto out;
	}

	/*Send a message to core*/
	memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

	ring_buf_elem.whole = 0;
	ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
	ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_USE_RINGBUF;
	ring_buf_elem.seq_no = 0;
	ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_DEBUG_START_CMD;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"die_index=0x%x, write to soc=0x%llx , mcu_core_id=%d ring_buf_elem.whole=0x%llx\n",
		host_break_cmd.device.die_index, g_break_cmd_addr,
		host_break_cmd.mcu_core_id, ring_buf_elem.whole);

	/*Send interrupt to the CMCU*/
	ret = vatools_send_ctrl_cmd(priv, host_break_cmd.device.die_index,
				    1 << CORE_CMCU, ring_buf_elem.whole);
	if (ret) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "send msg failed. ret=%d\n",
			     ret);
		goto out;
	}

#if 0
	/*old code*/
	/*Send a message to CMCU*/
	core_id.val = 0x1; /*CMCU only one*/
	cmd_desc.data.debug_desc.ioctl_cmd = cmd;
	cmd_desc.data.debug_desc.debug_cmd = host_break_cmd.cmd;
	cmd_desc.data.debug_desc.model_index = 0;
	cmd_desc.data.debug_desc.layer_index = 0;
	cmd_desc.data.debug_desc.opcode_index = 0;
	cmd_desc.data.debug_desc.break_ctrl = 0;
	cmd_desc.data.debug_desc.break_flag = host_break_cmd.break_flag.val;
	cmd_desc.data.debug_desc.mcu_index = host_break_cmd.mcu_core_id;
	VATOOLS_DBG(
		"ioctl_cmd=0x%x debug_cmd=0x%x model=0x%x layer=0x%x opcode=0x%x break_ctrl=0x%x break_flag=0x%x\n",
		cmd_desc.data.debug_desc.ioctl_cmd,
		cmd_desc.data.debug_desc.debug_cmd,
		cmd_desc.data.debug_desc.model_index,
		cmd_desc.data.debug_desc.layer_index,
		cmd_desc.data.debug_desc.opcode_index,
		cmd_desc.data.debug_desc.break_ctrl,
		cmd_desc.data.debug_desc.break_flag);
	/*Send is interrupted to fw*/
	ret = vastai_pci_send_msg(priv, host_break_cmd.device.die_index,
				  core_id, &cmd_desc, sizeof(cmd_desc));
	if (ret) {
		VATOOLS_INFO("send msg failed. ret=%d\n", ret);
		goto out;
	}
#endif

	/*TODO: If you need to read the returned data, you need to add a follow-up process here*/
	if (host_break_cmd.cmd == VADBG_CMD_DUMP) {
		ret = debugger_ioctl_dump(filp, cmd, arg, &host_break_cmd,
					  p_host_cmd);
		if (ret < 0) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID,
				     "debugger_ioctl_dump failed. ret=%d\n",
				     ret);
			goto out;
		}
	}

out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

int debugger_ioctl_prepare_breakpoints(struct file *filp, unsigned int cmd,
				       IOCTL_ARG_T arg,
				       struct S_HOST_ARG_VAL *p_host_cmd)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	/*void __user* argp = ( void __user* )arg;*/
	t_break_req *p_host_break_req;
	struct vastai_pci_info *priv = NULL;

	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);
	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		goto ERR_MEM;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto ERR_MEM;
	}
	p_host_break_req =
		(t_break_req *)kvmalloc(sizeof(t_break_req), GFP_KERNEL);

	if (!p_host_break_req) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, " kvmalloc error. size=%ld\n",
			     sizeof(t_break_req));
		ret = -ENOMEM;
		goto ERR_MEM;
	}
	memset(p_host_break_req, 0x0, sizeof(t_break_req));
	if (copy_from_user_ex(p_host_break_req, p_host_cmd->pcBuf,
			      sizeof(t_break_req))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		ret = -EFAULT;
		goto ERR_MEM_FREE;
	}
	VATOOLS_DUMP_BRIEF("copy_from_user_ex host_break_req: ",
			   p_host_break_req, sizeof(t_break_req));

	/*command information in fw. VADBG_CSRAM_BREAKPOINT_ADDR*/
	ret = vatools_pci_mem_write((struct vastai_pci_info *)priv,
				    p_host_break_req->device.die_index,
				    g_break_req_addr, (u8 *)p_host_break_req,
				    sizeof(t_break_req));

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "die_index=0x%x, write to soc=0x%llx , ret=%d\n",
		    p_host_break_req->device.die_index, g_break_req_addr, ret);

	VATOOLS_FUNC_EXIT;

ERR_MEM_FREE:
	kvfree(p_host_break_req);

ERR_MEM:
	return ret;
}

int debugger_ioctl_poll_break_status(struct file *filp, unsigned int cmd,
				     IOCTL_ARG_T arg,
				     struct S_HOST_ARG_VAL *p_host_cmd)
{
	int ret = 0;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	t_break_rsp host_break_rsp;
	struct vastai_pci_info *priv = NULL;

	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&host_break_rsp, 0x00, sizeof(t_break_rsp));
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		return ret;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}
	memset(&host_break_rsp, 0x0, sizeof(t_break_rsp));

	/*Poll for breakpoint information from VADBG_CSRAM_BREAKED_ADDR*/
	ret = vatools_pci_mem_read(priv,
				   reader->trans_category.device.die_index,
				   g_break_rsp_addr, (u8 *)&host_break_rsp,
				   sizeof(t_break_rsp));
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     " vatools_pci_mem_read error. ret=%d\n", ret);
		return -EFAULT;
	}

	VATOOLS_DUMP_BRIEF("copy_from_user_ex host_break_rsp: ",
			   &host_break_rsp, sizeof(t_break_rsp));

	if (copy_to_user_ex((void __user *)p_host_cmd->pcBuf, &host_break_rsp,
			    sizeof(t_break_rsp))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		return -EFAULT;
	}

	if (copy_to_user_ex((void __user *)argp, p_host_cmd,
			    sizeof(struct S_HOST_ARG_VAL))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		return -EFAULT;
	}

	VATOOLS_FUNC_EXIT;
	return ret;
}

int debugger_ioctl_set(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	struct S_HOST_ARG_VAL host_cmd = { 0 };

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "cmd=0x%x  filp=0x%p  node=0x%p  reader=0x%p\n", cmd, filp,
		    node, reader);

	if (!node) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "node is NULL\n");
		ret = -EINVAL;
	}

	memset(&host_cmd, 0x0, sizeof(struct S_HOST_ARG_VAL));
	if (copy_from_user_ex(&host_cmd, (void __user *)argp,
			      sizeof(struct S_HOST_ARG_VAL))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		return -EFAULT;
	}
	VATOOLS_DUMP_BRIEF("copy_from_user_ex host_cmd: ", &host_cmd,
			   sizeof(struct S_HOST_ARG_VAL));
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "host_cmd.nType=0x%x\n",
		    host_cmd.nType);

	switch (host_cmd.nType) {
	case HOST_CMD:
		ret = debugger_ioctl_breakpoint_cmd(filp, cmd, arg, &host_cmd);
		break;
	case HOST_PREPARE_BREAKPOINTS:
		ret = debugger_ioctl_prepare_breakpoints(filp, cmd, arg,
							 &host_cmd);
		break;
	case HOST_POLL_BREAK_STATUS:
		ret = debugger_ioctl_poll_break_status(filp, cmd, arg,
						       &host_cmd);
		break;
	}
	VATOOLS_FUNC_EXIT;

	return ret;
}

int debugger_ioctl_get(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret = 0;

	VATOOLS_FUNC_ENTERY;
	ret = debugger_ioctl_set(filp, cmd, arg);
	VATOOLS_FUNC_EXIT;

	return ret;
}

int debugger_ioctl_config(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	struct s_config_info vadbg_config_info = { 0 };
	u8 temp[128] = { 0 };
	u32 j = 0;
	struct vastai_pci_info *priv = NULL;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		return ret;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "cmd=0x%x  filp=0x%p  node=0x%p  reader=0x%p\n", cmd, filp,
		    node, reader);

	if (!node) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "node is NULL\n");
		ret = -EINVAL;
	}

	if (copy_from_user_ex(&vadbg_config_info, (void __user *)argp,
			      sizeof(struct s_config_info))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		return -EFAULT;
	}

	/*s_config_info configuration information in csram.*/
	VATOOLS_DUMP_BRIEF("s_config_info: ", &vadbg_config_info,
			   sizeof(struct s_config_info));
	ret = vatools_pci_mem_write(priv,
				    reader->trans_category.device.die_index,
				    VADBG_CSRAM_CONFIG_ADDR,
				    (u8 *)&vadbg_config_info,
				    sizeof(struct s_config_info));
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vatools_pci_mem_write error ret=%d\n", ret);
		return -EFAULT;
	}

	/*Clear the data on the dump data ddr*/
	memset(temp, 0x0, 128);
	for (j = 0; j < VADBG_DUMP_BODY_LEN / 128; j++) {
		ret = vatools_pci_mem_write(
			(struct vastai_pci_info *)priv,
			reader->trans_category.device.die_index,
			VADBG_DUMP_BODY_ADDR + j * 128, (u8 *)temp, 128);
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "ret=%d\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

int debugger_ioctl_fetch(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret = 0;

	VATOOLS_FUNC_ENTERY;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);

	VATOOLS_FUNC_EXIT;

	return ret;
}

long debugger_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	struct vastai_pci_info *priv = NULL;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		return ret;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "cmd=0x%x  filp=0x%p  node=0x%p  reader=0x%p\n", cmd, filp,
		    node, reader);

	switch (cmd) {
	case VATOOLS_DEBUG_SET:
		ret = debugger_ioctl_set(filp, cmd, arg);
		break;
	case VATOOLS_DEBUG_GET:
		ret = debugger_ioctl_get(filp, cmd, arg);
		break;
	case VATOOLS_DEBUG_CONFIG:
		ret = debugger_ioctl_config(filp, cmd, arg);
		break;
	case VATOOLS_DEBUG_FETCH:
		ret = debugger_ioctl_fetch(filp, cmd, arg);
		break;
	}
	VATOOLS_FUNC_EXIT;
	return ret;
}

int debugger_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);
	return 0;
}
int debugger_open(struct inode *inode, struct file *filp)
{
	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);
	return 0;
}

int debugger_release(struct inode *ignored, struct file *filp)
{
	int ret = 0;
	struct vatools_node *node;
	struct vatools_reader *reader;
	/*struct buf_desc         cmd_desc;*/
	/*union core_bitmap       core_id;*/
	struct vastai_pci_info *priv = NULL;
	t_break_cmd host_break_cmd;
	ring_buf_elem_t ring_buf_elem;

	V_UNREFERENCE(ignored);
	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		return ret;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p  node=0x%p  reader=0x%p\n",
		    filp, node, reader);

	/*release needs to send a debug stop command to avoid the debug state not ending when the app is killed*/
	/*TODO: Traversal sent to all cores*/

	memset(&host_break_cmd, 0, sizeof(t_break_cmd));
	host_break_cmd.break_flag.val = 0x00000001;
	host_break_cmd.cmd = VADBG_CMD_STOP;
	host_break_cmd.device.dev_id = reader->trans_category.device.dev_id;
	host_break_cmd.device.die_id = reader->trans_category.device.die_id;
	host_break_cmd.device.die_index =
		reader->trans_category.device.die_index;
	host_break_cmd.mcu_core_id = 0xFFFF;

	VATOOLS_DUMP_BRIEF("copy_from_user_ex host_break_cmd: ",
			   &host_break_cmd, sizeof(t_break_cmd));

	/*command information in fw. VADBG_CSRAM_BREAK_CMD_ADDR*/
	ret = vatools_pci_mem_write((struct vastai_pci_info *)priv,
				    host_break_cmd.device.die_index,
				    g_break_cmd_addr, (u8 *)&host_break_cmd,
				    sizeof(t_break_cmd));
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vatools_pci_mem_write ret=%d\n", ret);
		goto out;
	}

	/*Send a message to core*/
	memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

	ring_buf_elem.whole = 0;
	ring_buf_elem.cmd = VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
	ring_buf_elem.use_ringbuf = VATOOLS_INTERRUPT_USE_RINGBUF;
	ring_buf_elem.seq_no = 0;
	ring_buf_elem.sub_cmd = VATOOLS_INTERRUPT_DEBUG_STOP_CMD;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"die_index=0x%x, write to soc=0x%llx , mcu_core_id=%d ring_buf_elem.whole=0x%llx\n",
		host_break_cmd.device.die_index, g_break_cmd_addr,
		host_break_cmd.mcu_core_id, ring_buf_elem.whole);

	/*Send interrupted to core*/
	ret = vatools_send_ctrl_cmd(priv, host_break_cmd.device.die_index,
				    1 << CORE_CMCU, ring_buf_elem.whole);
	if (ret) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "send msg failed. ret=%d\n",
			     ret);
		goto out;
	}

#if 0
	/*Send a message to CMCU*/
	core_id.val = 0x1; /*CMCU only one*/
	cmd_desc.data.debug_desc.ioctl_cmd = VADBG_IOCTL_CMD;
	cmd_desc.data.debug_desc.debug_cmd = VADBG_CMD_STOP;
	cmd_desc.data.debug_desc.model_index = 0;
	cmd_desc.data.debug_desc.layer_index = 0;
	cmd_desc.data.debug_desc.opcode_index = 0;
	cmd_desc.data.debug_desc.break_ctrl = 0;
	cmd_desc.data.debug_desc.break_flag = 0x00000001;
	cmd_desc.data.debug_desc.mcu_index = 0;
	VATOOLS_DBG(
		"ioctl_cmd=0x%x debug_cmd=0x%x model=0x%x layer=0x%x opcode=0x%x break_ctrl=0x%x break_flag=0x%x\n",
		cmd_desc.data.debug_desc.ioctl_cmd,
		cmd_desc.data.debug_desc.debug_cmd,
		cmd_desc.data.debug_desc.model_index,
		cmd_desc.data.debug_desc.layer_index,
		cmd_desc.data.debug_desc.opcode_index,
		cmd_desc.data.debug_desc.break_ctrl,
		cmd_desc.data.debug_desc.break_flag);
	/*Send interrupted to fw*/
	ret = vastai_pci_send_msg(priv, reader->trans_category.device.die_index,
				  core_id, &cmd_desc, sizeof(cmd_desc));
	if (ret) {
		VATOOLS_INFO("send msg failed. ret=%d\n", ret);
		goto out;
	}
#endif

out:

	VATOOLS_FUNC_EXIT;
	return 0;
}

int debugger_fasync(int fd, struct file *filp, int mode)
{
	V_UNREFERENCE(fd);
	V_UNREFERENCE(filp);
	V_UNREFERENCE(mode);

	return 0;
}

int debugger_set_app_category(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg)
{
	struct vatools_reader *reader;
	u8 dummy[256] = { 0 };
	int i = 0;
	int ret = 0;
	struct vastai_pci_info *priv = NULL;

	V_UNREFERENCE(arg);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "VATOOLS_APP_DEBUGGER cmd=0x%x\n", cmd);

	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		return ret;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		return ret;
	}
	/*TODO: For the time being, the debug driver is only for one type of device.
	The fw inside the fw of this type of device is debugged when using the same address.*/
	/*If one driver is compatible with multiple types of devices, it needs to be modified.*/
	g_break_rsp_addr = (u64)VADBG_CSRAM_BREAKED_ADDR;
	g_break_req_addr = (u64)VADBG_CSRAM_BREAKPOINT_ADDR;
	g_break_cmd_addr = (u64)VADBG_CSRAM_BREAK_CMD_ADDR;
	g_dump_body_addr = (u64)VADBG_DUMP_BODY_ADDR;

	/*TODO: Clear data*/
	for (i = 0; i < VADBG_CSRAM_LEN / 256; i++) {
		ret = vatools_pci_mem_write(
			(struct vastai_pci_info *)priv,
			reader->trans_category.device.die_index,
			VADBG_CSRAM_ADDR + i * 256, (u8 *)dummy, 256);
	}

	return ret;
}
