#include "vatools.h"
#include "vatools_log.h"

/*
 * vatools all category file ops
 */
/*Arranged according to app_category*/
static const struct file_operations_tool app_fops[] = {
	{
		.owner = THIS_MODULE,
		.llseek = dummy_llseek,
		.read = dummy_read,
		.write = dummy_write,
		.write_iter = dummy_write_iter,
		.poll = dummy_poll,
		.unlocked_ioctl = dummy_ioctl,
		.compat_ioctl = dummy_ioctl,
		.mmap = dummy_mmap,
		.open = dummy_open,
		.release = dummy_release,
		.fasync = dummy_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = smi_llseek,
		.read = smi_read,
		.write = smi_write,
		.write_iter = smi_write_iter,
		.poll = smi_poll,
		.unlocked_ioctl = smi_ioctl,
		.compat_ioctl = smi_ioctl,
		.mmap = smi_mmap,
		.open = smi_open,
		.release = smi_release,
		.fasync = smi_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = profiler_llseek,
		.read = profiler_read,
		.write = profiler_write,
		.write_iter = profiler_write_iter,
		.poll = profiler_poll,
		.unlocked_ioctl = profiler_ioctl,
		.compat_ioctl = profiler_ioctl,
		.mmap = profiler_mmap,
		.open = profiler_open,
		.release = profiler_release,
		.fasync = profiler_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = debugger_llseek,
		.read = debugger_read,
		.write = debugger_write,
		.write_iter = debugger_write_iter,
		.poll = debugger_poll,
		.unlocked_ioctl = debugger_ioctl,
		.compat_ioctl = debugger_ioctl,
		.mmap = debugger_mmap,
		.open = debugger_open,
		.release = debugger_release,
		.fasync = debugger_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = logger_llseek,
		.read = logger_read,
		.write = logger_write,
		.write_iter = logger_write_iter,
		.poll = logger_poll,
		.unlocked_ioctl = logger_ioctl,
		.compat_ioctl = logger_ioctl,
		.mmap = logger_mmap,
		.open = logger_open,
		.release = logger_release,
		.fasync = logger_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = dummy_llseek,
		.read = dummy_read,
		.write = dummy_write,
		.write_iter = dummy_write_iter,
		.poll = dummy_poll,
		.unlocked_ioctl = dummy_ioctl,
		.compat_ioctl = dummy_ioctl,
		.mmap = dummy_mmap,
		.open = dummy_open,
		.release = dummy_release,
		.fasync = dummy_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = sharedmem_llseek,
		.read = sharedmem_read,
		.write = sharedmem_write,
		.write_iter = sharedmem_write_iter,
		.poll = sharedmem_poll,
		.unlocked_ioctl = sharedmem_ioctl,
		.compat_ioctl = sharedmem_ioctl,
		.mmap = sharedmem_mmap,
		.open = sharedmem_open,
		.release = sharedmem_release,
		.fasync = sharedmem_fasync,
	},
	{
		.owner = THIS_MODULE,
		.llseek = dummy_llseek,
		.read = dummy_read,
		.write = dummy_write,
		.write_iter = dummy_write_iter,
		.poll = dummy_poll,
		.unlocked_ioctl = dummy_ioctl,
		.compat_ioctl = dummy_ioctl,
		.mmap = dummy_mmap,
		.open = dummy_open,
		.release = dummy_release,
		.fasync = dummy_fasync,
	}
};

T_RING_BUF_STATICS ring_buf_statics_table[RING_BUF_STATICS_TABLE_SIZE] = {
	{ PERFORMANCE_HOST_2_VEMCU0, "HOST_2_VEMCU0__" },
	{ PERFORMANCE_HOST_2_VEMCU1, "HOST_2_VEMCU1__" },
	{ PERFORMANCE_HOST_2_VEMCU2, "HOST_2_VEMCU2__" },
	{ PERFORMANCE_HOST_2_VEMCU3, "HOST_2_VEMCU3__" },
	{ PERFORMANCE_SMCU_2_VDMCU0, "SMCU_2_VDMCU0__" },
	{ PERFORMANCE_VDSP0_2_VDMCU0, "VDSP0_2_VDMCU0_" },
	{ PERFORMANCE_VDSP1_2_VDMCU0, "VDSP1_2_VDMCU0_" },
	{ PERFORMANCE_VEMCU0_2_VDMCU0, "VEMCU0_2_VDMCU0" },
	{ PERFORMANCE_VEMCU1_2_VDMCU0, "VEMCU1_2_VDMCU0" },
	{ PERFORMANCE_SMCU_2_VDMCU1, "SMCU_2_VDMCU1__" },
	{ PERFORMANCE_VDSP1_2_VDMCU1, "VDSP1_2_VDMCU1_" },
	{ PERFORMANCE_VDSP2_2_VDMCU1, "VDSP2_2_VDMCU1_" },
	{ PERFORMANCE_VEMCU1_2_VDMCU1, "VEMCU1_2_VDMCU1" },
	{ PERFORMANCE_VEMCU2_2_VDMCU1, "VEMCU2_2_VDMCU1" },
	{ PERFORMANCE_SMCU_2_VDMCU2, "SMCU_2_VDMCU2__" },
	{ PERFORMANCE_VDSP2_2_VDMCU2, "VDSP2_2_VDMCU2_" },
	{ PERFORMANCE_VDSP3_2_VDMCU2, "VDSP3_2_VDMCU2_" },
	{ PERFORMANCE_VEMCU2_2_VDMCU2, "VEMCU2_2_VDMCU2" },
	{ PERFORMANCE_VEMCU3_2_VDMCU2, "VEMCU3_2_VDMCU2" },
	{ PERFORMANCE_VDSP0_2_CMCU, "VDSP0_2_CMCU___" },
	{ PERFORMANCE_VDSP1_2_CMCU, "VDSP1_2_CMCU___" },
	{ PERFORMANCE_VDSP2_2_CMCU, "VDSP2_2_CMCU___" },
	{ PERFORMANCE_VDSP3_2_CMCU, "VDSP3_2_CMCU___" },
	{ PERFORMANCE_CMCU_2_VDSP0, "CMCU_2_VDSP0___" },
	{ PERFORMANCE_CMCU_2_VDSP1, "CMCU_2_VDSP1___" },
	{ PERFORMANCE_CMCU_2_VDSP2, "CMCU_2_VDSP2___" },
	{ PERFORMANCE_CMCU_2_VDSP3, "CMCU_2_VDSP3___" },
	{ PERFORMANCE_HOST_2_VDSP0, "HOST_2_VDSP0___" },
	{ PERFORMANCE_HOST_2_VDSP1, "HOST_2_VDSP1___" },
	{ PERFORMANCE_HOST_2_VDSP2, "HOST_2_VDSP2___" },
	{ PERFORMANCE_HOST_2_VDSP3, "HOST_2_VDSP3___" },
	{ PERFORMANCE_SMCU0_2_HOST, "SMCU0_2_HOST___" },
	{ PERFORMANCE_SMCU1_2_HOST, "SMCU1_2_HOST___" },
	{ PERFORMANCE_VDMCU1_2_HOST, "VDMCU1_2_HOST__" },
	{ PERFORMANCE_VDMCU2_2_HOST, "VDMCU2_2_HOST__" },
	{ PERFORMANCE_VEMCU0_2_HOST, "VEMCU0_2_HOST__" },
	{ PERFORMANCE_VEMCU1_2_HOST, "VEMCU1_2_HOST__" },
	{ PERFORMANCE_VEMCU2_2_HOST, "VEMCU2_2_HOST__" },
	{ PERFORMANCE_VEMCU3_2_HOST, "VEMCU3_2_HOST__" },
	{ PERFORMANCE_VDSP0_2_HOST, "VDSP0_2_HOST___" },
	{ PERFORMANCE_VDSP1_2_HOST, "VDSP1_2_HOST___" },
	{ PERFORMANCE_VDSP2_2_HOST, "VDSP2_2_HOST___" },
	{ PERFORMANCE_VDSP3_2_HOST, "VDSP3_2_HOST___" },
	{ PERFORMANCE_DMA_HOST_2_DEV, "DMA_HOST_2_DEV_" },
	{ PERFORMANCE_DMA_DEV_2_HOST, "DMA_DEV_2_HOST_" },
	{ PERFORMANCE_DMA_RC_IN, "DMA_RC_IN______" },
	{ PERFORMANCE_DMA_RC_OUT, "DMA_RC_OUT_____" },
};

/*
 * add global vatools node open list, used for hot plug
 */
LIST_HEAD(vatools_open_list);
#if (TOOLS_WIN == 1)
struct mutex g_mutex_open_list;
#else
DEFINE_MUTEX(g_mutex_open_list);
#endif

static int vatools_add_open_list(enum va_f_type type);
static void vatools_del_open_list(enum va_f_type type);
atomic_t _vatools_in_kill_routine = ATOMIC_INIT(0);

/*
 * mutex for tools_init and tools_exit
 */
#if (TOOLS_WIN == 1)
struct mutex g_mutex_tools_init;
#else
DEFINE_MUTEX(g_mutex_tools_init);
#endif

/*
 * get core id by core index
 */

#if 0
static uint32_t _internal_parray_coreid[CORE_NUMBER] = {
	COREID_DEFINE_8(CORE_TYPE_LMCU),  COREID_DEFINE_8(CORE_TYPE_ODSP),
	COREID_DEFINE_4(CORE_TYPE_VEMCU), COREID_DEFINE_3(CORE_TYPE_VDMCU),
	(CORE_TYPE_SMCU << 6) | 0,	  COREID_DEFINE_4(CORE_TYPE_VDSP),
	(CORE_TYPE_CMCU << 6) | 0,
};

static u32 vatools_get_core_id(u32 n_core_index)
{
	return _internal_parray_coreid[n_core_index];
}
#endif

static struct vatools_node *vatools_get_node_from_minor(int minor)
{
	struct vatools_node *node = NULL;

	list_for_each_entry (node, vatools_get_vastai_head(), list_nodes) {
		if (MINOR(node->file_info.dev_num) == minor)
			return node;
	}
	return NULL;
}

struct vatools_node *vatools_get_node(void)
{
	struct vatools_node *node = NULL;

	list_for_each_entry (node, vatools_get_vastai_head(), list_nodes) {
		if (node != NULL)
			return node;
	}
	return NULL;
}

static long vatools_get_device_num(struct file *filp, unsigned int cmd,
				   IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	unsigned int device_num = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	device_num = vatools_get_vastai_pci_device_number();
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "device_num=%d\n", device_num);

	if (copy_to_user_ex((void __user *)argp, &device_num,
			    sizeof(unsigned int))) {
		ret = -EFAULT;
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		goto out;
	}

	ret = 0;

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_dev_info(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	struct vatools_node *node = vatools_file_get_node(filp);
	vatools_ioctl_arg_t *ioctl_arg;
	vatools_dev_info_t *dev_info_p = NULL;
	struct vastai_cdev *vacc_dev_p = NULL;
	struct vastai_cdev *vacc_dev_temp = NULL;
	struct vastai_render_file *render_file_p = NULL;
	struct vastai_render_file *render_file_temp = NULL;

	struct vastai_pci_info *pci_info = NULL;
	u32 device_num = 0;
	int die = 0;
	void *buffer = NULL;
	int buffer_size = 0;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	ioctl_arg = (vatools_ioctl_arg_t *)kvmalloc(sizeof(vatools_ioctl_arg_t),
						    GFP_KERNEL);
	if (ioctl_arg == NULL) {
		VATOOLS_ERR(pci_info, die_index, "kvmalloc error. size=%ld\n",
			    sizeof(vatools_ioctl_arg_t));
		ret = -ENOMEM;
		goto out;
	}

	ret = copy_from_user_ex(ioctl_arg, (void __user *)argp,
				sizeof(vatools_ioctl_arg_header_t));
	if (ret) {
		VATOOLS_ERR(pci_info, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	device_num = vatools_get_vastai_pci_device_number();
	if (device_num == 0) {
		ret = -ENODEV;
		ioctl_arg->header.length = 0;
		if (copy_to_user_ex((void __user *)argp, ioctl_arg,
				    sizeof(vatools_ioctl_arg_header_t))) {
			ret = -EFAULT;
		}
		goto out_free_ioctl_arg;
	}

	buffer_size = device_num * sizeof(vatools_dev_info_t);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "device_num=%d buffer_size=%d\n",
		    device_num, buffer_size);
	buffer = kvmalloc(buffer_size, GFP_KERNEL);
	if (buffer == NULL) {
		VATOOLS_ERR(pci_info, die_index, "kvmalloc error. size=%d\n",
			    buffer_size);
		ret = -ENOMEM;
		goto out_free_ioctl_arg;
	}

	dev_info_p = (vatools_dev_info_t *)buffer;
	memset(buffer, 0, buffer_size);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#endif
	down_read(&tools_devs_rw_sem);
	/*TODO: Hot-swappable, after the board is plugged and unplugged, the device sequence number changes, and it is no longer continuous from 0*/
	list_for_each_entry (pci_info, &vastai_tools_devs_list,
			     tools_dev_list) {
		if (pci_info == NULL) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "pci_info is NULL\n");
			continue;
		}
		if (vatools_check_pci_state(pci_info, VASTAI_NORMAL_STATE,
					    -1)) {
			VATOOLS_DBG(pci_info, die_index,
				    "pci_info->pci_state=0x%x\n",
				    atomic_read(&pci_info->pci_state));
			continue;
		}

		dev_info_p->dev_id = pci_info->dev_id;
		dev_info_p->die_num = pci_info->die_num_in_fn;
		VATOOLS_DBG(pci_info, die_index,
			    "dev_id=%d die_num=%d buffer_size=%d\n",
			    dev_info_p->dev_id, dev_info_p->die_num,
			    buffer_size);

		/*bar size*/
		memcpy(dev_info_p->bar_address, vatools_die_check,
		       sizeof(vatools_die_check));

		/*char unid[ VASTAI_BUF_SIZE_32 ];*/ /*SN ; get from common (host); not here*/
		/*char card_type[ VASTAI_BUF_SIZE_32 ];*/ /*Card type; get from common (host); not here*/

		dev_info_p->pciid.vender_id = pci_info->dev->vendor;
		dev_info_p->pciid.device_id = pci_info->dev->device;
		dev_info_p->pcisubid.sub_vender_id =
			pci_info->dev->subsystem_vendor;
		dev_info_p->pcisubid.sub_device_id =
			pci_info->dev->subsystem_device;

		memcpy(dev_info_p->pcie_slot, pci_name(pci_info->dev),
		       VASTAI_BUF_SIZE_32);
#if (TOOLS_WIN == 0)
		dev_info_p->kchar.majormin.major =
			MAJOR(pci_info->p_char->file_info.dev_num);
		dev_info_p->kchar.majormin.minor =
			MINOR(pci_info->p_char->file_info.dev_num);

		memcpy(dev_info_p->kchar.name,
		       pci_info->p_char->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		dev_info_p->vastai_version.majormin.major =
			MAJOR(pci_info->version_file->file_info.dev_num);
		dev_info_p->vastai_version.majormin.minor =
			MINOR(pci_info->version_file->file_info.dev_num);
		memcpy(dev_info_p->vastai_version.name,
		       pci_info->version_file->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		dev_info_p->vastai_ctrl.majormin.major =
			MAJOR(pci_info->ctl_file->file_info.dev_num);
		dev_info_p->vastai_ctrl.majormin.minor =
			MINOR(pci_info->ctl_file->file_info.dev_num);

		memcpy(dev_info_p->vastai_ctrl.name,
		       pci_info->ctl_file->file_info.file_name,
		       VASTAI_BUF_SIZE_32);
#endif

		dev_info_p->vatools.majormin.minor = TOOLS_MINOR;
		dev_info_p->vatools.majormin.major = major;
		memcpy(dev_info_p->vatools.name, node->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		for (die = 0; die < dev_info_p->die_num; die++) {
			dev_info_p->die_info[die].die_index.val =
				pci_info->dies[die].die_index;
			VATOOLS_DBG(pci_info, die_index,
				    "dies[%d] dev_info_p->die_index=0x%x\n",
				    die,
				    dev_info_p->die_info[die].die_index.val);

			/*vastai video*/
			list_for_each_entry_safe (render_file_p,
						  render_file_temp,
						  &pci_info->render_head,
						  node) {
				if (render_file_p->die_index ==
				    pci_info->dies[die].die_index) {
#if (TOOLS_WIN == 0)
					dev_info_p->die_info[die]
						.vastai_video.majormin.major =
						MAJOR(render_file_p->file_info
							      .dev_num);
					dev_info_p->die_info[die]
						.vastai_video.majormin.minor =
						MINOR(render_file_p->file_info
							      .dev_num);
#endif
					snprintf(dev_info_p->die_info[die]
							 .vastai_video.name,
						 VASTAI_BUF_SIZE_32,
						 "vastai_video%u",
						 dev_info_p->die_info[die]
							 .die_index.seq_num);
					break;
				}
			}
#ifdef CONFIG_DRM_DRIVER
			/*renderD*/
			list_for_each_entry_safe (render_file_p,
						  render_file_temp,
						  &pci_info->render_head,
						  node) {
				if (render_file_p->die_index ==
				    pci_info->dies[die].die_index) {
					struct vastai_device_handle
						*device_handle;
					device_handle =
						(struct vastai_device_handle
							 *)(render_file_p
								    ->dec_private_data);

					dev_info_p->die_info[die]
						.render.majormin.major =
						226; /*DRM devices have the system specifying the primary device number as 226,
												  unchanged.*/

					dev_info_p->die_info[die]
						.render.majormin.minor =
						device_handle->drm_dev->render
							->index;

					snprintf(dev_info_p->die_info[die]
							 .render.name,
						 VASTAI_BUF_SIZE_32,
						 "renderD%u",
						 pci_info->dies[die].render_id);
					break;
				}
			}
#endif
			/*vacc*/
			list_for_each_entry_safe (vacc_dev_p, vacc_dev_temp,
						  &pci_info->vacc_dev_head,
						  vacc_dev_node) {
				if (vacc_dev_p->die_index ==
				    pci_info->dies[die].die_index) {
#if (TOOLS_WIN == 0)
					dev_info_p->die_info[die]
						.vacc.majormin.major = MAJOR(
						vacc_dev_p->file_info.dev_num);
					dev_info_p->die_info[die]
						.vacc.majormin.minor = MINOR(
						vacc_dev_p->file_info.dev_num);
#endif
					snprintf(dev_info_p->die_info[die]
							 .vacc.name,
						 VASTAI_BUF_SIZE_32, "vacc%u",
						 dev_info_p->die_info[die]
							 .die_index.seq_num);
					break;
				}
			}
		}

		dev_info_p++;
	}
	up_read(&tools_devs_rw_sem);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#endif

	ioctl_arg->header.err = 0;
	ioctl_arg->header.length = buffer_size;

	if (copy_to_user_ex((void __user *)argp, ioctl_arg,
			    sizeof(vatools_ioctl_arg_header_t))) {
		ret = -EFAULT;
		goto out_free_buffer;
	}

	if (copy_to_user_ex((void __user *)((u8 *)argp +
				    sizeof(vatools_ioctl_arg_header_t)),
			    buffer, buffer_size)) {
		ret = -EFAULT;
		goto out_free_buffer;
	}

	ret = 0;

out_free_buffer:
	kvfree(buffer);

out_free_ioctl_arg:
	kvfree(ioctl_arg);

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

static long vatools_get_die_info(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;

	int die_info[MAX_DIE_NUM_PER_DEVICE + 2] = { 0 };
	int die_index_array[MAX_DIE_NUM_PER_DEVICE] = { 0 };
	int die_num = 0;
	int i = 0;
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	ret = copy_from_user_ex(die_info, (void __user *)argp,
				sizeof(die_info));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}
	priv = vatools_get_vastai_pci_device_info((char)die_info[0]);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     die_info[0]);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(priv, die_index, "device_id: %d\n", die_info[0]);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#endif
	ret = vatools_get_vastai_die_info_via_device_id(
		(char)die_info[0], die_index_array, &die_num);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index,
			    VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#endif
	if (ret) {
		VATOOLS_INFO(priv, die_index, "device_id=%d, error %ld\n",
			     die_info[0], ret);
		goto out;
	}
	die_info[1] = die_num;
	for (i = 0; i < die_num; i++) {
		die_info[2 + i] = die_index_array[i];
	}

	if (copy_to_user_ex((void __user *)argp, die_info, sizeof(die_info))) {
		ret = -EFAULT;
		VATOOLS_ERR(priv, die_index, "ret=%ld\n", ret);
		goto out;
	}

	ret = 0;
out:
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_dev_pcie_bus_id(struct file *filp, unsigned int cmd,
					IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;

	struct vastai_pci_info *priv = NULL;
	TS_SMI_DEV_PCIE_BUS_ID dev_pcie_bus_id = { 0 };
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&dev_pcie_bus_id, 0x00, sizeof(TS_SMI_DEV_PCIE_BUS_ID));
	ret = copy_from_user_ex(&dev_pcie_bus_id, (void __user *)argp,
				sizeof(TS_SMI_DEV_PCIE_BUS_ID));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy from user ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

	priv = vatools_get_vastai_pci_device_info((char)dev_pcie_bus_id.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     dev_pcie_bus_id.dev_id);
		return -ENODEV;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}
#if VATOOLS_INDEPENDANCE_DRIVER
	strcpy(dev_pcie_bus_id.pcie_port, "pcie-simu\n");
#else
	strcpy(dev_pcie_bus_id.pcie_port, pci_name(priv->dev));
#endif
	ret = copy_to_user_ex((void __user *)argp, &dev_pcie_bus_id,
			      sizeof(TS_SMI_DEV_PCIE_BUS_ID));
	if (ret) {
		ret = -EFAULT;
		VATOOLS_ERR(priv, die_index, "ret=%ld\n", ret);
		goto out;
	}

	ret = 0;

out:
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_dev_pcie_id(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	TS_SMI_DEV_PCIE_ID dev_pcie_id = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&dev_pcie_id, 0x00, sizeof(TS_SMI_DEV_PCIE_ID));
	ret = copy_from_user_ex(&dev_pcie_id, (void __user *)argp,
				sizeof(TS_SMI_DEV_PCIE_ID));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy from user ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	dev_pcie_id.pcie_id = 0x1ec6 | 0x0100 << 16;

	ret = copy_to_user_ex((void __user *)argp, &dev_pcie_id,
			      sizeof(TS_SMI_DEV_PCIE_ID));
	if (ret) {
		ret = -EFAULT;
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "ret=%ld\n", ret);
		goto out;
	}
	ret = 0;

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_dev_pcie_sub_id(struct file *filp, unsigned int cmd,
					IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	TS_SMI_DEV_PCIE_SUB_ID dev_pcie_sub_id = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&dev_pcie_sub_id, 0x00, sizeof(TS_SMI_DEV_PCIE_SUB_ID));
	ret = copy_from_user_ex(&dev_pcie_sub_id, (void __user *)argp,
				sizeof(TS_SMI_DEV_PCIE_SUB_ID));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy from user ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	dev_pcie_sub_id.pcie_sub_id = 0xFFFF;

	ret = copy_to_user_ex((void __user *)argp, &dev_pcie_sub_id,
			      sizeof(TS_SMI_DEV_PCIE_SUB_ID));
	if (ret) {
		ret = -EFAULT;
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "ret=%ld\n", ret);
		goto out;
	}
	ret = 0;

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_dev_major_minor_id(struct file *filp, unsigned int cmd,
					   IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	TS_SMI_DEV_MAJOR_MINOR dev_major_minor = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&dev_major_minor, 0x00, sizeof(TS_SMI_DEV_MAJOR_MINOR));
	ret = copy_from_user_ex(&dev_major_minor, (void __user *)argp,
				sizeof(TS_SMI_DEV_MAJOR_MINOR));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy from user ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	dev_major_minor.major_minor = 0x0;

	ret = copy_to_user_ex((void __user *)argp, &dev_major_minor,
			      sizeof(TS_SMI_DEV_MAJOR_MINOR));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy to user ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
	ret = 0;

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_die_render(struct file *filp, unsigned int cmd,
				   IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	TS_SMI_DIE_RENDER die_render = { 0 };
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&die_render, 0x00, sizeof(TS_SMI_DIE_RENDER));
	ret = copy_from_user_ex(&die_render, (void __user *)argp,
				sizeof(die_render));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy from user ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

	priv = vatools_get_vastai_pci_device_info((char)die_render.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     die_render.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}
	snprintf(die_render.render, 16, "renderD%u",
		 priv->dies[die_render.die_id].render_id);
	ret = copy_to_user_ex((void __user *)argp, &die_render,
			      sizeof(TS_SMI_DIE_RENDER));
	if (ret) {
		ret = -EFAULT;
		VATOOLS_ERR(priv, die_index, "ret=%ld\n", ret);
		goto out;
	}

	ret = 0;

out:
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_get_device_capability(struct file *filp, unsigned int cmd,
					  IOCTL_ARG_T arg)
{
	long ret;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	SMI_DEVICE_CAPABILITY device_cap = { 0 };
	u32 die_index = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&device_cap, 0x00, sizeof(SMI_DEVICE_CAPABILITY));
	ret = copy_from_user_ex(&device_cap, (void __user *)argp,
				sizeof(SMI_DEVICE_CAPABILITY));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy from user ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

	priv = vatools_get_vastai_pci_device_info((char)device_cap.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     device_cap.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}
	memcpy(&device_cap.capability, &priv->vadev,
	       sizeof(struct vastai_dev_info));
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);

	ret = copy_to_user_ex((void __user *)argp, &device_cap,
			      sizeof(SMI_DEVICE_CAPABILITY));
	if (ret) {
		ret = -EFAULT;
		VATOOLS_ERR(priv, die_index, "ret=%ld\n", ret);
		goto out;
	}

	ret = 0;

out:
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long vatools_set_app_category(struct file *filp, unsigned int cmd,
				     IOCTL_ARG_T arg)
{
	struct vatools_reader *reader = vatools_file_get_reader(filp);
	long ret;
	void __user *argp = (void __user *)arg;
/*int die_index = 0;*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	struct vatools_node *node = reader->node;
#endif

	VATOOLS_FUNC_ENTERY;
	ret = copy_from_user_ex(&(reader->trans_category), (void __user *)argp,
				sizeof(reader->trans_category));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	/*The following category needs to be bound to the device information at the same time. In the release section, you can release the resources of the corresponding device*/
	if ((reader->trans_category.app_category == VATOOLS_APP_SMI) ||
	    (reader->trans_category.app_category == VATOOLS_APP_PROFILER) ||
	    (reader->trans_category.app_category == VATOOLS_APP_DEBUGGER) ||
	    (reader->trans_category.app_category == VATOOLS_APP_MONITOR)) {
/*die_index = vatools_get_vastai_pci_die_index(*/
/*	(char)reader->trans_category.device.dev_id,*/
/*	reader->trans_category.device.die_id);*/
/*if (die_index < 0) {*/
/*	ret = -ENODEV;*/
/*	goto out;*/
/*}*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_lock(&node->node_reader_mutex);
#endif
/*reader->trans_category.device.die_index = die_index;*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_unlock(&node->node_reader_mutex);
#endif
	} else {
/*Data in the shared memory state is used for other purposes*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_lock(&node->node_reader_mutex);
#endif
		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			reader->trans_category.block_id = SMI_CMD_BLOCK_ID_0;
			reader->trans_category.app_category = VATOOLS_APP_SMI;
			reader->trans_category.device.dev_id = 0;
			reader->trans_category.device.die_id = 0;
			reader->trans_category.device.die_index = 0;
		} else {
/*Replacing the pid in user mode with the pid in kernel mode ensures that it is correctly identified in docker*/
#if (TOOLS_WIN == 1)
			reader->trans_category.device.dev_id =
				(u32)PsGetCurrentProcessId();
			reader->trans_category.device.die_id = 0;
			reader->trans_category.device.die_index =
				(u32)PsGetCurrentProcessId();
#else
/* sharedmem use ns/vpid to check in docker & don't overlay dev_id/die_id/die_index from userspace */
/*
			reader->trans_category.device.dev_id = current->tgid;
			reader->trans_category.device.die_id = 0;
			reader->trans_category.device.die_index = current->tgid;
*/
#endif
		}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_unlock(&node->node_reader_mutex);
#endif
	}
	/*VATOOLS DBG*/
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"reader=%p,app_category=%d  block_id=%d  device_id=%d  die_id=%d  "
		"die_index=0x%x\n",
		reader, reader->trans_category.app_category,
		reader->trans_category.block_id,
		reader->trans_category.device.dev_id,
		reader->trans_category.device.die_id,
		reader->trans_category.device.die_index);

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_lock(&node->node_reader_mutex);
#endif
	switch (reader->trans_category.app_category) {
	case VATOOLS_APP_SHAREDMEM:
		sharedmem_set_app_category(filp, cmd, arg);
		break;
	case VATOOLS_APP_DEBUGGER:
		debugger_set_app_category(filp, cmd, arg);
		break;
	}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_unlock(&node->node_reader_mutex);
#endif

out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static unsigned int vatools_get_app_category(struct file *filp)
{
	struct vatools_reader *reader = vatools_file_get_reader(filp);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "app_category=%d\n",
		    reader->trans_category.app_category);

	return (unsigned int)reader->trans_category.app_category;
}

/*
 * smi
 */

static long vatools_driver_read(struct file *file, unsigned int cmd,
				IOCTL_ARG_T arg)
{
	return vatools_driver_smi_fetch(file, cmd, arg);
}

static long vatools_driver_write(struct file *file, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	return vatools_driver_smi_fetch(file, cmd, arg);
}

/*
 * PCIe FOPS
 */

static long vatools_pcie_ioctl_bandwidth(T_SMI_IOCTL_TRANS_DATA *pkdata,
					 struct vastai_pci_info *priv,
					 int die_index)
{
	long ret;
	/*u32 low_upstream_count = 0;*/
	u64 upstream_count = 0;
	/*u32 low_downstream_count = 0;*/
	u64 downstream_count = 0;
	/*upstream*/
	/*
	ret = vatools_pci_mem_read( priv, die_index, 0x900002c, &low_upstream_count, sizeof( u32 ) );
	if ( ret < 0 )
	{
	ret = -EFAULT;
	goto out;
	}
	*/
	ret = vastai_pci_mem_read(priv, die_index, PCIE_BANDWIDTH_UPSTREAM,
				  &upstream_count, sizeof(u64));
	if (ret < 0) {
		ret = -EFAULT;
		goto out;
	}

	/*upstream_count &= 0xFFFFFFFF00000000;*/
	/*upstream_count |= low_upstream_count;*/

	VATOOLS_DBG(priv, die_index, "upstream_count: ret=0x%llx\n",
		    upstream_count);

	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr +
				      sizeof(TS_SMI_CMD_REQ),
			      &upstream_count, sizeof(u64));
	if (ret < 0) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
	/*downstream*/
	/*
	ret = vatools_pci_mem_read( priv, die_index, 0x9000034, &low_downstream_count, sizeof( u32 ) );
	if ( ret < 0 )
	{
	ret = -EFAULT;
	goto out;
	}
	*/
	ret = vastai_pci_mem_read(priv, die_index, PCIE_BANDWIDTH_DOWNSTREAM,
				  &downstream_count, sizeof(u64));
	if (ret < 0) {
		ret = -EFAULT;
		goto out;
	}

	/*downstream_count &= 0xFFFFFFFF00000000;*/
	/*downstream_count |= low_downstream_count;*/
	VATOOLS_DBG(priv, die_index, "downstream_count: ret=0x%llx\n",
		    downstream_count);
	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr +
				      sizeof(TS_SMI_CMD_REQ) + sizeof(u64),
			      &downstream_count, sizeof(u64));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
out:
	return ret;
}

static long vatools_pcie_ioctl_reset(T_SMI_IOCTL_TRANS_DATA *pkdata,
				     struct vastai_pci_info *priv,
				     int die_index)
{
	long ret;
	VATOOLS_DBG(
		priv, die_index,
		"smi trigger die_index=0x%x : reset. current ddr_bw_test=%d\n",
		die_index, priv->ddr_bw_test);
	priv->ddr_bw_test = 0;

	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DEVICE);
	ret = vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER);
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DEVICE);
	return ret;
}

static long vatools_pcie_ioctl_boot(T_SMI_IOCTL_TRANS_DATA *pkdata,
				    struct vastai_pci_info *priv, int die_index)
{
	long ret;
	VATOOLS_DBG(
		priv, die_index,
		"smi trigger die_index=0x%x : boot. current ddr_bw_test=%d\n",
		die_index, priv->ddr_bw_test);
	priv->ddr_bw_test = 0;
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DEVICE);
	ret = vastai_device_reset(priv, VASTAI_RESET_BOOT_DEV);
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DEVICE);
	return ret;
}

static long vatools_pcie_ioctl_reboot(T_SMI_IOCTL_TRANS_DATA *pkdata,
				      struct vastai_pci_info *priv,
				      int die_index)
{
	long ret;
	int die_id = 0;

	for (die_id = priv->die_num_in_fn - 1; die_id >= 0; die_id--) {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_lock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		ret = vastai_send_pcie_cmd(
			priv, vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_RESUME_BW_TEST, 0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_unlock(
				priv, die_index,
				VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_unlock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		if (ret) {
			VATOOLS_INFO(priv, DUMMY_DIE_ID,
				     "%s [resume_bw] , error:%ld\n", __func__,
				     ret);
			return ret;
		}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_lock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vastai_send_pcie_cmd(
			priv, vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_STOP_BW_TEST, 0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_unlock(
				priv, die_index,
				VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_unlock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		if (ret) {
			VATOOLS_INFO(priv, DUMMY_DIE_ID,
				     "%s [stop_bw] , error:%ld\n", __func__,
				     ret);
			return ret;
		}

		if (wait_for_completion_timeout(
			    &(priv->dies[die_id].stop_bw_done),
			    msecs_to_jiffies(
				    VASTAI_PCIE_WAIT_SMCU_MSG1_TIME)) <= 0) {
			VASTAI_PCI_ERR(priv, die_id, "%s timeout!\n", __func__);
			return -ETIMEDOUT;
		}

		reinit_completion(&(priv->dies[die_id].stop_bw_done));
	}
	ssleep(1); /*waiting udma actually stop*/
	VATOOLS_DBG(
		priv, die_index,
		"smi trigger die_index=0x%x : reboot. current ddr_bw_test=%d\n",
		die_index, priv->ddr_bw_test);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, vastai_pci_get_die_index(priv, die_id),
			  VATOOLS_IOCTL_DOMAIN_DEVICE);
#endif
	priv->ddr_bw_test = 0;

	ret = vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER |
						VASTAI_RESET_BOOT_DEV);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, vastai_pci_get_die_index(priv, die_id),
			    VATOOLS_IOCTL_DOMAIN_DEVICE);
#endif
	for (die_id = priv->die_num_in_fn - 1; die_id >= 0; die_id--) {
		if (iommu_is_enable(priv)) {
			if (priv->dies[die_id].vatool_dm_sg) {
				vastai_dma_buf_sg_put(
					priv, priv->dies[die_id].vatool_dm_sg);
			}

		} else {
			if (priv->dies[die_id].vatool_dm.vir) {
				vastai_udma_free(
					priv, &(priv->dies[die_id].vatool_dm));
			}
		}
	}
	return ret;
}

static long vatools_pcie_ioctl_fw_version(T_SMI_IOCTL_TRANS_DATA *pkdata,
					  struct vastai_pci_info *priv,
					  int die_index)
{
	long ret = -EINVAL;
	struct vastai_fw_version fw_ver;
	memcpy(&fw_ver, &(priv->dies[0].fw_ver),
	       sizeof(struct vastai_fw_version));
	VATOOLS_DUMP_BRIEF("fw_ver: ", &fw_ver,
			   sizeof(struct vastai_fw_version));
	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      &fw_ver, sizeof(struct vastai_fw_version));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
out:
	return ret;
}

static long vatools_pcie_ioctl_ecc_1bit(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	struct vastai_fifo *ecc_fifo;
	u32 table_size = pkdata->output_buf.buf_size;
	u8 *buffer;

	if (table_size > DDR_ECC_1BIT_SIZE) {
		table_size = DDR_ECC_1BIT_SIZE;
	}

	die_index = pkdata->device.die_index;
	buffer = (u8 *)kvmalloc(table_size, GFP_KERNEL);
	if (buffer == NULL) {
		VATOOLS_ERR(
			priv, die_index,
			"PCIE_CMD_FLAG_DDR_ECC_1BIT kvmalloc error. size=%d\n",
			table_size);
		ret = -ENOMEM;
		goto out;
	}

	ret = vatools_pci_mem_read(priv, die_index, ECC_1BIT_ERR_STORE_ADDR,
				   buffer, table_size);
	if (ret < 0) {
		ret = -EFAULT;
		goto out_free_write_buf_1bit;
	}
	ecc_fifo = (struct vastai_fifo *)buffer;
	VATOOLS_DUMP_BRIEF("ecc 1bit: ", buffer, table_size);
	/*ecc_fifo->rd returns to the application layer, and the corresponding variable is entry_count*/
	if (ecc_fifo->elem_count == 0) {
		VATOOLS_DBG(priv, die_index,
			    "ecc1bit: ecc_fifo->elem_count = 0\n");
		ecc_fifo->rd = 0;
	} else {
		ecc_fifo->rd = (ecc_fifo->elem_count +
				(((int)ecc_fifo->wr) - (int)(ecc_fifo->rd))) %
			       ecc_fifo->elem_count;
	}

	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      buffer, table_size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_write_buf_1bit;
	}

out_free_write_buf_1bit:
	kvfree(buffer);
out:
	return ret;
}

static long vatools_pcie_ioctl_ecc_2bit(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	struct vastai_fifo *ecc_fifo;
	u32 table_size = pkdata->output_buf.buf_size;
	u8 *buffer;

	if (table_size > DDR_ECC_2BIT_SIZE) {
		table_size = DDR_ECC_2BIT_SIZE;
	}

	die_index = pkdata->device.die_index;
	buffer = (u8 *)kvmalloc(table_size, GFP_KERNEL);
	if (buffer == NULL) {
		VATOOLS_ERR(
			priv, die_index,
			"PCIE_CMD_FLAG_DDR_ECC_1BIT kvmalloc error. size=%d\n",
			table_size);
		ret = -ENOMEM;
		goto out;
	}

	ret = vatools_pci_mem_read(priv, die_index, ECC_2BIT_ERR_STORE_ADDR,
				   buffer, table_size);
	if (ret < 0) {
		ret = -EFAULT;
		goto out_free_write_buf_2bit;
	}
	ecc_fifo = (struct vastai_fifo *)buffer;
	VATOOLS_DUMP_BRIEF("ecc 2bit: ", buffer, table_size);
	/*ecc_fifo->rd returns to the application layer, and the corresponding variable is entry_count*/
	if (ecc_fifo->elem_count == 0) {
		VATOOLS_DBG(priv, die_index,
			    "ecc2bit: ecc_fifo->elem_count = 0\n");
		ecc_fifo->rd = 0;
	} else {
		ecc_fifo->rd = (ecc_fifo->elem_count +
				(((int)ecc_fifo->wr) - (int)(ecc_fifo->rd))) %
			       ecc_fifo->elem_count;
	}

	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      buffer, table_size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_write_buf_2bit;
	}

out_free_write_buf_2bit:
	kvfree(buffer);
out:
	return ret;
}

int check_if_is_odsp_as_vdsp(struct vastai_pci_info *priv, uint32_t die_index,
			     int odsp_id)
{
	int ret = 0;
	int die_id = vastai_pci_get_die_id(priv, die_index);
	uint16_t core_type = priv->dies[die_id]
				     .core[CORE_POINT_ODSP0 + odsp_id]
				     .cores_info_ref->core_type;

	if (core_type == VDSP_TYPE)
		ret = ODSP_AS_VDSP;
	else if (core_type == ODSP_TYPE)
		ret = ODSP_AS_ODSP;
	else
		ret = -1;

	return ret;
}

static long vatools_pcie_ioctl_vdsp_count(T_SMI_IOCTL_TRANS_DATA *pkdata,
					  struct vastai_pci_info *priv,
					  int die_index)
{
/*TODO: to be continued*/
#if (TOOLS_WIN == 1)
	long ret = -EINVAL;

	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      priv->dies[vastai_pci_get_die_id(priv, die_index)]
				      .pcie_tx_vdsp_count,
			      pkdata->output_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	ret = copy_to_user_ex(((u8 *)pkdata->output_buf.buf_addr) +
				      sizeof(u32) * 4,
			      priv->dies[vastai_pci_get_die_id(priv, die_index)]
				      .pcie_rx_vdsp_count,
			      pkdata->output_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}
out:
	return ret;
#else
	long ret = -EINVAL;
	int i = 0;
	u32 cnt;
	/*u32 pcie_tx_vdsp_count[4];*/
	/*u32 pcie_rx_vdsp_count[4];*/
	die_index = pkdata->device.die_index;

	for (i = 0; i < SV100_MAX_VDSP_NUM; i++) {
		cnt = vastai_get_vdsp_cnt(
			priv, vastai_pci_get_die_id(priv, die_index), i,
			0 /*pcie_tx_core_count host->dsp*/);
		if (cnt == -1) {
			VATOOLS_DBG(priv, die_index,
				    "get tx vdsp cnt failed\n");
			ret = -EFAULT;
			goto out;
		}
		ret = copy_to_user_ex(((u8 *)pkdata->output_buf.buf_addr) +
					      i * sizeof(cnt),
				      &cnt, sizeof(cnt));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out;
		}

		cnt = vastai_get_vdsp_cnt(
			priv, vastai_pci_get_die_id(priv, die_index), i,
			1 /*pcie_rx_core_count dsp->host*/);
		if (cnt == -1) {
			VATOOLS_DBG(priv, die_index,
				    "get rx vdsp cnt failed\n");
			ret = -EFAULT;
			goto out;
		}
		ret = copy_to_user_ex(
			((u8 *)pkdata->output_buf.buf_addr) +
				(sizeof(u32) * SV100_MAX_VDSP_NUM) +
				i * sizeof(cnt),
			&cnt, sizeof(cnt));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out;
		}
	}

	/*odsp as vdsp*/
	/*add odsp pcie count*/
	if (pkdata->output_buf.buf_size == 96) {
		/*need odsp count*/
		for (i = 0; i < SV100_MAX_ODSP_NUM; i++) {
			if (check_if_is_odsp_as_vdsp(priv, die_index, i) != 1)
				continue;
			cnt = vastai_get_vdsp_cnt(
				priv, vastai_pci_get_die_id(priv, die_index),
				i + SV100_MAX_VDSP_NUM,
				0 /*pcie_tx_core_count host->dsp*/);
			if (cnt == -1) {
				VATOOLS_DBG(priv, die_index,
					    "get tx vdsp cnt failed\n");
				ret = -EFAULT;
				goto out;
			}
			ret = copy_to_user_ex(
				((u8 *)pkdata->output_buf.buf_addr) +
					sizeof(u32) * SV100_MAX_VDSP_NUM * 2 +
					i * sizeof(cnt),
				&cnt, sizeof(cnt));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%ld\n", ret);
				ret = -EFAULT;
				goto out;
			}

			cnt = vastai_get_vdsp_cnt(
				priv, vastai_pci_get_die_id(priv, die_index),
				i + SV100_MAX_VDSP_NUM,
				1 /*pcie_rx_core_count dsp->host*/);
			if (cnt == -1) {
				VATOOLS_DBG(priv, die_index,
					    "get rx vdsp cnt failed\n");
				ret = -EFAULT;
				goto out;
			}
			ret = copy_to_user_ex(
				((u8 *)pkdata->output_buf.buf_addr) +
					sizeof(u32) * SV100_MAX_VDSP_NUM * 2 +
					(sizeof(u32) * SV100_MAX_ODSP_NUM) +
					i * sizeof(cnt),
				&cnt, sizeof(cnt));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%ld\n", ret);
				ret = -EFAULT;
				goto out;
			}
		}
	}

out:
	return ret;
#endif
}

static long vatools_pcie_ioctl_ai_count(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	u8 *ai_count_buffer;
	u32 ai_count_buffer_size = PERFORMANCE_AI_LEN;

	if (pkdata->output_buf.buf_size < ai_count_buffer_size) {
		ret = -EFAULT;
		VATOOLS_INFO(priv, die_index,
			     "output buffer size < %d ret=%ld\n",
			     ai_count_buffer_size, ret);
		goto out;
	}

	ai_count_buffer = (u8 *)kvmalloc(ai_count_buffer_size, GFP_KERNEL);
	if (ai_count_buffer == NULL) {
		VATOOLS_ERR(priv, die_index,
			    "PCIE_CMD_FLAG_AI_COUNT kvmalloc. size=%d\n",
			    ai_count_buffer_size);
		ret = -ENOMEM;
		goto out;
	}

	die_index = pkdata->device.die_index;
	ret = vatools_pci_mem_read(priv, die_index, PERFORMANCE_AI_BASE,
				   ai_count_buffer, ai_count_buffer_size);
	if (ret < 0) {
		ret = -EFAULT;
		goto out_free_write_buf_ai_count;
	}

	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      ai_count_buffer, ai_count_buffer_size);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_write_buf_ai_count;
	}
out_free_write_buf_ai_count:
	kvfree(ai_count_buffer);
out:
	return ret;
}

static long
vatools_pcie_ioctl_ring_buf_statistic(T_SMI_IOCTL_TRANS_DATA *pkdata,
				      struct vastai_pci_info *priv,
				      int die_index)
{
	long ret;
	u32 i = 0;

	T_RING_BUF_STATICS ring_buf_statics[] = {
		{ PERFORMANCE_HOST_2_VEMCU0 },
		{ PERFORMANCE_HOST_2_VEMCU1 },
		{ PERFORMANCE_HOST_2_VEMCU2 },
		{ PERFORMANCE_HOST_2_VEMCU3 },
		{ PERFORMANCE_SMCU_2_VDMCU0 },
		{ PERFORMANCE_VDSP0_2_VDMCU0 },
		{ PERFORMANCE_VDSP1_2_VDMCU0 },
		{ PERFORMANCE_VEMCU0_2_VDMCU0 },
		{ PERFORMANCE_VEMCU1_2_VDMCU0 },
		{ PERFORMANCE_SMCU_2_VDMCU1 },
		{ PERFORMANCE_VDSP1_2_VDMCU1 },
		{ PERFORMANCE_VDSP2_2_VDMCU1 },
		{ PERFORMANCE_VEMCU1_2_VDMCU1 },
		{ PERFORMANCE_VEMCU2_2_VDMCU1 },
		{ PERFORMANCE_SMCU_2_VDMCU2 },
		{ PERFORMANCE_VDSP2_2_VDMCU2 },
		{ PERFORMANCE_VDSP3_2_VDMCU2 },
		{ PERFORMANCE_VEMCU2_2_VDMCU2 },
		{ PERFORMANCE_VEMCU3_2_VDMCU2 },
		{ PERFORMANCE_VDSP0_2_CMCU },
		{ PERFORMANCE_VDSP1_2_CMCU },
		{ PERFORMANCE_VDSP2_2_CMCU },
		{ PERFORMANCE_VDSP3_2_CMCU },
		{ PERFORMANCE_CMCU_2_VDSP0 },
		{ PERFORMANCE_CMCU_2_VDSP1 },
		{ PERFORMANCE_CMCU_2_VDSP2 },
		{ PERFORMANCE_CMCU_2_VDSP3 },
		{ PERFORMANCE_HOST_2_VDSP0 },
		{ PERFORMANCE_HOST_2_VDSP1 },
		{ PERFORMANCE_HOST_2_VDSP2 },
		{ PERFORMANCE_HOST_2_VDSP3 },
		{ PERFORMANCE_SMCU0_2_HOST },
		{ PERFORMANCE_SMCU1_2_HOST },
		{ PERFORMANCE_VDMCU1_2_HOST },
		{ PERFORMANCE_VDMCU2_2_HOST },
		{ PERFORMANCE_VEMCU0_2_HOST },
		{ PERFORMANCE_VEMCU1_2_HOST },
		{ PERFORMANCE_VEMCU2_2_HOST },
		{ PERFORMANCE_VEMCU3_2_HOST },
		{ PERFORMANCE_VDSP0_2_HOST },
		{ PERFORMANCE_VDSP1_2_HOST },
		{ PERFORMANCE_VDSP2_2_HOST },
		{ PERFORMANCE_VDSP3_2_HOST },
		{ PERFORMANCE_DMA_HOST_2_DEV },
		{ PERFORMANCE_DMA_DEV_2_HOST },
		{ PERFORMANCE_DMA_RC_IN },
		{ PERFORMANCE_DMA_RC_OUT },
	};

	u32 static_buf_cnt =
		sizeof(ring_buf_statics) / sizeof(ring_buf_statics[0]);
	u32 static_buf_len = static_buf_cnt * sizeof(T_VASTAI_FIFO_HEADER);
	u8 *static_buf = NULL;
	if (pkdata->output_buf.buf_size < static_buf_len) {
		ret = -EFAULT;
		VATOOLS_INFO(priv, die_index,
			     "output buffer size < %d ret=%ld\n",
			     static_buf_len, ret);
		goto out;
	}
	static_buf = (u8 *)kvmalloc(static_buf_len, GFP_KERNEL);
	if (NULL == static_buf) {
		VATOOLS_ERR(priv, die_index,
			    "PCIE_CMD_FLAG_HOST_COUNT kvmalloc. size=%d\n",
			    static_buf_len);
		ret = -ENOMEM;
		goto out;
	}

	for (i = 0; i < static_buf_cnt; i++) {
		ret = vatools_pci_mem_read(
			priv, pkdata->device.die_index,
			ring_buf_statics[i].base_addr,
			(void *)(static_buf + i * sizeof(T_VASTAI_FIFO_HEADER)),
			sizeof(T_VASTAI_FIFO_HEADER));
		if (ret < 0) {
			VATOOLS_INFO(
				priv, die_index,
				"Ring buf read memory base addr %x error\n",
				ring_buf_statics[i].base_addr);
			ret = -EFAULT;
			goto out_free_static_buf;
		}
	}

	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr +
				      sizeof(TS_SMI_CMD_REQ),
			      static_buf, static_buf_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_static_buf;
	}

out_free_static_buf:
	kvfree(static_buf);
out:
	return ret;
}

#define CMD_BUF_NAME_LONG 16
static long
vatools_pcie_ioctl_ring_buf_from_hw_cfg(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret = -EINVAL;

	u32 i = 0;
	u32 static_buf_cnt = 0;
	u8 *static_buf = NULL;
	u32 static_buf_len = 0;

	static_buf_cnt = sizeof(ring_buf_statics_table) /
			 sizeof(ring_buf_statics_table[0]);

	/*gpu ring buf*/
	static_buf_len = static_buf_cnt * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME);
	if (pkdata->output_buf.buf_size < static_buf_len) {
		ret = -EFAULT;
		VATOOLS_DBG(priv, pkdata->device.die_index,
			    "output buffer size < %d ret=%ld\n", static_buf_len,
			    ret);
		goto out;
	}
	static_buf = (u8 *)kvmalloc(static_buf_len, GFP_KERNEL);
	if (NULL == static_buf) {
		VATOOLS_DBG(priv, pkdata->device.die_index,
			    "PCIE_CMD_FLAG_HOST_COUNT kvmalloc. size=%d\n",
			    static_buf_len);
		ret = -ENOMEM;
		goto out;
	}
	memset(static_buf, 0x0, static_buf_len);

	for (i = 0; i < static_buf_cnt; i++) {
		ret = vatools_pci_mem_read(
			priv, pkdata->device.die_index,
			ring_buf_statics_table[i].base_addr,
			(void *)(static_buf +
				 i * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME)),
			sizeof(T_VASTAI_FIFO_HEADER));
		if (ret < 0) {
			VATOOLS_ERR(
				priv, pkdata->device.die_index,
				"Ring buf read memory base addr 0x%x error\n",
				ring_buf_statics_table[i].base_addr);
			ret = -EFAULT;
			goto out_free_static_buf;
		}
		memcpy(static_buf + i * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME) +
			       sizeof(T_VASTAI_FIFO_HEADER),
		       ring_buf_statics_table[i].name, CMD_BUF_NAME_LONG);
		VATOOLS_DBG(
			priv, pkdata->device.die_index,
			"Name: %s, total buf count %d, now loop %d times,\n",
			ring_buf_statics_table[i].name, static_buf_cnt, i);
	}

	pkdata->address = static_buf_cnt;

	ret = copy_to_user_ex((void __user *)(u8 *)pkdata->output_buf.buf_addr,
			      static_buf, static_buf_len);
	if (ret) {
		VATOOLS_ERR(priv, pkdata->device.die_index,
			    "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_static_buf;
	}

out_free_static_buf:
	kvfree(static_buf);
out:
	return ret;
}

#ifdef CONFIG_VASTAI_VIDEO

static long
vatools_pcie_ioctl_set_video_multi_core(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret = -EINVAL;
	u32 work_mode = (pkdata->address & 0xFFFFFFFF);
	/*call video callback function here*/
	VATOOLS_DBG(priv, die_index,
		    "die inex=0x%x set video multicore work_mode to %d\n",
		    pkdata->device.die_index, work_mode);
	ret = hantroenc_set_work_mode(pkdata->device.die_index,
				      (encoder_workmode_t)work_mode, 0);
	dec_work_mode_change(pkdata->device.die_index,
			     (decoder_workmode_t)work_mode);
	return ret;
}

static long
vatools_pcie_ioctl_get_video_multi_core(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	u32 work_mode = 0;
	int job_count = 0;
	/*call video callback function here*/
	ret = hantroenc_get_work_mode(pkdata->device.die_index,
				      (encoder_workmode_t *)&work_mode,
				      &job_count);
	pkdata->address = work_mode;
	pkdata->address = pkdata->address << 32 | job_count;

	VATOOLS_DBG(
		priv, die_index,
		"die inex=0x%x get video multicore work_mode=%d, job_count=%d\n",
		pkdata->device.die_index, work_mode, job_count);
	return ret;
}
#endif

static long vatools_pcie_ioctl_heart_beat(T_SMI_IOCTL_TRANS_DATA *pkdata,
					  struct vastai_pci_info *priv,
					  int die_index)
{
	long ret;
	core_heartbeat_t core_heartbeat;
	memset(&core_heartbeat, 0, sizeof(core_heartbeat_t));

	ret = vastai_pci_mem_read(priv, die_index, CORE_HEARTBEAT_ADDR,
				  &core_heartbeat, CORE_HEARTBEAT_LEN);
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "heart_beat ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index, "die inex=0x%x read heartbeat ret=%ld\n",
		    pkdata->device.die_index, ret);

	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      &core_heartbeat, CORE_HEARTBEAT_LEN);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
	}
	goto out;
out:
	return ret;
}

static long vatools_pcie_ioctl_barreset(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	u32 bar_readdata = 0;

	ret = vatools_pci_mem_read(priv, die_index, DDR_PCIE_BARRESET,
				   &bar_readdata, sizeof(u32));
	if (ret < 0) {
		ret = -EFAULT;
		goto out;
	}
	VATOOLS_DBG(priv, die_index, "bar_readdata: ret=0x%x\n", bar_readdata);

	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr +
				      sizeof(TS_SMI_CMD_REQ),
			      &bar_readdata, sizeof(u32));
	if (ret < 0) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
out:
	return ret;
}

static long vatools_pcie_ioctl_barstatus(T_SMI_IOCTL_TRANS_DATA *pkdata,
					 struct vastai_pci_info *priv,
					 int die_index)
{
	long ret;
	int i = 0;

	vatools_bar_info_sv100_t at_addr_array[VASTAI_PCI_BAR_NUM];
	memset(at_addr_array, 0x0,
	       sizeof(vatools_bar_info_sv100_t) * VASTAI_PCI_BAR_NUM);
	i = 0;
	for (; i < VASTAI_PCI_BAR_NUM; i++) {
		VATOOLS_DBG(priv, die_index, "bar_addr:%lx\n",
			    priv->bar[i].at_addr);
		at_addr_array[i].mmio_start = (u64)priv->bar[i].mmio_start;
		at_addr_array[i].mmio_end = (u64)priv->bar[i].mmio_end;
		at_addr_array[i].mmio_len = (u64)priv->bar[i].mmio_len;
		at_addr_array[i].at_addr = (u64)priv->bar[i].at_addr;
		at_addr_array[i].map_in_addr = (u64)priv->bar[i].map_in_addr;
		at_addr_array[i].map_out_addr = (u64)priv->bar[i].map_out_addr;
		at_addr_array[i].mem = (u64)priv->bar[i].mem;
		at_addr_array[i].mmio_flags = (u64)priv->bar[i].mmio_flags;
		at_addr_array[i].vmem = (u64)priv->bar[i].vmem;
		at_addr_array[i].minish_bar_size =
			(u64)priv->bar[i].minish_bar_size;
	}
	ret = copy_to_user_ex(
		(void __user *)pkdata->output_buf.buf_addr, at_addr_array,
		sizeof(vatools_bar_info_sv100_t) * (VASTAI_PCI_BAR_NUM - 1));
	if (ret < 0) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
out:
	return ret;
}

static long vatools_pcie_ioctl_reboot_ddrbw(T_SMI_IOCTL_TRANS_DATA *pkdata,
					    struct vastai_pci_info *priv,
					    int die_index)
{
	long ret = -EINVAL;
	int die_id = 0;
	unsigned long dma_bus_addr = 0;
	u32 pcie_bw_test_len = 4 * 1024 * 1024;
	priv->ddr_bw_test = 1;

	VATOOLS_DBG(priv, die_index, "reboot_ddrbw die_index=0x%x\n",
		    die_index);

	atomic_set(&(priv->pci_state), VASTAI_DEBUG_STATE);
	for (die_id = priv->die_num_in_fn - 1; die_id >= 0; die_id--) {
		if (iommu_is_enable(priv)) {
			if (!priv->dies[die_id].vatool_dm_sg) {
				priv->dies[die_id].vatool_dm_sg =
					vastai_dma_buf_sg_get(priv,
							      pcie_bw_test_len);
				dma_bus_addr =
					priv->dies[die_id]
						.vatool_dm_sg->dma_bus_addr;
			}

		} else {
			if (!priv->dies[die_id].vatool_dm.vir) {
				vastai_udma_malloc(
					priv, &(priv->dies[die_id].vatool_dm),
					pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id]
						       .vatool_dm.dma_bus_addr;
			}
		}

		if (!dma_bus_addr) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"malloc dma buf failed");
			return -1;
		}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_lock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		ret = vastai_send_pcie_cmd(
			priv, vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_SEND_DMA_ADDR, dma_bus_addr);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_unlock(
				priv, die_index,
				VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_unlock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		if (ret) {
			VATOOLS_INFO(priv, DUMMY_DIE_ID,
				     "%s [send_dma_addr] , error:%ld\n",
				     __func__, ret);
			break;
		}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_lock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		ret = vastai_send_pcie_cmd(
			priv, vastai_pci_get_die_index(priv, die_id),
			VASTAI_PCIE_SUB_SET_DDR_BW_TEST, 0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_unlock(
				priv, die_index,
				VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_unlock(
				priv, vastai_pci_get_die_index(priv, die_id),
				VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		if (ret) {
			VATOOLS_INFO(priv, DUMMY_DIE_ID,
				     "%s [ddr_bw] , error:%ld\n", __func__,
				     ret);
			break;
		}
	}
	VATOOLS_INFO(priv, DUMMY_DIE_ID, "set_ddr_bandwidth_test\n");

	return ret;
}

static long vatools_pcie_ioctl_reboot_pciedma(T_SMI_IOCTL_TRANS_DATA *pkdata,
					      struct vastai_pci_info *priv,
					      int die_index)
{
	long ret = -EINVAL;
	unsigned long dma_bus_addr = 0;
	int die_id = 0;
	u32 pcie_bw_test_len = 4 * 1024 * 1024;
	unsigned long channel_switch = 0;
	u32 dies_num = 1;

	VATOOLS_DBG(priv, die_index, "reboot_pciedma die_index=0x%x\n",
		    die_index);

	if (priv->dies[VASTAI_DIE1].pcie_nlw[1] > 4) {
		channel_switch = 1;
	}

	if (vastai_pci_compare_pcie_link_in_dies(priv)) {
		dies_num = priv->die_num_in_fn;
	}
	priv->ddr_bw_test = 1;
	atomic_set(&(priv->pci_state), VASTAI_DEBUG_STATE);
	for (die_id = 0; die_id < dies_num; die_id++) {
		u32 die_index_real = vastai_pci_get_die_index(priv, die_id);
		if (iommu_is_enable(priv)) {
			if (!priv->dies[die_id].vatool_dm_sg) {
				priv->dies[die_id].vatool_dm_sg =
					vastai_dma_buf_sg_get(priv,
							      pcie_bw_test_len);
				dma_bus_addr =
					priv->dies[die_id]
						.vatool_dm_sg->dma_bus_addr;
			}

		} else {
			if (!priv->dies[die_id].vatool_dm.vir) {
				vastai_udma_malloc(
					priv, &(priv->dies[die_id].vatool_dm),
					pcie_bw_test_len);
				dma_bus_addr = priv->dies[die_id]
						       .vatool_dm.dma_bus_addr;
			}
		}

		if (!dma_bus_addr) {
			VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
					"malloc dma buf failed");
			return -1;
		}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_lock(priv, die_index,
					  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_lock(priv, die_index_real,
					  VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		ret = vastai_send_pcie_cmd(priv, die_index_real,
					   VASTAI_PCIE_SUB_SEND_DMA_ADDR,
					   dma_bus_addr);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		if (priv == NULL)
			domain_mutex_unlock(
				priv, die_index,
				VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
		else
			domain_mutex_unlock(priv, die_index_real,
					    VATOOLS_IOCTL_DOMAIN_DIE);
#endif

		if (ret) {
			VATOOLS_INFO(priv, die_index_real,
				     "%s [send_dma_addr] , error:%ld\n",
				     __func__, ret);
			break;
		}

		if (channel_switch && (die_id == 1)) {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			if (priv == NULL)
				domain_mutex_lock(
					priv, die_index,
					VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
			else
				domain_mutex_lock(priv, die_index_real,
						  VATOOLS_IOCTL_DOMAIN_DIE);
#endif
			ret = vastai_send_pcie_cmd(
				priv, die_index_real,
				VASTAI_PCIE_SUB_SET_PCIE_BW_TEST,
				channel_switch);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			if (priv == NULL)
				domain_mutex_unlock(
					priv, die_index,
					VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
			else
				domain_mutex_unlock(priv, die_index_real,
						    VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		} else {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			if (priv == NULL)
				domain_mutex_lock(
					priv, die_index,
					VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
			else
				domain_mutex_lock(priv, die_index_real,
						  VATOOLS_IOCTL_DOMAIN_DIE);
#endif
			ret = vastai_send_pcie_cmd(
				priv, die_index_real,
				VASTAI_PCIE_SUB_SET_PCIE_BW_TEST, 0);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			if (priv == NULL)
				domain_mutex_unlock(
					priv, die_index,
					VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
			else
				domain_mutex_unlock(priv, die_index_real,
						    VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		}

		if (ret) {
			VATOOLS_INFO(priv, die_index_real,
				     "%s [pcie_bw] , error:%ld\n", __func__,
				     ret);
			break;
		}
		VATOOLS_INFO(
			priv, die_index_real,
			"set_pcie_bandwidth_test,die_id[%d],dma_bus_addr=0x%lx\n",
			die_id, dma_bus_addr);
	}
	return ret;
}

static int tools_vaccrt_die_info_get_head(struct vastai_cdev *vacc_dev, void *buffer)
{
	vacc_info_head_t *vacc_info_head = (vacc_info_head_t *)buffer;
	if (vacc_dev == NULL || buffer == NULL)
		return -1;
	vacc_info_head->ai_version = vacc_dev->ai_version;
	vacc_info_head->zone_count = vacc_dev->soc.zone_num;
	vacc_info_head->process_count =
		atomic_read(&vacc_dev->dev_trans_ai->dev_process_num);
	return 0;
}

static int tools_vaccrt_die_info_get_zone_ddr(struct vastai_cdev *vacc_dev,
					      void *buffer)
{
	int i = 0;
	vacc_zone_usage_t *vacc_zone_usage = (vacc_zone_usage_t *)buffer;
	if (vacc_dev == NULL || buffer == NULL)
		return -1;
	for (i = 0; i < TOOLS_ZONE_COUNT; i++) {
		vacc_zone_usage[i].total_size =
			vacc_dev->device_ddr_alloc[i]
				.shmre_alloc_head.total_size;
		vacc_zone_usage[i].free_size =
			vacc_dev->device_ddr_alloc[i].shmre_alloc_head.free_size;
	}
	return 0;
}

static long vatools_pcie_ioctl_runtime_info(T_SMI_IOCTL_TRANS_DATA *pkdata,
					    struct vastai_pci_info *priv,
					    u32 die_index)
{
	long ret = -EINVAL;
#ifdef CONFIG_VASTAI_AI
	u32 k = 0;
	int j = 0;
	vatools_runtime_info_head_t *info_head_p = NULL;
	vatools_runtime_info_head_t *info_head_one_p = NULL;
	vacc_info_head_t info_head;

	vatools_runtime_zone_usage_t *zone_usage_p = NULL;
	vatools_runtime_zone_usage_t *zone_usage_one_p = NULL;
	vacc_zone_usage_t zone_usage[TOOLS_ZONE_COUNT];
	vatools_runtime_process_info_t *process_info_p = NULL;
	vatools_runtime_process_info_t *process_info_one_p = NULL;
	vacc_process_info_t *vacc_process_info_p = NULL;
	int vacc_process_info_count = 0;

	vastai_runtime_statistic_t runtime_statistic;
	struct vastai_cdev *vacc_dev_p = NULL;
	struct vastai_cdev *vacc_dev_temp = NULL;

	union die_index_data did;
	struct vastai_pci_info *pci_info = NULL;
	u32 device_num = 0;
#endif

	struct vatools_node *node = vatools_get_node();
	VATOOLS_FUNC_ENTERY;

	mutex_lock(&node->rt_buf_mutex);
	if (node->rt_info_head_buf == NULL) {
		VATOOLS_DBG(priv, die_index, "rt_info_head_buf freed\n");
		ret = -EFAULT;
		goto out;
	}
#ifdef CONFIG_VASTAI_AI

	VATOOLS_DBG(priv, die_index, "die_index=0x%x\n", die_index);

	memset(&runtime_statistic, 0, sizeof(vastai_runtime_statistic_t));

	ret = copy_from_user_ex(&runtime_statistic,
				(const void __user *)pkdata->input_buf.buf_addr,
				sizeof(vastai_runtime_statistic_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	/*Gets information about the current process*/
	ret = vatools_get_current_process_info(
		&runtime_statistic.current_process_info);
	if (ret < 0) {
		VATOOLS_DBG(priv, die_index,
			    "get current process failed. ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
	runtime_statistic.current_process_info.die_index = die_index;

	/*Get the number of devices*/
	device_num = vatools_get_vastai_pci_device_number();
	VATOOLS_DBG(
		priv, die_index,
		"die_index=0x%x device_num=%d runtime_statistic.info_head_max_num=%d zone_usage_max_num=%d process_info_max_num=%d\n",
		die_index, device_num, runtime_statistic.info_head_max_num,
		runtime_statistic.zone_usage_max_num,
		runtime_statistic.process_info_max_num);

	if (device_num == 0) {
		ret = -ENODEV;
		VATOOLS_DBG(priv, die_index, "device_num is 0. ret=%ld\n", ret);
		goto out;
	}

	/*TODO: Get info_head Iterate through all cards and dies, one structure for each die*/
	k = 0;
	if (runtime_statistic.info_head_max_num) {
		VATOOLS_DBG(priv, die_index, "info_head_max_num=%d\n",
			    runtime_statistic.info_head_max_num);
		/*Each die has a structure*/
		info_head_p =
			(vatools_runtime_info_head_t *)node->rt_info_head_buf;
		if (info_head_p == NULL) {
			VATOOLS_ERR(
				priv, die_index, "vmalloc error. size=%ld\n",
				runtime_statistic.info_head_max_num *
					sizeof(vatools_runtime_info_head_t));
			ret = -ENOMEM;
			goto out;
		}
		memset(info_head_p, 0, RT_INFO_HEAD_BUF_SIZE);

		down_read(&tools_devs_rw_sem);
		/*Iterate through all devices*/
		list_for_each_entry (pci_info, &vastai_tools_devs_list,
				     tools_dev_list) {
			if (pci_info == NULL) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "pci_info is NULL\n");
				continue;
			}
			if (vatools_check_pci_state(pci_info,
						    VASTAI_NORMAL_STATE, -1)) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "priv->pci_state=0x%x\n",
					    atomic_read(&pci_info->pci_state));
				continue;
			}

			/*vacc*/
			list_for_each_entry_safe (vacc_dev_p, vacc_dev_temp,
						  &pci_info->vacc_dev_head,
						  vacc_dev_node) {
				VATOOLS_DBG(pci_info, die_index,
					    "vacc_dev_p=%p\n", vacc_dev_p);

				if (((u32)die_index == 0xffffffff) ||
				    (vacc_dev_p->die_index == die_index)) {
					VATOOLS_DBG(
						pci_info, die_index,
						"get info_head from vacc_dev_p=%p\n",
						vacc_dev_p);
					info_head_one_p =
						(vatools_runtime_info_head_t
							 *)(info_head_p + k);
					memset(&info_head, 0,
					       sizeof(vacc_info_head_t));
					ret = tools_vaccrt_die_info_get_head(
						vacc_dev_p, &info_head);
					if (ret < 0) {
						VATOOLS_DBG(
							pci_info, die_index,
							"tools_vaccrt_die_info_get_head failed. ret=%ld\n",
							ret);
					} else {
						info_head_one_p->die_index =
							vacc_dev_p->die_index;
						did.val = info_head_one_p
								  ->die_index;
						info_head_one_p->die_id =
							did.seq_num;
						info_head_one_p->ai_version =
							info_head.ai_version;
						info_head_one_p->zone_count =
							info_head.zone_count;
						info_head_one_p->process_count =
							info_head.process_count;

						vaccrt_version_number2string(
							info_head_one_p
								->ai_version,
							info_head_one_p
								->ai_version_str);
						k++;
						runtime_statistic.info_head_num =
							k;
						VATOOLS_DBG(
							pci_info, die_index,
							"runtime_statistic.info_head_num=%d ai_version=0x%x zone_count=%d process_count=%d info_head_num=%d\n",
							runtime_statistic
								.info_head_num,
							info_head_one_p
								->ai_version,
							info_head_one_p
								->zone_count,
							info_head_one_p
								->process_count,
							runtime_statistic
								.info_head_num);

						if (runtime_statistic
							    .info_head_num ==
						    runtime_statistic
							    .info_head_max_num) {
							VATOOLS_DBG(
								pci_info,
								die_index,
								"runtime_statistic.info_head_num=%d reach max. exit loop.\n",
								runtime_statistic
									.info_head_num);
							goto out_info_head_max;
						}
					}
				} /*if die_index*/
			} /*list loop*/
		} /*for (dev*/
	out_info_head_max:
		up_read(&tools_devs_rw_sem);
		ret = copy_to_user_ex(
			(void __user *)runtime_statistic.info_head_p,
			info_head_p,
			runtime_statistic.info_head_num *
				sizeof(vatools_runtime_info_head_t));
		if (ret) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex info_head ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_info_head;
		}

		ret = copy_to_user_ex((void __user *)pkdata->input_buf.buf_addr,
				      &runtime_statistic,
				      sizeof(vastai_runtime_statistic_t));
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_to_user_ex runtime_statistic ret=%ld\n",
				ret);
			ret = -EFAULT;
			goto out_info_head;
		}
	out_info_head:
		asm volatile("nop");
		//vfree(info_head_p);
	} /*end of info_head*/

	/*TODO: Get zone_usage iterate through all cards and dies, one structure for each die*/
	k = 0;
	if (runtime_statistic.zone_usage_max_num) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "zone_usage_max_num=%d\n",
			    runtime_statistic.zone_usage_max_num);
		/*Each die has a structure*/
		zone_usage_p =
			(vatools_runtime_zone_usage_t *)node->rt_zone_usage_buf;
		if (zone_usage_p == NULL) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID, "vmalloc error. size=%ld\n",
				runtime_statistic.zone_usage_max_num *
					sizeof(vatools_runtime_zone_usage_t));
			ret = -ENOMEM;
			goto out;
		}
		memset(zone_usage_p, 0, RT_ZONE_USAGE_BUF_SIZE);

		down_read(&tools_devs_rw_sem);
		/*Iterate through all devices*/
		list_for_each_entry (pci_info, &vastai_tools_devs_list,
				     tools_dev_list) {
			if (pci_info == NULL) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "pci_info is NULL\n");
				continue;
			}
			if (vatools_check_pci_state(pci_info,
						    VASTAI_NORMAL_STATE, -1)) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "priv->pci_state=0x%x\n",
					    atomic_read(&pci_info->pci_state));
				continue;
			}

			/*vacc*/
			list_for_each_entry_safe (vacc_dev_p, vacc_dev_temp,
						  &pci_info->vacc_dev_head,
						  vacc_dev_node) {
				VATOOLS_DBG(pci_info, die_index,
					    "vacc_dev_p=%p\n", vacc_dev_p);

				if (((u32)die_index == 0xffffffff) ||
				    (vacc_dev_p->die_index == die_index)) {
					VATOOLS_DBG(
						pci_info, die_index,
						"get zone_usage from vacc_dev_p=%p\n",
						vacc_dev_p);
					zone_usage_one_p =
						(vatools_runtime_zone_usage_t
							 *)(zone_usage_p + k);
					memset(zone_usage, 0,
					       sizeof(vacc_zone_usage_t) *
						       TOOLS_ZONE_COUNT);
					ret = tools_vaccrt_die_info_get_zone_ddr(
						vacc_dev_p, zone_usage);
					if (ret < 0) {
						VATOOLS_DBG(
							pci_info, die_index,
							"tools_vaccrt_die_info_get_zone_ddr failed. ret=%ld\n",
							ret);
					} else {
						zone_usage_one_p->die_index =
							vacc_dev_p->die_index;
						memcpy(zone_usage_one_p
							       ->zone_usage,
						       zone_usage,
						       sizeof(vacc_zone_usage_t) *
							       TOOLS_ZONE_COUNT);

						zone_usage_one_p
							->ddr_total_size =
							vacc_dev_p->soc
								.ddr_total_size;
						k++;
						runtime_statistic
							.zone_usage_num = k;
						VATOOLS_DBG(
							pci_info, die_index,
							"runtime_statistic.zone_usage_num=%d total_size=%lld free_size=%lld zone_usage_num=%d\n",
							runtime_statistic
								.zone_usage_num,
							zone_usage_one_p
								->zone_usage[0]
								.total_size,
							zone_usage_one_p
								->zone_usage[0]
								.free_size,
							runtime_statistic
								.zone_usage_num);

						if (runtime_statistic
							    .zone_usage_num ==
						    runtime_statistic
							    .zone_usage_max_num) {
							VATOOLS_DBG(
								pci_info,
								die_index,
								"runtime_statistic.zone_usage_num=%d reach max. exit loop.\n",
								runtime_statistic
									.zone_usage_num);
							goto out_zone_usage_max;
						}
					}
				} /*if die_index*/
			} /*list loop*/
		} /*for (dev*/
	out_zone_usage_max:
		up_read(&tools_devs_rw_sem);
		ret = copy_to_user_ex(
			(void __user *)runtime_statistic.zone_usage_p,
			zone_usage_p,
			runtime_statistic.zone_usage_num *
				sizeof(vatools_runtime_zone_usage_t));
		if (ret) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex zone_usage ret=%ld\n",
				    ret);
			ret = -EFAULT;
			goto out_zone_usage;
		}

		ret = copy_to_user_ex((void __user *)pkdata->input_buf.buf_addr,
				      &runtime_statistic,
				      sizeof(vastai_runtime_statistic_t));
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_to_user_ex runtime_statistic ret=%ld\n",
				ret);
			ret = -EFAULT;
			goto out_zone_usage;
		}
	out_zone_usage:
		asm volatile("nop");
		//vfree(zone_usage_p);
	} /*end of zone_usage*/

	/*TODO: Get process_info Iterate through all cards and dies, one structure for each die*/
	k = 0;
	if (runtime_statistic.process_info_max_num) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "process_info_max_num=%d\n",
			    runtime_statistic.process_info_max_num);
		/*One structure per process*/
		/*Data buf returned to the app*/
		process_info_p = (vatools_runtime_process_info_t *)
					 node->rt_process_info_buf;
		if (process_info_p == NULL) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"vmalloc error process_info_p. size=%ld\n",
				runtime_statistic.process_info_max_num *
					sizeof(vatools_runtime_process_info_t));
			ret = -ENOMEM;
			goto out;
		}
		/*The buf provided to the vaccrt interface to return data*/
		vacc_process_info_p =
			(vacc_process_info_t *)node->rt_vacc_process_info_buf;
		if (vacc_process_info_p == NULL) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"vmalloc error vacc_process_info_p. size=%ld\n",
				runtime_statistic.process_info_max_num *
					sizeof(vacc_process_info_t));
			ret = -ENOMEM;
			goto out_process_info;
		}

		memset(process_info_p, 0, RT_PROCESS_INFO_BUF_SIZE);

		memset(vacc_process_info_p, 0, RT_VACC_PROCESS_INFO_BUF_SIZE);

		down_read(&tools_devs_rw_sem);
		/*Iterate through all devices*/
		list_for_each_entry (pci_info, &vastai_tools_devs_list,
				     tools_dev_list) {
			if (pci_info == NULL) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "pci_info is NULL\n");
				continue;
			}
			if (vatools_check_pci_state(pci_info,
						    VASTAI_NORMAL_STATE, -1)) {
				VATOOLS_DBG(NULL, DUMMY_DIE_ID,
					    "priv->pci_state=0x%x\n",
					    atomic_read(&pci_info->pci_state));
				continue;
			}

			/*vacc*/
			list_for_each_entry_safe (vacc_dev_p, vacc_dev_temp,
						  &pci_info->vacc_dev_head,
						  vacc_dev_node) {
				VATOOLS_DBG(pci_info, die_index,
					    "vacc_dev_p=%p\n", vacc_dev_p);

				if (((u32)die_index == 0xffffffff) ||
				    (vacc_dev_p->die_index == die_index)) {
					VATOOLS_DBG(
						pci_info, die_index,
						"get process_info from vacc_dev_p=%p\n",
						vacc_dev_p);

					ret = vaccrt_die_info_get_process(
						vacc_dev_p, vacc_process_info_p,
						runtime_statistic
							.process_info_max_num,
						&vacc_process_info_count);

					VATOOLS_DBG(
						pci_info, die_index,
						"get process_info vacc_process_info_count=%d ret=%ld\n",
						vacc_process_info_count, ret);

					if (ret < 0) {
						VATOOLS_DBG(
							pci_info, die_index,
							"vaccrt_die_info_get_process failed. ret=%ld\n",
							ret);
					} else {
						for (j = 0;
						     j <
						     vacc_process_info_count;
						     j++) {
							process_info_one_p =
								(vatools_runtime_process_info_t
									 *)(process_info_p +
									    k);

							process_info_one_p
								->die_index =
								vacc_dev_p
									->die_index;

							VATOOLS_DBG(
								pci_info,
								die_index,
								"process_info=%u pid=%u vpid=%u level=%u ns=%llu zone=%llu %llu %llu %llu %llu\n",
								j,
								(vacc_process_info_p +
								 j)
									->pid,
								(vacc_process_info_p +
								 j)
									->vpid,
								(vacc_process_info_p +
								 j)
									->level,
								(vacc_process_info_p +
								 j)
									->ns,
								(vacc_process_info_p +
								 j)
									->zone_used
										[0],
								(vacc_process_info_p +
								 j)
									->zone_used
										[1],
								(vacc_process_info_p +
								 j)
									->zone_used
										[2],
								(vacc_process_info_p +
								 j)
									->zone_used
										[3],
								(vacc_process_info_p +
								 j)
									->zone_used
										[4]);

							memcpy((void *)((u8 *)process_info_one_p +
									sizeof(u32)),
							       (void *)(vacc_process_info_p +
									j),
							       sizeof(vacc_process_info_t));

							k++;
							runtime_statistic
								.process_info_num =
								k;
							VATOOLS_DBG(
								pci_info,
								die_index,
								"runtime_statistic.process_info_num=%d die_index=0x%x pid=%u vpid=%u level=%u ns=%llu zone=%llu %llu %llu %llu %llu\n",
								runtime_statistic
									.process_info_num,
								process_info_one_p
									->die_index,
								process_info_one_p
									->pid,
								process_info_one_p
									->vpid,
								process_info_one_p
									->level,
								process_info_one_p
									->ns,
								process_info_one_p
									->zone_used
										[0],
								process_info_one_p
									->zone_used
										[1],
								process_info_one_p
									->zone_used
										[2],
								process_info_one_p
									->zone_used
										[3],
								process_info_one_p
									->zone_used
										[4]);

							if (runtime_statistic
								    .process_info_num ==
							    runtime_statistic
								    .process_info_max_num) {
								VATOOLS_DBG(
									pci_info,
									die_index,
									"runtime_statistic.process_info_num=%d reach max. exit loop.\n",
									runtime_statistic
										.process_info_num);
								goto out_process_info_max;
							}
						} /*for process*/
					} /*vaccrt_die_info_get_process success*/
				} /*if die_index*/
			} /*list loop*/
		} /*for (dev*/
	out_process_info_max:
		up_read(&tools_devs_rw_sem);
		ret = copy_to_user_ex(
			(void __user *)runtime_statistic.process_info_p,
			process_info_p,
			runtime_statistic.process_info_num *
				sizeof(vatools_runtime_process_info_t));
		if (ret) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex process_info ret=%ld\n",
				    ret);
			ret = -EFAULT;
			goto out_process_info;
		}

		ret = copy_to_user_ex((void __user *)pkdata->input_buf.buf_addr,
				      &runtime_statistic,
				      sizeof(vastai_runtime_statistic_t));
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_to_user_ex runtime_statistic ret=%ld\n",
				ret);
			ret = -EFAULT;
			goto out_process_info;
		}
	out_process_info:
		if (process_info_p) {
			//vfree(process_info_p);
			//process_info_p = NULL;
		}
		if (vacc_process_info_p) {
			//vfree(vacc_process_info_p);
			//vacc_process_info_p = NULL;
		}
	} /*end of process_info*/

#endif
out:
	VATOOLS_FUNC_EXIT;
	mutex_unlock(&node->rt_buf_mutex);
	return ret;
}

static long
vatools_pcie_ioctl_current_process_info(T_SMI_IOCTL_TRANS_DATA *pkdata,
					struct vastai_pci_info *priv,
					int die_index)
{
	long ret;
	vatools_current_process_info_t current_process_info;

	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(priv, die_index, "die_index=0x%x\n", die_index);

	memset(&current_process_info, 0,
	       sizeof(vatools_current_process_info_t));
	/*Gets information about the current process*/
	ret = vatools_get_current_process_info(&current_process_info);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "get current process failed. ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
	current_process_info.die_index = die_index;
	ret = copy_to_user_ex((void __user *)pkdata->input_buf.buf_addr,
			      &current_process_info,
			      sizeof(vatools_current_process_info_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

static long vatools_pcie_ioctl_heartbeat_count(T_SMI_IOCTL_TRANS_DATA *pkdata,
					       struct vastai_pci_info *priv,
					       int die_index)
{
	long ret;
	u32 die_id = 0;
	union die_index_data did;
	vatools_heartbeat_count_t *heartbeat_count_p = NULL;
	int i = 0;
	int interval_seconds = 3;

	VATOOLS_FUNC_ENTERY;
	did.val = die_index;
	die_id = did.die_id;
	VATOOLS_DBG(priv, die_index, "die_index=0x%x die_id=%d\n", die_index,
		    die_id);

	heartbeat_count_p = (vatools_heartbeat_count_t *)vmalloc(
		sizeof(vatools_heartbeat_count_t));
	if (heartbeat_count_p == NULL) {
		VATOOLS_ERR(priv, die_index,
			    "heartbeat_count_p vmalloc error. size=%ld\n",

			    sizeof(vatools_heartbeat_count_t));
		ret = -ENOMEM;
		goto out;
	}

	memset(heartbeat_count_p, 0, sizeof(vatools_heartbeat_count_t));

	for (i = 0; i < HEARTBEAT_MAX_CNT; i++) {
		ret = vastai_read_heartbeat(
			priv, die_id, i * interval_seconds,
			&(heartbeat_count_p->heartbeat_counts[i][0]));
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "get heartbeat failed. ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_free;
		}
	}

	heartbeat_count_p->die_index = die_index;
	ret = copy_to_user_ex((void __user *)pkdata->input_buf.buf_addr,
			      heartbeat_count_p,
			      sizeof(vatools_heartbeat_count_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free;
	}
out_free:
	vfree(heartbeat_count_p);
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

/*Get real-time DDR bandwidth*/
static u64 vatools_ddr_monitor(struct vastai_pci_info *priv, int die_index,
			       u32 mc, u32 port, u32 read_or_write)
{
	u64 ddrbandwidth = 0;
	u32 val = 0;
	int ret = 0;
	int ddr_bw_index = 2;
	u64 mc_addr[MAX_MC_NUM] = { csr_mc0_axi_w_r_ostd, csr_mc1_axi_w_r_ostd,
				    csr_mc2_axi_w_r_ostd,
				    csr_mc3_axi_w_r_ostd };
	u64 addr = mc_addr[mc] + 5 * sizeof(u32);
	T_PERFMON_MC_FW mc_buffer;
	memset(&mc_buffer, 0x00, sizeof(T_PERFMON_MC_FW));
	if (vastai_get_board_type(priv) == SV100) {
		T_ENABLE_CLR_MODE_FW tEnableClr;
		T_REPORT_MODE_FW tReportMode;
		tReportMode.n_whole = 0;
		tEnableClr.n_whole = 0;
		tReportMode.n_bandwith_sel =
			read_or_write; /*set read/write flag*/
		tReportMode.n_port_sel = port & 0x7; /*set port*/
		tEnableClr.n_report_mode = tReportMode.n_whole & 0xFF;
		/*stop*/
		val = tEnableClr.n_whole;
		ret = vatools_fw_smcu_write(SMI_CMD_BLOCK_ID_0, priv, die_index,
					    addr, &val, sizeof(u32));
		if (0 != ret) {
			VATOOLS_DBG(priv, die_index,
				    "1/3. stop mc monitor fail. ret=%d\n", ret);
		}
		/*start*/
		tEnableClr.n_axiyall_enable = 1;
		val = tEnableClr.n_whole;
		ret = vatools_fw_smcu_write(SMI_CMD_BLOCK_ID_0, priv, die_index,
					    addr, &val, sizeof(u32));
		if (0 != ret) {
			VATOOLS_DBG(priv, die_index,
				    "2/3. start mc monitor fail. ret=%d\n",
				    ret);
		}
		/*read*/
		ret = vatools_fw_smcu_read(SMI_CMD_BLOCK_ID_0, priv, die_index,
					   mc_addr[mc], &mc_buffer,
					   sizeof(T_PERFMON_MC_FW));
		if (ret < 0) {
			VATOOLS_DBG(priv, die_index,
				    "3/3. read mc reg fail. ret=%d\n", ret);
		} else {
			ddrbandwidth = mc_buffer.n_val[ddr_bw_index];
		}
		VATOOLS_DBG(priv, die_index,
			    "read/write:%d, mc:%d, port:%d, count:%lld\n",
			    read_or_write, mc, port, ddrbandwidth);
	}
	if (vastai_get_board_type(priv) == SG100) {
	}
	/*Failure returns 0*/
	return ddrbandwidth;
}

static long vatools_pcie_ioctl_ddr_bandwidth(T_SMI_IOCTL_TRANS_DATA *pkdata,
					     struct vastai_pci_info *priv,
					     int die_index)
{
	long ret = -EINVAL;

	V_UNREFERENCE(pkdata);
	V_UNREFERENCE(priv);
	V_UNREFERENCE(die_index);
	VATOOLS_FUNC_ENTERY;
	VATOOLS_FUNC_EXIT;

	return ret;
}

static long
vatools_pcie_ioctl_ddr_bandwidth_monitor(T_SMI_IOCTL_TRANS_DATA *pkdata,
					 struct vastai_pci_info *priv,
					 int die_index)
{
	long ret;
	/*sg100: ddr channel, when 4 ddr use channel 2 6 3 7, 8 ddr use 0~7*/
	/*sv100: ddr channel, 0~3*/
	u32 ch = 0;
	u32 port = 0;
	u32 read = 0; /*1: read 0: write*/
	u32 idx_first = 0;
	u32 idx_second = 1;
	u32 sample_interval_us = 10000; /*default interval is 10ms*/
	vastai_ddr_bandwidth_monitor_t *ddr_bandwidth_p = NULL;
	u64 t_start;
	u64 t_end;
	/*struct vatools_node *node = vatools_get_node();*/

	/*Use address to pass the sampling interval in microseconds, which cannot exceed the u32 maximum.*/
	if (pkdata->address != 0 && (pkdata->address <= 0xFFFFFFFF)) {
		sample_interval_us = pkdata->address;
	}

	ddr_bandwidth_p = (vastai_ddr_bandwidth_monitor_t *)vmalloc(
		sizeof(vastai_ddr_bandwidth_monitor_t));

	if (ddr_bandwidth_p == NULL) {
		VATOOLS_ERR(
			priv, die_index,
			"vmalloc vastai_ddr_bandwidth_monitor_t failed. len=%ld\n",
			sizeof(vastai_ddr_bandwidth_monitor_t));
		ret = -EINVAL;
		goto out;
	}

	memset(ddr_bandwidth_p, 0, sizeof(vastai_ddr_bandwidth_monitor_t));
	/*Ensure that the two samples are not interrupted (a die-level lock is required later)*/
	/*mutex_lock(&node->node_profiler_mutex);*/
	t_start = vastai_get_host_time_ns();
	ddr_bandwidth_p->sample_interval_us = t_start / 1000;
	for (ch = 0; ch < SV100_DDR_MC_PHY_MAX; ch++) {
		for (port = 0; port < SV100_DDR_MC_PHY_PORT_MAX; port++) {
			/*First sampling*/
			/*UPSTREAM read from ddr*/
			ddr_bandwidth_p->mc_count_detail[idx_first]
				.mc_count[ch][port]
				.upstream_count = vatools_ddr_monitor(
				priv, die_index, ch, port, read);
			/*DOWNSTREAM write to ddr*/
			ddr_bandwidth_p->mc_count_detail[idx_first]
				.mc_count[ch][port]
				.downstream_count = vatools_ddr_monitor(
				priv, die_index, ch, port, !read);
		}
	}
	if (sample_interval_us < 0xFFFFFFFF) {
		/*Second sampling*/
		/*wait sample_interval_us*/
		msleep(sample_interval_us / 1000);
		t_end = vastai_get_host_time_ns();
		for (ch = 0; ch < SV100_DDR_MC_PHY_MAX; ch++) {
			for (port = 0; port < SV100_DDR_MC_PHY_PORT_MAX;
			     port++) {
				/*Second sampling*/
				/*UPSTREAM read from ddr*/
				ddr_bandwidth_p->mc_count_detail[idx_second]
					.mc_count[ch][port]
					.upstream_count = vatools_ddr_monitor(
					priv, die_index, ch, port, read);
				/*DOWNSTREAM write to ddr*/
				ddr_bandwidth_p->mc_count_detail[idx_second]
					.mc_count[ch][port]
					.downstream_count = vatools_ddr_monitor(
					priv, die_index, ch, port, !read);
			}
		}

		/*update interval time*/
		ddr_bandwidth_p->sample_interval_us = (t_end - t_start) / 1000;
	}
	/*mutex_unlock(&node->node_profiler_mutex);*/
	/*sample_interval_us == 0xFFFFFFFF does not take a second sample*/
	/*TODO: Calculate the ddr bandwidth of read/write and leave it to the application layer for processing*/
	ret = copy_to_user_ex((void __user *)(u8 *)pkdata->input_buf.buf_addr,
			      ddr_bandwidth_p,
			      sizeof(vastai_ddr_bandwidth_monitor_t));
	if (ret) {
		VATOOLS_ERR(priv, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free;
	}
out_free:
	vfree(ddr_bandwidth_p);
out:
	return ret;
}

static long vatools_pcie_ioctl_card_cpu_topo(T_SMI_IOCTL_TRANS_DATA *pkdata,
					     struct vastai_pci_info *priv,
					     int die_index)
{
#if (TOOLS_WIN == 0)
	long ret;
	char *cpu_card_topo_str =
		(char *)kvmalloc(CPU_AND_CARD_TOPO_STR_LEN, GFP_KERNEL);
	if (cpu_card_topo_str == NULL) {
		VATOOLS_ERR(priv, die_index,
			    "malloc cpu_card_topo_str buffer failed\n");
		return -EINVAL;
	}
	memset(cpu_card_topo_str, 0x0, CPU_AND_CARD_TOPO_STR_LEN);
	/*ret = vastai_pci_numa_cpu_info(priv, cpu_card_topo_str,*/
	/*CPU_AND_CARD_TOPO_STR_LEN);*/
	ret = vastai_pci_numa_cpu_info_all(cpu_card_topo_str,
					   CPU_AND_CARD_TOPO_STR_LEN);
	if (ret) {
		VATOOLS_INFO(priv, die_index,
			     "get topological relation failed, ret=%ld\n", ret);
		ret = -EFAULT;
		goto free;
	}
	VATOOLS_DBG(priv, die_index, "get topological relation: %s\n",
		    cpu_card_topo_str);
	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr,
			      cpu_card_topo_str, CPU_AND_CARD_TOPO_STR_LEN);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto free;
	}
free:
	kvfree(cpu_card_topo_str);
	return ret;
#else
	return -EINVAL;
#endif
}

static int tools_ras_format_transform(struct vastai_ras_err_info *in,
				      struct tools_ras_err_info *out)
{
	int ret = 0;

	/* tools_ras_err_head */
	out->head.version = RAS_SV100_DRIVER_VERSION;
	out->head.timestamp = in->head.timestamp;
	out->head.entry_size = in->head.entry_size;
	out->head.err_severity = in->head.err_severity;
	out->head.err_reason = in->head.err_reason;
	out->head.sub_component = in->head.sub_component;
	out->head.component = in->head.component;

	/* ras_entry */
	/* ddr_ecc */
	switch (out->head.component) {
	case VASTAI_RAS_CORE: {
		out->ras_entry.core.pc = in->ras_entry.core.pc;
		out->ras_entry.core.ps = in->ras_entry.core.ps;
	} break;
	case VASTAI_RAS_AI: {
		ret = 0;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown ras component %u\n",
			    out->head.component);
	} break;
	case VASTAI_RAS_VIDEO: {
		out->ras_entry.video.video_event =
			in->ras_entry.video.video_event;
		out->ras_entry.video.status = in->ras_entry.video.status;
	} break;
	case VASTAI_RAS_PVT: {
		out->ras_entry.pvt.reason = in->ras_entry.pvt.reason;
		out->ras_entry.pvt.percent = in->ras_entry.pvt.percent;
	} break;
	case VASTAI_RAS_DDR: {
		out->ras_entry.ddr_ecc.inline_ecc_info.addr_l =
			in->ras_entry.ddr_ecc.addr_1;
		out->ras_entry.ddr_ecc.inline_ecc_info.addr_h =
			in->ras_entry.ddr_ecc.addr_h;
		out->ras_entry.ddr_ecc.inline_ecc_info.axi_id =
			in->ras_entry.ddr_ecc.axi_id;
		out->ras_entry.ddr_ecc.inline_ecc_info.axi_data_l =
			in->ras_entry.ddr_ecc.axi_data_l;
		out->ras_entry.ddr_ecc.inline_ecc_info.axi_data_h =
			in->ras_entry.ddr_ecc.axi_data_h;
		out->ras_entry.ddr_ecc.inline_ecc_info.errbit =
			in->ras_entry.ddr_ecc.errbit;
	} break;
	case VASTAI_RAS_PCIE: {
		out->ras_entry.pcie.ep_or_rc = in->ras_entry.pcie.ep_or_rc;
		out->ras_entry.pcie.err_type = in->ras_entry.pcie.err_type;
		out->ras_entry.pcie.err_idx = in->ras_entry.pcie.err_idx;
		out->ras_entry.pcie.rsvd = in->ras_entry.pcie.rsvd;
	} break;
	case VASTAI_RAS_DMA: {
		out->ras_entry.dma.cor_cnt = in->ras_entry.dma.cor_cnt;
		out->ras_entry.dma.uncor_cnt = in->ras_entry.dma.uncor_cnt;
	} break;
	case VASTAI_RAS_OTHERS: {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown ras component %u\n",
			    out->head.component);
	} break;
	default: {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown ras component %u\n",
			    out->head.component);
		ret = 0;
	} break;
	}

	return ret;
}

static long vatools_pcie_ioctl_get_err_info(T_SMI_IOCTL_TRANS_DATA *pkdata,
					    struct vastai_pci_info *priv,
					    int die_index)
{
	long ret = -EINVAL;
	int i = 0;
	struct vatools_err_info_t err_info = { 0 };
	struct tools_ras_err_info *tools_ras_buf = NULL;

	ret = copy_from_user_ex(&err_info,
				(void __user *)pkdata->output_buf.buf_addr,
				sizeof(struct vatools_err_info_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		return -EFAULT;
	}

	tools_ras_buf =
		vmalloc(sizeof(struct tools_ras_err_info) * MAX_RAS_READ_ONCE);
	err_info.buffer = (uintptr_t)kvmalloc(
		sizeof(struct vastai_ras_err_info) * MAX_RAS_READ_ONCE,
		GFP_KERNEL);

	if ((void *)err_info.buffer == NULL || !tools_ras_buf) {
		VATOOLS_DBG(priv, die_index, "malloc err_info buffer failed\n");
		return -EINVAL;
	}
	memset((void *)err_info.buffer, 0x0,
	       sizeof(struct vastai_ras_err_info) * MAX_RAS_READ_ONCE);

	vastai_ras_err_vatools_read(
		&priv->dies[vastai_pci_get_die_id(priv, die_index)], &err_info);

	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr, &err_info,
			      sizeof(struct vatools_err_info_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto free;
	}

	for (i = 0; i < MAX_RAS_READ_ONCE; i++) {
		ret = tools_ras_format_transform(
			((struct vastai_ras_err_info *)err_info.buffer) + i,
			tools_ras_buf + i);
		if (ret) {
			VATOOLS_DBG(priv, die_index,
				    "tools_ras_format_transform err, i %d\n",
				    i);
			ret = -EFAULT;
			goto free;
		}
	}
	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr +
				      sizeof(struct vatools_err_info_t),
			      (void *)tools_ras_buf,
			      sizeof(struct tools_ras_err_info) *
				      MAX_RAS_READ_ONCE);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto free;
	}

	VATOOLS_DBG(priv, die_index, "get ras ok. ret=%ld\n", ret);
free:
	kvfree((void *)err_info.buffer);
	vfree((void *)tools_ras_buf);
	return ret;
}

/*Get the pcie bandwidth of all RC, EP of the die*/
static long
vatools_pcie_ioctl_pcie_bandwidth_monitor(T_SMI_IOCTL_TRANS_DATA *pkdata,
					  struct vastai_pci_info *priv,
					  int die_index)
{
	long ret = -EINVAL;
	vatools_pcie_bw_monitor_t bw_count;
	union die_index_data did;
	u32 bw_type = 0;

	did.val = die_index;
	memset(&bw_count, 0, sizeof(vatools_pcie_bw_monitor_t));

	bw_count.die_index = die_index;
	bw_count.timestamp_ns = vastai_get_host_time_ns();

	for (bw_type = 0; bw_type < VATOOLS_PCIE_BW_TYPE_MAX; bw_type++) {
		ret = vastai_get_upstream_pcie_bw(
			priv, did.die_id, bw_type,
			&bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_UPSTREAM]
				 .pcie_bw_count);
		bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_UPSTREAM]
			.return_value = ret;

		if (ret < 0) {
			VATOOLS_DBG(
				priv, die_index,
				"vastai_get_upstream_pcie_bw fail. bw_type=%d ret=%ld\n",
				bw_type, ret);
		}

		ret = vastai_get_downstream_pcie_bw(
			priv, did.die_id, bw_type,
			&bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_DOWNSTREAM]
				 .pcie_bw_count);
		bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_DOWNSTREAM]
			.return_value = ret;
		if (ret < 0) {
			VATOOLS_DBG(
				priv, die_index,
				"vastai_get_downstream_pcie_bw fail. bw_type=%d ret=%ld\n",
				bw_type, ret);
		}

		VATOOLS_DBG(
			priv, die_index,
			"pcie bandwidth: die_id_in_fn:%d  bw_type=%d upstream_count(d2h): 0x%llx downstream_count(h2d): 0x%llx \n",
			did.die_id, bw_type,
			bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_UPSTREAM]
				.pcie_bw_count,
			bw_count.pcie_bw[bw_type][VATOOLS_PCIE_BW_DOWNSTREAM]
				.pcie_bw_count);
	}

	ret = copy_to_user_ex((u8 *)pkdata->output_buf.buf_addr, &bw_count,
			      sizeof(vatools_pcie_bw_monitor_t));
	if (ret < 0) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

out:
	return ret;
}

static void get_addr_map_internal(struct vastai_pci_info *priv, uint64_t *buf,
			   int entry_count)
{
	int i = 0;

	for (i = 0; i < entry_count; i++) {
		if (i < vatool_address_count)
			buf[i] = vatools_get_address_by_index(priv, i);
		else
			buf[i] = 0x5A5A5A5A5A5A5A5A;
	}
	buf[entry_count - 1] = 0xFF5A5A5AFFA5A5A5;
	buf[entry_count - 2] = 0xFF5A5A5AFFA5A5A5;
}

static long vatools_pcie_ioctl_get_addr_map(T_SMI_IOCTL_TRANS_DATA *pkdata,
					    struct vastai_pci_info *priv,
					    int die_index)
{
	long ret = -EINVAL;
	uint64_t *addr = (uint64_t *)vmalloc(ADDRESS_MAP_SIZE);

	if (addr == NULL) {
		VATOOLS_DBG(priv, die_index, "vmalloc size %d failed\n",
			    ADDRESS_MAP_SIZE);
		ret = -ENOMEM;
		return ret;
	}
	memset(addr, 0, ADDRESS_MAP_SIZE);
	get_addr_map_internal(priv, addr, ADDRESS_MAP_SIZE / sizeof(uint64_t));
	VATOOLS_DUMP_BRIEF("addr map: ", addr, ADDRESS_MAP_SIZE);
	ret = copy_to_user_ex((void __user *)pkdata->output_buf.buf_addr, addr,
			      (pkdata->output_buf.buf_size > ADDRESS_MAP_SIZE ?
				       ADDRESS_MAP_SIZE :
				       pkdata->output_buf.buf_size));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}
out:
	vfree(addr);
	return ret;
}

static long vatools_pcie_ioctl_get_rdma_fd(T_SMI_IOCTL_TRANS_DATA *pkdata,
					   struct vastai_pci_info *priv,
					   int die_index)
{
	long ret = -EINVAL;
	struct dma_buf *dmabuf = NULL;
	int write_len = 0;
	struct vatools_rdmabuf_alloc rdma_alloc = { 0 };
	T_SMI_IOCTL_TRANS_DATA *kdata = pkdata;

	write_len = kdata->input_buf.buf_size;
	if (write_len != sizeof(struct vatools_rdmabuf_alloc)) {
		VATOOLS_DBG(
			priv, die_index,
			"write len not equal to sizeof(struct vatools_rdmabuf_alloc), error\n");
		ret = -EFAULT;
		goto out;
	}

	if (kdata->input_buf.buf_addr == 0) {
		VATOOLS_DBG(priv, die_index, "buf_addr zero err\n");
		ret = -EINVAL;
		goto out;
	}

	ret = copy_from_user_ex((void *)(&rdma_alloc),
				(void *)kdata->input_buf.buf_addr, write_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex err\n");
		ret = -EFAULT;
		goto out;
	}

	dmabuf = vastai_rdma_dmabuf_export(priv, die_index, rdma_alloc.size,
					   &rdma_alloc.dma_addr_t,
					   (rdma_mem_type_t)rdma_alloc.mem_type);

	if (dmabuf) {
		int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
		rdma_alloc.dma_buf_fd = fd;
	} else {
		ret = -ENOMEM;
	}

	if (copy_to_user_ex((void *)kdata->input_buf.buf_addr, &rdma_alloc,
			    sizeof(struct vatools_rdmabuf_alloc))) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

out:
	return ret;
}

static long vatools_pcie_ioctl_pcie_video_manage(T_SMI_IOCTL_TRANS_DATA *pkdata,
						 struct vastai_pci_info *priv,
						 int die_index);
/*PCIe command interface, which directly calls PCIe driver functions. Not sent to SMCU*/
static long vatools_pcie_ioctl(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
{
	/*struct vatools_node*   node   = vatools_file_get_node( filp );*/
	/*struct vatools_reader* reader = vatools_file_get_reader( filp );*/

	long ret;
	void __user *argp = (void __user *)arg;
	int write_len = 0;
	int read_len = 0;
	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	int ret2 = 0;
	int pci_info_status = VASTAI_NO_RUN_STATE;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl_cmd=0x%x\n", cmd);

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, (void __user *)argp, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index,
			    "copy_from_user_ex ret=%ld ioctl_cmd=0x%x\n", ret,
			    cmd);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index,
		    "block_id=%d  device_id=%d  die_id=%d  flag=0x%x  addr= "
		    "0x%llx\n",
		    kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		    kdata.flag, kdata.address);
	VATOOLS_DBG(
		priv, die_index,
		"from host: read_len(output)=%d  read_buf(output)=0x%llx  write_len(input)=%d"
		"write_buf(input)=0x%llx\n",
		kdata.output_buf.buf_size, kdata.output_buf.buf_addr,
		kdata.input_buf.buf_size, kdata.input_buf.buf_addr);

	write_len = kdata.input_buf.buf_size;
	read_len = kdata.output_buf.buf_size;
	/*commands do not care about priv or die_index, emulate all devices/dies*/
	if (kdata.flag == PCIE_CMD_FLAG_RUNTIME_INFO ||
	    kdata.flag == PCIE_CMD_FLAG_CURRENT_PROCESS_INFO) {
		priv = NULL;
		die_index = kdata.device.die_index;
	} else {
		priv = vatools_get_vastai_pci_device_info(
			(char)kdata.device.dev_id);

		/*device reboot reset boot do not check status*/
		switch (kdata.flag) {
		case PCIE_CMD_FLAG_RESET:
		case PCIE_CMD_FLAG_REBOOT:
		case PCIE_CMD_FLAG_BOOT: {
			if (priv == NULL) {
				VATOOLS_INFO(
					priv, die_index,
					"priv is NULL, die_index= 0x%x ioctl_cmd=0x%x kdata.flag=0x%x.\n",
					kdata.device.die_index, cmd,
					kdata.flag);
				ret = -ENODEV;
				goto out;
			}
			pci_info_status = atomic_read(&priv->pci_state);
			if ((pci_info_status == VASTAI_HOTP_STATE)) {
				VATOOLS_INFO(
					priv, die_index,
					"priv->pci_state= 0x%x ioctl_cmd=0x%x\n",
					pci_info_status, cmd);
				ret = -EACCES;
				goto out;
			}
			die_index = kdata.device.die_index;
		} break;
			/*trigger dma test only run at VASTAI_NORMAL_STATE*/
		case PCIE_CMD_FLAG_REBOOT_DDRBW:
		case PCIE_CMD_FLAG_REBOOT_PCIEDMA: {
			if (priv == NULL) {
				VATOOLS_INFO(
					priv, die_index,
					"priv is NULL, die_index= 0x%x ioctl_cmd=0x%x kdata.flag=0x%x .\n",
					kdata.device.die_index, cmd,
					kdata.flag);
				ret = -ENODEV;
				goto out;
			}
			pci_info_status = atomic_read(&priv->pci_state);
			if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
						    -1)) {
				VATOOLS_DBG(
					priv, die_index,
					"priv->pci_state= 0x%x ioctl_cmd=0x%x\n",
					pci_info_status, cmd);
				ret = -EACCES;
				goto out;
			}
			die_index = kdata.device.die_index;
		} break;
			/*read dma test result can run at VASTAI_DEBUG_STATE*/
		case PCIE_CMD_FLAG_BANDWIDTH:
		case PCIE_CMD_FLAG_DDR_BANDWIDTH:
		case PCIE_CMD_FLAG_DDR_BANDWIDTH_MONITOR:
		case PCIE_CMD_FLAG_PCIE_BANDWIDTH_MONITOR: {
			if (priv == NULL) {
				VATOOLS_INFO(
					priv, die_index,
					"priv is NULL, die_index= 0x%x ioctl_cmd=0x%x kdata.flag=0x%x  .\n",
					kdata.device.die_index, cmd,
					kdata.flag);
				ret = -ENODEV;
				goto out;
			}
			pci_info_status = atomic_read(&priv->pci_state);
			if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
						    VASTAI_DEBUG_STATE, -1)) {
				VATOOLS_DBG(
					priv, die_index,
					"priv->pci_state= 0x%x ioctl_cmd=0x%x\n",
					pci_info_status, cmd);
				ret = -EACCES;
				goto out;
			}
			die_index = kdata.device.die_index;
		} break;
			/*other smi or pcie cmd(not DMA ) can run on VASTAI_DEBUG_STATE*/
		default: {
			if (priv == NULL) {
				VATOOLS_INFO(
					NULL, DUMMY_DIE_ID,
					"priv is NULL, die_index= 0x%x ioctl_cmd=0x%x kdata.flag=0x%x\n",
					kdata.device.die_index, cmd,
					kdata.flag);
				ret = -ENODEV;
				goto out;
			}
			pci_info_status = atomic_read(&priv->pci_state);
			if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
						    VASTAI_DEBUG_STATE, -1)) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"priv->pci_state=0x%x ioctl_cmd=0x%x\n",
					pci_info_status, cmd);
				ret = -EACCES;
				goto out;
			}
			die_index = vatools_get_vastai_pci_die_index(
				(char)kdata.device.dev_id, kdata.device.die_id);
			if (die_index < 0) {
				ret = -ENODEV;
				goto out;
			}
		} break;
		}

#if 0
		priv = vatools_get_vastai_pci_device_info(
			(char)kdata.device.dev_id);
		/*device reboot reset boot do not check status*/
		if (kdata.flag != PCIE_CMD_FLAG_RESET &&
		    kdata.flag != PCIE_CMD_FLAG_REBOOT &&
		    kdata.flag != PCIE_CMD_FLAG_BOOT &&
		    kdata.flag != PCIE_CMD_FLAG_REBOOT_DDRBW &&
		    kdata.flag != PCIE_CMD_FLAG_REBOOT_PCIEDMA) {
			if (priv == NULL) {
				VATOOLS_DBG(
					priv, die_index,
					"priv is NULL, dev_id=0x%x ioctl_cmd=0x%x\n",
					kdata.device.dev_id, cmd);
				ret = -ENODEV;
				goto out;
			}
			if ((atomic_read(&priv->pci_state) !=
			     VASTAI_NORMAL_STATE)) {
				VATOOLS_DBG(
					priv, die_index,
					"priv->pci_state=0x%x ioctl_cmd=0x%x\n",
					atomic_read(&priv->pci_state), cmd);
				ret = -ENODEV;
				goto out;
			}
			die_index = vatools_get_vastai_pci_die_index(
				(char)kdata.device.dev_id, kdata.device.die_id);
			if (die_index < 0) {
				ret = -ENODEV;
				goto out;
			}
		} else {
			if (priv == NULL) {
				VATOOLS_DBG(
					priv, die_index,
					"priv is NULL, dev_id=0x%x ioctl_cmd=0x%x\n",
					kdata.device.dev_id, cmd);
				ret = -ENODEV;
				goto out;
			}
			if ((atomic_read(&priv->pci_state) ==
			     VASTAI_HOTP_STATE)) {
				VATOOLS_DBG(
					priv, die_index,
					"priv->pci_state=0x%x ioctl_cmd=0x%x\n",
					atomic_read(&priv->pci_state), cmd);
				ret = -ENODEV;
				goto out;
			}
			die_index = kdata.device.die_index;
		}
#endif
	}

	kdata.errcode = 0;

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	if (priv == NULL)
		domain_mutex_lock(priv, die_index,
				  VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
	else
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

	/*doesn't need priv commands, handle them separately, and then goto out_unlock_mutex*/
	switch (kdata.flag) {
	case PCIE_CMD_FLAG_RUNTIME_INFO: {
		ret = vatools_pcie_ioctl_runtime_info(&kdata, priv, die_index);
		goto out_unlock_mutex;
	} break;

	case PCIE_CMD_FLAG_CURRENT_PROCESS_INFO: {
		ret = vatools_pcie_ioctl_current_process_info(&kdata, priv,
							      die_index);
		goto out_unlock_mutex;
	} break;
	}

	/*The following commands require priv to exist*/
	if (priv == NULL) {
		VATOOLS_INFO(
			priv, die_index,
			"priv is NULL die_index= 0x%x ioctl_cmd=0x%x kdata.flag=0x%x\n",
			kdata.device.die_index, cmd, kdata.flag);
		ret = -ENODEV;
		goto out_unlock_mutex;
	}
	switch (kdata.flag) {
	case PCIE_CMD_FLAG_BANDWIDTH: {
		ret = vatools_pcie_ioctl_bandwidth(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_RESET: {
		ret = vatools_pcie_ioctl_reset(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_BOOT: {
		ret = vatools_pcie_ioctl_boot(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_REBOOT: {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_pcie_ioctl_reboot(&kdata, priv, die_index);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	} break;

	case PCIE_CMD_FLAG_FW_VERSION: {
		ret = vatools_pcie_ioctl_fw_version(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_DDR_ECC_1BIT: {
		ret = vatools_pcie_ioctl_ecc_1bit(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_DDR_ECC_2BIT: {
		ret = vatools_pcie_ioctl_ecc_2bit(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_VDSP_COUNT: {
		ret = vatools_pcie_ioctl_vdsp_count(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_AI_COUNT: {
		ret = vatools_pcie_ioctl_ai_count(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_RING_BUF_STATISTIC: {
		ret = vatools_pcie_ioctl_ring_buf_statistic(&kdata, priv,
							    die_index);
	} break;
	case PCIE_CMD_FLAG_RING_BUF_FROM_HW_CFG: {
		ret = vatools_pcie_ioctl_ring_buf_from_hw_cfg(&kdata, priv,
							      die_index);
	} break;
#ifdef CONFIG_VASTAI_VIDEO
		/*Set video to use multicore; 0: Not used; 1: Use*/
	case PCIE_CMD_FLAG_SET_VIDEO_MULTI_CORE: {
		ret = vatools_pcie_ioctl_set_video_multi_core(&kdata, priv,
							      die_index);
	} break;
	case PCIE_CMD_FLAG_GET_VIDEO_MULTI_CORE: {
		ret = vatools_pcie_ioctl_get_video_multi_core(&kdata, priv,
							      die_index);
	} break;
#endif
		/*core heartbeat*/
	case PCIE_CMD_FLAG_HEART_BEAT: {
		ret = vatools_pcie_ioctl_heart_beat(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_BARRESET: {
		ret = vatools_pcie_ioctl_barreset(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_BARSTATUS: {
		ret = vatools_pcie_ioctl_barstatus(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_REBOOT_DDRBW: {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_pcie_ioctl_reboot_ddrbw(&kdata, priv, die_index);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	} break;

	case PCIE_CMD_FLAG_REBOOT_PCIEDMA: {
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
		ret = vatools_pcie_ioctl_reboot_pciedma(&kdata, priv,
							die_index);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	} break;

	case PCIE_CMD_FLAG_HEART_BEAT_COUNT: {
		ret = vatools_pcie_ioctl_heartbeat_count(&kdata, priv,
							 die_index);
	} break;

	case PCIE_CMD_FLAG_DDR_BANDWIDTH: {
		ret = vatools_pcie_ioctl_ddr_bandwidth(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_DDR_BANDWIDTH_MONITOR: {
		ret = vatools_pcie_ioctl_ddr_bandwidth_monitor(&kdata, priv,
							       die_index);
	} break;

	case PCIE_CMD_FLAG_CARD_CPU_TOPO: {
		ret = vatools_pcie_ioctl_card_cpu_topo(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_ERR_INFO_READ: {
		ret = vatools_pcie_ioctl_get_err_info(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_PCIE_BANDWIDTH_MONITOR: {
		ret = vatools_pcie_ioctl_pcie_bandwidth_monitor(&kdata, priv,
								die_index);
	} break;

	case PCIE_CMD_FLAG_VIDEO_CMD: {
		ret = vatools_pcie_ioctl_pcie_video_manage(&kdata, priv,
							   die_index);
	} break;

	case PCIE_CMD_FLAG_GET_ADDR_MAP: {
		ret = vatools_pcie_ioctl_get_addr_map(&kdata, priv, die_index);
	} break;

	case PCIE_CMD_FLAG_GET_RDMA_FD: {
		ret = vatools_pcie_ioctl_get_rdma_fd(&kdata, priv, die_index);
	} break;

	default:
		VATOOLS_DBG(priv, die_index,
			    "Pcie cmd id %d don't support in current system\n",
			    kdata.flag);
		ret = -E_UNKNOWN_SUB_CMD;
		break;
	}

out_unlock_mutex:

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	if (priv == NULL)
		domain_mutex_unlock(priv, die_index,
				    VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
	else
		domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

out:
	kdata.errcode = ret;
	if (priv) {
		pci_info_status = atomic_read(&priv->pci_state);
		kdata.block_id = pci_info_status;
	}
	ret2 = copy_to_user_ex((void __user *)argp, &kdata, sizeof(kdata));
	if (ret2) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_index, "out: ret=%ld ret2=%d\n", ret, ret2);
	VATOOLS_FUNC_EXIT;

	return ret2;
}

/*For internal testing use*/
static int vatools_ioctl_test(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg)
{
	long ret = -EIO;
	/*struct vatools_node*   node   = NULL;*/
	/*struct vatools_reader* reader = NULL;*/
	/*void __user*           argp   = ( void __user* )arg;*/

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);
	VATOOLS_FUNC_ENTERY;

	/*node   = vatools_file_get_node( filp );*/
	/*reader = vatools_file_get_reader( filp );*/

	return ret;
}

#define SV100_VATOOLS_WEIGHT_MAGIC VATOOLS_UINT32_MAX
static void vatools_video_weight_init(void)
{
	int type = 0;
	u32 die_index = 0;
	u32 die = 0;
	struct vastai_pci_info *pci_info = NULL;
	union die_index_data did = { 0 };

	struct vatools_node *node = vatools_get_node();
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#else
	mutex_lock(&node->node_mutex);
#endif
	down_read(&tools_devs_rw_sem);
	list_for_each_entry (pci_info, &vastai_tools_devs_list,
			     tools_dev_list) {
		for (type = 0; type < ALLOC_VIDEO_MAX; type++) {
			for (die = 0; die < pci_info->die_num_in_fn; die++) {
				die_index = pci_info->dies[die].die_index;
				did.val = (u32)die_index;

				mutex_lock(&sharedmem_weight_mutex);
				node->die_weights[type][did.seq_num].die_seq =
					did.seq_num;
				node->die_weights[type][did.seq_num].die_weight =
					MIN_VIDEO_DIE_CAPABILITY;
				node->die_weights_real[type][did.seq_num]
					.die_seq = did.seq_num;
				node->die_weights_real[type][did.seq_num]
					.die_weight = MIN_VIDEO_DIE_CAPABILITY;

				mutex_unlock(&sharedmem_weight_mutex);
				VATOOLS_DBG(
					NULL, 0,
					"%s: dieseq %d, die weight %d, type %u\n",
					__func__,
					node->die_weights[type][did.seq_num]
						.die_seq,
					node->die_weights[type][did.seq_num]
						.die_weight,
					type);
			}
		}
	}
	up_read(&tools_devs_rw_sem);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#else
	mutex_unlock(&node->node_mutex);
#endif
}

static u32 get_random_num(u32 max)
{
	u32 num = 0;

	get_random_bytes(&num, sizeof(u32));
	/*don't use wait_for_random_bytes, it may sleep*/
	return num % max;
}

static u32 vatools_video_weight_alloc(struct vatools_node *node,
				      struct vatools_video_cap_query *cap_query)
{
	u32 i = 0;
	u8 type = 0;
	u32 die = 0;
	u32 max_die_len = MAX_OCCUPY_DIE_SINGLE;
	u32 seq = VATOOLS_UINT32_MAX;
	u32 min_die_weight = VATOOLS_UINT32_MAX;
	u32 temp = 0;
	u32 random = 0;

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#else
	mutex_lock(&node->node_mutex);
#endif

	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: die array len %u, max %u\n",
		    __func__, cap_query->die_array_len, max_die_len);

	max_die_len = (max_die_len > cap_query->die_array_len) ?
			      cap_query->die_array_len :
			      max_die_len;
	mutex_lock(&sharedmem_weight_mutex);

	if (cap_query->die_array_len == 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: die_array_len 0 \n",
			    __func__);
		goto out;
	}

	if (cap_query->flag_encode_or_decode >= ALLOC_VIDEO_MAX) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: unknown type %u\n",
			    __func__, cap_query->flag_encode_or_decode);
		goto out;
	}
	type = cap_query->flag_encode_or_decode;

	for (i = 0; i < max_die_len; i++) {
		die = cap_query->die_array[i];
		if (die >= MAX_OCCUPY_DIE_NUM)
			die = MAX_OCCUPY_DIE_NUM - 1;

		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"%s: seq %u, die weight %u, real die weight %u, type %u\n",
			__func__, die, node->die_weights[type][die].die_weight,
			node->die_weights_real[type][die].die_weight, type);
		temp = (node->die_weights[type][die].die_weight >
			node->die_weights_real[type][die].die_weight) ?
			       node->die_weights[type][die].die_weight :
			       node->die_weights_real[type][die].die_weight;
		if (temp < min_die_weight) {
			min_die_weight = temp;
			seq = die;
		}
	}

	if (min_die_weight == VATOOLS_UINT32_MAX) {
		random = get_random_num(max_die_len);
		seq = cap_query->die_array[random];
		cap_query->die_weight_total = VATOOLS_UINT32_MAX;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "%s: min weight above u32 max\n", __func__);
		goto out;
	}

	if ((VATOOLS_UINT32_MAX - node->die_weights[type][seq].die_weight) <
	    cap_query->die_weight) {
		cap_query->die_weight = VATOOLS_UINT32_MAX -
					node->die_weights[type][seq].die_weight;
		node->die_weights[type][seq].die_weight = VATOOLS_UINT32_MAX;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: not enough die weight\n",
			    __func__);
	} else {
		node->die_weights[type][seq].die_weight +=
			cap_query->die_weight;
	}
	cap_query->die_weight_total = node->die_weights[type][seq].die_weight;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"%s: sel seq %u, alloc %u, allocated %u, weight real %u, type %u\n",
		__func__, seq, cap_query->die_weight,
		node->die_weights[type][seq].die_weight,
		node->die_weights_real[type][seq].die_weight, type);

out:
	mutex_unlock(&sharedmem_weight_mutex);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#else
	mutex_unlock(&node->node_mutex);
#endif
	return seq;
}

#ifdef CONFIG_TOOLS_V2
static long vatools_ioctl_video_capability_query(struct file *filp,
						 unsigned int cmd,
						 IOCTL_ARG_T arg)
{
	long ret;
	struct vatools_video_cap_query cap_query = { 0 };
	struct vatools_reader *reader = NULL;
	struct vatools_node *node = NULL;
	void __user *argp = (void __user *)arg;
	u32 seq = 0;

	reader = vatools_file_get_reader(filp);
	node = reader->node;

	ret = copy_from_user_ex(&cap_query, (void __user *)argp,
				sizeof(struct vatools_video_cap_query));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "copy_from_user_ex ret=%ld ioctl_cmd=0x%x\n", ret,
			    cmd);
		return -EFAULT;
	}

	if (reader->own_dies.die_weight > 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "%s: reader already queried, return seq %d\n",
			    __func__, reader->own_dies.die_seq);
		cap_query.die_seq = reader->own_dies.die_seq;
		if (copy_to_user_ex((void __user *)argp, &cap_query,
				    sizeof(struct vatools_video_cap_query))) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "%s: copy_to_user_ex ret=%ld\n", __func__,
				    ret);
			return -EFAULT;
		}

		return 0;
	}

	seq = vatools_video_weight_alloc(node, &cap_query);
	if (seq == VATOOLS_UINT32_MAX) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "%s: can't seen any die, or codec type err\n",
			     __func__);
		return -ENOMEM;
	}

	cap_query.die_seq = seq;
	if (copy_to_user_ex((void __user *)argp, &cap_query,
			    sizeof(struct vatools_video_cap_query))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "%s: copy_to_user_ex ret=%ld\n",
			    __func__, ret);
		return -EFAULT;
	}

	if (cap_query.flag_encode_or_decode >= ALLOC_VIDEO_MAX) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "%s: query alloc type err, val %u\n", __func__,
			     reader->own_dies.flag_encode_or_decode);
		return -ENOMEM;
	}

	reader->own_dies.flag_encode_or_decode =
		cap_query.flag_encode_or_decode;
	reader->own_dies.die_weight += cap_query.die_weight;
	reader->own_dies.die_seq = seq;
	return 0;
}
#endif

static int vatools_ac_bench_dma_alloc(struct vatools_ac_bench_dma *ac_bench_dma)
{
	int ret = -ENOMEM;
	struct dma_buf *dmabuf = NULL;
	struct vastai_pci_info *priv = NULL;
	uint32_t size = ac_bench_dma->from.size;

	priv = vatools_get_vastai_pci_device_info(
		ac_bench_dma->from.die_index.dev_id);

	if ((atomic_read(&priv->pci_state) != VASTAI_NORMAL_STATE)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv->pci_state= 0x%x\n",
			    atomic_read(&priv->pci_state));
		return -ENODEV;
	}

	if (iommu_is_enable(priv))
		dmabuf = vastai_alloc_dma_buf_sg(priv, size);
	else
		dmabuf = vastai_alloc_dma_buf(priv, size);

	if (dmabuf) {
		int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
		ac_bench_dma->from.dma_buf_fd = fd;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "alloc dma buf suc,  buf_fd %d, size 0x%x\n",
			    ac_bench_dma->from.dma_buf_fd, size);
		ret = 0;
		//ac_bench_dma->from.virt_addr = (u64)dmabuf->userva;
	} else {
		ac_bench_dma->from.dma_buf_fd = 0;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "alloc dma buf fail,  buf_fd %d\n",
			    ac_bench_dma->from.dma_buf_fd);
		ret = -ENOMEM;
	}

	return ret;
}

static int vatools_ac_bench_dma_free(struct vatools_ac_bench_dma *ac_bench_dma,
				     struct vastai_pci_info *priv,
				     int die_index)
{
	return 0;
}

int vatools_ac_bench_dma_p2p(struct vatools_ac_bench_dma *ac_bench_dma)
{
	int ret = -EINVAL;
	int ret_save = 0;
	union core_bitmap core_id = { .val = 0 };
	struct kchar_cmd kcmd = { 0 };
	u32 size = 0;
	u32 entry_count = 0;
	struct vastai_pci_info *priv_from = NULL;
	struct vastai_pci_info *priv_to = NULL;
	struct vastai_pci_info *src_priv = NULL;
	union die_index_data src_die_index = { 0 };
	union die_index_data dst_die_index = { 0 };
	uint32_t loop = 0;
	uint32_t suc_num = 0;
	uint32_t fail_num = 0;
	struct vastai_dmadesc *desc = NULL;
	//struct vatools_node *node = vatools_get_node();
	uint64_t bar_addr = 0;

	priv_from = vatools_get_vastai_pci_device_info(
		ac_bench_dma->from.die_index.dev_id);
	if ((atomic_read(&priv_from->pci_state) != VASTAI_NORMAL_STATE)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv_from->pci_state= 0x%x\n",
			    atomic_read(&priv_from->pci_state));
		return -ENODEV;
	}

	priv_to = vatools_get_vastai_pci_device_info(
		ac_bench_dma->to.die_index.dev_id);
	if ((atomic_read(&priv_to->pci_state) != VASTAI_NORMAL_STATE)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv_to->pci_state= 0x%x\n",
			    atomic_read(&priv_to->pci_state));
		return -ENODEV;
	}
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"from die_index 0x%x, mmio_start 0x%llx, mmio_end 0x%llx, p2p dma start axi ddr addr 0x%llx\n",
		ac_bench_dma->from.die_index.val,
		priv_from->bar[AC_BENCH_BAR_P2P].mmio_start,
		priv_from->bar[AC_BENCH_BAR_P2P].mmio_end,
		ac_bench_dma->from.axi_addr);

	kcmd.p2p_start_cmd.local_addr = ac_bench_dma->from.axi_addr;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"to die_index 0x%x, mmio_start 0x%llx, mmio_end 0x%llx, p2p dma start axi addr 0x%llx\n",
		ac_bench_dma->to.die_index.val,
		priv_to->bar[AC_BENCH_BAR_P2P].mmio_start,
		priv_to->bar[AC_BENCH_BAR_P2P].mmio_end,
		ac_bench_dma->to.axi_addr);

	kcmd.p2p_start_cmd.remote_addr = ac_bench_dma->to.axi_addr;

	kcmd.p2p_start_cmd.size = ac_bench_dma->from.size;
	size = kcmd.p2p_start_cmd.size;
	entry_count = vast_div_round_up(size, VASTAI_MAX_DMA_BUF);
	desc = kvmalloc(sizeof(struct vastai_dmadesc) * entry_count,
			GFP_KERNEL);
	if (!desc) {
		return -ENOMEM;
	}

	src_die_index.val = ac_bench_dma->from.die_index.val;
	dst_die_index.val = ac_bench_dma->to.die_index.val;
	src_priv = priv_from;
	kcmd.p2p_start_cmd.die_index = ac_bench_dma->to.die_index.val;
	kcmd.p2p_start_cmd.local_to_remote = 1;
	vastai_ddr_to_bar(priv_to, ac_bench_dma->to.die_index.val,
			  kcmd.p2p_start_cmd.remote_addr, &bar_addr);
	kcmd.p2p_start_cmd.remote_addr = bar_addr;

	loop = ac_bench_dma->loop;
	loop = (loop > AC_BENCH_TEST_MAX_LOOP) ? AC_BENCH_TEST_MAX_LOOP : loop;
	//vastai_enable_udma_multi_chn(priv_from, true);
	while (loop--) {
		//mutex_lock(&node->node_mutex);
		//mutex_lock(&node->node_sharedmem_mutex);
		vastai_common_cut_p2p_buf(size, &kcmd, desc, src_priv,
					  vastai_ioctl_p2p_start_set_desc);
		ret = vastai_pci_dma_transfer_sync(src_priv,
						   kcmd.p2p_start_cmd.die_index,
						   core_id, desc, entry_count,
						   -1);
		if (ret < 0) {
			ret_save = ret;
			fail_num++;
		} else {
			suc_num++;
		}
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"p2p loop %d, ret %d, from index 0x%x, to die index 0x%x, src 0x%llx, dst 0x%llx, size 0x%x, direction %d, suc_cnt %u, fail_cnt %u\n",
			loop, ret, src_die_index.val,
			kcmd.p2p_start_cmd.die_index,
			kcmd.p2p_start_cmd.local_addr,
			kcmd.p2p_start_cmd.remote_addr, kcmd.p2p_start_cmd.size,
			kcmd.p2p_start_cmd.local_to_remote, suc_num, fail_num);
		//mutex_unlock(&node->node_sharedmem_mutex);
		//mutex_unlock(&node->node_mutex);
	}
	//vastai_enable_udma_multi_chn(priv_from, false);
	kvfree(desc);

	ac_bench_dma->suc_cnt = suc_num;
	ac_bench_dma->fail_cnt = suc_num;

	return ret_save;
}

#define VATOOLS_MAX_D2D_DMA_SINGLE (1024 * 1024 * 4)
int vatools_ac_bench_dma_d2d(struct vatools_ac_bench_dma *ac_bench_dma)
{
	int ret = -EINVAL;
	int ret_save = 0;
	struct vastai_pci_info *priv_from = NULL;
	uint32_t loop = 0;
	uint32_t suc_num = 0;
	uint32_t fail_num = 0;
	uint32_t len = 0;
	uint32_t temp_len = 0;
	uint64_t src_addr = 0;
	uint64_t dst_addr = 0;
	uint32_t die_index = 0;
	uint32_t direction = 0;
	u64 remote_address = 0x0;
	u64 local_address = 0x0;
	//struct vatools_node *node = vatools_get_node();

	priv_from = vatools_get_vastai_pci_device_info(
		ac_bench_dma->from.die_index.dev_id);
	if ((atomic_read(&priv_from->pci_state) != VASTAI_NORMAL_STATE)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "priv_from->pci_state= 0x%x\n",
			    atomic_read(&priv_from->pci_state));
		return -ENODEV;
	}
	die_index = ac_bench_dma->from.die_index.val;

	loop = ac_bench_dma->loop;
	loop = (loop > AC_BENCH_TEST_MAX_LOOP) ? AC_BENCH_TEST_MAX_LOOP : loop;

	src_addr = ac_bench_dma->from.axi_addr;
	dst_addr = ac_bench_dma->to.axi_addr;
	len = ac_bench_dma->from.size;
	direction = ac_bench_dma->direction;
	while (loop--) {
		temp_len = len;
		remote_address = dst_addr;
		local_address = src_addr;
		while (temp_len) {
			u32 current_len = temp_len <= VASTAI_MAX_DMA_BUF ?
						  temp_len :
						  VASTAI_MAX_DMA_BUF;
			ret = vastai_pci_data_movement(priv_from, die_index,
						       local_address,
						       remote_address,
						       current_len, direction);
			if (ret < 0) {
				ret_save = ret;
				fail_num++;
			} else {
				suc_num++;
			}

			remote_address += current_len;
			local_address += current_len;
			temp_len -= current_len;
		}
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"d2d loop %d, ret %d, die index 0x%x, src 0x%llx, dst 0x%llx, size 0x%x, suc_cnt %u, fail_cnt %u\n",
			loop, ret, die_index, src_addr, dst_addr, len, suc_num,
			fail_num);
	}

	ac_bench_dma->suc_cnt = suc_num;
	ac_bench_dma->fail_cnt = suc_num;

	return ret_save;
}

int vatools_ac_bench_dma_seq2seq(struct vatools_ac_bench_dma *ac_bench_dma)
{
	char *spi_buf = NULL;
	int ret = 0;
	union die_index_data from_die_index = { 0 };
	union die_index_data to_die_index = { 0 };
	union die_index_data master_die_index = { 0 };
	union die_index_data slave_die_index = { 0 };
	char file_version[5] = { 0 };

	char card_type_from[32] = { 0 };
	char unid_from[32] = { 0 };
	char bbox_mode_from[32] = { 0 };
	char bbox_type_from[32] = { 0 };

	char card_type_to[32] = { 0 };
	char unid_to[32] = { 0 };
	char bbox_mode_to[32] = { 0 };
	char bbox_type_to[32] = { 0 };

	const char *cardType = "N/A";
	const char *unidStr = "N/A";
	const char *bboxMode = "N/A";
	uint32_t is_d2d_flag = 0;
	struct vastai_pci_info *pci_from = NULL;
	struct vastai_pci_info *pci_to = NULL;
	VATOOLS_FUNC_ENTERY;

	from_die_index.val = ac_bench_dma->from.die_index.val;
	to_die_index.val = ac_bench_dma->to.die_index.val;

	if (from_die_index.val == to_die_index.val) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "don't support same die p2p/d2d test\n");
		ret = -1;
		goto out;
	}

	spi_buf = vmalloc(SPI_BUF_LEN_MAX);
	if (spi_buf == NULL) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "vmalloc spi_buf error. size=%d\n",
			    SPI_BUF_LEN_MAX);
		ret = -1;
		goto out;
	}

	memset(spi_buf, 0, SPI_BUF_LEN_MAX);
	ret = vatools_get_spi_buf(from_die_index.val, SPI_BLOCK_PRODUCT_INFO, 0,
				  SPI_BUF_LEN_MAX, spi_buf);
	if (ret < 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "vatools_get_spi_buf err, ret %d\n", ret);
		ret = -1;
		goto out_free;
	}

	memcpy(file_version, spi_buf, 4);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "file_version: %s\n", file_version);
	if (strcmp(file_version, "V2\0") == 0) {
		memcpy(card_type_from, spi_buf + 0x4, 16);
		memcpy(unid_from, spi_buf + 0x3C, 16);
		memcpy(bbox_type_from, spi_buf + 0x5C, 16);
		memcpy(bbox_mode_from, bboxMode, 4);
	} else if (strcmp(file_version, "V1\0") == 0) {
		memcpy(card_type_from, spi_buf + 0x4, 8);
		memcpy(unid_from, spi_buf + 0x34, 16);
		memcpy(bbox_mode_from, bboxMode, 4);
	} else {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown file_version: %s\n",
			    file_version);
		memcpy(card_type_from, cardType, 4);
		memcpy(unid_from, unidStr, 4);
		memcpy(bbox_mode_from, bboxMode, 4);
	}

	memset(spi_buf, 0, SPI_BUF_LEN_MAX);
	ret = vatools_get_spi_buf(to_die_index.val, SPI_BLOCK_PRODUCT_INFO, 0,
				  SPI_BUF_LEN_MAX, spi_buf);
	if (ret < 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "vatools_get_spi_buf err, ret %d\n", ret);
		ret = -1;
		goto out_free;
	}

	memcpy(file_version, spi_buf, 4);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "file_version: %s\n", file_version);
	if (strcmp(file_version, "V2\0") == 0) {
		memcpy(card_type_to, spi_buf + 0x4, 16);
		memcpy(unid_to, spi_buf + 0x3C, 16);
		memcpy(bbox_type_to, spi_buf + 0x5C, 16);
		memcpy(bbox_mode_to, bboxMode, 4);
	} else if (strcmp(file_version, "V1\0") == 0) {
		memcpy(card_type_to, spi_buf + 0x4, 8);
		memcpy(unid_to, spi_buf + 0x34, 16);
		memcpy(bbox_mode_to, bboxMode, 4);
	} else {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown file_version: %s\n",
			    file_version);
		memcpy(card_type_to, cardType, 4);
		memcpy(unid_to, unidStr, 4);
		memcpy(bbox_mode_to, bboxMode, 4);
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"card_type_from = %s, card_type_to = %s, from_die_index 0x%x, seq 0x%x, to_die_index 0x%x, seq 0x%x\n",
		card_type_from, card_type_to, from_die_index.val,
		from_die_index.seq_num, to_die_index.val, to_die_index.seq_num);

	if (strcmp(card_type_from, card_type_to) != 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "different cardtype just p2p\n");
		ret = vatools_ac_bench_dma_p2p(ac_bench_dma);
		if (ret < 0) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
				__func__, ret);
			ret = -1;
			goto out_free;
		}
		goto out_print;
	}

	if (strcmp(card_type_from, "VA16") == 0) {
		pci_from = get_vastai_pci_device_info(from_die_index.dev_id);
		pci_to = get_vastai_pci_device_info(to_die_index.dev_id);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "from sn %s, dev_id 0x%x\n",
			    pci_from->sn, from_die_index.dev_id);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "to sn %s, dev_id 0x%x\n",
			    pci_to->sn, to_die_index.dev_id);
		ret = strcmp(pci_from->sn, pci_to->sn);
		if (ret == 0 &&
		    ((from_die_index.dev_id ^ to_die_index.dev_id) <= 1)) {
			is_d2d_flag = 1;
		} else {
			is_d2d_flag = 0;
		}
		master_die_index.val =
			from_die_index.dev_id < to_die_index.dev_id ?
				from_die_index.val :
				to_die_index.val;
		slave_die_index.val =
			from_die_index.dev_id > to_die_index.dev_id ?
				from_die_index.val :
				to_die_index.val;

		if (is_d2d_flag) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: line %d\n",
				    __func__, __LINE__);

			if (master_die_index.val ==
			    from_die_index.val) { // from -> to direction 1
				ac_bench_dma->direction = 1;
			} else {
				ac_bench_dma->direction = 0;
			}
			ac_bench_dma->from.direction = ac_bench_dma->direction;
			ac_bench_dma->to.direction = ac_bench_dma->direction;
			ac_bench_dma->from.die_index.val = master_die_index.val;
			ac_bench_dma->to.die_index.val = slave_die_index.val;

			ret = vatools_ac_bench_dma_d2d(ac_bench_dma);
			if (ret < 0) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
					__func__, ret);
				ret = -1;
				goto out_free;
			}
		} else {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "va1 p2p test to do\n");
			ret = vatools_ac_bench_dma_p2p(ac_bench_dma);
			if (ret < 0) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
					__func__, ret);
				ret = -1;
				goto out_free;
			}
		}
	} else if (strcmp(card_type_from, "VA100") == 0) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "ac_bench unsupport cardtype SV100\n");
		ret = -1;
		goto out_free;
	} else {
		if (from_die_index.dev_id == to_die_index.dev_id) {
			is_d2d_flag = 1;
		} else {
			is_d2d_flag = 0;
		}
		master_die_index.val =
			from_die_index.die_id < to_die_index.die_id ?
				from_die_index.val :
				to_die_index.val;
		slave_die_index.val =
			from_die_index.die_id > to_die_index.die_id ?
				from_die_index.val :
				to_die_index.val;

		if (is_d2d_flag) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: line %d\n",
				    __func__, __LINE__);

			if (master_die_index.val ==
			    from_die_index.val) { // from -> to direction 1
				ac_bench_dma->direction = 1;
			} else {
				ac_bench_dma->direction = 0;
			}
			ac_bench_dma->from.direction = ac_bench_dma->direction;
			ac_bench_dma->to.direction = ac_bench_dma->direction;
			ac_bench_dma->from.die_index.val = master_die_index.val;
			ac_bench_dma->to.die_index.val = slave_die_index.val;

			ret = vatools_ac_bench_dma_d2d(ac_bench_dma);
			if (ret < 0) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
					__func__, ret);
				ret = -1;
				goto out_free;
			}
		} else {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "va1 p2p test to do\n");
			ret = vatools_ac_bench_dma_p2p(ac_bench_dma);
			if (ret < 0) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
					__func__, ret);
				ret = -1;
				goto out_free;
			}
		}
	}

out_print:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "is_d2d_flag %d, direction %d, master 0x%x, slave 0x%x\n",
		    is_d2d_flag, ac_bench_dma->direction, master_die_index.val,
		    slave_die_index.val);

out_free:
	vfree(spi_buf);
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

static long vatools_ioctl_ac_bench_test(struct file *filp, unsigned int cmd,
					IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	void __user *argp = (void __user *)arg;
	int write_len = 0;
	int read_len = 0;
	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	union vatools_ac_bench ac_bench_data = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl_cmd= 0x%x\n", cmd);

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, argp, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index,
			    "copy_from_user_ex ret=%ld ioctl_cmd= 0x%x\n", ret,
			    cmd);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index,
		    "block_id=%d  device_id=%d  die_id=%d  flag= 0x%x  addr= "
		    "0x%llx\n",
		    kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		    kdata.flag, kdata.address);
	VATOOLS_DBG(
		priv, die_index,
		"from host: read_len(output)= %d  read_buf(output)= 0x%llx  write_len(input)= %d"
		"write_buf(input)= 0x%llx\n",
		kdata.output_buf.buf_size, kdata.output_buf.buf_addr,
		kdata.input_buf.buf_size, kdata.input_buf.buf_addr);

	VATOOLS_DBG(
		priv, die_index,
		"sizeof(union vatools_ac_bench) %lu, sizeof(struct vatools_ac_bench_dma) %lu\n",
		sizeof(union vatools_ac_bench),
		sizeof(struct vatools_ac_bench_dma));

	write_len = kdata.input_buf.buf_size;
	read_len = kdata.output_buf.buf_size;
	if (write_len != sizeof(union vatools_ac_bench)) {
		VATOOLS_DBG(
			priv, die_index,
			"write len not equal to sizeof(union vatools_ac_bench), error\n");
		ret = -EFAULT;
		goto out;
	}
	ret = copy_from_user_ex((void *)&ac_bench_data,
				(void *)kdata.input_buf.buf_addr, write_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index,
			    "copy_from_user_ex ret=%ld ioctl_cmd= 0x%x\n", ret,
			    cmd);
		ret = -EFAULT;
		goto out;
	}

	switch (ac_bench_data.dma_info.ac_bench_dma_type) {
	case AC_BENCH_DMA_ALLOC: {
		ret = vatools_ac_bench_dma_alloc(&ac_bench_data.dma_info);
	} break;
	case AC_BENCH_DMA_FREE: {
		ret = vatools_ac_bench_dma_free(&ac_bench_data.dma_info, priv,
						die_index);
	} break;
	case AC_BENCH_DMA_START: {
		//ret = vatools_ac_bench_dma_start(&ac_bench_data.dma_info);
		ret = 0;
	} break;
	case AC_BENCH_DMA_P2P: {
		ret = vatools_ac_bench_dma_p2p(&ac_bench_data.dma_info);
	} break;
	case AC_BENCH_DMA_D2D: {
		ret = vatools_ac_bench_dma_d2d(&ac_bench_data.dma_info);
	} break;
	case AC_BENCH_COMPLEX_ROUTINE_TEST: {
		ret = vatools_ac_bench_dma_seq2seq(&ac_bench_data.dma_info);
	} break;
	default:
		VATOOLS_DBG(
			priv, die_index,
			"ac bench dma cmd type %u don't support in current system\n",
			ac_bench_data.dma_info.ac_bench_dma_type);
		ret = -EINVAL;
		break;
	}

	kdata.errcode = ret;
	ret = copy_to_user_ex(argp, &kdata, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index,
			    "copy_to_user_ex ret=%ld ioctl_cmd= 0x%x\n", ret,
			    cmd);
		ret = -EFAULT;
		goto out;
	}

	ret = copy_to_user_ex((void *)kdata.input_buf.buf_addr, &ac_bench_data,
			      write_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index,
			    "copy_from_user_ex ret=%ld ioctl_cmd= 0x%x\n", ret,
			    cmd);
		ret = -EFAULT;
		goto out;
	}

out:
	return ret;
}

static void set_die_weights_array(struct video_capability_manage *manager)
{
	struct vatools_node *node = vatools_get_node();
	uint32_t i = 0;
	uint32_t seq = 0;
	uint32_t type = 0;

	seq = manager->die_seq;
	type = manager->video_type;
	if (type == ALLOC_VIDEO_MAX) {
		while (i < ALLOC_VIDEO_MAX) {
			node->die_weights[i][seq].die_seq =
				(manager->die_weights[i][seq].die_seq ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights[i][seq].die_seq :
					manager->die_weights[i][seq].die_seq;
			node->die_weights[i][seq].die_weight =
				(manager->die_weights[i][seq].die_weight ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights[i][seq].die_weight :
					manager->die_weights[i][seq].die_weight;
			node->die_weights[i][seq].flag_encode_or_decode =
				(manager->die_weights[i][seq]
					 .flag_encode_or_decode ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights[i][seq]
						.flag_encode_or_decode :
					manager->die_weights[i][seq]
						.flag_encode_or_decode;

			node->die_weights_real[i][seq].die_seq =
				(manager->die_weights_real[i][seq].die_seq ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights_real[i][seq].die_seq :
					manager->die_weights_real[i][seq]
						.die_seq;
			node->die_weights_real[i][seq].die_weight =
				(manager->die_weights_real[i][seq].die_weight ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights_real[i][seq]
						.die_weight :
					manager->die_weights_real[i][seq]
						.die_weight;
			node->die_weights_real[i][seq].flag_encode_or_decode =
				(manager->die_weights_real[i][seq]
					 .flag_encode_or_decode ==
				 VATOOLS_UINT32_MAX) ?
					node->die_weights_real[i][seq]
						.flag_encode_or_decode :
					manager->die_weights_real[i][seq]
						.flag_encode_or_decode;
			i++;
		}
	} else {
		node->die_weights[type][seq].die_seq =
			(manager->die_weights[type][seq].die_seq ==
			 VATOOLS_UINT32_MAX) ?
				node->die_weights[type][seq].die_seq :
				manager->die_weights[type][seq].die_seq;
		node->die_weights[type][seq].die_weight =
			(manager->die_weights[type][seq].die_weight ==
			 VATOOLS_UINT32_MAX) ?
				node->die_weights[type][seq].die_weight :
				manager->die_weights[type][seq].die_weight;
		node->die_weights[type][seq].flag_encode_or_decode =
			(manager->die_weights[type][seq].flag_encode_or_decode ==
			 VATOOLS_UINT32_MAX) ?
				node->die_weights[type][seq]
					.flag_encode_or_decode :
				manager->die_weights[type][seq]
					.flag_encode_or_decode;

		node->die_weights_real[type][seq].die_seq =
			(manager->die_weights_real[type][seq].die_seq ==
			 VATOOLS_UINT32_MAX) ?
				node->die_weights_real[type][seq].die_seq :
				manager->die_weights_real[type][seq].die_seq;
		node->die_weights_real[type][seq].die_weight =
			(manager->die_weights_real[type][seq].die_weight ==
			 VATOOLS_UINT32_MAX) ?
				node->die_weights_real[type][seq].die_weight :
				manager->die_weights_real[type][seq].die_weight;
		node->die_weights_real[type][seq].flag_encode_or_decode =
			(manager->die_weights_real[type][seq]
				 .flag_encode_or_decode == VATOOLS_UINT32_MAX) ?
				node->die_weights_real[type][seq]
					.flag_encode_or_decode :
				manager->die_weights_real[type][seq]
					.flag_encode_or_decode;
	}
}

static void set_video_capability_manage(struct video_capability_manage *manager)
{
	struct vatools_reader *p_current_reader = NULL, *p_next_reader = NULL;
	struct vatools_node *node = vatools_get_node();

#ifdef CONFIG_TOOLS_V2
	mutex_lock(&node->node_reader_mutex);
#endif

	list_for_each_entry_safe (p_current_reader, p_next_reader,
				  &node->list_node_readers, list_readers) {
		if (p_current_reader->own_dies.die_seq == manager->die_seq) {
			p_current_reader->own_dies.die_seq = 0;
			p_current_reader->own_dies.die_weight = 0;
			p_current_reader->own_dies.flag_encode_or_decode = 0;
		}
	}
#ifdef CONFIG_TOOLS_V2
	mutex_unlock(&node->node_reader_mutex);
#endif
	set_die_weights_array(manager);
}
static long vatools_pcie_ioctl_pcie_video_manage(T_SMI_IOCTL_TRANS_DATA *pkdata,
						 struct vastai_pci_info *priv,
						 int die_index)
{
	long ret = -EINVAL;
	int write_len = 0;
	int read_len = 0;
	struct video_capability_manage *cap_manager = NULL;
	struct vatools_node *node = vatools_get_node();
	T_SMI_IOCTL_TRANS_DATA *kdata = pkdata;

	write_len = kdata->input_buf.buf_size;
	read_len = kdata->output_buf.buf_size;

	if (write_len != sizeof(struct video_capability_manage) ||
	    read_len < sizeof(struct video_capability_manage)) {
		VATOOLS_DBG(
			priv, die_index,
			"write/read len not equal to sizeof(struct video_capability_manage), error\n");
		ret = -EFAULT;
		goto out;
	}

	cap_manager = (struct video_capability_manage *)kvmalloc(
		sizeof(struct video_capability_manage), GFP_KERNEL);
	if (cap_manager == NULL) {
		VATOOLS_ERR(priv, die_index,
			    "malloc cap_manager buffer failed\n");
		ret = -EINVAL;
		goto out;
	}
	if (kdata->input_buf.buf_addr == 0 || kdata->output_buf.buf_addr == 0) {
		VATOOLS_DBG(priv, die_index, "buf_addr zero err\n");
		ret = -EINVAL;
		goto out_free;
	}

	ret = copy_from_user_ex((void *)cap_manager,
				(void *)kdata->input_buf.buf_addr, write_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex err\n");
		ret = -EFAULT;
		goto out_free;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"%s: die_seq %u, video_type %u, die_index 0x%x, sub_cmd %u\n",
		__func__, cap_manager->die_seq, cap_manager->video_type,
		cap_manager->die_index, cap_manager->sub_cmd);

	if (cap_manager->die_seq >= MAX_OCCUPY_DIE_NUM ||
	    cap_manager->video_type > ALLOC_VIDEO_MAX) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "%s: invalid param, die_seq %u, video_type %u\n",
			    __func__, cap_manager->die_seq,
			    cap_manager->video_type);
		ret = -EFAULT;
		goto out_free;
	}

	if (cap_manager->sub_cmd == VIDEO_CAPABILITY_READ) {
		memcpy((uint8_t *)cap_manager->die_weights,
		       (uint8_t *)(node->die_weights),
		       sizeof(struct vatools_occupy_die) * ALLOC_VIDEO_MAX *
			       MAX_OCCUPY_DIE_NUM);
		memcpy((uint8_t *)cap_manager->die_weights_real,
		       (uint8_t *)(node->die_weights_real),
		       sizeof(struct vatools_occupy_die) * ALLOC_VIDEO_MAX *
			       MAX_OCCUPY_DIE_NUM);
		if (copy_to_user_ex((void __user *)kdata->output_buf.buf_addr,
				    (uint8_t *)cap_manager,
				    sizeof(struct video_capability_manage))) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "%s: copy_to_user_ex ret=%ld\n", __func__,
				    ret);
			ret = -EFAULT;
			goto out_free;
		}
		ret = 0;
	} else if (cap_manager->sub_cmd == VIDEO_CAPABILITY_WRITE) {
		set_video_capability_manage(cap_manager);
		ret = 0;
	} else {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "%s: invalid param, cap_manager.sub_cmd  %u\n",
			    __func__, cap_manager->sub_cmd);
		ret = -EFAULT;
	}

out_free:
	kvfree(cap_manager);

out:
	return ret;
}

/*
 *vatools ioctl
 */

static loff_t vatools_llseek(struct file *filp, loff_t offset, int orig)
{
	loff_t ret = 0;
	struct vatools_node *node = vatools_file_get_node(filp);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(filp)].llseek(filp, offset,
							      orig);
	mutex_unlock(&node->node_mutex);
	return ret;
}

static ssize_t vatools_read(struct file *filp, char __user *buf, size_t size,
			    loff_t *pos)
{
	ssize_t ret = 0;
	struct vatools_node *node = vatools_file_get_node(filp);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	vatools_add_open_list(VATOOLS_READ);
	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(filp)].read(filp, buf, size,
							    pos);
	mutex_unlock(&node->node_mutex);
	vatools_del_open_list(VATOOLS_READ);
	return ret;
}

static ssize_t vatools_write(struct file *filp, const char __user *buf,
			     size_t size, loff_t *pos)
{
	ssize_t ret = size;
	struct vatools_node *node = NULL;
#ifdef VATOOLS_DRIVER_TEST_NODE
	char input[16] = { 0 };
#endif
	struct vatools_node *current_node = NULL, *next_node = NULL;

	//VATOOLS_FUNC_ENTER_INFO;
	list_for_each_entry_safe (current_node, next_node,
				  vatools_get_vastai_head(), list_nodes) {
		node = current_node;
	}

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		goto out;
	}

	vatools_add_open_list(VATOOLS_WRITE);
	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(filp)].write(filp, buf, size,
							     pos);

#ifdef VATOOLS_DRIVER_TEST_NODE
	ret = copy_from_user_ex(input, (void __user *)buf,
				min(size, sizeof(input)));
	if (ret < 0) {
		mutex_unlock(&node->node_mutex);
		goto out;
	}

	if (vatools_get_app_category(filp) == VATOOLS_APP_DUMMY &&
	    !strncmp(input, "ut_enable", strlen("ut_enable"))) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "vatools unit test enabled\n");
		atomic_set(&node->ut_enable, 1);
		tools_test_init(node);
	}

	if (vatools_get_app_category(filp) == VATOOLS_APP_DUMMY &&
	    !strncmp(input, "ut_disable", strlen("ut_disable"))) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vatools unit test disabled\n");
		atomic_set(&node->ut_enable, 0);
		tools_test_deinit(node);
	}
#endif
	mutex_unlock(&node->node_mutex);
	vatools_del_open_list(VATOOLS_WRITE);

	//VATOOLS_FUNC_EXIT_INFO;
out:
	ret = size;
	return ret;
}

static ssize_t vatools_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	ssize_t ret = 0;
	struct vatools_node *node = vatools_file_get_node(iocb->ki_filp);
	VATOOLS_FUNC_ENTER_INFO;
	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	vatools_add_open_list(VATOOLS_WRITE);
	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(iocb->ki_filp)].write_iter(
		iocb, from);
	mutex_unlock(&node->node_mutex);
	vatools_del_open_list(VATOOLS_WRITE);
	VATOOLS_FUNC_EXIT_INFO;
	return ret;
}

static unsigned int vatools_poll(struct file *filp,
				 struct poll_table_struct *wait)
{
	int ret = 0;
	struct vatools_node *node = vatools_file_get_node(filp);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(filp)].poll(filp, wait);
	mutex_unlock(&node->node_mutex);
	return ret;
}

#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
#if (TOOLS_WIN == 1)
static long long vatools_ioctl(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
#else
static long vatools_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
#endif
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	reader = vatools_file_get_reader(filp);
	if (!reader) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"ioctl cmd=0x%x node=0x%p filp=0x%p reader=0x%p is NULL\n",
			cmd, node, filp, reader);
		return ret;
	}

	if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
	    reader->trans_category.app_category != VATOOLS_APP_SHAREDMEM) {
		vatools_add_open_list(VATOOLS_IOCTL);
	}

	node = vatools_file_get_node(filp);
	if (!node) {
		if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
		    reader->trans_category.app_category !=
			    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_IOCTL);
		}
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"ioctl cmd=0x%x node=0x%p is NULL filp=0x%p reader=0x%p\n",
			cmd, node, filp, reader);
		return ret;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"[vatools_ioctl] [tgid:%d pid:%d] ioctl cmd=0x%x node=0x%p filp=%p reader=0x%p app_category=%d\n",
		current->tgid, current->pid, cmd, node, filp, reader,
		reader->trans_category.app_category);

	/*Specify the app_category according to the command, regardless of whether the user has set the app_category*/
	switch (cmd) {
	case VATOOLS_GENERAL_IOCTL_LOG_STATUS:
		reader->trans_category.app_category = VATOOLS_APP_LOGGER;
		break;
#ifdef CONFIG_TOOLS_V2
	case VATOOLS_IOCTL_V2_SMI_CMD:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_GET_DEVICE_INFO:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_PROFILER:
		reader->trans_category.app_category = VATOOLS_APP_PROFILER;
		break;
	case VATOOLS_IOCTL_V2_FLASH:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_GUARD:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_SHARE_MEM:
		reader->trans_category.app_category = VATOOLS_APP_SHAREDMEM;
		break;
	case VATOOLS_IOCTL_V2_VIDEO_DEBUGGER:
		reader->trans_category.app_category = VATOOLS_APP_DEBUGGER;
		break;
	case VATOOLS_IOCTL_V2_AI_DEBUGGER:
		reader->trans_category.app_category = VATOOLS_APP_DEBUGGER;
		break;
	case VATOOLS_IOCTL_V2_DEVICE_EVENT:
		reader->trans_category.app_category = VATOOLS_APP_EVENT;
		break;
	case VATOOLS_IOCTL_V2_CORE_TIME_SYNC:
		reader->trans_category.app_category = VATOOLS_APP_PROFILER;
		break;
#endif
	default:
		/*reader->trans_category.app_category = VATOOLS_APP_SMI;*/
		break;
	}

#ifdef CONFIG_TOOLS_V2
	/*V2 version ioctl*/
	ret = -0x0effffff; /*Impossible return value*/
	switch (cmd) {
		/*Test command*/
	case VATOOLS_IOCTL_V2_TEST: {
		/*ret = vatools_ioctl_test(filp, cmd, arg);*/
	} break;
		/*Process lock mechanism, prioritized*/
	case VATOOLS_IOCTL_V2_GUARD: {
		/*ret = vatools_ioctl_process_mutex_cmd(filp, cmd, arg);*/
	} break;
		/*Sets the category of the open file fd*/
	case VATOOLS_IOCTL_V2_SET_APP_CATEGORY: {
		/*ret = vatools_ioctl_set_app_category(filp, cmd, arg);*/
	} break;
		/*fetch device info*/
	case VATOOLS_IOCTL_V2_GET_DEVICE_INFO: {
		/*Cache after read, after setting the command, empty the cache and re-read*/
		ret = vatools_ioctl_v2_get_device_info(filp, cmd, arg);
	} break;
		/*Read and write data via SMI, write first, trigger an interrupt to SMCU, read later, read and write is done with a single call*/
	case VATOOLS_IOCTL_V2_SMI_CMD: {
		/*ret = vatools_ioctl_smi_cmd(filp, cmd, arg);*/
	} break;
		/*Read data in a normal way; Use only vastai_pcie reads; The address translation judgment is done in host/common*/
	case VATOOLS_IOCTL_V2_READ_BUF: {
		/*ret = vatools_ioctl_read_buf(filp, cmd, arg);*/
	} break;
		/*Write data in normal mode; Use only vastai_pcie writes; The address translation judgment is done in host/common*/
	case VATOOLS_IOCTL_V2_WRITE_BUF: {
		/*ret = vatools_ioctl_write_buf(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_PCIE_CMD: {
		/*ret = vatools_ioctl_pcie_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_PROFILER: {
		/*ret = vatools_ioctl_profiler_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_FLASH: {
		ret = vatools_ioctl_flash_cmd(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_SHARE_MEM: {
		/*ret = vatools_ioctl_sharedmem_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_AI_DEBUGGER: {
		/*ret = vatools_ioctl_ai_debugger_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_CORE_TIME_SYNC: {
		/*ret = vatools_ioctl_core_time_sync_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_LOG_STATUS: {
		/*ret = vatools_ioctl_get_log_status_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_DMA: {
		/*ret = vatools_ioctl_dma_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_BASE_INFO: {
		ret = vatools_ioctl_get_base_info(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_VIDEO_CAPABILITY_ALLOC_FREE: {
		ret = vatools_ioctl_video_capability_query(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_TXY_DMA_TEST: {
		ret = vatools_ioctl_ac_bench_test(filp, cmd, arg);
	} break;
	default: {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "[vatools_ioctl] unknown v2 ioctl cmd 0x%x\n", cmd);
		break;
	}
	}
	if (ret != -0x0effffff) {
		if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
		    reader->trans_category.app_category !=
			    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_IOCTL);
		}
		reader->ioctl_version = VATOOLS_IOCTL_V2_MAGIC;
		/*exit ioctl v2 here*/
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "[vatools_ioctl] v2 ioctl cmd 0x%x return %ld\n",
			    cmd, ret);
		return ret;
	}
/*V2 version ioctl come to an end*/
#endif

	mutex_lock(&node->node_mutex);
	mutex_lock(&node->node_sharedmem_mutex);
	switch (cmd) {
	case VATOOLS_GENERAL_IOCTL_TEST:
		ret = vatools_ioctl_test(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY:
		ret = vatools_set_app_category(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEVICE_NUM:
		ret = vatools_get_device_num(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEV_INFO:
		ret = vatools_get_dev_info(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DIE_INFO:
		ret = vatools_get_die_info(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_READ:
		ret = vatools_driver_read(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_WRITE:
		ret = vatools_driver_write(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_FETCH:
		ret = vatools_driver_smi_fetch(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEV_PCIE_BUS_ID:
		ret = vatools_get_dev_pcie_bus_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_PCIE_ID:
		ret = vatools_get_dev_pcie_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_PCIE_SUB_ID:
		ret = vatools_get_dev_pcie_sub_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_MAJOR_MINOR_ID:
		ret = vatools_get_dev_major_minor_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DIE_RENDER:
		ret = vatools_get_die_render(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_PCIE:
		ret = vatools_pcie_ioctl(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_DEVICE_CAPABILITY:
		ret = vatools_get_device_capability(filp, cmd, arg);
		break;

		/*Allocate DMA memory*/
	case VATOOLS_GENERAL_IOCTL_DMA_ALLOC:
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);
		ret = vatools_ioctl_dma_alloc(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DMA_FREE:
		ret = vatools_ioctl_dma_free(filp, cmd, arg);
		break;
		/*Start DMA transfer data*/
	case VATOOLS_GENERAL_IOCTL_DMA_START:
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);
		ret = vatools_ioctl_dma_start(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DMA_TRANS:
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);
		ret = vatools_ioctl_dma_trans(filp, cmd, arg);
		goto out;
		break;

		/*Read data in the normal way*/
	case VATOOLS_GENERAL_IOCTL_READ_BUF:
		ret = vatools_ioctl_read_reg_buf(filp, cmd, arg);
		break;

		/*Write data in normal mode*/
	case VATOOLS_GENERAL_IOCTL_WRITE_BUF:
		ret = vatools_ioctl_write_reg_buf(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_GET_BMCU_XSPI_VERSION:
		ret = vatools_ioctl_get_bmcu_xspi_ver(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_SRIOV_NUMBER:
		ret = vatools_ioctl_get_sriov_number(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_FLASH_BMCU_FW:
		ret = vatools_ioctl_flash_bmcu_fw(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_FLASH_XSPI_FW:
		ret = vatools_ioctl_flash_xspi_fw(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_GET_FLASH_STA:
		ret = vatools_ioctl_flash_sta(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_SWITCH_BMCU:
		ret = vatools_ioctl_bmcu_switch(filp, cmd, arg);
		break;
		/*core timestamp sync*/
	case VATOOLS_GENERAL_IOCTL_CORE_TIME_SYNC:
		ret = vatools_ioctl_core_time_sync(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_DEVICE_EVENT:
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);
		ret = vatools_ioctl_device_event(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DEVICE_EVENT_SELECT:
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);
		ret = vatools_ioctl_device_event_select(filp, cmd, arg);
		goto out;
		break;
		/*Read data by fnread*/
	case VATOOLS_GENERAL_IOCTL_FNREAD_BUF:
		ret = vatools_ioctl_fnread_reg_buf(filp, cmd, arg);
		break;
		/*Write data by fnwrite*/
	case VATOOLS_GENERAL_IOCTL_FNWRITE_BUF:
		ret = vatools_ioctl_fnwrite_reg_buf(filp, cmd, arg);
		break;

	default:
		/*Only when shared_memory is used for internal lock control, and the rest of the original process is not considered concurrency*/
		/*logger uses its own ioctl and mutex*/
		if (reader->trans_category.app_category ==
			    VATOOLS_APP_SHAREDMEM ||
		    reader->trans_category.app_category == VATOOLS_APP_LOGGER ||
		    VATOOLS_GENERAL_IOCTL_LOG_STATUS == cmd) {
			mutex_unlock(&node->node_sharedmem_mutex);
			mutex_unlock(&node->node_mutex);
		}

		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"[vatools_ioctl] ioctl_cmd=0x%X run app_fops.ioctl\n",
			cmd);

		ret = app_fops[vatools_get_app_category(filp)].unlocked_ioctl(
			filp, cmd, arg);
		if (reader->trans_category.app_category ==
			    VATOOLS_APP_SHAREDMEM ||
		    reader->trans_category.app_category == VATOOLS_APP_LOGGER ||
		    VATOOLS_GENERAL_IOCTL_LOG_STATUS == cmd) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "[vatools_ioctl] ioctl return %ld\n", ret);

			vatools_del_open_list(VATOOLS_IOCTL);
			return ret;
		} else {
			break;
		}
	}
	mutex_unlock(&node->node_sharedmem_mutex);
	mutex_unlock(&node->node_mutex);

	vatools_del_open_list(VATOOLS_IOCTL);
out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "[vatools_ioctl] ioctl return %ld\n",
		    ret);
	return ret;
}
#else
#if (TOOLS_WIN == 1)
static long long vatools_ioctl(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
#else
static long vatools_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
#endif
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	reader = vatools_file_get_reader(filp);
	if (!reader) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"ioctl cmd=0x%x node=0x%p filp=0x%p reader=0x%p is NULL\n",
			cmd, node, filp, reader);
		return ret;
	}

	if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
	    reader->trans_category.app_category != VATOOLS_APP_SHAREDMEM) {
		vatools_add_open_list(VATOOLS_IOCTL);
	}
	node = vatools_file_get_node(filp);
	if (!node) {
		if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
		    reader->trans_category.app_category !=
			    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_IOCTL);
		}
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"ioctl cmd=0x%x node=0x%p is NULL filp=0x%p reader=0x%p\n",
			cmd, node, filp, reader);
		return ret;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"[vatools_ioctl] [tgid:%d pid:%d] ioctl cmd=0x%x node=0x%p filp=%p reader=0x%p app_category=%d\n",
		current->tgid, current->pid, cmd, node, filp, reader,
		reader->trans_category.app_category);

	/*Specify the app_category according to the command, regardless of whether the user has set the app_category*/
	switch (cmd) {
	case VATOOLS_GENERAL_IOCTL_LOG_STATUS:
		reader->trans_category.app_category = VATOOLS_APP_LOGGER;
		break;
#ifdef CONFIG_TOOLS_V2
	case VATOOLS_IOCTL_V2_SMI_CMD:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_GET_DEVICE_INFO:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_PROFILER:
		reader->trans_category.app_category = VATOOLS_APP_PROFILER;
		break;
	case VATOOLS_IOCTL_V2_FLASH:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_GUARD:
		reader->trans_category.app_category = VATOOLS_APP_SMI;
		break;
	case VATOOLS_IOCTL_V2_SHARE_MEM:
		reader->trans_category.app_category = VATOOLS_APP_SHAREDMEM;
		break;
	case VATOOLS_IOCTL_V2_VIDEO_DEBUGGER:
		reader->trans_category.app_category = VATOOLS_APP_DEBUGGER;
		break;
	case VATOOLS_IOCTL_V2_AI_DEBUGGER:
		reader->trans_category.app_category = VATOOLS_APP_DEBUGGER;
		break;
	case VATOOLS_IOCTL_V2_DEVICE_EVENT:
		reader->trans_category.app_category = VATOOLS_APP_EVENT;
		break;
	case VATOOLS_IOCTL_V2_CORE_TIME_SYNC:
		reader->trans_category.app_category = VATOOLS_APP_PROFILER;
		break;
#endif
	default:
		/*reader->trans_category.app_category = VATOOLS_APP_SMI;*/
		break;
	}

#ifdef CONFIG_TOOLS_V2
	/*V2 version ioctl*/
	ret = -0x0effffff; /*Impossible return value*/
	switch (cmd) {
		/*Test command*/
	case VATOOLS_IOCTL_V2_TEST: {
		/*ret = vatools_ioctl_test(filp, cmd, arg);*/
	} break;
		/*Process lock mechanism, prioritized*/
	case VATOOLS_IOCTL_V2_GUARD: {
		/*ret = vatools_ioctl_process_mutex_cmd(filp, cmd, arg);*/
	} break;
		/*Sets the category of the open file fd*/
	case VATOOLS_IOCTL_V2_SET_APP_CATEGORY: {
		/*ret = vatools_ioctl_set_app_category(filp, cmd, arg);*/
	} break;
		/*fetch device info*/
	case VATOOLS_IOCTL_V2_GET_DEVICE_INFO: {
		/*Cache after read, after setting the command, empty the cache and re-read*/
		ret = vatools_ioctl_v2_get_device_info(filp, cmd, arg);
	} break;
		/*Read and write data via SMI, write first, trigger an interrupt to SMCU, read later, read and write is done with a single call*/
	case VATOOLS_IOCTL_V2_SMI_CMD: {
		/*ret = vatools_ioctl_smi_cmd(filp, cmd, arg);*/
	} break;
		/*Read data in a normal way; Use only vastai_pcie reads; The address translation judgment is done in host/common*/
	case VATOOLS_IOCTL_V2_READ_BUF: {
		/*ret = vatools_ioctl_read_buf(filp, cmd, arg);*/
	} break;
		/*Write data in normal mode; Use only vastai_pcie writes; The address translation judgment is done in host/common*/
	case VATOOLS_IOCTL_V2_WRITE_BUF: {
		/*ret = vatools_ioctl_write_buf(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_PCIE_CMD: {
		/*ret = vatools_ioctl_pcie_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_PROFILER: {
		/*ret = vatools_ioctl_profiler_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_FLASH: {
		ret = vatools_ioctl_flash_cmd(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_SHARE_MEM: {
		/*ret = vatools_ioctl_sharedmem_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_AI_DEBUGGER: {
		/*ret = vatools_ioctl_ai_debugger_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_CORE_TIME_SYNC: {
		/*ret = vatools_ioctl_core_time_sync_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_LOG_STATUS: {
		/*ret = vatools_ioctl_get_log_status_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_DMA: {
		/*ret = vatools_ioctl_dma_cmd(filp, cmd, arg);*/
	} break;
	case VATOOLS_IOCTL_V2_BASE_INFO: {
		ret = vatools_ioctl_get_base_info(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_VIDEO_CAPABILITY_ALLOC_FREE: {
		ret = vatools_ioctl_video_capability_query(filp, cmd, arg);
	} break;
	case VATOOLS_IOCTL_V2_TXY_DMA_TEST: {
		ret = vatools_ioctl_ac_bench_test(filp, cmd, arg);
	} break;
	default: {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "[vatools_ioctl] unknown v2 ioctl cmd 0x%x\n", cmd);
		break;
	}
	}
	if (ret != -0x0effffff) {
		if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
		    reader->trans_category.app_category !=
			    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_IOCTL);
		}
		reader->ioctl_version = VATOOLS_IOCTL_V2_MAGIC;
		/*exit ioctl v2 here*/
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "[vatools_ioctl] v2 ioctl cmd 0x%x return %ld\n",
			    cmd, ret);
		return ret;
	}
/*V2 version ioctl come to an end*/
#endif

	switch (cmd) {
	case VATOOLS_GENERAL_IOCTL_TEST:
		ret = vatools_ioctl_test(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY:
		ret = vatools_set_app_category(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEVICE_NUM:
		ret = vatools_get_device_num(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEV_INFO:
		ret = vatools_get_dev_info(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DIE_INFO:
		ret = vatools_get_die_info(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_READ:
		ret = vatools_driver_read(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_WRITE:
		ret = vatools_driver_write(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_FETCH:
		ret = vatools_driver_smi_fetch(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DEV_PCIE_BUS_ID:
		ret = vatools_get_dev_pcie_bus_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_PCIE_ID:
		ret = vatools_get_dev_pcie_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_PCIE_SUB_ID:
		ret = vatools_get_dev_pcie_sub_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_MAJOR_MINOR_ID:
		ret = vatools_get_dev_major_minor_id(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_GET_DIE_RENDER:
		ret = vatools_get_die_render(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_PCIE:
		ret = vatools_pcie_ioctl(filp, cmd, arg);
		break;

	case VATOOLS_GENERAL_IOCTL_DEVICE_CAPABILITY:
		ret = vatools_get_device_capability(filp, cmd, arg);
		break;

		/*Allocate DMA memory*/
	case VATOOLS_GENERAL_IOCTL_DMA_ALLOC:
		ret = vatools_ioctl_dma_alloc(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DMA_FREE:
		ret = vatools_ioctl_dma_free(filp, cmd, arg);
		break;
		/*Start DMA transfer data*/
	case VATOOLS_GENERAL_IOCTL_DMA_START:
		ret = vatools_ioctl_dma_start(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DMA_TRANS:
		ret = vatools_ioctl_dma_trans(filp, cmd, arg);
		goto out;
		break;

		/*Read data in the normal way*/
	case VATOOLS_GENERAL_IOCTL_READ_BUF:
		ret = vatools_ioctl_read_reg_buf(filp, cmd, arg);
		break;

		/*Write data in normal mode*/
	case VATOOLS_GENERAL_IOCTL_WRITE_BUF:
		ret = vatools_ioctl_write_reg_buf(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_GET_BMCU_XSPI_VERSION:
		ret = vatools_ioctl_get_bmcu_xspi_ver(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_SRIOV_NUMBER:
		ret = vatools_ioctl_get_sriov_number(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_FLASH_BMCU_FW:
		ret = vatools_ioctl_flash_bmcu_fw(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_FLASH_XSPI_FW:
		ret = vatools_ioctl_flash_xspi_fw(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_GET_FLASH_STA:
		ret = vatools_ioctl_flash_sta(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_SWITCH_BMCU:
		ret = vatools_ioctl_bmcu_switch(filp, cmd, arg);
		break;
		/*core timestamp sync*/
	case VATOOLS_GENERAL_IOCTL_CORE_TIME_SYNC:
		ret = vatools_ioctl_core_time_sync(filp, cmd, arg);
		break;
	case VATOOLS_GENERAL_IOCTL_DEVICE_EVENT:
		ret = vatools_ioctl_device_event(filp, cmd, arg);
		goto out;
		break;
	case VATOOLS_GENERAL_IOCTL_DEVICE_EVENT_SELECT:
		ret = vatools_ioctl_device_event_select(filp, cmd, arg);
		goto out;
		break;
		/*Read data by fnread*/
	case VATOOLS_GENERAL_IOCTL_FNREAD_BUF:
		ret = vatools_ioctl_fnread_reg_buf(filp, cmd, arg);
		break;
		/*Write data by fnwrite*/
	case VATOOLS_GENERAL_IOCTL_FNWRITE_BUF:
		ret = vatools_ioctl_fnwrite_reg_buf(filp, cmd, arg);
		break;

	default:

		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"[vatools_ioctl] ioctl_cmd=0x%X run app_fops.ioctl\n",
			cmd);

		ret = app_fops[vatools_get_app_category(filp)].unlocked_ioctl(
			filp, cmd, arg);
		if (reader->trans_category.app_category ==
			    VATOOLS_APP_SHAREDMEM ||
		    reader->trans_category.app_category == VATOOLS_APP_LOGGER ||
		    VATOOLS_GENERAL_IOCTL_LOG_STATUS == cmd) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "[vatools_ioctl] ioctl return %ld\n", ret);

			if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
			    reader->trans_category.app_category !=
				    VATOOLS_APP_SHAREDMEM) {
				vatools_del_open_list(VATOOLS_IOCTL);
			}
			return ret;
		} else {
			break;
		}
	}
	if (VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY != cmd &&
	    reader->trans_category.app_category != VATOOLS_APP_SHAREDMEM) {
		vatools_del_open_list(VATOOLS_IOCTL);
	}
out:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "[vatools_ioctl] ioctl return %ld\n",
		    ret);
	return ret;
}
#endif

static int vatools_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	int ret = 0;
	struct vatools_node *node = vatools_file_get_node(filp);
	V_UNREFERENCE(pvm);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	mutex_lock(&node->node_mutex);
	ret = app_fops[vatools_get_app_category(filp)].mmap(filp, pvm);
	mutex_unlock(&node->node_mutex);

	return ret;
}

#ifdef VATOOLS_HOT_PLUG_ENABLE
atomic_t g_rmmod_pid;
static int vatools_add_open_list(enum va_f_type type)
{
	struct vatools_pid_entry *pid_entry = NULL;
	struct vatools_pid_entry *pid_loop = NULL;
	struct vatools_pid_entry *temp = NULL;
	int pidnr = 0;

	pidnr = pid_nr(task_pid(current));
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "[hotplug add_pid] pidnr %d\n", pidnr);

	if (pidnr == atomic_read(&g_rmmod_pid) &&
	    atomic_read(&g_rmmod_pid) != 0)
		return 0;

	mutex_lock(&g_mutex_open_list);
	list_for_each_entry_safe (pid_loop, temp, &vatools_open_list, node) {
		if (pid_loop->nr_pid == pidnr) {
			pid_loop->refcount++;

			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"[hotplug re_add_pid] pid %d already there\n",
				pidnr);

			mutex_unlock(&g_mutex_open_list);

			return 0;
		}
	}

	pid_entry = vmalloc(sizeof(struct vatools_pid_entry));
	if (!pid_entry) {
		VATOOLS_INFO(
			NULL, DUMMY_DIE_ID,
			"[vatools_add_open_list] open list kzalloc error\n");
		mutex_unlock(&g_mutex_open_list);
		return -ENOMEM;
	}
	pid_entry->pid = task_pid(current);
	pid_entry->nr_pid = pidnr;
	pid_entry->refcount = 1;
	pid_entry->type = type;

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "[hotplug real_add_pid] pid %d new added\n", pidnr);
	list_add(&pid_entry->node, &vatools_open_list);
	get_pid(pid_entry->pid);
	mutex_unlock(&g_mutex_open_list);

	return 0;
}
#else
static int vatools_add_open_list(enum va_f_type type)
{
	V_UNREFERENCE(type);
	return 0;
}
#endif

#ifdef VATOOLS_HOT_PLUG_ENABLE
static void vatools_del_open_list(enum va_f_type type)
{
	struct vatools_pid_entry *pid_loop = NULL;
	struct vatools_pid_entry *temp = NULL;
	int pidnr = 0;

	pidnr = pid_nr(task_pid(current));

	mutex_lock(&g_mutex_open_list);
	list_for_each_entry_safe (pid_loop, temp, &vatools_open_list, node) {
		if (pid_loop->nr_pid == pidnr) {
			pid_loop->refcount--;
			list_del(&pid_loop->node);
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "[hotplug rm_pid] pid %d refcount %d\n",
				    pidnr, pid_loop->refcount);
			put_pid(pid_loop->pid);
			vfree(pid_loop);
			mutex_unlock(&g_mutex_open_list);
			return;
		}
	}

	mutex_unlock(&g_mutex_open_list);
}
#else
static void vatools_del_open_list(enum va_f_type type)
{
	V_UNREFERENCE(type);
}
#endif

static int vatools_open(struct inode *inode, struct file *filp)
{
	struct vatools_node *node = NULL;
	int ret;
	struct vatools_reader *reader = NULL;

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	V_UNREFERENCE(inode);
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"[vatools_open] [tgid:%d pid:%d] inode=%p filp=%p f_mode=0x%x\n",
		current->tgid, current->pid, inode, filp, filp->f_mode);

	ret = nonseekable_open(inode, filp);
	if (ret) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "[vatools_open] nonseekable_open ret=%d\n", ret);
		return ret;
	}

	node = vatools_get_node_from_minor(MINOR(inode->i_rdev));
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "[vatools_open] vatools_node *node=0x%p\n", node);

	if (!node) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "[vatools_open] node is NULL\n");
		return -ENODEV;
	}

	reader = (struct vatools_reader *)kvmalloc(
		sizeof(struct vatools_reader), GFP_KERNEL);
	if (!reader) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "[vatools_open] kvmalloc error. size=%ld\n",
			    sizeof(struct vatools_reader));
		return -ENOMEM;
	}

	memset(reader, 0, sizeof(struct vatools_reader));

	reader->node = node;
	reader->r_ver = 0;
#if (TOOLS_WIN == 1)
	reader->r_all = 0;
#else
	reader->r_all = in_egroup_p(inode->i_gid) || capable(CAP_SYSLOG);
#endif
	reader->profiler_checkpoint_corebitmap = 0;
	reader->event_timestamp_ns = 0;

	/*Set the default value*/
	reader->trans_category.app_category = VATOOLS_APP_DUMMY;
	reader->trans_category.block_id = SMI_CMD_BLOCK_ID_0;
	reader->trans_category.device.dev_id = 0; /*0x7 ffffffff;*/
	reader->trans_category.device.die_id = 0; /*0x7 ffffffff;*/
	reader->trans_category.device.die_index = 0; /*0x7 ffffffff;*/
	reader->event_timestamp_ns = 0;
#ifdef CONFIG_TOOLS_V2
	mutex_lock(&node->node_reader_mutex);
#else
	mutex_lock(&node->node_mutex);
#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_lock(&node->node_sharedmem_mutex);
#endif
#endif
	INIT_LIST_HEAD(&reader->list_readers);
	list_add_tail(&reader->list_readers, &node->list_node_readers);
	filp->private_data = reader;
#ifdef CONFIG_TOOLS_V2
	mutex_unlock(&node->node_reader_mutex);
#else
#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_unlock(&node->node_sharedmem_mutex);
#endif
	mutex_unlock(&node->node_mutex);
#endif

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "[vatools_open] node=0x%p  reader=0x%p\n", node, reader);

	VATOOLS_FUNC_EXIT;
	return 0;
}

#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
static int vatools_release(struct inode *ignored, struct file *filp)
{
	struct vatools_node *node = vatools_file_get_node(filp);
	struct vatools_reader *reader = vatools_file_get_reader(filp);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}
	V_UNREFERENCE(ignored);
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"[vatools_release] [tgid:%d pid:%d] node=0x%p filp=0x%p f_mode=0x%x\n",
		current->tgid, current->pid, node, filp, filp->f_mode);

#ifdef CONFIG_TOOLS_V2
	/*if (reader->ioctl_version == VATOOLS_IOCTL_V2_MAGIC)*/
	{
		/*TODO: Preferentially release interprocess locks mutex*/
		/*vatools_process_release_mutex_unlock(filp, 0x0, 0x0, NULL, NULL);*/

		mutex_lock(&node->node_mutex);
		mutex_lock(&node->node_sharedmem_mutex);
		mutex_lock(&node->node_reader_mutex);
		app_fops[vatools_get_app_category(filp)].release(ignored, filp);
		reader = (struct vatools_reader *)filp->private_data;

		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_add_open_list(VATOOLS_CLOSE);
		}
		if (reader) {
			/*pr_info( "vatools_release reader=%p\n", reader );*/
			list_del(&reader->list_readers);
			kvfree(reader);
			filp->private_data = NULL;
		}
		mutex_unlock(&node->node_reader_mutex);
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);

		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_CLOSE);
		}
	}
#else
	{
		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_add_open_list(VATOOLS_CLOSE);
		}

		mutex_lock(&node->node_mutex);
		mutex_lock(&node->node_sharedmem_mutex);
		app_fops[vatools_get_app_category(filp)].release(ignored, filp);
		reader = (struct vatools_reader *)filp->private_data;
		if (reader) {
			/*pr_info( "vatools_release reader=%p\n", reader );*/
			list_del(&reader->list_readers);
			kvfree(reader);
			filp->private_data = NULL;
		}
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);

		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_del_open_list(VATOOLS_CLOSE);
		}
	}
#endif
	VATOOLS_FUNC_EXIT;
	return 0;
}
#else
static int vatools_release(struct inode *ignored, struct file *filp)
{
	struct vatools_node *node = vatools_file_get_node(filp);
	struct vatools_reader *reader = vatools_file_get_reader(filp);

#if 0
	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}
#endif
	V_UNREFERENCE(ignored);
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"[vatools_release] [tgid:%d pid:%d] node=0x%p filp=0x%p f_mode=0x%x\n",
		current->tgid, current->pid, node, filp, filp->f_mode);

#ifdef CONFIG_TOOLS_V2
	/*if (reader->ioctl_version == VATOOLS_IOCTL_V2_MAGIC)*/
	{
		/*TODO: Preferentially release interprocess locks mutex*/
		/*vatools_process_release_mutex_unlock(filp, 0x0, 0x0, NULL, NULL);*/

		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_add_open_list(VATOOLS_CLOSE);
		}

		if (reader->trans_category.app_category ==
		    VATOOLS_APP_SHAREDMEM) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: line %d\n",
				    __func__, __LINE__);
			app_fops[vatools_get_app_category(filp)].release(
				ignored, filp);

		} else {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "%s: line %d\n",
				    __func__, __LINE__);
			mutex_lock(&node->node_mutex);
			mutex_lock(&node->node_reader_mutex);
			app_fops[vatools_get_app_category(filp)].release(
				ignored, filp);
			reader = (struct vatools_reader *)filp->private_data;
			if (reader) {
				if (reader->trans_category.app_category !=
				    VATOOLS_APP_SHAREDMEM) {
					vatools_del_open_list(VATOOLS_CLOSE);
				}
				/*pr_info( "vatools_release reader=%p\n", reader );*/
				list_del(&reader->list_readers);
				kvfree(reader);
				filp->private_data = NULL;
			}
			mutex_unlock(&node->node_reader_mutex);
			mutex_unlock(&node->node_mutex);
		}
	}
#else
	{
		if (reader->trans_category.app_category !=
		    VATOOLS_APP_SHAREDMEM) {
			vatools_add_open_list(VATOOLS_CLOSE);
		}

		mutex_lock(&node->node_mutex);
		mutex_lock(&node->node_sharedmem_mutex);
		app_fops[vatools_get_app_category(filp)].release(ignored, filp);
		reader = (struct vatools_reader *)filp->private_data;
		if (reader) {
			/*pr_info( "vatools_release reader=%p\n", reader );*/
			list_del(&reader->list_readers);
			kvfree(reader);
			filp->private_data = NULL;
		}
		mutex_unlock(&node->node_sharedmem_mutex);
		mutex_unlock(&node->node_mutex);

		vatools_del_open_list(VATOOLS_CLOSE);
	}
#endif
	VATOOLS_FUNC_EXIT;
	return 0;
}
#endif

static int vatools_fasync(int fd, struct file *filp, int mode)
{
	int ret = 0;
	struct vatools_node *node = vatools_file_get_node(filp);

	if (atomic_read(&_vatools_in_kill_routine) == 1) {
		return -EFAULT;
	}

	mutex_lock(&node->node_mutex);
#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_lock(&node->node_sharedmem_mutex);
#endif
	/*pr_info( "vatools_fasync reader " );*/
	ret = app_fops[vatools_get_app_category(filp)].fasync(fd, filp, mode);
#ifndef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_unlock(&node->node_sharedmem_mutex);
#endif
	mutex_unlock(&node->node_mutex);
	return ret;
}

static const struct file_operations vatools_fops = {
	.owner = THIS_MODULE,
	.llseek = vatools_llseek,
	.read = vatools_read,
	.write = vatools_write,
	.write_iter = vatools_write_iter,
	.poll = vatools_poll,
	.unlocked_ioctl = vatools_ioctl,
	.compat_ioctl = vatools_ioctl,
	.mmap = vatools_mmap,
	.open = vatools_open,
	.release = vatools_release,
	.fasync = vatools_fasync,
};

char *tools_node_name = "vatools";
static struct class *toolsclass;

#if KERNEL_VERSION(6, 2, 0) > LINUX_VERSION_CODE
static char *set_devnode(struct device *dev, umode_t *mode)
{
	if (mode)
		*mode = 0666; // set /dev/mydevice right: 0666
	return NULL;
}
#else
static char *set_devnode(const struct device *dev, umode_t *mode)
{
	if (mode)
		*mode = 0666; // set /dev/mydevice right: 0666
	return NULL;
}
#endif

/*
 *
 */
static int create_node(void *pci_dev, const char *node_name, int size)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	unsigned char *buffer = NULL;
	struct vastai_fifo *fifo = NULL;
	char vatools_dev_name[VATOOLS_DEVICE_NAME_LEN] = { 0 };
	struct vastai_pci_info *priv = (struct vastai_pci_info *)pci_dev;
	VATOOLS_FUNC_ENTERY;

#ifdef VATOOLS_HOT_PLUG_ENABLE
	atomic_set(&g_rmmod_pid, 0);
#endif
	buffer = (unsigned char *)kvmalloc(size, GFP_KERNEL);
	if (buffer == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "[create_node] kvmalloc error. size=%d\n", size);
		return -ENOMEM;
	}

	node = (struct vatools_node *)kzalloc(sizeof(struct vatools_node),
					      GFP_KERNEL);
	if (node == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "[create_node] node is NULL\n");
		ret = -ENOMEM;
		goto out_free_buffer;
	}

	memset(vatools_dev_name, 0, sizeof(char) * VATOOLS_DEVICE_NAME_LEN);
	sprintf(vatools_dev_name, "%s", node_name);

	node->node_buffer = buffer;
	node->size = size;
	node->pci_dev = pci_dev;

	atomic_set(&node->ut_enable, 0);

	node->dev_info = NULL;

	mutex_init(&node->rt_buf_mutex);
	node->rt_info_head_buf = kvmalloc(RT_INFO_HEAD_BUF_SIZE, GFP_KERNEL);
	if (node->rt_info_head_buf == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "rt_info_head_buf kvmalloc fail\n");
		ret = -ENOMEM;
		goto out_free_node;
	}
	node->rt_zone_usage_buf = kvmalloc(RT_ZONE_USAGE_BUF_SIZE, GFP_KERNEL);
	if (node->rt_zone_usage_buf == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "rt_zone_usage_buf kvmalloc fail\n");
		ret = -ENOMEM;
		goto out_free_rt_info_head_buf;
	}
	node->rt_process_info_buf =
		kvmalloc(RT_PROCESS_INFO_BUF_SIZE, GFP_KERNEL);
	if (node->rt_process_info_buf == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "rt_process_info_buf kvmalloc fail\n");
		ret = -ENOMEM;
		goto out_free_rt_zone_usage_buf;
	}
	node->rt_vacc_process_info_buf =
		kvmalloc(RT_VACC_PROCESS_INFO_BUF_SIZE, GFP_KERNEL);
	if (node->rt_vacc_process_info_buf == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "rt_vacc_process_info_buf kvmalloc fail\n");
		ret = -ENOMEM;
		goto out_free_rt_process_info_buf;
	}

	init_waitqueue_head(&node->wq);
	INIT_LIST_HEAD(&node->list_node_readers);
	mutex_init(&node->inventory_cache_mutex);
	mutex_init(&node->node_mutex);
	mutex_init(&node->node_sharedmem_mutex);
	mutex_init(&node->node_common_mutex);
	mutex_init(&node->node_profiler_mutex);
	mutex_init(&node->node_debugger_mutex);
	mutex_init(&node->node_logger_mutex);
	mutex_init(&node->node_smi_mutex);
#ifdef CONFIG_TOOLS_V2
	mutex_init(&node->node_dummy_mutex);
	mutex_init(&node->node_driver_mutex);
	mutex_init(&node->node_reader_mutex);
#endif
	mutex_init(&pcie_timeline_dma_mutex);
	mutex_init(&pcie_timeline_msg_mutex);
	mutex_init(&pcie_timeline_app_mutex);
	mutex_init(&sharedmem_weight_mutex);

	/*init timeline of pci dma*/
	node->profiler_dma_ringbuf = vmalloc(PROFILER_PCI_DMA_FIFO_LENGTH);
	if (node->profiler_dma_ringbuf == NULL) {
		VATOOLS_ERR(
			NULL, DUMMY_DIE_ID,
			"[create_node] profile dma ringbuf is NULL. need len=%d\n",
			PROFILER_PCI_DMA_FIFO_LENGTH);
		ret = -ENOMEM;
		goto out_free_rt_vacc_process_info_buf;
	}
	gp_profiler_dma_fifo = node->profiler_dma_ringbuf;
	fifo = (struct vastai_fifo *)node->profiler_dma_ringbuf;
	fifo->elem_count =
		(PROFILER_PCI_DMA_FIFO_LENGTH - sizeof(struct vastai_fifo)) /
		sizeof(profiler_dma_checkpoint_t);
	fifo->elem_size = sizeof(profiler_dma_checkpoint_t);
	/*Spin lock init(&node >DMA ringbuff lock of profile);*/

	/*init timeline of pci msg*/
	node->profiler_msg_ringbuf = vmalloc(PROFILER_PCI_MSG_FIFO_LENGTH);
	if (node->profiler_msg_ringbuf == NULL) {
		VATOOLS_ERR(
			NULL, DUMMY_DIE_ID,
			"[create_node] profile msg ringbuf is NULL. need len=%d\n",
			PROFILER_PCI_MSG_FIFO_LENGTH);
		ret = -ENOMEM;
		goto out_free_dma_fifo;
	}
	gp_profiler_msg_fifo = node->profiler_msg_ringbuf;
	fifo = (struct vastai_fifo *)node->profiler_msg_ringbuf;
	fifo->elem_count =
		(PROFILER_PCI_MSG_FIFO_LENGTH - sizeof(struct vastai_fifo)) /
		sizeof(profiler_msg_checkpoint_t);
	fifo->elem_size = sizeof(profiler_msg_checkpoint_t);
	/*spin lock init(&node >profile msg ringbuf lock);*/

	/*init event ringbuf*/
	node->event_ringbuf = vmalloc(EVENT_FIFO_LENGTH);
	if (node->event_ringbuf == NULL) {
		VATOOLS_ERR(
			NULL, DUMMY_DIE_ID,
			"[create_node] event_ringbuf is NULL. need len=%d\n",
			EVENT_FIFO_LENGTH);
		ret = -ENOMEM;
		goto out_free_msg_fifo;
	}
	memset(node->event_ringbuf, 0, EVENT_FIFO_LENGTH);
	fifo = (struct vastai_fifo *)node->event_ringbuf;
	fifo->elem_count = (EVENT_FIFO_LENGTH - sizeof(struct vastai_fifo)) /
			   sizeof(device_event_t);
	fifo->elem_size = sizeof(device_event_t);
	mutex_init(&node->event_mutex);
	init_waitqueue_head(&node->event_wait_queue);

	/*init timeline of app*/
	node->profiler_app_ringbuf = vmalloc(PROFILER_PCI_APP_FIFO_LENGTH);
	if (node->profiler_app_ringbuf == NULL) {
		VATOOLS_ERR(
			NULL, DUMMY_DIE_ID,
			"[create_node] profile app ringbuf is NULL. need len=%d\n",
			PROFILER_PCI_APP_FIFO_LENGTH);
		ret = -ENOMEM;
		goto out_free_event_fifo;
	}
	gp_profiler_app_fifo = node->profiler_app_ringbuf;
	fifo = (struct vastai_fifo *)node->profiler_app_ringbuf;
	fifo->elem_count =
		(PROFILER_PCI_APP_FIFO_LENGTH - sizeof(struct vastai_fifo)) /
		sizeof(profiler_app_checkpoint_t);
	fifo->elem_size = sizeof(profiler_app_checkpoint_t);
	/*spin lock init(&node >profile app ringbuf lock);*/

	INIT_LIST_HEAD(&node->list_nodes);

	INIT_LIST_HEAD(
		&node->list_node_process_mutex); /*TODO: Implements process mutex protection using kernel mutex*/

	/*INIT_LIST_HEAD( &node->t_sharedmem_mem_info_head );*/
	/*INIT_LIST_HEAD( &node->t_sharedmem_signal_info_head );*/

	list_add_tail(&node->list_nodes, vatools_get_vastai_head());

	/*finally, initialize the misc device for this node*/
#if KERNEL_VERSION(6, 4, 0) > LINUX_VERSION_CODE
	toolsclass = class_create(THIS_MODULE, "toolsclass");
#else
	toolsclass = class_create("toolsclass");
#endif
	if (toolsclass == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "class_create failed\n");
		goto out_free_app_fifo;
	}
	/*set node right*/
	toolsclass->devnode = set_devnode;

	node->file_info.dev_num = MKDEV(major, TOOLS_MINOR);
	ret = register_chrdev_region(node->file_info.dev_num, 1, "vatools");
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "register device num failed! alloc one [%d]\n",
			    node->file_info.dev_num);
		alloc_chrdev_region(&node->file_info.dev_num, 0, 1, "char");
	}

	node->file_info.dev.owner = THIS_MODULE;
	cdev_init(&node->file_info.dev, &vatools_fops);
	ret = cdev_add(&node->file_info.dev, node->file_info.dev_num, 1);
	if (ret < 0) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "cdev_add failed %d\n", ret);
		unregister_chrdev_region(node->file_info.dev_num, 1);
		class_destroy(toolsclass);
		goto out_free_app_fifo;
	}
	snprintf(node->file_info.file_name, VASTAI_BUF_SIZE_32, "%s",
		 tools_node_name);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "tools node name: %s\n",
		    node->file_info.file_name);
	node->file_info.device =
		device_create(toolsclass, NULL, node->file_info.dev_num,
			      &node->file_info, node->file_info.file_name);
	if (!node->file_info.device) {
		ret = PTR_ERR(node->file_info.device);
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "device_create failed %d\n",
			    ret);
		cdev_del(&node->file_info.dev);
		unregister_chrdev_region(node->file_info.dev_num, 1);
		class_destroy(toolsclass);
		goto out_free_app_fifo;
	}

	VATOOLS_INFO(
		priv, DUMMY_DIE_ID,
		"[create_node] [SUCCESS] pci_dev=%p created %lu bytes on node '%s'\n",
		pci_dev, (unsigned long)node->size, node->file_info.file_name);

	return 0;

out_free_app_fifo:
	vfree(node->profiler_app_ringbuf);

out_free_event_fifo:
	vfree(node->event_ringbuf);

out_free_msg_fifo:
	vfree(node->profiler_msg_ringbuf);

out_free_dma_fifo:
	vfree(node->profiler_dma_ringbuf);

out_free_rt_vacc_process_info_buf:
	kvfree(node->rt_vacc_process_info_buf);
out_free_rt_process_info_buf:
	kvfree(node->rt_process_info_buf);
out_free_rt_zone_usage_buf:
	kvfree(node->rt_zone_usage_buf);
out_free_rt_info_head_buf:
	kvfree(node->rt_info_head_buf);

out_free_node:
	kvfree(node);

out_free_buffer:
	kvfree(buffer);
	VATOOLS_FUNC_EXIT;
	VATOOLS_INFO(
		NULL, DUMMY_DIE_ID,
		"[create_node] [FAILED] pci_dev=%p created %lu bytes on node '%s' failed! ret=%d\n",
		pci_dev, (unsigned long)size, node_name, ret);
	return ret;
}

int vatools_fct_die_num(struct vastai_pci_info *priv, int die_num)
{
	/*Important: add this below line only for FCT test. DO NOT edit below line.*/
	/*If you want to change this, notice tools team. Thanks.*/
	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
			"[FCT]:vastai_pci_read_die_num=%d\n", die_num);
	return 0;
}

/*
 * tools driver heat
 */

static int vatools_driver_init(void *priv)
{
	int ret = 0;
	VATOOLS_FUNC_ENTERY;
	ret = create_node(priv, VATOOLS_DEV_NAME, VATOOLS_BUFFER_SIZE);
	if (unlikely(ret)) {
		VATOOLS_INFO(priv, DUMMY_DIE_ID,
			     "[driver_init] init %s failed. ret=%d\n",
			     VATOOLS_DEV_NAME, ret);
		goto out;
	}
	VATOOLS_INFO(priv, DUMMY_DIE_ID, "[driver_init] init %s ok\n",
		     VATOOLS_DEV_NAME);
out:
	VATOOLS_FUNC_EXIT;
	return ret;
}

void vatools_driver_exit(void *pci_dev)
{
	struct vatools_node *current_node = NULL, *next_node = NULL;
	V_UNREFERENCE(pci_dev);
	VATOOLS_FUNC_ENTERY;

	list_for_each_entry_safe (current_node, next_node,
				  vatools_get_vastai_head(), list_nodes) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "[driver_exit] deinit %s\n",
			     current_node->file_info.file_name);
		list_del(&current_node->list_nodes);
		/*we have to delete all the entry inside headlist*/
		kvfree(current_node->node_buffer);

		mutex_lock(&current_node->rt_buf_mutex);
		kvfree(current_node->rt_info_head_buf);
		current_node->rt_info_head_buf = NULL;

		kvfree(current_node->rt_zone_usage_buf);
		current_node->rt_zone_usage_buf = NULL;

		kvfree(current_node->rt_process_info_buf);
		current_node->rt_process_info_buf = NULL;

		kvfree(current_node->rt_vacc_process_info_buf);
		current_node->rt_vacc_process_info_buf = NULL;
		mutex_unlock(&current_node->rt_buf_mutex);

		/*free profiler timeline buffer*/
		vfree(current_node->profiler_dma_ringbuf);
		vfree(current_node->profiler_msg_ringbuf);
		vfree(current_node->event_ringbuf);
		vfree(current_node->profiler_app_ringbuf);
		gp_profiler_dma_fifo = NULL;
		gp_profiler_msg_fifo = NULL;
		current_node->event_ringbuf = NULL;
		gp_profiler_app_fifo = NULL;

#ifdef VATOOLS_DRIVER_TEST_NODE
		if (atomic_read(&current_node->ut_enable) == 1) {
			tools_test_deinit(current_node);
		}
#endif
		device_destroy(toolsclass, current_node->file_info.dev_num);
		cdev_del(&current_node->file_info.dev);
		unregister_chrdev_region(current_node->file_info.dev_num, 1);
		class_destroy(toolsclass);

		/*free node*/
		kvfree(current_node);
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "[driver_exit] deinit ok\n");
	}

	VATOOLS_FUNC_EXIT;
}

/*When the driver is loaded/unloaded, the data is updated*/
static int vatools_update_data_probe(void *priv)
{
	int ret = 0;
#ifdef CONFIG_TOOLS_V2
	ret = vatools_v2_clear_device_info(priv);
#endif
	return ret;
}

static int vatools_update_data_remove(void *priv)
{
	int ret = 0;
#ifdef CONFIG_TOOLS_V2
	ret = vatools_v2_clear_device_info(priv);
#endif
	return ret;
}

/*Enable compile-time check struct length and application layer alignment*/
#if (VATOOLS_CHECK_BYTE_ALIGH == 1)
static int vatools_check_align_compile(void)
{
	/*Compile time checks whether the size of the dev_info structure meets the requirements*/
	BUILD_BUG_ON_MSG(
		sizeof(vatools_v2_device_info_t) !=
			SIZEOF_V2_DEVICE_INFO_STRUCT,
		"*** VATOOLS complile error: vatools_v2_device_info_t size does NOT match");
	BUILD_BUG_ON(sizeof(vatools_v2_base_info_u) != VATOOLS_BASE_INFO_SIZE);
	BUILD_BUG_ON(sizeof(vatools_v2_device_info_u) !=
		     VATOOLS_DEVUCE_INFO_SIZE);
	BUILD_BUG_ON(sizeof(vatools_v2_die_info_u) != VATOOLS_DIE_INFO_SIZE);
	/*Compilation checks if mutex is 8-byte aligned*/
	BUILD_BUG_ON(offsetof(struct vatools_node, node_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_sharedmem_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_common_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_profiler_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_debugger_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_logger_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_smi_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_dummy_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_driver_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, node_reader_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_node, event_mutex) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_reader, debug_comp) % 8);
	BUILD_BUG_ON(offsetof(struct vatools_reader, sharedmem_mutex) % 8);

	return 0;
}
#endif

/*For all devices, vatools only loads once. Use this variable to identify when device counts init*/
/*If it is equal to 0 load the driver; exit, if it is equal to 0, uninstall the driver.*/
static atomic_t _vatools_init_device_count = ATOMIC_INIT(0);
/*Each time the card changes, the count is added by 1*/
atomic_t _vatools_changed_device_count = ATOMIC_INIT(0);

#if (TOOLS_WIN == 1)
static atomic_t _vatools_init_success = ATOMIC_INIT(0);

extern "C" extern WDFDEVICE g_tools_device_test;

void tools_io_stop()
{
	device_io_stop(g_tools_device_test);
}

void tools_io_start()
{
	if (1 == atomic_read(&_vatools_init_success)) {
		device_io_start(g_tools_device_test);
	}
}
#endif

/*Controls variables that are initialized only once*/
static atomic_t _vatools_init_only_once = ATOMIC_INIT(0);
int vatools_prepare_init_once(void)
{
	int ret = 0;

	if (0 == atomic_read(&_vatools_init_only_once)) {
		atomic_inc(&_vatools_init_only_once);

#if (TOOLS_WIN == 1)
		mutex_init(&g_mutex_tools_init);
		mutex_init(&g_mutex_open_list);
#endif
	}
	return ret;
}
atomic_t tools_online_flag = ATOMIC_INIT(0);

/*The PCIe driver calls the function, initializing the Vatools driver. There is only one node, and device, die is not related.*/
int tools_init(void *priv)
{
	int ret = 0;
	int j = 0;

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	VATOOLS_INFO(priv, DUMMY_DIE_ID,
		     "[tools_init] sharemem lock optimize enabled\n");
#endif

#ifdef VATOOLS_HOT_PLUG_ENABLE
	VATOOLS_INFO(priv, DUMMY_DIE_ID, "[tools_init] hot plug enabled\n");
#endif

	mutex_lock(&g_mutex_tools_init);
	atomic_set(&_vatools_in_kill_routine, 0);

#ifdef CONFIG_TOOLS_V2
	mutex_init(
		&((struct vastai_pci_info *)priv)->tools_info.tools_dev_mutex);
	/*
	mutex_init(
	&((struct vastai_pci_info *)priv)->tools_info.tools_die_mutex);
	*/
	init_completion(
		&((struct vastai_pci_info *)priv)->tools_info.smi_ack[0]);
	init_completion(
		&((struct vastai_pci_info *)priv)->tools_info.smi_ack[1]);
	init_completion(&((struct vastai_pci_info *)priv)
				 ->tools_info.core_time_sync_ack);
	for (j = 0; j < 4; j++) {
		((struct vastai_pci_info *)priv)
			->tools_info.pcie_tx_vdsp_count[j] = 0;
	}
	for (j = 0; j < 4; j++) {
		((struct vastai_pci_info *)priv)
			->tools_info.pcie_rx_vdsp_count[j] = 0;
	}
	((struct vastai_pci_info *)priv)->tools_info.ddr_bw_test = 0;
#endif

	VATOOLS_INFO(priv, DUMMY_DIE_ID,
		     "[tools_init] priv=0x%p before init, device_count=%d\n",
		     priv, atomic_read(&_vatools_init_device_count));

	if ((0 == atomic_read(&_vatools_init_device_count)) &&
	    (atomic_read(&tools_online_flag) == 0)) {
		ret = vatools_driver_init(priv);
		atomic_set(&tools_online_flag, 1);
	}
	atomic_inc(&_vatools_init_device_count);
	atomic_inc(&_vatools_changed_device_count);
	if (ret < 0) {
		VATOOLS_INFO(
			priv, DUMMY_DIE_ID,
			"[tools_init] init failed, total device_count=%d\n",
			atomic_read(&_vatools_init_device_count));
	} else {
		VATOOLS_INFO(priv, DUMMY_DIE_ID,
			     "[tools_init] init ok, total device_count=%d\n",
			     atomic_read(&_vatools_init_device_count));
	}

	vatools_video_weight_init();
	ret = vatools_update_data_probe(priv);
#if (TOOLS_WIN == 1)
	/*fix: BSOD because conflicts occurred during initialization of tools module for multi-card*/
	atomic_set(&_vatools_init_success, 1);
#endif

	mutex_unlock(&g_mutex_tools_init);
	return ret;
}

#ifdef VATOOLS_HOT_PLUG_ENABLE
static int vatools_open_files(struct vatools_node *node)
{
	int rc;

	mutex_lock(&g_mutex_open_list);
	rc = list_empty(&vatools_open_list);
	mutex_unlock(&g_mutex_open_list);
	return !rc;
}

static void complete_die_sig(struct vastai_pci_info *pci_info, int die)
{
	if (completion_done(&(pci_info->dies[die].smi_ack[0])) == 0) {
		pci_info->dies[die].smi_ack_msg[0] = -EINTR;
		complete_all(&(pci_info->dies[die].smi_ack[0]));
	}

	//pci_info->dies[die].smi_ack_msg[1] = -EINTR;
	//complete(&pci_info->dies[die].smi_ack[1]);
}

static void complete_pci_tools_sig(struct vastai_pci_info *pci_info)
{
	/* sv100 don't use  */
	//complete(&(pci_info->tools_info.smi_ack[0]));
	//complete(&(pci_info->tools_info.smi_ack[1]));

	if (completion_done(&(pci_info->tools_info.log_comp)) == 0) {
		complete_all(&(pci_info->tools_info.log_comp));
	}
}

static void send_complete_wake_sig(void)
{
	uint8_t die = 0;
	struct vastai_pci_info *pci_info = NULL;

	mutex_lock(&vastai_pci_info_list_lock);
	list_for_each_entry (pci_info, &vastai_pci_info_list, dev_list) {
		if (pci_info == NULL) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "pci_info is NULL\n");
			continue;
		}

		for (die = 0; die < pci_info->die_num_in_fn; die++) {
			complete_die_sig(pci_info, die);
		}
		complete_pci_tools_sig(pci_info);
	}
	mutex_unlock(&vastai_pci_info_list_lock);
}

static void vatools_pid_res_del(void *priv)
{
	unsigned int files = 0;
	int i = 0;
	struct vatools_pid_entry *pid_entry = NULL;
	struct vatools_pid_entry *temp = NULL;
	//int close_flag = 0;

	atomic_set(&g_rmmod_pid, pid_nr(task_pid(current)));

	send_complete_wake_sig();

	mutex_lock(&g_mutex_open_list);
	list_for_each_entry (pid_entry, &vatools_open_list, node) {
		//if (pid_entry->type != VATOOLS_CLOSE) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
			    "[hotplug res_del] kill pid %d\n",
			    pid_nr(pid_entry->pid));
		kill_pid(pid_entry->pid, SIGKILL, 1);
		//} else {
		//	close_flag = 1;
		//}
		files++;
	}

	mutex_unlock(&g_mutex_open_list);
	if (files) {
		for (; (i < 5) && vatools_open_files(priv); i++) {
			msleep(1000);
			VATOOLS_DBG(
				priv, DUMMY_DIE_ID,
				"[tools_exit] wait pid release res, %d ms\n",
				i * 100);

			mutex_lock(&g_mutex_open_list);
			pid_entry = NULL;
			list_for_each_entry (pid_entry, &vatools_open_list,
					     node) {
				VATOOLS_DBG(
					priv, DUMMY_DIE_ID,
					"[hotplug res_del] pid %d now at open list\n",
					pid_nr(pid_entry->pid));
			}
			mutex_unlock(&g_mutex_open_list);
		}
	}

	if (i == 5) {
		mutex_lock(&g_mutex_open_list);
		pid_entry = NULL;
		list_for_each_entry_safe (pid_entry, temp, &vatools_open_list,
					  node) {
			VATOOLS_DBG(
				priv, DUMMY_DIE_ID,
				"[hotplug reach max kill time] pid %d now still at open list\n",
				pid_nr(pid_entry->pid));

			list_del(&pid_entry->node);
			put_pid(pid_entry->pid);
			vfree(pid_entry);
		}
		mutex_unlock(&g_mutex_open_list);
	}
	VATOOLS_DBG(priv, DUMMY_DIE_ID,
		    "[%s] wait pid release res whole time %d ms\n", __func__,
		    i * 100);
}
#endif

void tools_exit(void *priv)
{
	mutex_lock(&g_mutex_tools_init);

	if (atomic_read(&_vatools_init_device_count) == 0) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
				 "[tools_exit] tools_init may not exec\n");
		mutex_unlock(&g_mutex_tools_init);
		return;
	}

	atomic_dec(&_vatools_init_device_count);
	atomic_inc(&_vatools_changed_device_count);

	VATOOLS_INFO(priv, DUMMY_DIE_ID,
		     "[tools_exit] init count %d, change count %d\n",
		     atomic_read(&_vatools_init_device_count),
		     atomic_read(&_vatools_changed_device_count));
#ifdef VATOOLS_HOT_PLUG_ENABLE
	atomic_set(&_vatools_in_kill_routine, 1);
	vatools_pid_res_del(priv);
#endif
	VATOOLS_INFO(priv, DUMMY_DIE_ID,
		     "[tools_exit] priv=0x%p, device_count=%d\n", priv,
		     atomic_read(&_vatools_init_device_count));

	vatools_update_data_remove(priv);

	if (0 == atomic_read(&_vatools_init_device_count)) {
		//vatools_driver_exit(priv);
	} else {
		atomic_set(&_vatools_in_kill_routine, 0);
	}

/*Enable compile-time check struct length and application layer alignment*/
#if (VATOOLS_CHECK_BYTE_ALIGH == 1)
	vatools_check_align_compile();
#endif
	VATOOLS_INFO(priv, DUMMY_DIE_ID,
		     "[tools_exit] done. priv=0x%p, device_count=%d\n", priv,
		     atomic_read(&_vatools_init_device_count));

	mutex_unlock(&g_mutex_tools_init);
	return;
}

#if VATOOLS_INDEPENDANCE_DRIVER

static int __init vatools_init(void)
{
	return tools_init(NULL);
}
static void __exit vatools_exit(void)
{
	tools_exit(NULL);
}

module_init(vatools_init);
module_exit(vatools_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Frank Bai<frank.bai@vastaitech.com>");
MODULE_DESCRIPTION("vatools driver");
MODULE_VERSION("0.1");

#endif
