﻿#ifndef __VATOOLS_PROFILER_H__
#define __VATOOLS_PROFILER_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

loff_t profiler_llseek(struct file *filp, loff_t offset, int orig);
ssize_t profiler_read(struct file *filp, char __user *buf, size_t size,
		      loff_t *pos);
ssize_t profiler_write(struct file *filp, const char __user *buf, size_t size,
		       loff_t *pos);
ssize_t profiler_write_iter(struct kiocb *iocb, struct iov_iter *from);
unsigned int profiler_poll(struct file *filp, struct poll_table_struct *wait);
long profiler_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg);
int profiler_mmap(struct file *filp, struct vm_area_struct *pvm);
int profiler_open(struct inode *inode, struct file *filp);
int profiler_release(struct inode *ignored, struct file *filp);
int profiler_fasync(int fd, struct file *filp, int mode);

/*The profiler driver is responsible for maintaining a ringbuf . Write override, profiler startup,
set flag, read data. Write to ringbuf and wait for the host to read.*/
/*Move the rp pointer after reading . Will there be a synchronization problem with simultaneous reads while writing? Mutex control?*/
void vatools_profiler_dma_checkpoint(
	struct s_profiler_dma_checkpoint *dma_section);
void vatools_profiler_msg_checkpoint(
	struct s_profiler_msg_checkpoint *msg_section);
void vatools_profiler_app_checkpoint(
	struct s_profiler_app_checkpoint *app_section);

/*Determine whether it needs to be turned on profiler timeline*/
extern unsigned int profiler_timeline_enable;
static inline unsigned int profiler_timeline_is_enable(void)
{
	return profiler_timeline_enable;
}

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_PROFILER_H__*/
