﻿
#ifndef __VATOOLS_TYPES_H__
#define __VATOOLS_TYPES_H__

#pragma pack(push)
#pragma pack(1)

/*Eliminate the compilation unused variable warning*/
#define V_UNREFERENCE(param) ((void)param);

typedef signed char s8;
typedef short s16;
typedef int s32;
typedef long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef char i8;
typedef short i16;
typedef int i32;
typedef long long i64;
typedef long long __s64;
typedef unsigned long long __u64;

typedef signed char INT8, *PINT8;
typedef signed short INT16, *PINT16;
typedef signed int INT32, *PINT32;
typedef signed long long INT64, *PINT64;
typedef unsigned char UINT8, *PUINT8;
typedef unsigned short UINT16, *PUINT16;
typedef unsigned int UINT32, *PUINT32;
typedef unsigned long long UINT64, *PUINT64;

#define MAX_UINT64 (unsigned long long)0xFFFFFFFFFFFFFFFF
#define MAX_INT64  (unsigned long long)0x7FFFFFFFFFFFFFFF
#define MAX_UINT32 (unsigned)0xFFFFFFFF
#define MAX_INT32  (unsigned)0x7FFFFFFF

#if (TOOLS_WIN == 1)
typedef void *IOCTL_ARG_T;
#else
#define HANDLE int /*compilable with windows file handler*/
typedef unsigned long IOCTL_ARG_T;
#endif

#pragma pack(pop)

#endif /*__VATOOLS_TYPES_H__*/
