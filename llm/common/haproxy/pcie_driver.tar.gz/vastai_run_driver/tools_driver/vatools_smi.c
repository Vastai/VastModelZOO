#include "vatools.h"
#include "vatools_log.h"

/*ioctl generic command V2 version*/

loff_t smi_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);

	return 0;
}

ssize_t smi_read(struct file *filp, char __user *buf, size_t size, loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t smi_write(struct file *filp, const char __user *buf, size_t size,
		  loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t smi_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);

	return 0;
}

unsigned int smi_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);

	return 0;
}

long smi_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EIO;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);

	return ret;
}

int smi_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);

	return 0;
}
int smi_open(struct inode *inode, struct file *filp)
{
	VATOOLS_FUNC_ENTERY;

	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);

	VATOOLS_FUNC_EXIT;
	return 0;
}

int smi_release(struct inode *ignored, struct file *filp)
{
	V_UNREFERENCE(ignored);
	V_UNREFERENCE(filp);

	return 0;
}

int smi_fasync(int fd, struct file *filp, int mode)
{
	V_UNREFERENCE(fd);
	V_UNREFERENCE(filp);
	V_UNREFERENCE(mode);

	return 0;
}

#ifdef CONFIG_TOOLS_V2

static void domain_mutex_lock__device(struct mutex *m)
{
	mutex_lock(m);
}
static void domain_mutex_lock__die(struct mutex *m)
{
	mutex_lock(m);
}

static void domain_mutex_lock__driver(struct mutex *m)
{
	mutex_lock(m);
}

/*device or die mutex*/
int domain_mutex_lock(struct vastai_pci_info *priv, u32 die_index, u32 field)
{
	struct vatools_node *node = NULL;
	union die_index_data did;
	did.val = die_index;

	VATOOLS_DBG(priv, die_index, "field= 0x%x\n", field);

	if (field & VATOOLS_IOCTL_DOMAIN_DEVICE) {
		domain_mutex_lock__device(&(priv->tools_info.tools_dev_mutex));
	}
	if (field & VATOOLS_IOCTL_DOMAIN_DIE) {
		domain_mutex_lock__die(
			&(priv->dies[did.die_id].tools_die_mutex));
	}
	if (field & VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER) {
		node = vatools_get_node();
		domain_mutex_lock__driver(&(node->node_driver_mutex));
	}
	return 0;
}

/*device or die mutex*/
int domain_mutex_unlock(struct vastai_pci_info *priv, u32 die_index, u32 field)
{
	struct vatools_node *node = NULL;
	union die_index_data did;
	did.val = die_index;

	if (field & VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER) {
		node = vatools_get_node();
		mutex_unlock(&(node->node_driver_mutex));
	}
	if (field & VATOOLS_IOCTL_DOMAIN_DIE) {
		mutex_unlock(&(priv->dies[did.die_id].tools_die_mutex));
	}
	if (field & VATOOLS_IOCTL_DOMAIN_DEVICE) {
		mutex_unlock(&(priv->tools_info.tools_dev_mutex));
	}
	return 0;
}

/*Access the SMCU SMI interface*/
long vatools_ioctl_smi_cmd(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	/*struct vatools_node *node = vatools_file_get_node(filp);*/
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;
	struct vastai_sv100_die *die = NULL;

	TS_SMI_CMD_REQ smi_cmd = { 0 };
	TS_SMI_CMD_REQ *smi_cmd_p = NULL;

	u32 write_len = 0;
	u32 read_len = 0;
	void *write_buf = NULL;
	void *read_buf = NULL;

	T_SMI_BLOCK *smi_block_p = NULL;
	u64 smi_die_address_offset = 0;
	int ready = 0;
	int re_trigger_fw_count = 3;

	V_UNREFERENCE(filp);
	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}

	smi_block_p = vatools_fw_smi_get_block(priv, ioctl_arg.block_id);
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	domain_mutex_lock(priv, ioctl_arg.die_index.val, ioctl_arg.lock_domain);

	write_len = ioctl_arg.input_buf.buf_size;
	read_len = ioctl_arg.output_buf.buf_size;

	if (write_len > smi_block_p->block_len ||
	    read_len > smi_block_p->block_len) {
		VATOOLS_INFO(priv, die_id,
			     "read_len=%d or write_len=%d over %d of %d\n",
			     read_len, write_len, smi_block_p->block_len,
			     ioctl_arg.block_id);
		ret = -EFAULT;
		goto out_mutex_unlock;
	}

	if ((read_len % 4 != 0) || (write_len % 4 != 0)) {
		VATOOLS_INFO(
			priv, die_id,
			"read_len=%d, write_len=%d, not align by 4 bytes\n",
			read_len, write_len);
		ret = -EFAULT;
		goto out_mutex_unlock;
	}

	write_buf = kvmalloc(ioctl_arg.input_buf.buf_size, GFP_KERNEL);
	if (write_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_id, "kvmalloc write_buf ret=%ld\n", ret);
		goto out_free_write_buf;
	}

	ret = copy_from_user_ex(write_buf,
				(void __user *)ioctl_arg.input_buf.buf_addr,
				ioctl_arg.input_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_from_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_write_buf;
	}

	VATOOLS_DUMP_BRIEF("ioctl_smi_cmd write_buf: ", write_buf,
			   ioctl_arg.input_buf.buf_size);

	/*TODO: Check the SMI command here, and if it's SMI_CMD_CODE_SPI_WRITE, clear the dev_info cache, as spi writes may modify the spi config data*/
	smi_cmd_p = (TS_SMI_CMD_REQ *)write_buf;
	if (smi_cmd_p != NULL && smi_cmd_p->cmd == SMI_CMD_CODE_SPI_WRITE) {
		struct vatools_node *node_p = vatools_get_node();
		VATOOLS_DBG(priv, die_id, "clear device info cache\n");
		kvfree(node_p->dev_info);
		node_p->dev_info = NULL;
		node_p->device_num = 0;
	}
	/*Check SMI command ends*/

	smi_die_address_offset = smi_block_p->block_address;

	VATOOLS_DBG(priv, die_id, "smi_block_p->block_address=0x%x\n",
		    smi_block_p->block_address);

	/*set flag to 0, write only 4 bytes, sync with fw*/
	*((u8 *)write_buf + 6) = FLAG_APP_PREPARE;
	ret = vatools_pci_mem_write(priv, die_index, smi_die_address_offset,
				    (u8 *)write_buf,
				    ioctl_arg.input_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_id,
			     "vatools_pci_mem_write flag=0 ret=%ld\n", ret);
		goto out_free_write_buf;
	}

	/*set flag to 1, write only 4 bytes, sync with fw*/
	*((u8 *)write_buf + 6) = FLAG_APP_REQ;
	ret = vatools_pci_mem_write(priv, die_index, smi_die_address_offset + 4,
				    ((u8 *)write_buf) + 4, sizeof(u32));
	if (ret < 0) {
		VATOOLS_INFO(priv, die_id,
			     "vatools_pci_mem_write flag=1 ret=%ld\n", ret);
		goto out_free_write_buf;
	}

	read_buf = kvmalloc(ioctl_arg.output_buf.buf_size, GFP_KERNEL);
	if (read_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_id, "kvmalloc read_buf=NULL ret=%ld\n",
			    ret);
		goto out_free_write_buf;
	}

/*TODO: If fw does not respond, the request is sent 3 times repeatedly.*/
re_trigger_fw:

	/*If it is a user interrupt, you need to clear the ack reply of the last smi command here,
	Otherwise, every time you enter here, wait_for will return directly, resulting in a mismatch between wait and ack*/
	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_id, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		ret = -EINVAL;
		goto out_mutex_unlock;
	}
	die = &(priv->dies[die_id]);
	reinit_completion(&(die->smi_ack[ioctl_arg.block_id]));

	ret = vatools_fw_send_smi_interrupt(priv, die_index);
	ret = vatools_wait_smi_ack(priv, die_index, ioctl_arg.block_id, 4, NULL,
				   0);
	if (ret < 0) {
		if (ret == -EINTR) {
			VATOOLS_DBG(
				priv, die_id,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld(-EINTR) re_trigger_fw_count=%d\n",
				die_index, ioctl_arg.block_id, ret,
				re_trigger_fw_count);
			goto out_free_read_buf;
		} else if (ret == -ETIMEDOUT) {
			VATOOLS_INFO(
				priv, die_id,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld(-ETIMEDOUT) re_trigger_fw_count=%d\n",
				die_index, ioctl_arg.block_id, ret,
				re_trigger_fw_count);
		} else {
			VATOOLS_INFO(
				priv, die_id,
				"smi_ack: die_index=0x%x block_id=%d timeout ret=%ld re_trigger_fw_count=%d\n",
				die_index, ioctl_arg.block_id, ret,
				re_trigger_fw_count);
			goto out_free_read_buf;
		}
	}

	memset(read_buf, 0x00, ioctl_arg.output_buf.buf_size);
	ret = vatools_pci_mem_read(priv, die_index, smi_die_address_offset,
				   read_buf, ioctl_arg.output_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_id, "ret=%ld\n", ret);
		goto out_free_read_buf;
	}

	VATOOLS_DUMP_BRIEF("ioctl_smi_cmd read_buf: ", read_buf,
			   ioctl_arg.output_buf.buf_size);

	memcpy(&smi_cmd, read_buf, sizeof(TS_SMI_CMD_REQ));

	VATOOLS_DBG(priv, die_id, "smi_cmd.flag=%d\n", smi_cmd.flag);
	/*fw has an answer and is no longer retransmitted, regardless of the execution result*/
	if (smi_cmd.flag == FLAG_FW_DATA_READY ||
	    smi_cmd.flag == FLAG_FW_ERROR_UNKNOWN_CMD ||
	    smi_cmd.flag == FLAG_FW_ERROR_ABORT) {
		ready = 1;
		/* Data ready*/
		VATOOLS_DBG(priv, die_id,
			    "READY: ioctl_arg.output_buf.buf_addr=0x%llx"
			    "ioctl_arg.output_buf.buf_size=%d\n",
			    ioctl_arg.output_buf.buf_addr,
			    ioctl_arg.output_buf.buf_size);

		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr, read_buf,
			ioctl_arg.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n",
				    ret);
			ret = -EFAULT;
			goto out_free_read_buf;
		}
		ret = smi_cmd.flag | 0x1000;
		goto out_free_read_buf;
	} else if (smi_cmd.flag == FLAG_APP_REQ) {
		/*fw has no reply, flag is the status of the request, the smcu has not done any processing, the request is retransmitted, and the loop ends after 3 times*/
		VATOOLS_INFO(
			priv, die_id,
			"SMCU not responding: smi_cmd.flag == FLAG_APP_REQ(0x01): re_trigger_fw_count=%d\n",
			re_trigger_fw_count);
		if (re_trigger_fw_count > 0) {
			re_trigger_fw_count--;
			goto re_trigger_fw;
		}
	}

	/* Data error*/
	VATOOLS_DBG(priv, die_id,
		    "ABORT: ioctl_arg.output_buf.buf_addr=0x%llx"
		    "ioctl_arg.output_buf.buf_size=%d\n",
		    ioctl_arg.output_buf.buf_addr,
		    ioctl_arg.output_buf.buf_size);

	ret = copy_to_user_ex((void __user *)ioctl_arg.output_buf.buf_addr,
			      read_buf, ioctl_arg.output_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out_free_read_buf;
	}
	ret = -ETIME;
	goto out_free_read_buf;

out_free_read_buf:
	kvfree(read_buf);

out_free_write_buf:
	kvfree(write_buf);

out_mutex_unlock:
	domain_mutex_unlock(priv, ioctl_arg.die_index.val,
			    ioctl_arg.lock_domain);

out:

	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;

	return ret2;
}

/*PCIe command interface, which directly calls PCIe driver functions. Not sent to SMCU*/
long vatools_ioctl_pcie_cmd(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	struct vatools_node *node = vatools_file_get_node(filp);
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;
	u32 i = 0;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	mutex_lock(&node->node_driver_mutex);

	switch (ioctl_arg.sub_cmd) {
	case VATOOLS_IOCTL_PCIE_BANDWIDTH: {
		u64 upstream_count = 0;
		u64 downstream_count = 0;
		ret = vatools_pci_mem_read(priv, die_index,
					   PCIE_BANDWIDTH_UPSTREAM,
					   &upstream_count, sizeof(u64));
		if (ret < 0) {
			ret = -EFAULT;
			goto out_mutex_unlock;
		}

		VATOOLS_DBG(priv, die_index, "upstream_count: ret=0x%llx\n",
			    upstream_count);
		ret = copy_to_user_ex((u8 *)ioctl_arg.output_buf.buf_addr +
					      sizeof(TS_SMI_CMD_REQ),
				      &upstream_count, sizeof(u64));
		if (ret < 0) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_mutex_unlock;
		}
		ret = vatools_pci_mem_read(priv, die_index,
					   PCIE_BANDWIDTH_DOWNSTREAM,
					   &downstream_count, sizeof(u64));
		if (ret < 0) {
			ret = -EFAULT;
			goto out_mutex_unlock;
		}
		VATOOLS_DBG(priv, die_index, "downstream_count: ret=0x%llx\n",
			    downstream_count);
		ret = copy_to_user_ex((u8 *)ioctl_arg.output_buf.buf_addr +
					      sizeof(TS_SMI_CMD_REQ) +
					      sizeof(u64),
				      &downstream_count, sizeof(u64));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_mutex_unlock;
		}
	} break;

	case VATOOLS_IOCTL_PCIE_RESET:
		vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER);
		break;

	case VATOOLS_IOCTL_PCIE_REBOOT:
		vastai_device_reset(priv, VASTAI_RESET_MSG_TRIGER |
						  VASTAI_RESET_BOOT_DEV);
		break;

	case VATOOLS_IOCTL_PCIE_FW_VERSION: {
		struct vastai_fw_version fw_ver;
		memcpy(&fw_ver, &(priv->dies[0].fw_ver),
		       sizeof(struct vastai_fw_version));
		VATOOLS_DUMP_BRIEF("fw_ver: ", &fw_ver,
				   sizeof(struct vastai_fw_version));
		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr, &fw_ver,
			sizeof(struct vastai_fw_version));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_mutex_unlock;
		}
	} break;

	case VATOOLS_IOCTL_PCIE_DDR_ECC_1BIT: {
		struct vastai_fifo *ecc_fifo;
		u32 table_size = ioctl_arg.output_buf.buf_size;
		u8 *buffer;

		if (table_size > DDR_ECC_1BIT_SIZE) {
			table_size = DDR_ECC_1BIT_SIZE;
		}

		ret = 0;
		buffer = (u8 *)kvmalloc(table_size, GFP_KERNEL);
		if (buffer == NULL) {
			VATOOLS_ERR(
				priv, die_index,
				"VATOOLS_IOCTL_PCIE_DDR_ECC_1BIT kvmalloc error. size=%d\n",
				table_size);
			ret = -ENOMEM;
			goto out_mutex_unlock;
		}

		ret = vatools_pci_mem_read(priv, die_index,
					   ECC_1BIT_ERR_STORE_ADDR, buffer,
					   table_size);
		if (ret < 0) {
			ret = -EFAULT;
			goto out_free_write_buf_1bit;
		}
		ecc_fifo = (struct vastai_fifo *)buffer;
		VATOOLS_DUMP_BRIEF("ecc 1bit: ", buffer, table_size);
		/*ecc_fifo->rd returns to the application layer, and the corresponding variable is entry_count*/
		if (ecc_fifo->elem_count == 0) {
			VATOOLS_INFO(priv, die_index,
				     "ecc1bit: ecc_fifo->elem_count = 0\n");
			ecc_fifo->rd = 0;
		} else {
			ecc_fifo->rd =
				(ecc_fifo->elem_count +
				 (((int)ecc_fifo->wr) - (int)(ecc_fifo->rd))) %
				ecc_fifo->elem_count;
		}

		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr, buffer,
			table_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_free_write_buf_1bit;
		}

	out_free_write_buf_1bit:
		kvfree(buffer);
	} break;

	case VATOOLS_IOCTL_PCIE_DDR_ECC_2BIT: {
		struct vastai_fifo *ecc_fifo;
		u32 table_size = ioctl_arg.output_buf.buf_size;
		u8 *buffer;

		if (table_size > DDR_ECC_2BIT_SIZE) {
			table_size = DDR_ECC_2BIT_SIZE;
		}

		ret = 0;
		buffer = (u8 *)kvmalloc(table_size, GFP_KERNEL);
		if (buffer == NULL) {
			VATOOLS_ERR(
				priv, die_index,
				"VATOOLS_IOCTL_PCIE_DDR_ECC_1BIT kvmalloc error. size=%d\n",
				table_size);
			ret = -ENOMEM;
			goto out_mutex_unlock;
		}

		ret = vatools_pci_mem_read(priv, die_index,
					   ECC_2BIT_ERR_STORE_ADDR, buffer,
					   table_size);
		if (ret < 0) {
			ret = -EFAULT;
			goto out_free_write_buf_2bit;
		}
		ecc_fifo = (struct vastai_fifo *)buffer;
		VATOOLS_DUMP_BRIEF("ecc 2bit: ", buffer, table_size);
		/*ecc_fifo->rd returns to the application layer, and the corresponding variable is entry_count*/
		if (ecc_fifo->elem_count == 0) {
			VATOOLS_INFO(priv, die_index,
				     "ecc2bit: ecc_fifo->elem_count = 0\n");
			ecc_fifo->rd = 0;
		} else {
			ecc_fifo->rd =
				(ecc_fifo->elem_count +
				 (((int)ecc_fifo->wr) - (int)(ecc_fifo->rd))) %
				ecc_fifo->elem_count;
		}

		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr, buffer,
			table_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_free_write_buf_2bit;
		}

	out_free_write_buf_2bit:
		kvfree(buffer);
	} break;

	case VATOOLS_IOCTL_PCIE_VDSP_COUNT: {
/*Todo: In Taveda*/
#if (TOOLS_WIN == 1)
		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr,
			priv->dies[vastai_pci_get_die_id(priv, die_index)]
				.pcie_tx_vdsp_count,
			ioctl_arg.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_mutex_unlock;
		}

		ret = copy_to_user_ex(
			((u8 *)ioctl_arg.output_buf.buf_addr) + sizeof(u32) * 4,
			priv->dies[vastai_pci_get_die_id(priv, die_index)]
				.pcie_rx_vdsp_count,
			ioctl_arg.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_mutex_unlock;
		}
#else
		/*on linux*/
		int i = 0;
		for (i = 0; i < SV100_MAX_VDSP_NUM; i++) {
			u32 cnt;
			cnt = vastai_get_vdsp_cnt(
				priv, vastai_pci_get_die_id(priv, die_index), i,
				0);
			if (cnt == -1) {
				VATOOLS_INFO(priv, die_index,
					     "get tx vdsp cnt failed\n");
				ret = -EFAULT;
				goto out_mutex_unlock;
			}
			ret = copy_to_user_ex(
				((u8 *)ioctl_arg.output_buf.buf_addr) +
					i * sizeof(cnt),
				&cnt, sizeof(cnt));
			if (ret) {
				VATOOLS_INFO(priv, die_index,
					     "copy_to_user_ex ret=%ld\n", ret);
				ret = -EFAULT;
				goto out_mutex_unlock;
			}

			cnt = vastai_get_vdsp_cnt(
				priv, vastai_pci_get_die_id(priv, die_index), i,
				1);
			if (cnt == -1) {
				VATOOLS_INFO(priv, die_index,
					     "get rx vdsp cnt failed\n");
				ret = -EFAULT;
				goto out_mutex_unlock;
			}
			ret = copy_to_user_ex(
				((u8 *)ioctl_arg.output_buf.buf_addr) +
					(sizeof(u32) * 4) + (i * sizeof(cnt)),
				&cnt, sizeof(cnt));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%ld\n", ret);
				ret = -EFAULT;
				goto out_mutex_unlock;
			}
		}
#endif /*end of platform*/
	} break;

	case VATOOLS_IOCTL_PCIE_AI_COUNT: {
		u8 *ai_count_buffer;
		u32 ai_count_buffer_size = 512;

		if (ioctl_arg.output_buf.buf_size < ai_count_buffer_size) {
			ret = -EFAULT;
			VATOOLS_INFO(priv, die_index,
				     "output buffer size < %d ret=%ld\n",
				     ai_count_buffer_size, ret);
			goto out_mutex_unlock;
		}

		ai_count_buffer =
			(u8 *)kvmalloc(ai_count_buffer_size, GFP_KERNEL);
		if (ai_count_buffer == NULL) {
			VATOOLS_ERR(
				priv, die_index,
				"VATOOLS_IOCTL_PCIE_AI_COUNT kvmalloc. size=%d\n",
				ai_count_buffer_size);
			ret = -ENOMEM;
			goto out_mutex_unlock;
		}

		ret = vatools_pci_mem_read(priv, die_index, PERFORMANCE_AI_BASE,
					   ai_count_buffer,
					   ai_count_buffer_size);
		if (ret < 0) {
			ret = -EFAULT;
			goto out_free_write_buf_ai_count;
		}

		ret = copy_to_user_ex(
			(void __user *)ioctl_arg.output_buf.buf_addr,
			ai_count_buffer, ai_count_buffer_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			ret = -EFAULT;
			goto out_free_write_buf_ai_count;
		}
	out_free_write_buf_ai_count:
		kvfree(ai_count_buffer);
	} break;

	case VATOOLS_IOCTL_PCIE_RING_BUF_STATISTIC: {
		u32 static_buf_cnt = sizeof(ring_buf_statics_table) /
				     sizeof(ring_buf_statics_table[0]);
		u32 static_buf_len =
			static_buf_cnt * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME);
		u8 *static_buf = NULL;

		if (ioctl_arg.output_buf.buf_size < static_buf_len) {
			ret = -EFAULT;
			VATOOLS_INFO(priv, die_index,
				     "output buffer size < %d ret=%ld\n",
				     static_buf_len, ret);
			goto out_mutex_unlock;
		}

		static_buf = (u8 *)kvmalloc(static_buf_len, GFP_KERNEL);
		if (!static_buf) {
			VATOOLS_ERR(
				priv, die_index,
				"VATOOLS_IOCTL_PCIE_HOST_COUNT kvmalloc. size=%d\n",
				static_buf_len);
			ret = -ENOMEM;
			goto out_mutex_unlock;
		}

		memset(static_buf, 0x0, static_buf_len);

		for (i = 0; i < static_buf_cnt; i++) {
			ret = vatools_pci_mem_read(
				priv, die_index,
				ring_buf_statics_table[i].base_addr,
				(void *)(static_buf +
					 i * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME)),
				sizeof(T_VASTAI_FIFO_HEADER));
			if (ret < 0) {
				VATOOLS_ERR(
					priv, die_index,
					"Ring buf read memory base addr 0x%x error\n",
					ring_buf_statics_table[i].base_addr);
				ret = -EFAULT;
				goto out_free_static_buf;
			}
			memcpy(static_buf +
				       i * sizeof(T_VASTAI_FIFO_HEADER_WITHNAME) +
				       sizeof(T_VASTAI_FIFO_HEADER),
			       ring_buf_statics_table[i].name,
			       CMD_BUF_NAME_LONG);
			VATOOLS_DBG(
				priv, die_index,
				"Name: %s, total buf count %d, now loop %d times,\n",
				ring_buf_statics_table[i].name, static_buf_cnt,
				i);
		}
		ret = copy_to_user_ex((u8 *)ioctl_arg.output_buf.buf_addr +
					      sizeof(TS_SMI_CMD_REQ),
				      static_buf, static_buf_len);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%ld\n", ret);
			goto out_free_static_buf;
		}

	out_free_static_buf:
		kvfree(static_buf);
	} break;

#ifdef CONFIG_VASTAI_VIDEO
		/*Set video to use multicore; 0: Not used; 1: Use*/
	case VATOOLS_IOCTL_PCIE_SET_VIDEO_MULTI_CORE: {
		u32 work_mode = (ioctl_arg.address & 0xFFFFFFFF);
		/*call video callback function here*/
		VATOOLS_DBG(
			priv, die_index,
			"die inex=0x%x set video multicore work_mode to %d\n",
			die_index, work_mode);
		ret = hantroenc_set_work_mode(die_index,
					      (encoder_workmode_t)work_mode, 0);
	} break;
	case VATOOLS_IOCTL_PCIE_GET_VIDEO_MULTI_CORE: {
		u32 work_mode = 0;
		int job_count = 0;
		/*call video callback function here*/
		ret = hantroenc_get_work_mode(die_index,
					      (encoder_workmode_t *)&work_mode,
					      &job_count);
		ioctl_arg.address = work_mode;
		ioctl_arg.address = ioctl_arg.address << 32 | job_count;

		VATOOLS_DBG(
			priv, die_index,
			"die inex=0x%x get video multicore work_mode=%d, job_count=%d\n",
			die_index, work_mode, job_count);
		goto out_mutex_unlock;
	} break;
#endif

	default:
		VATOOLS_DBG(
			priv, die_index,
			"driver sub_cmd id %d don't support in current system\n",
			ioctl_arg.sub_cmd);
		break;
	}

out_mutex_unlock:
	mutex_unlock(&node->node_driver_mutex);

out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_index, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
}

/*Read memory data*/
long vatools_ioctl_read_buf(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	/*struct vatools_node *node = vatools_file_get_node(filp);*/
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;
	u8 *temp_buf = NULL;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_id, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	temp_buf = (u8 *)kvmalloc(ioctl_arg.output_buf.buf_size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_id, " kvmalloc error. size=%d\n",
			    ioctl_arg.output_buf.buf_size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, ioctl_arg.output_buf.buf_size);
	ret = vastai_pci_mem_read(priv, die_index, ioctl_arg.address, temp_buf,
				  ioctl_arg.output_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_id,
			     "vastai_pci_mem_read error, ret=%ld\n", ret);
		goto out_kvfree;
	}

	ret = copy_to_user_ex((void *)ioctl_arg.output_buf.buf_addr, temp_buf,
			      ioctl_arg.output_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);
out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
}

/*Write memory data*/
long vatools_ioctl_write_buf(struct file *filp, unsigned int cmd,
			     IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	/*struct vatools_node *node = vatools_file_get_node(filp);*/
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;
	u8 *temp_buf = NULL;

	V_UNREFERENCE(filp);

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, die_id, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_id, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	temp_buf = (u8 *)kvmalloc(ioctl_arg.input_buf.buf_size, GFP_KERNEL);
	if (!temp_buf) {
		VATOOLS_ERR(priv, die_id, " kvmalloc error. size=%d\n",
			    ioctl_arg.input_buf.buf_size);
		ret = -ENOMEM;
		goto out;
	}

	memset(temp_buf, 0, ioctl_arg.input_buf.buf_size);
	ret = copy_from_user_ex(temp_buf, (void *)ioctl_arg.input_buf.buf_addr,
				ioctl_arg.input_buf.buf_size);
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_from_user_ex is error\n");
		ret = -EIO;
		goto out_kvfree;
	}

	ret = vastai_pci_mem_write(priv, die_index, ioctl_arg.address, temp_buf,
				   ioctl_arg.input_buf.buf_size);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_id,
			     "vastai_pci_mem_read error, ret=%ld\n", ret);
		goto out_kvfree;
	}

out_kvfree:
	kvfree(temp_buf);
out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
}

/*Flash*/
long vatools_ioctl_flash_v2_bmcu_fw(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EINVAL;
#if (TOOLS_WIN == 1)
#else
	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;
	void *buf;

	VATOOLS_FUNC_ENTERY;

	die_id = ioctl_arg_p->die_index.die_id;
	dev_id = ioctl_arg_p->die_index.dev_id;
	die_index = (u32)ioctl_arg_p->die_index.val;

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg_p->block_id, ioctl_arg_p->die_index.val,
		ioctl_arg_p->sub_cmd, ioctl_arg_p->address, ioctl_arg_p->value,
		ioctl_arg_p->lock_domain, ioctl_arg_p->count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg_p->input_buf.buf_size,
		ioctl_arg_p->input_buf.buf_addr,
		ioctl_arg_p->output_buf.buf_size,
		ioctl_arg_p->output_buf.buf_addr);

	if (ioctl_arg_p->input_buf.buf_size <= 0) {
		ret = -EINVAL;
		goto out;
	}

	buf = kvmalloc(ioctl_arg_p->input_buf.buf_size, GFP_KERNEL);
	if (!buf) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = copy_from_user_ex(buf,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				ioctl_arg_p->input_buf.buf_size);
	if (ret) {
		ret = -EFAULT;
		goto out_free;
	}

	ret = vastai_pci_flash_bmcu_bin(priv, die_id, NULL, buf,
					ioctl_arg_p->input_buf.buf_size);

out_free:
	kvfree(buf);

out:
	ioctl_arg_p->errcode = ret;
	VATOOLS_DBG(priv, die_id, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
#endif
	return ret;
}

long vatools_ioctl_flash_v2_xspi_fw(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EINVAL;
#if (TOOLS_WIN == 1)
#else

	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;
	void *buf;

	VATOOLS_FUNC_ENTERY;

	die_id = ioctl_arg_p->die_index.die_id;
	dev_id = ioctl_arg_p->die_index.dev_id;
	die_index = (u32)ioctl_arg_p->die_index.val;

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg_p->block_id, ioctl_arg_p->die_index.val,
		ioctl_arg_p->sub_cmd, ioctl_arg_p->address, ioctl_arg_p->value,
		ioctl_arg_p->lock_domain, ioctl_arg_p->count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg_p->input_buf.buf_size,
		ioctl_arg_p->input_buf.buf_addr,
		ioctl_arg_p->output_buf.buf_size,
		ioctl_arg_p->output_buf.buf_addr);

	if (ioctl_arg_p->input_buf.buf_size <= 0) {
		ret = -EINVAL;
		goto out;
	}

	buf = kvmalloc(ioctl_arg_p->input_buf.buf_size, GFP_KERNEL);
	if (!buf) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = copy_from_user_ex(buf,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				ioctl_arg_p->input_buf.buf_size);
	if (ret) {
		ret = -EFAULT;
		goto out_free;
	}

	ret = vastai_pci_flash_xspi(priv, die_id, NULL, buf,
				    ioctl_arg_p->input_buf.buf_size,
				    VASTAI_PCI_FLASH_BL0);

out_free:
	kvfree(buf);

out:
	ioctl_arg_p->errcode = ret;
	VATOOLS_DBG(priv, die_id, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
#endif
	return ret;
}

long vatools_ioctl_flash_v2_get_status(struct file *filp, unsigned int cmd,
				       IOCTL_ARG_T arg,
				       struct vastai_pci_info *priv,
				       ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EINVAL;

#if (TOOLS_WIN == 1)
#else
	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;
	struct flash_state flash_state;

	VATOOLS_FUNC_ENTERY;

	die_id = ioctl_arg_p->die_index.die_id;
	dev_id = ioctl_arg_p->die_index.dev_id;
	die_index = (u32)ioctl_arg_p->die_index.val;

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg_p->block_id, ioctl_arg_p->die_index.val,
		ioctl_arg_p->sub_cmd, ioctl_arg_p->address, ioctl_arg_p->value,
		ioctl_arg_p->lock_domain, ioctl_arg_p->count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg_p->input_buf.buf_size,
		ioctl_arg_p->input_buf.buf_addr,
		ioctl_arg_p->output_buf.buf_size,
		ioctl_arg_p->output_buf.buf_addr);

	ret = copy_from_user_ex(&flash_state,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				sizeof(struct flash_state));
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

	flash_state.flash_state = 0;

	switch (flash_state.flash_type) {
	case 0:
		flash_state.flash_state =
			atomic_read(&(priv->pci_state)) == VASTAI_NORMAL_STATE;
		break;
	case 1:
		/*flash always is done*/
		flash_state.flash_state = 1;
		break;
	default:
		break;
	}

	ret = copy_to_user_ex((void __user *)ioctl_arg_p->input_buf.buf_addr,
			      &flash_state, sizeof(struct flash_state));
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret = -EFAULT;
		goto out;
	}

out:
	ioctl_arg_p->errcode = ret;
	VATOOLS_DBG(priv, die_id, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
#endif
	return ret;
}
long vatools_ioctl_flash_v2_switch_bmcu(struct file *filp, unsigned int cmd,
					IOCTL_ARG_T arg,
					struct vastai_pci_info *priv,
					ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EINVAL;
#if (TOOLS_WIN == 1)
#else
	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;

	VATOOLS_FUNC_ENTERY;

	die_id = ioctl_arg_p->die_index.die_id;
	dev_id = ioctl_arg_p->die_index.dev_id;
	die_index = (u32)ioctl_arg_p->die_index.val;

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg_p->block_id, ioctl_arg_p->die_index.val,
		ioctl_arg_p->sub_cmd, ioctl_arg_p->address, ioctl_arg_p->value,
		ioctl_arg_p->lock_domain, ioctl_arg_p->count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg_p->input_buf.buf_size,
		ioctl_arg_p->input_buf.buf_addr,
		ioctl_arg_p->output_buf.buf_size,
		ioctl_arg_p->output_buf.buf_addr);

	ret = vastai_send_pcie_cmd(priv, die_index,
				   VASTAI_PCIE_SUB_BMCU_DEGRADE, 0);
	ioctl_arg_p->errcode = ret;
	VATOOLS_DBG(priv, die_id, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
#endif
	return ret;
}

static long vatools_ioctl_flash_v2_full_bl0_fw(struct file *filp,
					       unsigned int cmd,
					       IOCTL_ARG_T arg,
					       struct vastai_pci_info *priv,
					       ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EINVAL;
#if (TOOLS_WIN == 1)
#else
	u32 die_index = 0;
	u32 die_id;
	u32 dev_id;
	void *buf;

	VATOOLS_FUNC_ENTERY;

	die_id = ioctl_arg_p->die_index.die_id;
	dev_id = ioctl_arg_p->die_index.dev_id;
	die_index = (u32)ioctl_arg_p->die_index.val;

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg_p->block_id, ioctl_arg_p->die_index.val,
		ioctl_arg_p->sub_cmd, ioctl_arg_p->address, ioctl_arg_p->value,
		ioctl_arg_p->lock_domain, ioctl_arg_p->count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg_p->input_buf.buf_size,
		ioctl_arg_p->input_buf.buf_addr,
		ioctl_arg_p->output_buf.buf_size,
		ioctl_arg_p->output_buf.buf_addr);

	if (ioctl_arg_p->input_buf.buf_size <= 0) {
		ret = -EINVAL;
		goto out;
	}

	buf = kvmalloc(ioctl_arg_p->input_buf.buf_size, GFP_KERNEL);
	if (!buf) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = copy_from_user_ex(buf,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				ioctl_arg_p->input_buf.buf_size);
	if (ret) {
		ret = -EFAULT;
		goto out_free;
	}

	if (vastai_get_board_type(priv) == SG100 && priv->is_pf) {
		VATOOLS_DBG(priv, die_id, "%s: start flash sg100 fullbl0\n",
			    __func__);
		ret = vastai_pci_flash_xspi(priv, die_id, NULL, buf,
					    ioctl_arg_p->input_buf.buf_size,
					    VASTAI_PCI_FLASH_FULL);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_id,
				     "%s: flash xspi fail, ret=%ld\n", __func__,
				     ret);
			goto out_free;
		}
		vastai_pci_get_fw_ver_sg(priv, 0x1800);

		VATOOLS_DBG(priv, die_id, "%s: flash sg100 fullbl0 ok\n",
			    __func__);
	} else if (vastai_get_board_type(priv) == SV100) {
		VATOOLS_DBG(priv, die_id, "%s: start flash sv100 fullbl0\n",
			    __func__);
		ret = vastai_pci_flash_xspi(priv, die_id, NULL, buf,
					    ioctl_arg_p->input_buf.buf_size,
					    VASTAI_PCI_FLASH_FULL);
		if (ret < 0) {
			VATOOLS_INFO(priv, die_id,
				     "%s: flash xspi fail, ret=%ld\n", __func__,
				     ret);
			goto out_free;
		}
		vastai_pci_get_fw_ver(priv, 0x1C00, false);

		VATOOLS_DBG(priv, die_id, "%s: flash sv100 fullbl0 ok\n",
			    __func__);
	} else {
		VATOOLS_INFO(priv, die_id, "%s: unknown board fullbl0\n",
			     __func__);
		ret = -EFAULT;
	}

out_free:
	kvfree(buf);

out:
	ioctl_arg_p->errcode = ret;
	VATOOLS_DBG(priv, die_id, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
#endif
	return ret;
}

/*Flash-related operations*/
long vatools_ioctl_flash_cmd(struct file *filp, unsigned int cmd,
			     IOCTL_ARG_T arg)
{
#if (TOOLS_WIN == 1)
	long ret = -EINVAL;
	return ret;
#else
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;
	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, die_id, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_id, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	switch (ioctl_arg.sub_cmd) {
	case VATOOLS_IOCTL_FLASH_FULL_BL0_FW: {
		domain_mutex_lock(priv, ioctl_arg.die_index.val,
				  ioctl_arg.lock_domain);
		ret = vatools_ioctl_flash_v2_full_bl0_fw(filp, cmd, arg, priv,
							 &ioctl_arg);
		domain_mutex_unlock(priv, ioctl_arg.die_index.val,
				    ioctl_arg.lock_domain);
		break;
	}
	case VATOOLS_IOCTL_FLASH_BMCU_FW: {
		domain_mutex_lock(priv, ioctl_arg.die_index.val,
				  ioctl_arg.lock_domain);
		ret = vatools_ioctl_flash_v2_bmcu_fw(filp, cmd, arg, priv,
						     &ioctl_arg);
		domain_mutex_unlock(priv, ioctl_arg.die_index.val,
				    ioctl_arg.lock_domain);
		break;
	}
	case VATOOLS_IOCTL_FLASH_XSPI_FW: {
		domain_mutex_lock(priv, ioctl_arg.die_index.val,
				  ioctl_arg.lock_domain);
		ret = vatools_ioctl_flash_v2_xspi_fw(filp, cmd, arg, priv,
						     &ioctl_arg);
		domain_mutex_unlock(priv, ioctl_arg.die_index.val,
				    ioctl_arg.lock_domain);
		break;
	}
	case VATOOLS_IOCTL_FLASH_GET_FLASH_STATUS: {
		domain_mutex_lock(priv, ioctl_arg.die_index.val,
				  ioctl_arg.lock_domain);
		ret = vatools_ioctl_flash_v2_get_status(filp, cmd, arg, priv,
							&ioctl_arg);
		domain_mutex_unlock(priv, ioctl_arg.die_index.val,
				    ioctl_arg.lock_domain);
		break;
	}
	case VATOOLS_IOCTL_FLASH_SWITCH_BMCU: {
		domain_mutex_lock(priv, ioctl_arg.die_index.val,
				  ioctl_arg.lock_domain);
		ret = vatools_ioctl_flash_v2_switch_bmcu(filp, cmd, arg, priv,
							 &ioctl_arg);
		domain_mutex_unlock(priv, ioctl_arg.die_index.val,
				    ioctl_arg.lock_domain);
		break;
	}
	default: {
		ret = -E_UNKNOWN_SUB_CMD;
		VATOOLS_DBG(
			priv, die_id,
			"flash sub_cmd id %d don't support in current system\n",
			ioctl_arg.sub_cmd);
		break;
	}
	}

out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
#endif
}

/*Use kernel mutex to implement process mutex protection: locking*/
int vatools_process_mutex_lock(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	char mutex_name[VATOOLS_IOCTL_GUARD_NAME_LENGTH] = { 0 };
	struct vatools_process_mutex *p_process_mutex = NULL;
	struct vatools_process_mutex *p_current_process_mutex = NULL,
				     *p_next_process_mutex = NULL;
	bool found_mutex_name = false;
	struct vatools_process_mutex_filp *p_current_filp = NULL;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	memset(mutex_name, 0x00, sizeof(mutex_name));
	ret = copy_from_user_ex(mutex_name,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				sizeof(mutex_name));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		return ret;
	}

	VATOOLS_DBG(priv, die_index, "ioctl_cmd=0x%x mutex_name=%s\n", cmd,
		    mutex_name);

	/*If mutex_name does not exist, a new node is allocated*/
	list_for_each_entry_safe (p_current_process_mutex, p_next_process_mutex,
				  &node->list_node_process_mutex,
				  list_member_process_mutex) {
		VATOOLS_DBG(priv, die_index,
			    "p_current_process_mutex=0x%p  mutex_name=%s\n",
			    p_current_process_mutex,
			    p_current_process_mutex->mutex_name);
		if (strcmp(p_current_process_mutex->mutex_name, mutex_name) ==
		    0) {
			/*find mutex_name*/
			found_mutex_name = true;
			break;
		}
	}

	if (found_mutex_name) {
		VATOOLS_DBG(priv, die_index, "found mutex_name=%s\n",
			    p_current_process_mutex->mutex_name);
		p_process_mutex = p_current_process_mutex;
	} else {
		VATOOLS_DBG(priv, die_index, "not found mutex_name=%s\n",
			    mutex_name);
		/*Not found, initialize the new mutex node*/
		p_process_mutex = (struct vatools_process_mutex *)kvmalloc(
			sizeof(struct vatools_process_mutex), GFP_KERNEL);
		if (!p_process_mutex) {
			VATOOLS_ERR(priv, die_index,
				    "kvmalloc error. size=%ld\n",
				    sizeof(struct vatools_process_mutex));
			return -ENOMEM;
		}

		memset(p_process_mutex, 0,
		       sizeof(struct vatools_process_mutex));

		INIT_LIST_HEAD(&p_process_mutex->list_member_process_mutex);
		INIT_LIST_HEAD(&p_process_mutex->list_head_filp);

		strcpy(p_process_mutex->mutex_name, mutex_name);
		mutex_init(&p_process_mutex->process_mutex);

		list_add_tail(&p_process_mutex->list_member_process_mutex,
			      &node->list_node_process_mutex);
	}

	/*Mount the current filp on the linked list corresponding to mutex_name*/
	p_current_filp = (struct vatools_process_mutex_filp *)kvmalloc(
		sizeof(struct vatools_process_mutex_filp), GFP_KERNEL);
	if (!p_current_filp) {
		VATOOLS_ERR(priv, die_index, "kvmalloc error. size=%ld\n",
			    sizeof(struct vatools_process_mutex_filp));
		return -ENOMEM;
	}
	p_current_filp->filp = filp;
	list_add_tail(&p_current_filp->list_member_filp,
		      &p_process_mutex->list_head_filp);

	VATOOLS_DBG(priv, die_index, "mutex_lock=%p\n",
		    &p_process_mutex->process_mutex);
	mutex_lock(&p_process_mutex->process_mutex);

	ret = 0;
	return ret;
}

/*Implement process mutex protection using kernel mutex: unlock*/
int vatools_process_mutex_unlock(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg, struct vastai_pci_info *priv,
				 ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	char mutex_name[VATOOLS_IOCTL_GUARD_NAME_LENGTH] = { 0 };
	struct vatools_process_mutex *p_process_mutex = NULL;
	struct vatools_process_mutex *p_current_process_mutex = NULL,
				     *p_next_process_mutex = NULL;
	bool found_mutex_name = false;
	struct vatools_process_mutex_filp *p_current_process_mutex_filp = NULL,
					  *p_next_process_mutex_filp = NULL;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	memset(mutex_name, 0x00, sizeof(mutex_name));
	ret = copy_from_user_ex(mutex_name,
				(void __user *)ioctl_arg_p->input_buf.buf_addr,
				sizeof(mutex_name));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index, "ioctl_cmd=0x%x mutex_name=%s\n", cmd,
		    mutex_name);

	/*Find the node that matches the mutex_name*/
	list_for_each_entry_safe (p_current_process_mutex, p_next_process_mutex,
				  &node->list_node_process_mutex,
				  list_member_process_mutex) {
		VATOOLS_DBG(priv, die_index,
			    "p_current_process_mutex=0x%p  mutex_name=%s\n",
			    p_current_process_mutex,
			    p_current_process_mutex->mutex_name);
		if (strcmp(p_current_process_mutex->mutex_name, mutex_name) ==
		    0) {
			/*find mutex_name*/
			found_mutex_name = true;
			break;
		}
	}

	if (found_mutex_name) {
		VATOOLS_DBG(priv, die_index, "found mutex_name=%s\n",
			    p_current_process_mutex->mutex_name);
		p_process_mutex = p_current_process_mutex;
		VATOOLS_DBG(priv, die_index, "mutex_unlock=%p\n",
			    &p_process_mutex->process_mutex);
		mutex_unlock(&p_process_mutex->process_mutex);

		/*Deletes the memory corresponding to the current filp*/
		list_for_each_entry_safe (p_current_process_mutex_filp,
					  p_next_process_mutex_filp,
					  &p_process_mutex->list_head_filp,
					  list_member_filp) {
			VATOOLS_DBG(
				priv, die_index,
				"p_current_process_mutex_filp=0x%p  filp=%p\n",
				p_current_process_mutex_filp,
				p_current_process_mutex_filp->filp);
			if (filp == p_current_process_mutex_filp->filp) {
				/*Delete the filp node*/
				list_del(&(
					p_current_process_mutex_filp
						->list_member_filp)); /* To delete a node, the node must be deleted before the node memory is deleted*/
				kvfree(p_current_process_mutex_filp); /* Free up node memory*/
			}
		}
	} else {
		VATOOLS_DBG(priv, die_index, "not found mutex_name=%s\n",
			    mutex_name);
	}

out:
	return ret;
}

/*Use kernel mutex to implement process mutex protection: whether to lock or not*/
int vatools_process_mutex_is_locked(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	char mutex_name[256] = { 0 };
	struct vatools_process_mutex *p_process_mutex = NULL;
	struct vatools_process_mutex *p_current_process_mutex = NULL,
				     *p_next_process_mutex = NULL;
	bool found_mutex_name = false;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	/*Find the node that matches the mutex_name*/
	list_for_each_entry_safe (p_current_process_mutex, p_next_process_mutex,
				  &node->list_node_process_mutex,
				  list_member_process_mutex) {
		VATOOLS_DBG(priv, die_index,
			    "p_current_process_mutex=0x%p  mutex_name=%s\n",
			    p_current_process_mutex,
			    p_current_process_mutex->mutex_name);
		if (strcmp(p_current_process_mutex->mutex_name, mutex_name) ==
		    0) {
			/*find mutex_name*/
			found_mutex_name = true;
			break;
		}
	}

	if (found_mutex_name) {
		VATOOLS_DBG(priv, die_index, "found mutex_name=%s\n",
			    p_current_process_mutex->mutex_name);
		p_process_mutex = p_current_process_mutex;
		VATOOLS_DBG(priv, die_index, "mutex_is_locked=%p\n",
			    &p_process_mutex->process_mutex);
		ret = mutex_is_locked(
			&p_process_mutex
				 ->process_mutex); /*Returns 1 if the mutex is locked, 0 if unlocked.*/
	} else {
		ret = 0;
	}

	return ret;
}

/*Implement process mutex protection using kernel mutex: Try locking.*/
/*Try to acquire the mutex atomically.*/
/*Returns 1 if the mutex has been*/
/*acquired successfully, and 0 on contention.*/
int vatools_process_mutex_trylock(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg, struct vastai_pci_info *priv,
				  ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	char mutex_name[256] = { 0 };
	struct vatools_process_mutex *p_process_mutex = NULL;
	struct vatools_process_mutex *p_current_process_mutex = NULL,
				     *p_next_process_mutex = NULL;
	bool found_mutex_name = false;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	/*Find the node that matches the mutex_name*/
	list_for_each_entry_safe (p_current_process_mutex, p_next_process_mutex,
				  &node->list_node_process_mutex,
				  list_member_process_mutex) {
		VATOOLS_DBG(priv, die_index,
			    "p_current_process_mutex=0x%p  mutex_name=%s\n",
			    p_current_process_mutex,
			    p_current_process_mutex->mutex_name);
		if (strcmp(p_current_process_mutex->mutex_name, mutex_name) ==
		    0) {
			/*find mutex_name*/
			found_mutex_name = true;
			break;
		}
	}

	if (found_mutex_name) {
		VATOOLS_DBG(priv, die_index, "found mutex_name=%s\n",
			    p_current_process_mutex->mutex_name);
		p_process_mutex = p_current_process_mutex;
		VATOOLS_DBG(priv, die_index, "mutex_try_lock=%p\n",
			    &p_process_mutex->process_mutex);
		ret = mutex_trylock(
			&p_process_mutex
				 ->process_mutex); /*Try to acquire the mutex atomically. Returns 1 if the mutex has been*/
		/*acquired successfully, and 0 on contention.*/
	} else {
		ret = 0;
	}

	return ret;
}

/*Process mutex protection with kernel mutex: When a file is closed, all mutex associated with the file are released*/
int vatools_process_release_mutex_unlock(struct file *filp, unsigned int cmd,
					 IOCTL_ARG_T arg,
					 struct vastai_pci_info *priv,
					 ioctl_arg_t *ioctl_arg_p)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	/*void __user* rgp = ( wide __user* )arg;*/
	/*four mutex_names[ 256 ] = { 0 };*/
	/*struct wattles_process_mutex* p_process_mutex = null;*/
	struct vatools_process_mutex *p_current_process_mutex = NULL,
				     *p_next_process_mutex = NULL;
	/*bool                               found_mutex_name             = false;*/
	struct vatools_process_mutex_filp *p_current_process_mutex_filp = NULL,
					  *p_next_process_mutex_filp = NULL;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	/*File node close, unlock all related mutex*/

	/*TODO: If it is used by the last process, unlock and delete the node*/
	/*Find the node that matches the mutex_name*/
	list_for_each_entry_safe (p_current_process_mutex, p_next_process_mutex,
				  &node->list_node_process_mutex,
				  list_member_process_mutex) {
		VATOOLS_DBG(priv, die_index,
			    "p_current_process_mutex=0x%p  mutex_name=%s\n",
			    p_current_process_mutex,
			    p_current_process_mutex->mutex_name);

		/*Deletes the memory corresponding to the current filp*/
		list_for_each_entry_safe (
			p_current_process_mutex_filp, p_next_process_mutex_filp,
			&p_current_process_mutex->list_head_filp,
			list_member_filp) {
			VATOOLS_DBG(
				priv, die_index,
				"p_current_process_mutex_filp=0x%p  filp=%p\n",
				p_current_process_mutex_filp,
				p_current_process_mutex_filp->filp);
			if (filp == p_current_process_mutex_filp->filp) {
				VATOOLS_DBG(
					priv, die_index, "mutex_unlock=%p\n",
					&p_current_process_mutex->process_mutex);
				mutex_unlock(
					&p_current_process_mutex->process_mutex);
				/*Delete the filp node*/
				list_del(&(
					p_current_process_mutex_filp
						->list_member_filp)); /* To delete a node, the node must be deleted before the node memory is deleted*/
				kvfree(p_current_process_mutex_filp); /* Free up node memory*/
			}
		}
	}
	VATOOLS_FUNC_EXIT;
	return ret;
}

/*process mutex*/
long vatools_ioctl_process_mutex_cmd(struct file *filp, unsigned int cmd,
				     IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	/*struct vatools_node *node = vatools_file_get_node(filp);*/
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(NULL, die_id, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_id, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	switch (ioctl_arg.sub_cmd) {
		/*Implement process mutex protection with kernel mutex: lock*/
	case VATOOLS_IOCTL_GUARD_LOCK: {
		ret = vatools_process_mutex_lock(filp, cmd, arg, priv,
						 &ioctl_arg);
		return ret;
	} break;

		/*Implement process mutex protection using kernel mutex: unlock*/
	case VATOOLS_IOCTL_GUARD_UNLOCK: {
		ret = vatools_process_mutex_unlock(filp, cmd, arg, priv,
						   &ioctl_arg);
		return ret;
	} break;
	/**/
	case VATOOLS_IOCTL_GUARD_TRYLOCK: {
		ret = vatools_process_mutex_is_locked(filp, cmd, arg, priv,
						      &ioctl_arg);
		return ret;
	} break;

	case VATOOLS_IOCTL_GUARDU_IS_LOCKED: {
		ret = vatools_process_mutex_trylock(filp, cmd, arg, priv,
						    &ioctl_arg);
		return ret;
	} break;
	default: {
		VATOOLS_DBG(
			priv, die_id,
			"process mutex sub_cmd id %d don't support in current system\n",
			ioctl_arg.sub_cmd);
		break;
	}
	}

out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld   ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
}

/*Drive internal access to SMI*/
int vatools_driver_smi_cmd(u32 block_id, struct vastai_pci_info *priv,
			   int die_index, void *buf, unsigned int len)
{
	int ret = 0;
	TS_SMI_CMD_REQ *cmd = (TS_SMI_CMD_REQ *)buf;
	T_SMI_BLOCK *psmi_block;
	u64 smi_die_address_offset;
	u32 loop;
	u32 interval;
	struct vastai_sv100_die *die;
	union die_index_data did;
	u32 die_id;

	did.val = (u32)die_index;
	die_id = did.die_id;

	VATOOLS_DBG(priv, die_id, "block_id=%d, priv=%p, die_index=0x%x\n",
		    block_id, priv, die_index);

	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);

	psmi_block = vatools_fw_smi_get_block(priv, block_id);
	smi_die_address_offset = psmi_block->block_address;
	loop = psmi_block->query_count;
	interval = psmi_block->query_interval;

	/*add smi seq*/
	cmd->seq = vatools_get_smi_seq();

	VATOOLS_DUMP_BRIEF("driver_smi_cmd cmd req: ", buf, len);
	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset,
				   (u8 *)buf, len);
	if (ret < 0) {
		VATOOLS_DBG(priv, die_id, "ret=%d\n", ret);
		goto out_mutex_unlock;
	}

	/*set flag to 1, write only 4 bytes , sync with fw*/
	cmd->flag = FLAG_APP_REQ;
	ret = vastai_pci_mem_write(priv, die_index, smi_die_address_offset + 4,
				   ((u8 *)cmd) + 4, sizeof(u32));
	if (ret < 0) {
		VATOOLS_DBG(priv, die_id, "ret=%d\n", ret);
		goto out_mutex_unlock;
	}

	/*If it is a user interrupt, you need to clear the ack reply of the last smi command here,
	Otherwise, every time you enter here, wait_for will return directly, resulting in a mismatch between wait and ack*/

	if (!priv || (priv->die_num_in_fn <= die_id)) {
		VATOOLS_DBG(priv, die_id, "priv->die_num=%d < die_id=%d\n",
			    priv->die_num_in_fn, die_id);
		ret = -EINVAL;
		goto out_mutex_unlock;
	}
	die = &(priv->dies[die_id]);
	reinit_completion(&(die->smi_ack[block_id]));

	ret = vatools_fw_send_smi_interrupt(priv, die_index);
	ret = vatools_wait_smi_ack(priv, die_index, block_id, 5, NULL, 0);
	if (ret < 0) {
		if (ret == -EINTR) {
			VATOOLS_DBG(
				priv, die_id,
				"smi_ack: die_index=0x%x block_id=%d ret=%d(-EINTR)\n",
				die_index, block_id, ret);
			goto out_mutex_unlock;
		} else if (ret == -ETIMEDOUT) {
			VATOOLS_INFO(
				priv, die_id,
				"smiack: die_index=0x%x block_id=%d ret=%d(-ETIMEDOUT)\n",
				die_index, block_id, ret);
		} else {
			VATOOLS_INFO(
				priv, die_id,
				"smi_ack: die_index=0x%x block_id=%d ret=%d\n",
				die_index, block_id, ret);
			goto out_mutex_unlock;
		}
	} else if (ret != FLAG_FW_DATA_READY) {
		ret = -ENXIO;
		goto out_mutex_unlock;
	}

	ret = vastai_pci_mem_read(priv, die_index, smi_die_address_offset, buf,
				  len);
	if (ret < 0) {
		VATOOLS_DBG(priv, die_id, "ret=%d\n", ret);
		goto out_mutex_unlock;
	}
	VATOOLS_DUMP_BRIEF("driver_smi_cmd cmd rsp: ", buf, len);

	VATOOLS_DBG(priv, die_id, "read cmd.flag=%d\n", cmd->flag);

	if (cmd->flag == FLAG_FW_DATA_READY) {
		ret = len;
	} else {
		ret = -ENXIO;
	}

out_mutex_unlock:
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);

	VATOOLS_DBG(priv, die_id, "done ret=%d\n", ret);
	return ret;
}

/*dma*/
/*DMA allocates memory*/
int vatools_ioctl_dma_alloc_ex(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p)
{
	int ret = -EIO;
#if (TOOLS_WIN == 1)
#else
	int die_index = 0;
	struct dma_buf *dmabuf = NULL;
	dma_alloc_cmd_t dma_alloc_cmd;
	union die_index_data did;
	u32 die_id;

	VATOOLS_FUNC_ENTERY;

	memset(&dma_alloc_cmd, 0, sizeof(dma_alloc_cmd_t));
	ret = copy_from_user_ex(&dma_alloc_cmd,
				(void *)ioctl_arg_p->input_buf.buf_addr,
				sizeof(dma_alloc_cmd_t));
	if (ret) {
		VATOOLS_ERR(priv, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}

	die_index = dma_alloc_cmd.die_index;
	did.val = (u32)die_index;
	die_id = did.die_id;

	VATOOLS_DBG(priv, die_id, "die_index=0x%x, dma_buf_fd=0x%x, size=%d\n",
		    die_index, dma_alloc_cmd.dma_buf_fd, dma_alloc_cmd.size);

	dmabuf = vastai_alloc_dma_buf(priv, dma_alloc_cmd.size);
	if (dmabuf) {
		int fd = dma_buf_fd(dmabuf, O_CLOEXEC);
		dma_alloc_cmd.dma_buf_fd = fd;
	} else {
		dma_alloc_cmd.dma_buf_fd = -ENOMEM;
	}

	ret = copy_to_user_ex((void *)ioctl_arg_p->output_buf.buf_addr,
			      &dma_alloc_cmd, sizeof(dma_alloc_cmd_t));
	if (ret) {
		VATOOLS_ERR(priv, die_id, "copy_from_user_ex is error\n");
		return -EIO;
	}
#endif
	return ret;
}

/*Start the DMA transfer*/
int vatools_ioctl_dma_start_ex(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p)
{
	int ret = -EIO;
#if (TOOLS_WIN == 1)
#else
	struct dma_buf *dmabuf = NULL;
	struct vastai_dmadesc desc;
	union core_bitmap core_id = { .val = 0 };
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
	struct timespec tm_begin, tm_end;
#else
	u64 tm_begin, tm_end;
#endif
	unsigned long time_total_ns;
	u32 done_size = 0;
	u32 size = 0;
	u32 i = 0;
	dma_start_cmd_t dma_start_cmd;
	union die_index_data did;
	u32 die_id;
	u32 die_index;

	VATOOLS_FUNC_ENTERY;

	memset(&dma_start_cmd, 0, sizeof(dma_start_cmd_t));
	ret = copy_from_user_ex(&dma_start_cmd,
				(void *)ioctl_arg_p->input_buf.buf_addr,
				sizeof(dma_start_cmd_t));
	if (ret) {
		VATOOLS_ERR(priv, DUMMY_DIE_ID, "copy_from_user_ex is error\n");
		return -EIO;
	}
	die_index = dma_start_cmd.die_index;
	did.val = (u32)die_index;
	die_id = did.die_id;
	VATOOLS_DBG(
		priv, die_id,
		"die_index=0x%x, dma_buf_fd=0x%x, size=%d, axi_addr=0x%llx, is_dev_to_host=%d\n",
		die_index, dma_start_cmd.dma_buf_fd, dma_start_cmd.size,
		dma_start_cmd.axi_addr, dma_start_cmd.is_dev_to_host);

	dmabuf = dma_buf_get(dma_start_cmd.dma_buf_fd);
	if (IS_ERR(dmabuf)) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s dma buf fd is invalid\n",
			       __func__);
		return PTR_ERR(dmabuf);
	}
	size = dma_start_cmd.size;

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
	/*getnstimeofday function is removed from kernel5.6*/
	getnstimeofday(&tm_begin);
#else
	tm_begin = ktime_get_ns();
#endif

	desc.is_host_to_dev = !dma_start_cmd.is_dev_to_host;
	desc.is_src_not_user_mem = 1;
	desc.is_src_dma_addr = 1;

	while (done_size < dma_start_cmd.size) {
		struct vastai_dma_buf *dm = get_vastai_dma_buf(dmabuf, i);
		u32 temp_size = (size - done_size) < VASTAI_MAX_DMA_BUF ?
					(size - done_size) :
					VASTAI_MAX_DMA_BUF;

		desc.dev_addr = dma_start_cmd.axi_addr + done_size;
		desc.dma_lenth = temp_size;
		desc.host_addr.dma_addr = dm->dma_bus_addr;

		ret = vastai_pci_dma_transfer_sync(
			priv, dma_start_cmd.die_index, core_id, &desc, 1, -1);
		if (ret)
			break;

		i++;
		done_size += temp_size;
	}

	dma_buf_put(dmabuf);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
	getnstimeofday(&tm_end);
	time_total_ns = timespec_to_ns(&tm_end) - timespec_to_ns(&tm_begin);
#else
	tm_end = ktime_get_ns();
	time_total_ns = tm_end - tm_begin;
#endif

	if (time_total_ns > 30000 && 0) {
		struct vastai_fifo fifo;
		VATOOLS_DBG(priv, die_id, "die_index 0x%x time %ld\n",
			    dma_start_cmd.die_index, time_total_ns);

		vastai_pci_mem_read(priv, dma_start_cmd.die_index, 0x8c14000,
				    &fifo, sizeof(struct vastai_fifo));

		VATOOLS_DBG(
			priv, die_id,
			"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x] ",
			"0x8c14000\n", fifo.rd, fifo.wr, fifo.elem_count,
			fifo.elem_size);

		vastai_pci_mem_read(priv, dma_start_cmd.die_index, 0x8c1e000,
				    &fifo, sizeof(struct vastai_fifo));

		VATOOLS_DBG(
			priv, die_id,
			"%s rd[0x%x] wr[0x%x] elem_count[0x%x] elem_size[0x%x] ",
			"0x8c1e000\n", fifo.rd, fifo.wr, fifo.elem_count,
			fifo.elem_size);
	}
#endif
	return ret;
}

/*Start the DMA transfer*/
int vatools_ioctl_dma_free_ex(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			      ioctl_arg_t *ioctl_arg_p)
{
	int ret = -EIO;
#if (TOOLS_WIN == 1)
#else
#endif
	return ret;
}

long vatools_ioctl_dma_cmd(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
#if (TOOLS_WIN == 1)
	long ret = -EINVAL;
	return ret;
#else
	long ret = -EINVAL;

	long ret2 = 0;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	ioctl_arg_t ioctl_arg;

	/*struct vatools_node *node = vatools_file_get_node(filp);*/
	/*struct vatools_reader *reader = vatools_file_get_reader(filp);*/

	u32 die_index = 0;
	u32 die_id = 0;
	u32 dev_id = 0;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(priv, die_index, "ioctl cmd=0x%x\n", cmd);

	memset(&ioctl_arg, 0x00, sizeof(ioctl_arg_t));
	ret = copy_from_user_ex(&ioctl_arg, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	die_id = ioctl_arg.die_index.die_id;
	dev_id = ioctl_arg.die_index.dev_id;
	die_index = (u32)ioctl_arg.die_index.val;

	priv = vatools_get_vastai_pci_device_info((char)dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_id, "priv is NULL, dev_id=0x%x\n",
			     dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	VATOOLS_DBG(
		priv, die_id,
		"block_id=%d die_index=0x%x sub_cmd=0x%x address=0x%llx value=0x%llx lock_domain=%d count=%d\n",
		ioctl_arg.block_id, ioctl_arg.die_index.val, ioctl_arg.sub_cmd,
		ioctl_arg.address, ioctl_arg.value, ioctl_arg.lock_domain,
		ioctl_arg.count);
	VATOOLS_DBG(
		priv, die_id,
		"input_buf_size=%d input_buf_addr=0x%llx output_buf_size=%d output_buf_addr=0x%llx\n",
		ioctl_arg.input_buf.buf_size, ioctl_arg.input_buf.buf_addr,
		ioctl_arg.output_buf.buf_size, ioctl_arg.output_buf.buf_addr);

	switch (ioctl_arg.sub_cmd) {
	case VATOOLS_IOCTL_DMA_ALLOC: {
		ret = vatools_ioctl_dma_alloc_ex(filp, cmd, arg, priv,
						 &ioctl_arg);
	} break;
	case VATOOLS_IOCTL_DMA_START: {
		ret = vatools_ioctl_dma_start_ex(filp, cmd, arg, priv,
						 &ioctl_arg);
	} break;
	case VATOOLS_IOCTL_DMA_FREE: {
		ret = vatools_ioctl_dma_free_ex(filp, cmd, arg, priv,
						&ioctl_arg);
	} break;
	default:
		VATOOLS_DBG(
			priv, die_id,
			"dma sub_cmd id %d don't support in current system\n",
			ioctl_arg.sub_cmd);
		break;
	}

out:
	ioctl_arg.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &ioctl_arg,
			       sizeof(ioctl_arg_t));
	if (ret2) {
		VATOOLS_ERR(priv, die_id, "copy_to_user_ex ret=%ld\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_id, "out: ret=%ld ret2=%ld\n", ret, ret2);
	VATOOLS_FUNC_EXIT;
	return ret2;
#endif
}
#endif
