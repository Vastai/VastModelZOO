#include "vatools.h"
#include "vatools_log.h"

extern atomic_t _vatools_changed_device_count;

/*
 * dummy fops
 */
loff_t dummy_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);

	return 0;
}

ssize_t dummy_read(struct file *filp, char __user *buf, size_t size,
		   loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t dummy_write(struct file *filp, const char __user *buf, size_t size,
		    loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t dummy_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);

	return 0;
}

unsigned int dummy_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);

	return 0;
}

long dummy_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EIO;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);
	return ret;
}

int dummy_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);

	return 0;
}
int dummy_open(struct inode *inode, struct file *filp)
{
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);

	return 0;
}

int dummy_release(struct inode *ignored, struct file *filp)
{
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(ignored);
	V_UNREFERENCE(filp);

	return 0;
}

int dummy_fasync(int fd, struct file *filp, int mode)
{
	V_UNREFERENCE(fd);
	V_UNREFERENCE(filp);
	V_UNREFERENCE(mode);

	return 0;
}

#ifdef CONFIG_TOOLS_V2

/*Obtain the physical card cardtype string via driver*/
static char *vatools_get_physical_card_type(struct vastai_pci_info *priv)
{
	u32 card_type = 0;
	extern u32 cardtype; /*set by insmod parameter cardtype=0x..*/

	V_UNREFERENCE(priv);

	/*from driver-fw Read cardtype*/
	/*TODO: wait level0 support*/
	if (0) {
		/*get from driver pci_info*/
	} else {
		/*If fetching from driver fails, or is not supported, configure cardtype according to the driver macro definition*/
		if (cardtype != UINT_MAX)
			card_type = cardtype;
		else
			card_type = CONFIG_CARD_TYPE;
	}
	VATOOLS_DBG(priv, DUMMY_DIE_ID, "get_physical_card_type=0x%x\n",
		    card_type);
	switch (card_type) {
	case CARD_CLASS_VA100:
		return "VA100\0";
		break;
	case CARD_CLASS_VAM:
		return "VAM\0";
		break;
	case CARD_VA16:
		return "VA16\0";
		break;
	}
	return NULL;
}

struct vastai_die_info *vatool_get_die_info(struct vastai_pci_info *priv,
					    u8 die_id_in_fn)
{
	return vastai_get_die_info(priv, die_id_in_fn);

#if 0
	struct fn_tree_node *tree_node = NULL;
	list_for_each_entry (tree_node, &priv->fn_node_list, internal_node) {
		return tree_node->die_info;
	}
	return NULL;
#endif
}

struct vastai_pkg_info *vatool_get_pkg_info(struct vastai_pci_info *priv,
					    u8 die_id_in_fn)
{
	return vastai_get_pkg_info(priv, die_id_in_fn);
#if 0
	struct vastai_die_info *die_info =
		vatool_get_die_info(priv, die_id_in_fn);
	if (die_info)
		return die_info->pkg_info;
	VATOOLS_DBG(priv, die_id_in_fn,
		    "%s no find die_info of die_id_in_fn=%d\n", __FUNCTION__,
		    die_id_in_fn);
	return NULL;
#endif
}

int vatools_v2_clear_device_info(void *priv)
{
#if (TOOLS_DEBUG_NO_DEV_INFO_CACHE == 0)
	struct vatools_node *node_p = vatools_get_node();

	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
	if (node_p->dev_info != NULL) {
		VATOOLS_DBG(priv, DUMMY_DIE_ID,
			    "remove device info cache. node->dev_info=%p\n",
			    node_p->dev_info);
		vfree(node_p->dev_info);
		node_p->dev_info = NULL;
		node_p->device_num = 0;
	}
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
#endif
	return 0;
}

#if 0
static void check_need_refresh_cache(struct vatools_node *node)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		struct timespec tm_origin;
		u64 tm;
#else
		u64 tm;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
		getnstimeofday(&tm_origin);
		tm = timespec_to_ns(&tm_origin);
#else
		tm = ktime_get_ns();
#endif

	if (tm - node->last_refresh_time > DEVINFO_REFRESH_INTERVAL * NSEC_PER_SEC) {

		vatools_v2_clear_device_info(NULL);
		node->last_refresh_time = tm;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "timeout need refresh devinfo cache\n");
	}
}
#endif

void refresh_pcie_inventory_cache(void)
{
	int die = 0;
	long ret = -EINVAL;
	struct vastai_card_info *card_info = NULL;
	struct vastai_pci_info *pci_info = NULL;
	struct vatools_node *node = vatools_get_node();

	down_read(&tools_devs_rw_sem);
	mutex_lock(&node->inventory_cache_mutex);
	list_for_each_entry (pci_info, &vastai_tools_devs_list,
			     tools_dev_list) {
		if (pci_info == NULL) {
			VATOOLS_DBG(pci_info, DUMMY_DIE_ID, "priv is NULL\n");
			continue;
		}
		if (vatools_check_pci_state(pci_info, VASTAI_NORMAL_STATE,
					    VASTAI_NO_RUN_STATE,
					    VASTAI_DEBUG_STATE, -1)) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"pci_info->pci_state=0x%x  skip emulate device\n",
				atomic_read(&pci_info->pci_state));
			continue;
		}
		die = 0;
		card_info = vastai_get_card_info(pci_info);
		ret = vatools_get_spi_buf(pci_info->dies[die].die_index,
					  SPI_BLOCK_EEPROM, 0, SPI_BUF_LEN_MAX,
					  card_info->inventory);
		if (ret < 0) {
			memset(card_info->inventory, '\0',
			       SPI_EEPROM_BUF_LEN_MAX);
			atomic_set(&card_info->inventory_cached_flag,
				   INVENTORY_VALID_SIG);
			VATOOLS_DBG(
				pci_info, DUMMY_DIE_ID,
				"read mb spi buf fail, cached flag set 0x%x\n",
				atomic_read(&card_info->inventory_cached_flag));
		} else {
			atomic_set(&card_info->inventory_cached_flag,
				   INVENTORY_VALID_SIG);
			VATOOLS_DBG(
				pci_info, DUMMY_DIE_ID,
				"read mb spi buf suc, cached flag set to 0x%x\n",
				atomic_read(&card_info->inventory_cached_flag));
		}

		for (die = 0; die < pci_info->die_num_in_fn; die++) {
			ret = vatools_get_spi_buf(
				pci_info->dies[die].die_index,
				SPI_BLOCK_PRODUCT_INFO, 0, SPI_BUF_LEN_MAX,
				pci_info->dies[die].inventory);
			if (ret < 0) {
				atomic_set(&pci_info->dies[die]
						    .inventory_cached_flag,
					   0);
				VATOOLS_DBG(
					pci_info, DUMMY_DIE_ID,
					"read die spi buf fail, cached flag don't change 0x%x\n",
					atomic_read(
						&pci_info->dies[die]
							 .inventory_cached_flag));
			} else {
				atomic_set(&pci_info->dies[die]
						    .inventory_cached_flag,
					   INVENTORY_VALID_SIG);
				VATOOLS_DBG(
					pci_info, DUMMY_DIE_ID,
					"read die spi buf suc, cached flag set to 0x%x\n",
					atomic_read(
						&pci_info->dies[die]
							 .inventory_cached_flag));
			}
		}
	}
	mutex_unlock(&node->inventory_cache_mutex);
	up_read(&tools_devs_rw_sem);
}

static void fill_ddr_info(struct vastai_pci_info *priv, void *buf)
{
	int i;
	int banknum = 0;
	vatools_sv_ddr_info_t *sv_ddr_info = NULL;

	sv_ddr_info = (vatools_sv_ddr_info_t *)buf;
	banknum = vastai_get_share_mem_bank_num(priv);

	for (i = 0; i < banknum; i++) {
		vastai_get_share_mem_bank_info(
			priv, i,
			&sv_ddr_info->ddr_entry[i][VATOOLS_SV_SHARE_ENTRY].start,
			&sv_ddr_info->ddr_entry[i][VATOOLS_SV_SHARE_ENTRY].size);
	}
}

long vatools_ioctl_v2_get_device_info(struct file *filp, unsigned int cmd,
				      IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	void __user *argp = (void __user *)arg;
	struct vatools_node *node = vatools_get_node();
	ioctl_arg_t *ioctl_arg_p;
	vatools_v2_device_info_u *dev_info_p = NULL;
#ifdef CONFIG_VASTAI_AI
	struct vastai_cdev *vacc_dev_p = NULL;
	struct vastai_cdev *vacc_dev_temp = NULL;
#endif
#ifdef CONFIG_VASTAI_VIDEO
	struct vastai_render_file *render_file_p = NULL;
	struct vastai_render_file *render_file_temp = NULL;
#endif
	struct vastai_pci_info *pci_info = NULL;
	u32 device_num = 0;
	u32 needsize = 0;
	int die = 0;
	void *buffer = NULL;
	int buffer_size = 0;
	vatools_devices_info_t devices_info;
	u32 real_device_num =
		0; /*The number of cards that actually got the card info*/
	char *card_type = NULL;
	struct vastai_die_info *tree_die_info_p = NULL;
	struct vastai_pkg_info *tree_pkg_info_p = NULL;
	uint8_t oasv_map = 0;
	uint8_t loop = 0;
	struct vastai_card_info *card_info = NULL;

	trace_ioctl_v2_get_device_info_start(NULL, 0, 0, 0, __func__);
	VATOOLS_FUNC_ENTERY;

	V_UNREFERENCE(cmd);
	V_UNREFERENCE(tree_die_info_p);
	V_UNREFERENCE(tree_pkg_info_p);

	//check_need_refresh_cache(node);

	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);
	if (node == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "vatools node is null\n");
		ret = -EINVAL;
		goto out;
	}

	ioctl_arg_p = (ioctl_arg_t *)kvmalloc(sizeof(ioctl_arg_t), GFP_KERNEL);
	if (ioctl_arg_p == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "kvmalloc error. size=%ld\n",
			    sizeof(ioctl_arg_t));
		ret = -ENOMEM;
		goto out;
	}

	ret = copy_from_user_ex(ioctl_arg_p, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	/*Get the number of devices*/
	device_num = vatools_get_vastai_pci_device_number();
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "device_num=%d\n", device_num);
	needsize = sizeof(vatools_devices_info_t) -
		   sizeof(vatools_v2_device_info_u *) +
		   device_num * sizeof(vatools_v2_device_info_u);
	if (ioctl_arg_p->output_buf.buf_size < needsize) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"get devinfo v2 ioctl_arg_p->output_buf.buf_size 0x%x, need 0x%x\n",
			ioctl_arg_p->output_buf.buf_size, needsize);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	memset(&devices_info, 0, sizeof(vatools_devices_info_t));
	ret = copy_from_user_ex(&devices_info,
				(void __user *)ioctl_arg_p->output_buf.buf_addr,
				sizeof(vatools_devices_info_t));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	/*Copy the version number*/
	devices_info.base.info.magic_number = VATOOLS_MAGIC_CODE;
	devices_info.base.info.tools_ver_major = VATOOLS_DRV_VERSION_MAJOR_CODE;
	devices_info.base.info.tools_ver_middle =
		VATOOLS_DRV_VERSION_MIDDLE_CODE;
	devices_info.base.info.tools_ver_minor = VATOOLS_DRV_VERSION_MINOR_CODE;
	devices_info.base.info.device_number = device_num;
	devices_info.base.info.device_info_size =
		sizeof(vatools_v2_device_info_t);
	devices_info.base.info.card_change_count =
		atomic_read(&_vatools_changed_device_count);
	devices_info.base.info.tools_feature = VATOOLS_DRV_FEATURE_CURRENT;
	devices_info.base.info.tools_capability = VATOOLS_CAP_BASE |
						  VATOOLS_CAP_DMA_TRANS |
						  VATOOLS_CAP_CONCURRENT_REBOOT;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"magic_number=0x%x tools_ver_major=%d tools_ver_middle=%d tools_ver_minor=%d device_number=%d device_info_size=%d card_change_count=%d tools_feature=%d tools_capability=0x%llx\n",
		devices_info.base.info.magic_number,
		devices_info.base.info.tools_ver_major,
		devices_info.base.info.tools_ver_middle,
		devices_info.base.info.tools_ver_minor,
		devices_info.base.info.device_number,
		devices_info.base.info.device_info_size,
		devices_info.base.info.card_change_count,
		devices_info.base.info.tools_feature,
		devices_info.base.info.tools_capability);

	ret = copy_to_user_ex((void __user *)ioctl_arg_p->output_buf.buf_addr,
			      &devices_info, sizeof(vatools_devices_info_t));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	//if ((VATOOLS_IOCTL_DEVICE_INFO_REFRESH == ioctl_arg_p->sub_cmd) ||
	//    TOOLS_DEBUG_NO_DEV_INFO_CACHE) {
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "node->dev_info=%p\n", node->dev_info);
	/*Clear the cache and re-read the data*/
	/*mutex_lock(&node->node_common_mutex);*/
	if (node->dev_info) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"sub_cmd=%d debug=%d: remove cache node=0x%p node->dev_info=%p\n",
			ioctl_arg_p->sub_cmd, TOOLS_DEBUG_NO_DEV_INFO_CACHE,
			node, node->dev_info);
		vfree(node->dev_info);
		node->dev_info = NULL;
		node->device_num = 0;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "sub_cmd=%d debug=%d: remove cache done.\n",
			    ioctl_arg_p->sub_cmd,
			    TOOLS_DEBUG_NO_DEV_INFO_CACHE);
	}
	/*mutex unlock(&node >node common mutex);*/
	//}

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "get device info from SoC. node->dev_info=%p\n",
		    node->dev_info);

	if (device_num == 0 || device_num > MAX_DEVICE_NUM_PER_MANAGER) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "get device_num failed. device_num=%d\n",
			    device_num);
		ret = -ENODEV;
		ioctl_arg_p->count = device_num;
		ioctl_arg_p->errcode = ret;
		if (copy_to_user_ex((void __user *)argp, ioctl_arg_p,
				    sizeof(ioctl_arg_t))) {
			ret = -EFAULT;
		}
		goto out_free_ioctl_arg;
	}

	buffer_size = device_num * sizeof(vatools_v2_device_info_u);
	buffer = vmalloc(buffer_size);
	if (buffer == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "vmalloc error. size=%d ret=%ld\n", buffer_size,
			    ret);
		goto out_free_ioctl_arg;
	}

	dev_info_p = (vatools_v2_device_info_u *)buffer;
	memset(buffer, 0, buffer_size);

	/*TODO: Hot-swappable, after the board is plugged and unplugged, the device sequence number changes, and it is no longer continuous from 0*/
	down_read(&tools_devs_rw_sem);
	list_for_each_entry (pci_info, &vastai_tools_devs_list,
			     tools_dev_list) {
		if (pci_info == NULL) {
			VATOOLS_DBG(pci_info, DUMMY_DIE_ID, "priv is NULL\n");
			continue;
		}
		if (vatools_check_pci_state(pci_info, VASTAI_NORMAL_STATE,
					    VASTAI_NO_RUN_STATE,
					    VASTAI_DEBUG_STATE, -1)) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"pci_info->pci_state=0x%x  skip emulate device\n",
				atomic_read(&pci_info->pci_state));
#if 0
			/*TODO: The card status is not a working state, only the status is obtained, no other information is obtained*/
			dev_info_p->info.dev_id = pci_info->dev_id;
			dev_info_p->info.pci_state = pci_info->pci_state;
			/*Cycle Next device*/
			dev_info_p++;
			real_device_num++;
#endif
			continue;
		}

		dev_info_p->info.pci_state = atomic_read(&pci_info->pci_state);
		dev_info_p->info.board_type = vastai_get_board_type(pci_info);
		dev_info_p->info.dev_id = pci_info->dev_id;
		dev_info_p->info.die_num = pci_info->die_num_in_fn;
		VATOOLS_DBG(pci_info, DUMMY_DIE_ID,
			    "dev_id=%d die_num=%d buffer_size=%d\n",
			    dev_info_p->info.dev_id, dev_info_p->info.die_num,
			    buffer_size);

		/*bar size*/
		memcpy(dev_info_p->info.bar_address, vatools_die_check,
		       sizeof(vatools_die_check));

		dev_info_p->info.pciid.vender_id = pci_info->dev->vendor;
		dev_info_p->info.pciid.device_id = pci_info->dev->device;
		dev_info_p->info.pcisubid.sub_vender_id =
			pci_info->dev->subsystem_vendor;
		dev_info_p->info.pcisubid.sub_device_id =
			pci_info->dev->subsystem_device;

		memcpy(dev_info_p->info.pcie_slot, pci_name(pci_info->dev),
		       VASTAI_BUF_SIZE_32);
#if (TOOLS_WIN == 0)
		dev_info_p->info.kchar.majormin.major =
			MAJOR(pci_info->p_char->file_info.dev_num);
		dev_info_p->info.kchar.majormin.minor =
			MINOR_L(MINOR(pci_info->p_char->file_info.dev_num));
		dev_info_p->info.kchar.majormin.minor_h =
			MINOR_H(MINOR(pci_info->p_char->file_info.dev_num));
		memcpy(dev_info_p->info.kchar.name,
		       pci_info->p_char->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		dev_info_p->info.vastai_version.majormin.major =
			MAJOR(pci_info->version_file->file_info.dev_num);
		dev_info_p->info.vastai_version.majormin.minor = MINOR_L(
			MINOR(pci_info->version_file->file_info.dev_num));
		dev_info_p->info.vastai_version.majormin.minor_h = MINOR_H(
			MINOR(pci_info->version_file->file_info.dev_num));
		memcpy(dev_info_p->info.vastai_version.name,
		       pci_info->version_file->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		dev_info_p->info.vastai_ctrl.majormin.major =
			MAJOR(pci_info->ctl_file->file_info.dev_num);
		dev_info_p->info.vastai_ctrl.majormin.minor =
			MINOR_L(MINOR(pci_info->ctl_file->file_info.dev_num));
		dev_info_p->info.vastai_ctrl.majormin.minor_h =
			MINOR_H(MINOR(pci_info->ctl_file->file_info.dev_num));

		memcpy(dev_info_p->info.vastai_ctrl.name,
		       pci_info->ctl_file->file_info.file_name,
		       VASTAI_BUF_SIZE_32);
#endif

		dev_info_p->info.vatools.majormin.minor =
			MINOR_L((u16)node->file_info.dev_num);
		dev_info_p->info.vatools.majormin.minor_h =
			MINOR_H((u16)node->file_info.dev_num);
		dev_info_p->info.vatools.majormin.major = major;
		memcpy(dev_info_p->info.vatools.name, node->file_info.file_name,
		       VASTAI_BUF_SIZE_32);

		dev_info_p->info.cap.ai_cap =
			pci_info->vadev.dev_cap; /*I Video Competency set*/
		dev_info_p->info.cap.video_cap =
			pci_info->vadev.dev_cap; /*I Video Competency set*/

		/*Virtualization*/
		dev_info_p->info.dev_vfpf_flag.is_physfn = pci_info->is_physfn;
		dev_info_p->info.dev_vfpf_flag.is_virtfn = pci_info->is_virtfn;

		dev_info_p->info.iommu_en = (u8)pci_info->iommu_en + 1;
		dev_info_p->info.boot_failed_flag =
			(u8)pci_info->boot_failed_flag + 1;
		dev_info_p->info.probe_done = (u8)pci_info->probe_done + 1;
		dev_info_p->info.is_in_vm = (u8)pci_info->is_in_vm + 1;
		dev_info_p->info.flr_is_en = (u8)pci_info->flr_is_en + 1;

		dev_info_p->info.support_android_sriov = (u8)0;
		dev_info_p->info.support_diag = (u8)2;

		/*Set up the board or drive capability set*/
		/*Support Flash non-inductive upgrade*/
		if (vatools_flash_support_update_background(
			    pci_info, VATOOLS_FLASH_UPDATE_BMCU) == 1) {
			dev_info_p->info.capability0 |= 0x1;
		}
		if (vatools_flash_support_update_background(
			    pci_info, VATOOLS_FLASH_UPDATE_BL0) == 1) {
			dev_info_p->info.capability0 |= 0x2;
		}
		if (vatools_flash_support_update_background(
			    pci_info, VATOOLS_FLASH_UPDATE_PMCU) == 1) {
			dev_info_p->info.capability0 |= 0x4;
		}

		/*TODO:*/
		/*Read the motherboard inventory, and if the read fails, set the cardtype according to the driver configuration.
		 Compatible with all boards such as VA100, VA1, etc*/
		/*get spi config of main board(physical card)*/
		die = 0; /*Get only data for die0. Because for va100, vam, pci_info only die0 is valid*/

		card_info = vastai_get_card_info(pci_info);
		VATOOLS_DBG(pci_info, DUMMY_DIE_ID,
			    "card_type from pci_info %s\n",
			    pci_info->card_type);
		if (strncmp(pci_info->card_type, "va100", 5) == 0 ||
		    strncmp(pci_info->card_type, "VA100", 5) == 0) {
			if (atomic_read(&card_info->inventory_cached_flag) !=
			    INVENTORY_VALID_SIG) {
				VATOOLS_DBG(pci_info, DUMMY_DIE_ID,
					    "mb read from real inventory\n");
				mutex_lock(&node->inventory_cache_mutex);
				ret = vatools_get_spi_buf(
					pci_info->dies[die].die_index,
					SPI_BLOCK_EEPROM, 0, SPI_BUF_LEN_MAX,
					card_info->inventory);
				if (ret < 0) {
					atomic_set(
						&card_info->inventory_cached_flag,
						0);
					memset(card_info->inventory, '\0',
					       SPI_EEPROM_BUF_LEN_MAX);
					VATOOLS_DBG(
						pci_info, DUMMY_DIE_ID,
						"read mb spi buf fail, set cached flag 0x%x, die_index 0x%x, die %d\n",
						atomic_read(
							&card_info
								 ->inventory_cached_flag),
						pci_info->dies[die].die_index,
						die);
				} else {
					memcpy(dev_info_p->info.mb_spi_buf,
					       card_info->inventory,
					       SPI_EEPROM_BUF_LEN_MAX);
					atomic_set(
						&card_info->inventory_cached_flag,
						INVENTORY_VALID_SIG);
					VATOOLS_DBG(
						pci_info, DUMMY_DIE_ID,
						"read mb spi buf suc, cached flag set to 0x%x\n",
						atomic_read(
							&card_info
								 ->inventory_cached_flag));
				}
				mutex_unlock(&node->inventory_cache_mutex);
			} else {
				VATOOLS_DBG(pci_info, DUMMY_DIE_ID,
					    "mb read from inventory cache\n");
				mutex_lock(&node->inventory_cache_mutex);
				memcpy(dev_info_p->info.mb_spi_buf,
				       card_info->inventory,
				       SPI_EEPROM_BUF_LEN_MAX);
				mutex_unlock(&node->inventory_cache_mutex);
			}
		}

		VATOOLS_DUMP_BRIEF(
			"dump mb inventory: ", dev_info_p->info.mb_spi_buf,
			SPI_EEPROM_BUF_LEN_MAX);

		card_type = vatools_get_physical_card_type(pci_info);
		if (card_type) {
			strncpy(dev_info_p->info.card_type, card_type,
				VASTAI_BUF_SIZE_32 - 1);
			dev_info_p->info.card_type[VASTAI_BUF_SIZE_32 - 1] =
				'\0';
		}

		VATOOLS_DBG(pci_info, DUMMY_DIE_ID,
			    "dev_info_p->info.card_type=%s from fw config.\n",
			    dev_info_p->info.card_type);

		for (die = 0; die < dev_info_p->info.die_num; die++) {
			dev_info_p->info.die_info[die].info.die_index.val =
				pci_info->dies[die].die_index;
			VATOOLS_DBG(
				pci_info, die,
				"dies[%d] dev_info_p->info.die_index=0x%x\n",
				die,
				dev_info_p->info.die_info[die]
					.info.die_index.val);

/*Get the die_id_in_card of die from die_info*/
#if 1
			tree_die_info_p = vatool_get_die_info(pci_info, die);
			if (tree_die_info_p) {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.die_id_in_card =
					tree_die_info_p->die_id_in_card;
			} else {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.die_id_in_card = die;
			}

			tree_pkg_info_p = vatool_get_pkg_info(pci_info, die);
			if (tree_pkg_info_p) {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.pkg_id =
					tree_pkg_info_p->pkg_id;
			} else {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.pkg_id = 0;
			}
#else
			if (dev_info_p->info.die_num == 1) {
				tree_die_info_p =
					vatool_get_die_info(pci_info, die);
				if (tree_die_info_p) {
					dev_info_p->info.die_info[die]
						.info.sys_cfg_sv.die_id_in_card =
						tree_die_info_p->die_id_in_card;
				}
			} else {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.die_id_in_card = die;
			}
			if (dev_info_p->info.die_num == 1) {
				tree_pkg_info_p =
					vatool_get_pkg_info(pci_info, die);
				if (tree_pkg_info_p) {
					dev_info_p->info.die_info[die]
						.info.sys_cfg_sv.pkg_id =
						tree_pkg_info_p->pkg_id;
				}
			} else {
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.pkg_id = 0;
			}
#endif

			VATOOLS_DBG(
				pci_info, DUMMY_DIE_ID,
				"dev_info_p->info.die_info[%d].sys_cfg_sv.die_id_in_card= %d of tree_die_info_p=%p pkg_id=%d of tree_pkg_info_p=%p \n",
				die,
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.die_id_in_card,
				tree_die_info_p,
				dev_info_p->info.die_info[die]
					.info.sys_cfg_sv.pkg_id,
				tree_pkg_info_p);

			if (atomic_read(&pci_info->dies[die]
						 .inventory_cached_flag) !=
			    INVENTORY_VALID_SIG) {
				VATOOLS_DBG(
					pci_info, DUMMY_DIE_ID,
					"sub die read from real inventory\n");
				mutex_lock(&node->inventory_cache_mutex);
				ret = vatools_get_spi_buf(
					pci_info->dies[die].die_index,
					SPI_BLOCK_PRODUCT_INFO, 0,
					SPI_BUF_LEN_MAX,
					pci_info->dies[die].inventory);
				if (ret < 0) {
					atomic_set(
						&pci_info->dies[die]
							 .inventory_cached_flag,
						0x0);
					VATOOLS_INFO(
						pci_info, DUMMY_DIE_ID,
						"read die spi buf fail, cached flag don't change 0x%x, die_index 0x%x, die_id %d\n",
						atomic_read(
							&pci_info->dies[die]
								 .inventory_cached_flag),
						pci_info->dies[die].die_index,
						die);
				} else {
					memcpy(dev_info_p->info.die_info[die]
						       .info.spi_buf,
					       pci_info->dies[die].inventory,
					       SPI_BUF_LEN_MAX);
					atomic_set(
						&pci_info->dies[die]
							 .inventory_cached_flag,
						INVENTORY_VALID_SIG);
					VATOOLS_DBG(
						pci_info, DUMMY_DIE_ID,
						"read die spi buf suc, cached flag set to 0x%x\n",
						atomic_read(
							&pci_info->dies[die]
								 .inventory_cached_flag));
				}
				mutex_unlock(&node->inventory_cache_mutex);
			} else {
				VATOOLS_DBG(
					pci_info, DUMMY_DIE_ID,
					"sub die read from inventory cache\n");
				mutex_lock(&node->inventory_cache_mutex);
				memcpy(dev_info_p->info.die_info[die]
					       .info.spi_buf,
				       pci_info->dies[die].inventory,
				       SPI_BUF_LEN_MAX);

				mutex_unlock(&node->inventory_cache_mutex);
			}

			VATOOLS_DUMP_BRIEF(
				"dump die inventory: ",
				dev_info_p->info.die_info[die].info.spi_buf,
				SPI_EEPROM_BUF_LEN_MAX);

			/*get fw version of die*/
			memcpy(&dev_info_p->info.die_info[die].info.fw_ver,
			       &(pci_info->dies[die].fw_ver),
			       sizeof(struct vastai_fw_version));

			/*get pcie_nls, pcie_nlw, cls, clw*/
			dev_info_p->info.die_info[die].info.pcie_nls =
				pci_info->dies[die].pcie_nls[0];
			dev_info_p->info.die_info[die].info.pcie_nlw =
				pci_info->dies[die].pcie_nlw[0];
			dev_info_p->info.die_info[die].info.pcie_cls =
				vastai_get_speed_cap(pci_info);
			dev_info_p->info.die_info[die].info.pcie_clw =
				vastai_get_width_cap(pci_info);

			/*d2d negotiated_link_speed*/
			dev_info_p->info.die_info[die].info.pcie_nls_die2die =
				pci_info->dies[die].pcie_nls[1];
			/*d2d negotiated_link_width*/
			dev_info_p->info.die_info[die].info.pcie_nlw_die2die =
				pci_info->dies[die].pcie_nlw[1];
			/*pkg2pkg negotiated_link_speed*/
			dev_info_p->info.die_info[die].info.pcie_nls_pkg2pkg =
				pci_info->dies[die].pcie_nls[2];
			/*pkg2pkg negotiated_link_width*/
			dev_info_p->info.die_info[die].info.pcie_nlw_pkg2pkg =
				pci_info->dies[die].pcie_nlw[2];

			/*odsp as vdsp*/
			oasv_map = 0;
			for (loop = 0; loop < 8; loop++) {
				if (check_if_is_odsp_as_vdsp(
					    pci_info,
					    pci_info->dies[die].die_index,
					    loop) == ODSP_AS_VDSP)
					oasv_map = oasv_map | (1 << loop);
			}
			dev_info_p->info.die_info[die].info.odsp_as_vdsp =
				oasv_map;

#if 0
			/*TODO: enable this when level0 ready*/
			/*Save the inventory information for each die*/
			memcpy((void *)dev_info_p->info.die_info[die]
				       .info.inventory1.common_inventory
				       .card_type,
			       (void *)va_get_model_name(pci_info),
			       VATOOLS_MAX_INVENTORY_ITEM_LEN);
			memcpy((void *)dev_info_p->info.die_info[die]
				       .info.inventory1.common_inventory
				       .product_sn,
			       (void *)va_get_product_sn(pci_info),
			       VATOOLS_MAX_INVENTORY_ITEM_LEN);
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"inventory: die_index=0x%08x product_sn=%s card_type=%s\n",
				dev_info_p->info.die_info[die]
					.info.die_index.val,
				dev_info_p->info.die_info[die]
					.info.inventory1.common_inventory
					.card_type,
				dev_info_p->info.die_info[die]
					.info.inventory1.common_inventory
					.product_sn);
#endif

			/*vastai video*/
			list_for_each_entry_safe (render_file_p,
						  render_file_temp,
						  &pci_info->render_head,
						  node) {
				if (render_file_p->die_index ==
				    pci_info->dies[die].die_index) {
#if (TOOLS_WIN == 0)
					dev_info_p->info.die_info[die]
						.info.vastai_video.majormin
						.major =
						MAJOR(render_file_p->file_info
							      .dev_num);
					dev_info_p->info.die_info[die]
						.info.vastai_video.majormin
						.minor = MINOR_L(
						MINOR(render_file_p->file_info
							      .dev_num));
					dev_info_p->info.die_info[die]
						.info.vastai_video.majormin
						.minor_h = MINOR_H(
						MINOR(render_file_p->file_info
							      .dev_num));
#endif
					snprintf(
						dev_info_p->info.die_info[die]
							.info.vastai_video.name,
						VASTAI_BUF_SIZE_32, "%s",
						render_file_p->file_info
							.file_name);
					break;
				}
			}

#ifdef CONFIG_DRM_DRIVER
/*renderD*/
#if 0
			list_for_each_entry_safe (render_file_p,
						  render_file_temp,
						  &pci_info->render_head,
						  node) {
				if (render_file_p->die_index ==
				    pci_info->dies[die].die_index) {
					dev_info_p->info.die_info[die]
						.info.render.majormin.major =
						MAJOR(render_file_p->file_info
							      .dev_num);
					dev_info_p->info.die_info[die]
						.info.render.majormin.minor =
						MINOR_L(MINOR(
							render_file_p->file_info
								.dev_num));
					dev_info_p->info.die_info[die]
						.info.render.majormin.minor_h =
						MINOR_H(MINOR(
							render_file_p->file_info
								.dev_num));
					snprintf(dev_info_p->info.die_info[die]
							 .info.render.name,
						 VASTAI_BUF_SIZE_32, "%s",
						 render_file_p->file_info
							 .file_name);
					break;
				}
			}
#else
			/*sv100 shows the renderD node, using string concatenation*/
			{
				dev_info_p->info.die_info[die]
					.info.render.majormin.major = 226;
				dev_info_p->info.die_info[die]
					.info.render.majormin.minor =
					MINOR_L(pci_info->dies[die].render_id);
				dev_info_p->info.die_info[die]
					.info.render.majormin.minor_h =
					MINOR_H(pci_info->dies[die].render_id);

				snprintf(dev_info_p->info.die_info[die]
						 .info.render.name,
					 VASTAI_BUF_SIZE_32, "%s%d",
					 VA_NODE_NAME_RENDER,
					 pci_info->dies[die].render_id);
			}
#endif
#endif
			/*vacc*/
			list_for_each_entry_safe (vacc_dev_p, vacc_dev_temp,
						  &pci_info->vacc_dev_head,
						  vacc_dev_node) {
				if (vacc_dev_p->die_index ==
				    pci_info->dies[die].die_index) {
#if (TOOLS_WIN == 0)
					dev_info_p->info.die_info[die]
						.info.vacc.majormin.major =
						MAJOR(vacc_dev_p->file_info
							      .dev_num);
					dev_info_p->info.die_info[die]
						.info.vacc.majormin
						.minor = MINOR_L(MINOR(
						vacc_dev_p->file_info.dev_num));
					dev_info_p->info.die_info[die]
						.info.vacc.majormin
						.minor_h = MINOR_H(MINOR(
						vacc_dev_p->file_info.dev_num));
#endif
					snprintf(
						dev_info_p->info.die_info[die]
							.info.vacc.name,
						VASTAI_BUF_SIZE_32, "%s",
						vacc_dev_p->file_info.file_name);
					break;
				}
			}
		} /*end of die*/

		/*Get virtualized data*/
		memset(&dev_info_p->info.sriov_number, 0,
		       sizeof(struct sriov_number_s));
		dev_info_p->info.sriov_number.dev_id = dev_info_p->info.dev_id;
		dev_info_p->info.sriov_number.sriov_num =
			vastai_pci_get_sriov_numvfs(
				dev_info_p->info.sriov_number.dev_id);

		/* fill ddr info  */
		fill_ddr_info(pci_info, (void *)(&dev_info_p->info.ddr_info));

		/*Cycle through the next device*/
		dev_info_p++;
		real_device_num++;
	}
	up_read(&tools_devs_rw_sem);
	node->dev_info = (vatools_v2_device_info_u *)buffer;
	node->device_num = real_device_num;

	ioctl_arg_p->errcode = 0;
	ioctl_arg_p->count = real_device_num;
	ioctl_arg_p->output_buf.buf_size = buffer_size;

	if (copy_to_user_ex((void __user *)argp, ioctl_arg_p,
			    sizeof(ioctl_arg_t))) {
		ret = -EFAULT;
		VATOOLS_ERR(
			NULL, DUMMY_DIE_ID,
			"copy_to_user_ex failed: ret=%ld, sizeof(ioctl_arg_t)=%ld\n",
			ret, sizeof(ioctl_arg_t));
		goto out_free_buffer;
	}

	if (copy_to_user_ex((void __user *)devices_info.device_info_p, buffer,
			    buffer_size)) {
		ret = -EFAULT;
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "copy_to_user_ex failed: ret=%ld, buffer_size=%d\n",
			    ret, buffer_size);
		goto out_free_buffer;
	}

	ret = 0;

out_free_buffer:

out_free_ioctl_arg:
	kvfree(ioctl_arg_p);

out:
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "real_device_num=%d out: ret=%ld\n",
		    real_device_num, ret);
	trace_ioctl_v2_get_device_info_end(NULL, 0, 0, 0, __func__);
	VATOOLS_FUNC_EXIT;
	return ret;
}

long vatools_ioctl_get_base_info(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	long ret = -EINVAL;
	void __user *argp = (void __user *)arg;
	ioctl_arg_t *ioctl_arg_p;
	u32 device_num = 0;
	vatools_v2_base_info_u *base_info_p = NULL;

	VATOOLS_FUNC_ENTERY;
	V_UNREFERENCE(cmd);

	domain_mutex_lock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);

	ioctl_arg_p = (ioctl_arg_t *)vmalloc(sizeof(ioctl_arg_t));
	if (ioctl_arg_p == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "kvmalloc error. size=%ld\n",
			    sizeof(ioctl_arg_t));
		ret = -ENOMEM;
		goto out;
	}

	ret = copy_from_user_ex(ioctl_arg_p, (void __user *)argp,
				sizeof(ioctl_arg_t));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_ioctl_arg;
	}

	base_info_p = (vatools_v2_base_info_u *)vmalloc(
		sizeof(vatools_v2_base_info_u));
	if (base_info_p == NULL) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "kvmalloc error. size=%ld\n",
			    sizeof(vatools_v2_base_info_u));
		ret = -ENOMEM;
		goto out_free_base_info;
	}

	memset(base_info_p, 0, sizeof(vatools_v2_base_info_u));

	/*Get the number of devices*/
	device_num = vatools_get_vastai_pci_device_number();

	/*Copy the version number*/
	base_info_p->info.magic_number = VATOOLS_MAGIC_CODE;
	base_info_p->info.tools_ver_major = VATOOLS_DRV_VERSION_MAJOR_CODE;
	base_info_p->info.tools_ver_middle = VATOOLS_DRV_VERSION_MIDDLE_CODE;
	base_info_p->info.tools_ver_minor = VATOOLS_DRV_VERSION_MINOR_CODE;
	base_info_p->info.device_number = device_num;
	base_info_p->info.device_info_size = sizeof(vatools_v2_device_info_t);
	base_info_p->info.card_change_count =
		atomic_read(&_vatools_changed_device_count);
	base_info_p->info.tools_feature = VATOOLS_DRV_FEATURE_CURRENT;
	base_info_p->info.tools_capability = VATOOLS_CAP_BASE |
					     VATOOLS_CAP_DMA_TRANS |
					     VATOOLS_CAP_CONCURRENT_REBOOT;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"magic_number=0x%x tools_ver_major=%d tools_ver_middle=%d tools_ver_minor=%d device_number=%d device_info_size=%d card_change_count=%d tools_feature=%d tools_capability=0x%llx\n ",
		base_info_p->info.magic_number,
		base_info_p->info.tools_ver_major,
		base_info_p->info.tools_ver_middle,
		base_info_p->info.tools_ver_minor,
		base_info_p->info.device_number,
		base_info_p->info.device_info_size,
		base_info_p->info.card_change_count,
		base_info_p->info.tools_feature,
		base_info_p->info.tools_capability);

	ret = copy_to_user_ex((void __user *)ioctl_arg_p->output_buf.buf_addr,
			      base_info_p, sizeof(vatools_v2_base_info_u));
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_free_base_info;
	}

	ioctl_arg_p->errcode = 0;
	ioctl_arg_p->count = device_num;
	ioctl_arg_p->output_buf.buf_size = sizeof(vatools_v2_base_info_u);

	if (copy_to_user_ex((void __user *)argp, ioctl_arg_p,
			    sizeof(ioctl_arg_t))) {
		ret = -EFAULT;
		goto out_free_base_info;
	}

	ret = 0;
out_free_base_info:
	vfree(base_info_p);

out_free_ioctl_arg:
	vfree(ioctl_arg_p);

out:
	domain_mutex_unlock(NULL, 0, VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

#endif

/**
 * 0: 64bit
 * 1: 32bit
 */
int is_32_bit_thread(void)
{
#if (TOOLS_WIN == 1)
	return 0;
#else
	int is_32_bit = 0;
#if (defined(__aarch64__) || defined(__arm__))
	is_32_bit = test_thread_flag(TIF_32BIT);
#else
	is_32_bit = test_thread_flag(TIF_ADDR32);
#endif

	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "thread is %d bit\n",
		    is_32_bit ? 32 : 64);
	return is_32_bit;
#endif
}

unsigned long copy_to_user_ex(void __user *to, const void *from,
			      unsigned long n)
{
	unsigned long ret = 0;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "copy_to_user_ex: to=%p from=%p len=%ld\n", to, from, n);
#ifdef CONFIG_COMPAT
	if (is_32_bit_thread()) {
		ret = copy_to_user(
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)to) & 0xffffffff)),
			from, n);
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_to_user_ex: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				to, from, n, ret);
		}
		return ret;
	} else
#endif
	{
		ret = copy_to_user(to, from, n);
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_to_user_ex: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				to, from, n, ret);
		}
		return ret;
	}
	return 0;
}

unsigned long copy_from_user_ex(void *to, const void __user *from,
				unsigned long n)
{
	unsigned long ret = 0;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "copy_from_user_ex: to=%p from=%p len=%ld\n", to, from, n);
#ifdef CONFIG_COMPAT
	if (is_32_bit_thread()) {
		ret = copy_from_user(
			to,
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)from) & 0xffffffff)),
			n);
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_from_user_ex: fail: 32bit: to=%p from=%p len=%ld ret=%ld\n",
				to, from, n, ret);
		}
		return ret;
	} else
#endif
	{
		ret = copy_from_user(to, from, n);
		if (ret) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"copy_from_user_ex: fail: 64bit: to=%p from=%p len=%ld ret=%ld\n",
				to, from, n, ret);
		}
		return ret;
	}
	return 0;
}

char *vaccrt_version_number2string(uint32_t num, char *str)
{
	uint8_t val1 = (uint8_t)(num % 256);
	uint8_t val2 = (uint8_t)((num >> 8) % 256);
	uint8_t val3 = (uint8_t)((num >> 16) % 256);

	if (str == NULL) {
		return NULL;
	}
	memset(str, 0, strlen(str));
	sprintf(str, "%hhu.%hhu.%hhu", val3, val2, val1);
	return str;
}
