﻿#include "vatools.h"
#include "vatools_log.h"

LIST_HEAD(shard_addr_check_list);
struct mutex sharedmem_weight_mutex;
/*
 * shared memory
 */

static int add_shard_addr_check_list(uint64_t n_shard_addr)
{
	struct vatools_shared_addr_entry *shared_entry = NULL;
	struct vatools_shared_addr_entry *shared_loop = NULL;
	struct vatools_shared_addr_entry *tmp = NULL;

	shared_entry =
		kzalloc(sizeof(struct vatools_shared_addr_entry), GFP_KERNEL);
	if (!shared_entry) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "[addr_check_list] %s kzalloc error\n", __func__);
		return -ENOMEM;
	}
	shared_entry->pid = task_tgid_nr(current);
	shared_entry->handle = n_shard_addr;

	list_for_each_entry_safe (shared_loop, tmp, &shard_addr_check_list,
				  node) {
		//if (shared_loop->pid == task_tgid_nr(current) && shared_loop->handle == n_shard_addr) {
		//	VATOOLS_INFO(
		//		NULL, DUMMY_DIE_ID,
		//		"[addr_check_list] %s already create devicemem, addr 0x%llx\n",
		//		task_tgid_nr(current), shared_loop->handle);
		//}
		if (shared_loop->handle == n_shard_addr) {
			VATOOLS_ERR(
				NULL, DUMMY_DIE_ID,
				"[addr_check_list] %s already create devicemem, current pid %d, reserved pid %d, addr 0x%llx\n",
				__func__, task_tgid_nr(current),
				shared_loop->pid, shared_loop->handle);
		}
	}

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "[addr_check_list] %s added reserved pid %d, addr 0x%llx\n",
		    __func__, shared_loop->pid, shared_loop->handle);
	list_add(&shared_entry->node, &shard_addr_check_list);
	return 0;
}

static int check_if_valid_handle(uint64_t n_shard_addr)
{
	struct vatools_shared_addr_entry *shared_loop = NULL;
	struct vatools_shared_addr_entry *tmp = NULL;

	list_for_each_entry_safe (shared_loop, tmp, &shard_addr_check_list,
				  node) {
		//if (shared_loop->pid == task_tgid_nr(current) && shared_loop->handle == n_shard_addr) {
		//	VATOOLS_DBG(
		//		NULL, DUMMY_DIE_ID,
		//		"[check_if_valid_handle] valid: pid: %d, addr: 0x%llx\n",
		//		shared_loop->pid, shared_loop->handle);
		//	return 0;
		//}
		if (shared_loop->handle == n_shard_addr) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"[addr_check_list] %s valid, current pid %d, reserved pid: %d, addr: 0x%llx\n",
				__func__, task_tgid_nr(current),
				shared_loop->pid, shared_loop->handle);
			return 0;
		}
	}

	VATOOLS_ERR(
		NULL, DUMMY_DIE_ID,
		"[addr_check_list] %s invalid current pid: %d, reserved pid: %d, addr: 0x%llx, don't have such shared_addr\n",
		__func__, task_tgid_nr(current), shared_loop->pid,
		n_shard_addr);
	return -E_INVALID_SHAREMEM_HANDLE;
}

static void delete_from_addr_check_list(uint64_t n_shard_addr,
					enum entry_delete_path path)
{
	struct vatools_shared_addr_entry *shared_loop = NULL;
	struct vatools_shared_addr_entry *tmp = NULL;
	int count = 0;
	struct list_head *pos;
	int find = 0;

	list_for_each_entry_safe (shared_loop, tmp, &shard_addr_check_list,
				  node) {
		//if (shared_loop->pid == task_tgid_nr(current) && shared_loop->handle == n_shard_addr) {
		if (shared_loop->handle == n_shard_addr) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"[addr_check_list] %s, current pid %d, reserved pid: %d addr: 0x%llx delete device mem,\n",
				__func__, task_tgid_nr(current),
				shared_loop->pid, shared_loop->handle);
			list_del(&shared_loop->node);
			kfree(shared_loop);
			find = 1;
		}
	}

	if (find == 0)
		VATOOLS_ERR(NULL, DUMMY_DIE_ID,
			    "[addr_check_list] %s, path %s, %s\n", __func__,
			    path ? ("release") : ("delete mem"),
			    find ? ("finded entry") : ("no such entry"));

	list_for_each (pos, &shard_addr_check_list) {
		count++;
	}

	if (count == 0)
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "[addr_check_list] %s sum: %d, path %s, %s\n",
			    __func__, count,
			    path ? ("release") : ("delete mem"),
			    find ? ("finded entry") : ("no such entry"));
}

/*Create memory and mount it to the reader*/
static long sharedmem_create_buf(struct vatools_reader *reader,
				 T_MEMORY_ENTRY *p_memory, int is_debug)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;

	VATOOLS_FUNC_ENTERY;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);

	if (p_memory->tdata.n_len < sizeof(union vatools_filter)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unsupported tdata.n_len\n");
		goto ERR_MEM_INFO;
	}

	p_mem_info = (T_MEM_INFO *)kvmalloc(sizeof(T_MEM_INFO), GFP_KERNEL);
	if (!p_mem_info) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, " kvmalloc error. size=%ld\n",
			    sizeof(T_MEM_INFO));
		goto ERR_MEM_INFO;
	}

	p_mem_info->p_buf =
		kvmalloc((p_memory->tdata.n_len + sizeof(u64)), GFP_KERNEL);

	if (!p_mem_info->p_buf) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, " kvmalloc error. size=%ld\n",
			    p_memory->tdata.n_len + sizeof(u64));
		goto ERR_MEM_INFO_BUF;
	}
	/*Save data, find data lupa 2021-12-15*/
	/*Data that is called back by the user at the time of creation*/
	p_mem_info->user_data = p_memory->n_user_addr;
	p_mem_info->callback = p_memory->callback;
	memcpy(&p_mem_info->tchannel, &p_memory->tchannel,
	       sizeof(p_memory->tchannel));
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"sharedmem_create_buf p_mem_info->tchannel.id = %d,p_mem_info->tchannel.type = "
		"%d,p_mem_info->tchannel.writetype = %d\n",
		p_mem_info->tchannel.id, p_mem_info->tchannel.type,
		p_mem_info->tchannel.writetype);

	p_mem_info->version = p_memory->version;
	p_mem_info->flag_encode_or_decode = ALLOC_VIDEO_MAX;
	p_mem_info->flag_specify_die = p_memory->flag_specify_die;
	p_mem_info->flag_allocate_policy = p_memory->flag_allocate_policy;
	p_mem_info->flag_rsvd = p_memory->flag_rsvd;
	p_mem_info->die_seq = VATOOLS_UINT32_MAX;
	p_mem_info->die_weight = 0;

	/* Save data in English data lookup*/
	p_mem_info->n_effic_len = p_memory->tdata.n_len;
	INIT_LIST_HEAD(&p_mem_info->t_sharedmem_node);
	/*Node used for video to read data lupa add 2021-12-15 add begin*/
	p_mem_info->tvideo_debugger.debugtype = 0;
	p_mem_info->tvideo_debugger.debuginfo = NULL;
	p_mem_info->tvideo_debugger.needsendmsg = 0;
	p_mem_info->tvideo_debugger.startflag = 0;
	p_mem_info->tvideo_debugger.data_cnt = 0;
	p_mem_info->tvideo_debugger.is_debugbuf = is_debug;
	p_mem_info->tvideo_debugger.pmeminfo = p_mem_info;
	mutex_init(&p_mem_info->tvideo_debugger.data_info_mutex);
	INIT_LIST_HEAD(&p_mem_info->tvideo_debugger.t_node_head);
	/*Node used for video to read data lupa add 2021-12-15 add end*/
	mutex_init(&p_mem_info->mem_info_mutex);

	reader->filter.filter_info.element_len = p_memory->tdata.n_len;
	/* corresponding to the parent node*/
	p_mem_info->reader = reader;
	if (is_debug) {
		p_mem_info->tvideo_debugger.debugtype = p_memory->tdata.n_type;
	}
	mutex_lock(&reader->sharedmem_mutex);
	list_add_tail(&p_mem_info->t_sharedmem_node,
		      &reader->t_sharedmem_mem_info_head);
	mutex_unlock(&reader->sharedmem_mutex);

	p_memory->n_shard_addr = (u64)p_mem_info;
	add_shard_addr_check_list(p_memory->n_shard_addr);
	p_buf_header = (T_SHAREDMEM_BUF_HEADER *)p_mem_info->p_buf;
	p_buf_header->n_addr = p_memory->n_shard_addr;
	/*VATOOLS_DBG( " end." );*/
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "end . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		    p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		    p_memory->n_shard_addr, p_memory->tdata.n_type);
	VATOOLS_FUNC_EXIT;
	return 0;

ERR_MEM_INFO_BUF:
	p_mem_info->p_buf = NULL;
	kvfree(p_mem_info);
ERR_MEM_INFO:
	p_mem_info = NULL;

	VATOOLS_FUNC_EXIT;

	return -EFAULT;
}
/*Obtain the corresponding file handle pointer lupa 2015-12-15 add according to the channel*/
static T_MEM_INFO *
sharedmem_get_memptr_by_channel(struct vatools_reader *reader,
				T_MEMORY_ENTRY *p_memory)
{
	/* Memory information*/
	T_MEM_INFO *p_node1 = NULL, *p_tmp1 = NULL;
	T_MEM_INFO *p_mem_info = NULL;
	/*struct list_head* ptr        = NULL;*/
	/*File node information*/
	struct vatools_node *p_current = NULL, *p_next = NULL;
	struct vatools_reader *p_current_reader = NULL, *p_next_reader = NULL;
	if (NULL == p_memory) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return NULL;
	}
	if (VATOOLS_MEM_CMD_CHANNEL != p_memory->cmd_type) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"the cmd type is error: no equal VATOOLS_MEM_CMD_CHANNEL\n");
		return NULL;
	}
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"0.p_memory->tchannel.id = %d p_memory->tchannel.type = %d p_memory->tchannel.writetype =%d\n",
		p_memory->tchannel.id, p_memory->tchannel.type,
		p_memory->tchannel.writetype);
	if (NULL == reader) {
		/* Iterate through all file nodes. There is only one at the moment*/
		list_for_each_entry_safe (p_current, p_next,
					  vatools_get_vastai_head(),
					  list_nodes) {
			/*mutex_lock( &p_current->node_mutex );*/
			/*
			list_for_each( ptr, &p_current->list_node_readers )
			{
				if ( NULL == ptr || ptr->next == NULL || NULL == ptr->prev )
				{
					VATOOLS_DBG( "sharedmem_get_memptr_by_channel " );
					dump_stack();
					return NULL;
				}
			}
			*/
/*Get all the file open handles*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			mutex_lock(&p_current->node_reader_mutex);
#endif
			list_for_each_entry_safe (p_current_reader,
						  p_next_reader,
						  &p_current->list_node_readers,
						  list_readers) {
				/* Only file handles used by shared memory are compared*/
				if (p_current_reader->trans_category
					    .app_category ==
				    VATOOLS_APP_SHAREDMEM) {
					/*Find the corresponding channel information -- currently only the sorting of data regions is supported*/
					if (p_current_reader
						    ->n_sharedmem_init_done !=
					    VATOOLS_INIT_DONE) {
						VATOOLS_DBG(
							NULL, DUMMY_DIE_ID,
							"2.sharedmem_get_other_reader.p_current_reader->n_sharedmem_init_done != "
							"VATOOLS_INIT_DONE\n");
						continue;
					}
					mutex_lock(&p_current_reader
							    ->sharedmem_mutex);
					list_for_each_entry_safe (
						p_node1, p_tmp1,
						&p_current_reader
							 ->t_sharedmem_mem_info_head,
						t_sharedmem_node) {
						VATOOLS_DBG(
							NULL, DUMMY_DIE_ID,
							"1.p_node->tchannel.id=%d p_node->tchannel.type=%d p_node->tchannel.writetype=%d\n",
							p_node1->tchannel.id,
							p_node1->tchannel.type,
							p_node1->tchannel
								.writetype);
						if (p_node1->tchannel.id ==
							    p_memory->tchannel
								    .id &&
						    p_node1->tchannel.type ==
							    p_memory->tchannel
								    .type &&
						    p_node1->tchannel.writetype ==
							    p_memory->tchannel
								    .writetype) {
							p_mem_info = p_node1;
							break;
						}
					}
					mutex_unlock(
						&p_current_reader
							 ->sharedmem_mutex);
				}
				/* Find the exit loop*/
				if (NULL != p_mem_info) {
					break;
				}
			}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
			mutex_unlock(&p_current->node_reader_mutex);
#endif
			/*mutex_unlock( &p_current->node_mutex );*/
			/* Find the exit loop*/
			if (NULL != p_mem_info) {
				break;
			}
		}
	} else {
		if (reader->trans_category.app_category ==
		    VATOOLS_APP_SHAREDMEM) {
			/*if( p_memory->tchannel.writetype == VATOOLS_SHAREDMEM_WRITE_DATA*/
			/*   || p_memory->tchannel.writetype == VATOOLS_SHAREDMEM_WRITE_DEBUG )*/
			/*{*/
			if (reader->n_sharedmem_init_done !=
			    VATOOLS_INIT_DONE) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"2.sharedmem_get_other_reader.p_current_reader->n_sharedmem_init_done != "
					"VATOOLS_INIT_DONE\n");
				goto GET_SHARED_END;
			}
			mutex_lock(&reader->sharedmem_mutex);
			list_for_each_entry_safe (
				p_node1, p_tmp1,
				&reader->t_sharedmem_mem_info_head,
				t_sharedmem_node) {
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"2.p_node->tchannel.id=%d p_node->tchannel.type=%d p_node->tchannel.writetype=%d\n",
					p_node1->tchannel.id,
					p_node1->tchannel.type,
					p_node1->tchannel.writetype);
				if (p_node1->tchannel.id ==
					    p_memory->tchannel.id &&
				    p_node1->tchannel.type ==
					    p_memory->tchannel.type &&
				    p_node1->tchannel.writetype ==
					    p_memory->tchannel.writetype) {
					p_mem_info = p_node1;
					break;
				}
			}
			mutex_unlock(&reader->sharedmem_mutex);
			/*}*/
		}
	}
GET_SHARED_END:
	if (NULL == p_mem_info) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"no find the channel ptr, id=%d ,type=%d writetype=%d\n",
			p_memory->tchannel.id, p_memory->tchannel.type,
			p_memory->tchannel.writetype);
	}
	VATOOLS_FUNC_EXIT;
	return p_mem_info;
}
/*Get the corresponding file handle pointer lupa 2015-12-15 add*/
static T_MEM_INFO *sharedmem_get_memptr(struct vatools_reader *reader,
					T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;
	if (NULL == p_memory) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return NULL;
	}
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "cmd_type=%d\n", p_memory->cmd_type);
	switch (p_memory->cmd_type) {
	case VATOOLS_MEM_CMD_HANDLE:
		p_mem_info = (T_MEM_INFO *)p_memory->n_shard_addr;
		if (check_if_valid_handle(p_memory->n_shard_addr) ==
		    (-E_INVALID_SHAREMEM_HANDLE)) {
			VATOOLS_INFO(
				NULL, DUMMY_DIE_ID,
				"[addr_check_list] %s not valid hanle ,set p_mem_info NULL\n",
				__func__);
			p_mem_info = NULL;
		}
		break;
	case VATOOLS_MEM_CMD_CHANNEL:
		p_mem_info = sharedmem_get_memptr_by_channel(reader, p_memory);
		break;
	default:
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    " no find the command ,the command type=%d .\n",
			    p_memory->cmd_type);
		p_mem_info = NULL;
		break;
	}
	if (p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info=%p\n", p_mem_info);
		mutex_lock(&p_mem_info->mem_info_mutex);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info  %p=lock\n",
			    p_mem_info);
		p_buf_header = (T_SHAREDMEM_BUF_HEADER *)p_mem_info->p_buf;
		/*Simple check. Ensure data consistency*/
		if (p_buf_header->n_addr != (u64)p_mem_info) {
			/*BUGS :8816 lupa mod 2022-05-10*/
			/*p_mem_info = ZERO;*/
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "addr is not mash ptr\n");
			mutex_unlock(&p_mem_info->mem_info_mutex);
			VATOOLS_FUNC_EXIT;
			return NULL;
		}

		mutex_unlock(&p_mem_info->mem_info_mutex);
	}
	VATOOLS_FUNC_EXIT;
	return p_mem_info;
}

static struct vatools_reader *
sharedmem_get_other_reader(struct vatools_reader *reader)
{
	struct vatools_node *p_current = NULL, *p_next = NULL;
	struct vatools_reader *p_current_reader = NULL, *p_next_reader = NULL;
	struct vatools_reader *p_reader = NULL;
	/*struct list_head*      ptr      = NULL;*/
	if (NULL == reader) {
		/*pr_err( "error  NULL == reader\n" );*/
		return NULL;
	}
	VATOOLS_FUNC_ENTERY;

	list_for_each_entry_safe (p_current, p_next, vatools_get_vastai_head(),
				  list_nodes) {
		/*mutex_lock( &p_current->node_mutex );*/
		/*
		list_for_each( ptr, &p_current->list_node_readers )
		{
		pr_info( "sharedmem_get_other_reader ptr=%p\n", ptr );
		if ( NULL == ptr || ptr->next == NULL || NULL == ptr->prev )
		{
		VATOOLS_DBG( "sharedmem_get_memptr_by_channel " );
		dump_stack();
		return NULL;
		}
		}
		*/
		list_for_each_entry_safe (p_current_reader, p_next_reader,
					  &p_current->list_node_readers,
					  list_readers) {
			if (p_current_reader->trans_category.app_category ==
			    VATOOLS_APP_SHAREDMEM) {
				if (p_current_reader->n_sharedmem_init_done !=
				    VATOOLS_INIT_DONE) {
					VATOOLS_DBG(
						NULL, DUMMY_DIE_ID,
						"sharedmem_get_other_reader.p_current_reader->n_sharedmem_init_done != VATOOLS_INIT_DONE\n");
					continue;
				}
				/*In shared memory die_index is used to represent file handle types of the same class, i.e. one business node corresponds to one waiting node*/
				/*pr_info( "p_current_reader=%p\n", p_current_reader );*/
				/*pr_info( "reader=%p\n", reader );*/
				/*pr_info( " die_index=%d\n", p_current_reader->trans_category.device.die_index );*/
				/*pr_info( " dev_id=%d\n", p_current_reader->trans_category.device.dev_id );*/
				/*pr_info( " die_id=%d\n", p_current_reader->trans_category.device.die_id );*/
				if ((p_current_reader != reader) &&
				    (p_current_reader->trans_category.device
					     .dev_id ==
				     reader->trans_category.device.dev_id) &&
				    (p_current_reader->trans_category.device
					     .die_id ==
				     reader->trans_category.device.die_id) &&
				    (p_current_reader->trans_category.device
					     .die_index ==
				     reader->trans_category.device.die_index)) {
					p_reader = p_current_reader;
					VATOOLS_DBG(
						NULL, DUMMY_DIE_ID,
						"p_reader=%p,dev_id=%d,die_id=%d,die_index=%d\n",
						p_reader,
						reader->trans_category.device
							.dev_id,
						reader->trans_category.device
							.die_id,
						reader->trans_category.device
							.die_index);
					break;
				}
			}
		}
		/*mutex_unlock( &p_current->node_mutex );*/
	}
	if (!p_reader) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "no find the filetype, filetype=%d\n",
			    reader->trans_category.device.die_index);
	}

	VATOOLS_FUNC_EXIT;
	return p_reader;
}
static int sharemen_set_comp_complete(struct vatools_reader *reader)
{
	if (reader) {
		if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"sharemen_set_comp_complete reader->n_sharedmem_init_done not int\n");
			return 0;
		}
		mutex_lock(&reader->sharedmem_mutex);
		complete(&reader->debug_comp);
		mutex_unlock(&reader->sharedmem_mutex);
	}
	return 0;
}
static int sharedmen_free_video_debugbuf(t_video_debug_head *video_debug)
{
	struct vatools_reader *wait_reader = NULL;
	t_video_debug_info *p_current = NULL, *p_tmp = NULL;
	T_MEM_INFO *p_mem_info = NULL;
	T_MEMORY_ENTRY t_memory;
	if (NULL == video_debug) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "mem_info is null .\n");
		return -EFAULT;
	}
	VATOOLS_FUNC_ENTERY;

	/*For debugger-related resources, resources need to be released*/
	if (1 == video_debug->is_debugbuf) {
		/* Notifies the release of service resources*/
		memset(&t_memory, 0x00, sizeof(t_memory));
		t_memory.cmd_type = VATOOLS_MEM_CMD_CHANNEL;
		memcpy(&t_memory.tchannel, &video_debug->pmeminfo->tchannel,
		       sizeof(t_memory.tchannel));
		/*Because the node mounts all the service nodes on the service node, you want to find the service node*/
		t_memory.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;
		/*Get the data corresponding to the channel and find all nodes*/
		p_mem_info = sharedmem_get_memptr_by_channel(NULL, &t_memory);
		if (p_mem_info) {
			if (1 == p_mem_info->tvideo_debugger.startflag) {
/*You need to find the corresponding wait handle for processing*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
				mutex_lock(&p_mem_info->reader->node
						    ->node_reader_mutex);
#endif
				wait_reader = sharedmem_get_other_reader(
					p_mem_info->reader);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
				mutex_lock(&p_mem_info->reader->node
						    ->node_reader_mutex);
#endif
				if (wait_reader) {
					/*Set the corresponding debugger data*/
					p_mem_info->tvideo_debugger.debugtype =
						video_debug->debugtype;
					p_mem_info->tvideo_debugger.needsendmsg =
						1;
					p_mem_info->tvideo_debugger.startflag =
						0;
					/* Set the wait timeout*/
					sharemen_set_comp_complete(wait_reader);
				}
			}
			if (NULL != p_mem_info->tvideo_debugger.debuginfo) {
				kvfree(p_mem_info->tvideo_debugger.debuginfo);
				p_mem_info->tvideo_debugger.debuginfo = NULL;
			}
		}
	}
	list_for_each_entry_safe (p_current, p_tmp, &video_debug->t_node_head,
				  t_video_node) {
		/* Retake it from the queue first*/
		list_del(&p_current->t_video_node);
		/* Free up space again*/
		kvfree(p_current->p_buf);
		kvfree(p_current);
	}
	video_debug->data_cnt = 0;
	if (0 != video_debug->debuginfo) {
		kvfree(video_debug->debuginfo);
		video_debug->debuginfo = 0;
	}
	VATOOLS_FUNC_EXIT;
	return 0;
}
static long sharedmem_delete_buf(struct vatools_reader *reader,
				 T_MEMORY_ENTRY *p_memory, int is_debug)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;
	u8 type = 0;

	struct vatools_node *node = vatools_get_node();
	if (!p_memory) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "Input parameter is null error .\n");
		return -EFAULT;
	}

	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);
	p_mem_info = sharedmem_get_memptr(reader, p_memory);
	/*Pro_Info( "Sherdme_Delete_Buff IS_Debug=%D\N", IS_Debug);*/
	if (!p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info is null .\n");
		goto ERR_MEM_INFO;
	}

	mutex_lock(&sharedmem_weight_mutex);

	type = p_mem_info->flag_encode_or_decode;
	if (p_mem_info->die_seq != VATOOLS_UINT32_MAX &&
	    p_mem_info->die_seq < MAX_OCCUPY_DIE_NUM &&
	    type < ALLOC_VIDEO_MAX) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"%s: seq %u, reclaim weight %u, real die weight %u, fake %u, type %u\n",
			__func__, p_mem_info->die_seq, p_mem_info->die_weight,
			node->die_weights_real[type][p_mem_info->die_seq]
				.die_weight,
			node->die_weights[type][p_mem_info->die_seq].die_weight,
			type);
		if (node->die_weights_real[type][p_mem_info->die_seq]
			    .die_weight < p_mem_info->die_weight) {
			node->die_weights_real[type][p_mem_info->die_seq]
				.die_weight = 0;
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"%s: reclaim err die_weights_real < p_mem_info->die_weight\n",
				__func__);
		} else {
			node->die_weights_real[type][p_mem_info->die_seq]
				.die_weight -= p_mem_info->die_weight;
		}
	}

	mutex_unlock(&sharedmem_weight_mutex);

	p_buf_header = (T_SHAREDMEM_BUF_HEADER *)p_mem_info->p_buf;
	if (!is_debug && p_buf_header->n_addr != p_memory->n_shard_addr) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, " delete addr is error .\n");
		goto ERR_MEM_INFO;
	}
	/*delete has been locked as a whole, and you don't need to add it internally*/
	/*Delete the corresponding debugger node information lupa 2021-12-15 add*/
	mutex_lock(&reader->sharedmem_mutex);
	list_del(&p_mem_info->t_sharedmem_node);
	mutex_unlock(&reader->sharedmem_mutex);
	sharedmen_free_video_debugbuf(&p_mem_info->tvideo_debugger);
	kvfree(p_mem_info->p_buf);
	p_mem_info->p_buf = NULL;

	delete_from_addr_check_list((uint64_t)p_mem_info,
				    DELETE_ENTRY_FROM_DELETEMEM);
	kvfree(p_mem_info);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, " end\n");
	VATOOLS_FUNC_EXIT;
	return 0;

ERR_MEM_INFO:

	VATOOLS_FUNC_EXIT;

	return -EFAULT;
}

static long sharemem_dlen_per_reader(struct vatools_reader *reader,
				     void __user *p_userbuf, int max_len,
				     int n_type)
{
	int n_len_cnt = 0;
	T_MEM_INFO *p_node = NULL, *p_tmp = NULL;

	void __user *p_buf = (void __user *)p_userbuf;

	if (!reader) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			" list_for_each_entry_safe reader = NULL or p_buf == NULL\n");
		return -EFAULT;
	}
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"reader->n_sharedmem_init_done ! = VATOOLS_INIT_DONE\n");
		return 0;
	}
	if (!p_buf) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "Input parameter is null error .\n");
		return -EFAULT;
	}

	list_for_each_entry_safe (p_node, p_tmp,
				  &reader->t_sharedmem_mem_info_head,
				  t_sharedmem_node) {
		if (!p_node) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				" list_for_each_entry_safe p_node = NULL\n");
			continue;
		}
		if (n_type != p_node->tchannel.writetype ||
		    p_node->n_effic_len == 0) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"n_type(%d) != p_node->tchannel.writetype(%d)  ,p_node->n_effic_len=%d  .\n",
				n_type, p_node->tchannel.writetype,
				p_node->n_effic_len);
			continue;
		}

		if (n_len_cnt + p_node->n_effic_len > max_len) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "User buf is too small .\n");
			break;
		}

		n_len_cnt += p_node->n_effic_len;
	}

	return n_len_cnt;
}

static long sharedmem_read_buf(struct vatools_reader *reader,
			       void __user *p_userbuf, int max_len, int n_type)
{
	int n_len_cnt = 0;
	int n_ret = 0;
	T_MEM_INFO *p_node = NULL, *p_tmp = NULL;

	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;
	/*struct list_head* t_lsit_head = NULL;*/
	void __user *p_buf = (void __user *)p_userbuf;

	if (!reader) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			" list_for_each_entry_safe reader = NULL or p_buf == NULL\n");
		return -EFAULT;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "begin .\n");
	/*In the process of multi-process operation, there may be scenarios where only open is processed by other processes*/
	/* Data that is not initialized is not processed*/
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"reader->n_sharedmem_init_done ! = VATOOLS_INIT_DONE\n");
		return 0;
	}
	if (!p_buf) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "Input parameter is null error .\n");
		return -EFAULT;
	}
	mutex_lock(&reader->sharedmem_mutex);
	list_for_each_entry_safe (p_node, p_tmp,
				  &reader->t_sharedmem_mem_info_head,
				  t_sharedmem_node) {
		if (!p_node) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				" list_for_each_entry_safe p_node = NULL\n");
			continue;
		}
		if (n_type != p_node->tchannel.writetype ||
		    p_node->n_effic_len == 0) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"n_type(%d) != p_node->tchannel.writetype(%d)  ,p_node->n_effic_len=%d  .\n",
				n_type, p_node->tchannel.writetype,
				p_node->n_effic_len);
			continue;
		}

		if (n_len_cnt + p_node->n_effic_len > max_len) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "User buf is too small .\n");
			break;
		}
		mutex_lock(&p_node->mem_info_mutex);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info  %p=lock\n",
			    p_node);
		p_buf_header = (T_SHAREDMEM_BUF_HEADER *)p_node->p_buf;
		/*PR_info, "#%D %Scopy_to_User=%P%P\N", __Line____, __Function___,P_BUF_Header->C_Bodybuff, P_BUF Plus N_Lane_CNT );*/
		if (NULL != p_buf_header && p_node->n_effic_len > 0) {
			if (copy_to_user_ex((u8 *)p_buf + n_len_cnt,
					    p_buf_header->c_bodybuf,
					    p_node->n_effic_len)) {
				VATOOLS_ERR(NULL, DUMMY_DIE_ID,
					    "copy_to_user_ex error .\n");
				n_ret = -EFAULT;
			}
		}

		mutex_unlock(&p_node->mem_info_mutex);
		if (n_ret < 0) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID, " n_ret=%d error .\n",
				     n_ret);
			break;
		}

		n_len_cnt += p_node->n_effic_len;
	}
	mutex_unlock(&reader->sharedmem_mutex);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end . n_len_cnt=%d\n", n_len_cnt);
	return n_len_cnt;
}
static long sharedmem_read_all(T_MEMORY_ENTRY *p_memory)
{
	struct vatools_node *p_current = NULL, *p_next = NULL;
	struct vatools_reader *p_current_reader = NULL, *p_next_reader = NULL;
	u32 n_len_cnt = 0;
	int n_ret = 0;

	/*struct list_head*     ptr   = NULL;*/
	T_SHAREDMEM_BUF_INFO *p_buf =
		(T_SHAREDMEM_BUF_INFO *)p_memory->tdata.n_buf_addr;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);
	if (!p_buf) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     " Input parameter is null error .\n");
		return -EFAULT;
	}
	VATOOLS_FUNC_ENTERY;
	list_for_each_entry_safe (p_current, p_next, vatools_get_vastai_head(),
				  list_nodes) {
#if 1
/*mutex_lock( &p_current->node_mutex );*/
/*
list_for_each( ptr, &p_current->list_node_readers )
{
if ( NULL == ptr || ptr->next == NULL || NULL == ptr->prev )
{
VATOOLS_DBG( "sharedmem_get_memptr_by_channel " );
dump_stack();
return -EFAULT;
}
}
*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_lock(&p_current->node_reader_mutex);
#endif
		list_for_each_entry_safe (p_current_reader, p_next_reader,
					  &p_current->list_node_readers,
					  list_readers) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    " p_current_reader=0x%p  p_current=0x%p\n",
				    p_current_reader, p_current);

			if (p_current_reader->trans_category.app_category ==
			    VATOOLS_APP_SHAREDMEM) {
				/*Copy data by node*/
				if (n_len_cnt >= p_memory->tdata.n_len) {
					VATOOLS_DBG(
						NULL, DUMMY_DIE_ID,
						"n_len_cnt=%d greater then p_memory->n_len=%d .\n",
						n_len_cnt,
						p_memory->tdata.n_len);
					break;
				}

				n_ret = sharemem_dlen_per_reader(
					p_current_reader,
					(u8 *)p_buf->c_buf + n_len_cnt,
					(p_memory->tdata.n_len - n_len_cnt),
					p_memory->tdata.n_type);
				if (n_ret < 0) {
					VATOOLS_DBG(
						NULL, DUMMY_DIE_ID,
						"dlen check return=%d error .\n",
						n_ret);
					break;
				}

				if (n_ret != 0) {
					p_current_reader->filter.filter_info
						.data_len = n_ret;
					if (copy_to_user_ex(
						    (u8 *)p_buf->c_buf +
							    n_len_cnt,
						    &p_current_reader->filter,
						    sizeof(union vatools_filter))) {
						VATOOLS_ERR(
							NULL, DUMMY_DIE_ID,
							"filter info copy_to_user_ex error .\n");
						n_ret = -EFAULT;
						break;
					}
					VATOOLS_DBG(
						NULL, DUMMY_DIE_ID,
						"vpid %d, ns %lld, level %d, element %d, docker id 0x%llx, docker name %s\n",
						p_current_reader->filter
							.filter_info.vpid,
						p_current_reader->filter
							.filter_info.ns,
						p_current_reader->filter
							.filter_info.level,
						p_current_reader->filter
							.filter_info.element_len,
						p_current_reader->filter
							.filter_info.docker_env
							.docker_id,
						p_current_reader->filter
							.filter_info.docker_env
							.docker_name);
					n_len_cnt +=
						p_current_reader->filter
							.filter_info.element_len;
				}

				n_ret = sharedmem_read_buf(
					p_current_reader,
					(u8 *)p_buf->c_buf + n_len_cnt,
					(p_memory->tdata.n_len - n_len_cnt),
					p_memory->tdata.n_type);
				if (n_ret < 0) {
					VATOOLS_DBG(NULL, DUMMY_DIE_ID,
						    " return=%d error .\n",
						    n_ret);
					break;
				}
				n_len_cnt += n_ret;
			}
		}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_unlock(&p_current->node_reader_mutex);
#endif
		/*mutex_unlock( &p_current->node_mutex );*/
		if (n_ret < 0) {
			return n_ret;
		}
#endif
	}
	if (copy_to_user_ex((void __user *)&p_buf->n_len, &n_len_cnt,
			    sizeof(p_buf->n_len))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		return -EFAULT;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end .\n");
	VATOOLS_FUNC_EXIT;
	return 0;
}
static long sharedmem_write_buf(struct vatools_reader *reader,
				T_MEMORY_ENTRY *p_memory)
{
	long n_ret = 0;
	T_MEM_INFO *p_mem_info = NULL;
	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;
	struct vatools_node *node = vatools_get_node();
	u8 type = 0;

	V_UNREFERENCE(reader);

	if (NULL == p_memory) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     " Input parameter is null error .\n");
		return -EFAULT;
	}

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);
	p_mem_info = sharedmem_get_memptr(NULL, p_memory);
	if (!p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    " p_mem_info is null error .\n");
		return -EFAULT;
	}
	VATOOLS_FUNC_ENTERY;

	p_buf_header = (T_SHAREDMEM_BUF_HEADER *)p_mem_info->p_buf;
	if (p_buf_header->n_addr != p_memory->n_shard_addr) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, " write addr is error .\n");
		return -EFAULT;
	}
	if (p_mem_info->n_effic_len < (int)p_memory->tdata.n_len) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     " write date len(%d) malloc len(%d)  is error .\n",
			     p_memory->tdata.n_len, p_mem_info->n_effic_len);
		return -EFAULT;
	}
	mutex_lock(&p_mem_info->mem_info_mutex);

	if (p_memory->die_seq != VATOOLS_UINT32_MAX &&
	    p_memory->die_seq < MAX_OCCUPY_DIE_NUM &&
	    p_mem_info->die_seq == VATOOLS_UINT32_MAX &&
	    p_mem_info->flag_encode_or_decode == ALLOC_VIDEO_MAX &&
	    p_memory->flag_encode_or_decode < ALLOC_VIDEO_MAX) {
		p_mem_info->die_seq = p_memory->die_seq;
		p_mem_info->flag_encode_or_decode =
			p_memory->flag_encode_or_decode;
	}

	type = p_memory->flag_encode_or_decode;
	if (p_memory->die_weight > p_mem_info->die_weight &&
	    p_memory->die_seq != VATOOLS_UINT32_MAX &&
	    p_memory->die_seq < MAX_OCCUPY_DIE_NUM &&
	    p_memory->die_seq == p_mem_info->die_seq &&
	    p_memory->flag_encode_or_decode ==
		    p_mem_info->flag_encode_or_decode &&
	    p_mem_info->flag_encode_or_decode < ALLOC_VIDEO_MAX) {
		mutex_lock(&sharedmem_weight_mutex);
		if ((VATOOLS_UINT32_MAX -
		     node->die_weights_real[type][p_memory->die_seq].die_weight) <
		    (p_memory->die_weight - p_mem_info->die_weight)) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"%s: new > origin weights real outbound, seq %u, real weight, %u, p_mem weight %u, p_mem_info weight %u, type %u\n",
				__func__, p_memory->die_seq,
				node->die_weights_real[type][p_memory->die_seq]
					.die_weight,
				p_memory->die_weight, p_mem_info->die_weight,
				type);
			p_mem_info->die_weight =
				VATOOLS_UINT32_MAX -
				node->die_weights_real[type][p_memory->die_seq]
					.die_weight;
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight = VATOOLS_UINT32_MAX;
		} else {
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight +=
				(p_memory->die_weight - p_mem_info->die_weight);
			p_mem_info->die_weight = p_memory->die_weight;
		}

		mutex_unlock(&sharedmem_weight_mutex);
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"%s: new > origin seq %u, update weight to %u, type %u",
			__func__, p_mem_info->die_seq,
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight,
			type);
	}

	if (p_memory->die_weight < p_mem_info->die_weight &&
	    p_memory->die_seq != VATOOLS_UINT32_MAX &&
	    p_memory->die_seq < MAX_OCCUPY_DIE_NUM &&
	    p_memory->die_seq == p_mem_info->die_seq &&
	    p_memory->flag_encode_or_decode ==
		    p_mem_info->flag_encode_or_decode &&
	    p_mem_info->flag_encode_or_decode < ALLOC_VIDEO_MAX) {
		mutex_lock(&sharedmem_weight_mutex);
		if (node->die_weights_real[type][p_memory->die_seq].die_weight <
		    (p_mem_info->die_weight - p_memory->die_weight)) {
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"%s: origin > new weights real outbound, seq %u, real weight, %u, p_mem weight %u, p_mem_info weight %u, type %u\n",
				__func__, p_memory->die_seq,
				node->die_weights_real[type][p_memory->die_seq]
					.die_weight,
				p_memory->die_weight, p_mem_info->die_weight,
				type);
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight = 0;
			p_mem_info->die_weight = 0;
		} else {
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight -=
				(p_mem_info->die_weight - p_memory->die_weight);
			p_mem_info->die_weight = p_memory->die_weight;
		}
		mutex_unlock(&sharedmem_weight_mutex);
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"%s: origin > new seq %u, update weight to %u, type %u",
			__func__, p_mem_info->die_seq,
			node->die_weights_real[type][p_memory->die_seq]
				.die_weight,
			type);
	}

	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info  %p=lock", p_mem_info);
	/*pr_info( "#%d %copy_from_user_ex = %p %p\n", __LINE__, __FUNCTION__, p_buf_header->c_bodybuf,*/
	/*       ( const void __user* )p_memory->tdata.n_buf_addr );*/
	if (copy_from_user_ex(p_buf_header->c_bodybuf,
			      (const void __user *)p_memory->tdata.n_buf_addr,
			      p_memory->tdata.n_len)) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		n_ret = -EFAULT;
	}
	mutex_unlock(&p_mem_info->mem_info_mutex);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end .\n");
	VATOOLS_FUNC_EXIT;
	return n_ret;
}
static long sharedmem_check_reader(struct vatools_reader *reader)
{
	long ret = 0;
	struct vatools_node *p_current = NULL, *p_next = NULL;
	struct vatools_reader *p_current_reader = NULL, *p_next_reader = NULL;

	/*struct list_head* ptr = NULL;*/

	/*Query whether a node exists*/
	list_for_each_entry_safe (p_current, p_next, vatools_get_vastai_head(),
				  list_nodes) {
		/*
		list_for_each( ptr, &p_current->list_node_readers )
		{
		if ( NULL == ptr || NULL == ptr->next || NULL == ptr->prev )
		{
		VATOOLS_DBG( "sharedmem_get_memptr_by_channel " );
		dump_stack();
		return -EFAULT;
		}
		}
		*/
		/*mutex_lock( &p_current->node_mutex );*/
		list_for_each_entry_safe (p_current_reader, p_next_reader,
					  &p_current->list_node_readers,
					  list_readers) {
			if (reader == p_current_reader) {
				ret = 1;
				break;
			}
		}
		/*mutex_unlock( &p_current->node_mutex );*/
	}
	return ret;
}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
static long sharedmem_poll_buf(struct vatools_reader *reader,
			       T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_node = NULL, *p_tmp = NULL;
	struct vatools_node *p_dev = NULL;
	u32 timeout_water = 3000; /*Wait for 3s in a loop and then execute*/
	long ret = 0;
	T_SHAREDMEM_BUF_INFO *p_bufIn = NULL;
	void __user *p_user_buf = NULL;
	/* Get the handle that the business is waiting for*/
	struct vatools_reader *reader_data = NULL;
	T_SHAREDMEM_BUF_INFO *p_buf = NULL;

	VATOOLS_FUNC_ENTERY;

	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	p_buf = (T_SHAREDMEM_BUF_INFO *)p_memory->tdata.n_buf_addr;

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);
	/* Take out the root node*/
	p_dev = reader->node;

	/* Set the timeout mechanism*/
	p_memory->cmd_type = 0;

	ret = wait_for_completion_interruptible_timeout(
		&(reader->debug_comp), msecs_to_jiffies(timeout_water));
	reinit_completion(&(reader->debug_comp));

	if (ret == 0) {
		p_memory->cmd_type = VATOOLS_MEM_CMD_TIMEOUT;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "timeout! (%d ms) ret=%ld\n",
			    timeout_water, ret);
		ret = -EIO;
		goto END;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "process be killed! ret=%ld\n",
			    ret);
		ret = -EINTR;
		goto END;
	} else if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "Unknow err! ret=%ld\n", ret);
		ret = -EIO;
		goto END;
	}

	mutex_lock(&p_dev->node_sharedmem_mutex);
	ret = 0;
	/*goto POLL_END;*/

	mutex_lock(&reader->node->node_reader_mutex);
	if (0 == sharedmem_check_reader(reader)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "reader is  no find\n");
		mutex_unlock(&reader->node->node_reader_mutex);
		goto POLL_END;
	}

	if (1 == reader->exit) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "recv other_reader is  exit\n");
		mutex_unlock(&reader->node->node_reader_mutex);
		goto POLL_END;
	}
	/*Last Poll_End;*/
	/*Find the corresponding service node*/
	/*pr_info("sharedmem_poll_buf ptr=%p\n", reader);*/
	reader_data = sharedmem_get_other_reader(reader);
	if (NULL == reader_data) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "on find the file node %d\n",
			    reader->trans_category.device.die_index);
		mutex_unlock(&reader->node->node_reader_mutex);
		goto POLL_END;
	}
	if (reader_data->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"reader->n_sharedmem_init_done ! = VATOOLS_INIT_DONE\n");
		mutex_unlock(&reader->node->node_reader_mutex);
		goto POLL_END;
	}
	p_user_buf = (void __user *)p_buf->c_buf;
	mutex_unlock(&reader->node->node_reader_mutex);
	mutex_lock(&reader_data->sharedmem_mutex);
	list_for_each_entry_safe (p_node, p_tmp,
				  &reader_data->t_sharedmem_mem_info_head,
				  t_sharedmem_node) {
		if (1 == p_node->tvideo_debugger.needsendmsg) {
			/*If there is data, it means that the operation is valid.*/
			p_memory->cmd_type = 0;
			p_memory->callback =
				p_node->callback; /* callback function*/
			p_memory->tchannel.id =
				p_node->tchannel
					.id; /*The channel ID corresponding to the channel*/
			p_memory->tchannel.type =
				p_node->tchannel.type; /*The channel type*/
			p_memory->tchannel.writetype =
				p_node->tvideo_debugger
					.startflag; /* Start end flag*/
			p_memory->n_user_addr =
				p_node->user_data; /* User data*/
			p_memory->tdata.n_type =
				p_node->tvideo_debugger
					.debugtype; /*debugger data this time*/
			p_memory->n_shard_addr = (u64)
				p_node; /*The address of the shared memory*/
			/*user data copy*/
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "p_node->tvideo_debugger.debuginfo=%p\n",
				    p_node->tvideo_debugger.debuginfo);
			p_bufIn = (T_SHAREDMEM_BUF_INFO *)
					  p_node->tvideo_debugger.debuginfo;
			if (1 == p_node->tvideo_debugger.startflag &&
			    0 != p_bufIn) {
				VATOOLS_DUMP_BRIEF(
					"tvideo_debugger.debuginfo\n", p_bufIn,
					sizeof(T_SHAREDMEM_BUF_INFO) +
						p_bufIn->n_len);
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"p_bufIn->c_buf %p p_bufIn->n_len=%d\n",
					p_bufIn->c_buf, p_bufIn->n_len);
				if (0 != p_bufIn->n_len) {
					/*pr_info( "#%d %scopy_to_user=%p %p\n", __LINE__, __FUNCTION__, p_user_buf, p_bufIn->c_buf );*/
					if (copy_to_user_ex(
						    (void __user *)p_user_buf,
						    p_bufIn->c_buf,
						    p_bufIn->n_len)) {
						VATOOLS_ERR(
							NULL, DUMMY_DIE_ID,
							"copy_to_user_ex error .\n");
						ret = -EFAULT;
						goto READ_END;
					}
				}
				if (copy_to_user_ex((void __user *)&p_buf->n_len,
						    &p_bufIn->n_len,
						    sizeof(p_bufIn->n_len))) {
					VATOOLS_ERR(
						NULL, DUMMY_DIE_ID,
						"copy_to_user_ex error .\n");
					ret = -EFAULT;
					goto READ_END;
				}
			}

			/* indicates that data has been sent to the upper layer*/
			p_node->tvideo_debugger.needsendmsg = 0;
			break;
		}
	}
READ_END:
	mutex_unlock(&reader_data->sharedmem_mutex);
POLL_END:
	mutex_unlock(&p_dev->node_sharedmem_mutex);
END:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end\n");
	VATOOLS_FUNC_EXIT;
	return ret;
}
#else
static long sharedmem_poll_buf(struct vatools_reader *reader,
			       T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_node = NULL, *p_tmp = NULL;
	struct vatools_node *p_dev = NULL;
	u32 timeout_water = 3000; /*Wait for 3s in a loop and then execute*/
	long ret = 0;
	T_SHAREDMEM_BUF_INFO *p_bufIn = NULL;
	void __user *p_user_buf = NULL;
	/* Get the handle that the business is waiting for*/
	struct vatools_reader *reader_data = NULL;
	T_SHAREDMEM_BUF_INFO *p_buf;

	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}

	p_buf = (T_SHAREDMEM_BUF_INFO *)p_memory->tdata.n_buf_addr;

	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin . addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		p_memory->tdata.n_buf_addr, p_memory->tdata.n_len,
		p_memory->n_shard_addr, p_memory->tdata.n_type);
	/* Take out the root node*/
	p_dev = reader->node;

	/* Set the timeout mechanism*/
	p_memory->cmd_type = 0;

	ret = wait_for_completion_interruptible_timeout(
		&(reader->debug_comp), msecs_to_jiffies(timeout_water));
	reinit_completion(&(reader->debug_comp));

	if (ret == 0) {
		p_memory->cmd_type = VATOOLS_MEM_CMD_TIMEOUT;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "timeout! (%d ms) ret=%ld\n",
			    timeout_water, ret);
		ret = -EIO;
		goto END;
	} else if (ret == -ERESTARTSYS || ret == -EINTR) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "process be killed! ret=%ld\n",
			    ret);
		ret = -EINTR;
		goto END;
	} else if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "Unknow err! ret=%ld\n", ret);
		ret = -EIO;
		goto END;
	}

	mutex_lock(&p_dev->node_mutex);
	mutex_lock(&p_dev->node_sharedmem_mutex);
	ret = 0;
	/*goto POLL_END;*/

	if (0 == sharedmem_check_reader(reader)) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "reader is  no find\n");
		goto POLL_END;
	}

	if (1 == reader->exit) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "recv other_reader is  exit\n");
		goto POLL_END;
	}
	/*Last Poll_End;*/
	/*Find the corresponding service node*/
	/*pr_info("sharedmem_poll_buf ptr=%p\n", reader);*/
	reader_data = sharedmem_get_other_reader(reader);
	if (NULL == reader_data) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "on find the file node %d\n",
			    reader->trans_category.device.die_index);
		goto POLL_END;
	}
	if (reader_data->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"reader->n_sharedmem_init_done ! = VATOOLS_INIT_DONE\n");
		goto POLL_END;
	}
	p_user_buf = (void __user *)p_buf->c_buf;
	mutex_lock(&reader_data->sharedmem_mutex);
	list_for_each_entry_safe (p_node, p_tmp,
				  &reader_data->t_sharedmem_mem_info_head,
				  t_sharedmem_node) {
		if (1 == p_node->tvideo_debugger.needsendmsg) {
			/*If there is data, it means that the operation is valid.*/
			p_memory->cmd_type = 0;
			p_memory->callback =
				p_node->callback; /* callback function*/
			p_memory->tchannel.id =
				p_node->tchannel
					.id; /*The channel ID corresponding to the channel*/
			p_memory->tchannel.type =
				p_node->tchannel.type; /*The channel type*/
			p_memory->tchannel.writetype =
				p_node->tvideo_debugger
					.startflag; /* Start end flag*/
			p_memory->n_user_addr =
				p_node->user_data; /* User data*/
			p_memory->tdata.n_type =
				p_node->tvideo_debugger
					.debugtype; /*debugger data this time*/
			p_memory->n_shard_addr = (u64)
				p_node; /*The address of the shared memory*/
			/*user data copy*/
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "p_node->tvideo_debugger.debuginfo=%p\n",
				    p_node->tvideo_debugger.debuginfo);
			p_bufIn = (T_SHAREDMEM_BUF_INFO *)
					  p_node->tvideo_debugger.debuginfo;
			if (1 == p_node->tvideo_debugger.startflag &&
			    0 != p_bufIn) {
				VATOOLS_DUMP_BRIEF(
					"tvideo_debugger.debuginfo\n", p_bufIn,
					sizeof(T_SHAREDMEM_BUF_INFO) +
						p_bufIn->n_len);
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"p_bufIn->c_buf %p p_bufIn->n_len=%d\n",
					p_bufIn->c_buf, p_bufIn->n_len);
				if (0 != p_bufIn->n_len) {
					/*pr_info( "#%d %scopy_to_user=%p %p\n", __LINE__, __FUNCTION__, p_user_buf, p_bufIn->c_buf );*/
					if (copy_to_user_ex(
						    (void __user *)p_user_buf,
						    p_bufIn->c_buf,
						    p_bufIn->n_len)) {
						VATOOLS_ERR(
							NULL, DUMMY_DIE_ID,
							"copy_to_user_ex error .\n");
						ret = -EFAULT;
						goto READ_END;
					}
				}
				if (copy_to_user_ex((void __user *)&p_buf->n_len,
						    &p_bufIn->n_len,
						    sizeof(p_bufIn->n_len))) {
					VATOOLS_ERR(
						NULL, DUMMY_DIE_ID,
						"copy_to_user_ex error .\n");
					ret = -EFAULT;
					goto READ_END;
				}
			}

			/* indicates that data has been sent to the upper layer*/
			p_node->tvideo_debugger.needsendmsg = 0;
			break;
		}
	}
READ_END:
	mutex_unlock(&reader_data->sharedmem_mutex);
POLL_END:
	mutex_unlock(&p_dev->node_sharedmem_mutex);
	mutex_unlock(&p_dev->node_mutex);
END:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end\n");
	VATOOLS_FUNC_EXIT;
	return ret;
}
#endif

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
static long sharedmem_start_video_debugger(struct vatools_reader *reader,
					   T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_MEMORY_ENTRY tMemEntry;
	int n_ret = 0;
	struct vatools_reader *reader_wait = NULL;
	T_SHAREDMEM_BUF_INFO *p_buf = NULL;
	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	/*return 0;*/
	VATOOLS_FUNC_ENTERY;
	memcpy(&tMemEntry, p_memory, sizeof(T_MEMORY_ENTRY));
	/* to the service node*/
	tMemEntry.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;
	p_mem_info = sharedmem_get_memptr(NULL, &tMemEntry);
	if (NULL == p_mem_info) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	/*Locate the service node Find fdtype*/
	if (p_mem_info->tvideo_debugger.pmeminfo) {
		/*pr_info( "sharedmem_start_video_debugger ptr=%p\n", p_mem_info->reader );*/
		mutex_lock(&p_mem_info->reader->node->node_reader_mutex);
		reader_wait = sharedmem_get_other_reader(p_mem_info->reader);
		if (NULL == reader_wait) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "no find wait for thread\n");
			n_ret = -EFAULT;
			mutex_unlock(
				&p_mem_info->reader->node->node_reader_mutex);
			goto SHARED_END;
		}
		if (1 == p_mem_info->tvideo_debugger.startflag) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "the channel is starting debugger\n");
			n_ret = -EEXIST;
			mutex_unlock(
				&p_mem_info->reader->node->node_reader_mutex);
			goto SHARED_END;
		}
		/*Create debugger-related data*/
		p_mem_info->tvideo_debugger.debuginfo = kvmalloc(
			sizeof(T_SHAREDMEM_BUF_INFO) + p_memory->tdata.n_len,
			GFP_KERNEL);
		if (NULL == p_mem_info->tvideo_debugger.debuginfo) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID,
				     "kvmalloc is error.\n");
			n_ret = -EFAULT;
			mutex_unlock(
				&p_mem_info->reader->node->node_reader_mutex);
			goto SHARED_END;
		}
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "p_mem_info->tvideo_debugger.debuginfo=%p\n",
			    p_mem_info->tvideo_debugger.debuginfo);
		p_mem_info->tvideo_debugger.debugtype = p_memory->tdata.n_type;
		/*Assign a value to the content of the data*/
		p_buf = (T_SHAREDMEM_BUF_INFO *)
				p_mem_info->tvideo_debugger.debuginfo;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_memory->tdata.n_len=%d\n",
			    p_memory->tdata.n_len);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "p_memory->tdata.n_buf_addr=0x%llx\n",
			    p_memory->tdata.n_buf_addr);

		if (p_memory->tdata.n_len > 0) {
			/*pr_info( "#%d %s copy_from_user_ex=%p %p\n", __LINE__, __FUNCTION__, p_buf->c_buf,*/
			/*       ( const void __user* )p_memory->tdata.n_buf_addr );*/
			if (copy_from_user_ex(p_buf->c_buf,
					      (const void __user *)p_memory
						      ->tdata.n_buf_addr,
					      p_memory->tdata.n_len)) {
				VATOOLS_ERR(NULL, DUMMY_DIE_ID,
					    "copy_from_user_ex error .\n");
				n_ret = -EFAULT;
				kvfree(p_mem_info->tvideo_debugger.debuginfo);
				p_mem_info->tvideo_debugger.debuginfo = NULL;
				mutex_unlock(&p_mem_info->reader->node
						      ->node_reader_mutex);
				goto SHARED_END;
			}
		}

		p_buf->n_len = p_memory->tdata.n_len;
		VATOOLS_DUMP_BRIEF(">tvideo_debugger.debuginfo", p_buf,
				   sizeof(T_SHAREDMEM_BUF_INFO) +
					   p_memory->tdata.n_len);
		/* Set the start flag*/
		p_mem_info->tvideo_debugger.needsendmsg = 1;
		p_mem_info->tvideo_debugger.startflag = 1;
		/*Pointer data is brought back to the service*/
		p_memory->n_shard_addr = (u64)p_mem_info;
		/*complete( &reader_wait->debug_comp );*/
		sharemen_set_comp_complete(reader_wait);
		mutex_unlock(&p_mem_info->reader->node->node_reader_mutex);
	} else {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the pmeminfo  is null\n");
	}
	/*In order to release the corresponding resource when stopping*/
	n_ret = sharedmem_create_buf(reader, p_memory, 1);

SHARED_END:
	VATOOLS_FUNC_EXIT;

	/* Create your own shared memory data. It is used to notify the service when it is released*/
	return n_ret;
}
#else
static long sharedmem_start_video_debugger(struct vatools_reader *reader,
					   T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_MEMORY_ENTRY tMemEntry;
	int n_ret = 0;
	struct vatools_reader *reader_wait = NULL;
	T_SHAREDMEM_BUF_INFO *p_buf = NULL;
	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	/*return 0;*/
	VATOOLS_FUNC_ENTERY;
	memcpy(&tMemEntry, p_memory, sizeof(T_MEMORY_ENTRY));
	/* to the service node*/
	tMemEntry.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;
	p_mem_info = sharedmem_get_memptr(NULL, &tMemEntry);
	if (NULL == p_mem_info) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	/*Locate the service node Find fdtype*/
	if (p_mem_info->tvideo_debugger.pmeminfo) {
		/*pr_info( "sharedmem_start_video_debugger ptr=%p\n", p_mem_info->reader );*/
		reader_wait = sharedmem_get_other_reader(p_mem_info->reader);
		if (NULL == reader_wait) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "no find wait for thread\n");
			n_ret = -EFAULT;
			goto SHARED_END;
		}
		if (1 == p_mem_info->tvideo_debugger.startflag) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "the channel is starting debugger\n");
			n_ret = -EEXIST;
			goto SHARED_END;
		}
		/*Create debugger-related data*/
		p_mem_info->tvideo_debugger.debuginfo = kvmalloc(
			sizeof(T_SHAREDMEM_BUF_INFO) + p_memory->tdata.n_len,
			GFP_KERNEL);
		if (NULL == p_mem_info->tvideo_debugger.debuginfo) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID,
				     "kvmalloc is error.\n");
			n_ret = -EFAULT;
			goto SHARED_END;
		}
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "p_mem_info->tvideo_debugger.debuginfo=%p\n",
			    p_mem_info->tvideo_debugger.debuginfo);
		p_mem_info->tvideo_debugger.debugtype = p_memory->tdata.n_type;
		/*Assign a value to the content of the data*/
		p_buf = (T_SHAREDMEM_BUF_INFO *)
				p_mem_info->tvideo_debugger.debuginfo;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_memory->tdata.n_len=%d\n",
			    p_memory->tdata.n_len);
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "p_memory->tdata.n_buf_addr=0x%llx\n",
			    p_memory->tdata.n_buf_addr);

		if (p_memory->tdata.n_len > 0) {
			/*pr_info( "#%d %s copy_from_user_ex=%p %p\n", __LINE__, __FUNCTION__, p_buf->c_buf,*/
			/*       ( const void __user* )p_memory->tdata.n_buf_addr );*/
			if (copy_from_user_ex(p_buf->c_buf,
					      (const void __user *)p_memory
						      ->tdata.n_buf_addr,
					      p_memory->tdata.n_len)) {
				VATOOLS_ERR(NULL, DUMMY_DIE_ID,
					    "copy_from_user_ex error .\n");
				n_ret = -EFAULT;
				kvfree(p_mem_info->tvideo_debugger.debuginfo);
				p_mem_info->tvideo_debugger.debuginfo = NULL;
				goto SHARED_END;
			}
		}

		p_buf->n_len = p_memory->tdata.n_len;
		VATOOLS_DUMP_BRIEF(">tvideo_debugger.debuginfo", p_buf,
				   sizeof(T_SHAREDMEM_BUF_INFO) +
					   p_memory->tdata.n_len);
		/* Set the start flag*/
		p_mem_info->tvideo_debugger.needsendmsg = 1;
		p_mem_info->tvideo_debugger.startflag = 1;
		/*Pointer data is brought back to the service*/
		p_memory->n_shard_addr = (u64)p_mem_info;
		/*complete( &reader_wait->debug_comp );*/
		sharemen_set_comp_complete(reader_wait);
	} else {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the pmeminfo  is null\n");
	}
	/*In order to release the corresponding resource when stopping*/
	n_ret = sharedmem_create_buf(reader, p_memory, 1);

SHARED_END:
	VATOOLS_FUNC_EXIT;

	/* Create your own shared memory data. It is used to notify the service when it is released*/
	return n_ret;
}
#endif
static long sharedmem_stop_video_debugger(struct vatools_reader *reader,
					  T_MEMORY_ENTRY *p_memory)
{
	T_MEM_INFO *p_mem_info = NULL;
	T_MEMORY_ENTRY tMemEntry;
	int n_ret = 0;
	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	VATOOLS_FUNC_ENTERY;
	memcpy(&tMemEntry, p_memory, sizeof(T_MEMORY_ENTRY));
	/* to the service node*/
	tMemEntry.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;

	p_mem_info = sharedmem_get_memptr(NULL, &tMemEntry);
	if (NULL == p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "no find  memory info\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	/*pr_info( "sharedmem_stop_video_debugger" );*/
	sharedmen_free_video_debugbuf(&p_mem_info->tvideo_debugger);
	n_ret = sharedmem_delete_buf(reader, p_memory, 1);
SHARED_END:
	VATOOLS_FUNC_EXIT;
	return n_ret;
}
static long sharedmem_read_video_debugger(struct vatools_reader *reader,
					  T_MEMORY_ENTRY *p_memory)
{
	/* A global lock needs to be added*/
	t_video_debug_info *p_current = NULL, *p_next = NULL;
	T_MEM_INFO *p_mem_info = NULL;
	void __user *p_user_buf = NULL;
	T_MEMORY_ENTRY tMemEntry;
	int n_ret = 0;
	int n_len_cnt = 0;
	T_SHAREDMEM_BUF_INFO *p_buf;
	int n_max_len = 0;

	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	p_buf = (T_SHAREDMEM_BUF_INFO *)p_memory->tdata.n_buf_addr;
	if (NULL == p_buf) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	n_max_len = p_memory->tdata.n_len;

	VATOOLS_FUNC_ENTERY;
	memcpy(&tMemEntry, p_memory, sizeof(T_MEMORY_ENTRY));
	/* to the service node*/
	tMemEntry.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;
	p_mem_info = sharedmem_get_memptr(NULL, &tMemEntry);
	if (NULL == p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info is null\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	p_user_buf = p_buf->c_buf;
	/*Get video-related data*/
	list_for_each_entry_safe (p_current, p_next,
				  &p_mem_info->tvideo_debugger.t_node_head,
				  t_video_node) {
		T_SHAREDMEM_BUF_HEADER *p_buf_header =
			(T_SHAREDMEM_BUF_HEADER *)p_current->p_buf;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "n_len_cnt=%d\n", n_len_cnt);
		if (n_max_len <= n_len_cnt + p_current->n_effic_len) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID,
				    "the memory too large please get again");
			n_ret = n_len_cnt;
			goto SHARED_END;
		}
		/*pr_info( "#%d %s copy_to_user_ex=%p %p\n", __LINE__, __FUNCTION__, p_user_buf + n_len_cnt,*/
		/*        p_buf_header->c_bodybuf );*/
		if (copy_to_user_ex((u8 *)p_user_buf + n_len_cnt,
				    p_buf_header->c_bodybuf,
				    p_current->n_effic_len)) {
			VATOOLS_ERR(NULL, DUMMY_DIE_ID,
				    "copy_to_user_ex error .\n");
			n_ret = n_len_cnt;
			goto SHARED_END;
		}

		n_len_cnt += p_current->n_effic_len;
		/* Retake it from the queue first*/
		list_del(&p_current->t_video_node);
		/* Free up space again*/
		kvfree(p_current->p_buf);
		kvfree(p_current);
	}
	if (copy_to_user_ex((void __user *)&p_buf->n_len, &n_len_cnt,
			    sizeof(p_buf->n_len))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		return -EFAULT;
	}
SHARED_END:
	VATOOLS_FUNC_EXIT;
	return n_ret;
}

static long sharedmem_set_docker_info(struct vatools_reader *reader,
				      T_MEMORY_ENTRY *p_memory)
{
	VATOOLS_FUNC_ENTERY;
	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}

	if (sizeof(struct docker_info) != p_memory->tdata.n_len) {
		VATOOLS_INFO(
			NULL, DUMMY_DIE_ID,
			"error docker info len, sizeof(struct docker_info) %ld, p_memory->tdata.n_len %d\n",
			sizeof(struct docker_info), p_memory->tdata.n_len);
		return -EFAULT;
	}

	if (copy_from_user_ex(&reader->filter.filter_info.docker_env,
			      (const void __user *)p_memory->tdata.n_buf_addr,
			      sizeof(struct docker_info))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		return -EFAULT;
	}
	return 0;
}

static long sharedmem_write_video_debugger(struct vatools_reader *reader,
					   T_MEMORY_ENTRY *p_memory)
{
	t_video_debug_info *pdebuginfo = NULL;
	T_SHAREDMEM_BUF_HEADER *p_buf_header = NULL;
	T_MEM_INFO *p_mem_info = NULL;
	int nstartflag = 0;
	T_MEMORY_ENTRY tMemEntry;
	if (NULL == p_memory || NULL == reader) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		return -EFAULT;
	}
	VATOOLS_FUNC_ENTERY;
	memcpy(&tMemEntry, p_memory, sizeof(T_MEMORY_ENTRY));

	/*Fetch the service node The memory is mounted below the service node*/
	tMemEntry.tchannel.writetype = VATOOLS_SHAREDMEM_WRITE_DATA;
	p_mem_info = sharedmem_get_memptr(NULL, &tMemEntry);
	if (NULL == p_mem_info) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "the memory info is null\n");
		goto ERR_MEM_INFO;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "p_mem_info->tchannel.id=%d,type=%d,writetype=%d\n",
		    p_mem_info->tchannel.id, p_mem_info->tchannel.type,
		    p_mem_info->tchannel.writetype);

	/*When startflag is 0, no data needs to be written*/
	mutex_lock(&p_mem_info->mem_info_mutex);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "p_mem_info  %p=lock\n", p_mem_info);
	nstartflag = p_mem_info->tvideo_debugger.startflag;
	mutex_unlock(&p_mem_info->mem_info_mutex);
	if (0 == nstartflag) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "the memory entry is null\n");
		goto ERR_MEM_INFO;
	}
	pdebuginfo = (t_video_debug_info *)kvmalloc(sizeof(t_video_debug_info),
						    GFP_KERNEL);
	if (NULL == pdebuginfo) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "kvmalloc is error.\n");
		goto ERR_MEM_INFO;
	}
	pdebuginfo->p_buf =
		kvmalloc(p_memory->tdata.n_len + sizeof(u64), GFP_KERNEL);
	if (!pdebuginfo->p_buf) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, " kvmalloc error. size=%ld\n",
			     p_memory->tdata.n_len + sizeof(u64));
		goto ERR_MEM_INFO_BUF;
	}
	INIT_LIST_HEAD(&pdebuginfo->t_video_node);
	pdebuginfo->n_effic_len = p_memory->tdata.n_len;
	p_buf_header = (T_SHAREDMEM_BUF_HEADER *)pdebuginfo->p_buf;
	p_buf_header->n_addr = (u64)p_memory;
	if (copy_from_user_ex(p_buf_header->c_bodybuf,
			      (const void __user *)p_memory->tdata.n_buf_addr,
			      p_memory->tdata.n_len)) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		goto ERR_MEM_INFO_TYPE;
	}
	mutex_lock(&p_mem_info->tvideo_debugger.data_info_mutex);
	p_mem_info->tvideo_debugger.data_cnt++;
	list_add_tail(&p_mem_info->tvideo_debugger.t_node_head,
		      &pdebuginfo->t_video_node);
	while (p_mem_info->tvideo_debugger.data_cnt > 100) {
/* Delete the first element*/
#if (TOOLS_WIN == 1)
		list_del(p_mem_info->tvideo_debugger.t_node_head.Flink);
#else
		list_del(p_mem_info->tvideo_debugger.t_node_head.next);
#endif
		p_mem_info->tvideo_debugger.data_cnt--;
	}
	mutex_unlock(&p_mem_info->tvideo_debugger.data_info_mutex);
	VATOOLS_FUNC_EXIT;
	return 0;

ERR_MEM_INFO_TYPE:
	kvfree(pdebuginfo->p_buf);
ERR_MEM_INFO_BUF:
	pdebuginfo->p_buf = NULL;
	kvfree(pdebuginfo);
ERR_MEM_INFO:
	pdebuginfo = NULL;
	VATOOLS_FUNC_EXIT;

	return -EFAULT;
}

loff_t sharedmem_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);

	return 0;
}
ssize_t sharedmem_read(struct file *filp, char __user *buffer, size_t size,
		       loff_t *ppos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buffer);
	V_UNREFERENCE(size);
	V_UNREFERENCE(ppos);

	return 0;
}
ssize_t sharedmem_write(struct file *filp, const char __user *buffer,
			size_t size, loff_t *ppos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buffer);
	V_UNREFERENCE(size);
	V_UNREFERENCE(ppos);

	return 0;
}
unsigned int sharedmem_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);

	return 0;
}
/*
static long sharedmem_create_video_debugger_func( struct vatools_reader* reader, T_MEMORY_ENTRY* p_memory )
{
long        n_ret      = 0;
T_MEM_INFO* p_mem_info = NULL;
if ( NULL == p_memory || NULL == reader )
{
VATOOLS_INFO( "the memory entry is null" );
return -EFAULT;
}
p_mem_info = sharedmem_get_memptr( reader, p_memory );
if ( !p_mem_info )
{
VATOOLS_INFO( "p_mem_info is null ." );
return -EFAULT;
}
mutex_lock( &p_mem_info->mem_info_mutex );
p_mem_info->tchannel.id   = p_memory->tchannel.id;
p_mem_info->tchannel.type = p_memory->tchannel.type;
p_mem_info->callback      = p_memory->callback;
mutex_unlock( &p_mem_info->mem_info_mutex );
return 0;
}
static long sharedmem_delete_video_debugger_func( struct vatools_reader* reader, T_MEMORY_ENTRY* p_memory )
{
long        n_ret      = 0;
T_MEM_INFO* p_mem_info = NULL;
if ( NULL == p_memory || NULL == reader )
{
VATOOLS_INFO( "the memory entry is null" );
return -EFAULT;
}
p_mem_info = sharedmem_get_memptr( reader, p_memory );
if ( !p_mem_info )
{
VATOOLS_INFO( "p_mem_info is null ." );
return - EFAULT;
}
mutex_lock ( &p_mem_info ->mem_info_mutex );
p_mem_info->tchannel.id = -1;
p_mem_info->tchannel.type = -1;
p_mem_info ->callback = NULL;
mutex_unlock( &p_mem_info->mem_info_mutex);
return 0;
}
*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
long sharedmem_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long n_ret = -EIO;
	T_MEMORY_ENTRY t_memory = { 0 };
	struct vatools_node *p_dev = NULL;
	struct vatools_reader *reader = NULL;
	void __user *p_argp = (void __user *)arg;
	/*int                    pull     = 0;*/
	VATOOLS_FUNC_ENTERY;

	trace_sharedmem_ioctl_start(NULL, 0, 0, 0, __func__);
	reader = vatools_file_get_reader(filp);
	if (NULL == reader) {
		/*pr_info( " NULL == reader  ." );*/
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	p_dev = vatools_file_get_node(filp);
	mutex_lock(&p_dev->node_sharedmem_mutex);
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin cmd=0x%x  p_dev=0x%p  reader=0x%p  &reader->sharedmem_mutex=0x%p\n",
		cmd, p_dev, reader, &reader->sharedmem_mutex);

	if (copy_from_user_ex(&t_memory, p_argp, sizeof(T_MEMORY_ENTRY))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		n_ret = -EFAULT;
		goto SHARED_MUTEX_END;
	}

	/* If it is not initialized, it will not be processed by the business for a long time*/
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "n_sharedmem_init_done is not inited .\n");
		n_ret = -EFAULT;
		goto SHARED_MUTEX_END;
	}
	mutex_unlock(&p_dev->node_sharedmem_mutex);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		    t_memory.tdata.n_buf_addr, t_memory.tdata.n_len,
		    t_memory.n_shard_addr, t_memory.tdata.n_type);

	switch (cmd) {
		/* Create shared memory*/
	case VATOOLS_CREATE_SHARE_MEM:
	case OLD_VATOOLS_CREATE_SHARE_MEM:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_create_buf(reader, &t_memory, 0);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/* Delete shared memory*/
	case VATOOLS_DELETE_SHARE_MEM:
	case OLD_VATOOLS_DELETE_SHARE_MEM:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_delete_buf(reader, &t_memory, 0);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/* Reads all shared memory data*/
	case VATOOLS_READ_SHARE_MEM:
	case OLD_VATOOLS_READ_SHARE_MEM:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_read_all(&t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/* Write to shared memory*/
	case VATOOLS_WRITE_SHARE_MEM:
	case OLD_VATOOLS_WRITE_SHARE_MEM:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_write_buf(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/*Listen on shared memory lupa 2021-12-15 add*/
	case VATOOLS_POLL_SHARE_MEM:
	case OLD_VATOOLS_POLL_SHARE_MEM:
		/*pull  = 1;*/
		n_ret = sharedmem_poll_buf(reader, &t_memory);
		break;
		/*Start listening video debugger data lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_start_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/*stop debugger lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_stop_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/*Read debugger information lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_read_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/*Write denbugger information lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_write_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
		/*case VATOOLS_CREATE_VIDEO_MEM_FUNCTION:*/
		/*    n_ret = sharedmem_create_video_debugger_func( reader, &t_memory );*/
		/*    break;*/
		/*case VATOOLS_DELETE_VIDEO_MEM_FUNCTION:*/
		/*    n_ret = sharedmem_delete_video_debugger_func( reader, &t_memory );*/
		/*    break;*/
	case VATOOLS_SHARE_MEM_SET_DOCKER_NAME:
	case OLD_VATOOLS_SHARE_MEM_SET_DOCKER_NAME:
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_set_docker_info(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		break;
	default:
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown oictl:0x%x.\n", cmd);
		break;
	}
	if (copy_to_user_ex((void __user *)p_argp, &t_memory,
			    sizeof(T_MEMORY_ENTRY))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end cmd=0x%x. ret=%ld\n", cmd, n_ret);
	VATOOLS_FUNC_EXIT;
	/*Exit normally*/
	return n_ret;
SHARED_MUTEX_END:
	mutex_unlock(&p_dev->node_sharedmem_mutex);
SHARED_END:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end cmd=0x%x. ret=%ld\n", cmd, n_ret);
	VATOOLS_FUNC_EXIT;
	trace_sharedmem_ioctl_end(NULL, 0, 0, 0, __func__);
	return n_ret;
}
#else
long sharedmem_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long n_ret = -EIO;
	T_MEMORY_ENTRY t_memory = { 0 };
	struct vatools_node *p_dev = NULL;
	struct vatools_reader *reader = NULL;
	void __user *p_argp = (void __user *)arg;
	/*int                    pull     = 0;*/
	VATOOLS_FUNC_ENTERY;

	trace_sharedmem_ioctl_start(NULL, 0, 0, 0, __func__);
	reader = vatools_file_get_reader(filp);
	if (NULL == reader) {
		/*pr_info( " NULL == reader  ." );*/
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	p_dev = vatools_file_get_node(filp);
	mutex_lock(&p_dev->node_mutex);
	mutex_lock(&p_dev->node_sharedmem_mutex);
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"begin cmd=0x%x  p_dev=0x%p  reader=0x%p  &reader->sharedmem_mutex=0x%p\n",
		cmd, p_dev, reader, &reader->sharedmem_mutex);

	if (copy_from_user_ex(&t_memory, p_argp, sizeof(T_MEMORY_ENTRY))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex error .\n");
		n_ret = -EFAULT;
		goto SHARED_MUTEX_END;
	}

	/* If it is not initialized, it will not be processed by the business for a long time*/
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "n_sharedmem_init_done is not inited .\n");
		n_ret = -EFAULT;
		goto SHARED_MUTEX_END;
	}
	mutex_unlock(&p_dev->node_sharedmem_mutex);
	mutex_unlock(&p_dev->node_mutex);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "addr=0x%llx  len=%d  shared_addr=0x%llx  type=%d\n",
		    t_memory.tdata.n_buf_addr, t_memory.tdata.n_len,
		    t_memory.n_shard_addr, t_memory.tdata.n_type);

	switch (cmd) {
		/* Create shared memory*/
	case VATOOLS_CREATE_SHARE_MEM:
	case OLD_VATOOLS_CREATE_SHARE_MEM:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_create_buf(reader, &t_memory, 0);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/* Delete shared memory*/
	case VATOOLS_DELETE_SHARE_MEM:
	case OLD_VATOOLS_DELETE_SHARE_MEM:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_delete_buf(reader, &t_memory, 0);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/* Reads all shared memory data*/
	case VATOOLS_READ_SHARE_MEM:
	case OLD_VATOOLS_READ_SHARE_MEM:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_read_all(&t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/* Write to shared memory*/
	case VATOOLS_WRITE_SHARE_MEM:
	case OLD_VATOOLS_WRITE_SHARE_MEM:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_write_buf(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/*Listen on shared memory lupa 2021-12-15 add*/
	case VATOOLS_POLL_SHARE_MEM:
	case OLD_VATOOLS_POLL_SHARE_MEM:
		/*pull  = 1;*/
		n_ret = sharedmem_poll_buf(reader, &t_memory);
		break;
		/*Start listening video debugger data lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_start_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/*Stop debugger lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_stop_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/*Read debugger information lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_read_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/*Write denbugger information lupa 2021-12-15 add*/
	case VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER:
	case OLD_VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_write_video_debugger(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;

	case VATOOLS_SHARE_MEM_SET_DOCKER_NAME:
	case OLD_VATOOLS_SHARE_MEM_SET_DOCKER_NAME:
		mutex_lock(&p_dev->node_mutex);
		mutex_lock(&p_dev->node_sharedmem_mutex);
		n_ret = sharedmem_set_docker_info(reader, &t_memory);
		mutex_unlock(&p_dev->node_sharedmem_mutex);
		mutex_unlock(&p_dev->node_mutex);
		break;
		/*case VATOOLS_CREATE_VIDEO_MEM_FUNCTION:*/
		/*    n_ret = sharedmem_create_video_debugger_func( reader, &t_memory );*/
		/*    break;*/
		/*case VATOOLS_DELETE_VIDEO_MEM_FUNCTION:*/
		/*    n_ret = sharedmem_delete_video_debugger_func( reader, &t_memory );*/
		/*    break;*/
	default:
		n_ret = -E_UNKNOWN_SUB_CMD;
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "unknown oictl:0x%x.\n", cmd);
		break;
	}
	if (copy_to_user_ex((void __user *)p_argp, &t_memory,
			    sizeof(T_MEMORY_ENTRY))) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_to_user_ex error .\n");
		n_ret = -EFAULT;
		goto SHARED_END;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end cmd=0x%x. ret=%ld\n", cmd, n_ret);
	VATOOLS_FUNC_EXIT;
	/*Exit normally*/
	return n_ret;
SHARED_MUTEX_END:
	mutex_unlock(&p_dev->node_sharedmem_mutex);
	mutex_unlock(&p_dev->node_mutex);
SHARED_END:
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end cmd=0x%x. ret=%ld\n", cmd, n_ret);
	VATOOLS_FUNC_EXIT;
	trace_sharedmem_ioctl_end(NULL, 0, 0, 0, __func__);
	return n_ret;
}
#endif

int sharedmem_open(struct inode *inode, struct file *filp)
{
	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);
#if 0
	struct vatools_node *p_dev = vatools_file_get_node(filp);
	struct vatools_node *anonymous_dev;
	int ret;
	struct vatools_reader *reader;
	VATOOLS_DBG("begin ");
	ret = nonseekable_open(inode, filp);
	if (ret) {
		return ret;
	}
	anonymous_dev = kvmalloc(sizeof(*p_dev), GFP_KERNEL);
	if (!anonymous_dev) {
		VATOOLS_INFO("kvmalloc error . size=%d\n", sizeof(*p_dev));
		return -ENOMEM;
	}
	memcpy(anonymous_dev, p_dev, sizeof(*p_dev));
	INIT_LIST_HEAD(&anonymous_dev->list_nodes);
	INIT_LIST_HEAD(&anonymous_dev->t_sharedmem_mem_info_head);
	INIT_LIST_HEAD(&anonymous_dev->t_sharedmem_signal_info_head);
	mutex_init(&anonymous_dev->sharedmem_mutex);
	mutex_lock(&p_dev->sharedmem_mutex);
	list_add_tail(&anonymous_dev->list_nodes, vatools_get_vastai_head());
	mutex_unlock(&p_dev->sharedmem_mutex);
	/*filp->private_data = anonymous_dev;*/
	reader = vatools_file_get_reader(filp);
	reader->node = anonymous_dev;
#endif
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end\n");
	return 0;
}
int sharedmem_fasync(int fd, struct file *filp, int mode)
{
	struct vatools_reader *reader = NULL;
	reader = vatools_file_get_reader(filp);

	return fasync_helper(fd, filp, mode, &reader->sharedmem_pt_fasync);
}

static int sharedmen_free_buf(struct vatools_reader *reader)
{
	int type = 0;
	T_MEM_INFO *p_current = NULL, *p_tmp = NULL;
	struct vatools_reader *reader_other = NULL;
	struct vatools_node *node = vatools_get_node();
	/*struct list_head*      ptr          = NULL;*/
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "begin.\n");
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "n_sharedmem_init_done is not int_done.\n");
		return 0;
	}

	/*
	list_for_each( ptr, &reader->t_sharedmem_mem_info_head )
	{
		if ( NULL == ptr || ptr->next == NULL || NULL == ptr->prev )
		{
			VATOOLS_DBG( "t_sharedmem_mem_info_head ");
			dump_stack();
			return NULL;
		}
	}
	*/
	mutex_lock(&reader->sharedmem_mutex);
	list_for_each_entry_safe (p_current, p_tmp,
				  &reader->t_sharedmem_mem_info_head,
				  t_sharedmem_node) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"list_for_each_entry_safe.t_sharedmem_mem_info_head\n");
		list_del(&p_current->t_sharedmem_node);
		/*Release the debugger data first*/
		sharedmen_free_video_debugbuf(&p_current->tvideo_debugger);
		p_current->tvideo_debugger.pmeminfo = NULL;
		p_current->tvideo_debugger.debuginfo = NULL;

		mutex_lock(&sharedmem_weight_mutex);
		type = p_current->flag_encode_or_decode;
		if (p_current->die_seq != VATOOLS_UINT32_MAX &&
		    p_current->die_seq < MAX_OCCUPY_DIE_NUM &&
		    p_current->die_weight != 0 &&
		    p_current->flag_encode_or_decode < ALLOC_VIDEO_MAX) {
			if (node->die_weights_real[type][p_current->die_seq]
				    .die_weight < p_current->die_weight) {
				node->die_weights_real[type][p_current->die_seq]
					.die_weight = 0;
				VATOOLS_DBG(
					NULL, DUMMY_DIE_ID,
					"%s: node->die_weights_real below zero\n",
					__func__);
			} else {
				node->die_weights_real[type][p_current->die_seq]
					.die_weight -= p_current->die_weight;
			}
			VATOOLS_DBG(
				NULL, DUMMY_DIE_ID,
				"%s: thread down,  seq %u, reclaim %u, real to %u\n",
				__func__, p_current->die_seq,
				p_current->die_weight,
				node->die_weights_real[type][p_current->die_seq]
					.die_weight);
		}
		mutex_unlock(&sharedmem_weight_mutex);
		delete_from_addr_check_list((uint64_t)p_current,
					    DELETE_ENTRY_FROM_RELEASEEMEM);

		kvfree(p_current->p_buf);
		kvfree(p_current);
	}
	mutex_unlock(&reader->sharedmem_mutex);
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "complete( &reader->debug_comp )\n");
	/*Release resource -- the data corresponding to the resource*/
	/*Resources are released, flag bit receipt*/
	reader->n_sharedmem_init_done = VATOOLS_UNINIT;
	/*Notification is only required when a process with 0 exits*/
	if (0 == reader->exit) {
		/*pr_info( "sharedmen_free_buf ptr=%p\n", reader );*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_lock(&reader->node->node_reader_mutex);
#endif
		reader_other = sharedmem_get_other_reader(reader);
		if (NULL != reader_other) {
			/*pr_info( "sharedmen_free_buf reader_other=%p\n", reader_other );*/
			reader_other->exit = 1;
			sharemen_set_comp_complete(reader_other);
			/*reinit_completion( &( reader_other->debug_comp ) );*/
		}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_unlock(&reader->node->node_reader_mutex);
#endif
	}

	/*
	list_for_each_entry_safe( p_current, p_tmp, &reader->t_sharedmem_signal_info_head, t_sharedmem_node )
	{
	   VATOOLS_DBG( "list_for_each_entry_safe.t_sharedmem_signal_info_head " );
	   kvfree( p_current->p_buf );
	   list_del( &p_current->t_sharedmem_node );
	   kvfree( p_current );
	}
	*/
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end .\n");
	return 0;
}

static void recal_video_capability(struct vatools_node *node,
				   struct vatools_reader *reader)
{
	u8 flag = reader->own_dies.flag_encode_or_decode;

	if (flag >= ALLOC_VIDEO_MAX) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s: unknown tye, flag %u\n",
			     __func__, flag);
		return;
	}

	mutex_lock(&sharedmem_weight_mutex);
	if (node->die_weights[flag][reader->own_dies.die_seq].die_weight <
	    reader->own_dies.die_weight) {
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"%s: seq %u collect %u, to %u, type %u, below zero\n",
			__func__, reader->own_dies.die_seq,
			reader->own_dies.die_weight,
			node->die_weights[flag][reader->own_dies.die_seq]
				.die_weight,
			flag);
		node->die_weights[flag][reader->own_dies.die_seq].die_weight =
			0;
	} else {
		node->die_weights[flag][reader->own_dies.die_seq].die_weight -=
			reader->own_dies.die_weight;
	}

	if (reader->own_dies.die_weight)
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "%s: seq %u collect %u, to %u, type %u\n", __func__,
			    reader->own_dies.die_seq,
			    reader->own_dies.die_weight,
			    node->die_weights[flag][reader->own_dies.die_seq]
				    .die_weight,
			    flag);

	mutex_unlock(&sharedmem_weight_mutex);
}

int sharedmem_release(struct inode *inode, struct file *filp)
{
	struct vatools_node *p_dev = NULL;
	struct vatools_reader *reader = NULL;

	V_UNREFERENCE(inode);
	p_dev = vatools_file_get_node(filp);
	if (!p_dev) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "private_data is null.\n");
		return -ENOMEM;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "mutex_lock begin.\n");
	/*mutex_lock( &p_dev->node_sharedmem_mutex );*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_lock(&p_dev->node_sharedmem_mutex);
#endif
	reader = vatools_file_get_reader(filp);
	if (reader) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "begin.\n");
		/*pr_info( "sharedmem_release reader=%p\n", reader );*/
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_lock(&p_dev->node_reader_mutex);
#endif
		recal_video_capability(p_dev, reader);
		list_del(&reader->list_readers);
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
		mutex_unlock(&p_dev->node_reader_mutex);
#endif
		/*p_dev = container_of(inode->i_cdev, struct vatools_node, t_cdev);*/
		sharedmen_free_buf(reader);
		kvfree(reader);
		filp->private_data = NULL;
	} else {
		/*pr_info( "sharedmem_release  is null " );*/
	}
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	mutex_unlock(&p_dev->node_sharedmem_mutex);
#endif
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "mutex_lock end.\n");
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end.\n");
	/*pr_info( "sharedmem_release than " );*/
	return 0;
}

ssize_t sharedmem_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);

	return 0;
}

int sharedmem_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);

	return 0;
}

int sharedmem_set_app_category(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg)
{
	struct vatools_node *p_dev = NULL;
	struct vatools_reader *reader = NULL;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "VATOOLS_APP_SHAREDMEM  cmd=0x%x\n",
		    cmd);

	V_UNREFERENCE(cmd);
	V_UNREFERENCE(arg);
	p_dev = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	/*mutex_lock( &p_dev->node_sharedmem_mutex );*/
	/*TODO: The detection cannot be initialized repeatedly.*/
	if (reader->n_sharedmem_init_done != VATOOLS_INIT_DONE) {
		/*TODO: reader is already enabled, there is no need to start anonymous_dev here.*/
		INIT_LIST_HEAD(&reader->t_sharedmem_mem_info_head);
		/*INIT_LIST_HEAD( &reader->t_sharedmem_signal_info_head );*/
		mutex_init(&reader->sharedmem_mutex);
		/*Primitive signal lupa 2021-12-15 add*/
		init_completion(&reader->debug_comp);
		/*mutex_lock( &p_dev->sharedmem_mutex );*/
		/*list_add_tail( &anonymous_dev->list_nodes, vatools_get_vastai_head() );*/
		/*mutex_unlock( &p_dev->sharedmem_mutex );*/
		/*filp->private_data = anonymous_dev;*/
		/*reader->node = anonymous_dev;*/
		reader->n_sharedmem_init_done = VATOOLS_INIT_DONE;
		reader->exit = 0;

		reader->filter.filter_info.version =
			(SHAREMEM_VERSION_SV100 << SHAREMEM_VERSION_OFFSET) |
			SHAREMEM_VERSION_INITIAL;
		reader->filter.filter_info.head.nDieID = 0x55AA55AA;
		reader->filter.filter_info.head.nDeviceID = 0x55AA55AA;
		reader->filter.filter_info.vpid = task_tgid_vnr(current);
		reader->filter.filter_info.tid = task_tgid_nr(current);
		reader->filter.filter_info.ns =
			(u64)task_active_pid_ns(current);
		reader->filter.filter_info.level =
			(u32)task_active_pid_ns(current)->level;

		VATOOLS_DBG(NULL, DUMMY_DIE_ID, "vpid %d, ns %lld, level %d\n",
			    reader->filter.filter_info.vpid,
			    reader->filter.filter_info.ns,
			    reader->filter.filter_info.level);
	}
	/*mutex_unlock( &p_dev->node_sharedmem_mutex );*/
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "end\n");
	return 0;
}
