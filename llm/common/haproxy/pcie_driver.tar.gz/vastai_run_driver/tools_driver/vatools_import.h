﻿#ifndef __VATOOLS_IMPORT_H__
#define __VATOOLS_IMPORT_H__

/*import not define in this driver code*/
#ifdef VA_DRIVER_SG100

struct vastai_dev_info {
	int dev_id;
	u64 unid;
	char pcie_slot[16]; /*0000:01:00.00*/
	char pcie_dev_name[16]; /*kchar:0*/
	char device_name[16]; /*sv100*/

	union pci_id_u {
		u32 val;
		struct {
			u16 vender_id;
			u16 device_id;
		};
	} pci_id;

	union pci_sub_id_u {
		u32 val;
		struct {
			u16 sub_vender_id;
			u16 sub_device_id;
		};
	} pci_sub_id;

	union major_minor_uu {
		u32 val;
		struct {
			u16 minor;
			u16 major;
		};
	} major_minor;

	struct ai_video_cap_u {
		int ai_cap;
		int video_cap;
	} cap;

	int die_num;
	struct vastai_die_info_s {
		union die_index_data die_index;
		char vacc_name[16]; /*vacc0*/
		char render_name[16]; /*render129*/
	} die_info[4];
};

#endif

#ifdef VA_DRIVER_SV100

#endif

#endif /*__VATOOLS_IMPORT_H__*/
