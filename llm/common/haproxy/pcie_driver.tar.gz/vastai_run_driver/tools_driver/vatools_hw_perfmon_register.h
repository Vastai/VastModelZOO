﻿
#ifndef __VATOOLS_HW_PERFMON_REGISTER_H__
#define __VATOOLS_HW_PERFMON_REGISTER_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

#define csr_mc0_axi_w_r_ostd	       0x380058
#define csr_mc0_axi_aw_ar_cmd	       0x38005C
#define csr_mc0_axi_aw_ar_band	       0x380060
#define csr_mc0_axi_ar_id01_latency_rp 0x380064
#define csr_mc0_axi_ar_id23_latency_rp 0x380068
/******************** Field ************************
 * axiyall_enable      0:1;
 * axi0_enable         1:2;
 * axi1_enable         2:3;
 * axi2_enable         3:4;
 * axi3_enable         4:5;
 * axi4_enable         5:6;
 * axi0_clr            6:7;
 * axi1_clr            7:8;
 * axi2_clr            8:9;
 * axi3_clr            9:10;
 * axi4_clr            10:11;
 * cnt_mode            11:12;
 * report_mode         12:20
 ***************************************************/
#define csr_mc0_axi_enable_clr_mode    0x38006C
#define csr_mc1_axi_w_r_ostd	       0x480058
#define csr_mc1_axi_aw_ar_cmd	       0x48005C
#define csr_mc1_axi_aw_ar_band	       0x480060
#define csr_mc1_axi_ar_id01_latency_rp 0x480064
#define csr_mc1_axi_ar_id23_latency_rp 0x480068
/******************** Field ************************
 * axiyall_enable      0:1;
 * axi0_enable         1:2;
 * axi1_enable         2:3;
 * axi2_enable         3:4;
 * axi3_enable         4:5;
 * axi4_enable         5:6;
 * axi0_clr            6:7;
 * axi1_clr            7:8;
 * axi2_clr            8:9;
 * axi3_clr            9:10;
 * axi4_clr            10:11;
 * cnt_mode            11:12;
 * report_mode         12:20
 ***************************************************/
#define csr_mc1_axi_enable_clr_mode    0x48006C
#define csr_mc2_axi_w_r_ostd	       0x580058
#define csr_mc2_axi_aw_ar_cmd	       0x58005C
#define csr_mc2_axi_aw_ar_band	       0x580060
#define csr_mc2_axi_ar_id01_latency_rp 0x580064
#define csr_mc2_axi_ar_id23_latency_rp 0x580068
/******************** Field ************************
 * axiyall_enable      0:1;
 * axi0_enable         1:2;
 * axi1_enable         2:3;
 * axi2_enable         3:4;
 * axi3_enable         4:5;
 * axi4_enable         5:6;
 * axi0_clr            6:7;
 * axi1_clr            7:8;
 * axi2_clr            8:9;
 * axi3_clr            9:10;
 * axi4_clr            10:11;
 * cnt_mode            11:12;
 * report_mode         12:20
 ***************************************************/
#define csr_mc2_axi_enable_clr_mode    0x58006C
#define csr_mc3_axi_w_r_ostd	       0x680058
#define csr_mc3_axi_aw_ar_cmd	       0x68005C
#define csr_mc3_axi_aw_ar_band	       0x680060
#define csr_mc3_axi_ar_id01_latency_rp 0x680064
#define csr_mc3_axi_ar_id23_latency_rp 0x680068
/******************** Field ************************
 * axiyall_enable      0:1;
 * axi0_enable         1:2;
 * axi1_enable         2:3;
 * axi2_enable         3:4;
 * axi3_enable         4:5;
 * axi4_enable         5:6;
 * axi0_clr            6:7;
 * axi1_clr            7:8;
 * axi2_clr            8:9;
 * axi3_clr            9:10;
 * axi4_clr            10:11;
 * cnt_mode            11:12;
 * report_mode         12:20
 ***************************************************/
#define csr_mc3_axi_enable_clr_mode 0x68006C
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak0_perfmon_en 0x700058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak0_perfmon_sel   0x70005C
#define csr_oak0_perfmon_timer 0x700060
#define csr_oak0_perfmon_data0 0x700064
#define csr_oak0_perfmon_data1 0x700068
#define csr_oak0_perfmon_data2 0x70006C
#define csr_oak0_perfmon_data3 0x700070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak1_perfmon_en 0x800058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak1_perfmon_sel   0x80005C
#define csr_oak1_perfmon_timer 0x800060
#define csr_oak1_perfmon_data0 0x800064
#define csr_oak1_perfmon_data1 0x800068
#define csr_oak1_perfmon_data2 0x80006C
#define csr_oak1_perfmon_data3 0x800070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak2_perfmon_en 0x900058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak2_perfmon_sel   0x90005C
#define csr_oak2_perfmon_timer 0x900060
#define csr_oak2_perfmon_data0 0x900064
#define csr_oak2_perfmon_data1 0x900068
#define csr_oak2_perfmon_data2 0x90006C
#define csr_oak2_perfmon_data3 0x900070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak3_perfmon_en 0xA00058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak3_perfmon_sel   0xA0005C
#define csr_oak3_perfmon_timer 0xA00060
#define csr_oak3_perfmon_data0 0xA00064
#define csr_oak3_perfmon_data1 0xA00068
#define csr_oak3_perfmon_data2 0xA0006C
#define csr_oak3_perfmon_data3 0xA00070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak4_perfmon_en 0xB00058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak4_perfmon_sel   0xB0005C
#define csr_oak4_perfmon_timer 0xB00060
#define csr_oak4_perfmon_data0 0xB00064
#define csr_oak4_perfmon_data1 0xB00068
#define csr_oak4_perfmon_data2 0xB0006C
#define csr_oak4_perfmon_data3 0xB00070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak5_perfmon_en 0xC00058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak5_perfmon_sel   0xC0005C
#define csr_oak5_perfmon_timer 0xC00060
#define csr_oak5_perfmon_data0 0xC00064
#define csr_oak5_perfmon_data1 0xC00068
#define csr_oak5_perfmon_data2 0xC0006C
#define csr_oak5_perfmon_data3 0xC00070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak6_perfmon_en 0xD00058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak6_perfmon_sel   0xD0005C
#define csr_oak6_perfmon_timer 0xD00060
#define csr_oak6_perfmon_data0 0xD00064
#define csr_oak6_perfmon_data1 0xD00068
#define csr_oak6_perfmon_data2 0xD0006C
#define csr_oak6_perfmon_data3 0xD00070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_oak7_perfmon_en 0xE00058
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_oak7_perfmon_sel   0xE0005C
#define csr_oak7_perfmon_timer 0xE00060
#define csr_oak7_perfmon_data0 0xE00064
#define csr_oak7_perfmon_data1 0xE00068
#define csr_oak7_perfmon_data2 0xE0006C
#define csr_oak7_perfmon_data3 0xE00070
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_odma0_perfmon_en 0xF002D0
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_odma0_perfmon_sel	0xF002D4
#define csr_odma0_perfmon_timer 0xF002D8
#define csr_odma0_perfmon_data0 0xF002DC
#define csr_odma0_perfmon_data1 0xF002E0
#define csr_odma0_perfmon_data2 0xF002E4
#define csr_odma0_perfmon_data3 0xF002E8
/******************** Field ************************
 * en                  0:1;
 * start               1:2;
 * stop                2:3;
 * spare0              3:4;
 * data_idx            4:16
 ***************************************************/
#define csr_odma1_perfmon_en 0x10002D0
/******************** Field ************************
 * sel0                0:8;
 * sel1                8:16;
 * sel2                16:24;
 * sel3                24:32
 ***************************************************/
#define csr_odma1_perfmon_sel	0x10002D4
#define csr_odma1_perfmon_timer 0x10002D8
#define csr_odma1_perfmon_data0 0x10002DC
#define csr_odma1_perfmon_data1 0x10002E0
#define csr_odma1_perfmon_data2 0x10002E4
#define csr_odma1_perfmon_data3 0x10002E8

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_HW_PERFMON_REGISTER_H__*/
