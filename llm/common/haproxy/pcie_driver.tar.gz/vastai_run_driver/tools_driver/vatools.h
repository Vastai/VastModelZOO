﻿#ifndef __VATOOLS_H__
#define __VATOOLS_H__

/*chip driver dependant*/
#define VA_DRIVER_SV100
#undef VA_DRIVER_SG100

#ifdef VA_DRIVER_SG100
#else
#endif

/*0: on linux 1: on windows*/
#undef TOOLS_WIN
#define TOOLS_WIN 0

#if (TOOLS_WIN == 1)
/*on windows*/

#include "img_hal.h"
#include "vlinux_wait_queue.h"
#include "vlog.h"
#include "vastai_device.h"
#include "vlinux_hal.h"
#include "vlinux.h"
#include "vcommon.h"
#include "../video_driver/enc_drv/vastai_enc.h"
#include "common_cus/video_driver/common/vastai_render.h"
#include "common_cus/ai_driver/vastai_ai.h"
#include "vastai_fifo.h"
#include "vastai_pci_test.h"
#include "vastai_pci_boot.h"
#include "vastai_pci_dbg.h"
#include "vastai_export_api.h"

#include "vatools_types.h"
#include "vatools_smi_cmd.h"
#include "vatools_define.h"
#include "vatools_common.h"
#include "vatools_driver.h"
#include "vatools_debugger.h"
#include "vatools_profiler.h"
#include "vatools_logger.h"
#include "vatools_smi.h"
#include "vatools_sharedmem.h"
#include "vatools_dummy.h"
#include "vatools_hw_perfmon_register.h"

#pragma pack(push)
#pragma pack(1)
#pragma pack(pop)

#else
/*platform*/
/*on linux*/

#include <linux/aio.h>
#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/ktime.h>
#include <linux/list.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/poll.h>
#include <linux/printk.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <linux/time64.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/uio.h>
#include <linux/vmalloc.h>
#include <uapi/linux/time.h>
#include <linux/ctype.h>
#include <linux/platform_device.h>
#include <linux/version.h>
#include <linux/random.h>
#include <linux/dma-buf.h>
#include <linux/errno.h>
#include <linux/init.h>
#include <linux/rtc.h>
#include <linux/cdev.h>
#include <linux/wait.h>
#include <linux/compat.h>
#include <linux/thread_info.h>
#include <linux/pid_namespace.h>
#include <linux/pid.h>

#ifdef VA_DRIVER_SG100

#else
#include "vastai_export_api.h"
#include "vastai_pci_api.h"
#include "vastai_pci_dbg.h"
#include "vastai_pci_test.h"
#include "vastai_pci_boot.h"
#include "vastai_sv100_reg.h"
#include "vastai_fifo.h"
#include "vastai_pci.h"
#include "vastai_udma_engine.h"
#include "vastai_fifo.h"
#include "vastai_dev.h"
#include "../gfx/gfx_drv.h"
#include "sg100_cmd.h"
#include "hw_config.h"
#include "vastai_trans_layer.h"
#include "vastai_ras.h"

#ifdef CONFIG_VASTAI_VIDEO
#include "vastai_render.h"
#include "vastai_enc.h"
#endif
#if (defined CONFIG_VASTAI_AI) || (defined CONFIG_VASTAI_KUNIT)
#include "vastai_ai.h"
#include "vastai_common.h"
#endif
#endif

/*for list all pci_info when hotplug enabled*/
extern struct list_head vastai_pci_info_list; /*export from vastai_pci_basic*/
extern struct list_head vastai_tools_devs_list; /*export from vastai_pci_basic*/
extern struct rw_semaphore tools_devs_rw_sem;

#include "vatools_types.h"
#include "vatools_import.h"
#include "vatools_smi_cmd.h"
#include "vatools_define.h"
#include "vatools_ras.h"
#include "vatools_common.h"
#include "vatools_driver.h"
#include "vatools_debugger.h"
#include "vatools_profiler.h"
#include "vatools_logger.h"
#include "vatools_smi.h"
#include "vatools_sharedmem.h"
#include "vatools_dummy.h"
#include "vatools_hw_perfmon_register.h"
#pragma pack(push)
#pragma pack(1)
#pragma pack(pop)
#endif /*end of platfrom*/

#endif /*__VATOOLS_H__*/
