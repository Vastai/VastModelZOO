﻿#ifndef __VATOOLS_COMMON_H__
#define __VATOOLS_COMMON_H__
#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

extern vatools_bar_address_t vatools_die_check[4][2];

#define VATOOLS_BAR_SMI_MAX_BYTES (SMI_CMD_BLOCK0_LEN)

int vatools_get_vastai_die_info_via_device_id(char dev_id, int die_index[],
					      int *die_num);
u32 vatools_get_vastai_pci_die_index(char dev_id, int die_id);
T_SMI_BLOCK *vatools_fw_smi_get_block(struct vastai_pci_info *priv,
				      unsigned int block_id);
T_SMI_BLOCK *
vatools_fw_smi_get_block_via_app_category(unsigned int app_category,
					  struct vastai_pci_info *priv);
int vatools_get_vastai_pci_device_number(void);
struct vastai_pci_info *vatools_get_vastai_pci_device_info(char dev_id);
struct list_head *vatools_get_vastai_head(void);
int vatools_pci_mem_fread(struct vastai_pci_info *priv, int die_index,
			  u64 relative_addr, void *buf, unsigned int len);
int vatools_pci_mem_fwrite(struct vastai_pci_info *priv, int die_index,
			   u64 relative_addr, const void *buf,
			   unsigned int len);
int vatools_pci_mem_read(struct vastai_pci_info *priv, int die_index,
			 u64 relative_addr, void *buf, unsigned int len);
int vatools_pci_mem_write(struct vastai_pci_info *priv, int die_index,
			  u64 relative_addr, const void *buf, unsigned int len);
struct vatools_node *vatools_file_get_node(struct file *filp);
struct vatools_reader *vatools_file_get_reader(struct file *filp);
long vatools_driver_smi_fetch(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg);
int vatools_fw_smcu_read(u32 block_id, struct vastai_pci_info *priv,
			 int die_index, u64 relative_addr, void *buf,
			 unsigned int len);
int vatools_fw_smcu_write(u32 block_id, struct vastai_pci_info *priv,
			  int die_index, u64 relative_addr, const void *buf,
			  unsigned int len);
int vatools_ioctl_dma_alloc(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
int vatools_ioctl_dma_free(struct file *filp, unsigned int cmd,
			   IOCTL_ARG_T arg);
int vatools_ioctl_dma_start(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
int vatools_ioctl_dma_trans(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
int vatools_ioctl_read_reg_buf(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg);
int vatools_ioctl_write_reg_buf(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg);
int vatools_send_ctrl_cmd(struct vastai_pci_info *pci_info, u32 die_index,
			  u32 core_bit_map, u64 info);
int vatools_ioctl_core_time_sync(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg);
void vatools_get_current_time(struct rtc_time *tm);
int vatools_ioctl_get_bmcu_xspi_ver(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg);
int vatools_ioctl_get_sriov_number(struct file *filp, unsigned int cmd,
				   IOCTL_ARG_T arg);
int vatools_ioctl_flash_bmcu_fw(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg);
int vatools_ioctl_flash_xspi_fw(struct file *filp, unsigned int cmd,
				IOCTL_ARG_T arg);
int vatools_ioctl_flash_sta(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
int vatools_ioctl_bmcu_switch(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg);
int vatools_ioctl_device_event(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg);
int vatools_ioctl_device_event_select(struct file *filp, unsigned int cmd,
				      IOCTL_ARG_T arg);
struct vatools_node *vatools_get_node(void);
int vatools_fw_send_smi_interrupt(struct vastai_pci_info *priv, int die_index);
int vatools_wait_smi_ack(struct vastai_pci_info *priv, u32 die_index,
			 u32 block_id, int from, char *bak_buf,
			 int bak_buf_len);
int vatools_fw_send_interrupt(struct vastai_pci_info *priv, int die_index,
			      u32 type);
int vatools_dump_smi_block_mem(struct vastai_pci_info *priv, int die_index,
			       u32 block_id, u32 len, int from, char *bak_buf,
			       int bak_buf_len);
void vatools_driver_smi_set_flag(u8 *buf, u32 size, u8 flag);
#ifdef CONFIG_TOOLS_V2
struct vastai_pci_info *
vatools_get_vastai_pci_device_info_by_die_index(u32 die_index);
int vatools_get_spi_buf(u32 die_index, u32 unit, u64 address, u32 len,
			void *spi_buf);
#endif
u32 vatools_fifo_iterate(struct vastai_fifo *fifo, u32 index);
int vatools_event_wait_queue_condition_func(u64 local_timestamp_ns);
typedef int (*set_desc_func)(struct vastai_dmadesc *, struct dma_buf *,
			     struct kchar_cmd *, int, u32, u32,
			     struct vastai_pci_info *);
int vastai_common_cut_dma_buf(u32 size, struct kchar_cmd *kcmd,
			      struct vastai_dmadesc *desc,
			      struct vastai_pci_info *pci_info,
			      struct dma_buf *dmabuf,
			      set_desc_func pSetDescFunc);
int vastai_ioctl_dma_start_set_desc(struct vastai_dmadesc *desc,
				    struct dma_buf *dmabuf,
				    struct kchar_cmd *kcmd, int i,
				    u32 done_size, u32 temp_size,
				    struct vastai_pci_info *pci_info);
int vastai_ioctl_dma_trans_set_desc(struct vastai_dmadesc *desc,
				    struct dma_buf *dmabuf,
				    struct kchar_cmd *kcmd, int i,
				    u32 done_size, u32 temp_size,
				    struct vastai_pci_info *pci_info);
int vatools_pci_mem_read_direct(struct vastai_pci_info *priv, int die_index,
				u64 relative_addr, void *buf, unsigned int len);
int vatools_pci_mem_write_direct(struct vastai_pci_info *priv, int die_index,
				 u64 relative_addr, const void *buf,
				 unsigned int len);
int vatools_pci_flash_xspi(struct vastai_pci_info *priv, u32 die_id,
			   struct char_drv_info *dev, u8 partition);
int vatools_pci_flash_xspi_bin(struct vastai_pci_info *priv, u32 die_id,
			       u8 *path_name, const void *bin_buf,
			       size_t buf_size, u8 partition, u8 *mode);
int vatools_pci_flash_xspi_fw(struct vastai_pci_info *priv, u32 die_id,
			      u8 *path_name, const void *bin_buf,
			      size_t buf_size, u8 partition);
int vatools_pci_flash_bmcu(struct vastai_pci_info *priv, u32 die_id);
int vatools_pci_flash_bmcu_bin(struct vastai_pci_info *priv, u32 die_id,
			       u8 *path_name, const void *bin_buf,
			       size_t buf_size);
int vatools_pci_update_flag_xspi(struct vastai_pci_info *priv, u32 die_id,
				 u8 partition, u8 mode);
int vatools_pci_set_flash_wp(struct vastai_pci_info *priv, u32 die_id,
			     struct char_drv_info *dev, u32 cfg);
int vatools_pci_read_xspi(struct vastai_pci_info *priv, u32 die_id,
			  unsigned long addr, void *buf, u32 len, u8 partition);
int vatools_pci_get_sriov_numvfs(char dev_id);
int vatools_send_pcie_cmd_paras(struct vastai_pci_info *priv, u32 die_index,
				u32 sub_cmd, u64 paras);
#ifdef CONFIG_TOOLS_V2
int vatools_api_setfreq(struct vastai_pci_info *priv, unsigned int freq_unit,
			unsigned int freq_value);
int vatools_api_getfreq(struct vastai_pci_info *priv, unsigned int freq_unit,
			unsigned int *freq_value);
#endif
int vatools_get_current_process_info(
	vatools_current_process_info_t *current_process_info);
int vatools_gfx_interface(struct vastai_pci_info *priv, u32 cmd,
			  u64 cmd_args_addr, u32 cmd_args_size, u64 info_addr,
			  u32 info_size);
int vatools_device_event_callback(u32 die_index, u32 core_bit, u32 event);
void vatools_print_buffer_hex(const char *prefix_str, void *pBuff,
			      unsigned int nLen);
int vatools_pci_tl_read(struct vastai_pci_info *priv, unsigned int die_id,
			u64 dev_addr, void *data, size_t size);
unsigned int vatools_murmur_hash32(const void *key, int len, unsigned int seed);
bool vatools_check_pci_state(struct vastai_pci_info *priv, ...);
int vatools_flash_support_update_background(struct vastai_pci_info *priv,
					    u32 flash_type);
int vatools_ioctl_fnread_reg_buf(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg); /*call fread*/
int vatools_ioctl_fnwrite_reg_buf(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg); /*call fwrite*/
char *vatools_log_brief_filename(const char *in_fliename, const char *in_func,
				 char *out_filename);
board_type_e vatools_get_board_type(struct vastai_pci_info *priv);
u16 vatools_get_smi_seq(void);

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_COMMON_H__*/
