﻿#include "vatools.h"
#include "vatools_log.h"

/*runtime implements the dynamic switch DLC function. When the DLC is turned off, the data cannot be read through perfmon.*/
/*It will be because of the access to an unknown address hang. Comment the following code for the time being, do not read DLC and ODMA*/
#define VATOOLS_PROFILER_DLC_ODMA (0)

/*Use global variables to identify whether to enable profiler and fifo addresses*/
unsigned int profiler_timeline_enable = 0;
void *gp_profiler_dma_fifo = NULL;
void *gp_profiler_msg_fifo = NULL;
void *gp_profiler_app_fifo = NULL;
struct mutex pcie_timeline_dma_mutex;
struct mutex pcie_timeline_msg_mutex;
struct mutex pcie_timeline_app_mutex;
static unsigned int app_section_sn = 0;

/*Read PCIe DMA performance data, function execution is frequent, the execution time is required to be as short as possible, and it cannot be blocked*/
void vatools_profiler_dma_checkpoint(
	struct s_profiler_dma_checkpoint *dma_section)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_dma_fifo;
	u8 *fifo_p = NULL;
	int locked;

	/*TODO: If timeline data collection is not enabled, return directly*/
	if (!profiler_timeline_enable) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "profiler pcie timeline is disable\n");
		return;
	}

	dma_section->version = PROFILER_DMA_VERSION;
	dma_section->pid = task_tgid_nr(current);

	/*debug*/
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"dma_checkpoint[%d]: %u %u %u | pid=%lld |%llu %u %u | %llu %llu %u %u %llu\n",
		profiler_timeline_enable, dma_section->dev_id,
		dma_section->die_id, dma_section->die_index, dma_section->pid,
		dma_section->dma_axi_addr, dma_section->dma_data_size,
		dma_section->dma_dir, dma_section->time_of_driver_recv_dma_req,
		dma_section->time_of_host_trigger_dma,
		dma_section->time_of_dma_run, dma_section->time_of_dma_finish,
		dma_section->time_of_driver_notify_host_dma_done);

	if (fifo == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "dma fifo is NULL\n");
		return;
	}

	/*if(vastai_fifo_is_full(fifo) || !vastai_is_fifo_valid(fifo)) {*/
	if (!vastai_is_fifo_valid(fifo)) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "dma fifo is not valid\n");
		return;
	}

	if (vastai_fifo_is_full(fifo)) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "dma fifo is full\n");
		locked = mutex_trylock(&pcie_timeline_dma_mutex);
		if (!locked) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "dma trylock fail=%d\n",
				    locked);
			return;
		}
	}

	fifo_p = (u8 *)fifo + vastai_fifo_wr_next(fifo);
	memcpy(fifo_p, dma_section, fifo->elem_size);
	mutex_unlock(&pcie_timeline_dma_mutex);
#else
	V_UNREFERENCE(dma_section);
#endif
	return;
}

/*empty dma buffer*/
static void vatools_profiler_dma_checkpoint_clear(void)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_dma_fifo;
	mutex_trylock(
		&pcie_timeline_dma_mutex); /*TODO: change mutex_trylock to mutex_lock*/
	fifo->rd = 0;
	fifo->wr = 0;
	memset(fifo->buf, 0, fifo->elem_count * fifo->elem_size);
	mutex_unlock(&pcie_timeline_dma_mutex);
#endif
}

/*Read PCIe MSG performance data, function execution is frequent, and the execution time is required to be as short as possible, and it cannot be blocked*/
void vatools_profiler_msg_checkpoint(
	struct s_profiler_msg_checkpoint *msg_section)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_msg_fifo;
	u8 *fifo_p = NULL;
	int locked;

	/*TODO: If timeline data collection is not enabled, return directly*/
	if (!profiler_timeline_enable) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "profiler pcie timeline is disable\n");
		return;
	}

	msg_section->version = PROFILER_MSG_VERSION;
	msg_section->pid = task_tgid_nr(current);

	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"msg_checkpoint[%d]: %u %u %u | pid=%lld |send=%llu recv=%llu\n",
		profiler_timeline_enable, msg_section->dev_id,
		msg_section->die_id, msg_section->die_index, msg_section->pid,
		msg_section->time_of_host_send_msg,
		msg_section->time_of_fw_recv_msg);

	if (fifo == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "msg fifo is NULL\n");
		return;
	}

	/*if(vastai_fifo_is_full(fifo) || !vastai_is_fifo_valid(fifo)) {*/
	if (!vastai_is_fifo_valid(fifo)) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "msg fifo is not valid\n");
		return;
	}
	if (vastai_fifo_is_full(fifo)) {
		locked = mutex_trylock(&pcie_timeline_msg_mutex);
		if (!locked) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "msg trylock fail=%d\n",
				    locked);
			return;
		}
	}

	fifo_p = (u8 *)fifo + vastai_fifo_wr_next(fifo);
	memcpy(fifo_p, msg_section, fifo->elem_size);
	mutex_unlock(&pcie_timeline_msg_mutex);
#else
	V_UNREFERENCE(msg_section);
#endif
	return;
}

/*empty msg buffer*/
static void vatools_profiler_msg_checkpoint_clear(void)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_msg_fifo;
	mutex_trylock(
		&pcie_timeline_msg_mutex); /*TODO: change mutex_trylock to mutex_lock*/
	fifo->rd = 0;
	fifo->wr = 0;
	memset(fifo->buf, 0, fifo->elem_count * fifo->elem_size);
	mutex_unlock(&pcie_timeline_msg_mutex);
#endif
}

/*Read app performance data, function execution is frequent, the execution time is required to be as short as possible, and it cannot be blocked*/
void vatools_profiler_app_checkpoint(
	struct s_profiler_app_checkpoint *app_section)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_app_fifo;
	u8 *fifo_p = NULL;
	int locked;

	/*TODO: If timeline data collection is not enabled, return directly*/
	if (!profiler_timeline_enable) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "profiler pcie timeline is disable\n");
		return;
	}

	/* Fill in the necessary data*/
	/*app_section->version = 0;*/
	app_section->pid = task_tgid_vnr(current);
	app_section->tid = 0;
	app_section->ns = (u64)task_active_pid_ns(current);
	app_section->level = (u32)task_active_pid_ns(current)->level;
	app_section->timestamp_ns = vastai_get_host_time_ns();
	app_section->sn = app_section_sn++;

	/*debug*/
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"app_checkpoint[%d]: %u 0x%x %u %u | %lld %llu %u | %llu | %u 0x%x 0x%x 0x%x 0x%x \n",
		profiler_timeline_enable, app_section->sn,
		app_section->die_index, app_section->file_node_id,
		app_section->subtype, app_section->pid, app_section->ns,
		app_section->level, app_section->timestamp_ns,
		app_section->json_str_len, app_section->info.data[0],
		app_section->info.data[1], app_section->info.data[2],
		app_section->info.data[3]);

	/*TODO: If timeline data collection is not enabled, return directly*/
	if (!profiler_timeline_enable) {
		VATOOLS_DBG(NULL, DUMMY_DIE_ID,
			    "profiler pcie timeline is disable\n");
		return;
	}

	if (fifo == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "app fifo is NULL\n");
		return;
	}

	/*if(vastai_fifo_is_full(fifo) || !vastai_is_fifo_valid(fifo)) {*/
	if (!vastai_is_fifo_valid(fifo)) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "app fifo is not valid\n");
		return;
	}

	if (vastai_fifo_is_full(fifo)) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "app fifo is full\n");
		locked = mutex_trylock(&pcie_timeline_app_mutex);
		if (!locked) {
			VATOOLS_DBG(NULL, DUMMY_DIE_ID, "app trylock fail=%d\n",
				    locked);
			return;
		}
	}

	fifo_p = (u8 *)fifo + vastai_fifo_wr_next(fifo);
	memcpy(fifo_p, app_section, fifo->elem_size);
	mutex_unlock(&pcie_timeline_app_mutex);
#else
	V_UNREFERENCE(app_section);
	V_UNREFERENCE(app_section_sn);
#endif
	return;
}

/*empty app buffer*/
static void vatools_profiler_app_checkpoint_clear(void)
{
#ifdef VATOOLS_PROFILER_ENABLE
	struct vastai_fifo *fifo = (struct vastai_fifo *)gp_profiler_app_fifo;
	mutex_trylock(
		&pcie_timeline_app_mutex); /*TODO: change mutex_trylock to mutex_lock*/
	fifo->rd = 0;
	fifo->wr = 0;
	memset(fifo->buf, 0, fifo->elem_count * fifo->elem_size);
	mutex_unlock(&pcie_timeline_app_mutex);
#endif
}

loff_t profiler_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);
	return -EPERM;
}

ssize_t profiler_read(struct file *filp, char __user *buf, size_t size,
		      loff_t *pos)
{
	/*struct vatools_node*    node        = vatools_file_get_node( filp );*/
	struct vatools_reader *reader = vatools_file_get_reader(filp);
	T_SMI_BLOCK *p_smi_block = NULL;
	ssize_t ret = 0;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	int device_id = 0;

	size_t length = 0;
	struct T_PERFMON_DATA data;

	/*read data from fw*/
	T_PERFMON_FW perf_buffer;
	int index = 0;
#if (VATOOLS_PROFILER_DLC_ODMA == 1)
	u64 odma_addr[MAX_ODMA_NUM] = { csr_odma0_perfmon_en,
					csr_odma1_perfmon_en };

	u64 oak_addr[MAX_DLC_NUM] = {
		csr_oak0_perfmon_en, csr_oak1_perfmon_en, csr_oak2_perfmon_en,
		csr_oak3_perfmon_en, csr_oak4_perfmon_en, csr_oak5_perfmon_en,
		csr_oak6_perfmon_en, csr_oak7_perfmon_en
	};
#endif

	u64 mc_addr[MAX_MC_NUM] = { csr_mc0_axi_w_r_ostd, csr_mc1_axi_w_r_ostd,
				    csr_mc2_axi_w_r_ostd,
				    csr_mc3_axi_w_r_ostd };
	T_PERFMON_MC_FW mc_buffer;

	V_UNREFERENCE(pos);
	VATOOLS_FUNC_ENTERY;

	memset(&data, 0x00, sizeof(struct T_PERFMON_DATA));
	memset(&perf_buffer, 0x00, sizeof(T_PERFMON_FW));
	memset(&mc_buffer, 0x00, sizeof(T_PERFMON_MC_FW));

	die_index = reader->trans_category.device.die_index;
	device_id = reader->trans_category.device.dev_id;

	VATOOLS_DBG(priv, die_index,
		    "app_category=%d  block_id=%d  device_id=%d  die_id=%d"
		    "die_index=0x%x\n",
		    reader->trans_category.app_category,
		    reader->trans_category.block_id,
		    reader->trans_category.device.dev_id,
		    reader->trans_category.device.die_id,
		    reader->trans_category.device.die_index);

	ret = 0;
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     reader->trans_category.device.dev_id);
		ret = -ENODEV;
		goto profiler_read_out;
	}
	p_smi_block = vatools_fw_smi_get_block_via_app_category(
		reader->trans_category.app_category, priv);
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
				    VASTAI_DEBUG_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto profiler_read_out;
	}

	length = min(size, sizeof(struct T_PERFMON_DATA));

	VATOOLS_DBG(priv, die_index,
		    "priv=0x%p, device_id=%d, die_index=0x%x\n", priv,
		    device_id, die_index);

	VATOOLS_DBG(priv, die_index,
		    "sizeof(T_PERFMON_DATA)=%ld, size=%ld, min length=%ld\n",
		    sizeof(struct T_PERFMON_DATA), size, length);
#if (VATOOLS_PROFILER_DLC_ODMA == 1)
	/*runtime implements the dynamic toggle DLC function. When the DLC is turned off, the data cannot be read through perfmon.*/
	/*It will be due to accessing an unknown address hang. Comment the following code for the time being, do not read DLC and ODMA*/

	/*ODM A0*/
	for (index = 0; index < sizeof(odma_addr) / sizeof(u64); index++) {
		memset(&perf_buffer, 0x00, sizeof(T_PERFMON_FW));
		ret = vatools_fw_smcu_read(p_smi_block->block_id, priv,
					   die_index, odma_addr[index],
					   &perf_buffer, sizeof(T_PERFMON_FW));
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "[odma index %d] ret=%ld\n", index, ret);
			goto profiler_read_out;
		}
		memcpy(&(data.tODMA[index]), &perf_buffer,
		       sizeof(T_PERFMON_FW));
	}

	/*oak*/
	for (index = 0; index < MAX_DLC_NUM; index++) {
		memset(&perf_buffer, 0x00, sizeof(T_PERFMON_FW));
		ret = vatools_fw_smcu_read(p_smi_block->block_id, priv,
					   die_index, oak_addr[index],
					   &perf_buffer, sizeof(T_PERFMON_FW));
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index,
				     "[oak index %d] ret=%ld\n", index, ret);
			goto profiler_read_out;
		}
		memcpy(&(data.tDLC[index]), &perf_buffer, sizeof(T_PERFMON_FW));
	}
#endif
	/*mc*/
	for (index = 0; index < MAX_MC_NUM; index++) {
		memset(&mc_buffer, 0x00, sizeof(T_PERFMON_MC_FW));
		ret = vatools_fw_smcu_read(p_smi_block->block_id, priv,
					   die_index, mc_addr[index],
					   &mc_buffer, sizeof(T_PERFMON_MC_FW));
		if (ret < 0) {
			VATOOLS_INFO(priv, die_index, "[mc index %d] ret=%ld\n",
				     index, ret);
			goto profiler_read_out;
		}
		memcpy(&(data.tMC[index]), &mc_buffer, sizeof(T_PERFMON_MC_FW));
	}

	VATOOLS_DUMP_BRIEF("profiler_read buffer: ", &data, length);

	if (copy_to_user_ex((void __user *)buf, &data, length)) {
		ret = -EFAULT;
		VATOOLS_ERR(priv, die_index, "ret=%ld\n", ret);
		goto profiler_read_out;
	}
	ret = length;

profiler_read_out:
	VATOOLS_DBG(priv, die_index, "ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;
	return ret;
}

ssize_t profiler_write(struct file *filp, const char __user *buf, size_t size,
		       loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);
	return -EPERM;
}

ssize_t profiler_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);
	return -EPERM;
}

unsigned int profiler_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);
	return -EPERM;
}

static long profiler_set_performance_csr(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg)
{
	/*struct vatools_node* node = vatools_file_get_node( filp );*/
	/*struct vatools_reader*  reader   = vatools_file_get_reader( filp );*/
	long ret = -EINVAL;
	struct vastai_pci_info *priv = NULL;
	void __user *argp = (void __user *)arg;
	int i = 0;
	u32 *kp_value = NULL;
	void *pk_buf = NULL;
	struct T_ADDR_VAL val = { 0 };
	u32 die_index = 0;

	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(priv, die_index, "cmd=0x%x\n", cmd);

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, (void __user *)argp, sizeof(kdata));
	if (ret) {
		VATOOLS_DBG(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index,
		    "block_id=%d  device_id=%d  die_id=%d  flag=0x%x  addr= "
		    "0x%llx\n",
		    kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		    kdata.flag, kdata.address);
	VATOOLS_DBG(
		priv, die_index,
		"read_len=%d  read_buf=0x%llx  write_len=%d  write_buf=0x%llx\n",
		kdata.output_buf.buf_size, kdata.output_buf.buf_addr,
		kdata.input_buf.buf_size, kdata.input_buf.buf_addr);

	priv = vatools_get_vastai_pci_device_info((char)kdata.device.dev_id);
	die_index = kdata.device.die_index;
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     kdata.device.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE,
				    VASTAI_DEBUG_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	ret = copy_from_user_ex(&val, (void __user *)kdata.input_buf.buf_addr,
				sizeof(struct T_ADDR_VAL));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out;
	}

	VATOOLS_DBG(priv, die_index,
		    "ret=%ld, addr=0x%llx, len=%d, val.pcBuf=0x%p\n", ret,
		    val.nAddr, val.nLen, val.pcBuf);

	pk_buf = kzalloc(val.nLen, GFP_KERNEL);
	if (pk_buf == NULL) {
		ret = -ENOMEM;
		VATOOLS_ERR(priv, die_index, "kzalloc ret=%ld\n", ret);
		goto out;
	}

	ret = copy_from_user_ex(pk_buf, (void __user *)val.pcBuf, val.nLen);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%ld\n",
			    ret);
		ret = -EFAULT;
		goto out_kfree;
	}

	kp_value = (u32 *)pk_buf;
	for (i = 0; i < val.nLen / sizeof(u32); i++) {
		u32 v = *(kp_value + i);
		u64 addr = (u64)(val.nAddr + i * 4);
/*VATOOLS_DBG(priv, die_index, "[%d] addr=0x%08llx, val=0x%08x\n",*/
/*	    i, addr, v);*/
#if (VATOOLS_PROFILER_DLC_ODMA == 0)
		/*TODO:*/
		/*runtime implements the dynamic toggle DLC function. When the DLC is turned off, the data cannot be read through perfmon.*/
		/*It will be due to accessing an unknown address hang. Temporarily filter addresses and do not access DLC and ODMA*/
		if (addr >= csr_mc0_axi_w_r_ostd &&
		    addr <= csr_mc3_axi_enable_clr_mode)
#endif
		{
			VATOOLS_DBG(priv, die_index,
				    "[%d] addr=0x%08llx, val=0x%08x\n", i, addr,
				    v);
			ret = vatools_fw_smcu_write(kdata.block_id, priv,
						    kdata.device.die_index,
						    addr, &v, sizeof(u32));
		}
	}

out_kfree:
	kvfree(pk_buf);
out:
	VATOOLS_DBG(priv, die_index, "out: ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

static int profiler_release_checkpoint(struct file *filp)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	struct vatools_node *p_current = NULL, *p_next = NULL;
	struct vastai_pci_info *priv = NULL;
	ring_buf_elem_t ring_buf_elem;
	u32 core_index = 0;
	u32 core_bitmap = 0;
	int can_release_checkpoint = 1;
	u32 die_index = 0;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	priv = vatools_get_vastai_pci_device_info(
		(char)reader->trans_category.device.dev_id);

	die_index = reader->trans_category.device.die_index;

	VATOOLS_DBG(
		priv, die_index,
		"filp=0x%p  node=0x%p  reader=0x%p  reader->profiler_checkpoint_corebitmap=0x%x\n",
		filp, node, reader, reader->profiler_checkpoint_corebitmap);

	/*disable profiler checkpoint*/
	/*TODO: For each open fd, if PROFILER_CHECKPOINT_MSG_START is called, the calculator increases. At the time of release, if the calculator is 0, it is released.*/
	if (reader->profiler_checkpoint_corebitmap != 0) {
		/*TODO: Cycle checking all dies, if die_index is the same and profiler_checkpoint_corebitmap has a value set, not 0,*/
		/* indicates that another program is using the profiler and cannot be released*/

		list_for_each_entry_safe (p_current, p_next,
					  vatools_get_vastai_head(),
					  list_nodes) {
			struct vatools_reader *p_current_reader = NULL,
					      *p_next_reader = NULL;

			for (core_index = 0; core_index < CORE_NUMBER;
			     core_index++) {
				can_release_checkpoint = 1;

				list_for_each_entry_safe (
					p_current_reader, p_next_reader,
					&p_current->list_node_readers,
					list_readers) {
					VATOOLS_DBG(
						priv, die_index,
						"p_current_reader=0x%p  p_current_node=0x%p\n",
						p_current_reader, p_current);
					VATOOLS_DBG(
						priv, die_index,
						"profiler_checkpoint_corebitmap=0x%x  category=%d dev=%d die=%d die_index=0x%x\n",
						p_current_reader
							->profiler_checkpoint_corebitmap,
						p_current_reader->trans_category
							.app_category,
						p_current_reader->trans_category
							.device.dev_id,
						p_current_reader->trans_category
							.device.die_id,
						p_current_reader->trans_category
							.device.die_index);

					if ((reader != p_current_reader) &&
					    (reader->trans_category
						     .app_category ==
					     p_current_reader->trans_category
						     .app_category) &&
					    (reader->trans_category.device
						     .dev_id ==
					     p_current_reader->trans_category
						     .device.dev_id) &&
					    (reader->trans_category.device
						     .die_id ==
					     p_current_reader->trans_category
						     .device.die_id) &&
					    (reader->trans_category.device
						     .die_index ==
					     p_current_reader->trans_category
						     .device.die_index)) {
						/*core_bitmap loop check*/
						if ((((p_current_reader
							       ->profiler_checkpoint_corebitmap >>
						       core_index) &
						      0x1))) {
							can_release_checkpoint =
								0;
							break;
						}
					}
				}
				VATOOLS_DBG(priv, die_index,
					    "can_release_checkpoint=0x%x\n",
					    can_release_checkpoint);
				if (can_release_checkpoint &&
				    (((reader->profiler_checkpoint_corebitmap >>
				       core_index) &
				      0x1))) {
					/*release checkpoint*/
					/*Send a message to core, stop profiler checkpoints*/
					memset(&ring_buf_elem, 0,
					       sizeof(ring_buf_elem));

					ring_buf_elem.whole = 0;
					ring_buf_elem.cmd =
						VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
					ring_buf_elem.use_ringbuf =
						VATOOLS_INTERRUPT_USE_RINGBUF;
					ring_buf_elem.seq_no = 0;
					ring_buf_elem.sub_cmd =
						VATOOLS_INTERRUPT_PROFILER_STOP_CMD;
					ring_buf_elem.val =
						PROFILER_CHECKPOINT_MSG_STOP;
					core_bitmap =
						(0x1 << (core_index)) &
						((0x1 << CORE_NUMBER) - 1);

					VATOOLS_DBG(
						priv, die_index,
						"release: die_index=0x%x, core_bitmap=0x%x ring_buf_elem.val=0x%x ring_buf_elem.whole=0x%llx\n",
						die_index, core_bitmap,
						PROFILER_CHECKPOINT_MSG_STOP,
						ring_buf_elem.whole);

/*Send interrupted to core*/
#ifdef VATOOLS_PROFILER_ENABLE
					ret = vatools_send_ctrl_cmd(
						priv, die_index, core_bitmap,
						ring_buf_elem.whole);
#else
					ret = -EINVAL;
#endif
					VATOOLS_DBG(
						priv, die_index,
						"release: send ctrl cmd PROFILER_CHECKPOINT_MSG_STOP to core_bitmap=0x%x return 0x%x\n",
						core_bitmap, ret);
					if (ret < 0 &&
					    ret != -ERESTARTSYS /*recive signal, do not log*/) {
						VATOOLS_INFO(
							priv, die_index,
							"release: send ctrl cmd PROFILER_CHECKPOINT_MSG_STOP failed. die_index=0x%x, core_bitmap=0x%x ring_buf_elem.val=0x%x ring_buf_elem.whole=0x%llx ret=%d\n",
							die_index, core_bitmap,
							PROFILER_CHECKPOINT_MSG_STOP,
							ring_buf_elem.whole,
							ret);
						/*goto out;*/
					}

					reader->profiler_checkpoint_corebitmap &=
						~(0x1 << core_index);
					VATOOLS_DBG(
						priv, die_index,
						"reader->profiler_checkpoint_corebitmap=0x%x\n",
						reader->profiler_checkpoint_corebitmap);
				}
			}
		}
	}
	/*out:*/
	reader->profiler_checkpoint_corebitmap = 0;
	VATOOLS_DBG(priv, die_index,
		    "reader->profiler_checkpoint_corebitmap=0x%x\n",
		    reader->profiler_checkpoint_corebitmap);
	VATOOLS_FUNC_EXIT;

	return 0;
}

static int profiler_ioctl_set(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret = 0;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;
	void __user *argp = (void __user *)arg;
	T_SMI_IOCTL_TRANS_DATA kdata = { 0 };
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	int ret2 = 0;
	ring_buf_elem_t ring_buf_elem;
	u32 core_bitmap = 0;
	u32 core_index = 0;

	V_UNREFERENCE(cmd);

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	VATOOLS_DBG(
		priv, die_index,
		"ioctl cmd=0x%x  filp=0x%p  node=0x%p  reader=0x%p core_bitmap=0x%x\n",
		cmd, filp, node, reader,
		reader->profiler_checkpoint_corebitmap);

	if (!node) {
		VATOOLS_INFO(priv, die_index, "node is NULL\n");
		ret = -EINVAL;
		goto out;
	}

	memset(&kdata, 0x00, sizeof(T_SMI_IOCTL_TRANS_DATA));
	ret = copy_from_user_ex(&kdata, (void __user *)argp, sizeof(kdata));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex ret=%d\n", ret);
		ret = -EFAULT;
		goto out;
	}

	core_index = (u32)(kdata.address & 0xFFFFFFFF);

	VATOOLS_DBG(
		priv, die_index,
		"block_id=0x%x  device_id=0x%x  die_id=0x%x  die_id=0x%x  flag=0x%x  addr= "
		"0x%llx\n",
		kdata.block_id, kdata.device.dev_id, kdata.device.die_id,
		kdata.device.die_index, kdata.flag, kdata.address);
	VATOOLS_DBG(priv, die_index,
		    "read_len=%d  read_buf=0x%llx  write_len=%d"
		    "write_buf=0x%llx\n",
		    kdata.output_buf.buf_size, kdata.output_buf.buf_addr,
		    kdata.input_buf.buf_size, kdata.input_buf.buf_addr);

	priv = vatools_get_vastai_pci_device_info((char)kdata.device.dev_id);
	die_index = kdata.device.die_index;
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     kdata.device.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

	die_index = vatools_get_vastai_pci_die_index((char)kdata.device.dev_id,
						     kdata.device.die_id);
	if (die_index < 0) {
		ret = -ENODEV;
		goto out;
	}

	switch (kdata.flag) {
	case PROFILER_CHECKPOINT_MSG_START: {
		VATOOLS_DBG(priv, die_index,
			    "PROFILER_CHECKPOINT_MSG_START: core_index=%d\n",
			    core_index);
		/*TODO: Indicates that the fd has the profiler checkpoints function enabled, and when the fd release is released, it needs to be checked, and the stop command is
		 * sent to fw.*/
		/*Disable this feature. Avoid affecting FW performance.*/

		/*TODO: Determine if coreindex is CORE_HOST_PCIE, enable the pcie timeline function,*/
		if (CORE_HOST_PCIE == core_index) {
			/*clear pcie buffer*/
			vatools_profiler_dma_checkpoint_clear();
			vatools_profiler_msg_checkpoint_clear();
			vatools_profiler_app_checkpoint_clear();
			profiler_timeline_enable = 1;
		} else {
			/*Send a message to core*/
			memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

			ring_buf_elem.whole = 0;
			ring_buf_elem.cmd =
				VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
			ring_buf_elem.use_ringbuf =
				VATOOLS_INTERRUPT_USE_RINGBUF;
			ring_buf_elem.seq_no = 0;
			ring_buf_elem.sub_cmd =
				VATOOLS_INTERRUPT_PROFILER_START_CMD;
			ring_buf_elem.val = kdata.flag;
			core_bitmap = (0x1 << (core_index)) &
				      ((0x1 << CORE_NUMBER) - 1);

			VATOOLS_DBG(
				priv, die_index,
				"START: die_index=0x%x, core_bitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
				kdata.device.die_index, core_bitmap, kdata.flag,
				ring_buf_elem.whole);

#ifdef VATOOLS_PROFILER_ENABLE
			/*Send interrupted to CMCU // 1 << CORE_CMCU,*/
			ret = vatools_send_ctrl_cmd(priv,
						    kdata.device.die_index,
						    core_bitmap,
						    ring_buf_elem.whole);
#else
			ret = -EINVAL;
#endif
			VATOOLS_DBG(priv, die_index,
				    "send ctrl cmd return 0x%x\n", ret);
			if (ret < 0) {
				VATOOLS_INFO(
					priv, die_index,
					"START: send ctrl cmd failed. die_index=0x%x, core_bitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx ret=%d\n",
					kdata.device.die_index, core_bitmap,
					kdata.flag, ring_buf_elem.whole, ret);
				goto out;
			}
			/*Record cores with Profiler checkpoint enabled, and use corebitmap records, one bit per core*/
			reader->profiler_checkpoint_corebitmap |= core_bitmap;
		}
	} break;

	case PROFILER_CHECKPOINT_MSG_STOP: {
		VATOOLS_DBG(priv, die_index,
			    "PROFILER_CHECKPOINT_MSG_STOP: core_index=%d\n",
			    core_index);
		/*TODO: Determine if coreindex is CORE_HOST_PCIE, enable the pcie timeline function,*/
		if (CORE_HOST_PCIE == core_index) {
			profiler_timeline_enable = 0;
			/*clear pcie buffer*/
			vatools_profiler_dma_checkpoint_clear();
			vatools_profiler_msg_checkpoint_clear();
			vatools_profiler_app_checkpoint_clear();
		} else {
			/*Only one core is released*/
			memset(&ring_buf_elem, 0, sizeof(ring_buf_elem));

			ring_buf_elem.whole = 0;
			ring_buf_elem.cmd =
				VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD;
			ring_buf_elem.use_ringbuf =
				VATOOLS_INTERRUPT_USE_RINGBUF;
			ring_buf_elem.seq_no = 0;
			ring_buf_elem.sub_cmd =
				VATOOLS_INTERRUPT_PROFILER_STOP_CMD;
			ring_buf_elem.val = kdata.flag;
			core_bitmap = (0x1 << (core_index)) &
				      ((0x1 << CORE_NUMBER) - 1);

			VATOOLS_DBG(
				priv, die_index,
				"STOP: die_index=0x%x, core_bitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx\n",
				kdata.device.die_index, core_bitmap, kdata.flag,
				ring_buf_elem.whole);

/*Send interrupted to core*/
#ifdef VATOOLS_PROFILER_ENABLE
			ret = vatools_send_ctrl_cmd(priv,
						    kdata.device.die_index,
						    core_bitmap,
						    ring_buf_elem.whole);
#else
			ret = -EINVAL;
#endif
			VATOOLS_DBG(
				priv, die_index,
				"STOP: send ctrl cmd PROFILER_CHECKPOINT_MSG_STOP to core_bitmap=0x%x return 0x%x\n",
				core_bitmap, ret);
			if (ret < 0) {
				VATOOLS_INFO(
					priv, die_index,
					"STOP: send ctrl cmd PROFILER_CHECKPOINT_MSG_STOP failed. die_index=0x%x, core_bitmap=0x%x kdata.flag=0x%x ring_buf_elem.whole=0x%llx ret=%d\n",
					kdata.device.die_index, core_bitmap,
					kdata.flag, ring_buf_elem.whole, ret);
				goto out;
			}
			/*Record cores with Profiler checkpoint enabled, and use corebitmap records, one bit per core*/
			reader->profiler_checkpoint_corebitmap &= ~core_bitmap;
		}

	} break;

	case PROFILER_CHECKPOINT_MSG_READ_RPWP: {
		void *temp_buf = NULL;
		if (kdata.output_buf.buf_size == 0) {
			ret = -EINVAL;
			VATOOLS_DBG(priv, die_index,
				    "[READ_RPWP] error. size=%d\n",
				    kdata.output_buf.buf_size);
			goto out;
		}
		temp_buf = (void *)vmalloc(kdata.output_buf.buf_size);
		if (!temp_buf) {
			VATOOLS_ERR(priv, die_index,
				    "[READ_RPWP] vmalloc error. size=%d\n",
				    kdata.output_buf.buf_size);
			ret = -ENOMEM;
			goto out;
		}

		VATOOLS_DBG(priv, die_index,
			    "[READ_RPWP] addr=0x%llx buf_size=%d\n",
			    kdata.address, kdata.output_buf.buf_size);

		ret = vastai_pci_mem_read(priv, die_index, kdata.address,
					  temp_buf, kdata.output_buf.buf_size);
		if (ret < 0) {
			ret = -EFAULT;
			VATOOLS_INFO(priv, die_index,
				     " vastai_pci_mem_read error. ret=%d\n",
				     ret);
			goto PROFILER_CHECKPOINT_MSG_READ_RPWP_vfree;
		}

		VATOOLS_DUMP_BRIEF("[READ_RPWP] --------------", temp_buf,
				   kdata.output_buf.buf_size);
		VATOOLS_DUMP_BRIEF("[READ_RPWP] --------------",
				   (u8 *)temp_buf + 384, 80);
		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
				      temp_buf, kdata.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d byte=%d\n", ret,
				    kdata.output_buf.buf_size);
			ret = -EFAULT;
			goto PROFILER_CHECKPOINT_MSG_READ_RPWP_vfree;
		}

	PROFILER_CHECKPOINT_MSG_READ_RPWP_vfree:
		vfree(temp_buf);

		goto out;
	} break;

	case PROFILER_CHECKPOINT_MSG_READ_CTRL: {
		u8 *temp_buf = NULL;
		if (kdata.output_buf.buf_size == 0) {
			ret = -EINVAL;
			VATOOLS_DBG(priv, die_index,
				    "[READ_CTRL] error. size=%d\n",
				    kdata.output_buf.buf_size);
			goto out;
		}
		temp_buf = (u8 *)vmalloc(kdata.output_buf.buf_size);
		if (!temp_buf) {
			VATOOLS_ERR(priv, die_index,
				    "[READ_CTRL] vmalloc error. size=%d\n",
				    kdata.output_buf.buf_size);
			ret = -ENOMEM;
			goto out;
		}

		VATOOLS_DBG(priv, die_index,
			    "[READ_CTRL] ctrl_addr=0x%x buf_size=%d\n",
			    PROFILER_CTRL_BASE_ADDR /*Hardness. Address*/,
			    kdata.output_buf.buf_size);

		ret = vastai_pci_mem_read(
			priv, die_index,
			PROFILER_CTRL_BASE_ADDR /*Hardness. Address*/, temp_buf,
			kdata.output_buf.buf_size);
		if (ret < 0) {
			ret = -EFAULT;
			VATOOLS_INFO(priv, die_index,
				     " vastai_pci_mem_read error. ret=%d\n",
				     ret);
			goto PROFILER_CHECKPOINT_MSG_READ_CTRL_vfree;
		}

		/*check bufsize and copy timeline status in driver to host*/
		if (kdata.output_buf.buf_size < 32) {
			ret = -EFAULT;
			VATOOLS_DBG(
				priv, die_index,
				"note: kdata.output_buf.buf_size < 32. no timeline status of driver. ret=%d\n",
				ret);
		} else {
			*(temp_buf + CORE_HOST_PCIE) =
				profiler_timeline_enable & 0x01;
		}

		VATOOLS_DUMP_BRIEF("[READ_CTRL] --------------", temp_buf,
				   kdata.output_buf.buf_size);

		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
				      temp_buf, kdata.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d byte=%d\n", ret,
				    kdata.output_buf.buf_size);
			ret = -EFAULT;
			goto PROFILER_CHECKPOINT_MSG_READ_CTRL_vfree;
		}

	PROFILER_CHECKPOINT_MSG_READ_CTRL_vfree:
		vfree(temp_buf);

		goto out;
	} break;

	case PROFILER_CHECKPOINT_MSG_READ_DATA: {
		void *temp_buf = NULL;
		if (kdata.output_buf.buf_size == 0) {
			ret = -EINVAL;
			VATOOLS_DBG(priv, die_index,
				    "[READ_DATA] error. size=%d\n",
				    kdata.output_buf.buf_size);
			goto out;
		}
		temp_buf = (void *)vmalloc(kdata.output_buf.buf_size);
		if (!temp_buf) {
			VATOOLS_ERR(priv, die_index,
				    "[READ_DATA] vmalloc error. size=%d\n",
				    kdata.output_buf.buf_size);
			ret = -ENOMEM;
			goto out;
		}

		VATOOLS_DBG(priv, die_index,
			    "[READ_DATA] addr=0x%llx buf_size=%d\n",
			    kdata.address, kdata.output_buf.buf_size);

		ret = vatools_pci_tl_read(priv, kdata.device.die_id,
					  kdata.address, temp_buf,
					  kdata.output_buf.buf_size);
		if (ret < 0) {
			ret = -EFAULT;
			VATOOLS_INFO(priv, die_index,
				     " vastai_pci_mem_read error. ret=%d\n",
				     ret);
			goto PROFILER_CHECKPOINT_MSG_READ_DATA_vfree;
		}

		if (kdata.output_buf.buf_size > 512) {
			VATOOLS_DUMP_BRIEF("[READ_DATA] head ------", temp_buf,
					   256);

			VATOOLS_DUMP_BRIEF(
				"[READ_DATA] tail ------",
				temp_buf + kdata.output_buf.buf_size - 256,
				256);
		} else {
			VATOOLS_DUMP_BRIEF("[READ_DATA] body ======", temp_buf,
					   kdata.output_buf.buf_size);
		}

		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
				      temp_buf, kdata.output_buf.buf_size);
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d byte=%d\n", ret,
				    kdata.output_buf.buf_size);
			ret = -EFAULT;
			goto PROFILER_CHECKPOINT_MSG_READ_DATA_vfree;
		}

	PROFILER_CHECKPOINT_MSG_READ_DATA_vfree:
		vfree(temp_buf);

		goto out;
	} break;

	case PROFILER_CHECKPOINT_MSG_WRITE_RPWP: {
		u8 *temp_buf = NULL;
		if (kdata.output_buf.buf_size == 0) {
			ret = -EINVAL;
			VATOOLS_DBG(priv, die_index,
				    "[WRITE_RPWP] error. size=%d\n",
				    kdata.input_buf.buf_size);
			goto out;
		}
		temp_buf = (u8 *)vmalloc(kdata.input_buf.buf_size);
		if (!temp_buf) {
			VATOOLS_ERR(priv, die_index,
				    "[WRITE_RPWP] vmalloc error. size=%d\n",
				    kdata.input_buf.buf_size);
			ret = -ENOMEM;
			goto out;
		}

		if (copy_from_user_ex(temp_buf,
				      (void *)kdata.input_buf.buf_addr,
				      kdata.input_buf.buf_size)) {
			ret = -EFAULT;
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex ret=%d\n", ret);
			goto PROFILER_CHECKPOINT_MSG_WRITE_RPWP_vfree;
		}

		VATOOLS_DBG(priv, die_index,
			    "[WRITE_RPWP] addr=0x%llx buf_size=%d\n",
			    kdata.address, kdata.input_buf.buf_size);
		VATOOLS_DUMP_BRIEF("[WRITE_RPWP] --------------", temp_buf,
				   kdata.input_buf.buf_size);

		ret = vastai_pci_mem_write(priv, die_index, kdata.address,
					   temp_buf, kdata.input_buf.buf_size);
		if (ret < 0) {
			ret = -EFAULT;
			goto PROFILER_CHECKPOINT_MSG_WRITE_RPWP_vfree;
		}

	PROFILER_CHECKPOINT_MSG_WRITE_RPWP_vfree:
		vfree(temp_buf);

		goto out;
	} break;

		/*pcie dma profiler timeline*/
	case PROFILER_CHECKPOINT_MSG_READ_PCIE_DMA: {
#ifdef VATOOLS_PROFILER_ENABLE
		/*Use TLV to pass data, pay attention to the ferrule data copy*/
		T_SMI_TLV tlv;
		void *ringbuf_data_p = NULL;
		struct vastai_fifo *fifo = NULL;
		u32 count = 0;
		u32 wr_to_end_len = 0;
		u32 rd = 0;
		u32 wr = 0;

		fifo = (struct vastai_fifo *)node->profiler_dma_ringbuf;
		mutex_lock(&pcie_timeline_dma_mutex);
		rd = fifo->rd;
		wr = fifo->wr;

		if (vastai_fifo_is_empty(fifo) || !vastai_is_fifo_valid(fifo)) {
			ret = -ENOMEM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_dma_mutex_unlock;
		}

		if (fifo->elem_count == 0) {
			ret = -EDOM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_dma_mutex_unlock;
		}
		count = (wr + (fifo->elem_count - rd)) % fifo->elem_count;
		ringbuf_data_p =
			(void *)((u8 *)fifo + vastai_fifo_rd_pre_fetch(fifo));

		tlv.address = 0;
		tlv.length = count * fifo->elem_size;
		tlv.value[0] = 0;

		VATOOLS_DBG(
			priv, die_index,
			"read pcie dma: count=%d size=%d tlv.length=%d ringbuf_data_p=%p rd=0x%x wr=0x%x\n",
			count, fifo->elem_size, tlv.length, ringbuf_data_p, rd,
			wr);

		/*copy header*/
		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr, &tlv,
				      sizeof(T_SMI_TLV));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d len=%ld\n", ret,
				    sizeof(T_SMI_TLV));
			ret = -EFAULT;
			goto out_dma_mutex_unlock;
		}

		if (rd < wr) {
			/*copy value*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, count * fifo->elem_size);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, count * fifo->elem_size);
				ret = -EFAULT;
				goto out_dma_mutex_unlock;
			}
		} else {
			/*rd -> end*/
			wr_to_end_len =
				(fifo->elem_count - rd) * fifo->elem_size;
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, wr_to_end_len);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_dma_mutex_unlock;
			}
			/*0 -> wr*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV) + wr_to_end_len),
				fifo->buf, (wr * fifo->elem_size));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_dma_mutex_unlock;
			}
		}
		VATOOLS_DBG(priv, die_index,
			    "read pcie DMA done. rd=%d, wr=%d\n", rd, wr);
		fifo->rd = wr;
	out_dma_mutex_unlock:
		mutex_unlock(&pcie_timeline_dma_mutex);
		goto out;
#endif
	} break;

		/*pcie msg profiler timeline*/
	case PROFILER_CHECKPOINT_MSG_READ_PCIE_MSG: {
#ifdef VATOOLS_PROFILER_ENABLE
		/*Use TLV to pass data, pay attention to the ferrule data copy*/
		T_SMI_TLV tlv;
		void *ringbuf_data_p = NULL;
		struct vastai_fifo *fifo = NULL;
		u32 count = 0;
		u32 wr_to_end_len = 0;
		u32 rd = 0;
		u32 wr = 0;

		fifo = (struct vastai_fifo *)node->profiler_msg_ringbuf;
		mutex_lock(&pcie_timeline_msg_mutex);
		rd = fifo->rd;
		wr = fifo->wr;

		if (vastai_fifo_is_empty(fifo) || !vastai_is_fifo_valid(fifo)) {
			ret = -ENOMEM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_msg_mutex_unlock;
		}

		if (fifo->elem_count == 0) {
			ret = -EDOM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_msg_mutex_unlock;
		}
		count = (wr + (fifo->elem_count - rd)) % fifo->elem_count;
		ringbuf_data_p =
			(void *)((u8 *)fifo + vastai_fifo_rd_pre_fetch(fifo));

		tlv.address = 0;
		tlv.length = count * fifo->elem_size;
		tlv.value[0] = 0;

		VATOOLS_DBG(
			priv, die_index,
			"read pcie msg: count=%d size=%d tlv.length=%d ringbuf_data_p=%p rd=0x%x wr=0x%x\n",
			count, fifo->elem_size, tlv.length, ringbuf_data_p, rd,
			wr);

		/*copy header*/
		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr, &tlv,
				      sizeof(T_SMI_TLV));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d len=%ld\n", ret,
				    sizeof(T_SMI_TLV));
			ret = -EFAULT;
			goto out_msg_mutex_unlock;
		}

		if (rd < wr) {
			/*copy value*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, count * fifo->elem_size);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, count * fifo->elem_size);
				ret = -EFAULT;
				goto out_msg_mutex_unlock;
			}
		} else {
			/*rd -> end*/
			wr_to_end_len =
				(fifo->elem_count - rd) * fifo->elem_size;
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, wr_to_end_len);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_msg_mutex_unlock;
			}
			/*0 -> wr*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV) + wr_to_end_len),
				fifo->buf, (wr * fifo->elem_size));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_msg_mutex_unlock;
			}
		}
		VATOOLS_DBG(priv, die_index,
			    "read pcie msg done. rd=%d, wr=%d\n", rd, wr);
		fifo->rd = wr;
	out_msg_mutex_unlock:
		mutex_unlock(&pcie_timeline_msg_mutex);
		goto out;
#endif
	} break;

		/*pcie app profiler timeline: read*/
	case PROFILER_CHECKPOINT_MSG_READ_PCIE_APP: {
#ifdef VATOOLS_PROFILER_ENABLE
		/*Use TLV to pass data, pay attention to the ferrule data copy*/
		T_SMI_TLV tlv;
		void *ringbuf_data_p = NULL;
		struct vastai_fifo *fifo = NULL;
		u32 count = 0;
		u32 wr_to_end_len = 0;
		u32 rd = 0;
		u32 wr = 0;

		fifo = (struct vastai_fifo *)node->profiler_app_ringbuf;
		mutex_lock(&pcie_timeline_app_mutex);
		rd = fifo->rd;
		wr = fifo->wr;

		if (vastai_fifo_is_empty(fifo) || !vastai_is_fifo_valid(fifo)) {
			ret = -ENOMEM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_app_mutex_unlock;
		}

		if (fifo->elem_count == 0) {
			ret = -EDOM;
			/*copy header*/
			memset(&tlv, 0, sizeof(T_SMI_TLV));
			ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr,
					      &tlv, sizeof(T_SMI_TLV));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d len=%ld\n",
					    ret, sizeof(T_SMI_TLV));
				ret = -EFAULT;
			}
			goto out_app_mutex_unlock;
		}
		count = (wr + (fifo->elem_count - rd)) % fifo->elem_count;
		ringbuf_data_p =
			(void *)((u8 *)fifo + vastai_fifo_rd_pre_fetch(fifo));

		tlv.address = 0;
		tlv.length = count * fifo->elem_size;
		tlv.value[0] = 0;

		VATOOLS_DBG(
			priv, die_index,
			"read pcie msg: count=%d size=%d tlv.length=%d ringbuf_data_p=%p rd=0x%x wr=0x%x\n",
			count, fifo->elem_size, tlv.length, ringbuf_data_p, rd,
			wr);

		/*copy header*/
		ret = copy_to_user_ex((void *)kdata.output_buf.buf_addr, &tlv,
				      sizeof(T_SMI_TLV));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_to_user_ex ret=%d len=%ld\n", ret,
				    sizeof(T_SMI_TLV));
			ret = -EFAULT;
			goto out_app_mutex_unlock;
		}

		if (rd < wr) {
			/*copy value*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, count * fifo->elem_size);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, count * fifo->elem_size);
				ret = -EFAULT;
				goto out_app_mutex_unlock;
			}
		} else {
			/*rd -> end*/
			wr_to_end_len =
				(fifo->elem_count - rd) * fifo->elem_size;
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV)),
				ringbuf_data_p, wr_to_end_len);
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_app_mutex_unlock;
			}
			/*0 -> wr*/
			ret = copy_to_user_ex(
				(void *)((u8 *)kdata.output_buf.buf_addr +
					 sizeof(T_SMI_TLV) + wr_to_end_len),
				fifo->buf, (wr * fifo->elem_size));
			if (ret) {
				VATOOLS_ERR(priv, die_index,
					    "copy_to_user_ex ret=%d byte=%d\n",
					    ret, wr_to_end_len);
				ret = -EFAULT;
				goto out_app_mutex_unlock;
			}
		}
		VATOOLS_DBG(priv, die_index,
			    "read pcie msg done. rd=%d, wr=%d\n", rd, wr);
		fifo->rd = wr;
	out_app_mutex_unlock:
		mutex_unlock(&pcie_timeline_app_mutex);
		goto out;
#endif
	} break;

		/*pcie app profiler timeline: write*/
	case PROFILER_CHECKPOINT_MSG_WRITE_PCIE_APP: {
#ifdef VATOOLS_PROFILER_ENABLE
		struct s_profiler_app_checkpoint app_section;
		memset(&app_section, 0,
		       sizeof(struct s_profiler_app_checkpoint));

		ret = copy_from_user_ex(
			(void *)&app_section, (void *)kdata.input_buf.buf_addr,
			sizeof(struct s_profiler_app_checkpoint));
		if (ret) {
			VATOOLS_ERR(priv, die_index,
				    "copy_from_user_ex ret=%d len=%ld\n", ret,
				    sizeof(struct s_profiler_app_checkpoint));
			ret = -EFAULT;
			goto out;
		}

		vatools_profiler_app_checkpoint(&app_section);

		VATOOLS_DBG(priv, die_index, "write pcie app done. len=%ld\n",
			    sizeof(struct s_profiler_app_checkpoint));
		goto out;
#endif
	} break;
	}

out:
	kdata.errcode = ret;
	ret2 = copy_to_user_ex((void __user *)argp, &kdata, sizeof(kdata));
	if (ret2) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex ret=%d\n", ret);
		ret2 = -EFAULT;
	}
	VATOOLS_DBG(priv, die_index, "ioctl return ret=%d  ret2=%d\n", ret,
		    ret2);

	return ret2;
}

static int profiler_ioctl_get(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	int ret = 0;

	VATOOLS_FUNC_ENTERY;
	ret = profiler_ioctl_set(filp, cmd, arg);
	VATOOLS_FUNC_EXIT;

	return ret;
}

long profiler_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EINVAL;

	switch (cmd) {
	case VATOOLS_PROFILER_SET_PERFORMANCE_CSR:
		ret = profiler_set_performance_csr(filp, cmd, arg);
		break;
	case VATOOLS_PROFILER_SET:
		ret = profiler_ioctl_set(filp, cmd, arg);
		break;
	case VATOOLS_PROFILER_GET:
		ret = profiler_ioctl_get(filp, cmd, arg);
		break;
	}

	return ret;
}

int profiler_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);
	return -EPERM;
}
int profiler_open(struct inode *inode, struct file *filp)
{
	VATOOLS_FUNC_ENTERY;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);

	VATOOLS_FUNC_EXIT;
	return 0;
}

int profiler_release(struct inode *ignored, struct file *filp)
{
	int ret = 0;
	struct vatools_node *node;
	struct vatools_reader *reader;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(ignored);
	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);
	VATOOLS_DBG(
		NULL, DUMMY_DIE_ID,
		"filp=0x%p  node=0x%p  reader=0x%p  reader->profiler_checkpoint_corebitmap=0x%x\n",
		filp, node, reader, reader->profiler_checkpoint_corebitmap);

	ret = profiler_release_checkpoint(filp);
	return ret;
}

int profiler_fasync(int fd, struct file *filp, int mode)
{
	V_UNREFERENCE(fd);
	V_UNREFERENCE(filp);
	V_UNREFERENCE(mode);
	return -EPERM;
}
