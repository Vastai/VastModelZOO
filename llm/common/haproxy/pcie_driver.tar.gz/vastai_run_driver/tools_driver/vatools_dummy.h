﻿#ifndef __VATOOLS_DUMMY_H__
#define __VATOOLS_DUMMY_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

loff_t dummy_llseek(struct file *filp, loff_t offset, int orig);
ssize_t dummy_read(struct file *filp, char __user *buf, size_t size,
		   loff_t *pos);
ssize_t dummy_write(struct file *filp, const char __user *buf, size_t size,
		    loff_t *pos);
ssize_t dummy_write_iter(struct kiocb *iocb, struct iov_iter *from);
unsigned int dummy_poll(struct file *filp, struct poll_table_struct *wait);
long dummy_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg);
int dummy_mmap(struct file *filp, struct vm_area_struct *pvm);
int dummy_open(struct inode *inode, struct file *filp);
int dummy_release(struct inode *ignored, struct file *filp);
int dummy_fasync(int fd, struct file *filp, int mode);
long vatools_ioctl_v2_get_device_info(struct file *filp, unsigned int cmd,
				      IOCTL_ARG_T arg);
long vatools_ioctl_get_base_info(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg);
int is_32_bit_thread(void);
unsigned long copy_from_user_ex(void *to, const void __user *from,
				unsigned long n);
unsigned long copy_to_user_ex(void __user *to, const void *from,
			      unsigned long n);
int vatools_v2_clear_device_info(void *priv);
int vaccrt_die_info_get_head(struct vastai_cdev *vacc_dev, void *buffer);
int vaccrt_die_info_get_zone_ddr(struct vastai_cdev *vacc_dev, void *buffer);
int vaccrt_die_info_get_process(struct vastai_cdev *vacc_dev, void *buffer,
				int max_count, int *count);
char *vaccrt_version_number2string(uint32_t num, char *str);
struct vastai_die_info *vatool_get_die_info(struct vastai_pci_info *priv,
					    u8 die_id_in_fn);
struct vastai_pkg_info *vatool_get_pkg_info(struct vastai_pci_info *priv,
					    u8 die_id_in_fn);

void refresh_pcie_inventory_cache(void);

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_DUMMY_H__*/
