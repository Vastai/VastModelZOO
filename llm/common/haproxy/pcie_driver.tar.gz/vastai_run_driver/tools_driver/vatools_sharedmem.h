﻿#ifndef __VATOOLS_SHAREDMEM_H__
#define __VATOOLS_SHAREDMEM_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

#define SHAREDMEM_TOOLS_MAX_DEVICES 1

enum enum_sharedmem_write_type {
	VATOOLS_SHAREDMEM_WRITE_DATA = 0, /*Normal data*/
	VATOOLS_SHAREDMEM_WRITE_SINGAL = 1, /* Signal data*/
	VATOOLS_SHAREDMEM_WRITE_DEBUG = 2, /*debug data*/
};

typedef struct tar_data_info {
	u32 n_type; /*data type*/
	u32 n_len; /*Data length*/
	u64 n_buf_addr; /* Data address*/
} t_data_info;
typedef struct tar_channel_info {
	int id; /*channel id*/
	int type; /*channel type : decode encode*/
	int writetype; /*For details on the type of write operation to this channel, see enum_sharedmem_write_type*/
} t_channle_info;
typedef struct memory_entry {
	int cmd_type; /*Type of operation*/
	t_channle_info tchannel; /*Channel information.*/
	u64 n_shard_addr; /* Open up a space location*/
	u64 n_user_addr; /*User postback data*/
	t_data_info tdata; /*Data storage area*/
	/*void *callback; Callback function*/
	u64 callback; /* callback function*/

	/*The app calls the input parameter*/
	u32 version; /*version number, now write 0*/
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
	u8 flag_specify_die; /*0: Not specified 1: specify die*/
	u8 flag_allocate_policy; /*Allocation policy method: 0: Take the lowest resource occupation die*/
	u8 flag_rsvd;
	u32 die_seq;
	u32 die_weight; /*allocated die weight*/
} T_MEMORY_ENTRY;

typedef struct tar_video_debug_info {
	struct list_head t_video_node;
	int n_effic_len; /*Valid data length of the data area*/
	void *p_buf; /* Truthful shared data*/
} t_video_debug_info;

typedef struct t_video_debug_header {
	int is_debugbuf; /*Whether the area is a debug area*/
	int needsendmsg; /* Whether a message needs to be sent*/
	int startflag; /*debugger start flag*/
	int debugtype; /*debug*/
	int data_cnt; /* How many blocks of data does a have*/
	int rest; /* Reservation field*/
	struct mutex data_info_mutex; /* Data zone internal lock*/
	struct list_head
		t_node_head; /*Message log when used for video debugger lupa add 2021-12-15*/
	struct t_mem_info
		*pmeminfo; /*The head pointer to which the data corresponds*/
	void *debuginfo; /*Used to store debugger-related data*/
} t_video_debug_head;

#if (TOOLS_WIN == 1)
/*TODO: tobedone: need check this*/
/*remove compile warning: Warning	C4366	The result of the unary '&' operator may be unaligned*/
#pragma pack(8)
#endif
/*The basic unit of shared memory. One per channel*/
typedef struct t_mem_info {
	t_channle_info tchannel; /*Channel information.*/
	int rest; /* Reservation field*/
	u64 user_data; /* is used to store the user's corresponding data pointer*/
	struct list_head t_sharedmem_node;
	struct mutex mem_info_mutex; /* Data zone internal lock*/
	int n_effic_len; /*Valid data length of the data area*/
	t_video_debug_head
		tvideo_debugger; /*Used to record data for videodebugger*/
	void *p_buf; /* Truthful shared data*/
	/*void *callback; Callback function*/
	u64 callback; /* callback function*/
	struct vatools_reader *reader; /* to put the corresponding parent node*/
	struct vatools_reader
		*waitreader; /* to put the corresponding parent node*/

	/*The app calls the input parameter*/
	u32 version; /*version number, now write 0*/
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
	u8 flag_specify_die; /*0: Not specified 1: specify die*/
	u8 flag_allocate_policy; /*Allocation policy method: 0: Take the lowest resource occupation die*/
	u8 flag_rsvd;
	u32 die_seq;
	u32 die_weight; /*allocated die weight*/
} T_MEM_INFO;

#pragma pack(1)

typedef struct tar_sharedmen_buf_info {
	int n_len;
	char c_buf[0];
} T_SHAREDMEM_BUF_INFO;

typedef struct tar_sharedmen_buf_header {
	u64 n_addr; /* is the address of the sharedmem used to quickly find the message header*/
	char c_bodybuf[0];
} T_SHAREDMEM_BUF_HEADER;

/*Shared memory operations begin lupa add 2021-12-15*/
/*Not yet used*/
loff_t sharedmem_llseek(struct file *filp, loff_t offset, int orig);
/*Not yet used*/
ssize_t sharedmem_read(struct file *filp, char __user *buf, size_t size,
		       loff_t *pos);
/*Not yet used*/
ssize_t sharedmem_write(struct file *filp, const char __user *buf, size_t size,
			loff_t *pos);
/*Not yet used*/
ssize_t sharedmem_write_iter(struct kiocb *iocb, struct iov_iter *from);
/*Not yet used*/
unsigned int sharedmem_poll(struct file *filp, struct poll_table_struct *wait);
/*Not yet used*/
int sharedmem_mmap(struct file *filp, struct vm_area_struct *pvm);
/*Control data lupa modify 2021-12-15*/
long sharedmem_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg);
/*Not yet used*/
int sharedmem_open(struct inode *inode, struct file *filp);
/*Resource release*/
int sharedmem_release(struct inode *ignored, struct file *filp);
int sharedmem_fasync(int fd, struct file *filp, int mode);
/*Set the usage type to sharedmemory*/
int sharedmem_set_app_category(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg);
/*Shared memory operations end lupa add 2021-12-15*/

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_SHAREDMEM_H__*/
