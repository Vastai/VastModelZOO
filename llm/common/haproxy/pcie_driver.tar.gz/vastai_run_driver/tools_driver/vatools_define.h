﻿#ifndef __VATOOLS_DEFINE_H__
#define __VATOOLS_DEFINE_H__

/*All data from the driver interface is aligned to 1 byte*/
#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

/*Compile the standalone Vatools driver. Used for internal testing*/
#ifndef VATOOLS_INDEPENDANCE_DRIVER
#define VATOOLS_INDEPENDANCE_DRIVER 0
#endif

#include "vatool_addr_partition.h"
/*Feature definition*/

#ifdef VA_DRIVER_SG100
/*Hot-swappable capability*/
#undef VATOOLS_HOT_PLUG_ENABLE
/*sv100, sg100 Drive convergence*/
#undef VATOOLS_SV_SG_MERGE
/*Profiler Timeline Data Collection: MCU time synchronization*/
#undef VATOOLS_CORE_TIME_SYNC_ENABLE
/*profiler timeline Data acquisition*/
#undef VATOOLS_PROFILER_ENABLE
/*sharemem lock optimize, don't use node_mutex anymore*/
#undef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
/*use cache or not: 1:do not use cache; 0: use cache*/
#define TOOLS_DEBUG_NO_DEV_INFO_CACHE (0)
/* enable test node */
//#define VATOOLS_DRIVER_TEST_NODE
#else
/*Hot-swappable capability*/
#define VATOOLS_HOT_PLUG_ENABLE
/*sv100, sg100 Drive convergence*/
#undef VATOOLS_SV_SG_MERGE
/*Profiler Timeline Data Acquisition: MCU time synchronization*/
#define VATOOLS_CORE_TIME_SYNC_ENABLE
/*profiler timeline Data acquisition*/
#define VATOOLS_PROFILER_ENABLE
/*sharemem lock optimize, don't use node_mutex anymore*/
#define VATOOLS_SHAREMEM_LOCK_OPTIMIZE
/*use cache or not: 1:do not use cache; 0: use cache*/
#define TOOLS_DEBUG_NO_DEV_INFO_CACHE (0)
/* enable test node */
//#define VATOOLS_DRIVER_TEST_NODE
#endif

#define V_UNREFERENCE(param) ((void)param);

#define VATOOLS_CHECK_BYTE_ALIGH (1)

#define SMI_CMD_ACK_WAIT_MS (1000)

/*NOTE: The following definitions, app, driver need to be consistent, and copied to each application*/

/*Defines the maximum number of devices that can be managed*/
#ifndef MAX_DEVICE_NUM_PER_MANAGER
#define MAX_DEVICE_NUM_PER_MANAGER 128
#endif
/*Define the maximum number of dies in each device*/
#ifndef MAX_DIE_NUM_PER_DEVICE
#define MAX_DIE_NUM_PER_DEVICE VASTAI_DIE_MAX_NUM
#endif
/*Define the maximum number of units in each die, and if it is exceeded, each command needs to expand it by itself*/
#define MAX_UNIT_NUM_PER_DIE 32
#define VATOOLS_UINT32_MAX   0xFFFFFFFF
/*Defines the maximum length of the vatools file node filename*/
#define VATOOLS_DEVICE_NAME_LEN (32)
/*Vatools tool drives the file node*/
#define VATOOLS_DEV_NAME      "vatools"
#define VATOOLS_DEV_PATH_NAME "/dev/vatools"
#define VA_NODE_NAME_CARD     "card"
#define VA_NODE_NAME_RENDER   "renderD"
#define VA_NODE_NAME_KCHAR    "kchar:"

/*Define internal usage error codes*/
#define E_UNKNOWN_IOCTL		  201 /*IOCTL not recognized*/
#define E_UNKNOWN_SUB_CMD	  202 /*Command not recognized*/
#define E_UNPROCCESSED_CMD	  203 /*Command not supported*/
#define E_INVALID_SHAREMEM_HANDLE 404
/*IOCTL MAIGC CODE*/
#define VATOOLS_IOCTL_MAGIC 0xA1

#define VATOOLS_BUFFER_SIZE (0x1000)

/*Define the ioctl command offsets for each function*/
#define VATOOLS_GENERAL_IOCTL_BASE		0x10
#define VATOOLS_HARDWARE_PERFORMANCE_IOCTL_BASE 0x50
#define VATOOLS_SHAREDMEMORY_IOCTL_BASE		0x60
#define VATOOLS_LOGGER_IOCTL_BASE		0x70
#define VATOOLS_DEBUG_IOCTL_BASE		0x80
#define VATOOLS_SMI_IOCTL_BASE			0x90
#define VATOOLS_MONITOR_IOCTL_BASE		0xa0
#define MAX_RAS_READ_ONCE			100
/*ioctl generic command*/
/*Test commands*/
#define VATOOLS_GENERAL_IOCTL_TEST                                             \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x00)
/*Set the category of the open file fd*/
#define VATOOLS_GENERAL_IOCTL_SET_APP_CATEGORY                                 \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x01)
/*Get device quantity*/
#define VATOOLS_GENERAL_IOCTL_GET_DEVICE_NUM                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x02)
/*Get the info*/
#define VATOOLS_GENERAL_IOCTL_GET_DIE_INFO                                     \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x03)
/*Read data via SMI*/
#define VATOOLS_GENERAL_IOCTL_READ                                             \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x04)
/*Write data via SMI*/
#define VATOOLS_GENERAL_IOCTL_WRITE                                            \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x05)
/*Read and write data via DMI, read and write with a single call*/
#define VATOOLS_GENERAL_IOCTL_FETCH                                            \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x06)
/*Get the pcie bus_id for the device*/
#define VATOOLS_GENERAL_IOCTL_GET_DEV_PCIE_BUS_ID                              \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x07)
/*Fetch the Render*/
#define VATOOLS_GENERAL_IOCTL_GET_DIE_RENDER                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x08)
/*The data is read through the PCIE driver and the data is not sent to the smi*/
#define VATOOLS_GENERAL_IOCTL_PCIE                                             \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x09)
/*Obtain a PCIe ID*/
#define VATOOLS_GENERAL_IOCTL_GET_PCIE_ID                                      \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0a)
/*fetch pcie sub id*/
#define VATOOLS_GENERAL_IOCTL_GET_PCIE_SUB_ID                                  \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0b)
/*Get the driver major minor version number*/
#define VATOOLS_GENERAL_IOCTL_GET_MAJOR_MINOR_ID                               \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0c)
/*fetch device competency set*/
#define VATOOLS_GENERAL_IOCTL_DEVICE_CAPABILITY                                \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0d)
/*fetch firmware log status*/
#define VATOOLS_GENERAL_IOCTL_LOG_STATUS                                       \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0e)
/*Allocate DMA memory*/
#define VATOOLS_GENERAL_IOCTL_DMA_ALLOC                                        \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x0f)
/*Start DMA Transfer Data*/
#define VATOOLS_GENERAL_IOCTL_DMA_START                                        \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x10)
/*Normal way to read data*/
#define VATOOLS_GENERAL_IOCTL_READ_BUF                                         \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x11)
/*Write data in normal mode*/
#define VATOOLS_GENERAL_IOCTL_WRITE_BUF                                        \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x12)
/*Use kernel mutex to implement process mutex protection: locking*/
#define VATOOLS_GENERAL_IOCTL_GUARD_LOCK                                       \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x13)
/*Process mutex protection with kernel mutex: Unlock*/
#define VATOOLS_GENERAL_IOCTL_GUARD_UNLOCK                                     \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x14)
/*Use kernel mutex to implement process mutex protection: trylock*/
#define VATOOLS_GENERAL_IOCTL_GUARD_TRYLOCK                                    \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x15)
/*Implement process mutex protection with kernel mutex: is locked*/
#define VATOOLS_GENERAL_IOCTL_GUARD_IS_LOCKED                                  \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x16)
/*core timestamp sync*/
#define VATOOLS_GENERAL_IOCTL_CORE_TIME_SYNC                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x17)
/*Obtain the version information of the bmcu xspi*/
#define VATOOLS_GENERAL_IOCTL_GET_BMCU_XSPI_VERSION                            \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x18)
/*Burn into the BMCU FW version*/
#define VATOOLS_GENERAL_IOCTL_FLASH_BMCU_FW                                    \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x19)
/*Burn in the XSPI FW version*/
#define VATOOLS_GENERAL_IOCTL_FLASH_XSPI_FW                                    \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1A)
/*Obtain the flashing status*/
#define VATOOLS_GENERAL_IOCTL_GET_FLASH_STA                                    \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1B)
/*Change the BMCU version*/
#define VATOOLS_GENERAL_IOCTL_SWITCH_BMCU                                      \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1C)
/*fetch device info*/
#define VATOOLS_GENERAL_IOCTL_GET_DEV_INFO                                     \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1D)
/*fetch reset event*/
#define VATOOLS_GENERAL_IOCTL_DEVICE_EVENT                                     \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1E)
/*Obtain whether SRIOV is enabled and the number of VFs*/
#define VATOOLS_GENERAL_IOCTL_SRIOV_NUMBER                                     \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x1F)

/*Get the event event*/
#define VATOOLS_GENERAL_IOCTL_DEVICE_EVENT_SELECT                              \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x20)

/*Free up DMA application memory space*/
#define VATOOLS_GENERAL_IOCTL_DMA_FREE                                         \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x21)
/*DMA: User-space memory is passed to the kernel and can be used without alloc dma memory first*/
#define VATOOLS_GENERAL_IOCTL_DMA_TRANS                                        \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x22)

/*Use fnread to read data*/
#define VATOOLS_GENERAL_IOCTL_FNREAD_BUF                                       \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x23)
/*Write data by fnwrite mode*/
#define VATOOLS_GENERAL_IOCTL_FNWRITE_BUF                                      \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_GENERAL_IOCTL_BASE + 0x24)

/*Set the Acquisition Performance Project command*/
#define VATOOLS_PROFILER_SET_PERFORMANCE_CSR                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_HARDWARE_PERFORMANCE_IOCTL_BASE + 0x01)
/*Set the performance command*/
#define VATOOLS_PROFILER_SET                                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_HARDWARE_PERFORMANCE_IOCTL_BASE + 0x02)
/*Read performance commands*/
#define VATOOLS_PROFILER_GET                                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_HARDWARE_PERFORMANCE_IOCTL_BASE + 0x03)

/*used for ioctrl type stable struct, same as struct memory_entry*/
struct unref_struct {
	u8 array[72];
};
/*shared memory ioctl*/
/*Create shared memory information*/
#define VATOOLS_CREATE_SHARE_MEM                                               \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x01,     \
	      struct unref_struct)
/*Deletes shared memory information*/
#define VATOOLS_DELETE_SHARE_MEM                                               \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x02,     \
	      struct unref_struct)
/*Get the shared memory information*/
#define VATOOLS_READ_SHARE_MEM                                                 \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x03,     \
	      struct unref_struct)
/*Write shared memory information*/
#define VATOOLS_WRITE_SHARE_MEM                                                \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x04,     \
	      struct unref_struct)
/*Wait for the information to start*/
#define VATOOLS_POLL_SHARE_MEM                                                 \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x05,     \
	      struct unref_struct)

/*Start video debugger information*/
#define VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER                                 \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x06,     \
	      struct unref_struct)
/*Stop video debugger information*/
#define VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER                                  \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x07,     \
	      struct unref_struct)
/*Read Video debugger information*/
#define VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER                                  \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x08,     \
	      struct unref_struct)
/*Write video debugger information*/
#define VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER                                 \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x09,     \
	      struct unref_struct)
/*Additional callback functions*/
#define VATOOLS_CREATE_VIDEO_MEM_FUNCTION                                      \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0A,     \
	      struct unref_struct)
/*Delete the callback function*/
#define VATOOLS_DELETE_VIDEO_MEM_FUNCTION                                      \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0B,     \
	      struct unref_struct)

#define VATOOLS_SHARE_MEM_SET_DOCKER_NAME                                      \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0C,     \
	      struct unref_struct)

#define DOCKER_NAME_SIZE 128
struct docker_info {
	u64 docker_id;
	char docker_name[DOCKER_NAME_SIZE];
};

/*used for compatible with old, same as old struct memory_entry*/
struct unref_struct_old {
	u8 array[56];
};

/*shared memory ioctl*/
/*Create shared memory information*/
#define OLD_VATOOLS_CREATE_SHARE_MEM                                           \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x01,     \
	      struct unref_struct_old)
/*Deletes shared memory information*/
#define OLD_VATOOLS_DELETE_SHARE_MEM                                           \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x02,     \
	      struct unref_struct_old)
/*Get the shared memory information*/
#define OLD_VATOOLS_READ_SHARE_MEM                                             \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x03,     \
	      struct unref_struct_old)
/*Write shared memory information*/
#define OLD_VATOOLS_WRITE_SHARE_MEM                                            \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x04,     \
	      struct unref_struct_old)
/*Wait for the information to start*/
#define OLD_VATOOLS_POLL_SHARE_MEM                                             \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x05,     \
	      struct unref_struct_old)

/*Start video debugger information*/
#define OLD_VATOOLS_SHARE_MEM_VIDEO_START_DEBUGGER                             \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x06,     \
	      struct unref_struct_old)
/*Stop video debugger information*/
#define OLD_VATOOLS_SHARE_MEM_VIDEO_STOP_DEBUGGER                              \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x07,     \
	      struct unref_struct_old)
/*Read Video debugger information*/
#define OLD_VATOOLS_SHARE_MEM_VIDEO_READ_DEBUGGER                              \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x08,     \
	      struct unref_struct_old)
/*Write video debugger information*/
#define OLD_VATOOLS_SHARE_MEM_VIDEO_WRITE_DEBUGGER                             \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x09,     \
	      struct unref_struct_old)
/*Additional callback functions*/
#define OLD_VATOOLS_CREATE_VIDEO_MEM_FUNCTION                                  \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0A,     \
	      struct unref_struct_old)
/*Delete the callback function*/
#define OLD_VATOOLS_DELETE_VIDEO_MEM_FUNCTION                                  \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0B,     \
	      struct unref_struct_old)
#define OLD_VATOOLS_SHARE_MEM_SET_DOCKER_NAME                                  \
	_IOWR(VATOOLS_IOCTL_MAGIC, VATOOLS_SHAREDMEMORY_IOCTL_BASE + 0x0C,     \
	      struct unref_struct_old)

/*debug tools*/
/*Configure the debugging tool commands*/
#define VATOOLS_DEBUG_CONFIG                                                   \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_DEBUG_IOCTL_BASE + 0x01)
/*Set up the debugging tool commands*/
#define VATOOLS_DEBUG_SET                                                      \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_DEBUG_IOCTL_BASE + 0x02)
/*Read the debugging tool command*/
#define VATOOLS_DEBUG_GET                                                      \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_DEBUG_IOCTL_BASE + 0x03)
/*Get the debugging tool command*/
#define VATOOLS_DEBUG_FETCH                                                    \
	_IO(VATOOLS_IOCTL_MAGIC, VATOOLS_DEBUG_IOCTL_BASE + 0x04)

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(ARRAY) (sizeof(ARRAY) / sizeof(ARRAY[0]))
#endif

/*Define the core index enumeration value, the core index bitmap, and each bit represents a core*/
enum core_bit_index {
	CORE_LMCU0 = 0,
	CORE_LMCU1 = 1,
	CORE_LMCU2 = 2,
	CORE_LMCU3 = 3,
	CORE_LMCU4 = 4,
	CORE_LMCU5 = 5,
	CORE_LMCU6 = 6,
	CORE_LMCU7 = 7,
	CORE_ODSP0 = 8,
	CORE_ODSP1 = 9,
	CORE_ODSP2 = 10,
	CORE_ODSP3 = 11,
	CORE_ODSP4 = 12,
	CORE_ODSP5 = 13,
	CORE_ODSP6 = 14,
	CORE_ODSP7 = 15,
	CORE_VEMCU0 = 16,
	CORE_VEMCU1 = 17,
	CORE_VEMCU2 = 18,
	CORE_VEMCU3 = 19,
	CORE_VDMCU0 = 20,
	CORE_VDMCU1 = 21,
	CORE_VDMCU2 = 22,
	CORE_SMCU = 23,
	CORE_VDSP0 = 24,
	CORE_VDSP1 = 25,
	CORE_VDSP2 = 26,
	CORE_VDSP3 = 27,
	CORE_CMCU = 28,
	CORE_NUMBER = 29,
	CORE_HOST_PCIE =
		CORE_NUMBER, /*TODO: This enumeration is borrowed here.*/
	VA_CORE_MAX = 32, /*Up to 32 cores*/
};

/*Use Core Enum Count to simulate a sequence of drive functions*/
enum driver_simu_core_bit_index {
	CORE_HOST_PCIE_DMA = CORE_HOST_PCIE,
	CORE_HOST_PCIE_MSG,
	CORE_HOST_PCIE_APP,
	CORE_HOST_PCIE_MAX
};

#define CORE_TYPE_CMCU	0x0
#define CORE_TYPE_LMCU	0x1
#define CORE_TYPE_ODSP	0x2
#define CORE_TYPE_VDSP	0x8
#define CORE_TYPE_VDMCU 0xA
#define CORE_TYPE_VEMCU 0xB
#define CORE_TYPE_SMCU	0xF

#define SET_INDEX_CORE(TYPE, ID) ((TYPE) << 6 | (ID))
#define GET_CORE_TYPE(TYPE)	 ((TYPE) >> 6)
#define GET_INDEX_CORE(ID)	 ((ID) & 0x3F)

#define COREID_DEFINE_3(t) (t << 6) | 0, (t << 6) | 1, (t << 6) | 2
#define COREID_DEFINE_4(t)                                                     \
	(t << 6) | 0, (t << 6) | 1, (t << 6) | 2, (t << 6) | 3
#define COREID_DEFINE_8(t)                                                     \
	(t << 6) | 0, (t << 6) | 1, (t << 6) | 2, (t << 6) | 3, (t << 6) | 4,  \
		(t << 6) | 5, (t << 6) | 6, (t << 6) | 7

#define SV100_MAX_SMCU_NUM   1 /*smcu count*/
#define SV100_MAX_CMCU_NUM   1 /*cmcu count*/
#define SV100_MAX_LMCU_NUM   8 /*cmcu count*/
#define SV100_MAX_ODSP_NUM   8 /*odsp count*/
#define SV100_MAX_VDSP_NUM   4 /*vdsp count*/
#define SV100_MAX_VEMCU_NUM  4 /*vemcu count*/
#define SV100_MAX_VDMCU_NUM  3 /*vdmcu count*/
#define SV100_MAX_DRIVER_NUM 1 /*driver count*/
/*core to core interruption cmcu ringbuf data structure*/
typedef struct ring_buf_elem_struct {
	union {
		u64 whole;
		struct {
			u8 seq_no : 8; /*Low 8bit, serial number, as-is return*/
			u32 val : 32; /*Data value*/
			u16 sub_cmd : 16; /*Child Instructions*/
			u8 cmd : 7; /*Instruction family*/
			u8 use_ringbuf : 1; /*1: Use ringbuf, 0: Do not use ringbuf*/
		};
	};

} ring_buf_elem_t;

#define VATOOLS_INTERRUPT_USE_RINGBUF	  (1)
#define VATOOLS_INTERRUPT_NOT_USE_RINGBUF (0)

#define VATOOLS_INTERRUPT_TOOLS_CATEGARY_CMD                                   \
	(0x01) /*core2core interrupts ringbuf data, cmd=0x01 indicates that it is a message of the debug function*/

typedef enum {
	VATOOLS_INTERRUPT_VALUE_STOP = 0,
	VATOOLS_INTERRUPT_VALUE_START = 1,
} VATOOLS_VAL_t;

/*TOOLS SUB CMD*/
typedef enum {
	VATOOLS_INTERRUPT_UNKNOWN_CMD = 0,
	VATOOLS_INTERRUPT_DEBUG_START_CMD =
		1, /*core2core interrupts ringbuf data, cmd=0x01 indicates that it is a
						  message of the debug function*/
	VATOOLS_INTERRUPT_DEBUG_STOP_CMD = 2,
	VATOOLS_INTERRUPT_PROFILER_START_CMD =
		3, /*core2core interrupts ringbuf data, cmd=0x02 is a message for the
						     profiler feature*/
	VATOOLS_INTERRUPT_PROFILER_STOP_CMD = 4,
	VATOOLS_INTERRUPT_CORE_TIME_START_SYNC =
		5, /*core2core interrupts ringbuf data, cmd=0x03 indicates a message
						       that is the core time sync function*/
	VATOOLS_INTERRUPT_CORE_TIME_STOP_SYNC = 6,
	VATOOLS_INTERRUPT_MAX_CMD
} VATOOLS_SUBCMD_t;

enum enum_app_category {
	VATOOLS_APP_DUMMY = 0,
	VATOOLS_APP_SMI = 1,
	VATOOLS_APP_PROFILER = 2,
	VATOOLS_APP_DEBUGGER = 3,
	VATOOLS_APP_LOGGER = 4,
	VATOOLS_APP_MONITOR = 5,
	VATOOLS_APP_SHAREDMEM = 6,
	VATOOLS_APP_EVENT = 7,
	VATOOLS_APP_MAX
};

enum enum_cmd_type {
	VATOOLS_MEM_CMD_HANDLE = 0,
	VATOOLS_MEM_CMD_CHANNEL = 1,
	VATOOLS_MEM_CMD_TIMEOUT = 2,
};

/*block quantity*/
#define SMI_BLOCK_ID_MAX (8)

enum __SMI_CMD_BLOCK_IDS {
	SMI_CMD_BLOCK_ID_0 = 0,
	SMI_CMD_BLOCK_ID_1,
	SMI_CMD_BLOCK_ID_2,
	SMI_CMD_BLOCK_ID_3,
	SMI_CMD_BLOCK_ID_4,
	SMI_CMD_BLOCK_ID_5,
	SMI_CMD_BLOCK_ID_6,
	SMI_CMD_BLOCK_ID_7,
	SMI_CMD_BLOCK_ID_MAX = SMI_BLOCK_ID_MAX,
	SMI_CMD_BLOCK_ID_IGNORE = 0x0000FFFF
};

enum __SMI_CMD_BLOCK_USED_FLAG {
	SMI_CMD_BLOCK_IDLE = 0,
	SMI_CMD_BLOCK_BUSY = 1
};

typedef struct s_device {
	u32 dev_id;
	u32 die_id;
	u32 die_index; /*low die_id:8;  dev_id:16; high seq_num:8;*/
} T_DEVICE;

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
typedef struct s_vasmi_buf_array {
	u32 buf_size;
	u8 buf[0];
} T_SMI_BUF_ARR;
#endif
#else
typedef struct s_vasmi_buf_array {
	u32 buf_size;
	u8 buf[0];
} T_SMI_BUF_ARR;
#endif

typedef struct s_vasmi_buf_ptr {
	u32 buf_size;
	/*void *buf_addr;*/
	u64 buf_addr;
} T_SMI_BUF_PTR;

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
typedef struct s_vasmi_tlv {
	u32 address;
	u32 length;
	u8 value[0];
} T_SMI_TLV;
#endif
#else
typedef struct s_vasmi_tlv {
	u32 address;
	u32 length;
	u8 value[0];
} T_SMI_TLV;
#endif

/**/
typedef struct SMI_IOCTL_TRANS_CATEGORY_s {
	u32 app_category;
	u32 block_id;
	/*Card information*/
	T_DEVICE device;
	/*TODO: In order to adapt to an arm server, the structure needs to be a multiple of 8bytes. When adjusting
	 * variables, you need to consider whether or not they are 8bytes aligned. Don't modify here for the time being,*/
	/*Modified in Drive Structure vatools_reader; The next time you organize your code, you need to think holistically*/
} T_SMI_IOCTL_TRANS_CATEGORY;

/*The host uses IOCTL and drivers for data exchange and transmission*/
typedef struct SMI_IOCTL_TRANS_DATA_s {
	u32 block_id;
	/*Card information*/
	T_DEVICE device;
	u64 address;
	u32 flag; /*0x1: use pcie interface  0x0: use smi interface*/
	T_SMI_BUF_PTR
	output_buf; /*host side stores the data buffer returned by fw. Data: fw->host*/
	T_SMI_BUF_PTR
	input_buf; /*host side to write fw's data buffer. Data: host->fw*/
	int errcode; /*Call kernel ioctl to return a value*/
} T_SMI_IOCTL_TRANS_DATA;

typedef struct SMI_DEV_PCIE_BUS_ID {
	int dev_id;
	char pcie_port[16];
} TS_SMI_DEV_PCIE_BUS_ID;

typedef struct SMI_DEV_PCIE_ID {
	int dev_id;
	unsigned int pcie_id;
} TS_SMI_DEV_PCIE_ID;

typedef struct SMI_DEV_PCIE_SUB_ID {
	int dev_id;
	unsigned int pcie_sub_id;
} TS_SMI_DEV_PCIE_SUB_ID;

typedef struct SMI_DEV_MAJOR_MINOR {
	int dev_id;
	unsigned int major_minor;
} TS_SMI_DEV_MAJOR_MINOR;

typedef struct SMI_DIE_RENDER {
	int dev_id;
	int die_id;
	char render[16];
} TS_SMI_DIE_RENDER;

typedef struct SMI_DEVICE_CAPABILITY {
	int dev_id;
	int die_id;
	struct vastai_dev_info capability;
} SMI_DEVICE_CAPABILITY;

#define VASTAI_BUF_SIZE_32  (32)
#define VASTAI_CMD_READ_LEN (4096)
struct tools_file_info {
	struct vatools_node *node;
	char file_name[VASTAI_BUF_SIZE_32];
	dev_t dev_num;
	struct cdev dev;
	struct class *class;
	struct device *device;
};

enum TOOLS_ARG_INDEX {
	TOOLS_ARG_ADDR,
	TOOLS_ARG_VAL,
	TOOLS_ARG_LEN,
	TOOLS_ARG_DEVICE_ID,
	TOOLS_ARG_DIE_ID,
	TOOLS_ARG_DIE_SEQ,
	TOOLS_ARG_DIE_INDEX,
	TOOLS_ARG_SRC_DIE_INDEX,
	TOOLS_ARG_SRC_AXI_ADDR,
	TOOLS_ARG_DST_DIE_INDEX,
	TOOLS_ARG_DST_BAR_ADDR,
	TOOLS_ARG_DST_AXI_ADDR,
	TOOLS_ARG_TRANS_SIZE,
	TOOLS_ARG_DIRECTION,
	TOOLS_ARG_TRANS_LOOP,
	TOOLS_ARG_MAX,
};

struct tools_test_arg_t {
	unsigned char id;
	unsigned char *name;
	unsigned long def;
};

struct tools_char_drv_info {
	struct tools_file_info file_info;
	struct tools_test_arg_t args[TOOLS_ARG_MAX];
	uint8_t rsv[16];
};

typedef int (*tools_cmd_function_t)(struct tools_char_drv_info *,
				    struct vastai_pci_info *);

struct tools_test_info {
	char *cmd;
	tools_cmd_function_t pFunc;
};

/*The ringbuf size where the event data is saved*/
#define EVENT_FIFO_LENGTH (2 * 1024 * 1024)

/*Get the Event Reset status*/
/*CORE_POINT_CMCU does not represent the CMCU, but represents the entire ai-sys, including all cores of the entire
 * ai-sys; SMCU does not have a reset; The others represent their respective core resets*/
enum device_common_event_e {
	EVT_RESET_START = RESET_START, /*reset starts*/
	EVT_RESET_STOP =
		RESET_END, /*reset completes and returns to the normal state*/
	EVT_COMMON_MAX = 10 /*common event, There can only be a maximum of 10*/
};

/*Event definition for VEMCU video event submodule/core, starting from 11*/
enum vemcu_exception_event_e {
	VCENC_EXCEPTION_ERROR = 11,
	VCENC_EXCEPTION_NULL_ARGUMENT, /**ERROR Null argument**/
	VCENC_EXCEPTION_INVALID_ARGUMENT, /**ERROR Invalid argument*/
	VCENC_EXCEPTION_INVALID_STATUS, /*VCEncStrmEncode: ERROR Invalid status*/
	VCENC_EXCEPTION_INVALID_GOPSIZE, /*VCEncStrmEncode: ERROR Invalid gopSize*/
	VCENC_EXCEPTION_NOTCODED_FRAME, /*VCEncStrmEncode: ERROR Invalid coding type*/
	VCENC_EXCEPTION_STREAM_BUFFER, /*VCEncStrmEncode: ERROR Invalid output stream buffer*/
	VCENC_EXCEPTION_TOO_SMALL_OUTPUT_STREAM_BUFFER, /*VCEncStrmEncode: ERROR Too small output stream buffer*/
	VCENC_EXCEPTION_NOT_SUPPORT_MULTI_CORE, /*VCEncStrmEncode: multi-segment not support multi-core*/
	VCENC_EXCEPTION_INVALID_BASELINE_PROFILE, /*VCEncSetCodingCtrl: ERROR Invalid frame type for baseline profile*/
	VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAV, /*VCEncStrmEncode: ERROR Invalid input busChromaV*/
	VCENC_EXCEPTION_INVALID_INPUT_BUS_CHROMAU, /*VCEncStrmEncode: ERROR Invalid input busChromaU*/
	VCENC_EXCEPTION_INVALID_INPUT_BUSLUMA, /*VCEncStrmEncode: ERROR Invalid input busLuma*/
	VCENC_EXCEPTION_INVALID_INPUT_FORMAT, /*VCEncStrmEncodeExt: ERROR Invalid input format*/
	VCENC_EXCEPTION_INVALID_INPUT_BUSLUMASTAB, /*VCEncStrmEncodeExt: ERROR Invalid input busLumaStab*/
	VCENC_EXCEPTION_MEMORY_ERROR, /**ERROR Memery error*/
	VCENC_EXCEPTION_EWL_ERROR, /**ERROR Invalid argument*/
	VCENC_EXCEPTION_EWL_MEMORY_ERROR, /**ERROR Ewl Memery error*/
	VCENC_EXCEPTION_OUTPUT_BUFFER_OVERFLOW, /**ERROR Revert FrameNum Update on output buffer overflow*/
	VCENC_EXCEPTION_HW_BUS_ERROR, /**ERROR Hardware bus error*/
	VCENC_EXCEPTION_HW_DATA_ERROR, /**ERROR Hardware data error*/
	VCENC_EXCEPTION_HW_TIMEOUT, /**ERROR hardware timeout*/
	VCENC_EXCEPTION_HW_RESERVED, /**ERROR Hardware reserved*/
	VCENC_EXCEPTION_SYSTEM_ERROR, /**ERROR System error*/
	VCENC_EXCEPTION_INSTANCE_ERROR, /**ERROR Instance error*/
	VCENC_EXCEPTION_HRD_ERROR, /**ERROR Hrd error*/
	VCENC_EXCEPTION_HW_RESET, /**ERROR Hardware reset*/
	VCENC_EXCEPTION_HASH_LEN_MISMATCH, /**ERROR Hash len mismatch*/
	VCENC_EXCEPTION_FW_RESET, /**ERROR FW reset*/
	VCENC_EXCEPTION_INSATANCE_CHECK_MISMATCH, /**ERROR Instance check mismatch*/
	VCENC_EXCEPTION_IM_RESET, /**ERROR hantrovcmd_isr failed. im reset dev->hwregs*/
	VCENC_EXCEPTION_ENCODE_EXT_MCU_V2, /**ERROR  VCEncStrmEncodeExt_mcu_V2*/
	VCENC_EXCEPTION_HANDLE_ENCODER_ISR, /**ERROR  HandleEncoderIsr failed*/
	VCENC_EXCEPTION_HANG_HANTRO_RESET_ISR_FAILED, /**FAILED hang reset hantrovcmd_isr failed irq*/
	VCENC_EXCEPTION_HANTRO_VCMD_ISR_TIMEOUT, /**ERROR hantrovcmd_isr error timeout*/
	VCDEC_EXCEPTION_RESERVED /**ERRORR decoder reserved*/
};

/*reset event iInformation*/
typedef struct device_event_s {
	u64 timestamp_ns; /*The time when the event occurred*/
	u32 die_index;
	u32 core_index;
	u32 event;
} device_event_t;

/*tools command interface*/
typedef struct vatools_cmd {
	union ucmd {
/*Apply for DMA space*/
#if (TOOLS_WIN == 1)
		/*on windows*/
		/*Apply for DMA space*/
		struct {
			struct dma_buf *dma_buf_fd;
			UINT64 hostva; /*no use*/
			u32 size;
			u32 die_index;
		} alloc_cmd;
		/*Start DMA transfer*/
		struct {
			u32 is_dev_to_host;
			struct dma_buf *dma_buf_fd;
			u64 axi_addr;
			u32 size;
			u32 die_index;
		} dma_start_cmd;
		/*User-space memory is passed directly to the kernel, no DMA Alloc memory is required before use*/
		struct {
			u32 is_dev_to_host;
			void *vir_addr;
			u64 axi_addr;
			u32 length;
			u32 die_index;
			int pid;
		} dma_trans_cmd;
		struct {
			u32 is_dev_to_host;
			u32 die_index;
			u64 axi_addr;
			struct vastai_channel_buf *channel_buf;
			int channel_num;
			int pid;
		} dma_trans_sg_cmd;

#else
		/*platform*/
		/*on linux*/
		struct {
			u32 size;
			int dma_buf_fd;
			u32 die_index;
		} alloc_cmd;
		/*Start DMA transfer*/
		struct {
			u32 is_dev_to_host;
			int dma_buf_fd;
			u64 axi_addr;
			u32 size;
			u32 die_index;
		} dma_start_cmd;
		/*User-space memory is passed directly to the kernel, no DMA Alloc memory is required before use*/
		struct {
			u32 is_dev_to_host;
			u64 vir_addr;
			u64 axi_addr;
			u32 length;
			u32 die_index;
			int pid;
		} dma_trans_cmd;
		struct {
			u32 is_dev_to_host;
			u32 die_index;
			u64 axi_addr;
			struct vastai_channel_buf *channel_buf;
			int channel_num;
			int pid;
		} dma_trans_sg_cmd;
#endif /*end of platform*/
		struct {
			u32 die_index;
			u32 timeout_water;
			u32 is_timeout;
			u64 log_ring_ctl;
		} log_poll_cmd;
		struct {
			u32 die_index;
			u64 addr;
			u32 size;
			u64 buf;
		} access_mem_cmd;
		struct {
			u32 event_count;
			device_event_t buf[0];
		} event;
	} cmd;
} T_VATOOLS_CMD;

/*PCIe command, do not use smcu. Direct access to the driver*/
enum e_pcie_cmd_flag {
	PCIE_CMD_FLAG_NONE = 0, /*not*/
	PCIE_CMD_FLAG_BANDWIDTH = 1, /*Obtain the PCI bandwidth*/
	PCIE_CMD_FLAG_RESET = 2, /*device reset*/
	PCIE_CMD_FLAG_REBOOT = 3, /*device reboot*/
	PCIE_CMD_FLAG_STRING = 4, /*Flexible text command*/
	PCIE_CMD_FLAG_FW_VERSION = 5, /*Get the firmware version*/
	PCIE_CMD_FLAG_DDR_ECC_1BIT = 6, /*Get DDR ECC 1-bit error data*/
	PCIE_CMD_FLAG_DDR_ECC_2BIT = 7, /*Get DDR ECC 2bit error data*/
	PCIE_CMD_FLAG_VDSP_COUNT = 8, /*Get VDSP stats*/
	PCIE_CMD_FLAG_AI_COUNT = 9, /*Get AI stats. 512 bytes.*/
	PCIE_CMD_FLAG_RING_BUF_STATISTIC = 10, /*Get ring buffer stats*/
	PCIE_CMD_FLAG_SET_VIDEO_MULTI_CORE =
		11, /*Set video to use multicore; 0: Not used; 1: Use*/
	PCIE_CMD_FLAG_GET_VIDEO_MULTI_CORE =
		12, /*Read video multicore mode and job count*/
	PCIE_CMD_FLAG_FW_VERSION_V2 =
		13, /*Get the FW version number, read all dies*/
	PCIE_CMD_FLAG_GET_BOX_TYPE = 14, /*Get the bbox type*/
	PCIE_CMD_FLAG_HEART_BEAT = 15, /*core heartbeat*/
	PCIE_CMD_FLAG_BOOT = 16, /*device boot*/
	PCIE_CMD_FLAG_BARRESET = 17, /*bar reset*/
	PCIE_CMD_FLAG_BARSTATUS = 18, /*bar status*/
	PCIE_CMD_FLAG_REBOOT_DDRBW = 19, /*Switch to DDR bandwidth bin*/
	PCIE_CMD_FLAG_REBOOT_PCIEDMA = 20, /*Switch to test PCIE DMA bandwidth*/
	PCIE_CMD_FLAG_RUNTIME_INFO = 21, /*Get runtime info*/
	PCIE_CMD_FLAG_CURRENT_PROCESS_INFO =
		22, /*Get the current process info*/
	PCIE_CMD_FLAG_HEART_BEAT_COUNT = 23, /*Get heartbeat stats*/
	PCIE_CMD_FLAG_DDR_BANDWIDTH = 24, /*Get DDR bandwidth statistics*/
	PCIE_CMD_FLAG_CARD_CPU_TOPO =
		25, /*Obtain the topology relationship between the device and the CPU*/
	PCIE_CMD_FLAG_GFX_CMD = 26, /*Get gfx data*/
	PCIE_CMD_FLAG_RING_BUF_FROM_HW_CFG =
		27, /*Get ringbuf info from hw cfg*/
	PCIE_CMD_FLAG_ERR_INFO_READ = 28, /*Obtain the alarm message*/
	PCIE_CMD_FLAG_DDR_BANDWIDTH_MONITOR =
		29, /*Get DDR bandwidth statistics*/
	PCIE_CMD_FLAG_VF_VGPU_INFO_GET = 30, /*Get vf gpu/mem utilization*/
	PCIE_CMD_FLAG_VF_VIDEO_INFO_GET = 31, /*Get vf video utilization*/
	PCIE_CMD_FLAG_PCIE_BANDWIDTH_MONITOR =
		32, /*Get PCIe bandwidth statistics*/
	PCIE_CMD_FLAG_VIDEO_CMD = 33, /*Video sub Instructions*/
	PCIE_CMD_FLAG_DIAG_CMD = 34, /*diag sub instructions*/
	PCIE_CMD_FLAG_GET_VF_VERSION = 35, /*get vf version*/
	PCIE_CMD_FLAG_GET_PF_VF_MAP = 36, /*get pf->vf mapping*/
	PCIE_CMD_FLAG_GET_ADDR_MAP = 37, /*get hw address map*/
	PCIE_CMD_FLAG_GET_RDMA_FD = 38, /*get hw address map*/
	PCIE_CMD_FLAG_GET_VM_GUEST_OS_INFO = 39, /*get vm guest os info*/
	PCIE_CMD_FLAG_GET_VF_VGPU_MEMORY_USAGE =
		40, /*host trigger guest, write memory info to device buffer*/
	PCIE_CMD_FLAG_GET_VF_VGPU_PROCESS_GPU_UTILIZATION =
		41, /*host trigger guest, write process utilization to device buffer.*/
	PCIE_CMD_FLAG_GET_VF_VGPU_PROCESS_MEMORY_USAGE = 42,
	/* host trigger guest, write process memory usage to device buffer.*/
	PCIE_CMD_FLAG_MAX,
};

typedef struct S_HOST_ARG_VAL {
	/*0, cmd, driver needs to send interrupt to fw after receiving it 1, data, driver is only responsible for
	 * reading and writing data, and does not send interrupt to fw*/
	unsigned int nType;
	void *pcBuf;
} T_HOST_ARG_VAL;

/*Inter-process mutex structure*/
struct vatools_process_mutex {
	struct list_head list_member_process_mutex;
	struct list_head list_head_filp;
	struct mutex process_mutex;
	char mutex_name[256]; /*Mutex name, the same name is the same mutex*/
};

/*file* linked list*/
struct vatools_process_mutex_filp {
	struct list_head list_member_filp;
	struct file *filp;
};

/*filter struct size same as video*/
#pragma pack(push)
#pragma pack(4)

enum EModuleType {
	PROFILER_ENCODER,
	PROFILER_DECODER,
};

struct TVChanInfo {
	u32 dwStructVer;
	u32 dwSize;
	s32 nChanID;
	s32 nDieID;
	s32 nDeviceID;
	u32 dwMemSize;
	s32 nChanFlag;
	s32 nCoreID;
	s32 nReserved;
	enum EModuleType eModuleType;
};

struct TVdecStatis {
	struct TVChanInfo tVChanInfo;
	u32 dwDecType;
	u32 dwFrameRate;
	u32 dwRecvFrame;
	u32 dwLoseFrame;
	u32 dwPackError;
	u32 dwFullLose;
	u32 dwBitRate;
	u32 dwAvrVideoBitRate;
	u32 dwDecWidth;
	u32 dwDecHeight;
	u32 dwDecInputCnt;
	u32 dwDecOutputCnt;
	u32 dwFramesLeft;
	u32 dwMcuCcount;
	u32 dwTotalCycle;
	u32 dwReserved[8];
};

struct TVencStatis {
	struct TVChanInfo tVChanInfo;
	s32 nFrameRate;
	s32 nBitRate;
	s32 nAvrBitRate;
	s32 nIdrCount;
	s32 nUsrForceIdrCnt;
	s32 nEncInputCnt;
	s32 nEncOutputCnt;
	s32 nFailedNum;
	s32 nAvgTimeCost;
	s32 nMaxTimeCost;
	u32 dwEncoderVersion;
	u32 dwMcuCcount;
	u32 dwTotalCycle;
	u32 dwReserved[8];
};

struct TVencBasicParams {
	struct TVChanInfo tVChanInfo;
	s32 nEncWidth;
	s32 nEncHeight;
	s32 nRdoLevel;
	s32 nGopSize;
	s32 nCompressor;
	s32 nEnableRdoQuant;
	u32 dwEncType;
	u32 dwBitRate;
	u32 u32FrameRate;
	u32 dwGOP;
	u32 dwProfile;
	u32 dwLevel;
	u32 dwPicOrderCountType;
	u32 dwLoopFilterMask;
	u32 dwEnctroyMode;
	u32 dwDeblockMode;
	u32 dwSliceMode;
	u32 dwSliceSize;
	u32 dwFmoMode;
	u32 dw8x8Mode;
	u32 dwTwoPass;
	u32 dwQualityLevel;
	u32 dwWeight;
	u32 dwReserved[8];
};

struct TVencRcParams {
	struct TVChanInfo tVChanInfo;
	s32 dwRcMode;
	s32 nIMaxQuant;
	s32 nIMinQuant;
	s32 nPBMaxQuant;
	s32 nPBMinQuant;
	s32 nAvgQpI;
	s32 nAvgQpP;
	s32 nHrdSize;
	s32 nInitQp;
	s32 nPicRc;
	s32 nBlkRc;
	s32 nPskip;
	s32 nBitrateWindow;
	s32 nMaxBitrate;
	s32 nTargBitrate;
	s32 nStatTimeSeconds;
	u32 dwReserved[8];
};

typedef struct tagVencSwRegs {
	struct TVChanInfo tVChanInfo;
	s32 nDeviceID;
	s32 nDieID;
	s32 nCoreID;
	u32 dwSwreg215;
	u32 dwSwreg216;
	u32 dwSwreg217;
	u32 dwSwreg218;
	u32 dwSwreg219;
	u32 dwSwreg220;
	u32 dwSwreg221;
	u32 dwSwreg222;
	u32 dwSwreg223;
	u32 dwSwreg82;
} TVencSwRegs;
typedef struct tagVcodecInfo {
	struct TVChanInfo tVChanInfo;
	struct TVdecStatis tVdecStats;
	struct TVencStatis tVencStats;
	struct TVencBasicParams tVencBasicParams;
	struct TVencRcParams tVencRcParams;
	u32 dwReserved[8];
} TVcodecInfo;

#define SHAREMEM_VERSION_SV100	 0x1
#define SHAREMEM_VERSION_SG100	 0x2
#define SHAREMEM_VERSION_OFFSET	 24 /*offset bit*/
#define SHAREMEM_VERSION_INITIAL 0x1
struct vatools_sharemem_filter {
	struct TVChanInfo head;
	u32 version;
	int32_t vpid;
	int32_t tid;
	uint64_t ns;
	uint32_t level;
	uint64_t timestamp_ns;
	uint32_t element_len;
	uint32_t fn_index;
	uint32_t rsvd[14];
	uint32_t data_len;
	struct docker_info docker_env;
	uint8_t array[0];
};

union vatools_filter {
	/*uint8_t date[452];*/
	/*TVcodecInfo info;*/
	struct vatools_sharemem_filter filter_info; /*sharemem filter;*/
};
#pragma pack(pop)

// ac_bench_test struct
#pragma pack(push)
#pragma pack(1)
#define AC_BENCH_TEST_SIZE	 512
#define AC_BENCH_DMA_DEV_TO_HOST 1
#define AC_BENCH_DMA_HOST_TO_DEV 0

#define AC_BENCH_DMA_P2P_FROM_TO 1
#define AC_BENCH_DMA_P2P_TO_FROM 0

#define AC_BENCH_DMA_PORT_2_PORT     1
#define AC_BENCH_BAR_P2P	     VASTAI_PCI_BAR2
#define AC_BENCH_TEST_P2P_BAR_OFFSET 0x100000000
#define AC_BENCH_TEST_DMA_RSV	     0x40
#define AC_BENCH_TEST_MAX_LOOP	     10000
enum {
	AC_BENCH_DMA_ALLOC = 1,
	AC_BENCH_DMA_FREE,
	AC_BENCH_DMA_START,
	AC_BENCH_DMA_P2P,
	AC_BENCH_DMA_D2D,
	AC_BENCH_COMPLEX_ROUTINE_TEST,
};
struct vatools_dma_pack {
	union die_index_data die_index;
	uint32_t size;
	int dma_buf_fd;
	uint64_t axi_addr;
	uint64_t pcie_bar_addr;
	uint64_t virt_addr;
	uint32_t direction;
};
struct vatools_ac_bench_dma {
	uint32_t routine_select;
	uint32_t ac_bench_dma_version;
	uint32_t ac_bench_dma_type;
	uint32_t pid;
	uint64_t buf_u;
	uint32_t buf_u_len;
	uint32_t loop;
	uint32_t suc_cnt;
	uint32_t fail_cnt;
	uint32_t direction;
	uint32_t rsv[AC_BENCH_TEST_DMA_RSV];
	struct vatools_dma_pack from;
	struct vatools_dma_pack to;
};
union vatools_ac_bench {
	uint8_t array[AC_BENCH_TEST_SIZE];
	struct vatools_ac_bench_dma dma_info;
};

#pragma pack(pop)

#ifndef CONFIG_TOOLS_V2

#define MAX_OCCUPY_DIE_NUM	 (VASTAI_DIE_MAX_NUM * MAX_DEVICE_NUM_PER_MANAGER)
#define MAX_VIDEO_DIE_CAPABILITY 20000
#define MIN_VIDEO_DIE_CAPABILITY 0
#define MAX_OCCUPY_DIE_SINGLE	 128

enum {
	ALLOC_VIDEO_ENCODE,
	ALLOC_VIDEO_DECODE,
	ALLOC_VIDEO_MAX,
};
struct vatools_video_cap_query {
	/*The app calls the input parameter*/
	u32 version; /*version number, now write 0*/
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
	u8 flag_specify_die; /*0: Not specified 1: specify die*/
	u8 flag_allocate_policy; /*Allocation policy method: 0: Take the lowest resource occupation die*/
	u8 flag_rsvd;
	u32 die_weight; /*allocated die weight*/
	u32 specified_die_seq; /*specified die seq*/

	/*interface returns data*/
	/*optimal die seq*/
	u32 die_seq;
	u32 die_weight_total; /*die The value of the resource after being allocated by this request*/
	u32 rsvd[16];
	u32 die_array_len;
	u8 die_array[MAX_OCCUPY_DIE_SINGLE];
};

struct vatools_occupy_die {
	u32 die_seq;
	u32 die_weight;
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
};

#if (TOOLS_WIN == 1)
#pragma pack(push)
#pragma pack(8)
#endif
#define RT_INFO_HEAD_BUF_SIZE	      (1024 * 1024)
#define RT_ZONE_USAGE_BUF_SIZE	      (1024 * 1024)
#define RT_PROCESS_INFO_BUF_SIZE      (1024 * 1024 * 10)
#define RT_VACC_PROCESS_INFO_BUF_SIZE (1024 * 1024 * 10)
#define DEVINFO_REFRESH_INTERVAL      60 /* s */
struct vatools_node {
	wait_queue_head_t wq;
	struct mutex node_mutex;
	/*lupa add 2021-12-23 begin resource locks for the entire business. Ensure that resources are exclusive when
	 * processing the business*/
	struct mutex node_sharedmem_mutex;
	struct mutex node_common_mutex;
	struct mutex node_profiler_mutex;
	struct mutex node_debugger_mutex;
	struct mutex node_logger_mutex;
	struct mutex node_smi_mutex;

	/*lupa add 2021-12-23 end Resource lock for the entire business. Ensure that resources are exclusive when
	 * processing the business*/
	struct list_head list_nodes;
	void *pci_dev;
	unsigned char *node_buffer;
	unsigned int size;
	unsigned int
		rsv; /*8-byte alignment is required to adapt to the ARM server*/
	struct list_head list_node_readers;
	struct list_head list_node_process_mutex;

	/*pcie dma / msg ringbuf, for profiler timeline*/
	void *profiler_dma_ringbuf;
	void *profiler_msg_ringbuf;

	/*core event ringbuf*/
	void *event_ringbuf;
	/*core event mutex*/
	struct mutex event_mutex;
	/*Wait for core's event; For example, the reset event*/
	wait_queue_head_t event_wait_queue;
	struct vatools_occupy_die die_weights[ALLOC_VIDEO_MAX]
					     [MAX_OCCUPY_DIE_NUM];
	struct vatools_occupy_die die_weights_real[ALLOC_VIDEO_MAX]
						  [MAX_OCCUPY_DIE_NUM];
	/*app ringbuf, for profiler timeline*/
	void *profiler_app_ringbuf;

	// pre alloc runtime buffer
	struct mutex rt_buf_mutex;
	u8 *rt_info_head_buf;
	u8 *rt_zone_usage_buf;
	u8 *rt_process_info_buf;
	u8 *rt_vacc_process_info_buf;

	u64 last_refresh_time;
	struct tools_char_drv_info *drv;
	struct mutex inventory_cache_mutex;

	atomic_t ut_enable;
};

enum va_f_type {
	VATOOLS_OPEN,
	VATOOLS_READ,
	VATOOLS_WRITE,
	VATOOLS_IOCTL,
	VATOOLS_CLOSE,
};

struct vatools_pid_entry {
	int refcount;
	struct pid *pid;
	struct list_head node;
	enum va_f_type type;
	int nr_pid;
};
#if (TOOLS_WIN == 1)
#pragma pack(pop)
#endif

struct vatools_reader {
	struct vatools_node *node;

	struct list_head list_readers;
	struct list_head
		malloc_pointers; /*TODO: Holds the memory pointer of each open fd request, and if the fd is
					     closed, loops to free up space*/

	/*sharedmem*/
	struct list_head t_sharedmem_mem_info_head;
	/*struct list_head t_sharedmem_signal_info_head;*/
	/*Add a semaphore to trigger a wait event*/
	struct completion
		debug_comp; /*Used to record the trigger signal using lupa add 2021-12-15*/
	struct fasync_struct *sharedmem_pt_fasync;
	struct mutex sharedmem_mutex;
	int n_sharedmem_init_done; /*Indicates whether it has been initialized; 1 - Complete Initialization 0 - Not
				      Initialized*/

	/*reader generic variable. Not yet used.*/
	size_t r_off;
	int r_all; /*Compatible with ARM servers. Change the boot type to int*/
	int r_ver;
	unsigned int
		profiler_checkpoint_corebitmap; /*Record the core with the Profiler checkpoint enabled, and use the
							corebitmap record, one bit per core*/

	T_SMI_IOCTL_TRANS_CATEGORY
	trans_category; /*Adapt to the structure of the arm server and the host, and pay attention to the 8 byte
			   alignment*/
	int exit; /*Whether to exit*/
	/*Adapt to the ARM server, 8-byte alignment is required, trans_category is not modified for the time being, here
	 * the reserved field alignment is used.*/
	u64 event_timestamp_ns; /*identifies that this time, as well as previous events, have been sent to the host
				   thread; This time is updated each time an event is sent to the host*/
	/*share mem filter*/
	union vatools_filter filter;
	struct vatools_occupy_die own_dies;
	struct vatools_occupy_die real_own_dies;
};

#endif

typedef struct VASTAI_FIFO_HEADER {
	u32 rd;
	u32 wr;
	u32 elem_count;
	u32 elem_size;
} T_VASTAI_FIFO_HEADER;
typedef struct VASTAI_FIFO_HEADER_WITHNAME {
	u32 rd;
	u32 wr;
	u32 elem_count;
	u32 elem_size;
	char name[CMD_BUF_NAME_LONG];
} T_VASTAI_FIFO_HEADER_WITHNAME;
typedef struct RING_BUF_STATITCS {
	u32 base_addr;
	char name[CMD_BUF_NAME_LONG];
} T_RING_BUF_STATICS;

/*NOTE: The above definition, app, driver need to be consistent, copied to each application*/

/*CSRAM defines the data address*/
#define PERFORMANCE_AI_LEN (512) /*sv100 512 bytes*/
#define DDR_ECC_1BIT_SIZE  (1024) /*use csram to store ecc , 1k bytes*/
#define DDR_ECC_2BIT_SIZE  (1024) /*use csram to store ecc , 1k bytes*/
/*Reading this address triggers bar2 to switch to bar2 as the default address*/
#define DDR_PCIE_BARRESET 0x814000000

/*VEMCU ring buff*/
#define PERFORMANCE_HOST_2_VEMCU0 (CSRAM_BASE_ADDR + 0x56000)
#define PERFORMANCE_HOST_2_VEMCU1 (CSRAM_BASE_ADDR + 0x56400)
#define PERFORMANCE_HOST_2_VEMCU2 (CSRAM_BASE_ADDR + 0x56800)
#define PERFORMANCE_HOST_2_VEMCU3 (CSRAM_BASE_ADDR + 0x56C00)
/*VDMCU ring buf*/
#define PERFORMANCE_SMCU_2_VDMCU0   (CSRAM_BASE_ADDR + 0x3E000)
#define PERFORMANCE_VDSP0_2_VDMCU0  (CSRAM_BASE_ADDR + 0x3E400)
#define PERFORMANCE_VDSP1_2_VDMCU0  (CSRAM_BASE_ADDR + 0x3E800)
#define PERFORMANCE_VEMCU0_2_VDMCU0 (CSRAM_BASE_ADDR + 0x3EC00)
#define PERFORMANCE_VEMCU1_2_VDMCU0 (CSRAM_BASE_ADDR + 0x3F000)
#define PERFORMANCE_SMCU_2_VDMCU1   (CSRAM_BASE_ADDR + 0x3F400)
#define PERFORMANCE_VDSP1_2_VDMCU1  (CSRAM_BASE_ADDR + 0x3F800)
#define PERFORMANCE_VDSP2_2_VDMCU1  (CSRAM_BASE_ADDR + 0x3FC00)
#define PERFORMANCE_VEMCU1_2_VDMCU1 (CSRAM_BASE_ADDR + 0x40000)
#define PERFORMANCE_VEMCU2_2_VDMCU1 (CSRAM_BASE_ADDR + 0x40400)
#define PERFORMANCE_SMCU_2_VDMCU2   (CSRAM_BASE_ADDR + 0x40800)
#define PERFORMANCE_VDSP2_2_VDMCU2  (CSRAM_BASE_ADDR + 0x40C00)
#define PERFORMANCE_VDSP3_2_VDMCU2  (CSRAM_BASE_ADDR + 0x41000)
#define PERFORMANCE_VEMCU2_2_VDMCU2 (CSRAM_BASE_ADDR + 0x41400)
#define PERFORMANCE_VEMCU3_2_VDMCU2 (CSRAM_BASE_ADDR + 0x41800)
/*CMCU ring buf*/
#define PERFORMANCE_VDSP0_2_CMCU (CSRAM_BASE_ADDR + 0x49400)
#define PERFORMANCE_VDSP1_2_CMCU (CSRAM_BASE_ADDR + 0x49800)
#define PERFORMANCE_VDSP2_2_CMCU (CSRAM_BASE_ADDR + 0x49C00)
#define PERFORMANCE_VDSP3_2_CMCU (CSRAM_BASE_ADDR + 0x4A000)
/*VDSP ring buf*/
#define PERFORMANCE_CMCU_2_VDSP0 (CSRAM_BASE_ADDR + 0x45400)
#define PERFORMANCE_CMCU_2_VDSP1 (CSRAM_BASE_ADDR + 0x46000)
#define PERFORMANCE_CMCU_2_VDSP2 (CSRAM_BASE_ADDR + 0x47000)
#define PERFORMANCE_CMCU_2_VDSP3 (CSRAM_BASE_ADDR + 0x48000)
#define PERFORMANCE_HOST_2_VDSP0 (CSRAM_BASE_ADDR + 0x57000)
#define PERFORMANCE_HOST_2_VDSP1 (CSRAM_BASE_ADDR + 0x57400)
#define PERFORMANCE_HOST_2_VDSP2 (CSRAM_BASE_ADDR + 0x57800)
#define PERFORMANCE_HOST_2_VDSP3 (CSRAM_BASE_ADDR + 0x57C00)
/*HOST(PCIE) ring buf*/
#define PERFORMANCE_SMCU0_2_HOST  (CSRAM_BASE_ADDR + 0x51800)
#define PERFORMANCE_SMCU1_2_HOST  (CSRAM_BASE_ADDR + 0x51C00)
#define PERFORMANCE_VDMCU0_2_HOST (CSRAM_BASE_ADDR + 0x52000)
#define PERFORMANCE_VDMCU1_2_HOST (CSRAM_BASE_ADDR + 0x52400)
#define PERFORMANCE_VDMCU2_2_HOST (CSRAM_BASE_ADDR + 0x52800)
#define PERFORMANCE_VEMCU0_2_HOST (CSRAM_BASE_ADDR + 0x52C00)
#define PERFORMANCE_VEMCU1_2_HOST (CSRAM_BASE_ADDR + 0x53000)
#define PERFORMANCE_VEMCU2_2_HOST (CSRAM_BASE_ADDR + 0x53400)
#define PERFORMANCE_VEMCU3_2_HOST (CSRAM_BASE_ADDR + 0x53800)
#define PERFORMANCE_VDSP0_2_HOST  (CSRAM_BASE_ADDR + 0x53C00)
#define PERFORMANCE_VDSP1_2_HOST  (CSRAM_BASE_ADDR + 0x54000)
#define PERFORMANCE_VDSP2_2_HOST  (CSRAM_BASE_ADDR + 0x54400)
#define PERFORMANCE_VDSP3_2_HOST  (CSRAM_BASE_ADDR + 0x54800)
/*Host(DMA) ring buf*/
#define PERFORMANCE_DMA_HOST_2_DEV (CSRAM_BASE_ADDR + 0x00014000)
#define PERFORMANCE_DMA_DEV_2_HOST (CSRAM_BASE_ADDR + 0x00014000 + 0xA000)
#define PERFORMANCE_DMA_RC_IN	   (CSRAM_BASE_ADDR + 0x00014000 + 0xA000 * 2)
#define PERFORMANCE_DMA_RC_OUT	   (CSRAM_BASE_ADDR + 0x00014000 + 0xA000 * 3)

/*-----------------------------------------------------------------------*/
/*profiler host interface*/
/*-----------------------------------------------------------------------*/
/*The application layer calls the API*/
#define MAX_HW_MONITOR_NUM 4
#define MAX_ODMA_NUM	   2
#define MAX_DLC_NUM	   8
#define MAX_MC_NUM	   4

typedef struct T_ENABLE_CLR_MODE_FW_s {
	union {
		u32 n_whole; /*total value*/
		struct {
			u32 n_axiyall_enable : 1; /*enable all bit*/
			u32 n_axi0_enable : 1; /*enable axi0 bit*/
			u32 n_axi1_enable : 1; /*enable axi1 bit*/
			u32 n_axi2_enable : 1; /*enable axi2 bit*/
			u32 n_axi3_enable : 1; /*enable axi3 bit*/
			u32 n_axi4_enable : 1; /*enable axi4 bit*/
			u32 n_axi0_clr : 1; /*clear axi0 bit*/
			u32 n_axi1_clr : 1; /*clear axi1 bit*/
			u32 n_axi2_clr : 1; /*clear axi2 bit*/
			u32 n_axi3_clr : 1; /*clear axi3 bit*/
			u32 n_axi4_clr : 1; /*clear axi4 bit*/
			u32 n_cnt_mode : 1; /*clear axi5 bit*/
			u32 n_report_mode : 8;
		};
	};
} T_ENABLE_CLR_MODE_FW;

/*report mode struct*/
typedef struct T_REPORT_MODE_FW_s {
	union {
		u8 n_whole; /*total value*/
		struct {
			u8 n_outstand_sel : 1; /*outstand selector bit*/
			u8 n_cmd_sel : 1; /*command selector bit*/
			u8 n_bandwith_sel : 1; /*bandwidth selector bit*/
			u8 n_latency_sel01 : 1; /*latency01 selector bit*/
			u8 n_latency_sel23 : 1; /*latency23 selector bit*/
			u8 n_port_sel : 3; /*port selector*/
		};
	};
} T_REPORT_MODE_FW;

struct T_ADDR_VAL {
	u64 nAddr;
	u32 nLen;
	/*u64 pcBuf;*/
	void *pcBuf;
};

struct T_PERFMON_SEL {
	union {
		u32 n_whole;
		struct {
			u32 n_is_enable : 1;
			u32 n_is_start : 1;
			u32 n_is_stop : 1;
			u32 n_spare : 1;
			u32 n_index : 12;
		};
	};
	u32 n_data_sel;
	u32 n_timer;
};

typedef struct tar_perfmon_mc_fw {
	u32 n_val[6];
} T_PERFMON_MC_FW;

typedef struct tar_perfmon_fw {
	union {
		u32 n_whole;
		struct {
			u32 n_is_enable : 1;
			u32 n_is_start : 1;
			u32 n_is_stop : 1;
			u32 n_spare : 1;
			u32 n_index : 12;
		};
	};
	u8 n_data_sel[MAX_HW_MONITOR_NUM];
	u32 n_timer;
	u32 n_data[MAX_HW_MONITOR_NUM];
} T_PERFMON_FW;

struct T_PERFMON_DATA {
	T_PERFMON_FW tODMA[MAX_ODMA_NUM];
	T_PERFMON_FW tDLC[MAX_DLC_NUM];
	T_PERFMON_MC_FW tMC[MAX_MC_NUM];
};

/*-----------------------------------------------------------------------*/
/*smi cmd block*/
/*-----------------------------------------------------------------------*/

#define SMI_CMD_LOOP_TOTAL_COUNT (20) /*Total number of polls*/
#define SMI_CMD_LOOP_ADDING_COUNT                                              \
	(3) /*The number of times the polling duration is increased*/
#define SMI_CMD_LOOP_INTERVAL_START (2) /*Initial polling interval, in ms*/
#define SMI_CMD_LOOP_INTERVAL_ADDING                                           \
	(10) /*Increase the time interval each time, unit ms*/
/*-----------------------------------------------------------------------*/
/*driver internal define*/
/*-----------------------------------------------------------------------*/
#define VATOOLS_UNINIT	  0
#define VATOOLS_INIT_DONE 1

/*-----------------------------------------------------------------------*/
/*vadebugger start*/
/*-----------------------------------------------------------------------*/
#define VADBG_CSRAM_ADDR (0x08cf4400) /*debug used csram base address*/
#define VADBG_CSRAM_LEN	 (4096)
/*vadebugger end*/

/*profiler checkpoint start*/
/*profiler csram base address*/
/*#define PERFORMANCE_AI_BASE ( CSRAM_BASE_ADDR + 0x000F4000 )*/
#define PROFILER_CSRAM_ADDR (0x08CF4200)
/*profiler used csram size*/
#define PROFILER_CSRAM_LEN (512)
/*Number of SOC cores*/
#define PROFILER_CORE_COUNT CORE_NUMBER
/*Each core uses 512 KB*/
#define PROFILER_DDR_BUFFER_LEN 0x80000
/*csram saved profiler control data, each core 1 byte*/
#define PROFILER_CTRL_BASE_ADDR (PROFILER_CSRAM_ADDR)
/*csram saved rpwp address. RP accounts for 8 bytes lower and WP accounts for 8 bytes higher*/
#define PROFILER_RPWP_STARTADDR (PROFILER_CSRAM_ADDR + 0x20)
/*CSRAM holds the RP, WP length for each core. A total of 16bytes*/
#define PROFILER_RPWP_SIZE 0x10
/*Read rp, wp, host need to use mask, and only keep the low significant bits*/
#define PROFILER_CORE_BUF_WP_MASK (PROFILER_DDR_BUFFER_LEN - 1)
/*-----------------------------------------------------------------------*/
/*profiler checkpoint end*/
/*-----------------------------------------------------------------------*/
/*profiler The command code for collecting data*/
enum e_profiler_checkpoint_msg_type {
	PROFILER_CHECKPOINT_MSG_STOP = 0, /*Stop acquisition*/
	PROFILER_CHECKPOINT_MSG_START = 1, /*Start the collection*/
	PROFILER_CHECKPOINT_MSG_READ_RPWP =
		2, /*Read and write pointers. fw does not receive this command*/
	PROFILER_CHECKPOINT_MSG_WRITE_RPWP =
		3, /*Write read/write pointers. fw does not receive this command*/
	PROFILER_CHECKPOINT_MSG_READ_DATA =
		4, /*Read DDR data. fw does not receive this command*/
	PROFILER_CHECKPOINT_MSG_READ_CTRL = 5, /*Read control*/
	PROFILER_CHECKPOINT_MSG_READ_PCIE_DMA = 6, /*PCIE dma data acquisition*/
	PROFILER_CHECKPOINT_MSG_READ_PCIE_MSG = 7, /*PCIE msg data acquisition*/
	PROFILER_CHECKPOINT_MSG_WRITE_PCIE_APP =
		8, /*app data collection: write*/
	PROFILER_CHECKPOINT_MSG_READ_PCIE_APP = 9, /*app data collection: read*/
};

/*Define the data type of the timeline collection point u8*/
enum e_profiler_checkpoint_type {
	/*general*/
	PROFILER_CHECKPOINT_UNKNOWN = 0x00,
	PROFILER_CHECKPOINT_IDLE = 0x01,
	PROFILER_CHECKPOINT_DUTY_BEGIN = 0x02,
	PROFILER_CHECKPOINT_DUTY_END = 0x03,
	/*vdsp*/
	PROFILER_CHECKPOINT_HOST_TO_VDSP = 0x04,
	PROFILER_CHECKPOINT_VDSP_TO_HOST = 0x05,
	PROFILER_CHECKPOINT_OPCODE_BEGIN = 0x06,
	PROFILER_CHECKPOINT_OPCODE_END = 0x07,
	PROFILER_CHECKPOINT_VDSP_TO_CMCU = 0x08,
	PROFILER_CHECKPOINT_CMCU_TO_VDSP = 0x09,
	/*pcie*/
	PROFILER_CHECKPOINT_PCIE_DMA = 0x10, /*16*/
	PROFILER_CHECKPOINT_PCIE_MSG = 0x11, /*17*/
	PROFILER_CHECKPOINT_PCIE_DMA_HOST_TO_DEVICE = 0x12, /*18*/
	PROFILER_CHECKPOINT_PCIE_DMA_DEVICE_TO_HOST = 0x13, /*19*/
	PROFILER_CHECKPOINT_PCIE_DMA_HOST_TO_DEVICE_BANDWIDTH = 0x14, /*20*/
	PROFILER_CHECKPOINT_PCIE_DMA_DEVICE_TO_HOST_BANDWIDTH = 0x15, /*21*/
	PROFILER_CHECKPOINT_PCIE_APP = 0x16, /*22*/

	/*cmcu ping: bit7=0 pong: bit7=1*/
	PROFILER_CHECKPOINT_PING_MODEL_BEGIN = 0x70, /*112*/
	PROFILER_CHECKPOINT_PING_MODEL_END = 0x71, /*113*/
	PROFILER_CHECKPOINT_PING_LAYER_BEGIN = 0x72, /*114*/
	PROFILER_CHECKPOINT_PING_LAYER_END = 0x73, /*115*/
	PROFILER_CHECKPOINT_PING_TIMESTAMP = 0x74, /*116*/
	PROFILER_CHECKPOINT_PING_MODEL_DUTY = 0x75, /*117*/
	PROFILER_CHECKPOINT_PING_LAYER_DUTY = 0x76, /*118*/
	PROFILER_CHECKPOINT_PING_LAYER_OPCODE = 0x77, /*119*/

	PROFILER_CHECKPOINT_PONG_MODEL_BEGIN =
		PROFILER_CHECKPOINT_PING_MODEL_BEGIN | 0x80, /*240*/
	PROFILER_CHECKPOINT_PONG_MODEL_END =
		PROFILER_CHECKPOINT_PING_MODEL_END | 0x80, /*241*/
	PROFILER_CHECKPOINT_PONG_LAYER_BEGIN =
		PROFILER_CHECKPOINT_PING_LAYER_BEGIN | 0x80, /*242*/
	PROFILER_CHECKPOINT_PONG_LAYER_END =
		PROFILER_CHECKPOINT_PING_LAYER_END | 0x80, /*243*/
	PROFILER_CHECKPOINT_PONG_TIMESTAMP =
		PROFILER_CHECKPOINT_PING_TIMESTAMP | 0x80, /*244*/
	PROFILER_CHECKPOINT_PONG_MODEL_DUTY =
		PROFILER_CHECKPOINT_PING_MODEL_DUTY | 0x80, /*245*/
	PROFILER_CHECKPOINT_PONG_LAYER_DUTY =
		PROFILER_CHECKPOINT_PING_LAYER_DUTY | 0x80, /*246*/
	PROFILER_CHECKPOINT_PONG_LAYER_OPCODE =
		PROFILER_CHECKPOINT_PING_LAYER_OPCODE | 0x80, /*247*/

	PROFILER_CHECKPOINT_MAX,
};

#ifndef MD5_MODEL_ID_LEN
#define MD5_MODEL_ID_LEN 4 /*16 uint32_t 128bit*/
#endif

#ifndef PROFILER_OPCODE_MAX
#define PROFILER_OPCODE_MAX 32
#endif

/*profiler timeline version*/
#define PROFILER_CMCU_VERSION 0x01
#define PROFILER_VDSP_VERSION 0x01

#define PROFILER_MODEL_NAME_STR_LEN_MAX (128)
/*CMCU performance acquisition data parameters*/
typedef struct s_profiler_cmcu_section {
	uint8_t version;
	uint8_t type; /*Timeline data type e_profiler_checkpoint_type*/
	uint16_t length; /*Data length*/
	uint32_t current_cycle_count; /*Timing moments; use core cycle count*/
	uint32_t last_cycle_count_after_checkpoint; /*The time collected after the checkpoint function is called*/
	uint32_t sn; /*The serial number of the collected data is automatically increased by 1*/
	uint32_t process_vid; /*The video of the process that is currently executing the task*/
	uint32_t core_timestamp; /*250us timer*/

	/*parameter complexes*/
	union u_param_cmcu {
		/*model parameter*/
		struct {
			uint32_t model_name;
			uint32_t model_id[MD5_MODEL_ID_LEN];
			uint32_t layer_count;
			uint16_t batch_size;
			uint16_t req_int_src; /*req from host or vdsp; use EM_INT_SRC_t*/
			uint16_t vdsp_total_msg_index; /*from vdsp, associate with vdsp checkpoint data*/
			uint16_t rsvd;
			uint8_t model_name_str
				[PROFILER_MODEL_NAME_STR_LEN_MAX]; /*save model_name string in
										    model_info*/
		} __attribute__((packed)) cmcu_model;
		/*layer parameter*/
		struct {
			uint32_t model_name;
			uint32_t model_id[MD5_MODEL_ID_LEN];
			uint32_t real_layer_id;
			uint32_t pipeline_id;
			uint32_t group_id : 8;
			uint32_t group_flag : 8; /*group type t*/
			uint32_t batch_id : 8;
			uint32_t rsvd : 8;
		} __attribute__((packed)) cmcu_layer;

		/*Opcode*/
		struct {
			uint32_t real_layer_id;
			uint8_t opcode_num;
			uint16_t opcode_duty;
			uint8_t opcode_data_length;
			uint8_t opcode_data[PROFILER_OPCODE_MAX];
		} __attribute__((packed)) cmcu_opcode;

	} param;
	uint8_t rsvd[32];
	uint32_t magic_number; /*magic number*/
} __attribute__((packed)) profiler_cmcu_section_t;

/*
	Time description:
	  ...  last_section_end|  ckp_occupy0  |section_begin|  ckp_occupy1  |section_end|  ckp_occupy2
   |next_section_begin ...

		section_end.last_cycle_count_after_checkpoint is when the section really begins; Corresponds to the
   begin of the previous section of the image section_end.last_cycle_count_after_checkpoint -
   section_begin.current_cycle_count is the time taken by the checkpoint function; Correspondence ckp_occupy1
		next_section_begin.current_cycle_count - section_end.current_cycle_count It's ckp_occupy2 time
		Between section_begin and section_end, the checkpoint function time is included, which needs to be
   removed from the image.
	*/

/*VDSP performance data acquisition parameters*/
typedef struct s_profiler_vdsp_section {
	uint8_t version;
	uint8_t type; /*Timeline data type e_profiler_checkpoint_type*/
	uint16_t length; /*Data length*/
	uint32_t current_cycle_count; /*Timing moments; use core cycle count*/
	uint32_t last_cycle_count_after_checkpoint; /*The time collected after the checkpoint function is called*/
	uint32_t sn; /*The serial number of the collected data is automatically increased by 1*/
	uint32_t process_vid; /*The video of the process that is currently executing the task*/
	uint32_t core_timestamp; /*WDT clock cycle num,250us timer*/

	union u_param_vdsp {
		struct {
			uint32_t data_id;
			uint32_t stream_id;
			uint32_t msg_ringbuf_index;
		} __attribute__((packed)) host_to_vdsp;
		struct {
			uint32_t data_id;
			uint32_t stream_id;
			uint32_t context_id;
			uint32_t msg_ringbuf_index;
		} __attribute__((packed)) vdsp_to_host;
		struct {
			uint32_t data_id;
			uint32_t stream_id;
			uint32_t context_id;
			uint32_t op_id;
			uint32_t loop_count;
		} __attribute__((packed)) opcode;
		struct {
			uint32_t data_id;
			uint32_t stream_id;
			uint32_t context_id;
			uint32_t msg_ringbuf_index;
			uint16_t loop_index;
			uint16_t total_msg_index; /*vdsp to cmcu total message index for correlating information between
						     vdsp and cmcu.*/
		} __attribute__((packed)) vdsp_to_cmcu;
		struct {
			uint32_t data_id;
			uint32_t stream_id;
			uint32_t context_id;
			uint32_t msg_ringbuf_index;
			uint16_t loop_index;
			uint16_t total_msg_index; /*vdsp to cmcu total message index for correlating information between
						     vdsp and cmcu.*/
		} __attribute__((packed)) cmcu_to_vdsp;
	} param;
	uint8_t rsvd[32];
	uint32_t magic_number; /*magic number*/
} profiler_vdsp_section_t;

/*Driver timeline:*/
#define PROFILER_DMA_VERSION 0x01
#define PROFILER_MSG_VERSION 0x01

/*dma: 4: the time when the driver receives the DMA request, the time when the driver notifies the user that the DMA is
 * completed, the actual start execution time of the DMA, and the actual execution end time of the DMA.*/
/*Time period*/
typedef struct s_profiler_dma_checkpoint {
	u8 version;
	u8 rsvd[3];
	s64 pid;
	u32 dev_id;
	u32 die_id;
	u32 die_index;
	u64 time_of_driver_recv_dma_req; /*host. 1970.1.1 ns begin*/
	u64 time_of_host_trigger_dma; /*host 2*/
	u32 time_of_dma_run; /*smcu 3*/
	u32 time_of_dma_finish; /*smcu 4*/
	u64 time_of_driver_notify_host_dma_done; /*host 5 ; end*/
	u64 dma_axi_addr;
	u32 dma_dir;
	u32 dma_data_size;
	u32 rsvd2[4];
} profiler_dma_checkpoint_t;

/*Driver timeline: Msg: 2: the time when FW received Msg, the time when Dev initiated out_desc, and the point in time*/
typedef struct s_profiler_msg_checkpoint {
	u8 version;
	u8 rsvd[3];
	s64 pid;
	u32 dev_id;
	u32 die_id;
	u32 die_index;
	u64 time_of_host_send_msg; /*1970.1.1 ns begin*/
	u64 time_of_fw_recv_msg; /*device_send_out_desc It's a bit difficult, don't do it yet. 1970.1.1 ns end*/
	u32 core_bitmap; /*0x0010: vdsp0 ; 0x0020: vdsp1 ; 0x0040: vdsp2 ; 0x0080: vdsp3*/
	u32 msg_cmd;
	/*command number used in FW*/
	/*#define CMD_RUN_MODEL	  0x40185602*/
	/*#define CMD_RUN_STREAM	  0x40185603*/
	/*#define CMD_LOAD_MODEL	  0x40185604*/
	/*#define CMD_DESTROY_MODEL 0x40185605*/
	/*#define CMD_LOAD_VDSP_OPERATOR 0x40185606*/
	/*#define CMD_LOAD_ODSP_OPERATOR 0x40185607*/
	u32 rsvd2[4];
} profiler_msg_checkpoint_t;

/*timeline: app checkpoint data acquisition, universal interface*/
#define PROFILER_APP_JSON_STR_LENGTH (256)
typedef struct s_profiler_app_checkpoint {
	u8 version;
	u8 rsvd[3];
	s64 pid;
	u32 tid;
	u64 ns;
	u32 level;
	u64 timestamp_ns;
	u32 sn;
	u32 die_index;
	u32 file_node_id; /*Serial number of the node of the device file used by the service*/
	u32 rsvd2[8];
	u32 subtype; /*Distinguish the type of data to be collected*/
	u32 json_str_len; /*0: Do not use JSON, the data is parsed according to U32 1: Use JSON string*/
	/*Save specific information*/
	union {
		u8 json_str[PROFILER_APP_JSON_STR_LENGTH];
		u32 data[PROFILER_APP_JSON_STR_LENGTH / sizeof(u32)];
	} info;
} profiler_app_checkpoint_t;

/*Ringbuf, which holds PCIe DMA acquisition data*/
#define PROFILER_PCI_DMA_FIFO_LENGTH (100 * 1024 * 1024)
/*Ringbuf that holds PCIe MSG acquisition data*/
#define PROFILER_PCI_MSG_FIFO_LENGTH (100 * 1024 * 1024)
/*Ringbuf that stores the data collected by the app*/
#define PROFILER_PCI_APP_FIFO_LENGTH (100 * 1024 * 1024)

extern void *gp_profiler_dma_fifo;
extern void *gp_profiler_msg_fifo;
extern void *gp_profiler_app_fifo;

/*profiler checkpoint end*/

/*core time sync start*/

/*core time sync command code*/
enum e_core_time_sync_msg_type {
	CORE_TIME_SYNC_MSG_STOP = 0, /*Stop clock synchronization*/
	CORE_TIME_SYNC_MSG_START = 1, /*Start clock synchronization*/
	CORE_TIME_SYNC_MSG_READ = 2, /*Read CSRAM clock synchronization data*/
	CORE_TIME_SYNC_MSG_MAX
};

/*Saves the time of each core, and writes to each core when it receives a synchronization interruption.*/
typedef struct core_time_sync_s {
	unsigned int
		perfmon_data_index; /*Read oak6's perfmon PERFMON_DATA_INDEX registers*/
	unsigned int
		cycle_count; /*Read the cycle of the current core count: XT_RSR_CCOUNT*/
	unsigned int core_freq; /*Written by smcu*/
	unsigned int core_timestamp; /*WDT clock cycle num,250us timer*/
} core_time_sync_t;

/*Save the core time sync data address, data core_time_sync_t . One per core.*/
#define INTER_CORE_TIME_SYNC_ADDR                                              \
	(0x08cf3e00) /*TODO: Temporary use, application required*/

typedef struct core_time_sync_data_s {
	core_time_sync_t core_time[CORE_NUMBER];
	u64 host_time_ns[CORE_NUMBER];
} core_time_sync_data_t;

extern struct mutex pcie_timeline_dma_mutex;
extern struct mutex pcie_timeline_msg_mutex;
extern struct mutex pcie_timeline_app_mutex;
extern struct mutex sharedmem_weight_mutex;

/*-----------------------------------------------------------------------*/
/*core time sync end*/
/*-----------------------------------------------------------------------*/

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
struct bmcu_xspi_ver {
	s32 buf_size;
	union die_index_data die_index;
	char bmcu_active[32];
	char bmcu_backup[32];
	s32 die_num;
	struct {
		char xspi_ver[32];
	} dies[0];
};
#endif
#else
struct bmcu_xspi_ver {
	s32 buf_size;
	union die_index_data die_index;
	char bmcu_active[32];
	char bmcu_backup[32];
	s32 die_num;
	struct {
		char xspi_ver[32];
	} dies[0];
};
#endif
struct sriov_number_s {
	int dev_id;
	int sriov_num;
};

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
struct flash_bmcu_xspi {
	union die_index_data
		die_index; /*If you flash bmcu, pls check this die_index is master die*/
	s32 buf_size;
	char buf[0];
};
#endif
#else
struct flash_bmcu_xspi {
	union die_index_data
		die_index; /*If you flash bmcu, pls check this die_index is master die*/
	s32 buf_size;
	char buf[0];
};
#endif

struct flash_state {
	union die_index_data die_index;
	u32 flash_type; /*0: BMCU; 1: xspi; 2: PMCU;*/
	s32 flash_state; /*0: doing; 1: done; other: errno;*/
};

/*-------------------------------------------------------*/
/*v2 version*/
/*The length of the version number string*/
#define VASTAI_VER_LEN (64)

#define VASTAI_DIE_MAX_NUM (4)

/*Firmware version number*/
typedef struct vatools_fw_version_s {
	unsigned char ver[VASTAI_VER_LEN]; /*Product version number*/
	unsigned char fw_ver[VASTAI_VER_LEN]; /*Firmware version number*/
	unsigned char smcu_ver[VASTAI_VER_LEN]; /*SMCU version number*/
	unsigned char vdmcu_ver[VASTAI_VER_LEN]; /*VDMCU version number*/
	unsigned char vemcu_ver[VASTAI_VER_LEN]; /*VEMCU version number*/
	unsigned char vdsp_ver[VASTAI_VER_LEN]; /*VDSP version number*/
	unsigned char cmcu_ver[VASTAI_VER_LEN]; /*CMCU version number*/
	unsigned char lmcu_ver[VASTAI_VER_LEN]; /*LMCU version number*/
	unsigned char odsp_ver[VASTAI_VER_LEN]; /*ODSP version number*/
	unsigned char driver_ver[VASTAI_VER_LEN]; /*Driver version number*/
} vatools_fw_version_t;

/*die index structure*/
typedef union vatools_die_index_data_u {
	u32 val; /*the universal device  ID*/
	struct {
		u32 die_id : 8; /*the die ID*/
		u32 dev_id : 16; /*thd device ID*/
		u32 seq_num : 8; /*the Serial number*/
	};
} vatools_die_index_data_t;

/*linux defination: major 12 bit; minor 20 bit*/
#define MINOR_H(dev) ((unsigned int)(((dev) >> 16) & 0xf))
#define MINOR_L(dev) ((unsigned int)(((dev)) & 0xffff))
typedef union major_minor_u {
	u32 val; /*The value of the primary and minor version number*/
	struct {
		u16 minor; /*minor version number*/
		u16 major : 12; /*Major version number*/
		u16 minor_h : 4; /*minor version number. 4-bit high*/
	};
} major_minor_t; /*Major and minor version numbers*/

typedef struct node_base_info_s {
	char name[VASTAI_BUF_SIZE_32];
	union major_minor_u majormin;
} node_base_info_t;

typedef struct vatools_die_info_s {
	/*The universal die index*/
	union vatools_die_index_data_u die_index;
	/*vacc name*/
	struct node_base_info_s vacc;
	/*render name*/
	struct node_base_info_s render;
	/*video name*/
	struct node_base_info_s vastai_video;
	/*bbox type*/
	char bbox_type[VASTAI_BUF_SIZE_32];
} vatools_die_info_t;

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
struct card_info {
	int cnt;
	char buf[0];
};
#endif
#else
struct card_info {
	int cnt;
	char buf[0];
};
#endif

union pci_id {
	u32 val; /*PCI ID value*/
	struct {
		u16 vender_id; /*sell ID*/
		u16 device_id; /*Device ID*/
	};
};

union pci_sub_id {
	u32 val; /*PCI SUB ID*/
	struct {
		u16 sub_vender_id; /*SUB vender ID*/
		u16 sub_device_id; /*SUB device ID*/
	};
};

struct ai_video_cap {
	int ai_cap; /*AI Capability Set*/
	int video_cap; /*VIDEO capability set*/
};

/*bar size check*/
typedef struct vatools_bar_address_s {
	u64 begin;
	u64 end;
} vatools_bar_address_t;

typedef struct vatools_dev_vfpf_flag_s {
	u32 is_physfn;
	u32 is_virtfn;
} vatools_dev_vfpf_flag_t;
typedef struct vatools_dev_info_s {
	int dev_id; /*Device ID*/
	char unid[VASTAI_BUF_SIZE_32]; /*Sn*/
	char pcie_slot[VASTAI_BUF_SIZE_32]; /*PCI slot. format 0000:01:00.00*/
	char card_type[VASTAI_BUF_SIZE_32]; /*Card type*/
	char bbox_mode[VASTAI_BUF_SIZE_32]; /*card bbox type*/
	/*PCI ID information*/
	union pci_id pciid; /*PCI ID information*/
	union pci_sub_id pcisubid;
	struct node_base_info_s kchar; /*Major and minor version numbers*/
	struct node_base_info_s vatools; /*Major and minor version numbers*/
	struct node_base_info_s vastai_ctrl; /*Major and minor version numbers*/
	struct node_base_info_s
		vastai_version; /*Major and minor version numbers*/
	struct ai_video_cap cap; /*Video Capability Set*/
	struct vatools_bar_address_s bar_address[4][2]; /*bar size*/
	int die_num; /*the number*/
	vatools_die_info_t die_info[VASTAI_DIE_MAX_NUM]; /*Information*/
} vatools_dev_info_t;

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
/*Device performance data*/
struct vatools_performance_info {
	/*PCI performance data*/
	struct {
		u32 pcie_tx_vdsp_count
			[4]; /*The amount of data that PCI sends to the VDSP*/
		u32 pcie_rx_vdsp_count
			[4]; /*The amount of data that PCI received from VDSP*/
		u64 pcie_bandwidth_upstream; /*PCI uplink bandwidth. Device to host.*/
		u64 pcie_bandwidth_downstream; /*PCI downlink bandwidth. Host-to-device.*/
	} pcie_performance;
	/*CSRAM information*/
	u8 csram_info[0];
};
#endif
#else
/*Device performance data*/
struct vatools_performance_info {
	/*PCI performance data*/
	struct {
		u32 pcie_tx_vdsp_count
			[4]; /*The amount of data that PCI sends to the VDSP*/
		u32 pcie_rx_vdsp_count
			[4]; /*The amount of data that PCI received from VDSP*/
		u64 pcie_bandwidth_upstream; /*PCI uplink bandwidth. Device to host.*/
		u64 pcie_bandwidth_downstream; /*PCI downlink bandwidth. Host-to-device.*/
	} pcie_performance;
	/*CSRAM information*/
	u8 csram_info[0];
};
#endif

/*Device ECC information*/
struct vatools_ecc_entry {
	u32 addr_1; /*address low*/
	u32 addr_h; /*Address high position*/
	u32 axi_id; /*axi ID*/
	u32 axi_data_l; /*axi data is low*/
	u32 axi_data_h; /*axi data high*/
	u32 errbit; /*err bit*/
};

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
/*Equipment ECC table*/
struct vatools_ecc_table {
	u32 entry_count; /*entry number*/
	u32 rsvd_0; /*retain*/
	u32 rsvd_1; /*retain*/
	u32 rsvd_2; /*retain*/
	struct vatools_ecc_entry entry[0]; /*ECC Entry data*/
};
#endif
#else
/*Equipment ECC table*/
struct vatools_ecc_table {
	u32 entry_count; /*entry number*/
	u32 rsvd_0; /*retain*/
	u32 rsvd_1; /*retain*/
	u32 rsvd_2; /*retain*/
	struct vatools_ecc_entry entry[0]; /*ECC Entry data*/
};
#endif

typedef struct smi_cmd_header_s {
	u32 unit; /*The specified unit of the command operation, starting from 0, if the command does not need to be
		     parsed, fill in 0, if it is all, fill in 0xFFFF, this field can also be extended by command*/
	u16 data_len; /*indicates the byte length of the data that occurs to FW or the data returned by FW, in bytes*/
	u8 flag; /*indicates whether fw is ready for data, 0x01U, data ready,*/
	/*0x00U data is not ready, enter 0x00U when the application layer sends the command*/
	u8 cmd; /*Specific commands*/
	u64 rw_addr : 48; /*Read and write address. total 48 bit*/
	u16 seq;
} smi_cmd_header_t; /*SMI command format, total 64 bit*/

typedef struct smi_cmd_s {
	smi_cmd_header_t header; /*smi command header*/
	u8 data[1024 -
		sizeof(smi_cmd_header_t)]; /*data area; take the maximum value of all blocks; 1K bytes*/
} smi_cmd_t; /*SMI cmd, including header and data area*/

typedef struct smi_cmd_req_s {
	u32 block_id; /*smi block id*/
	u32 wait_ack_timeout; /*SMI command wait for ACK timeout, unit: ms; 0 does not use wait_ack, returns directly*/
	smi_cmd_t req; /*smi req request command*/
	smi_cmd_t rsp; /*SMI RSP returns data*/
} smi_arg_t;

/*The host uses IOCTL and drivers for data exchange and transmission*/
/*ioctl arg header*/
typedef struct vatools_ioctl_arg_header_s {
	u32 type;
	vatools_die_index_data_t die_index;
	u64 address;
	u32 length;
	int err;
} vatools_ioctl_arg_header_t;

#if (TOOLS_WIN == 1)
#ifdef __cplusplus
/*ioctl arg*/
typedef struct vatools_ioctl_arg_s {
	vatools_ioctl_arg_header_t header;
	union {
		u8 body[0];
		vatools_dev_info_t dev_info[0];
		smi_arg_t smi;
		void *buffer;
	};
} vatools_ioctl_arg_t;
#endif
#else
/*ioctl arg*/
typedef struct vatools_ioctl_arg_s {
	vatools_ioctl_arg_header_t header;
	union {
		u8 body[0];
		vatools_dev_info_t dev_info[0];
		smi_arg_t smi;
		void *buffer;
	};
} vatools_ioctl_arg_t;
#endif

/*STORE ADDR OF HEARTBEAT COUNT*/
#define CORE_HEARTBEAT_ADDR 0x08cf3020
#define CORE_HEARTBEAT_LEN  (120)

typedef struct core_heartbeat_s {
	u32 smcu_thread_hb; /*from smcu while(1)*/
	u32 smcu_timer_hb; /*from smcu interrutp*/
	u32 cmcu_hb;
	u32 lmcu0_hb;
	u32 lmcu1_hb;
	u32 lmcu2_hb;
	u32 lmcu3_hb;
	u32 lmcu4_hb;
	u32 lmcu5_hb;
	u32 lmcu6_hb;
	u32 lmcu7_hb;
	u32 odsp0_hb;
	u32 odsp1_hb;
	u32 odsp2_hb;
	u32 odsp3_hb;
	u32 odsp4_hb;
	u32 odsp5_hb;
	u32 odsp6_hb;
	u32 odsp7_hb;
	u32 vdmcu0_hb;
	u32 vdmcu1_hb;
	u32 vdmcu2_hb;
	u32 vemcu0_hb;
	u32 vemcu1_hb;
	u32 vemcu2_hb;
	u32 vemcu3_hb;
	u32 vdsp0_hb;
	u32 vdsp1_hb;
	u32 vdsp2_hb;
	u32 vdsp3_hb;
} core_heartbeat_t;

#define VATOOLS_PCI_BUS_SIZE (128)
typedef union {
	u8 rsvd[VATOOLS_PCI_BUS_SIZE];
	struct {
		unsigned char
			number; /*Bus number All pf vfs that belong to the same physical card have the same
					 number*/
		unsigned char primary; /*Number of primary bridge*/
		unsigned char max_bus_speed; /*enum pci_bus_speed*/
		unsigned char cur_bus_speed; /*enum pci_bus_speed*/
		char name[48];
		unsigned int domain_id; /*pci domain*/
		unsigned int card_id; /*pci card id*/
	} pci_bus;
} vatools_pci_bus_u;

typedef struct sys_cfg_sv_s {
	unsigned char devfn;
	unsigned char pfn;
	unsigned char vfn;
	unsigned char vf_active;
	unsigned char pkg_id;
	unsigned char is_super_pf;
	unsigned char is_admin_pf;
	unsigned char card_type;
	unsigned int card_id;
	unsigned int die_id_in_card;
	unsigned int rsvd[32];
} sys_cfg_sv_t;

#define VATOOLS_SYSTEM_CFG_SIZE (256)
typedef union {
	u8 rsvd[VATOOLS_SYSTEM_CFG_SIZE];
	struct {
		unsigned char devfn;
		unsigned char pfn;
		unsigned char vfn;
		unsigned char vf_active;
		unsigned char stream_id;
		unsigned char gfx_mpu_en;
		/*0: display disable 1:display enable*/
		unsigned char dp_en;
		unsigned char gfx_mode;
		/*0:master pkg, 1: slave pkg*/
		unsigned char pkg_id;
		/*0:1:00 LOCAL*/
		unsigned char atu_or_gart;
		unsigned char fn_mode;
		unsigned char is_super_pf;
		unsigned char is_admin_pf;
		/*bar4_5_cfg_size 0:normal cfg,vf-256MB PF-2GB*/
		/*1:1GB 2:2GB 4:4GB 8:8GB 16:16GB 32:32GB 64:64GB*/
		unsigned char bar4_5_cfg_size;
		/*0:EVB 1:AIC-ANYI 2:AIC_ZHAOGE*/
		unsigned char card_type;
		/*16:16GB 32:32GB 64:64GB*/
		unsigned char sum_ddr_sz;
		unsigned int smmu_sync_01;
		unsigned int card_id;
		unsigned char total_pf_per_card;
		unsigned char total_vf_per_pf;
		unsigned char decoder_sriov_en;
		unsigned char cur_pf_vf_num;
		/*1MB assigned*/
		unsigned int gart_size;
		unsigned int reserved32_03;
	} sys_cfg;
	sys_cfg_sv_t sys_cfg_sv;
} vatools_sys_cfg_u;

/*get gpu device info*/
typedef struct vatools_gfx_render_info_s {
	int drm_major; /*major node ; minor node is the same of below *_id*/
	int gfx_primary_id; /*index in /dev/dri/cardxxx for gfx drm device.*/
	int gfx_render_id; /*index in /dev/dri/renderxxx for gfx drm device.*/
	int nulldisp_primary_id; /*index in /dev/dri/cardxxx for nulldisp drm device.*/
} vatools_gfx_render_info_t;

/*ddr info*/
typedef enum VATOOLS_DDR_ENTRY_OBJ {
	VATOOLS_VF_MANAGE,
	VATOOLS_META_FW,
	VATOOLS_ENC_DEC_CMD_BUF,
	VATOOLS_AI_MODULE_OPCODE,
	VATOOLS_SMMU_CD_TABLE,
	VATOOLS_RESERVED_DDR,
	VATOOLS_RUNTIME,
	/*VATOOLS_GART, drive added, arrangement change, put last*/
	VATOOLS_GPU_HEAP,
	VATOOLS_GPU_DISPLAY,
	VATOOLS_GART,
	VATOOLS_DDR_ENTRY_MAX,
} vatools_ddr_entry_index;

struct vatools_ddr_entry {
	u64 noc_addr;
	u64 fn_addr;
	u64 cpu_pa;
	u64 bar_offset;
	u64 size;
};

typedef struct vatools_ddr_info_s {
	u64 card_ddr_size; /*the card ddr sum size*/
	u64 fn_ddr_size; /*the function ddr sum size*/
	struct vatools_ddr_entry ddr_entry[VATOOLS_DDR_ENTRY_MAX];
	u8 rsvd[216];
} vatools_ddr_info_t; /* for sg */

/*ddr info*/
enum VATOOLS_SV_DDR_ENTRY_OBJ {
	VATOOLS_SV_STREAM_ENTRY,
	VATOOLS_SV_MODEL_ENTRY,
	VATOOLS_SV_VDSP_ENTRY,
	VATOOLS_SV_ODSP_ENTRY,
	VATOOLS_SV_SHARE_ENTRY,
	VATOOLS_SV_DDR_ENTRY_MAX,
};

enum VATOOLS_SV_DDR_BANK {
	SV_DDR_BANK0,
	SV_DDR_BANK_MAX,
};

struct vatools_sv_ddr_entry {
	u64 start;
	u64 size;
};

typedef union {
	struct vatools_sv_ddr_entry ddr_entry[SV_DDR_BANK_MAX]
					     [VATOOLS_SV_DDR_ENTRY_MAX];
	u8 rsvd[sizeof(vatools_ddr_info_t)];
} vatools_sv_ddr_info_t; /* for sv */

#ifdef CONFIG_TOOLS_V2

#define VATOOLS_MAGIC_CODE 0xA283419D

/*MAJOR: Matches the major version of the tools release. Currently write 3*/
/*MIDDLE: Undefined. Write 0*/
/*MINOR: Add 1 every time you add a feature to the driver, or fix a major bug. The application layer can be used for
 * compatible driver processing*/
/*Define a historical version identity*/
enum vatools_drv_version_major_code_e {
	VATOOLS_DRV_VERSION_MAJOR_CODE_1 =
		1, /*Historical Version: Initial Version*/
	VATOOLS_DRV_VERSION_MAJOR_CODE_3 =
		3, /*Historical Version: Modify the Convergence version*/
	/*-- Current Version --*/
	VATOOLS_DRV_VERSION_MAJOR_CODE_CURRENT =
		VATOOLS_DRV_VERSION_MAJOR_CODE_3, /*Current version number*/
};

enum vatools_drv_version_middle_code_e {
	VATOOLS_DRV_VERSION_MIDDLE_CODE_5 =
		5, /*Historical Version: Initial Version*/
	VATOOLS_DRV_VERSION_MIDDLE_CODE_6 =
		6, /*Historical Version: Modify the Convergence version*/
	/*-- Current Version --*/
	VATOOLS_DRV_VERSION_MIDDLE_CODE_CURRENT =
		VATOOLS_DRV_VERSION_MIDDLE_CODE_6, /*Current version number*/
};

enum vatools_drv_version_minor_code_e {
	VATOOLS_DRV_VERSION_MINOR_CODE_1 =
		1, /*Historical Version: Initial Version*/
	VATOOLS_DRV_VERSION_MINOR_CODE_2 =
		2, /*Historical Version: Modify the Convergence version*/
	/*-- Current Version --*/
	VATOOLS_DRV_VERSION_MINOR_CODE_CURRENT =
		VATOOLS_DRV_VERSION_MINOR_CODE_2, /*Current version number*/
};

#define VATOOLS_DRV_VERSION_MAJOR_CODE	VATOOLS_DRV_VERSION_MAJOR_CODE_CURRENT
#define VATOOLS_DRV_VERSION_MIDDLE_CODE VATOOLS_DRV_VERSION_MIDDLE_CODE_CURRENT
#define VATOOLS_DRV_VERSION_MINOR_CODE	VATOOLS_DRV_VERSION_MINOR_CODE_CURRENT

/*sv100 log address configuration*/
#define SV100_LOG_CORE_COUNT (29)
/*behind 32 byte is ctrl byte*/
#define SV100_LOG_CTRL_LEN	    (SV100_LOG_CORE_COUNT * 16 + 32)
#define SV100_LOG_CTRL_INFO	    (0x08CF30A0)
#define SV100_LOG_MSG_FLAG	    (0x08CF3098)
#define SV100_LOGSYS_RPWP_STARTADDR SV100_LOG_CTRL_INFO
#define SV100_LOGSYS_RPWP_SIZE	    0x10

/*sg100 log address configuration*/
#define SG100_LOG_CORE_COUNT (17)
/*behind 32 byte is ctrl byte*/
#define SG100_LOG_CTRL_LEN	    (SG100_LOG_CORE_COUNT * 16 + 32)
#define SG100_LOG_CTRL_INFO	    (0x008e1400)
#define SG100_LOG_MSG_FLAG	    (SG100_LOG_CTRL_INFO + 512 - 4)
#define SG100_LOGSYS_RPWP_STARTADDR SG100_LOG_CTRL_INFO
#define SG100_LOGSYS_RPWP_SIZE	    0x10

/*SPI data buffer length*/
#define SPI_BUF_LEN_MAX	       (1000)
#define SPI_EEPROM_BUF_LEN_MAX (1000)

/*Version number definition*/
#define VASTAI_VER_COMMON_LEN	   (64) /*Maximum number of characters per version*/
#define VASTAI_VER_COMMON_MAX_ITEM (64) /*Maximum number of versions*/
typedef union {
	u8 fw_ver[VASTAI_VER_COMMON_MAX_ITEM][VASTAI_VER_COMMON_LEN];
	struct {
		u8 ver[VASTAI_VER_COMMON_LEN];
		u8 smcu_ver[VASTAI_VER_COMMON_LEN];
		u8 bmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 vdmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 vemcu_ver[VASTAI_VER_COMMON_LEN];
		u8 vdsp_ver[VASTAI_VER_COMMON_LEN];
		u8 cmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 lmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 odsp_ver[VASTAI_VER_COMMON_LEN];
		u8 driver_ver[VASTAI_VER_COMMON_LEN];
		u8 phy_ver[VASTAI_VER_COMMON_LEN];
		u8 bmcu_backup_ver[VASTAI_VER_COMMON_LEN];
	} sv100_fw_version;
	struct {
		u8 ver[VASTAI_VER_COMMON_LEN];
		u8 smcu_ver[VASTAI_VER_COMMON_LEN];
		u8 cmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 omcu_ver[VASTAI_VER_COMMON_LEN];
		u8 gmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 vemcu_ver[VASTAI_VER_COMMON_LEN];
		u8 odsp_ver[VASTAI_VER_COMMON_LEN];
		u8 vdsp_ver[VASTAI_VER_COMMON_LEN];
		u8 pmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 vdmcu_ver[VASTAI_VER_COMMON_LEN];
		u8 ver_bk[VASTAI_VER_COMMON_LEN];
		u8 bl0_ver[VASTAI_VER_COMMON_LEN];
		u8 bl0_ver_bk[VASTAI_VER_COMMON_LEN];
		u8 driver_ver[VASTAI_VER_COMMON_LEN];
		u8 phy_ver[VASTAI_VER_COMMON_LEN];
	} sg100_fw_version;
} vatools_v2_fw_version_u;

/*inventory info1*/
#define VATOOLS_INVENTORY_INFO_SIZE    (256)
#define VATOOLS_MAX_INVENTORY_ITEM_LEN 16

typedef union {
	char rsvd[VATOOLS_INVENTORY_INFO_SIZE];
	/*Public information*/
	struct {
		char card_type[VATOOLS_MAX_INVENTORY_ITEM_LEN +
			       1]; /*ASIIC card type*/
		char product_sn[VATOOLS_MAX_INVENTORY_ITEM_LEN +
				1]; /*ASCII product serial number*/
		char mfg_pn[VATOOLS_MAX_INVENTORY_ITEM_LEN +
			    1]; /*ASCII-Product MFG Part Number*/
		char hw_version[8]; /*ASCII product hardware version number*/
	} common_inventory;
	/*Chip or card-related information*/
	struct {
		char pcb_supplier[9]; /*ASCII-PCB Component Supplier 0x05*/
		char mech_supplier[7]; /*ASCII-Structural Components Supplier 0x06*/
		char manufacturer[6]; /*ASCII-Product OEM Manufacturer 0x07*/
		char mfg_date[10]; /*ASCII-The date the board was manufactured:MM/DD/YYYY 0x08*/
		char main_chip_pn[5]; /*ASCII-Main chip model 0x09*/
		char main_chip_version[2]; /*ASCII-Main chip version number 0x0A*/
		char max_power
			[3]; /*ASCII-Product Design Maximum Power Consumption 0x0B*/
		char main_chip_quantity[1]; /*ASCII-Number of main chips 0x0C*/
		char single_memory_chip_capacity_
			[3]; /*ASCII-Single memory granular capacity 0x0D*/
		char memory_chip_quantity_per_main_chip
			[1]; /*ASCII - Number of memory particles configured for a single
							       main chip 0x0E*/
		char input_clock_type
			[3]; /*ASCII - System Input Clock Type: Osc/Crystal 0x0F*/
		char input_clock_frequency
			[4]; /*ASCII-System input clock frequency 0x10*/
		char pcie_max_lane_num
			[2]; /*ASCII - Supports PCIe maximum number of lanes 0x11*/
		char pcie_max_speed[4]; /*ASCII - Supports PCIe up to 0x12 rate*/
		char core_ot_throttling_threshold
			[2]; /*ASCII - Default main chip junction temperature overtemperature
							 frequency reduction threshold 0x13*/
		char core_ot_shutdown_threshold
			[3]; /*ASCII - Default main chip junction temperature, overtemperature
						       power-down threshold, 0x14*/
		char inlet_ot_throttling_threshold
			[2]; /*ASCII-The default air inlet temperature overtemperature
							  frequency reduction threshold 0x15*/
		char inlet_ot_shutdown_threshold
			[2]; /*ASCII-The default air inlet temperature is overtemperature and
							the power-down threshold 0x16*/
		char outlet_ot_throttling_threshold
			[2]; /*ASCII - Default air outlet temperature overtemperature
							   frequency reduction threshold 0x17*/
		char outlet_ot_shutdown_threshold
			[2]; /*ASCII - Default air outlet temperature, over-temperature
							 power-down threshold, 0x18*/
		char gf_oc_throttling_threshold
			[4]; /*ASCII-The default cheat overcurrent downscaling threshold(mA)
						       0x19*/
		char gf_oc_shutdown_threshold
			[4]; /*ASCII-The default cheat overcurrent power-down threshold(mA) 0x1A*/
		char dp_interface_support[2]; /*ASCII-Supports dp: yes/No 0x1F*/
		char eth_mac_address_0[17]; /*ASCII-Ethernet MAC address 0 0x24*/
		char eth_mac_address_1[17]; /*ASCII-Ethernet MAC address 1 0x25*/
	} sg_inventory;
	struct {
		char file_version[4]; /*ASIIC  offset:  0*/
		char mfg_vendor[16]; /*ASIIC  offset:  1C*/
		char mfg_date[8]; /*ASIIC  offset:  4C*/
		char chip_batch_number[4]; /*ASIIC  offset:  54*/
		u32 power_consumtion; /*HEX  offset:  58*/
		char die0_bbox_type[4]; /*ASIIC  offset:  5C*/
		char die1_bbox_type[4]; /*ASIIC  offset:  60*/
		char die2_bbox_type[4]; /*ASIIC  offset:  64*/
		char die3_bbox_type[4]; /*ASIIC  offset:  68*/
		u32 core_max_frequency_die0; /*HEX offset: AM*/
		u32 encoder_max_frequency_die0; /*HEX  offset:  B0*/
		u32 decoder_max_frequency_die0; /*HEX  offset:  B4*/
		u32 ddr_max_frequency_die0; /*HEX  offset:  B8*/
		u32 other_frequency_die0; /*HEX  offset:  BC*/
		char die1[4]; /*ASIIC  offset:  C0*/
		u32 core_max_frequency_die1; /*HEX  offset:  C4*/
		u32 encoder_max_frequency_die1; /*HEX  offset:  C8*/
		u32 decoder_max_frequency_die1; /*HEX  offset:  CC*/
		u32 ddr_max_frequency_die1; /*HEX  offset:  D0*/
		u32 other_frequency_die1; /*HEX  offset:  D4*/
		char die2[4]; /*ASIIC  offset:  D8*/
		u32 core_max_frequency_die2; /*HEX  offset:  DC*/
		u32 encoder_max_frequency_die2; /*HEX offset: E0*/
		u32 decoder_max_frequency_die2; /*HEX offset: E4*/
		u32 ddr_max_frequency_die2; /*HEX offset: E8*/
		u32 other_frequency_die2; /*HEX  offset:  EC*/
		char die3[4]; /*ASIIC  offset:  F0*/
		u32 core_max_frequency_die3; /*HEX  offset:  F4*/
		u32 encoder_max_frequency_die3; /*HEX  offset:  F8*/
		u32 decoder_max_frequency_die3; /*HEX  offset:  FC*/
		u32 ddr_max_frequency_die3; /*HEX  offset:  100*/
		u32 other_frequency_die3; /*HEX  offset:  104*/
		u32 over_temper_alert_point_; /*HEX  offset:  168*/
		u32 over_temper_shutdown_point; /*HEX  offset:  16C*/
		u32 over_current_shutdown_point; /*HEX  offset:  170*/
	} sv_inventory;
} vatools_v2_inventory1_u;

/*vatools bar info struct*/
enum VATOOLS_PCI_BAR {
	VATOOLS_PCI_BAR0,
	VATOOLS_PCI_BAR1,
	VATOOLS_PCI_BAR2,
	VATOOLS_PCI_BAR3,
	VATOOLS_PCI_BAR4,
	VATOOLS_PCI_BAR5,
	VATOOLS_PCI_ROMBAR,
	VATOOLS_PCI_BAR_NUM
};
/*sv100, sg100 bar info struct, used in devinfo*/
typedef struct vatools_bar_info_s {
	u64 mmio_start;
	u64 mmio_end;
	u64 mmio_len;
	u64 mmio_flags;
	/*inbound pcie to axi address translation*/
	u64 noc_addr;
	u64 fn_base_addr;
} vatools_bar_info;

/*sv100 bar info struct, used in pcie barstatus command*/
typedef struct vatools_bar_info_sv100_s {
	u64 mmio_start;
	u64 mmio_end;
	u64 mmio_len;
	u64 mmio_flags;
	/*inbound pcie to axi address translation*/
	u64 at_addr;
	u64 mem;
	u64 vmem;
	u64 map_in_addr;
	u64 map_out_addr;
	u64 minish_bar_size;
} vatools_bar_info_sv100_t;

/*V2 ioctl command header information*/
/*Save the tools-driven feature set. Add 1 in order*/
enum vatools_drv_feature_e {
	VATOOLS_DRV_FEATURE_1 = 1, /*Historical Version: Initial Version*/
	VATOOLS_DRV_FEATURE_2 =
		2, /*Historical Version: Modify the Convergence version*/
	VATOOLS_DRV_FEATURE_3 =
		3, /*Previous Versions: Changed support for VA100 compatible with VA1, added
				      die_id_in_card parameters*/
	/*-- Current feature set --*/
	VATOOLS_DRV_FEATURE_CURRENT =
		VATOOLS_DRV_FEATURE_3, /*Current feature set*/
};

/*vatools driver capability bit*/
enum vatools_capability_e {
	VATOOLS_CAP_BASE = 1 << 0,
	VATOOLS_CAP_DMA_TRANS = 1
				<< 1, /* support dma trans without dma alloc */
	VATOOLS_CAP_CONCURRENT_REBOOT =
		1 << 2, /* support send pcie reboot parallel */
};

#define VATOOLS_BASE_INFO_SIZE (256)
typedef union {
	u8 rsvd[VATOOLS_BASE_INFO_SIZE];
	struct {
		u32 rsvd[4];
		u32 magic_number;
		u32 security[4];
		u32 tools_ver_major;
		u32 tools_ver_middle;
		u32 tools_ver_minor;
		u32 device_number;
		u32 device_info_size; /*Save device info size*/
		u32 card_change_count; /*Indicates changes in the card situation within the system, plus 1 for each
					  change*/
		u32 tools_feature; /*Identify the features supported by the tools driver, in order to add 1*/
		u64 tools_capability; /*The capability of driver*/
	} info;
} vatools_v2_base_info_u;

/*V2 get_device_info*/
#define VATOOLS_DIE_INFO_SIZE (1024 * 8)
typedef union {
	u8 rsvd[VATOOLS_DIE_INFO_SIZE];
	struct {
		/*32*u32 header*/
		u32 rsvd[32];
		/*The universal die index*/
		vatools_die_index_data_t die_index;
		/*vacc name*/
		struct node_base_info_s vacc;
		/*render name*/
		struct node_base_info_s render;
		/*video name*/
		struct node_base_info_s vastai_video;
		/*bbox type*/
		char bbox_type[VASTAI_BUF_SIZE_32];
		char spi_buf[SPI_BUF_LEN_MAX]; /*SPI data*/
		u32 pcie_nls; /*H2D negotiated_link_speed*/
		u32 pcie_nlw; /*H2D negotiated_link_width*/
		vatools_v2_fw_version_u fw_ver;
		vatools_v2_inventory1_u inventory1; /*Save inventory data*/
		sys_cfg_sv_t sys_cfg_sv;
		u32 pcie_nls_die2die; /*D2D negotiated_link_speed*/
		u32 pcie_nlw_die2die; /*D2D negotiated_link_width*/
		u32 pcie_nls_pkg2pkg; /*Pkg2Pkg negotiated_link_speed*/
		u32 pcie_nlw_pkg2pkg; /*Pkg2Pkg negotiated_link_width*/
		u32 odsp_as_vdsp; /*bitmap: 0: no; 0xff all odsp as vdsp*/
		u32 pcie_cls; /*capability link speed*/
		u32 pcie_clw; /*capability link speed*/
	} info;
} vatools_v2_die_info_u;

#define VATOOLS_DEVUCE_INFO_SIZE (1024 * 50)
typedef struct vatools_v2_device_info_s {
	/*32*u32 header*/
	u32 rsvd[32];
	/*device info*/
	int dev_id; /*Device ID*/
	char unid[VASTAI_BUF_SIZE_32]; /*Sn*/
	char pcie_slot[VASTAI_BUF_SIZE_32]; /*PCI slot. format 0000:01:00.00*/
	char card_type
		[VASTAI_BUF_SIZE_32]; /*Card type: Assigned by compilation parameters or obtained by pciinfo*/
	char bbox_mode[VASTAI_BUF_SIZE_32]; /*card bbox mode*/
	char bbox_type[VASTAI_BUF_SIZE_32]; /*card bbox type*/
	/*PCI ID information*/
	union pci_id pciid; /*PCI ID information*/
	union pci_sub_id pcisubid;
	struct node_base_info_s kchar; /*Major and minor version numbers*/
	struct node_base_info_s vatools; /*Major and minor version numbers*/
	struct node_base_info_s vastai_ctrl; /*Major and minor version numbers*/
	struct node_base_info_s
		vastai_version; /*Major and minor version numbers*/
	struct ai_video_cap cap; /*Video Capability Set*/
	struct vatools_bar_address_s bar_address[4][2]; /*bar size*/
	int die_num; /*the number*/
	vatools_v2_die_info_u die_info[VASTAI_DIE_MAX_NUM]; /*Information*/
	vatools_dev_vfpf_flag_t dev_vfpf_flag;
	u64 smcu_access_ddr_address_limit
		[2]; /*The range of addresses that can be accessed by the SMCU*/
	struct sriov_number_s sriov_number;
	vatools_v2_fw_version_u fw_ver;
	vatools_sys_cfg_u sys_cfg; /*SG100 csram_hw_cfg->system_cfg*/
	vatools_pci_bus_u pci_bus;
	node_base_info_t gfx_primary_node;
	node_base_info_t gfx_render_node;
	node_base_info_t gfx_nulldisp_primary_node;
	vatools_ddr_info_t ddr_info;
	u32 board_type; /*sv100 or sg100*/
	u64 board_physical_id; /*Identify the same physical card offset: 38616*/
	u64 capability0; /*Identify the ability to drive the device. Press bit to use offset: 38624*/
	u32 pci_state; /*Identifies the PCI info status*/
	u8 mb_spi_buf[SPI_BUF_LEN_MAX]; /*Inventory information for VA100 and similar boards offset: 39628*/
	vatools_bar_info
		bar[VATOOLS_PCI_BAR_NUM]; /*sg100 bar info offset: 39964*/
	u8 iommu_en; /*0: invalid, 1: false, 2: true*/
	u8 boot_failed_flag; /*0: invalid, 1: false, 2: true*/
	u8 probe_done; /*0: invalid, 1: false, 2: true*/
	u8 is_in_vm; /*0: invalid, 1: false, 2: true*/
	u8 flr_is_en; /*0: invalid, 1: false, 2: true*/
	u8 video_mmu_enabled; /*0: invalid, 1: false, 2: true*/
	u8 ddk_init_done; /*0: invalid, 1: false, 2: true*/
	u8 ras_enabled; /*0: invalid, 1: false, 2: true*/
	u8 support_android_sriov; /*0: invalid, 1: false, 2: true*/
	u8 support_diag; /*0: invalid, 1: false, 2: true*/
	u8 rsvd3[2]; /*4 byte align*/
} vatools_v2_device_info_t;

/*After adjusting the struct components, you need to manually modify the size value, which must match. Otherwise, the
 * compilation error*/
#define SIZEOF_V2_DEVICE_INFO_STRUCT (39976)

typedef union {
	u8 rsvd[VATOOLS_DEVUCE_INFO_SIZE];
	vatools_v2_device_info_t info;
} vatools_v2_device_info_u;

typedef struct vatools_devices_info_s {
	vatools_v2_base_info_u base;
	vatools_v2_device_info_u *device_info_p;
} vatools_devices_info_t;

/*TODO: capability0 use definitions*/
/*
	bit0'0: BMCU do not support Flash inductive upgrades
	bit0'1: The BMCU supports Flash non-inductive upgrades
	bit1'0: BL0/XSPI does not support Flash inductive upgrades
	bit1'1: BL0/XSPI supports Flash Senseless Upgrade
	bit2'0: PMCU does not support Flash inductive upgrades
	bit2'1: PMCU supports Flash non-inductive upgrades
	Others are unused.
	*/
/*TODO: change to vastai code later*/
enum vatools_flash_update_type_e {
	VATOOLS_FLASH_UPDATE_BMCU = 0,
	VATOOLS_FLASH_UPDATE_BL0,
	VATOOLS_FLASH_UPDATE_PMCU,
};

#define MAX_OCCUPY_DIE_NUM	 (VASTAI_DIE_MAX_NUM * MAX_DEVICE_NUM_PER_MANAGER)
#define MAX_VIDEO_DIE_CAPABILITY 20000
#define MIN_VIDEO_DIE_CAPABILITY 0
#define MAX_OCCUPY_DIE_SINGLE	 128

enum {
	ALLOC_VIDEO_ENCODE,
	ALLOC_VIDEO_DECODE,
	ALLOC_VIDEO_MAX,
};
struct vatools_video_cap_query {
	/*The app calls the input parameter*/
	u32 version; /*version number, now write 0*/
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
	u8 flag_specify_die; /*0: Not specified 1: specify die*/
	u8 flag_allocate_policy; /*Allocation policy method: 0: Take the lowest resource occupation die*/
	u8 flag_rsvd;
	u32 die_weight; /*allocated die weight*/
	u32 specified_die_seq; /*specified die seq*/

	/*interface returns data*/
	/*optimal die seq*/
	u32 die_seq;
	u32 die_weight_total; /*die The value of the resource after being allocated by this request*/
	u32 rsvd[16];
	u32 die_array_len;
	u8 die_array[MAX_OCCUPY_DIE_SINGLE];
};

struct vatools_occupy_die {
	u32 die_seq;
	u32 die_weight;
	u8 flag_encode_or_decode; /*0: Encoding 1: Decoding*/
};

#define RT_INFO_HEAD_BUF_SIZE	      (1024 * 1024)
#define RT_ZONE_USAGE_BUF_SIZE	      (1024 * 1024)
#define RT_PROCESS_INFO_BUF_SIZE      (1024 * 1024 * 10)
#define RT_VACC_PROCESS_INFO_BUF_SIZE (1024 * 1024 * 10)
#define DEVINFO_REFRESH_INTERVAL      60 /* s */

struct vatools_node {
	wait_queue_head_t wq;
	struct mutex node_mutex;
	/*lupa add 2021-12-23 begin resource locks for the entire business. Ensure that resources are exclusive when
	 * processing the business*/
	struct mutex node_sharedmem_mutex;
	struct mutex node_common_mutex;
	struct mutex node_profiler_mutex;
	struct mutex node_debugger_mutex;
	struct mutex node_logger_mutex;
	struct mutex node_smi_mutex;
	struct mutex node_dummy_mutex;
	struct mutex node_driver_mutex;
	struct mutex node_reader_mutex;

	/*lupa add 2021-12-23 end Resource lock for the entire business. Ensure that resources are exclusive when
	 * processing the business*/
	struct list_head list_nodes;
	void *pci_dev;
	unsigned char *node_buffer;
	unsigned int size;
	unsigned int
		rsv; /*8-byte alignment is required to adapt to the ARM server*/
	struct list_head list_node_readers;
	struct list_head list_node_process_mutex;

	/*pcie dma / msg ringbuf, for profiler timeline*/
	void *profiler_dma_ringbuf;
	void *profiler_msg_ringbuf;

	/*core event ringbuf*/
	void *event_ringbuf;
	/*core event mutex*/
	struct mutex event_mutex;
	/*Wait for core's event; For example, the reset event*/
	wait_queue_head_t event_wait_queue;
	vatools_v2_device_info_u *dev_info;
	u32 device_num;
	u32 rsvd; /*for arm cpu, 8 byte align*/
	struct vatools_occupy_die die_weights[ALLOC_VIDEO_MAX]
					     [MAX_OCCUPY_DIE_NUM];
	struct vatools_occupy_die die_weights_real[ALLOC_VIDEO_MAX]
						  [MAX_OCCUPY_DIE_NUM];
	/*app ringbuf, for profiler timeline*/
	void *profiler_app_ringbuf;

	// pre alloc runtime buffer
	struct mutex rt_buf_mutex;
	u8 *rt_info_head_buf;
	u8 *rt_zone_usage_buf;
	u8 *rt_process_info_buf;
	u8 *rt_vacc_process_info_buf;

	u64 last_refresh_time;
	struct tools_char_drv_info *drv;
	struct mutex inventory_cache_mutex;

	atomic_t ut_enable;
	struct tools_file_info file_info;
};

enum va_f_type {
	VATOOLS_OPEN,
	VATOOLS_READ,
	VATOOLS_WRITE,
	VATOOLS_IOCTL,
	VATOOLS_CLOSE,
};

struct vatools_pid_entry {
	int refcount;
	struct pid *pid;
	struct list_head node;
	enum va_f_type type;
	int nr_pid;
};

struct vatools_reader {
	struct vatools_node *node;
	struct list_head list_readers;
	struct list_head
		malloc_pointers; /*TODO: Holds the memory pointer of each open fd request, and if the fd is
					     closed, loops to free up space*/
	/*sharedmem*/
	struct list_head t_sharedmem_mem_info_head;
	/*struct list_head t_sharedmem_signal_info_head;*/
	/*Add a semaphore to trigger a wait event*/
	struct completion
		debug_comp; /*Used to record the trigger signal using lupa add 2021-12-15*/
	struct fasync_struct *sharedmem_pt_fasync;
	struct mutex sharedmem_mutex;
	int n_sharedmem_init_done; /*Indicates whether it has been initialized; 1 - Complete Initialization 0 - Not
				      Initialized*/
	/*reader generic variable. Not yet used.*/
	size_t r_off;
	int r_all;
	int r_ver;
	unsigned int
		profiler_checkpoint_corebitmap; /*Record the core with the Profiler checkpoint enabled, and use the
							corebitmap record, one bit per core*/

	T_SMI_IOCTL_TRANS_CATEGORY
	trans_category; /*Adapt to the structure of the arm server and the host, and pay attention to the 8 byte
			   alignment*/
	int exit; /*Whether to exit*/
	/*Adapt to the ARM server, 8-byte alignment is required, trans_category is not modified for the time being, here
	 * the reserved field alignment is used.*/
	u64 event_timestamp_ns; /*identifies that this time, as well as previous events, have been sent to the host
				   thread; This time is updated each time an event is sent to the host*/
	u32 ioctl_version; /*VATOOLS_IOCTL_V2_MAGIC: v2 version*/
	int rsvd; /*for arm cpu, 8 byte align*/
	/*share mem filter*/
	union vatools_filter filter;
	struct vatools_occupy_die own_dies;
};

/*SPI order unit bit*/
#define SPI_BLOCK_CODE	       0x1 /*spi flash code*/
#define SPI_BLOCK_ECC	       0x2 /*spi flash user setting information*/
#define SPI_BLOCK_PRODUCT_INFO 0x4 /*spi flash productinfo inventory*/
#define SPI_BLOCK_MFG_INFO     0x8 /*spi flash MFG information*/
#define SPI_BLOCK_BBOX_INFO    0x10 /*spi flash production bbox*/
#define SPI_BLOCK_EEPROM       0x20 /*spi eeprom, gpu inventory, va100 mainboard*/

/*below is ioctl General commands V2 version*/

#define VATOOLS_IOCTL_V2_MAGIC 0xA2
/*Test commands*/
#define VATOOLS_IOCTL_V2_TEST _IO(VATOOLS_IOCTL_V2_MAGIC, 0x00)
/*Set the category of the open file FD*/
#define VATOOLS_IOCTL_V2_SET_APP_CATEGORY _IO(VATOOLS_IOCTL_V2_MAGIC, 0x01)
/*Obtain the device info*/
#define VATOOLS_IOCTL_V2_GET_DEVICE_INFO _IO(VATOOLS_IOCTL_V2_MAGIC, 0x02)
enum e_ioctl_get_device_info_sub_cmd {
	VATOOLS_IOCTL_DEVICE_INFO_NONE = 0,
	VATOOLS_IOCTL_DEVICE_INFO_REFRESH =
		1, /*Do not read the cache, re-read the relevant data from the chip*/
};

/*Read data in the normal way*/
#define VATOOLS_IOCTL_V2_READ_BUF _IO(VATOOLS_IOCTL_V2_MAGIC, 0x03)
/*Data is written in the normal way*/
#define VATOOLS_IOCTL_V2_WRITE_BUF _IO(VATOOLS_IOCTL_V2_MAGIC, 0x04)

/*Get reset event*/
#define VATOOLS_IOCTL_V2_DEVICE_EVENT _IO(VATOOLS_IOCTL_V2_MAGIC, 0x05)

/*core timestamp sync*/
#define VATOOLS_IOCTL_V2_CORE_TIME_SYNC _IO(VATOOLS_IOCTL_V2_MAGIC, 0x06)
enum e_ioctl_core_time_sync_sub_cmd {
	VATOOLS_IOCTL_CORE_TIME_SYNC_STOP = 0, /*Stop clock synchronization*/
	VATOOLS_IOCTL_CORE_TIME_SYNC_START = 1, /*Start clock synchronization*/
	VATOOLS_IOCTL_CORE_TIME_SYNC_READ =
		2, /*Read CSRAM clock synchronization data*/
};

/*Read and write data via SMI, write first, trigger interrupt to SMCU, read later, read and write is done with a single
 * call*/
#define VATOOLS_IOCTL_V2_SMI_CMD _IO(VATOOLS_IOCTL_V2_MAGIC, 0x07)
/*ioctl smi sub cmd*/
enum e_ioctl_smi_sub_cmd {
	VATOOLS_IOCTL_SMI_NONE = 0,
	VATOOLS_IOCTL_SMI_READ = 1,
	VATOOLS_IOCTL_SMI_WRITE = 2,
	VATOOLS_IOCTL_SMI_FETCH = 3,
};

/*A command family that is processed through PCIe*/
#define VATOOLS_IOCTL_V2_PCIE_CMD _IO(VATOOLS_IOCTL_V2_MAGIC, 0x08)
/*ioctl pcie type/cmd command, do not use smcu. Drive direct processing*/
enum e_ioctl_pcie_sub_cmd {
	VATOOLS_IOCTL_PCIE_NONE = 0,
	VATOOLS_IOCTL_PCIE_BANDWIDTH = 1,
	VATOOLS_IOCTL_PCIE_RESET = 2,
	VATOOLS_IOCTL_PCIE_REBOOT = 3,
	VATOOLS_IOCTL_PCIE_STRING = 4,
	VATOOLS_IOCTL_PCIE_FW_VERSION = 5,
	VATOOLS_IOCTL_PCIE_DDR_ECC_1BIT = 6,
	VATOOLS_IOCTL_PCIE_DDR_ECC_2BIT = 7,
	VATOOLS_IOCTL_PCIE_VDSP_COUNT = 8,
	VATOOLS_IOCTL_PCIE_AI_COUNT = 9, /*512bytes  PERFORMANCE_AI_BASE*/
	VATOOLS_IOCTL_PCIE_RING_BUF_STATISTIC = 10,
	VATOOLS_IOCTL_PCIE_SET_VIDEO_MULTI_CORE =
		11, /*Set video to use multicore; 0: Not used; 1: Use*/
	VATOOLS_IOCTL_PCIE_GET_VIDEO_MULTI_CORE =
		12, /*Get video multicore mode and job count*/
	VATOOLS_IOCTL_PCIE_MAX
};

#define VATOOLS_IOCTL_V2_PROFILER _IO(VATOOLS_IOCTL_V2_MAGIC, 0x0a)
enum e_ioctl_profiler_sub_cmd {
	VATOOLS_IOCTL_PROFILER_NONE = 0,
	VATOOLS_IOCTL_PROFILER_PERFMON_READ = 1, /*Read the perfmon register*/
	VATOOLS_IOCTL_PROFILER_PERFMON_WRITE =
		2, /*Write to the perfmon register*/
	/*profiler command code to collect data*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_STOP = 3, /*Stop acquisition*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_START = 4, /*Start the collection*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_READ_RPWP =
		5, /*Read and write pointers. fw does not receive this command*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_WRITE_RPWP =
		6, /*Write read/write pointers. fw does not receive this command*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_READ_DATA =
		7, /*Read DDR data. fw does not receive this command*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_READ_CTRL = 8, /*Read control*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_READ_PCIE_DMA =
		9, /*PCIE dma data acquisition*/
	VATOOLS_IOCTL_PROFILER_TIMELINE_READ_PCIE_MSG =
		10, /*PCIE msg data acquisition*/
	VATOOLS_IOCTL_PROFILER_MAX
};

#define VATOOLS_IOCTL_V2_FLASH _IO(VATOOLS_IOCTL_V2_MAGIC, 0x0b)
enum e_ioctl_flash_sub_cmd {
	VATOOLS_IOCTL_FLASH_NONE = 0,
	VATOOLS_IOCTL_FLASH_BMCU_FW = 1, /*Burn into the BMCU FW version*/
	VATOOLS_IOCTL_FLASH_XSPI_FW = 2, /*Burn into the XSPI FW version*/
	VATOOLS_IOCTL_FLASH_GET_FLASH_STATUS = 3, /*Get the flashing status*/
	VATOOLS_IOCTL_FLASH_SWITCH_BMCU = 4, /*Switch the BMCU version*/
	VATOOLS_IOCTL_FLASH_PMCU_FW = 5, /*Burn in the PMCU fw version*/
	VATOOLS_IOCTL_FLASH_FULL_BL0_FW = 6, /*Burn full bl0 fw version*/
};

/*fetch firmware log status*/
#define VATOOLS_IOCTL_V2_LOG_STATUS _IO(VATOOLS_IOCTL_V2_MAGIC, 0x0c)
/*Dma*/
#define VATOOLS_IOCTL_V2_DMA _IO(VATOOLS_IOCTL_V2_MAGIC, 0x0d)
enum e_ioctl_dma_sub_cmd {
	VATOOLS_IOCTL_DMA_NONE = 0,
	VATOOLS_IOCTL_DMA_ALLOC = 1, /*Allocate DMA memory*/
	VATOOLS_IOCTL_DMA_START = 2, /*Start DMA transfer data*/
	VATOOLS_IOCTL_DMA_FREE = 3, /*Free up DMA memory*/
};

/*Use kernel mutex to implement process mutex protection*/
#define VATOOLS_IOCTL_V2_GUARD _IO(VATOOLS_IOCTL_V2_MAGIC, 0x0f)
enum e_ioctl_guard_sub_cmd {
	VATOOLS_IOCTL_GUARD_NONE = 0,
	VATOOLS_IOCTL_GUARD_LOCK = 1, /*Lock*/
	VATOOLS_IOCTL_GUARD_UNLOCK = 2, /*unlock*/
	VATOOLS_IOCTL_GUARD_TRYLOCK = 3, /*trylock*/
	VATOOLS_IOCTL_GUARDU_IS_LOCKED = 4, /*is locked*/
};
#define VATOOLS_IOCTL_GUARD_NAME_LENGTH (256)

/*Shared memory*/
#define VATOOLS_IOCTL_V2_SHARE_MEM _IO(VATOOLS_IOCTL_V2_MAGIC, 0x10)
enum e_ioctl_share_mem_sub_cmd {
	VATOOLS_IOCTL_SHARE_MEM_NONE = 0,
	VATOOLS_IOCTL_SHARE_MEM_CREATE = 1, /*Create shared memory information*/
	VATOOLS_IOCTL_SHARE_MEM_DELETE = 2, /*Delete shared memory information*/
	VATOOLS_IOCTL_SHARE_MEM_READ = 3, /*Get shared memory information*/
	VATOOLS_IOCTL_SHARE_MEM_WRITE = 4, /*Write shared memory information*/
	VATOOLS_IOCTL_SHARE_MEM_POLL = 5, /*Wait for the message to start*/
};

/*debug videos and shared memory subcommands*/
#define VATOOLS_IOCTL_V2_VIDEO_DEBUGGER _IO(VATOOLS_IOCTL_V2_MAGIC, 0x11)
enum e_ioctl_video_debugger_sub_cmd {
	VATOOLS_IOCTL_VIDEO_DEBUGGER_NONE = 0,
	VATOOLS_IOCTL_VIDEO_DEBUGGER_START =
		11, /*Start video debugger message*/
	VATOOLS_IOCTL_VIDEO_DEBUGGER_STOP = 12, /*Stop video debugger message*/
	VATOOLS_IOCTL_VIDEO_DEBUGGER_READ = 13, /*Read video debugger message*/
	VATOOLS_IOCTL_VIDEO_DEBUGGER_WRITE =
		14, /*Write video debugger message*/
	VATOOLS_IOCTL_VIDEO_DEBUGGER_FUNCTION_CREATE =
		15, /*Additional callback function*/
	VATOOLS_IOCTL_VIDEO_DEBUGGER_FUNCTION_DELETE =
		16, /*Delete the callback function*/
};

/*there debug*/
#define VATOOLS_IOCTL_V2_AI_DEBUGGER _IO(VATOOLS_IOCTL_V2_MAGIC, 0x12)
enum e_ioctl_ai_debugger_sub_cmd {
	VATOOLS_IOCTL_AI_DEBUGGER_NONE = 0,
	VATOOLS_IOCTL_AI_DEBUGGER_CONFIG =
		1, /*Configure the debugging tool command*/
	VATOOLS_IOCTL_AI_DEBUGGER_SET = 2, /*Set the debugging tool command*/
	VATOOLS_IOCTL_AI_DEBUGGER_GET = 3, /*Read the debugging tool command*/
	VATOOLS_IOCTL_AI_DEBUGGER_FETCH =
		4, /*Get the die index test tool command*/
};

/*get vatools_v2_base_info_u, version and device_number etc.*/
#define VATOOLS_IOCTL_V2_BASE_INFO _IO(VATOOLS_IOCTL_V2_MAGIC, 0x13)

/*command scope*/
enum e_ioctl_cmd_domain {
	VATOOLS_IOCTL_DOMAIN_NONE = 0, /*No scope information*/
	VATOOLS_IOCTL_DOMAIN_DEVICE = 1 << 0, /*card-level commands*/
	VATOOLS_IOCTL_DOMAIN_DIE = 1 << 1, /*the level command*/
	VATOOLS_IOCTL_DOMAIN_SOFTWARE_LAYER =
		1 << 2, /*driver-level command, not delivered to SMI*/
	VATOOLS_IOCTL_DOMAIN_MAX = 1 << 3, /**/
};

/*alloc and free video capability*/
#define VATOOLS_IOCTL_V2_VIDEO_CAPABILITY_ALLOC_FREE                           \
	_IO(VATOOLS_IOCTL_V2_MAGIC, 0x14)

/// tongxinyuan dma test requirement
#define VATOOLS_IOCTL_V2_TXY_DMA_TEST _IO(VATOOLS_IOCTL_V2_MAGIC, 0x15)

#define VIDEO_CAPABILITY_READ  0
#define VIDEO_CAPABILITY_WRITE 1
struct video_capability_manage {
	uint32_t version;
	uint32_t die_index;
	uint32_t die_seq;
	uint32_t video_type;
	uint32_t sub_cmd;
	struct vatools_occupy_die die_weights[ALLOC_VIDEO_MAX]
					     [MAX_OCCUPY_DIE_NUM];
	struct vatools_occupy_die die_weights_real[ALLOC_VIDEO_MAX]
						  [MAX_OCCUPY_DIE_NUM];
};

typedef struct buf_ptr_s {
	u32 buf_size;
	/*void *buf_addr;*/
	u64 buf_addr;
} buf_ptr_t;

/*The host uses IOCTL and drivers for data exchange and transmission*/
typedef struct ioctl_arg_s {
	u32 sub_cmd; /*Depending on the ioctl command, it is parsed as a subcommand of the corresponding command*/
	union die_index_data die_index; /*The universal die index*/
	u32 block_id; /*The SMI command uses block IDs, each with its own csram region*/
	u32 lock_domain; /*command scope, which is used to determine the lock*/
	i64 errcode; /*Call kernel ioctl to return a value*/
	u64 address; /*Common data address parameter*/
	u64 value; /*Common data value parameter*/
	u32 count; /*Common counting parameters*/
	buf_ptr_t input_buf; /*host side to write fw's data buffer. Data: host->fw*/
	buf_ptr_t output_buf; /*host side stores the data buffer returned by fw. Data: fw->host*/

#if (TOOLS_WIN == 1) /*for win DeviceIoControl*/
	LPDWORD lpBytesReturned;
	u64 lpOverlapped; /*lpoverlapped*/
#else
	u64 rsvd1; /*is used to align with the win driver bytes*/
	u64 rsvd2; /*is used to align with the win driver bytes*/
#endif
	u32 rsvd[8];
} ioctl_arg_t;

/*DMA Memory Allocation Command*/
typedef struct dma_alloc_cmd_s {
	HANDLE dma_buf_fd;
	UINT64 hostva;
	u32 size;
	u32 die_index;
} dma_alloc_cmd_t;

/*DMA Initiation Command*/
typedef struct dma_start_cmd_s {
	u32 is_dev_to_host;
	HANDLE dma_buf_fd;
	u64 axi_addr;
	u32 size;
	u32 die_index;
} dma_start_cmd_t;

/*User-space memory is passed directly to the kernel, eliminating the need for DMA Alloc memory before use*/
typedef struct dma_trans_cmd_s {
	u32 is_dev_to_host;
	u64 vir_addr;
	u64 axi_addr;
	u32 length;
	u32 die_index;
	int pid;
} dma_trans_cmd_t;

/*upper is ioctl generic command V2 version*/
#endif

/*Gets information about the current process*/
typedef struct vatools_current_process_info_s {
	u32 die_index;
	u32 pid;
	u32 vpid;
	u32 level;
	u64 ns;
	u32 resvd[4];
} vatools_current_process_info_t;

/*TODO: rutime info*/
/*struct from vaccrt*/
/*defined in vastai_ai.h*/
/*runtime info struct for tools*/
/*Each die has a structure*/
typedef struct vatools_runtime_info_head_s {
	u32 die_index;
	u32 die_id; /*is vacc0, vacc1 ...; not device.die_id*/
	u32 ai_version;
	u32 zone_count;
	u32 process_count;
	char ai_version_str[32];
} vatools_runtime_info_head_t;
/*Each die has a structure*/
typedef enum {
	TOOLS_ZONE_STREAM, // CSRAM, STREAM_INFO
	TOOLS_ZONE_MODEL, // DDR LOCAL SHARE, MODEL_INFO OPCODE_CSR
	TOOLS_ZONE_VDSP_OPERATOR, // DDR VDSP0 ENTRY1, CODE
	TOOLS_ZONE_SHARE, // DDR SHARE WEIGHT, MODEL INPUT/OUTPUT, VIDEO
	TOOLS_ZONE_ODSP_OPERATOR, // DDR ODSP0 ENTRY1, CODE
	TOOLS_ZONE_COUNT,
} tools_zone_type_t;
typedef struct vatools_runtime_zone_usage_s {
	u32 die_index;
	u64 ddr_total_size;
	vacc_zone_usage_t zone_usage[TOOLS_ZONE_COUNT];
} vatools_runtime_zone_usage_t;
/*Each process has a structure*/
typedef struct vatools_runtime_process_info_s {
	u32 die_index;
	u32 pid;
	u32 vpid;
	u32 level;
	u64 ns;
	u64 zone_used[TOOLS_ZONE_COUNT];
} vatools_runtime_process_info_t;

typedef struct vastai_runtime_statistic_s {
	u32 info_head_max_num; /*The maximum value to which data can be accessed*/
	u32 info_head_num; /*The maximum value of the data read*/
	u64 info_head_p; /*vatools_runtime_info_head_t **/
	u32 zone_usage_max_num; /*The maximum value to which data can be accessed*/
	u32 zone_usage_num; /*The maximum value of the data read*/
	u64 zone_usage_p; /*vatools_runtime_zone_usage_t **/
	u32 process_info_max_num; /*The maximum value to which data can be accessed*/
	u32 process_info_num; /*The maximum value of the data read*/
	u64 process_info_p; /*vatools_runtime_process_info_t **/
	vatools_current_process_info_t
		current_process_info; /*Gets information about the current process*/
} vastai_runtime_statistic_t;

/*DDR bandwidth*/
#define DDR_MC_PHY_MAX		  (16)
#define DDR_MC_PHY_PORT_MAX	  (16)
#define SG100_DDR_MC_PHY_MAX	  (8)
#define SV100_DDR_MC_PHY_MAX	  (4)
#define SG100_DDR_MC_PHY_PORT_MAX (4)
#define SV100_DDR_MC_PHY_PORT_MAX (5)

/*
sv100
Port0: PCIe EP Master
Port1: ODMA0/1 rd/wr, wddma rd, odsp wr/rd, data_export wr, ctrans rd. (DAP_MNOC_mst_rd, DAP_MNOC_mst_wr)
Port2: encoder/decoder, VMCU dma.(DEC0-4_AXI_mst, ENC0-3_AXI_mst, vmcu dma)
Port3: V3D, Video DSP
Port4: SMCU/CMCU, Security DMA, PCIe RC Master

sg100
Port0: gfx
Port1: video
Port2: pcie ep rc, tcu,gmcu
Port3: pmcu,cedar,xspi,qspi,jtag,vdsp,odma,oak_ctrans,dataexp,wddma,lmcu,odsp,cmcu,dsu,smcu
*/

// old interface: compatible older driver
typedef struct __attribute__((packed)) vastai_ddr_bandwidth_mc_s {
	u64 upstream_count_mb; /*UPSTREAM read from ddr*/
	u64 downstream_count_mb; /*DOWNSTREAM write to ddr*/
} vastai_ddr_bandwidth_mc_t;

typedef struct __attribute__((packed)) vastai_ddr_bandwidth_s {
	vastai_ddr_bandwidth_mc_t ddr_bandwidth
		[SV100_DDR_MC_PHY_MAX]; /*Data collected by MC_PHY, in MB, compatible with previous drivers*/
} vastai_ddr_bandwidth_t;

// new interface: ddr monitor
typedef struct __attribute__((packed)) vastai_ddr_bandwidth_mc_count_monitor_s {
	u64 upstream_count; /* UPSTREAM read from ddr. unit: byte*/
	u64 downstream_count; /* DOWNSTREAM write to ddr. unit: byte*/
} vastai_ddr_bandwidth_mc_count_t;

typedef struct __attribute__((packed))
vastai_ddr_bandwidth_mc_count_detail_monitor_s {
	vastai_ddr_bandwidth_mc_count_t mc_count[DDR_MC_PHY_MAX]
						[DDR_MC_PHY_PORT_MAX];
} vastai_ddr_bandwidth_mc_count_detail_t;

typedef struct __attribute__((packed)) vastai_ddr_bandwidth_monitor_s {
	u64 sample_interval_us;
	vastai_ddr_bandwidth_mc_count_detail_t mc_count_detail[2]; // 2 samples
} vastai_ddr_bandwidth_monitor_t;

typedef struct __attribute__((packed)) vastai_ddr_bandwidth_data_s {
	vastai_ddr_bandwidth_mc_t ddr_bw_data[DDR_MC_PHY_MAX]
					     [DDR_MC_PHY_PORT_MAX];
} vastai_ddr_bandwidth_data_t;

/*Get Heartbeat stats*/
typedef struct vatools_heartbeat_count_s {
	u32 die_index;
	u32 heartbeat_counts[HEARTBEAT_MAX_CNT][SV_HEARTBEAT_CNT_REG_NUM];
} vatools_heartbeat_count_t;

/*The length of the topological relationship string between the CPU and the card device*/
#define CPU_AND_CARD_TOPO_STR_LEN 1024 * 10

enum device_node_name_e {
	DEV_NODE_TOOLS,
	DEV_NODE_VIDEO,
	DEV_NODE_AI,
	DEV_NODE_CTL,
	DEV_NODE_RENDER,
};

/*defined in SMCU FW: Card type definition. fw, driver*/
typedef enum {
	CARD_CLASS_VA1 = 0x00, /*Card Class Type for VA1 series card*/
	CARD_VA1 = 0x00,
	CARD_VA1V,
	CARD_VA1A,
	CARD_VA1E,
	CARD_CLASS_VE1 = 0x10, /*Card Class Type for VE1 series card*/
	CARD_VE1_S = 0x10,
	CARD_VE1_P,
	CARD_VE1_V,
	CARD_VE1_M, /*power module user va1m,have fan as ve1 config module*/
	CARD_VE1_C,
	CARD_CLASS_VA1X = 0x20, /*Card Class Type for VA1X series card*/
	CARD_VA1M = 0x20,
	CARD_VA1U,
	CARD_CLASS_VA10 = 0x30, /*Card Class Type for VA10 series card*/
	CARD_VA10 = 0x30,
	CARD_VA12,
	CARD_VA16,
	CARD_CLASS_VA100 = 0x40, /*Card Class Type for VA100 series card*/
	CARD_VA100 = 0x40,
	CARD_CLASS_VAM = 0x50, /*Card Class Type for VAM series card*/
	CARD_VAM = 0x50,
	CARD_CLASS_EVB = 0x80,
	CARD_EVB1 = 0x80,
	CARD_CLASS_UNKNOW = 0xf0,
} CARD_TYPE;

/*win compatible 32/64bit*/
struct file_operations_tool {
	struct module *owner;
	loff_t (*llseek)(struct file *, loff_t, int);
	ssize_t (*read)(struct file *, char __user *, size_t, loff_t *);
	ssize_t (*write)(struct file *, const char __user *, size_t, loff_t *);
	ssize_t (*read_iter)(struct kiocb *, struct iov_iter *);
	ssize_t (*write_iter)(struct kiocb *, struct iov_iter *);
	unsigned int (*poll)(struct file *, struct poll_table_struct *);
	long (*unlocked_ioctl)(struct file *, unsigned int, IOCTL_ARG_T);
	long (*compat_ioctl)(struct file *, unsigned int, IOCTL_ARG_T);
	int (*mmap)(struct file *, struct vm_area_struct *);
	int (*open)(struct inode *, struct file *);
	int (*release)(struct inode *, struct file *);
	int (*fasync)(int, struct file *, int);
};

/*Get PCIe bandwidth, compatible with all boards, including 3 directions*/
enum vatools_pcie_bw_direction_e {
	VATOOLS_PCIE_BW_UPSTREAM = 0, /*d2h*/
	VATOOLS_PCIE_BW_DOWNSTREAM = 1, /*h2d*/
	VATOOLS_PCIE_BW_DIRECTION
};

enum vatools_pcie_bw_type_e {
	VATOOLS_PCIE_BW_H_WITH_D_TYPE = 0,
	VATOOLS_PCIE_BW_D_WITH_D_TYPE = 1,
	VATOOLS_PCIE_BW_PKG_WITH_PKG_TYPE = 2,
	VATOOLS_PCIE_BW_TYPE_MAX
};

typedef struct vatools_pcie_bw_monitor_data_s {
	s32 return_value; /*0: Success <0: Failed*/
	u64 pcie_bw_count;
} vatools_pcie_bw_monitor_data_t;

typedef struct vatools_pcie_bw_monitor_s {
	u32 version;
	u32 die_index;
	u64 timestamp_ns; /*The moment of data collection. Unit: nanoseconds ns*/
	vatools_pcie_bw_monitor_data_t pcie_bw[VATOOLS_PCIE_BW_TYPE_MAX]
					      [VATOOLS_PCIE_BW_DIRECTION];
} vatools_pcie_bw_monitor_t;

#define RING_BUF_STATICS_TABLE_SIZE 47
extern T_RING_BUF_STATICS ring_buf_statics_table[RING_BUF_STATICS_TABLE_SIZE];
enum {
	ODSP_AS_ODSP = 0,
	ODSP_AS_VDSP = 1,
};
int check_if_is_odsp_as_vdsp(struct vastai_pci_info *priv, uint32_t die_index,
			     int odsp_id);

#define MAX_BDF_LEN 64
#define MAX_FN_NUM  7
// bdf input buffer need 8 * sizeof(struct bdf_info), first entry is pf bdf
struct bdf_info {
	uint32_t version; // default 1

	uint32_t is_valid;
	uint32_t domain;
	uint32_t bus;
	uint32_t dev;
	uint32_t func;
	char bdf_str[MAX_BDF_LEN];

	uint32_t rsvd[16];
};

typedef int (*set_desc_func)(struct vastai_dmadesc *, struct dma_buf *,
			     struct kchar_cmd *, int, u32, u32,
			     struct vastai_pci_info *);

extern int vastai_common_cut_p2p_buf(u32 size, struct kchar_cmd *kcmd,
				     struct vastai_dmadesc *desc,
				     struct vastai_pci_info *pci_info,
				     set_desc_func pSetDescFunc);
extern int vastai_ioctl_p2p_start_set_desc(struct vastai_dmadesc *desc,
					   struct dma_buf *dmabuf,
					   struct kchar_cmd *kcmd, int i,
					   u32 done_size, u32 temp_size,
					   struct vastai_pci_info *pci_info);
int vatools_ac_bench_dma_p2p(struct vatools_ac_bench_dma *ac_bench_dma);
int vatools_ac_bench_dma_d2d(struct vatools_ac_bench_dma *ac_bench_dma);
int vatools_ac_bench_dma_seq2seq(struct vatools_ac_bench_dma *ac_bench_dma);
void tools_test_init(struct vatools_node *node);
void tools_test_deinit(struct vatools_node *node);
u64 vatools_get_address_by_index(struct vastai_pci_info *priv,
				 AddressEnum index);
#define VATOOLS_CMD_BUF_LEN 4096
#define INVENTORY_VALID_SIG 0x5A

typedef enum vatools_rdma_memory_type {
	VATOOLS_RDMA_DEVICE_MEMORY = 0,
	VATOOLS_RDMA_HOST_MEMORY = 1
} vatools_rdma_memory_type_t;

struct vatools_rdmabuf_alloc {
	uint64_t size;
	uint64_t dma_addr_t;
	int dma_buf_fd;
	vatools_rdma_memory_type_t mem_type;
	uint32_t rsv[16];
};

#ifdef VATOOLS_HOT_PLUG_ENABLE
extern struct mutex vastai_pci_info_list_lock;
#endif

struct vatools_shared_addr_entry {
	struct list_head node;
	int32_t pid;
	uint64_t handle;
};
enum entry_delete_path {
	DELETE_ENTRY_FROM_DELETEMEM,
	DELETE_ENTRY_FROM_RELEASEEMEM,
};

#define TOOLS_MINOR 65520
extern unsigned int major;

#define ADDRESS_MAP_SIZE (2048 * 8)

#ifdef __cplusplus
}
#endif
#pragma pack(pop)

#endif /*__VATOOLS_DEFINE_H__*/
