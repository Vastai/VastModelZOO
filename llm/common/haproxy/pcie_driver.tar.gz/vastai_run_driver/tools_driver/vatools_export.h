﻿#ifndef __VATOOLS_EXPORT_H__
#define __VATOOLS_EXPORT_H__

#include "vatools.h"

#endif /*__VATOOLS_EXPORT_H__*/
