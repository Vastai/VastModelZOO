﻿#ifndef __VATOOLS_LOG_H__
#define __VATOOLS_LOG_H__

#if (TOOLS_WIN == 1)
/*on windows*/

#pragma pack(push)
#pragma pack(1)

#define VATOOLS_PREFIX "vastai [VATOOLS] "
#define DUMMY_DIE_ID   0xff

/*eliminate unused-var warning*/
#ifndef UNREFERENCED_PARAMETER
#define UNREFERENCED_PARAMETER(P) (P = P)
#endif

extern unsigned char vastai_pci_log_level;

/*vastai_pci_log_level = 0, printing pr_err information*/
#define VATOOLS_ERR(pcie, die_id, ...)                                         \
	do {                                                                   \
		VLOG_ERR(__VA_ARGS__);                                         \
	} while (0)

#define VATOOLS_ERR_RATELIMIT(pcie, die_id, ...)                               \
	do {                                                                   \
		VLOG_ERR(__VA_ARGS__);                                         \
	} while (0)

/*VASTAI_PCI_NORMAL_LEVEL, printing pr_info information*/
#define VATOOLS_INFO(pcie, die_id, ...)                                        \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_NORMAL_LEVEL) {          \
			VLOG_INFO(__VA_ARGS__);                                \
		}                                                              \
	} while (0)
#define VATOOLS_INFO_RATELIMIT(...)                                            \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_NORMAL_LEVEL)            \
			VLOG_INFO(__VA_ARGS__);                                \
	} while (0)

/*VASTAI_PCI_DEBUG_LEVEL, printing debug information*/
#define VATOOLS_DBG(pcie, die_id, ...)                                         \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {           \
			VLOG_DEBUG(__VA_ARGS__);                               \
		}                                                              \
	} while (0)
#define VATOOLS_DBG_RATELIMIT(...)                                             \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL)             \
			VLOG_DEBUG(__VA_ARGS__);                               \
	} while (0)

/*VASTAI_PCI_DATA_LEVEL, printing data or dump information*/
#define VATOOLS_HEX_DUMP(level, prefix_str, prefix_type, rowsize, groupsize,         \
			 buf, len, ascii)                                            \
	do {                                                                         \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL) {                 \
			if (len > 1024) {                                            \
				vatools_print_buffer_hex(prefix_str, buf,            \
							 1024);                      \
				VLOG_DEBUG(                                          \
					".... buffer len=%d, only dump 1k bytes.\n", \
					(unsigned int)len);                          \
			} else {                                                     \
				vatools_print_buffer_hex(prefix_str, buf,            \
							 len);                       \
			}                                                            \
		}                                                                    \
	} while (0)

#define VATOOLS_DUMP_BRIEF(title, buf, buf_size_byte)                          \
	VATOOLS_HEX_DUMP(KERN_DEBUG, title, DUMP_PREFIX_NONE, 32, 4, buf,      \
			 buf_size_byte, false)

#define VATOOLS_FUNC_ENTERY                                                    \
	VATOOLS_DBG_RATELIMIT("pid:%d %s entry!\n", PsGetCurrentThreadId(),    \
			      __func__)
#define VATOOLS_FUNC_EXIT                                                      \
	VATOOLS_DBG_RATELIMIT("pid:%d %s done!\n", PsGetCurrentThreadId(),     \
			      __func__)

#define VATOOLS_DUMP_DATA(title, buf, buf_size_byte)                           \
	do {                                                                   \
		VLOG_INFO("hex output not support: %s\n", title);              \
	} while (0)

#pragma pack(pop)

#else /*platform*/

#pragma pack(push)
#pragma pack(1)
extern unsigned char vastai_pci_log_level;

#define VATOOLS_PREFIX		  "tools [%s.%d tg:%d p:%d] "
#define VATOOLS_PREFIX_DUMP	  "vastai DUMP tools "
#define VATOOLS_DIE_ID(die_index) (die_index & 0xff)

#define __FILENAME__                                                           \
	(strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)

#define VATOOLS_ERR(pcie, die_id, fmt, args...)                                \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_ERR(pcie, VATOOLS_DIE_ID(die_id),                   \
			       VATOOLS_PREFIX "die_index=0x%08x " fmt,         \
			       vatools_log_brief_filename(__FILENAME__,        \
							  __func__, __fname),  \
			       __LINE__, current->tgid, current->pid, die_id,  \
			       ##args);                                        \
	} while (0)

#define VATOOLS_ERR_RATELIMIT(pcie, die_id, fmt, args...)                      \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_ERR_RATELIMIT(                                      \
			VATOOLS_PREFIX "die_index=0x%08x " fmt,                \
			vatools_log_brief_filename(__FILENAME__, __func__,     \
						   __fname),                   \
			__LINE__, current->tgid, current->pid, die_id,         \
			##args);                                               \
	} while (0)

#define VATOOLS_INFO(pcie, die_id, fmt, args...)                               \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_INFO(pcie, VATOOLS_DIE_ID(die_id),                  \
				VATOOLS_PREFIX "die_index=0x%08x " fmt,        \
				vatools_log_brief_filename(__FILENAME__,       \
							   __func__, __fname), \
				__LINE__, current->tgid, current->pid, die_id, \
				##args);                                       \
	} while (0)

#define VATOOLS_INFO_RATELIMIT(pcie, die_id, fmt, args...)                     \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_INFO_RATELIMIT(                                     \
			VATOOLS_PREFIX "die_index=0x%08x " fmt,                \
			vatools_log_brief_filename(__FILENAME__, __func__,     \
						   __fname),                   \
			__LINE__, current->tgid, current->pid, die_id,         \
			##args);                                               \
	} while (0)

#define VATOOLS_DBG(pcie, die_id, fmt, args...)                                \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_DBG(pcie, VATOOLS_DIE_ID(die_id),                   \
			       VATOOLS_PREFIX "%s "                            \
					      "die_index=0x%08x " fmt,         \
			       vatools_log_brief_filename(__FILENAME__,        \
							  __func__, __fname),  \
			       __LINE__, current->tgid, current->pid,          \
			       __func__, die_id, ##args);                      \
	} while (0)

#define VATOOLS_DBG_RATELIMIT(pcie, die_id, fmt, args...)                      \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_DBG_RATELIMIT(                                      \
			VATOOLS_PREFIX "%s "                                   \
				       "die_index=0x%08x " fmt,                \
			vatools_log_brief_filename(__FILENAME__, __func__,     \
						   __fname),                   \
			__LINE__, current->tgid, current->pid, __func__,       \
			die_id, ##args);                                       \
	} while (0)

#define VATOOLS_PERF(fmt, args...)                                             \
	do {                                                                   \
		char __fname[3];                                               \
		VASTAI_PCI_PERF(VATOOLS_PREFIX "die_index=0x%08x " fmt,        \
				vatools_log_brief_filename(__FILENAME__,       \
							   __func__, __fname), \
				__LINE__, current->tgid, current->pid,         \
				DUMMY_DIE_ID, ##args);                         \
	} while (0)

#define VATOOLS_DUMP_DATA(title, buf, buf_size_byte)                           \
	do {                                                                   \
		print_hex_dump(KERN_INFO, title, DUMP_PREFIX_NONE, 32, 4, buf, \
			       buf_size_byte, false);                          \
	} while (0)

#define VATOOLS_DUMP_BRIEF(title, buf, buf_size_byte)                          \
	do {                                                                   \
		if (vastai_pci_log_level & VASTAI_PCI_DEBUG_LEVEL)             \
			print_hex_dump(KERN_DEBUG, VATOOLS_PREFIX_DUMP title,  \
				       DUMP_PREFIX_NONE, 32, 4, buf,           \
				       buf_size_byte, false);                  \
	} while (0)

#define VATOOLS_FUNC_ENTERY                                                    \
	VATOOLS_DBG_RATELIMIT(NULL, DUMMY_DIE_ID, "%s entry!\n", __func__)

#define VATOOLS_FUNC_EXIT                                                      \
	VATOOLS_DBG_RATELIMIT(NULL, DUMMY_DIE_ID, "%s exit!\n", __func__)

#define VATOOLS_FUNC_ENTER_INFO                                                \
	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "pid:%d %s entry!\n", current->pid,   \
		     __func__)

#define VATOOLS_FUNC_EXIT_INFO                                                 \
	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "pid:%d %s exit!\n", current->pid,    \
		     __func__)
#pragma pack(pop)
#endif /*end of platform*/

#endif /*__VATOOLS_LOG_H__*/

/*trace function*/
#undef TRACE_SYSTEM
#define TRACE_SYSTEM vatools

#if !defined(__VATOOLS_TRACE_H__) || defined(TRACE_HEADER_MULTI_READ)
#define __VATOOLS_TRACE_H__
#include <linux/tracepoint.h>
#include "vatools.h"

DECLARE_EVENT_CLASS(
	vatools_trace_time_class,

	TP_PROTO(struct vastai_pci_info *t, u32 die_id, u32 dev_id, u32 seq_num,
		 const char *str),

	TP_ARGS(t, die_id, dev_id, seq_num, str),

	TP_STRUCT__entry(__field(int, state) __field(u32, die_id)
				 __field(u32, dev_id) __field(u32, seq_num)
					 __field(u64, time)
						 __array(char, need, 64)),

	TP_fast_assign(__entry->die_id = die_id; __entry->dev_id = dev_id;
		       strcpy(__entry->need, str); __entry->seq_num = seq_num;
		       __entry->time = jiffies;),

	TP_printk("%s:%u:%u:%u: time %u us", __entry->need, __entry->die_id,
		  __entry->dev_id, __entry->seq_num,
		  jiffies_to_usecs(__entry->time)));

#define DEFINE_ATTR_TIME_CLASS_EVENT(name)                                     \
	DEFINE_EVENT(vatools_trace_time_class, name,                           \
		     TP_PROTO(struct vastai_pci_info *t, u32 die_id,           \
			      u32 dev_id, u32 seq_num, const char *str),       \
		     TP_ARGS(t, die_id, dev_id, seq_num, str))

DEFINE_ATTR_TIME_CLASS_EVENT(smi_fetch_start);
DEFINE_ATTR_TIME_CLASS_EVENT(smi_fetch_end);
DEFINE_ATTR_TIME_CLASS_EVENT(sharedmem_ioctl_start);
DEFINE_ATTR_TIME_CLASS_EVENT(sharedmem_ioctl_end);
DEFINE_ATTR_TIME_CLASS_EVENT(ioctl_v2_get_device_info_start);
DEFINE_ATTR_TIME_CLASS_EVENT(ioctl_v2_get_device_info_end);

#endif

#undef TRACE_INCLUDE_PATH
#define TRACE_INCLUDE_PATH .
#define TRACE_INCLUDE_FILE vatools_log

#include <trace/define_trace.h>
