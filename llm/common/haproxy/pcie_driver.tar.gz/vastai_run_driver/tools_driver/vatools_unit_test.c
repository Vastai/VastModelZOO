#include "vatools.h"
#include "vatools_log.h"

#ifdef VATOOLS_DRIVER_TEST_NODE
struct class *toolclass;

static inline unsigned long tools_test_args_value(struct tools_test_arg_t *args,
						  unsigned char index)
{
	unsigned char i;

	for (i = 0; i < TOOLS_ARG_MAX; i++) {
		if (index == args[i].id)
			return args[i].def;
	}

	return -1;
}

int tools_test_example(struct tools_char_drv_info *dev,
		       struct vastai_pci_info *priv)
{
	return 0;
}

static int p2p_test(struct tools_char_drv_info *dev,
		    struct vastai_pci_info *priv)
{
	struct vatools_ac_bench_dma ac_bench_dma = { 0 };
	int ret = 0;

	ac_bench_dma.from.die_index.val =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_DIE_INDEX);
	ac_bench_dma.to.die_index.val =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_DIE_INDEX);

	ac_bench_dma.from.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_AXI_ADDR);
	ac_bench_dma.to.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_AXI_ADDR);

	ac_bench_dma.from.size =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_SIZE);
	ac_bench_dma.loop =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_LOOP);
	ret = vatools_ac_bench_dma_p2p(&ac_bench_dma);
	if (ret < 0)
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
			     __func__, ret);
	return ret;
}

static int d2d_test(struct tools_char_drv_info *dev,
		    struct vastai_pci_info *priv)
{
	struct vatools_ac_bench_dma ac_bench_dma = { 0 };
	int ret = 0;

	ac_bench_dma.from.die_index.val =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_DIE_INDEX);

	ac_bench_dma.from.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_AXI_ADDR);
	ac_bench_dma.direction =
		tools_test_args_value(dev->args, TOOLS_ARG_DIRECTION);

	ac_bench_dma.to.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_AXI_ADDR);

	ac_bench_dma.from.size =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_SIZE);
	ac_bench_dma.loop =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_LOOP);

	ret = vatools_ac_bench_dma_d2d(&ac_bench_dma);
	if (ret < 0)
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "%s: vatools_ac_bench_dma_p2p fail, ret %d\n",
			     __func__, ret);
	return ret;
}

static int seq2seq_test(struct tools_char_drv_info *dev,
			struct vastai_pci_info *priv)
{
	struct vatools_ac_bench_dma ac_bench_dma = { 0 };
	int ret = 0;

	ac_bench_dma.from.die_index.val =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_DIE_INDEX);
	ac_bench_dma.to.die_index.val =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_DIE_INDEX);

	ac_bench_dma.from.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_SRC_AXI_ADDR);

	ac_bench_dma.to.axi_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_AXI_ADDR);
	ac_bench_dma.to.pcie_bar_addr =
		tools_test_args_value(dev->args, TOOLS_ARG_DST_BAR_ADDR);

	ac_bench_dma.from.size =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_SIZE);
	ac_bench_dma.loop =
		tools_test_args_value(dev->args, TOOLS_ARG_TRANS_LOOP);

	VATOOLS_INFO(NULL, DUMMY_DIE_ID,
		     "from die_index 0x%x , dst die_index 0x%x, direciton %d\n",
		     ac_bench_dma.from.die_index.val,
		     ac_bench_dma.to.die_index.val, ac_bench_dma.direction);
	ret = vatools_ac_bench_dma_seq2seq(&ac_bench_dma);
	if (ret < 0)
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "%s: vatools_ac_bench_dma_seq2seq fail, ret %d\n",
			     __func__, ret);
	return ret;
}

static int tools_product_show(struct tools_char_drv_info *dev,
			      struct vastai_pci_info *priv)
{
	char *spi_buf = NULL;
	int ret = 0;
	uint32_t die_index = 0;
	uint32_t die_id = 0;
	uint32_t device_id = 0;
	uint32_t die_seq = 0;
	char file_version[5] = { 0 };
	char card_type[32] = { 0 };
	char unid[32] = { 0 };
	char bbox_mode[32] = { 0 };
	char bbox_type[32] = { 0 };
	const char *cardType = "N/A";
	const char *unidStr = "N/A";
	const char *bboxMode = "N/A";
	VATOOLS_FUNC_ENTER_INFO;

	die_id = tools_test_args_value(dev->args, TOOLS_ARG_DIE_ID);
	device_id = tools_test_args_value(dev->args, TOOLS_ARG_DEVICE_ID);
	die_seq = tools_test_args_value(dev->args, TOOLS_ARG_DIE_SEQ);

	die_index = die_id << 24 | device_id << 8 | die_seq;

	VATOOLS_INFO(NULL, DUMMY_DIE_ID,
		     "target[0x%x: 0x%x: 0x%x], die_index 0x%x\n", die_id,
		     device_id, die_seq, die_index);
	spi_buf = vmalloc(SPI_BUF_LEN_MAX);
	if (spi_buf == NULL) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vmalloc spi_buf error. size=%d\n",
			     SPI_BUF_LEN_MAX);
		ret = -1;
		goto out;
	}

	memset(spi_buf, 0, SPI_BUF_LEN_MAX);
	ret = vatools_get_spi_buf(die_index, SPI_BLOCK_PRODUCT_INFO, 0,
				  SPI_BUF_LEN_MAX, spi_buf);
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "vatools_get_spi_buf err, ret %d\n", ret);
		ret = -1;
		goto out_free;
	}
	ret = 0;

	memcpy(file_version, spi_buf, 4);
	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "file_version: %s\n", file_version);
	if (strcmp(file_version, "V2\0") == 0) {
		memcpy(card_type, spi_buf + 0x4, 16);
		memcpy(unid, spi_buf + 0x3C, 16);
		memcpy(bbox_type, spi_buf + 0x5C, 16);
		memcpy(bbox_mode, bboxMode, 4);
#if 0
            char* pbbox_type =
                vatools_get_bbox_mode_forsmi( dev_info[ dev ].info.die_num, bbox_type, dev_info[ dev ].info.card_type );
            // 写入bboxmode
            if ( pbbox_type && 0 != strlen( pbbox_type ) )
            {
                memcpy( dev_info[ dev ].info.bbox_mode, pbbox_type, strlen( pbbox_type ) );
            }
#endif
	} else if (strcmp(file_version, "V1\0") == 0) {
		memcpy(card_type, spi_buf + 0x4, 8);
		memcpy(unid, spi_buf + 0x34, 16);
		memcpy(bbox_mode, bboxMode, 4);
	} else {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "unknown file_version: %s\n",
			     file_version);
		memcpy(card_type, cardType, 4);
		memcpy(unid, unidStr, 4);
		memcpy(bbox_mode, bboxMode, 4);
	}

	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s ret %d\n", __func__, ret);
	VATOOLS_INFO(
		NULL, DUMMY_DIE_ID,
		"target[0x%x: 0x%x: 0x%x], die_index 0x%x, card_type = %s\n",
		die_id, device_id, die_seq, die_index, card_type);
	VATOOLS_INFO(
		NULL, DUMMY_DIE_ID,
		"target[0x%x: 0x%x: 0x%x], die_index 0x%x, unid(S/N) = %s\n",
		die_id, device_id, die_seq, die_index, unid);
	VATOOLS_INFO(
		NULL, DUMMY_DIE_ID,
		"target[0x%x: 0x%x: 0x%x], die_index 0x%x, bbox_mode = %s\n",
		die_id, device_id, die_seq, die_index, bbox_mode);

out_free:
	vfree(spi_buf);
out:
	VATOOLS_FUNC_EXIT_INFO;
	return ret;
}

static struct tools_test_arg_t tools_test_args_default[TOOLS_ARG_MAX] = {
	{ TOOLS_ARG_ADDR, "addr", 0 },
	{ TOOLS_ARG_VAL, "val", 0 },
	{ TOOLS_ARG_LEN, "len", 4 },
	{ TOOLS_ARG_DIE_ID, "dieid", 0 },
	{ TOOLS_ARG_DEVICE_ID, "deviceid", 0 },
	{ TOOLS_ARG_DIE_SEQ, "dieseq", 0 },
	{ TOOLS_ARG_DIE_INDEX, "dieindex", 0 },
	{ TOOLS_ARG_SRC_DIE_INDEX, "srcdieindex", 0 },
	{ TOOLS_ARG_SRC_AXI_ADDR, "srcaxiaddr", 0 },
	{ TOOLS_ARG_DST_DIE_INDEX, "dstdieindex", 0 },
	{ TOOLS_ARG_DST_BAR_ADDR, "dstbaraddr", 0 },
	{ TOOLS_ARG_DST_AXI_ADDR, "dstaxiaddr", 0 },
	{ TOOLS_ARG_TRANS_SIZE, "transsize", 0 },
	{ TOOLS_ARG_DIRECTION, "direction", 0 },
	{ TOOLS_ARG_TRANS_LOOP, "transloop", 0 },
};

static struct tools_test_info tools_test_info_array[] = {
	{ "test_example", tools_test_example },
	{ "show_product_info", tools_product_show },
	{ "p2p_test", p2p_test },
	{ "d2d_test", d2d_test },
	{ "seq2seq_test", seq2seq_test },
};

static void tools_test_args_init(struct tools_test_arg_t *args)
{
	unsigned int i;

	for (i = 0; i < TOOLS_ARG_MAX; i++)
		*(args + i) = tools_test_args_default[i];
}

static int tools_test_cmdline_args(char *cmdline, char *cmd,
				   struct tools_test_arg_t *args, int argc)
{
	int status = 0, DONE, FOUND = 0;
	char *end, *argname, *cp;
	unsigned short base;
	unsigned long result, value, val, i, j;

	for (i = 0; i < argc; i++)
		args[i].def = VASTAI_VAL_DW_MASK;

	/* get cmd */
	while (*cmdline == ' ' || *cmdline == '\t')
		cmdline++;

	while (*cmdline != ' ' && *cmdline != '\t' && *cmdline != '\0') {
		*cmd = *cmdline;
		cmd++;
		cmdline++;
	}
	*cmd = '\0';
	if (*cmdline == '\0')
		goto WEDONE;

	*cmdline = '\0';
	cmdline++;
	while (*cmdline == ' ' || *cmdline == '\t')
		cmdline++;

	end = cmdline;
	while (*end == ' ' || *end == '\t')
		end++;

	/*
	 * Parse cmdline
	 */
	DONE = (*end == '\0') ? 1 : 0;
	while (!DONE) {
		/* get the register name */
		while (*end != '=' && *end != '\0')
			end++;
		if (*end == '\0') {
			status = 1;
			goto WEDONE;
		}
		*end = '\0';
		argname = cmdline;
		/* now get value to write to register */
		cmdline = ++end;
		/* if there's whitespace after the '=', exit with an error */
		if (*end == ' ' || *end == '\t' || *end == '\n') {
			status = 1;
			goto WEDONE;
		}
		while (*end != ' ' && *end != '\t' && *end != '\n' &&
		       *end != '\0')
			end++;
		if (*end == '\0')
			DONE = 1;
		else
			*end = '\0';

		if (!strcmp(argname, "file") || !strcmp(argname, "filec")) {
			val = 1;
		} else {
			/* get the base, convert value to base-10 if necessary
			 */
			val = 0;
			result = 0;
			cp = cmdline;
			if (cp[0] == '0' && (cp[1] == 'x' || cp[1] == 'X')) {
				base = 16;
				cp += 2;

			} else {
				base = 10;
			}
			while (isxdigit(*cp)) {
				value = isdigit(*cp) ?
						(*cp - '0') :
						((islower(*cp) ? toupper(*cp) :
								 *cp) -
						 'A' + 10);

				result = result * base + value;
				cp++;
			}

			val = result;
		}

		FOUND = 0;
		/*
		 * verify the register arg is valid, and if the value is not
		 * too big, write it to the corresponding location in arg_vals
		 */
		for (j = 0; j < argc && !FOUND; j++) {
			if (!strcmp(argname, args[j].name)) {
				args[j].def = val;
				FOUND = 1;
			}
		}
		if (!FOUND) {
			VASTAI_PCI_ERR(NULL, DUMMY_DIE_ID, "arg %s err\n",
				       argname);
			status = 0;
			goto WEDONE;
		}

		/*
		 * point cmdline and end to next non-whitespace
		 * (next argument)
		 */
		cmdline = ++end;
		while (*cmdline == ' ' || *cmdline == '\t' || *cmdline == '\n')
			cmdline++;
		end = cmdline;
		/*
		 * if, after skipping whitespace, we hit end of line or EOF,
		 * we're done
		 */
		if (*end == '\0')
			DONE = 1;
	}

WEDONE:
	return status;
}

static int tools_char_open(struct inode *inode, struct file *filp)
{
	struct tools_file_info *file_info;
	struct tools_char_drv_info *drv;
	struct tools_char_drv_info *an_drv;

	VATOOLS_FUNC_ENTER_INFO;
	file_info = container_of(inode->i_cdev, struct tools_file_info, dev);
	drv = container_of(file_info, struct tools_char_drv_info, file_info);

	an_drv = kmalloc(sizeof(*drv), GFP_KERNEL);
	if (!an_drv) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "an_drv kmalloc fail\n");
		return -ENOMEM;
	}
	memcpy(an_drv, drv, sizeof(*drv));

	tools_test_args_init(an_drv->args);
	filp->private_data = an_drv;
	VATOOLS_FUNC_EXIT_INFO;

	return 0;
}

static int tools_char_release(struct inode *inode, struct file *filp)
{
	VATOOLS_FUNC_ENTER_INFO;
	if (!filp->private_data)
		kfree(filp->private_data);
	VATOOLS_FUNC_EXIT_INFO;
	return 0;
}

int tools_proc_cmd(uint8_t *input, int input_len,
		   struct tools_char_drv_info *drv)
{
	int ret, i;
	unsigned char cmd[64];
	int cmd_count =
		sizeof(tools_test_info_array) / sizeof(struct tools_test_info);

	ret = tools_test_cmdline_args(input, cmd, drv->args, TOOLS_ARG_MAX);
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "%s cmdline_args err=%d\n",
			    __func__, ret);
		ret = -EFAULT;
		goto out;
	} else if (!strncmp("help", cmd, strlen("help"))) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s cmd list, cmd count %d\n",
			     __func__, cmd_count);
		for (i = 0; i < cmd_count; i++) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s \n",
				     tools_test_info_array[i].cmd);
		}
		ret = 0;
		goto out;
	} else {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "input cmd %s\n", cmd);
		for (i = 0; i < cmd_count; i++) {
			if (!strcmp(tools_test_info_array[i].cmd, cmd)) {
				ret = tools_test_info_array[i].pFunc(drv, NULL);
				VATOOLS_INFO(NULL, DUMMY_DIE_ID,
					     "pFunc ret %d\n", ret);
				break;
			}
		}

		/* unknown cmd */
		if (i == cmd_count) {
			VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s unknown cmd %s\n",
				     __func__, cmd);
			ret = -ENODEV;
			goto out;
		}
	}
	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "%s ret %d\n", __func__, ret);

out:
	return ret;
}

static ssize_t tools_char_write(struct file *filp, const char __user *buffer,
				size_t count, loff_t *offset)
{
	int ret = count;
	uint8_t *input_buf;
	size_t real_data_len = min((size_t)VATOOLS_CMD_BUF_LEN, count);
	struct tools_char_drv_info *drv =
		(struct tools_char_drv_info *)filp->private_data;

	VATOOLS_FUNC_ENTER_INFO;
	if (count == 0) {
		ret = count;
		goto out;
	}
	input_buf = kzalloc(VATOOLS_CMD_BUF_LEN, GFP_KERNEL);
	if (!input_buf) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "input buf alloc fail\n");
		ret = -ENOMEM;
		goto out;
	}
	ret = copy_from_user_ex(input_buf, (void __user *)buffer,
				real_data_len);
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "copy_from_user_ex fail\n");
		ret = -EFAULT;
		goto out_free;
	}

	VATOOLS_INFO(NULL, DUMMY_DIE_ID, "write:%s\n", input_buf);
	ret = tools_proc_cmd(input_buf, VASTAI_CMD_READ_LEN, drv);
	if (ret) {
		VATOOLS_ERR(NULL, DUMMY_DIE_ID, "tools_proc_cmd fail, ret %d\n",
			    ret);
		ret = -EFAULT;
		goto out_free;
	}

	ret = count;
	VATOOLS_FUNC_EXIT_INFO;
out_free:
	kfree(input_buf);
out:
	return ret;
}

static ssize_t tools_char_read(struct file *filp, char __user *buffer,
			       size_t count, loff_t *offset)
{
	return -ENODEV;
}

static long tools_char_ioctl(struct file *filp, unsigned int cmd,
			     unsigned long arg)
{
	return -ENODEV;
}

static const struct file_operations tools_test_fop = {
	.owner = THIS_MODULE,
	.open = tools_char_open,
	.release = tools_char_release,
	.write = tools_char_write,
	.read = tools_char_read,
	.llseek = default_llseek,
	.unlocked_ioctl = tools_char_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = tools_char_ioctl,
#endif
};

static int tools_driver_test(struct vatools_node *node,
			     const struct file_operations *fop, const char *fmt,
			     ...)
{
	va_list vargs;
	int ret = 0;

	struct tools_char_drv_info *drv =
		kmalloc(sizeof(struct tools_char_drv_info), GFP_KERNEL);
	struct tools_file_info *file_info = &drv->file_info;
	node->drv = drv;

#if KERNEL_VERSION(6, 4, 0) > LINUX_VERSION_CODE
	toolclass = class_create(THIS_MODULE, "tools_test4");
#else
	toolclass = class_create("tools_test4");
#endif
	file_info->dev_num = MKDEV(500, 18);
	ret = register_chrdev_region(file_info->dev_num, 1, "tools_test");
	if (ret) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID,
			     "register_chrdev_region error, ret %d\n", ret);
		alloc_chrdev_region(&file_info->dev_num, 0, 1, "tools_test1");
	}

	file_info->dev.owner = THIS_MODULE;
	cdev_init(&file_info->dev, fop);
	ret = cdev_add(&file_info->dev, file_info->dev_num, 1);
	if (ret < 0) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "cdev add error\n");
		return ret;
	}

	va_start(vargs, fmt);
	vsnprintf(file_info->file_name, 32, fmt, vargs);
	va_end(vargs);
	file_info->device = device_create(toolclass, NULL, file_info->dev_num,
					  file_info, file_info->file_name);

	if (!file_info->device) {
		ret = PTR_ERR(file_info->device);
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "device_create error\n");
		return ret;
	}
	return ret;
}

void tools_test_init(struct vatools_node *node)
{
	(void)tools_driver_test(node, &tools_test_fop, "tools_test2");
}

void tools_test_deinit(struct vatools_node *node)
{
	struct tools_char_drv_info *drv = node->drv;
	struct tools_file_info *file_info = &drv->file_info;

	VATOOLS_FUNC_ENTER_INFO;
	device_destroy(toolclass, file_info->dev_num);
	class_destroy(toolclass);
	cdev_del(&file_info->dev);
	unregister_chrdev_region(file_info->dev_num, 1);

	VATOOLS_FUNC_EXIT_INFO;
}
#else
void tools_test_init(struct vatools_node *node)
{
}

void tools_test_deinit(struct vatools_node *node)
{
}
#endif
