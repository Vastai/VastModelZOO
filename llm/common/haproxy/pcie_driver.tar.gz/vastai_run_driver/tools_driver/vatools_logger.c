﻿#include "vatools.h"
#include "vatools_log.h"

/*
 * logger
 */
/*fetch firmware log state*/
int vatools_ioctl_get_log_status(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg)
{
	int ret = 0;
	/*structfour_drv_info *dev=(struct four_drv_info*)philp->private_data;*/
	struct vatools_cmd vcmd;
	void __user *argp = (void __user *)arg;
	struct vastai_pci_info *priv = NULL;
	int die_index = 0;
	union die_index_data did;
	u32 flag = 0;
	u32 timeout_water = 0;
	struct vastai_sv100_die *die = NULL;
	u8 buf[SV100_LOG_CTRL_LEN] = { 0 };
	u32 extra_log_ctrl_len = 0;

	V_UNREFERENCE(filp);
	V_UNREFERENCE(cmd);
	VATOOLS_FUNC_ENTERY;

	memset(&vcmd, 0, sizeof(vcmd));
	ret = copy_from_user_ex(&vcmd, (void __user *)argp, sizeof(vcmd));
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_from_user_ex is error\n");
		ret = -EIO;
		goto out;
	}

	did.val = (u32)vcmd.cmd.log_poll_cmd.die_index;
	die_index = vcmd.cmd.log_poll_cmd.die_index;

	priv = vatools_get_vastai_pci_device_info((char)did.dev_id);
	if (priv == NULL) {
		VATOOLS_INFO(priv, die_index, "priv is NULL, dev_id=0x%x\n",
			     did.dev_id);
		ret = -ENODEV;
		goto out;
	}
	if (vatools_check_pci_state(priv, VASTAI_NORMAL_STATE, -1)) {
		VATOOLS_DBG(priv, die_index, "priv->pci_state=0x%x\n",
			    atomic_read(&priv->pci_state));
		ret = -ENODEV;
		goto out;
	}

#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_lock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif
	VATOOLS_DBG(priv, die_index,
		    "input timeout_water=%d is_timeout=%x log_ring_ctl=%llx\n",
		    vcmd.cmd.log_poll_cmd.timeout_water,
		    vcmd.cmd.log_poll_cmd.is_timeout,
		    vcmd.cmd.log_poll_cmd.log_ring_ctl);

	/*Modify log ddr size to be compatible with older versions of the tool. Reuse is_timeout variable,
	which were not used in previous versions, and have a default value of 0.*/
	/*is_timeout=0x80000000 is a new tool that needs to read log ctrl byte*/
	/*log ctrl byte bit1=1 identifies a log ddr size of 512KB*/
	if (vcmd.cmd.log_poll_cmd.is_timeout & 0x80000000) {
		extra_log_ctrl_len = 0;
	} else {
		extra_log_ctrl_len = 32;
	}

	/*VATOOLS_DBG(priv, die_index, "is_timeout=0x%x extra_log_ctrl_len=%d\n",*/
	/*vcmd.cmd.log_poll_cmd.is_timeout, extra_log_ctrl_len);*/

	/*trigger smcu to poll log buf*/
	flag = 0;
	if (vcmd.cmd.log_poll_cmd.timeout_water !=
	    0xffffffff /*0xffffffff: do not need wait*/) {
		timeout_water = vcmd.cmd.log_poll_cmd.timeout_water != 0x0 ?
					vcmd.cmd.log_poll_cmd.timeout_water :
					500;
		die = &(((struct vastai_pci_info *)priv)
				->dies[vastai_pci_get_die_id(priv, die_index)]);

		/*Notify the SMCU log, and send a notification to the host when there is a log on a regular basis*/
		vastai_pci_mem_write(priv, die_index, LOG_MSG_FLAG, &flag,
				     sizeof(flag));

		/*wait complete*/
		ret = wait_for_completion_interruptible_timeout(
			&(die->log_comp), HZ * timeout_water / 1000);
		reinit_completion(&(die->log_comp));
		if (ret == 0) {
			VATOOLS_DBG(priv, die_index,
				    "timeout! (%d ms) ret=%d\n", timeout_water,
				    ret);
			vcmd.cmd.log_poll_cmd.is_timeout = 1;
			ret = -EIO;
			// goto out_lock;
		} else if (ret == -ERESTARTSYS || ret == -EINTR) {
			VATOOLS_DBG(priv, die_index,
				    "process be killed! ret=%d\n", ret);
			ret = -EINTR;
			// goto out_lock;
		} else if (ret < 0) {
			VATOOLS_DBG(priv, die_index, "Unknow err! ret=%d\n",
				    ret);
			ret = -EIO;
			// goto out_lock;
		}
	}

	/*get log ring ctl, even wait occur error or timeout*/
	memset(buf, 0, SV100_LOG_CTRL_LEN);
	ret = vastai_pci_mem_read(priv, die_index, SV100_LOG_CTRL_INFO, buf,
				  SV100_LOG_CTRL_LEN);
	if (ret < 0) {
		VATOOLS_INFO(priv, die_index,
			     "vastai_pci_mem_read is error, ret=%d\n", ret);
		goto out_lock;
	}
	ret = copy_to_user_ex((void __user *)vcmd.cmd.log_poll_cmd.log_ring_ctl,
			      buf, SV100_LOG_CTRL_LEN - extra_log_ctrl_len);
	if (ret) {
		VATOOLS_ERR(priv, die_index, "copy_to_user_ex is error\n");
		ret = -EIO;
		goto out_lock;
	}
out_lock:
#ifdef VATOOLS_SHAREMEM_LOCK_OPTIMIZE
	domain_mutex_unlock(priv, die_index, VATOOLS_IOCTL_DOMAIN_DIE);
#endif

out:
	VATOOLS_DBG(priv, die_index, "ret=%d\n", ret);

	VATOOLS_FUNC_EXIT;

	return ret;
}

loff_t logger_llseek(struct file *filp, loff_t offset, int orig)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(offset);
	V_UNREFERENCE(orig);

	return 0;
}

ssize_t logger_read(struct file *filp, char __user *buf, size_t size,
		    loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t logger_write(struct file *filp, const char __user *buf, size_t size,
		     loff_t *pos)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(buf);
	V_UNREFERENCE(size);
	V_UNREFERENCE(pos);

	return 0;
}

ssize_t logger_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
	V_UNREFERENCE(iocb);
	V_UNREFERENCE(from);

	return 0;
}

unsigned int logger_poll(struct file *filp, struct poll_table_struct *wait)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(wait);

	return 0;
}

long logger_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg)
{
	long ret = -EIO;
	struct vatools_node *node = NULL;
	struct vatools_reader *reader = NULL;

	VATOOLS_FUNC_ENTERY;

	node = vatools_file_get_node(filp);
	reader = vatools_file_get_reader(filp);

	VATOOLS_DBG(NULL, DUMMY_DIE_ID,
		    "ioctl cmd=0x%X node=0x%p reader=0x%p app_category=%d\n",
		    cmd, node, reader, reader->trans_category.app_category);

	switch (cmd) {
		/*fetch firmware log status*/
	case VATOOLS_GENERAL_IOCTL_LOG_STATUS:
		ret = vatools_ioctl_get_log_status(filp, cmd, arg);
		break;
	default:
		VATOOLS_DBG(
			NULL, DUMMY_DIE_ID,
			"ioctl logger unknown cmd=0x%X node=0x%p reader=0x%p app_category=%d\n",
			cmd, node, reader, reader->trans_category.app_category);
		break;
	}
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "ioctl ret=%ld\n", ret);
	VATOOLS_FUNC_EXIT;

	return ret;
}

int logger_mmap(struct file *filp, struct vm_area_struct *pvm)
{
	V_UNREFERENCE(filp);
	V_UNREFERENCE(pvm);

	return 0;
}
int logger_open(struct inode *inode, struct file *filp)
{
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(inode);
	V_UNREFERENCE(filp);

	return 0;
}

int logger_release(struct inode *ignored, struct file *filp)
{
	struct vatools_node *p_dev = NULL;
	struct vatools_reader *reader = NULL;
	VATOOLS_DBG(NULL, DUMMY_DIE_ID, "filp=0x%p\n", filp);

	V_UNREFERENCE(ignored);
	VATOOLS_FUNC_ENTERY;

	p_dev = vatools_file_get_node(filp);
	if (!p_dev) {
		VATOOLS_INFO(NULL, DUMMY_DIE_ID, "p_dev is null.\n");
		return -ENOMEM;
	}
	reader = vatools_file_get_reader(filp);
	if (reader) {
		list_del(&reader->list_readers);
		kvfree(reader);
		filp->private_data = NULL;
	} else {
	}

	VATOOLS_FUNC_EXIT;
	return 0;
}

int logger_fasync(int fd, struct file *filp, int mode)
{
	V_UNREFERENCE(fd);
	V_UNREFERENCE(filp);
	V_UNREFERENCE(mode);

	return 0;
}
