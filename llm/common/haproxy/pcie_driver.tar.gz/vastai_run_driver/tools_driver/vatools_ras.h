#ifndef __VATOOLS_RAS_H__
#define __VATOOLS_RAS_H__

#define RAS_RSV_PER_ENTRY  32
#define RAS_MAX_ENTRY_SIZE (512 * 1024)

#define RAS_SG100_DRIVER_VERSION 1
#define RAS_SV100_DRIVER_VERSION 1

#pragma pack(push)
#pragma pack(1)
struct tools_mmu_err_entry {
	u32 streamid; //SG100 only supports 64 streamids
	u32 substreamid; //SG100 only supports 256 substreamids
	u64 va;
	u64 pa;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_mpu_err_entry {
	u8 vm_id; /*stream id/osid*/
	u8 rd_or_rd;
	u8 dev_id; /*gfx num/encoder num/decoder num*/
	u8 reserved;
	u64 addr;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_gpu_err_entry {
	u8 pfn;
	u8 vfn;
	u8 vf_active;
	u8 status;
	u32 reserved02;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_pvt_err_entry {
	u32 reason; /* over-current or over-temperature */
	u32 percent;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_video_err_entry {
	u32 video_event;
	u32 status;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_dma_err_entry {
	u32 cor_cnt;
	u32 uncor_cnt;
	u32 stream_id;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_pcie_err_entry {
	u32 ep_or_rc : 8; /* EP or RC err status reg */
	u32 err_type : 8; /* Correctable or Uncorrectable */
	u32 err_idx : 8; /* Which bit of the error */
	u32 rsvd : 8; /* If aer already injected and not handled */
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_core_err_entry {
	u32 pc;
	u32 ps;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_inline_ecc_entry {
	u32 addr_l;
	u32 addr_h;
	u32 axi_id;
	u32 axi_data_l;
	u32 axi_data_h;
	u32 errbit;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_link_ecc_rd_entry {
	u8 mc_idx;
	u32 syndrome;
	u32 err_cnt[2][4]; //rank_id byte0~byte3
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_link_ecc_wr_entry {
	u8 mc_idx;
	u8 rank_idx;
	u8 fatal_err_flag;
	u8 dq_or_dmi_flag;
	u8 err_byte_lane;
	u8 dmi_syndrome;
	u32 nonfatal_err_cnt;
	u32 data_syndrome;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

struct tools_ddr_err_entry {
	struct tools_inline_ecc_entry inline_ecc_info;
	struct tools_link_ecc_rd_entry rd_link_ecc_info;
	struct tools_link_ecc_wr_entry wr_link_ecc_info;
	u8 rsv[RAS_RSV_PER_ENTRY];
};

typedef union {
	struct tools_ddr_err_entry ddr_ecc;
	struct tools_core_err_entry core;
	struct tools_pcie_err_entry pcie;
	struct tools_dma_err_entry dma;
	struct tools_video_err_entry video;
	struct tools_pvt_err_entry pvt;
	struct tools_gpu_err_entry gpu;
	struct tools_mpu_err_entry mpu;
	struct tools_mmu_err_entry mmu;
	u8 max[RAS_MAX_ENTRY_SIZE];
} tools_ras_entry_t;

struct tools_ras_err_head {
	u32 version;
	u32 timestamp;
	u32 entry_size : 8;
	u32 err_severity : 4;
	u32 err_reason : 8;
	u32 sub_component : 8;
	u32 component : 4;
};

#define TOOLS_MAX_RAS_U32_SIZE (sizeof(tools_ras_entry_t) / sizeof(u32))

struct tools_ras_err_info {
	struct tools_ras_err_head head;
	/* sizeof(ras_entry) should be equal to sizeof(entry_paddings) */
	union {
		tools_ras_entry_t ras_entry;
		u32 entry_paddings[TOOLS_MAX_RAS_U32_SIZE];
	};
};

#pragma pack(pop)
#endif
