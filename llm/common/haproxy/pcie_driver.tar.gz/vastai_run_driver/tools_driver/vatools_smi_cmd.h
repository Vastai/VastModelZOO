﻿#ifndef __VATOOLS_SMI_CMD_H__
#define __VATOOLS_SMI_CMD_H__

#include "vatools_types.h"

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

/*Write and bitset command test addreas is 0x08cf6cf0*/
/*SMI function used csram begin address*/
#define SMI_DIE_ADDRESS_OFFSET_BASE ((u32)(0x08cf3600))

/*block quantity*/
#define SMI_BLOCK_ID_MAX (8)

/*Initialize the write to the CSRAM SMI header area*/
typedef struct SMI_BLOCK_HEADER_s {
	u32 smi_version;
	u32 block_header_num; /*High 8bit default setting 0xA1, identifies the SMI area has been set.*/
	u32 block_address[SMI_BLOCK_ID_MAX];
} T_SMI_BLOCK_HEADER;

/*The address of each block and the usage tag*/
typedef struct SMI_BLOCK_s {
	u32 block_id;
	u32 block_address;
	u32 block_len;
	u32 block_used_flag;
	u32 query_count;
	u32 query_interval;
} T_SMI_BLOCK;

#define SMI_CMD_BLOCK_LEN (1024) /*block total length*/
#define SMI_CMD_HEADER_LEN                                                     \
	(sizeof(TS_SMI_CMD_REQ)) /*The maximum length of the smi command needs to be modified with fw*/
#define SMI_CMD_BODY_LEN                                                       \
	(1000) /*The maximum length of the smi command needs to be modified with fw*/
#define SMI_CMD_BLOCK0_LEN                                                     \
	(SMI_CMD_BLOCK_LEN) /*SMI block0 default total length*/
#define SMI_CMD_BLOCK0_DATA_LEN                                                \
	(SMI_CMD_BODY_LEN) /*SMI block0 default data length*/
#define SMI_CMD_BLOCK0_RSVD (8) /*Smi Block0 reserved values*/
#define SMI_CMD_BLOCK0_ADDR                                                    \
	((u32)(SMI_DIE_ADDRESS_OFFSET_BASE +                                   \
	       sizeof(T_SMI_BLOCK_HEADER))) /*Smi Block0 Default address*/
#define SMI_CMD_BLOCK1_LEN                                                     \
	(SMI_CMD_BLOCK_LEN) /*SMI block1 default data length*/
#define SMI_CMD_BLOCK1_DATA_LEN                                                \
	(SMI_CMD_BODY_LEN) /*SMI block1 default data length*/
#define SMI_CMD_BLOCK1_RSVD (8) /*Smi Block1 reserved values*/
#define SMI_CMD_BLOCK1_ADDR                                                    \
	((u32)(SMI_CMD_BLOCK0_ADDR +                                           \
	       SMI_CMD_BLOCK0_LEN)) /*Smee Block1 default address*/
#define SMI_CMD_BLOCK2_ADDR ((u32)0) /*SMI block2 default data length*/
#define SMI_CMD_BLOCK2_LEN  (0) /*SMI block2 default data length*/
#define SMI_CMD_BLOCK3_ADDR ((u32)0) /*SMI block3 default data length*/
#define SMI_CMD_BLOCK3_LEN  (0) /*SMI block3 default data length*/
#define SMI_CMD_BLOCK4_ADDR ((u32)0) /*SMI block4 default data length*/
#define SMI_CMD_BLOCK4_LEN  (0) /*SMI block4 default data length*/
#define SMI_CMD_BLOCK5_ADDR ((u32)0) /*SMI block5 default data length*/
#define SMI_CMD_BLOCK5_LEN  (0) /*SMI block5 default data length*/
#define SMI_CMD_BLOCK6_ADDR ((u32)0) /*SMI block6 default data length*/
#define SMI_CMD_BLOCK6_LEN  (0) /*SMI block6 default data length*/
#define SMI_CMD_BLOCK7_ADDR ((u32)0) /*SMI block7 default data length*/
#define SMI_CMD_BLOCK7_LEN  (0) /*SMI block7 defaults to the overall length*/
/*PCIe reads data up to 4MB at a time*/
#define SMI_VASTAI_PCI_RW_BUF_LEN_ONCE 0x400000 /*4MB*/
/*Define the maximum number of devices that can be managed*/
#ifndef MAX_DEVICE_NUM_PER_MANAGER
#define MAX_DEVICE_NUM_PER_MANAGER 128
#endif
/*Defines the maximum number of dies in each device*/
#ifndef MAX_DIE_NUM_PER_DEVICE
#define MAX_DIE_NUM_PER_DEVICE VASTAI_DIE_MAX_NUM
#endif
/*Define the maximum number of units in each die,
if exceeded, each command needs to be expanded by itself,
This universal definition is not available*/
/*The value is related to the command definition and cannot be changed to a larger number*/
#define MAX_UNIT_NUM_PER_DIE 32
/*flag description:
App & SMCU Communication Status:
The highest bit: 0 indicates the status information
0x01: The app sends data, and so on SMCU processes
0x02: After the SMC receives the interrupt, it is written as 0x02, which means that it is already being processed, and the interrupt will not be processed again in the future
0x03: The SMCU data is ready and written as 0x03, which means that the application layer can read the data.
0x04: SMC error
0x81: SMC received an unknown command
0x82: There was an error with the SMCU
0x83: The SMC system is busy
0x84: The command parameter is incorrect
0x85: SMC does not support commands, including deprecated and unimplemented commands
*/
/*Indicates whether the SMCU is ready for the data flag*/
#define FLAG_APP_PREPARE	  0x00 /*No command*/
#define FLAG_APP_REQ		  0x01 /*Apply the initiation command*/
#define FLAG_FW_WORKING		  0x02 /*smcu starts processing the command*/
#define FLAG_FW_DATA_READY	  0x03 /*smcu command was successfully executed*/
#define FLAG_FW_ERROR_UNKNOWN_CMD 0x81 /*SMCU detects unknown commands*/
#define FLAG_FW_ERROR_ABORT	  0x82 /*smcu command execution error*/
#define FLAG_FW_ERROR_SYSTEM_BUSY 0x83 /*smcu traditional*/
#define FLAG_FW_ERROR_PARAM	  0x84 /*command parameter is incorrect*/
#define FLAG_FW_ERR_UNSUPPORTED_CMD                                            \
	0x85 /*smcu does not support commands, including deprecated and unimplemented commands*/

/*Define the sending command structure, a total of 64 bits,*/
typedef struct DIE_CMD_REQ_s {
	u32 unit; /*The specified unit of the command operation, starting from 0, if the command does not need to be parsed, fill in 0, if it is all, fill in 0xFFFF,*/
	/*The field can also be extended as a command*/
	u16 data_len; /*indicates the length of the data sent to the fw or the data returned by the fw, in bytes*/
	u8 flag; /*Indicates whether fw is ready for data, 0x01U, data ready,*/
	/*0x00U data is not ready, enter 0x00U when the application layer sends the command*/
	u8 cmd; /*Specific commands*/
	u64 rw_addr : 48; /*Read and write address. total 48 bit*/
	u16 seq;
} TS_SMI_CMD_REQ;

/*Send command federations*/
/*A command header structure containing the address parameter, consisting of u64 cmd and u64 param,*/
/*In order to unify the data processing with FW, addr and value are added, which can be ignored when not in use*/
typedef struct SMI_MEM32_s {
	u32 addr;
	u32 value;
} TS_SMI_MEM32;

typedef struct SMI_MEM64_s {
	u64 addr;
	u64 value;
} TS_SMI_MEM64;

typedef struct VAL_RANGE {
	u32 min;
	u32 max;
} TS_VAL_RANGE;
#define SMI_CMD_VAL_RANGE_CHECK(_val, _min, _max)                              \
	((_val) < _min && (_val) > _max)

/*Define an empty unit*/
#define SMI_CMD_UNIT_NULL (0x00000000U)
/*Define all units*/
#define SMI_CMD_UNIT_ALL (0xFFFFFFFFU)
/*Defines the default post-56bit for the composition command*/
#define SMI_CMD_DEFAULT_56BIT 0x0001000000000000UL

/*Define command parsing macros*/
#define SMI_CMD_EXTRACT_CMD(c)	   ((u8)(((u64)c >> 56) & 0xFF))
#define SMI_CMD_EXTRACT_FLAG(c)	   ((u8)(((u64)c >> 48) & 0xFF))
#define SMI_CMD_EXTRACT_DATALEN(c) ((u16)(((u64)c >> 32) & 0xFFFF))
#define SMI_CMD_EXTRACT_UNIT(c)	   ((u32)(((u64)c) & 0xFFFFFFFF))

/*Define a command combination macro*/
#define SMI_CMD_PACK_CMD(c) ((u64)((((u64)(c)) << 56) | SMI_CMD_DEFAULT_56BIT))
#define SMI_CMD_PACK_CMD_UNIT(c, u)                                            \
	((u64)((((u64)(c)) << 56) | SMI_CMD_DEFAULT_56BIT) | u)
#define SMI_CMD_PACK_FLAG(x, c)	   ((u64)((u64)c | (u64)x << 48))
#define SMI_CMD_PACK_DATALEN(x, c) ((u64)((u64)c | (u64)x << 32))
#define SMI_CMD_PACK_UNIT(x, c)	   ((u64)((u64)c | (u64)x))

/*smi command code, populating u8 cmd field*/
/*
The list of SMI commands, sorted by command value, needs to be added here for new commands, so that the commands can be assigned subsequently
#define SMI_CMD_CODE_CTL_RESET ( 0x01 )
#define SMI_CMD_CODE_CTL_READ ( 0x02 )
#define SMI_CMD_CODE_CTL_PERI_ACCESS ( 0x03 )
#define SMI_CMD_CODE_PVT_PROCESS_GET ( 0x05 )
#define SMI_CMD_CODE_PVT_VOLTAGE_GET ( 0x06 )
#define SMI_CMD_CODE_TEMPERATURE_GET ( 0x07 )
#define SMI_CMD_CODE_PLL_CLOCK_GET ( 0x08 )
#define SMI_CMD_CODE_TEMPERATURE_GET_DEVICE ( 0x09 )
#define SMI_CMD_CODE_INF_GET_SUMMERY ( 0x0A )
#define SMI_CMD_CODE_INF_GET_MEMORY ( 0x0B )
#define SMI_CMD_CODE_INF_GET_SERIALNO ( 0x0C )
#define SMI_CMD_CODE_INF_GET_ALARM ( 0x0E )
#define SMI_CMD_CODE_CTL_MODULE_ENABLE ( 0x0F )
#define SMI_CMD_CODE_CTL_WRITE_TEST ( 0x10 )
#define SMI_CMD_CODE_AIC_PIN_VOLTAGE_GET ( 0x11 )
#define SMI_CMD_CODE_PIN_VOLTAGE_GET ( 0x12 )
#define SMI_CMD_CODE_POWER_VOLTAGE_GET ( 0x13 )
#define SMI_CMD_CODE_POWER_CURRENT_GET ( 0x14 )
#define SMI_CMD_CODE_POWER_GET ( 0x15 )
#define SMI_CMD_CODE_CTL_BATCH_READ ( 0x16 )
#define SMI_CMD_CODE_CTL_BATCH_WRITE ( 0x17 )
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_SET ( 0x18 )
#define SMI_CMD_CODE_BMCU_STATUS_GET ( 0x19 )
#define SMI_CMD_CODE_GET_FAN_SPEED_MODE ( 0x1A )
#define SMI_CMD_CODE_SET_FAN_SPEED_MODE ( 0x1B )
#define SMI_CMD_CODE_GET_FAN_SPEED ( 0x1C )
#define SMI_CMD_CODE_SET_FAN_SPEED ( 0x1D )
#define SMI_CMD_CODE_CTL_MODULE_STATUS ( 0x1F )
#define SMI_CMD_CODE_SPI_PROTECT_CONTROL ( 0x20 )
#define SMI_CMD_CODE_SPI_READ ( 0x21 )
#define SMI_CMD_CODE_FW_CONFIG ( 0x22 )
#define SMI_CMD_CODE_PVT_PSM_MODEL_SET ( 0x23 )
#define SMI_CMD_CODE_PVT_PSM_DISABLE ( 0x24 )
#define SMI_CMD_CODE_PVT_PSM_GET ( 0x25 )
#define SMI_CMD_CODE_POWER_CURRENT_THRESHOLD_GET (0x26)
#define SMI_CMD_CODE_TOP_TEST_SET (0x27)
#define SMI_CMD_CODE_FCT (0x28)
#define SMI_CMD_CODE_VCC_CTRL (0x29)
#define SMI_CMD_CODE_CONFIG_GET (0x30)
#define SMI_CMD_CODE_CONFIG_SET (0x31)
#define SMI_CMD_CODE_CTL_WRITE ( 0x82 )
#define SMI_CMD_CODE_CTL_BITSET ( 0x83 )
#define SMI_CMD_CODE_PLL_CLOCK_SET ( 0x88 )
#define SMI_CMD_CODE_CTL_MODULE_DISABLE ( 0x8F )
#define SMI_CMD_CODE_AIC_PIN_VOLTAGE_SET ( 0x91 )
#define SMI_CMD_CODE_PIN_VOLTAGE_SET ( 0x92 )
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_GET ( 0x98 )
#define SMI_CMD_CODE_SPI_WRITE ( 0xA1 )
#define SMI_CMD_CODE_POWER_CURRENT_THRESHOLD_SET (0xA6)
#define PCIE_CMD_CODE_CONTROL ( 0xF1 )
The list of SMI commands, sorted by command value, needs to be added here for new commands, so that the commands can be assigned subsequently
*/
/*reset Unused*/
#define SMI_CMD_CODE_CTL_RESET (0x01)

/*Read and write in-memory data*/
#define SMI_CMD_CODE_CTL_READ  (0x02)
#define SMI_CMD_CODE_CTL_WRITE (0x82)

/*Bitwise reads and writes*/
/*bitset, the setting specifies that the bit is 1, and the rest is kept in the original value. -B address mask.*/
/*The bit that needs to be operated in the mask is set to 1, and the others are 0, and the original address data is written back after the operation.*/
#define SMI_CMD_CODE_CTL_BITSET (0x83)

/*Control commands, set enable/disable module/unit, and use unit bit to identify specific modules*/
/*bit value 0: disable; bit value 1: enable*/
/*Unit bit 0: The AI module is enabled/disabled/stated*/
/*unit bit 1: Video module enabled/disabled/stated*/
/*Unit bit 2: AutoFreq enables/disables/states*/
/*Unit bit 3: ECC enabled/disabled/stated*/
/*unit bit 4: overtemp enabled/disabled/stated*/
/*unit bit 5: overcur enabled/disabled/stated*/
/*unit bit 6: dpm enabled/disabled/stated*/
/*unit bit 7: sriov enabled/disabled/stated*/
/*unit bit 8: autoidle enabled/disabled/stated*/
/*unit bit 9: WriteProtection enabled/disabled/stated*/
#define SMI_CMD_CODE_CTL_MODULE_ENABLE	(0x0F)
#define SMI_CMD_CODE_CTL_MODULE_DISABLE (0x8F)
#define SMI_CMD_CODE_CTL_MODULE_STATUS	(0x1F)

/*Used for internal testing*/
#define SMI_CMD_CODE_CTL_WRITE_TEST (0x10)

/*Batch read and write data*/
#define SMI_CMD_CODE_CTL_BATCH_READ  (0x16)
#define SMI_CMD_CODE_CTL_BATCH_WRITE (0x17)

/*PVT x: specific unit number*/
/*process, not used yet*/
#define SMI_CMD_CODE_PVT_PROCESS_GET (0x05)

/*pvt voltage monitoring point, unit: millivolt mV, 7 groups: dapb0 dapt0 dapm ddr_phy0 ddr_phy1 ddr_phy2 ddr_phy3*/
#define SMI_CMD_CODE_PVT_VOLTAGE_GET (0x06)

/*Vpin Voltage Read and Write, Unit: Millivolt mV, 3 Groups: VID, DLC, SoC, VID Range 700mV~1100mV, DLC Range: 650mV~1200mV SoC Range: 700mV~1100mV*/
#define SMI_CMD_CODE_PIN_VOLTAGE_GET (0x12)
#define SMI_CMD_CODE_PIN_VOLTAGE_SET (0x92)

/*add in card Type: Vpin Voltage Read and Write, Unit: Millivolt mV, 3 groups: VID, DLC, SoC, VID range 700mV~1100mV, DLC range: 650mV~1200mV*/
/*SoC range: 700mV~1100mV*/
#define SMI_CMD_CODE_AIC_PIN_VOLTAGE_GET (0x11)
#define SMI_CMD_CODE_AIC_PIN_VOLTAGE_SET (0x91)

/*Power Voltage Reading, Unit: mV, 3 Groups, DDR, VID, DLC+SoC*/
#define SMI_CMD_CODE_POWER_VOLTAGE_GET (0x13)
/*Power current reading, mA, 3 groups, DDR, VID, DLC+SoC*/
#define SMI_CMD_CODE_POWER_CURRENT_GET (0x14)
/*Read power consumption, unit mW, 4 group, DDR, VID, DLC+SoC, Total*/
#define SMI_CMD_CODE_POWER_GET (0x15)
/*Read the bmcu status*/
#define SMI_CMD_CODE_BMCU_STATUS_GET (0x19)

/*SPI flash*/
#define SMI_CMD_CODE_SPI_PROTECT_CONTROL (0x20)
#define SMI_CMD_CODE_SPI_READ		 (0x21)
#define SMI_CMD_CODE_SPI_WRITE		 (0xA1)

/*WHV PSM*/
#define SMI_CMD_CODE_PVT_PSM_MODEL_SET (0x23)
#define SMI_CMD_CODE_PVT_PSM_DISABLE   (0x24)
#define SMI_CMD_CODE_PVT_PSM_GET       (0x25)

/*Power current threshold*/
#define SMI_CMD_CODE_POWER_CURRENT_THRESHOLD_GET (0x26)
#define SMI_CMD_CODE_POWER_CURRENT_THRESHOLD_SET (0xA6)

/*Fan mode: Ӣ : 0; Manual: 1*/
#define SMI_CMD_CODE_GET_FAN_SPEED_MODE (0x1A)
/*Fan mode: Ƶ 0 ; Manual: 1*/
#define SMI_CMD_CODE_SET_FAN_SPEED_MODE (0x1B)
/*Fan speed: Read the fan speed, return two values: u32 0~100; % of velocity %; u32 frequency, in Hz*/
#define SMI_CMD_CODE_GET_FAN_SPEED (0x1C)
/*Fan speed: Set fan speed: 0~100; Percentage of speed %*/
#define SMI_CMD_CODE_SET_FAN_SPEED (0x1D)
enum SMI_FAN_MODE_e {
	FAN_MODE_AUTO = 0, /*Auto mode*/
	FAN_MODE_MANUAL = 1, /*Manual mode*/
};

/*Top test*/
#define SMI_CMD_CODE_TOP_TEST_SET (0x27)

/*Read the SoC temperature The received MCU data is divided by 100, which translates to degrees Celsius*/
#define SMI_CMD_CODE_TEMPERATURE_GET (0x07)
/*Read/write temperature threshold*/
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_SET (0x18)
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_GET (0x98)
/*Reading the board temperature receives the MCU data by dividing by 100, which translates to degrees Celsius*/
/*Temperature arrangement: BMCU; air inlet; air outlet;*/
#define SMI_CMD_CODE_TEMPERATURE_GET_DEVICE (0x09)

/*PLL: Frequency Read Write, u64 identifies a frequency value*/
#define SMI_CMD_CODE_PLL_CLOCK_GET (0x08)
#define SMI_CMD_CODE_PLL_CLOCK_SET (0x88)

/*Read the summary information*/
#define SMI_CMD_CODE_INF_GET_SUMMERY (0x0A)
/*Memory usage*/
#define SMI_CMD_CODE_INF_GET_MEMORY (0x0B)
/*Read the serial number*/
#define SMI_CMD_CODE_INF_GET_SERIALNO (0x0C)
/*Read the abnormal alarm data and use the unit bit to identify the specific module*/
/*bit value 0: disable; bit value 1: enable*/
#define SMI_CMD_CODE_INF_GET_ALARM (0x0E)

/*PCIe command, does not use smcu. Direct access to the driver*/
#define PCIE_CMD_CODE_CONTROL (0xF1)

/*FCT production tests use unit as a subcommand*/
#define SMI_CMD_CODE_FCT (0x28)
/*FCT command unit subcommand definition*/
enum SMI_FCT_SUBCMD_e {
	SMI_CMD_CODE_FCT_PMU31_PAGE0 = 1, /*PMU31 related register access*/
	SMI_CMD_CODE_FCT_PMU31_PAGE1, /*PMU31 related register access*/
	SMI_CMD_CODE_FCT_PMU31_PAGE2, /*PMU31 related register access*/
	SMI_CMD_CODE_FCT_PMU32_PAGE0, /*PMU32 related register access*/
	SMI_CMD_CODE_FCT_PMU32_PAGE1, /*PMU32 related register access*/
	SMI_CMD_CODE_FCT_PMU32_PAGE2, /*PMU32 related register access*/
	SMI_CMD_CODE_FCT_CLOCK, /*Clock chip configuration,*/
	SMI_CMD_CODE_FCT_CLOCK_SEL, /*SV100 clock input selection: 0x00100280.bit0 == 1 --> 100M ;0-->25M*/
	SMI_CMD_CODE_FCT_BMCU_TEMPERATURE, /*BMCU Temperature*/
	SMI_CMD_CODE_FCT_BMCU_SMBUS, /*BMCU SMBUS access*/
	SMI_CMD_CODE_FCT_AVS_GET_TEMPERATURE, /*AVS get temperature*/
	SMI_CMD_CODE_FCT_AVS_GET_VLOTAGE, /*AVS get voltage*/
	SMI_CMD_CODE_FCT_AVS_GET_CURRENT, /*AVS get current*/
	SMI_CMD_CODE_FCT_BMCU_HW_ID, /*BMCU hw id: 0: VG1200 1: VG1000*/
};
#define SMI_CMD_CODE_FCT_CLOCK_SEL_REG (0x00100280)

/*vcc volt control command*/
#define SMI_CMD_CODE_VCC_CTRL (0x29)
enum SMI_VCC_CTRL_e {
	VCC_CTRL_VOLT_1V8,
	VCC_CTRL_VOLT_0V75,
	VCC_CTRL_GETSTEP_1V8,
	VCC_CTRL_GETSTEP_0V75,
	VCC_CTRL_SETSTEP_1V8,
	VCC_CTRL_SETSTEP_0V75,
	VCC_CTRL_MAX,
};

/*Configure commands, using unit to identify each function item that needs to be configured. Use data[0] to identify the parameter value or parameter sequence number of each
 * function item*/
#define SMI_CMD_CODE_CONFIG_GET (0x30)
#define SMI_CMD_CODE_CONFIG_SET (0x31)

// FW config
#define SMI_CMD_CODE_FW_CONFIG (0x22)

//--------------------PERIPHERAL access-----------------------
#define SMI_CMD_CODE_CTL_PERI_ACCESS (0x03)

/*Parameter range*/
#define FREQUENCY_DISPLAY_MAX                                                  \
	4000000000 /*modify for remove compare with U32 warning*/
/*Define commands to form macros*/
/*Define the command type, up to bit:0 read up to bit:1 write*/
/*Determine whether the command is a write function*/
#define IS_WRITE_CMD(x)                                                        \
	((u8)(((u64)x & 0x8000000000000000UL) == 0x8000000000000000UL))

/*Control command*/
#define SMI_CMD_CTL_RESET SMI_CMD_PACK_CMD(SMI_CMD_CODE_CTL_RESET)
/*Read from address, command format: -r address data_len*/
#define SMI_CMD_CTL_READ SMI_CMD_PACK_CMD(SMI_CMD_CODE_CTL_READ)
/*Write parameters to the address -w address data_len data*/
#define SMI_CMD_CTL_WRITE SMI_CMD_PACK_CMD(SMI_CMD_CODE_CTL_WRITE)
/*bitset, the setting specifies that the bit is 1, and the rest is kept in the original value. -B address mask.*/
/*The bit that needs to be operated in the mask is set to 1, and the others are 0, and the original address data is written back after the operation.*/
#define SMI_CMD_CTL_BITSET SMI_CMD_PACK_CMD(SMI_CMD_CODE_CTL_BITSET)
/*bitclear, the setting specifies the bit to 0, and the other values are kept as original. -C address mask.*/
/*Used for internal testing, simulating the write operation*/
#define SMI_CMD_CTL_WRITE_TEST SMI_CMD_PACK_CMD(SMI_CMD_CODE_CTL_WRITE_TEST)

/*Set up reads in batches*/
#define SMI_CMD_BATCH_FETCH SMI_CMD_PACK_CMD(SMI_CMD_CODE_BATCH_FETCH)
#define SMI_CMD_BATCH_GET   SMI_CMD_PACK_CMD(SMI_CMD_CODE_BATCH_GET)

/*PVT x: specific unit number*/
/*process, not used yet*/
#define SMI_CMD_PVT_PROCESS_GET(x)                                             \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_PVT_PROCESS_GET, x)

/*pvt voltage monitoring point, unit: millivolt mV*/
#define SMI_CMD_PVT_VOLTAGE_GET(x)                                             \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_PVT_VOLTAGE_GET, x)
#define PVT_VOLTAGE_DISPLAY_MIN 0
#define PVT_VOLTAGE_DISPLAY_MAX 100000
#define PVT_VOLT_VID_MIN	700
#define PVT_VOLT_VID_MAX	1100
#define PVT_VOLT_DLC_MIN	650
#define PVT_VOLT_DLC_MAX	1200
#define PVT_VOLT_SOC_MIN	700
#define PVT_VOLT_SOC_MAX	1100

/*Vpin voltage read/write, 3 groups of VID, DLC, SOC mV, VID RMS: 0.7~1.1v, DLC RMS: 0.65~1.2v, SOC RMS: 0.7~1.1v*/
#define SMI_CMD_PIN_VOLTAGE_GET(x)                                             \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_PIN_VOLTAGE_GET, x)
#define SMI_CMD_PIN_VOLTAGE_SET(x)                                             \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_PIN_VOLTAGE_SET, x)
#define SMI_CMD_PIN_VOLTAGE_VID_MIN 474
#define SMI_CMD_PIN_VOLTAGE_VID_MAX 1185
#define SMI_CMD_PIN_VOLTAGE_DLC_MIN 474
#define SMI_CMD_PIN_VOLTAGE_DLC_MAX 1185
#define SMI_CMD_PIN_VOLTAGE_SOC_MIN 470
#define SMI_CMD_PIN_VOLTAGE_SOC_MAX 1185
#define PIN_VOLTAGE_DISPLAY_MIN	    0
#define PIN_VOLTAGE_DISPLAY_MAX	    2000000

/*Voltage and current consumption, 3 groups, DDR, VID, DLC+SOC , mV, mA*/
#define SMI_CMD_POWER_VOLTAGE_GET(x)                                           \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_POWER_VOLTAGE_GET, x)
#define SMI_CMD_POWER_CURRENT_GET(x)                                           \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_POWER_CURRENT_GET, x)
#define POWER_VOLTAGE_DISPLAY_MIN 0
#define POWER_VOLTAGE_DISPLAY_MAX 20000000
#define POWER_CURRENT_DISPLAY_MIN 0
#define POWER_CURRENT_DISPLAY_MAX 10000000

/*Read Power Consumption, 4 Groups, DDR, VID, DLC+SOC, total mW*/
#define SMI_CMD_POWER_GET(x) SMI_CMD_PACK_CMD_UNIT(SIM_CMD_CODE_POWER_GET, x)
#define POWER_DISPLAY_MIN    0
#define POWER_DISPLAY_MAX    1000000000

/*The received MCU data is divided by 100 and converted to degrees Celsius*/
#define SMI_CMD_TEMPERATURE_GET(x)                                             \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_TEMPERATURE_GET, x)
#define TEMPERATURE_DISPLAY_MIN 0
#define TEMPERATURE_DISPLAY_MAX 10000

#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_SD_MIN 20
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_SD_MAX 120
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_DF_MIN 50
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_DF_MAX 140
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_IF_MIN 70
#define SMI_CMD_CODE_TEMPERATURE_THRESHOLD_IF_MAX 150

/*Info*/
#define SMI_CMD_INF_GET_SUMMERY	 SMI_CMD_PACK_CMD(SMI_CMD_CODE_INF_GET_SUMMERY)
#define SMI_CMD_INF_GET_MEMORY	 SMI_CMD_PACK_CMD(SMI_CMD_CODE_INF_GET_MEMORY)
#define SMI_CMD_INF_GET_SERIALNO SMI_CMD_PACK_CMD(SMI_CMD_CODE_INF_GET_SERIALNO)
/*Alarm*/
#define SMI_CMD_INF_GET_ALARM(x)                                               \
	SMI_CMD_PACK_CMD_UNIT(SMI_CMD_CODE_INF_GET_ALARM, x)

#ifdef __cplusplus
}
#endif
#pragma pack(pop)

#endif /*__VATOOLS_SMI_CMD_H__*/
