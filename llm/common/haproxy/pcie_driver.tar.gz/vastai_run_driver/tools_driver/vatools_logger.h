﻿#ifndef __VATOOLS_LOGGER_H__
#define __VATOOLS_LOGGER_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

/*get log status*/
int vatools_ioctl_get_log_status(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg);
loff_t logger_llseek(struct file *filp, loff_t offset, int orig);
ssize_t logger_read(struct file *filp, char __user *buf, size_t size,
		    loff_t *pos);
ssize_t logger_write(struct file *filp, const char __user *buf, size_t size,
		     loff_t *pos);
ssize_t logger_write_iter(struct kiocb *iocb, struct iov_iter *from);
unsigned int logger_poll(struct file *filp, struct poll_table_struct *wait);
long logger_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg);
int logger_mmap(struct file *filp, struct vm_area_struct *pvm);
int logger_open(struct inode *inode, struct file *filp);
int logger_release(struct inode *ignored, struct file *filp);
int logger_fasync(int fd, struct file *filp, int mode);

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_LOGGER_H__*/
