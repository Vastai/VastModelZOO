﻿#ifndef __VATOOLS_DRIVER_H__
#define __VATOOLS_DRIVER_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

int tools_init(void *pci_dev);
void tools_exit(void *pci_dev);
extern atomic_t tools_online_flag;
void vatools_driver_exit(void *pci_dev);

int vatools_prepare_init_once(void);
int vatools_fct_die_num(struct vastai_pci_info *priv, int die_num);

#if (TOOLS_WIN == 1)
void tools_io_stop();
void tools_io_start();
#endif

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_DRIVER_H__*/
