﻿#ifndef __VATOOLS_SMI_H__
#define __VATOOLS_SMI_H__

#pragma pack(push)
#pragma pack(1)
#ifdef __cplusplus
extern "C" {
#endif

/*ioctl generic command V2 version*/
loff_t smi_llseek(struct file *filp, loff_t offset, int orig);
ssize_t smi_read(struct file *filp, char __user *buf, size_t size, loff_t *pos);
ssize_t smi_write(struct file *filp, const char __user *buf, size_t size,
		  loff_t *pos);
ssize_t smi_write_iter(struct kiocb *iocb, struct iov_iter *from);
unsigned int smi_poll(struct file *filp, struct poll_table_struct *wait);
long smi_ioctl(struct file *filp, unsigned int cmd, IOCTL_ARG_T arg);
int smi_mmap(struct file *filp, struct vm_area_struct *pvm);
int smi_open(struct inode *inode, struct file *filp);
int smi_release(struct inode *ignored, struct file *filp);
int smi_fasync(int fd, struct file *filp, int mode);
long vatools_ioctl_smi_cmd(struct file *filp, unsigned int cmd,
			   IOCTL_ARG_T arg);
long vatools_ioctl_pcie_cmd(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
long vatools_ioctl_read_buf(struct file *filp, unsigned int cmd,
			    IOCTL_ARG_T arg);
long vatools_ioctl_write_buf(struct file *filp, unsigned int cmd,
			     IOCTL_ARG_T arg);
int domain_mutex_lock(struct vastai_pci_info *priv, u32 die_index, u32 field);
int domain_mutex_unlock(struct vastai_pci_info *priv, u32 die_index, u32 field);
long vatools_ioctl_flash_cmd(struct file *filp, unsigned int cmd,
			     IOCTL_ARG_T arg);
#ifdef CONFIG_TOOLS_V2
long vatools_ioctl_flash_v2_bmcu_fw(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p);
long vatools_ioctl_flash_v2_xspi_fw(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p);
long vatools_ioctl_flash_v2_pmcu_fw(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p);
long vatools_ioctl_flash_v2_get_status(struct file *filp, unsigned int cmd,
				       IOCTL_ARG_T arg,
				       struct vastai_pci_info *priv,
				       ioctl_arg_t *ioctl_arg_p);
long vatools_ioctl_flash_v2_switch_bmcu(struct file *filp, unsigned int cmd,
					IOCTL_ARG_T arg,
					struct vastai_pci_info *priv,
					ioctl_arg_t *ioctl_arg_p);
long vatools_ioctl_process_mutex_cmd(struct file *filp, unsigned int cmd,
				     IOCTL_ARG_T arg);
int vatools_process_mutex_lock(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p);
int vatools_process_mutex_unlock(struct file *filp, unsigned int cmd,
				 IOCTL_ARG_T arg, struct vastai_pci_info *priv,
				 ioctl_arg_t *ioctl_arg_p);
int vatools_process_mutex_is_locked(struct file *filp, unsigned int cmd,
				    IOCTL_ARG_T arg,
				    struct vastai_pci_info *priv,
				    ioctl_arg_t *ioctl_arg_p);
int vatools_process_mutex_trylock(struct file *filp, unsigned int cmd,
				  IOCTL_ARG_T arg, struct vastai_pci_info *priv,
				  ioctl_arg_t *ioctl_arg_p);
int vatools_process_release_mutex_unlock(struct file *filp, unsigned int cmd,
					 IOCTL_ARG_T arg,
					 struct vastai_pci_info *priv,
					 ioctl_arg_t *ioctl_arg_p);
int vatools_driver_smi_cmd(u32 block_id, struct vastai_pci_info *priv,
			   int die_index, void *buf, unsigned int len);
long vatools_ioctl_dma_cmd(struct file *filp, unsigned int cmd,
			   IOCTL_ARG_T arg);
int vatools_ioctl_dma_alloc_ex(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p);
int vatools_ioctl_dma_start_ex(struct file *filp, unsigned int cmd,
			       IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			       ioctl_arg_t *ioctl_arg_p);
int vatools_ioctl_dma_free_ex(struct file *filp, unsigned int cmd,
			      IOCTL_ARG_T arg, struct vastai_pci_info *priv,
			      ioctl_arg_t *ioctl_arg_p);
#endif /*CONFIG_TOOLS_V2*/

#ifdef __cplusplus
}
#endif
#pragma pack(pop)
#endif /*__VATOOLS_SMI_H__*/
