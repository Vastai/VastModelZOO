#ifndef __VASTAI_VIDEO_LOG_H__
#define __VASTAI_VIDEO_LOG_H__

#define VAVIDEO_PREFIX	      "[VAVIDEO] (pid %d) "

#define VAVIDEO_ERR(pcie, die_id, fmt, args...)                                \
	VASTAI_PCI_ERR(pcie, die_id, VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_ERR_RATELIMIT(pcie, die_id, fmt, args...)                      \
	VASTAI_PCI_ERR_RATELIMIT(VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_INFO(pcie, die_id, fmt, args...)                               \
	VASTAI_PCI_INFO(pcie, die_id, VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_INFO_RATELIMIT(pcie, die_id, fmt, args...)                     \
	VASTAI_PCI_INFO_RATELIMIT(VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_DBG(pcie, die_id, fmt, args...)                                \
	VASTAI_PCI_DBG(pcie, die_id, VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_DBG_RATELIMIT(fmt, args...)                                    \
	VASTAI_PCI_DBG_RATELIMIT(VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_PERF(fmt, args...)                                             \
	VASTAI_PCI_PERF(VAVIDEO_PREFIX fmt, current->pid, ##args)

#define VAVIDEO_DUMP_BRIEF(title, buf, buf_size_byte)                          \
	VASTAI_PCI_HEX_DUMP(KERN_DEBUG, VAVIDEO_PREFIX title,                      \
			 DUMP_PREFIX_NONE, 32, 4, buf, buf_size_byte, false)

#define VAVIDEO_FUNC_ENTERY                                                    \
	VAVIDEO_DBG_RATELIMIT("pid:%d %s entry!\n", current->pid, __func__)
			      
#define VAVIDEO_FUNC_EXIT                                                      \
	VAVIDEO_DBG_RATELIMIT("pid:%d %s done!\n", current->pid, __func__)

#endif //__VASTAI_VIDEO_LOG_H__