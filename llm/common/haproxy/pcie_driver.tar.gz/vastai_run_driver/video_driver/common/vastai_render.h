#ifndef __VASTAI_RENDER_H__
#define __VASTAI_RENDER_H__

#define VASTAI_VIDEO_DEBUG_DIR     "vastai_video"
#define VASTAI_VIDEO_DEBUG_NAME    "debug"

#define VASTAI_DEBUG_PARAM_DIEINDEX  "dieindex"
#define VASTAI_DEBUG_PARAM_ENCMODE   "enc_mode"
#define VASTAI_DEBUG_PARAM_DECMODE   "dec_mode"
#define VASTAI_DEBUG_PARAM_ENC_LOGLEVEL  "enc_loglevel"
#define VASTAI_DEBUG_PARAM_DEC_LOGLEVEL  "dec_loglevel"

typedef enum {
    VIDEO_STATE_INITING,
    VIDEO_STATE_CHANGING,
    VIDEO_STATE_READY,
    VIDEO_STATE_MAX,
}video_state_t;

struct vastai_video_info{
	struct vastai_device_handle *dec_device_handle;
	struct enc_chn_info *enc_info;
	struct device_handle *enc_device_handle;
	struct vastai_render_file *render_file;
	struct pid_entry *pid_entry;
    wait_queue_head_t wait_queue;
};

struct vastai_render_file {
	struct vastai_file_info file_info;
	struct vastai_pci_info *pci_info;
	void* private_data;
	void *dec_private_data;
	void *enc_private_data;
	struct list_head node;
	unsigned int die_index;

};

int vastai_render_file_init(struct vastai_pci_info *pci_info, u32 die_index,
				void *dec_private_data, void *enc_private_data);
void vastai_render_file_deinit(struct vastai_pci_info *pci_info);
#endif
