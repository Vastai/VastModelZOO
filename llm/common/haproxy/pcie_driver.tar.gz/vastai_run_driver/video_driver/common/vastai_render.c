/*
 * vastai_pci - driver a Vastai PCI device
 * Copyright (C) 2021 Vastai Technologies All Rights Reserved.
 * This work is licensed under the terms of the GNU GPL, version 2.
 *
 * Create on: 2020/09/25
 * Author: gang.wang
 */

#include <linux/ctype.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/dma-buf.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>
#include <linux/fs.h>
#include <linux/string.h>

#include "vastai_pci.h"
#include "vastaidec.h"
#include "vastai_vcmd.h"
#include "vastai_dev.h"
#include "vastai_render.h"
#include "vastai_enc.h"

//vastai video debug node related code start, node name: /proc/vastai/video/debug
static struct proc_dir_entry* dir;
static char video_debug_buffer[1024];

static int do_video_debug(char* buffer, size_t count) {
	const char* delim1 = " ", *delim2 = "=";
	char* token, *param, *value;
	int die_index = 0;

	token = strsep(&buffer, delim1);
	while (token) {
		param = strsep(&token, delim2);
		value = token;
		//printk("%s param=%s, value=%s\n", __func__, param, value);

		if (strncmp(param, VASTAI_DEBUG_PARAM_DIEINDEX, sizeof(VASTAI_DEBUG_PARAM_DIEINDEX)) == 0) {

			die_index = simple_strtol(value, NULL, 16);

		} else if (strncmp(param, VASTAI_DEBUG_PARAM_ENC_LOGLEVEL, sizeof(VASTAI_DEBUG_PARAM_ENC_LOGLEVEL)) == 0) {

			int enc_loglevel = simple_strtol(value, NULL, 10);
			hantroenc_set_log_level(enc_loglevel);

		} else if (strncmp(param, VASTAI_DEBUG_PARAM_DEC_LOGLEVEL, sizeof(VASTAI_DEBUG_PARAM_DEC_LOGLEVEL)) == 0) {

			//int dec_loglevel = simple_strtol(value, NULL, 10);
			//TODO

		} else if (strncmp(param, VASTAI_DEBUG_PARAM_ENCMODE, sizeof(VASTAI_DEBUG_PARAM_ENCMODE)) == 0) {
		#ifdef VASTAI_VIDEO_DEBUG
			encoder_workmode_t work_mode = (encoder_workmode_t)simple_strtol(value, NULL, 10);
			hantroenc_set_work_mode(die_index, work_mode, false);
		#else
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				"set encoder work mode is not supported from echo cmd, please use vasmi tool to set!!!\n");
			return -1;
		#endif
		} else if (strncmp(param, VASTAI_DEBUG_PARAM_DECMODE, sizeof(VASTAI_DEBUG_PARAM_DECMODE)) == 0) {
		#ifdef VASTAI_VIDEO_DEBUG 
			decoder_workmode_t work_mode = (decoder_workmode_t)simple_strtol(value, NULL, 10);
			dec_work_mode_change(die_index, work_mode);
		#else
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				"set decoder work mode is not supported from echo cmd, please use vasmi tool to set!!!\n");
			return -1;
		#endif
		} else {
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				"%s error unsupported param: %s\n", __func__, param);
			return -1;
		}

		token = strsep(&buffer, delim1);
	}

	return 0;
}

static int video_debug_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static int video_debug_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t video_debug_read(struct file *filp, char __user *buffer,
			    size_t count, loff_t *offset)
{
	int ret;
	//printk("%s, count=%ld, offset=%lld, video_debug_buffer=%s\n", __func__, count, *offset, video_debug_buffer);
	ret = video_copy_to_user(buffer, video_debug_buffer, MIN(count, strlen(video_debug_buffer)));
	if (ret) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "%s error %d\n", __func__, ret);
		return -EFAULT;
	}

	return 0;
}

static ssize_t video_debug_write(struct file *filp, const char __user *buffer,
			    size_t count, loff_t *offset)
{
	int ret;
	static char video_debug_buffer[1024];
	//printk("%s, count=%ld, offset=%lld, video_debug_buffer=%s\n", __func__, count, *offset, video_debug_buffer);
	ret = video_copy_from_user(video_debug_buffer, buffer, MIN(count, sizeof(video_debug_buffer)));
	if (ret) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "%s error %d\n", __func__, ret);
		return -EFAULT;
	}

	do_video_debug(video_debug_buffer, count);
	return MIN(count, sizeof(video_debug_buffer));
}

static long video_debug_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	return 0;
}
static int video_debug_init = 0;
static int video_debug_deinit = 0;
#if KERNEL_VERSION(5,6,0) <= LINUX_VERSION_CODE
static	struct proc_ops vastai_video_debug_ops = {
	.proc_open = video_debug_open,
	.proc_release = video_debug_release,
	.proc_read = video_debug_read,
	.proc_write = video_debug_write,
	.proc_ioctl = video_debug_ioctl,
};
#else
static  struct file_operations vastai_video_debug_ops = {
	.owner = THIS_MODULE,
	.open = video_debug_open,
	.release = video_debug_release,
	.read = video_debug_read,
	.write = video_debug_write,
	.unlocked_ioctl = video_debug_ioctl,
};
#endif

static int vastai_video_debug_init(void) {
	struct proc_dir_entry* file;
	if (video_debug_init)
		return 0;
	dir = proc_mkdir(VASTAI_VIDEO_DEBUG_DIR, NULL);
	if (dir == NULL) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "create debug dir %s failed\n", VASTAI_VIDEO_DEBUG_DIR);
		return -1;
	}

	file = proc_create(VASTAI_VIDEO_DEBUG_NAME, 0777, dir, &vastai_video_debug_ops);
	if (file == NULL) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "create debug dir %s failed\n", VASTAI_VIDEO_DEBUG_NAME);
		return -1;
	}
	video_debug_init = 1;
	return 0;
}

static int vastai_video_debug_deinit(void) {
	if (video_debug_deinit)
		return 0;
	remove_proc_entry(VASTAI_VIDEO_DEBUG_NAME, dir);
	remove_proc_entry(VASTAI_VIDEO_DEBUG_DIR, NULL);

	video_debug_deinit = 1;

	return 0;
}
//vastai video debug node related code end

extern int vastai_add_file(struct vastai_pci_info *pci_info);
extern int vastai_del_file(struct vastai_pci_info *pci_info);

static int render_open(struct inode *inode, struct file *filp)
{
	int ret = 0;
	struct vastai_file_info *file_info;
	struct vastai_render_file *render_file;
	struct vastai_video_info *video_info =
		kmalloc(sizeof(struct vastai_video_info), GFP_KERNEL);
	if (!video_info)
		return -ENOMEM;

	file_info = to_vastai_file_info(inode->i_cdev);
	render_file =
		container_of(file_info, struct vastai_render_file, file_info);
	if ((atomic_read(&render_file->pci_info->pci_state) == VASTAI_HOTP_STATE)) {
		return -ENODEV;
	}

	video_info->render_file = render_file;
	video_info->dec_device_handle = NULL; //will set on decoder ioctl separately
	video_info->enc_device_handle = NULL; //will set on encoder ioctl separately
	
	filp->private_data = video_info;
	ret = vastai_add_file(render_file->pci_info);
	if(ret != 0) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "render open add file failed %d\n", ret);
		return ret;
	}
	hantroenc_open(inode, filp);

	return 0;
}

static int render_release(struct inode *inode, struct file *filp)
{
	struct vastai_video_info *video_info =
		(struct vastai_video_info *)filp->private_data;

	if (video_info->enc_device_handle == NULL && video_info->dec_device_handle != NULL) {
		struct vastai_device_handle *device_handle  =
					video_info->dec_device_handle;
		vastaivcmd_release(filp, &device_handle->die);
		atomic_dec(&(device_handle->die.dec_job_count));
	} else if (video_info->dec_device_handle == NULL && video_info->enc_device_handle != NULL) {
		hantroenc_release(inode, filp);
		atomic_dec(&(video_info->enc_device_handle->die.enc_job_count));
	}

	vastai_del_file(video_info->render_file->pci_info);

	kfree(filp->private_data);

	return 0;
}

static ssize_t render_read(struct file *filp, char __user *buffer,
			    size_t count, loff_t *offset)
{
	return 0;
}
static long render_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct vastai_video_info *video_info;

	video_info = (struct vastai_video_info *)filp->private_data;
	if (cmd == VASTAI_VCMD_IOCH_SET_DECODER) {

		if (video_info->dec_device_handle != NULL
				&& video_info->dec_device_handle == video_info->render_file->dec_private_data) {
			return 0;
		}

		video_info->dec_device_handle = video_info->render_file->dec_private_data;
		video_info->enc_device_handle = NULL;

		atomic_inc(&(video_info->dec_device_handle->die.dec_job_count));

		//VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "video driver setup decoder\n");
		return 0;
	} else {
		if (!video_info->enc_device_handle && !video_info->dec_device_handle) {
			video_info->enc_device_handle = video_info->render_file->enc_private_data;
			video_info->dec_device_handle = NULL;

			atomic_inc(&(video_info->enc_device_handle->die.enc_job_count));

			if (atomic_read(&video_info->enc_device_handle->die.encoder_state) != VIDEO_STATE_READY){
				VAVIDEO_ERR(video_info->enc_device_handle->die.priv_dev,
							(u8)(video_info->enc_device_handle->die.die_index),
							"current encoder state is not ready, return\n");
				return -1;
			}

			//VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "video driver setup encoder\n");
		}

		if (cmd == VASTAI_ENC_IOCH_SET_ENCODER) {
			return 0;
		}
	}

	if (_IOC_TYPE(cmd) == VASTAI_VCMD_IOC_MAGIC)
		return vastaidec_ioctl(filp, cmd, arg);

	if(_IOC_TYPE(cmd) == VASTAI_ENC_IOC_MAGIC)
		return hantroenc_ioctl(filp, cmd, arg);


	return 0;
}

unsigned int render_poll(struct file *filp, poll_table *wait)
{
	return hantroenc_poll(filp, wait);
}

static const struct file_operations fop = {
	.owner = THIS_MODULE,
	.open = render_open,
	.release = render_release,
	.read = render_read,
	.unlocked_ioctl = render_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = render_ioctl,
#endif
	.poll = render_poll,
};

int vastai_render_file_init(struct vastai_pci_info *pci_info, u32 die_index,
				void *dec_private_data, void *enc_private_data)
{
	struct vastai_render_file *render_file =
		vmalloc(sizeof(struct vastai_render_file));
	int ret;

	if (render_file == NULL) {
		return -ENOMEM;
	}

	render_file->die_index = die_index;
	render_file->pci_info  = pci_info;
	ret = vastai_file_create(&render_file->file_info, pci_info, &fop,
				 "vastai_video%d",
				 vastai_get_vacc_id(pci_info, die_index));
	render_file->dec_private_data = dec_private_data;
	render_file->enc_private_data = enc_private_data;
	list_add_tail(&render_file->node, &pci_info->render_head);

	vastai_video_debug_init();

	return ret;
}

void vastai_render_file_deinit(struct vastai_pci_info *pci_info)
{
	struct vastai_render_file *render_file, *temp;

	hantroenc_cleanup(pci_info);
	vastai_cleanup(pci_info);

	list_for_each_entry_safe (
		render_file,
		temp, &pci_info->render_head, node) {
		vastai_file_destroy(&render_file->file_info);
		list_del(&render_file->node);
		vfree(render_file);
	}

	vastai_video_debug_deinit();
}
