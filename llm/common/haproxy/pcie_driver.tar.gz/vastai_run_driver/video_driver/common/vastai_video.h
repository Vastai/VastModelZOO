#ifndef __VASTAI_VIDEO_H
#define __VASTAI_VIDEO_H

#include "vastai_pci.h"
#include "vastai_video_log.h"

static inline int vastai_video_read_pcie(void* pci_info, unsigned int die_id, void* val, void* addr, unsigned int len){
	int ret;
	ret = vastai_pci_mem_read((struct vastai_pci_info *)pci_info, die_id, (u64)(addr), val, len);
	return ret;
}

static inline int vastai_video_write_pcie(void* pci_info, unsigned int die_id, void* val, void* addr, unsigned int len){
	return vastai_pci_mem_write((struct vastai_pci_info *)pci_info, die_id, (u64)(addr), val, len);
}

static inline int ioread32_pcie(void* addr){
	struct vastai_pci_info *pcie_dev = get_vastai_pci_device_info(0);
	int ret;
	vastai_pci_mem_read(pcie_dev, 0, (u64)(addr), &ret, sizeof(int));
	return ret;
}

static inline int iowrite32_pcie(int val, void* addr){
	struct vastai_pci_info *pcie_dev = get_vastai_pci_device_info(0);
	return vastai_pci_mem_write(pcie_dev, 0, (u64)(addr), &val, sizeof(int));
}
#define vastai_ioread32(addr)        ioread32_pcie((addr))
#define vastai_iowrite32(val, addr)  iowrite32_pcie((val), (addr))
#define vastai_readl(addr)           ioread32_pcie((addr))
#define vastai_writel(val, addr)     iowrite32_pcie((val), (addr))
#endif
