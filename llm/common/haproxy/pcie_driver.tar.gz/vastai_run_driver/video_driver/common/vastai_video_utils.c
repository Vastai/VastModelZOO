#include <linux/ioctl.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/vmalloc.h>
#include "vastai_video_utils.h"
#include "vastai_video.h"

void vastai_cmdid_init(VastCmdbufQueue *IdQueue, codec_type_t type)
{
    memset(IdQueue, 0, sizeof(VastCmdbufQueue));
    IdQueue->max_size = MAX_ELEM_NUM;
    IdQueue->type = type;
    spin_lock_init(&IdQueue->spin_lock);
}

int vastai_cmdid_queue_empty(VastCmdbufQueue *IdQueue)
{
	if (NULL == IdQueue){
		return -EINVAL;
	}

	if (IdQueue->rd == IdQueue->wr){
		return 1;
	}

	return 0;
}

int vastai_cmdid_queue_full(VastCmdbufQueue *IdQueue){
	u16 rd = 0, wr = 0;
	if (NULL == IdQueue) {
		return -EINVAL;
	}

	rd = IdQueue->rd;
	wr = IdQueue->wr;
	VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
		"%s: type=%d, rd: %d, wr: %d\n", __func__, IdQueue->type, rd, wr);
	if (( wr + 1) % IdQueue->max_size == rd){
		return 1;
	}

	return 0;
}

int vastai_cmdid_enqueue(VastCmdbufQueue *IdQueue,  u32 CmdId, u32 irq_status, u32 mcu_ccount, u32 cycles)
{
    if(vastai_cmdid_queue_full(IdQueue)) {
        VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
			"%s: type=%d, cmdbuf id queue is full!\n", __func__, IdQueue->type);
        return -ENOMEM;
    }
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
    	"%s: before type=%d, rd=%d, wr=%d\n", __func__, IdQueue->type, IdQueue->rd, IdQueue->wr);
    IdQueue->cmdbuf_id_fifo[IdQueue->wr] = CmdId;
    IdQueue->cmdbuf_irq_status[IdQueue->wr] = irq_status;
    IdQueue->mcu_ccount_q[IdQueue->wr] = mcu_ccount;
    IdQueue->cycles_q[IdQueue->wr] = cycles;    
    IdQueue->wr = (IdQueue->wr + 1) % IdQueue->max_size;
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
		"%s: after type=%d, rd=%d, wr=%d\n", __func__, IdQueue->type, IdQueue->rd, IdQueue->wr);
    return 0;
}

int vastai_cmdid_dequeue(VastCmdbufQueue *IdQueue, u32* CmdId, u32* irq_status, u32 *mcu_ccount, u32 *cycles)
 {
     if(vastai_cmdid_queue_empty(IdQueue)) {
         //printk("%s: cmdbuf id queue is empty!\n");
         return -EAGAIN;
     }
     VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
     	"%s: before type=%d, rd=%d, wr=%d\n", __func__, IdQueue->type, IdQueue->rd, IdQueue->wr);
     *CmdId = IdQueue->cmdbuf_id_fifo[IdQueue->rd];
     *irq_status = IdQueue->cmdbuf_irq_status[IdQueue->rd];
    if(mcu_ccount)
      *mcu_ccount = IdQueue->mcu_ccount_q[IdQueue->rd];
    if(cycles)
      *cycles = IdQueue->cycles_q[IdQueue->rd];	     
     IdQueue->rd = (IdQueue->rd + 1) % IdQueue->max_size;
     VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
	 	"%s: after type=%d, rd=%d, wr=%d\n", __func__, IdQueue->type, IdQueue->rd, IdQueue->wr);
     return 0;
 }




 void init_bi_list(bi_list* list)
{
  list->head = NULL;
  list->tail = NULL; 
}

bi_list_node* bi_list_create_node(void)
{
  bi_list_node* node=NULL;
  node=(bi_list_node*)vmalloc(sizeof(bi_list_node));
  if(node==NULL)
  {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "vmalloc for node fail!\n");
    return node;
  }
  memset(node,0,sizeof(bi_list_node)); 
  return node;
}
void bi_list_free_node(bi_list_node* node)
{
  //free current node
  vfree(node);
  return;
}

void bi_list_insert_node_tail(bi_list* list,bi_list_node* current_node)
{
  if(current_node==NULL)
  {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "insert node tail  NULL\n");
    return;
  }
  if(list->tail)
  {
   current_node->previous=list->tail;
   list->tail->next=current_node;
   list->tail=current_node;
   list->tail->next=NULL;
  }
  else
  {
   list->head=current_node;
   list->tail=current_node;
   current_node->next=NULL;
   current_node->previous=NULL;
  }
  return;
}

void bi_list_insert_node_before(bi_list* list,bi_list_node* base_node,bi_list_node* new_node)
{
  bi_list_node* temp_node_previous=NULL;
  if(new_node==NULL)
  {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "insert node before new node NULL\n");
    return;
  }
  if(base_node)
  {
   if(base_node->previous)
   {
    //at middle position
    temp_node_previous = base_node->previous;
    temp_node_previous->next=new_node;
    new_node->next = base_node;
    base_node->previous = new_node;
    new_node->previous=temp_node_previous;
   }
   else
   {
    //at head
    base_node->previous = new_node;
    new_node->next = base_node;
    list->head=new_node;
    new_node->previous = NULL;
   }
  }
  else
  {
   //at tail
   bi_list_insert_node_tail(list,new_node);
  }
  return;
}

void bi_list_remove_node(bi_list* list,bi_list_node* current_node)
{
  bi_list_node* temp_node_previous=NULL;
  bi_list_node* temp_node_next=NULL;
  if(current_node==NULL)
  {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "remove node NULL\n");
    return;
  }
  temp_node_next=current_node->next;
  temp_node_previous=current_node->previous;
  
  if(temp_node_next==NULL && temp_node_previous==NULL )
  {
    //there is only one node.
    list->head=NULL;
    list->tail=NULL;
  }
  else if(temp_node_next==NULL)
  {
    //at tail
    list->tail=temp_node_previous;
    temp_node_previous->next=NULL;
  }
  else if( temp_node_previous==NULL)
  {
    //at head
    list->head=temp_node_next;
    temp_node_next->previous=NULL;
  }
  else
  {
   //at middle position
   temp_node_previous->next=temp_node_next;
   temp_node_next->previous=temp_node_previous;
  }
  return;
}


/**
 * 0: 64bit
 * 1: 32bit
*/
int video_is_32_bit(void)
{
	int is_32_bit = 0;
#if (defined(__aarch64__) || defined(__arm__))
	is_32_bit = test_thread_flag(TIF_32BIT);
#else
	is_32_bit = test_thread_flag(TIF_ADDR32);
#endif
	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "is_32_bit_thread = %d\n", is_32_bit);
	return is_32_bit;
}

unsigned long video_copy_to_user(void __user *to, const void *from,
			      unsigned long n)
{
	unsigned long ret = 0;
	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "to=%p , from=%p ,n=%ld", to, from, n);
#ifdef CONFIG_COMPAT
	if (video_is_32_bit()) {
		ret = copy_to_user(
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)to) & 0xffffffff)),
			from, n);
		if (ret) {
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "fail: 32bit: to=%p from=%p n=%ld ret=%ld",
				    to, from, n, ret);
		}
		return ret;
	} else
#endif
  {
		ret = copy_to_user(to, from, n);
		if (ret) {
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				    "fail: 64bit: to=%p from=%p n=%ld ret=%ld",
				    to, from, n, ret);
		}
		return ret;
	}
	return 0;
}

unsigned long video_copy_from_user(void *to, const void __user *from,
				unsigned long n)
{
	unsigned long ret = 0;
	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "to=%p , from=%p ,n=%ld ", to, from, n);
#ifdef CONFIG_COMPAT
	if (video_is_32_bit()) {
		ret = copy_from_user(
			to,
			(void __user *)compat_ptr(
				(compat_uptr_t)(((u64)from) & 0xffffffff)),
			n);
		if (ret) {
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				    "fail: 32bit: to=%p from=%p n=%ld ret=%ld",
				    to, from, n, ret);
		}
		return ret;
	} else
#endif
  {
		ret = copy_from_user(to, from, n);
		if (ret) {
			VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				    "fail: 64bit: to=%p from=%p n=%ld ret=%ld",
				    to, from, n, ret);
		}
		return ret;
	}
	return 0;
}
