#ifndef __VASTAI_VIDEO_UTILS_H__
#define __VASTAI_VIDEO_UTILS_H__

#include <linux/ioctl.h>
#include <linux/fs.h>
#include <linux/compat.h>
#include <linux/thread_info.h>

#define MAX_ELEM_NUM 256

typedef enum{
    DECODER,
    ENCODER,
} codec_type_t;

typedef struct bi_list_node{
  void* data;
  struct bi_list_node* next; 
  struct bi_list_node* previous;
}bi_list_node;

typedef struct bi_list{
  bi_list_node* head; 
  bi_list_node* tail; 
}bi_list;

typedef struct {
    volatile u16 rd;
    volatile u16 wr;
    volatile u16 max_size;
    u32 cmdbuf_id_fifo[MAX_ELEM_NUM];
    u32 cmdbuf_irq_status[MAX_ELEM_NUM];
    u32 mcu_ccount_q[MAX_ELEM_NUM];
    u32 cycles_q[MAX_ELEM_NUM];
    spinlock_t spin_lock;
    codec_type_t type;
}VastCmdbufQueue;

void vastai_cmdid_init(VastCmdbufQueue *IdQueue, codec_type_t type);

int vastai_cmdid_queue_empty(VastCmdbufQueue *IdQueue);

int vastai_cmdid_queue_full(VastCmdbufQueue *IdQueue);

int vastai_cmdid_enqueue(VastCmdbufQueue *IdQueue, u32 CmdId, u32 irq_status, u32 mcu_ccount, u32 cycles);

int vastai_cmdid_dequeue(VastCmdbufQueue *IdQueue, u32 *CmdId, u32 *irq_status, u32 *mcu_ccount, u32 *cycles);



void init_bi_list(bi_list* list);

bi_list_node* bi_list_create_node(void);

void bi_list_free_node(bi_list_node* node);

void bi_list_insert_node_tail(bi_list* list,bi_list_node* current_node);

void bi_list_insert_node_before(bi_list* list,bi_list_node* base_node,bi_list_node* new_node);

void bi_list_remove_node(bi_list* list,bi_list_node* current_node);


int video_is_32_bit(void);
unsigned long video_copy_from_user(void *to, const void __user *from,
                               unsigned long n);
unsigned long video_copy_to_user(void __user *to, const void *from,
                               unsigned long n);

#endif