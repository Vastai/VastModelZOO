/*
 * VAstai Decoder device driver (kernel module)
*
* Copyright (C) 2020 VASTAI Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#ifndef __VASTAI_VCMD_DRIVER_H_
#define __VASTAI_VCMD_DRIVER_H_
#ifdef __FREERTOS__
#include "basetype.h"
#include "dev_common_freertos.h"
#elif defined(__linux__)
#include <linux/ioctl.h>    /* needed for the _IOW etc stuff used later */
#endif
#include "subsys.h"
#include "vastai_video_utils.h"

#ifdef __FREERTOS__
//addr_t has been defined in basetype.h //Now the FreeRTOS mem need to support 64bit env
#elif defined(__linux__)
#undef  addr_t
#define addr_t ADDR_T_VCMD
typedef size_t addr_t;
#endif

#define VASTAI_DECODER_VERSION_MAJOR 0
#define VASTAI_DECODER_VERSION_MINOR 1
#define VASTAI_DECODER_VERSION_REVISION 4

/* Use 'v' as magic number for vcmd */
#define VASTAI_VCMD_IOC_MAGIC  'v'
/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": G and S atomically
 * H means "sHift": T and Q atomically
 */

#define VIDEO_DEC_IOW(nr, type)                         _IO(VASTAI_VCMD_IOC_MAGIC, nr)
#define VIDEO_DEC_IOR(nr, type)                         _IO(VASTAI_VCMD_IOC_MAGIC, nr)
#define VIDEO_DEC_IOWR(nr, type)                        _IO(VASTAI_VCMD_IOC_MAGIC, nr)

#define VASTAI_VCMD_IOCH_SET_DECODER                    VIDEO_DEC_IOWR(19, u16)
#define VASTAI_VCMD_IOCH_GET_CMDBUF_PARAMETER           VIDEO_DEC_IOWR(20,struct cmdbuf_mem_parameter *)
#define VASTAI_VCMD_IOCH_GET_CMDBUF_POOL_SIZE           VIDEO_DEC_IOWR(21,unsigned long)
#define VASTAI_VCMD_IOCH_SET_CMDBUF_POOL_BASE           VIDEO_DEC_IOWR(22,unsigned long)
#define VASTAI_VCMD_IOCH_GET_VCMD_PARAMETER             VIDEO_DEC_IOWR(24, struct config_parameter *)
#define VASTAI_VCMD_IOCH_RESERVE_CMDBUF                 VIDEO_DEC_IOWR(25,struct exchange_parameter *)
#define VASTAI_VCMD_IOCH_LINK_RUN_CMDBUF                VIDEO_DEC_IOR(26,u16 *)
#define VASTAI_VCMD_IOCH_WAIT_CMDBUF                    VIDEO_DEC_IOWR(27, struct waitcmd_parameter *)
#define VASTAI_VCMD_IOCH_RELEASE_CMDBUF                 VIDEO_DEC_IOWR(28, struct waitcmd_parameter *)
#define VASTAI_VCMD_IOCH_POLLING_CMDBUF                 VIDEO_DEC_IOR(40,u16 *)
#define VASTAIDEC_IOCX_GET_VCMDCFG                      VIDEO_DEC_IOR(41,u32 *)
#define VASTAI_VCMD_IOCH_GET_FRAMEBUF                   VIDEO_DEC_IOWR(42, framebuf_desc_t *)
#define VASTAI_VCMD_IOCH_GET_ID_PARAMETER               VIDEO_DEC_IOWR(43, vcmd_id_parameter *)
#define VASTAI_VCMD_IOCH_READWRITE_DEVICE_MEM           VIDEO_DEC_IOWR(44, transfer_mem_param *)
#define VASTAI_CONFIG_CORE_CHANNEL                      VIDEO_DEC_IOWR(45, channel_info_t *)
#define VASTAI_DEC_GET_DIE_ID                           VIDEO_DEC_IOWR(46, int *)
#define VASTAI_GET_AVAILABLE_CHANNELS                   VIDEO_DEC_IOWR(47, channels_t *)
#define VASTAI_GET_DEC_WORK_MODE                        VIDEO_DEC_IOWR(48, u32 *)
#define VASTAI_RELEASE_CORE_CHANNEL                     VIDEO_DEC_IOWR(49, int)

#define VASTAI_MEM_WRITE 0
#define VASTAI_MEM_READ 1


#define VASTAI_VCMD_IOC_MAXNR 50

/*priority support*/

#define MAX_CMDBUF_PRIORITY_TYPE            2       //0:normal priority,1:high priority

#define CMDBUF_PRIORITY_NORMAL            0
#define CMDBUF_PRIORITY_HIGH              1

#if 0
#define OPCODE_WREG               (0x01<<27)
#define OPCODE_END                (0x02<<27)
#define OPCODE_NOP                (0x03<<27)
#define OPCODE_RREG               (0x16<<27)
#define OPCODE_INT                (0x18<<27)
#define OPCODE_JMP                (0x19<<27)
#define OPCODE_STALL              (0x09<<27)
#define OPCODE_CLRINT             (0x1a<<27)
#define OPCODE_JMP_RDY0           (0x19<<27)
#define OPCODE_JMP_RDY1           ((0x19<<27)|(1<<26))
#define JMP_IE_1                  (1<<25)
#define JMP_RDY_1                 (1<<26)

#define CLRINT_OPTYPE_READ_WRITE_1_CLEAR         0
#define CLRINT_OPTYPE_READ_WRITE_0_CLEAR         1
#define CLRINT_OPTYPE_READ_CLEAR                 2

#define VC8000E_FRAME_RDY_INT_MASK                        0x0001
#define VC8000E_CUTREE_RDY_INT_MASK                       0x0002
#define VC8000E_DEC400_INT_MASK                           0x0004
#define VC8000E_L2CACHE_INT_MASK                          0x0008
#define VC8000E_MMU_INT_MASK                              0x0010

#define VC8000D_FRAME_RDY_INT_MASK                        0x0100
#define VC8000D_DEC400_INT_MASK                           0x0400
#define VC8000D_L2CACHE_INT_MASK                          0x0800
#define VC8000D_MMU_INT_MASK                              0x1000
#endif

#define HW_ID_1_0_C                0x43421001
#define HW_ID_1_1_2                0x43421102

#define ANY_CMDBUF_ID 0xFFFF

#define VCMD_HW_ID                  0x4342

#define EXECUTING_CMDBUF_ID_ADDR       26
#define VCMD_EXE_CMDBUF_COUNT           3

#define WORKING_STATE_IDLE              0
#define WORKING_STATE_WORKING           1
#define CMDBUF_EXE_STATUS_OK            0
#define CMDBUF_EXE_STATUS_CMDERR        1
#define CMDBUF_EXE_STATUS_BUSERR        2

#define CMDBUF_MAX_SIZE                     (512*4*4)
#define CMDBUF_POOL_TOTAL_SIZE              (2*1024*1024)        //approximately=128x(320x240)=128x2k=128x8kbyte=1Mbytes
#define TOTAL_DISCRETE_CMDBUF_NUM           (CMDBUF_POOL_TOTAL_SIZE/CMDBUF_MAX_SIZE)
#define IM_CMDBUF_NUM						(64)
#define CMDBUF_VCMD_REGISTER_TOTAL_SIZE     5*1024*1024 - CMDBUF_POOL_TOTAL_SIZE * 2
#define VCMD_REGISTER_SIZE                  (128*4)
#define MAX_SAME_MODULE_TYPE_CORE_NUMBER    4
#define MAX_VCMD_NUMBER                     (MAX_VCMD_TYPE*MAX_SAME_MODULE_TYPE_CORE_NUMBER)

#define CmdIdQueueSize         TOTAL_DISCRETE_CMDBUF_NUM // 256
#define CmdIdQueueFull           1
#define CmdIdQueueEmpty          0
#define CmdIdFifoDone            1


#define ASIC_VCMD_SWREG_AMOUNT                  27
#define VCMD_REGISTER_CONTROL_OFFSET            0X40
#define VCMD_REGISTER_INT_STATUS_OFFSET         0X44
#define VCMD_REGISTER_INT_CTL_OFFSET            0X48

typedef u32 IdType;

enum
{
    VIDEO_LOGLEVEL_ERROR = 0,
    VIDEO_LOGLEVEL_WARN,
    VIDEO_LOGLEVEL_INFO,
    VIDEO_LOGLEVEL_DEBUG,
    VIDEO_LOGLEVEL_TRACE,
    VIDEO_LOGLEVEL_COUNT
};

/*module_type support*/

enum vcmd_module_type{
  VCMD_TYPE_ENCODER = 0,
  VCMD_TYPE_CUTREE,
  VCMD_TYPE_DECODER,
  VCMD_TYPE_JPEG_ENCODER,
  VCMD_TYPE_JPEG_DECODER,
  MAX_VCMD_TYPE
};

struct cmdbuf_mem_parameter
{
  u64 virt_cmdbuf_addr;
  u64 phy_cmdbuf_addr;                 //cmdbuf pool base physical address
  u32 mmu_phy_cmdbuf_addr;             //cmdbuf pool base mmu mapping address
  u32 cmdbuf_total_size;               //cmdbuf pool total size in bytes.
  u16 cmdbuf_unit_size;                //one cmdbuf size in bytes. all cmdbuf have same size.
  u64 virt_status_cmdbuf_addr;
  u64 phy_status_cmdbuf_addr;          //status cmdbuf pool base physical address
  u32 mmu_phy_status_cmdbuf_addr;      //status cmdbuf pool base mmu mapping address
  u32 status_cmdbuf_total_size;        //status cmdbuf pool total size in bytes.
  u16 status_cmdbuf_unit_size;         //one status cmdbuf size in bytes. all status cmdbuf have same size.
  u64 base_ddr_addr;                   //for pcie interface, hw can only access phy_cmdbuf_addr-pcie_base_ddr_addr.
  u64 vcmd_reg_mem_busAddress;         //start physical address of vcmd registers memory of  CMDBUF.

  u16 vcmd_core_id;                    //vcmd-core-id
}__attribute__((packed));

struct config_parameter
{
  u16 module_type;                    //input vc8000e=0,cutree=1,vc8000d=2,jpege=3, jpegd=4
  u16 vcmd_core_num;                  //output, how many vcmd cores are there with corresponding module_type.
  u16 submodule_main_addr;            //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_dec400_addr;          //output ,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_L2Cache_addr;         //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_MMU_addr;             //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_MMUWrite_addr;        //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_axife_addr;           //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 submodule_axifewrite_addr;      //output,if submodule addr == 0xffff, this submodule does not exist.
  u16 config_status_cmdbuf_id;        // output , this status comdbuf save the all register values read in driver init.//used for analyse configuration in cwl.
  u32 vcmd_hw_version_id;
}__attribute__((packed));


typedef struct {
	u32 channel;
	u64 stream_src_addr;         //stream buf addr on host user space
	u64 stream_dst_addr;         //stream buf phy addr on pcie device side
	u32 stream_size;             //stream data len
	u64 vcmdbuf_src_addr;        //vcmd buf addr on host user space
	u64 vcmdbuf_dst_addr;        //vcmd buf phy addr on pcie device side
	u32 vcmd_size;               //vcmd data len
}__attribute__((packed)) vcmd_desc_t;

typedef struct {
	u32 channel;
	u64 stream_dst_addr;         //stream buf addr on host user space
	u64 stream_src_addr;         //stream buf phy addr on pcie device side
	u32 stream_size;             //stream data len
}__attribute__((packed)) framebuf_desc_t;

typedef struct {
    u16 vcmd_core_id;                   //input.
    u16 module_type;                    //input vc8000e=0,cutree=1,vc8000d=2,jpege=3, jpegd=4
    u32 decoderAsicId;                  // output , for main module: hardware build id;
    u32 hwBuildId;                      // output , hardware build id
    u32 l2CacheVersion;                 // output , l2cache version.
}__attribute__((packed)) vcmd_id_parameter;

typedef struct {
	u8 dir;                             //transfer direction, host to device: 0, device to host: 1;
	u64 bus_addr;                       //device bus address;
	u64 local_addr;                     //host virtual address;
	u32 len;                            //transfer data length;
}__attribute__((packed)) transfer_mem_param;


typedef struct {
	int capacity[HXDEC_MAX_CORES];
	int skipped[HXDEC_MAX_CORES];
} dec_res_t;

typedef enum {
    NORMAL_DECODE = 0,
    AV1_DECODE,
    MAX_DECODER_NUM
} decode_type_t;

typedef enum {
    NORMAL0 = 0,
    NORMAL1,
    NORMAL2,
    AV10,
    AV11,
    MAX_CORE_NUM
} decoder_coreid_t;

typedef enum {
    VDMCU0 = 0,
    VDMCU1,
    VDMCU2,
    MAX_MCU_NUM
} decoder_mcuid_t;

typedef struct {
	u32 channel;
	u32 type;
	u32 width;
	u32 height;
	u32 core_id;
	u32 die_id;
} channel_info_t;

typedef struct {
	u32 width;
	u32 height;
	u32 channels[5];
} channels_t;

#define MAX_RESP_COUNT 2
typedef struct {
	channel_info_t channel_info;
	int dec_ratio;
	struct file *filp;
	struct list_head list;
} channel_desc_t;


struct waitcmd_parameter
{
  u32 core_id;
  u32 cmdbuf_id;
  u16 status;
  u16 reserved;
  u32 mcu_ccount;
  u32 cycles;
}__attribute__((packed));

/*need to consider how many memory should be allocated for status.*/
struct exchange_parameter
{
  u64 executing_time;                 //input ;executing_time=encoded_image_size*(rdoLevel+1)*(rdoq+1);
  u16 module_type;                    //input input vc8000e=0,IM=1,vc8000d=2, jpege=3, jpegd=4
  u16 cmdbuf_size;                    //input, reserve is not used; link and run is input.
  u16 priority;                       //input,normal=0, high/live=1
  u16 cmdbuf_id;                      //output, it is unique in driver.
  u16 core_id;
#ifdef VASTAI_DMA
  vcmd_desc_t  vcmdbuf_desc;
#endif
}__attribute__((packed));

struct noncache_mem
{
  u32 *virtualAddress;
  dma_addr_t  busAddress;
  unsigned int mmu_bus_address;  /* buffer physical address in MMU*/
  u32 size;
  u16 cmdbuf_id;
};

struct cmdbuf_obj
{
	u32 module_type;               //current CMDBUF type: input vc8000e=0,IM=1,vc8000d=2,jpege=3, jpegd=4
	u32 priority;                  //current CMDBUFpriority: normal=0, high=1
	u64 executing_time;           //current CMDBUFexecuting_time=encoded_image_size*(rdoLevel+1)*(rdoq+1);
	u32 cmdbuf_size;              //current CMDBUF size
	u32 *cmdbuf_User_virtualAddress; //current CMDBUF user space address
	size_t cmdbuf_busAddress;      //current CMDBUF start physical address.
	unsigned int mmu_cmdbuf_busAddress;      //current CMDBUF start mmu mapping address.
	u32 *status_virtualAddress;   //current status CMDBUF start virtual address.
	size_t status_busAddress;      //current status CMDBUF start physical address.
	unsigned int mmu_status_busAddress;      //current status CMDBUF start mmu mapping address.
	u32 status_size;              //current status CMDBUF size
	u32 executing_status;          //current CMDBUF executing status.
	struct file *filp;            //file pointer in the same process.
	u16 core_id;                  //which vcmd core is used.
	u16 cmdbuf_id;                 //It is a handle to identify cmdbuf.also is an interrupt vector.position in pool,same as status position.
	u8 cmdbuf_data_loaded;        //0 means sw has not copied data into this CMDBUF; 1 means sw has copied data into this CMDBUF
	u8 cmdbuf_data_linked;        //0 :not linked, 1:linked.
	u8 cmdbuf_run_done;           //0:waiting for CMDBUF finish;1:op code in CMDBUF has finished one by one. VASTAI_VCMD_IOCH_WAIT_CMDBUF will check this variable.
	u8 cmdbuf_need_remove;        // if 0, not need to remove CMDBUF; 1 CMDBUF can be removed if it is not the last CMDBUF;
	u32 waited;                   // if 0, the cmd buf hasn't been waited, otherwise, has been waited.
	u8 has_end_cmdbuf;            //if 1, the last opcode is end opCode.
	u8 no_normal_int_cmdbuf;      //if 1, JMP will not send normal interrupt.
	u32 user_flag;                //if 1, current CMDBUF is from user space
	u32 mcu_ccount;
	u32 cycles;
	u32 is_wakeup;
};


struct vastaivcmd_dev
{
	struct vcmd_config vcmd_core_cfg; //config of each core,such as base addr, irq,etc
	u32 core_id; //vcmd core id for driver and sw internal use
	u32 sw_cmdbuf_rdy_num;
	struct mutex mutex;
	wait_queue_head_t * wait_abort_queue;
	bi_list list_manager;
	volatile u8 *hwregs;/* IO mem base */
	u32 reg_mirror[ASIC_VCMD_SWREG_AMOUNT];
	u32 duration_without_int;              //number of cmdbufs without interrupt.
	u8 working_state;
	u64 total_exe_time;
	u16 status_cmdbuf_id;//used for analyse configuration in cwl.
	u32 hw_version_id; /*megvii 0x43421001, later 0x43421102*/
	u32 *vcmd_reg_mem_virtualAddress;//start virtual address of vcmd registers memory of  CMDBUF.
	size_t vcmd_reg_mem_busAddress;  //start physical address of vcmd registers memory of  CMDBUF.
	unsigned int mmu_vcmd_reg_mem_busAddress;  //start mmu mapping address of vcmd registers memory of CMDBUF.
	u32  vcmd_reg_mem_size;              // size of vcmd registers memory of CMDBUF.
	u32  dma_package_size;              // size of vcmd registers memory of CMDBUF.
	struct work_struct work;
	struct die_info *die;
	u32 mcu_vcmd_status;
	VastCmdbufQueue cmdbufId_queue;

	struct noncache_mem vcmd_buf_mem_pool;
	struct noncache_mem vcmd_status_buf_mem_pool;
	struct noncache_mem vcmd_registers_mem_pool;
	u16 cmdbuf_used[TOTAL_DISCRETE_CMDBUF_NUM];
	u16 cmdbuf_used_pos;
	u16 cmdbuf_used_residual;
	u16 vcmd_position[MAX_VCMD_TYPE];

	int vcmd_type_core_num[MAX_VCMD_TYPE];

	struct wait_queue_head vcmd_cmdbuf_memory_wait;
	spinlock_t vcmd_cmdbuf_alloc_lock;

	struct cmdbuf_obj cmdbuf_obj_sets[TOTAL_DISCRETE_CMDBUF_NUM];

	int decoder_crash_flag;
};

struct die_info
{
	/* pointer to pcie dev */
	void *vcmd_pri;
	/* die id, start from 0 */
	int die_id;
	/* pointer to vcmd for one die */
	struct vastaivcmd_dev* vastaivcmd_data;
	struct vastaivcmd_dev* vcmd_manager[MAX_VCMD_TYPE][MAX_VCMD_NUMBER];

	int vcmd_type_core_num[MAX_VCMD_TYPE];

	wait_queue_head_t wait_queue_vcmd[MAX_VCMD_NUMBER];
	wait_queue_head_t abort_queue_vcmd[MAX_VCMD_NUMBER];


	/* bi_list_node* global_cmdbuf_node[TOTAL_DISCRETE_CMDBUF_NUM]; */


	wait_queue_head_t mc_wait_queue;
	struct workqueue_struct *workqueue;
	//spinlock_t cfg_core_lock;
	struct mutex allocate_core_mutex;
	struct list_head die_channel_head;
	dec_res_t dec_res;
	u32 die_channels;

	int core_num;
	decoder_workmode_t work_mode;
	atomic_t decoder_state;
	atomic_t dec_job_count;
	u8 reset_end_bitmap;
};

int vastaivcmd_open(struct inode *inode, struct file *filp);
long vastaivcmd_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
void vastaivcmd_process_init(void);
int vastaivcmd_init(struct die_info *die);
void vastaivcmd_cleanup(struct die_info *die);
int vastaivcmd_release(struct file *filp, struct die_info *die);
int set_dec_work_mode(struct die_info *die_info, decoder_workmode_t work_mode);
#endif
