/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2019 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------
--
--  Abstract : VC8000 Vcmd device driver (kernel module)
--
------------------------------------------------------------------------------*/

#ifndef _VC8000_VCMD_DRIVER_H_
#define _VC8000_VCMD_DRIVER_H_
#include <linux/poll.h>
#include "vastai_vcmd.h"
#include "vastai_pci.h"

#ifdef __FREERTOS__
/* needed for the _IOW etc stuff used later */
#include "base_type.h"
#include "osal.h"
#include "dev_common_freertos.h"
#elif defined(__linux__)
#include <linux/ioctl.h>    /* needed for the _IOW etc stuff used later */
#else //For other os
//TODO...
#endif
#ifdef HANTROMMU_SUPPORT
#include "hantrommu.h"
#endif

#ifdef HANTROAXIFE_SUPPORT
#include "vc8000_axife.h"
#endif

#ifdef __FREERTOS__
//ptr_t has been defined in base_type.h //Now the FreeRTOS mem need to support 64bit env
#elif defined(__linux__)
#undef  ptr_t
#define ptr_t  PTR_T_KERNEL
typedef size_t ptr_t;
#endif

#define VASTAI_ENC_IOC_MAGIC  'e'

#define VIDEO_ENC_IOW(nr, type)                                 _IO(VASTAI_ENC_IOC_MAGIC, nr)
#define VIDEO_ENC_IOR(nr, type)                                 _IO(VASTAI_ENC_IOC_MAGIC, nr)
#define VIDEO_ENC_IOWR(nr, type)                                _IO(VASTAI_ENC_IOC_MAGIC, nr)

#define VASTAI_ENC_IOCH_SET_ENCODER                             VIDEO_ENC_IOWR(24, u16)
#define VASTAI_ENC_IOCH_GET_CMDBUF_PARAMETER                    VIDEO_ENC_IOWR(25, struct cmdbuf_mem_parameter *)
#define VASTAI_ENC_IOCH_GET_CMDBUF_POOL_SIZE                    VIDEO_ENC_IOWR(26, unsigned long)
#define VASTAI_ENC_IOCH_SET_CMDBUF_POOL_BASE                    VIDEO_ENC_IOWR(27, unsigned long)
#define VASTAI_ENC_IOCH_GET_VCMD_PARAMETER                      VIDEO_ENC_IOWR(28, struct config_parameter *)
#define VASTAI_ENC_IOCH_RESERVE_CMDBUF                          VIDEO_ENC_IOWR(29, struct exchange_parameter *)
#define VASTAI_ENC_IOCH_LINK_RUN_CMDBUF                         VIDEO_ENC_IOR(30, struct exchange_parameter *)
#define VASTAI_ENC_IOCH_WAIT_CMDBUF                             VIDEO_ENC_IOR(31, struct enc_waitcmd_parameter*)
#define VASTAI_ENC_IOCH_RELEASE_CMDBUF                          VIDEO_ENC_IOR(32, struct enc_waitcmd_parameter*)
#define VASTAI_ENC_IOCH_POLLING_CMDBUF                          VIDEO_ENC_IOR(33, u16 *)
#define VASTAI_ENC_IOCH_GET_ENCMODE                             VIDEO_ENC_IOR(34, u16 *)
#define VASTAI_ENC_IOCH_GET_MULTIMODE_RESERVE                   VIDEO_ENC_IOR(35, u32 *)
#define VASTAI_ENC_IOCH_GET_MULTIMODE_RELEASE                   VIDEO_ENC_IOR(36, u32 *)
#define VASTAI_ENC_IOCH_INT_VEMCU                               VIDEO_ENC_IOWR(41, unsigned long *)
#define VASTAI_ENC_IOCH_ALLOCCHANNEL_LOCK                       VIDEO_ENC_IOWR(42, unsigned int*)
#define VASTAI_ENC_IOCH_ALLOCCHANNEL_UNLOCK                     VIDEO_ENC_IOWR(43, unsigned int*)
#define VASTAI_ENC_IOCH_ATTACH_VENCCHNL                         VIDEO_ENC_IOWR(44, unsigned long*)
#define VASTAI_ENC_IOCH_DETACH_VENCCHNL                         VIDEO_ENC_IOWR(45, unsigned long*)
#define VASTAI_ENC_IOCH_SET_VENCCHNLMSG                         VIDEO_ENC_IOWR(46, unsigned long*)
#define VASTAI_ENC_IOCH_GET_VENCCHNLMSG                         VIDEO_ENC_IOWR(47, unsigned long*)
#define VASTAI_ENC_IOCH_GET_VCMD_ENABLE                         VIDEO_ENC_IOWR(50, unsigned long)
#define VASTAI_ENC_IOCH_GET_DIE_ID                              VIDEO_ENC_IOWR(60, int *)

#define VASTAI_ENC_IOC_MAXNR 60
#define VASTAI_MAX_ENC_CORES  (4)
#define VASTAI_MAX_CORE_CHANNEL  (32)

#define VENC_MAGIC_NUMBER		(0x6aa6)
//#define CORE_MAX  (CORE_MMU)

#define HOST_VEMCU0_MSG_ADDR    (0x8c56000)
#define HOST_VEMCU1_MSG_ADDR    (0x8c56400)
#define HOST_VEMCU2_MSG_ADDR    (0x8c56800)
#define HOST_VEMCU3_MSG_ADDR    (0x8c56c00)

#define ENCODER_WORKMODE_ADDR       (0x814000000)
#define ENCODER_SINGLE_MODE_MAGIC   (0xaaaaaaaa)
#define ENCODER_MULTI_MODE_MAGIC    (0xbbbbbbbb)

#define HOST_VEMCU_MAX_FIFO_LEN  (0x1000) //4k for vemcu 0~3
#define HOST_VEMCU_ELEM_SIZE     (sizeof(host_to_vemcu_msg_t))
#define HOST_VEMCU_MAX_MSG_NUM	((HOST_VEMCU_MAX_FIFO_LEN - sizeof(struct vastai_fifo)) / HOST_VEMCU_ELEM_SIZE)

#define ASIC_STATUS_ALL       (ASIC_STATUS_SEGMENT_READY |\
                               ASIC_STATUS_FUSE_ERROR |\
                               ASIC_STATUS_SLICE_READY |\
                               ASIC_STATUS_LINE_BUFFER_DONE |\
                               ASIC_STATUS_HW_TIMEOUT |\
                               ASIC_STATUS_BUFF_FULL |\
                               ASIC_STATUS_HW_RESET |\
                               ASIC_STATUS_ERROR |\
                               ASIC_STATUS_FRAME_READY)


#define MULTI_MODE_ALLOW_MAX_STREAM        32  //multi-mode allow max stream encode
#define CHECK_RESET_STAT_INTERVAL          10  //mode switch check reset status interval

enum
{
  CORE_VC8000E = 0,
  CORE_VC8000EJ = 1,
  CORE_CUTREE = 2,
  CORE_DEC400 = 3,
  CORE_MMU = 4,
  CORE_L2CACHE = 5,
  CORE_AXIFE = 6,
  CORE_APBFT = 7,
  CORE_MMU_1 = 8,
  CORE_AXIFE_1 = 9,
  CORE_MAX
};

enum data_subtype {
       VCMD,
       STREAM,
       SUB_TYPE_MAX,
};

typedef enum {
    SINGLE_CORE_MODE,    //one stream encode on one encoder core
    MULTI_CORE_MODE,     //one stream encode on multi encoder core
    WORK_MODE_MAX,
}encoder_workmode_t;

typedef struct CoreWaitOut
{
  u32 job_id[4];
  u32 irq_status[4];
  u32 irq_num;
} CORE_WAIT_OUT;

typedef struct
{
  u32 subsys_idx;
  u32 core_type;
  unsigned long offset;
  u32 reg_size;
  int irq;
}CORE_CONFIG;

typedef struct
{
  unsigned long base_addr;
  u32 iosize;
  u32 resouce_shared; //indicate the core share resources with other cores or not.If 1, means cores can not work at the same time.
}SUBSYS_CONFIG;

typedef struct
{
  u32 type_info; //indicate which IP is contained in this subsystem and each uses one bit of this variable
  unsigned long offset[CORE_MAX];
  unsigned long regSize[CORE_MAX];
  int irq[CORE_MAX];
}SUBSYS_CORE_INFO;

typedef struct
{
  SUBSYS_CONFIG cfg;
  SUBSYS_CORE_INFO core_info;
}SUBSYS_DATA;

// add by taoz dma  dma
typedef struct tagDmaDataTrans
{
  unsigned int    dwStructVer;
  unsigned int    dwSize;
  unsigned int    dwDataSize;
  unsigned int    dwOutputBufLen;
  unsigned int    dwDeviceId;
  unsigned int    dwReserve;
  void* pInSrcAddr;
  void* pOutAddr;
}TDmaDataTrans;

typedef struct tagIntVEMCU
{
  unsigned int    dwStructVer;
  unsigned int    dwSize;
  unsigned int    dwDeviceId;
  unsigned int    dwDieId;
  unsigned int    dwCoreId;
  unsigned int    dwCsrAddr;
  unsigned int    dwVal;

}TIntVEMCU;

typedef struct vemcu_to_host_msg
{
  unsigned int instance_addr;
  unsigned int enc_status;
  unsigned int core_id;
  unsigned int reserved;
} vemcu_to_host_msg_t;

typedef struct multivemcu_to_host_msg
{
  unsigned int cmdbuf_id;
  unsigned int encstate;
  unsigned int core_id;
  unsigned int mcu_ccount;
  unsigned int total_cycles;  
  unsigned int reserved;  
} multivemcu_to_host_msg_t;

typedef struct multivemcu_to_host_msg  enc_waitcmd_parameter;

typedef struct host_to_vemcu_msg
{
  unsigned int magic;
  unsigned int cmdbuf_id;
  unsigned int cmdbuf_len;
  unsigned int module_type;
  u64 executing_time;
} host_to_vemcu_msg_t;

typedef struct tagVidEncDest
{
  u32 dwInstAddr;
	u32 dwReserved;
}TVidEncDest;

typedef struct tagVidEncInit
{
	u32 dwReserved;
}TVidEncInit;
typedef struct tagVidEncPutData
{
	u32 dwInstAddr;
	u32 dwPsAddr;
	u32 dwReserved;
}TVidEncPutData;

typedef struct tagVidEncCfgParam
{
  u32 dwStructVer;
  u32 dwSize;
  u32 dwCmdId;
  u32 dwEncType;
  union
  {
    TVidEncDest tParamDest;         // dwCmdId = VEMCU_CMDID_DEST_CODEC
    TVidEncInit tParamInit;         // dwCmdId = VEMCU_CMDID_INIT_CODEC
    TVidEncPutData tParamPutData;   // dwCmdId = VEMCU_CMDID_PUT_DATA
    /* data */
  }uParam;
}TVidEncCfgParam;
typedef struct venc_msg_chninfo
{
  unsigned int instance_addr;
  unsigned int msg_addr;    // to init vastai_fifo
  unsigned int die_index;
  unsigned int core_id;
} venc_msg_chninfo_t;
struct enc_chn_info
{
	u32 core_id;
  u32 die_index;
  u32 instance_addr;
  u64 msg_addr;
	wait_queue_head_t wait_queue;
	struct list_head node;
//  struct vastai_fifo* rcv;
	u32 event;
};
struct core_info
{
  struct list_head enc_chn_head;
  struct enc_chn_info enc_chn_set[VASTAI_MAX_CORE_CHANNEL];
};

struct multimode_limit_stream{
    pid_t  main_pid;
    pid_t  namespace_pid;
    struct pid_namespace *pid_ns;
};

struct die_enc_info
{
	/* pointer to pcie dev */
  int die_index;
	struct vastai_pci_info *priv_dev;
  struct core_info venc_core_info[VASTAI_MAX_ENC_CORES];
  struct vastaivcmd_dev* vastaivcmd_data;
  int core_num;

  int vcmd_type_core_num[MAX_VCMD_TYPE];
	struct vastaivcmd_dev* vcmd_manager[MAX_VCMD_TYPE][MAX_VCMD_NUMBER];

	struct noncache_mem vcmd_buf_mem_pool;
	struct noncache_mem vcmd_status_buf_mem_pool;
	struct noncache_mem vcmd_registers_mem_pool;
	u16 cmdbuf_used[TOTAL_DISCRETE_CMDBUF_NUM];
	u16 cmdbuf_used_pos;
	u16 cmdbuf_used_pos_im;
	u16 cmdbuf_used_residual;
	u16 cmdbuf_used_residual_im;
	u16 vcmd_position[MAX_VCMD_TYPE];
  struct cmdbuf_obj cmdbuf_obj_sets[TOTAL_DISCRETE_CMDBUF_NUM];

  struct wait_queue_head vcmd_cmdbuf_memory_wait;
  struct wait_queue_head venc_alloc_channel_wait;
  struct mutex mutex;
  struct mutex vastai_fifo_mutex;
  wait_queue_head_t wait_queue;
  struct work_struct work;
  struct workqueue_struct *workqueue;
  VastCmdbufQueue cmdbufId_queue;
  multivemcu_to_host_msg_t mcu_msg[TOTAL_DISCRETE_CMDBUF_NUM];   //encode information send from vemcu when one frame is ready

  atomic_t enc_job_count;
  atomic_t encoder_state;
  encoder_workmode_t encoder_mode;
  struct multimode_limit_stream  limit_info[MULTI_MODE_ALLOW_MAX_STREAM];
  u8 reset_end_bitmap;
  int venc_chanl_locked;
};

typedef struct device_handle
{
  //unsigned int  die_index;
  //void* priv_dev;
  struct die_enc_info die;
  struct mutex chan_alloc_mutex;
  struct mutex device_mutex;
  struct list_head node;
  ktime_t timestamp;
  struct file *lock_filp;
} device_handle_t;

#ifndef MIN
#define MIN(a, b)  ((a) < (b) ? (a):(b))
#endif

#ifndef MAX
#define MAX(a, b)  ((a) > (b) ? (a):(b))
#endif
//add by taoz dma for dma end
int  hantroenc_init(void *pcie_dev, unsigned int die_index);
void  hantroenc_cleanup(void *pcie_dev);
int  hantroenc_normal_init(void *pcie_dev, unsigned int die_index);
void  hantroenc_normal_cleanup(void *pcie_dev);

int hantroenc_open(struct inode *inode, struct file *filp);
int hantroenc_release(struct inode *inode, struct file *filp);
long hantroenc_ioctl(struct file *filp,
                          unsigned int cmd, unsigned long arg);
unsigned int hantroenc_poll(struct file *filp, poll_table *wait);
int hantroenc_get_device_from_dieindex(u32 die_index, device_handle_t** enc_device_handle);
int hantroenc_set_work_mode(int die_index, encoder_workmode_t work_mode, u32 init);
int hantroenc_get_work_mode(int die_index, encoder_workmode_t* work_mode, int* job_count);
void hantroenc_set_log_level(int level);
int vastai_video_enc_reset_handler(u32 die_index, u32 core_bit, reset_event event);
#endif /* !_VC8000_VCMD_DRIVER_H_ */


