/*------------------------------------------------------------------------------
--
--           This software is confidential and proprietary and may be used
--            only as expressly authorized by a licensing agreement from
--
--                                Verisilicon.
--
--                       (C) COPYRIGHT 2014 VERISILICON
--                              ALL RIGHTS RESERVED
--
--                   The entire notice above must be reproduced
--                   on all copies and should not be removed.
--
--------------------------------------------------------------------------------
--
--  Abstract : H2 Encoder device driver (kernel module)
--
------------------------------------------------------------------------------*/

#include <linux/version.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/time.h>
#include <linux/poll.h>
#include <linux/sched/signal.h>
#include <linux/timer.h>
#include "vastai_enc.h"
#include "vastai_pci.h"
#include "vastai_fifo.h"
#include "vastai_render.h"
#include "vastai_vcmd.h"
#include "vastai_video_utils.h"

#define VASTAI_ENC_CORE0  VEMCU0_2_HOST_INT
#define VASTAI_ENC_CORE1  VEMCU1_2_HOST_INT
#define VASTAI_ENC_CORE2  VEMCU2_2_HOST_INT
#define VASTAI_ENC_CORE3  VEMCU3_2_HOST_INT
#define ENCCORE0_IRQ_BASE VASTAI_ENC_CORE0

#define VC8000          "vc8000"

#define VASTAI_ENC_LOCK_TIMEOUT     10
#define VASTAI_ENC_LOCK_FLAG_TRUE   1
#define VASTAI_ENC_LOCK_FLAG_FALSE  0

/*------------------------------------------------------------------------
*****************************VCMD CONFIGURATION BY CUSTOMER********************************
-------------------------------------------------------------------------*/
//video encoder vcmd configuration
#define VASTAI_DDR_BASE_ADDRESS             0x800000000//0x30000000

#define VCMD_ENC_IO_ADDR_0                  0x2500000//0x20000   /*customer specify according to own platform*/
#define VCMD_ENC_IO_SIZE_0                  (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_ENC_INT_PIN_0                  -1
#define VCMD_ENC_MODULE_TYPE_0              0
#define VCMD_ENC_MODULE_MAIN_ADDR_0         0x1000	/*customer specify according to own platform*/
#define VCMD_ENC_MODULE_DEC400_ADDR_0       0XFFFF	/*0xffff means no such kind of submodule*/
#define VCMD_ENC_MODULE_L2CACHE_ADDR_0      0XFFFF
#define VCMD_ENC_MODULE_MMU0_ADDR_0         0XFFFF //0X2000
#define VCMD_ENC_MODULE_MMU1_ADDR_0         0XFFFF //0X4000
#define VCMD_ENC_MODULE_AXIFE0_ADDR_0       0XFFFF //0X3000
#define VCMD_ENC_MODULE_AXIFE1_ADDR_0       0XFFFF //0X5000

#define VCMD_ENC_IO_ADDR_1                  0x2600000   /*customer specify according to own platform*/
#define VCMD_ENC_IO_SIZE_1                  (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_ENC_INT_PIN_1                  -1
#define VCMD_ENC_MODULE_TYPE_1              0
#define VCMD_ENC_MODULE_MAIN_ADDR_1         0x1000	/*customer specify according to own platform*/
#define VCMD_ENC_MODULE_DEC400_ADDR_1       0XFFFF	/*0xffff means no such kind of submodule*/
#define VCMD_ENC_MODULE_L2CACHE_ADDR_1      0XFFFF
#define VCMD_ENC_MODULE_MMU_ADDR_1          0XFFFF

#define VCMD_ENC_IO_ADDR_2                  0x2700000   /*customer specify according to own platform*/
#define VCMD_ENC_IO_SIZE_2                  (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_ENC_INT_PIN_2                  -1
#define VCMD_ENC_MODULE_TYPE_2              0
#define VCMD_ENC_MODULE_MAIN_ADDR_2         0x1000	/*customer specify according to own platform*/
#define VCMD_ENC_MODULE_DEC400_ADDR_2       0XFFFF	/*0xffff means no such kind of submodule*/
#define VCMD_ENC_MODULE_L2CACHE_ADDR_2      0XFFFF
#define VCMD_ENC_MODULE_MMU_ADDR_2          0XFFFF

#define VCMD_ENC_IO_ADDR_3                  0x2800000   /*customer specify according to own platform*/
#define VCMD_ENC_IO_SIZE_3                  (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_ENC_INT_PIN_3                  -1
#define VCMD_ENC_MODULE_TYPE_3              0
#define VCMD_ENC_MODULE_MAIN_ADDR_3         0x1000	/*customer specify according to own platform*/
#define VCMD_ENC_MODULE_DEC400_ADDR_3       0XFFFF	/*0xffff means no such kind of submodule*/
#define VCMD_ENC_MODULE_L2CACHE_ADDR_3      0XFFFF
#define VCMD_ENC_MODULE_MMU_ADDR_3          0XFFFF

//video encoder cutree/IM  vcmd configuration


#define VCMD_IM_IO_ADDR_0                   0x2502000//0x22000	/*customer specify according to own platform*/
#define VCMD_IM_IO_SIZE_0                   (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_IM_INT_PIN_0                   -1
#define VCMD_IM_MODULE_TYPE_0               1
#define VCMD_IM_MODULE_MAIN_ADDR_0          0x1000	 /*customer specify according to own platform*/
#define VCMD_IM_MODULE_DEC400_ADDR_0        0XFFFF	 /*0xffff means no such kind of submodule*/
#define VCMD_IM_MODULE_L2CACHE_ADDR_0       0XFFFF
#define VCMD_IM_MODULE_MMU0_ADDR_0          0XFFFF //0X2000
#define VCMD_IM_MODULE_MMU1_ADDR_0          0XFFFF
#define VCMD_IM_MODULE_AXIFE0_ADDR_0        0XFFFF //0X3000
#define VCMD_IM_MODULE_AXIFE1_ADDR_0        0XFFFF // 0XFFFF

#define VCMD_IM_IO_ADDR_1                   0x2602000	/*customer specify according to own platform*/
#define VCMD_IM_IO_SIZE_1                   (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_IM_INT_PIN_1                   -1
#define VCMD_IM_MODULE_TYPE_1               1
#define VCMD_IM_MODULE_MAIN_ADDR_1          0x1000	 /*customer specify according to own platform*/
#define VCMD_IM_MODULE_DEC400_ADDR_1        0XFFFF	 /*0xffff means no such kind of submodule*/
#define VCMD_IM_MODULE_L2CACHE_ADDR_1       0XFFFF
#define VCMD_IM_MODULE_MMU_ADDR_1           0XFFFF

#define VCMD_IM_IO_ADDR_2                   0x2702000	/*customer specify according to own platform*/
#define VCMD_IM_IO_SIZE_2                   (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_IM_INT_PIN_2                   -1
#define VCMD_IM_MODULE_TYPE_2               1
#define VCMD_IM_MODULE_MAIN_ADDR_2          0x1000	 /*customer specify according to own platform*/
#define VCMD_IM_MODULE_DEC400_ADDR_2        0XFFFF	 /*0xffff means no such kind of submodule*/
#define VCMD_IM_MODULE_L2CACHE_ADDR_2       0XFFFF
#define VCMD_IM_MODULE_MMU_ADDR_2           0XFFFF

#define VCMD_IM_IO_ADDR_3                   0x2802000	/*customer specify according to own platform*/
#define VCMD_IM_IO_SIZE_3                   (ASIC_VCMD_SWREG_AMOUNT * 4)	/* bytes */
#define VCMD_IM_INT_PIN_3                   -1
#define VCMD_IM_MODULE_TYPE_3               1
#define VCMD_IM_MODULE_MAIN_ADDR_3          0x1000	 /*customer specify according to own platform*/
#define VCMD_IM_MODULE_DEC400_ADDR_3        0XFFFF	 /*0xffff means no such kind of submodule*/
#define VCMD_IM_MODULE_L2CACHE_ADDR_3       0XFFFF
#define VCMD_IM_MODULE_MMU_ADDR_3           0XFFFF

#define VASTAI_ENC_MAX_CORES                (4)
#define VCMD_ENC_DDR_SIZE                   (1024 * 1024 * 9)
#define VCMD_ENC_DDR_BASE_ADDR_0            (0x818000000)
//#define VCMD_ENC_DDR_BASE_ADDR_1			(VCMD_ENC_DDR_BASE_ADDR_0 + VCMD_ENC_DDR_SIZE)
//#define VCMD_ENC_DDR_BASE_ADDR_2			(VCMD_ENC_DDR_BASE_ADDR_1 + VCMD_ENC_DDR_SIZE)
//#define VCMD_ENC_DDR_BASE_ADDR_3			(VCMD_ENC_DDR_BASE_ADDR_3 + VCMD_ENC_DDR_SIZE)

static struct vcmd_config vcmd_core_array[]= {
	//encoder configuration
	{VCMD_ENC_IO_ADDR_0,
	VCMD_ENC_IO_SIZE_0,
	VCMD_ENC_INT_PIN_0,
	VCMD_ENC_MODULE_TYPE_0,
	VCMD_ENC_MODULE_MAIN_ADDR_0,
	VCMD_ENC_MODULE_DEC400_ADDR_0,
	VCMD_ENC_MODULE_L2CACHE_ADDR_0,
	VCMD_ENC_MODULE_MMU0_ADDR_0,
	VCMD_ENC_MODULE_MMU1_ADDR_0,
	VCMD_ENC_MODULE_AXIFE0_ADDR_0,
	VCMD_ENC_MODULE_AXIFE1_ADDR_0},

	{VCMD_ENC_IO_ADDR_1,
	VCMD_ENC_IO_SIZE_1,
	VCMD_ENC_INT_PIN_1,
	VCMD_ENC_MODULE_TYPE_1,
	VCMD_ENC_MODULE_MAIN_ADDR_1,
	VCMD_ENC_MODULE_DEC400_ADDR_1,
	VCMD_ENC_MODULE_L2CACHE_ADDR_1,
	VCMD_ENC_MODULE_MMU_ADDR_1},

	{VCMD_ENC_IO_ADDR_2,
	VCMD_ENC_IO_SIZE_2,
	VCMD_ENC_INT_PIN_2,
	VCMD_ENC_MODULE_TYPE_2,
	VCMD_ENC_MODULE_MAIN_ADDR_2,
	VCMD_ENC_MODULE_DEC400_ADDR_2,
	VCMD_ENC_MODULE_L2CACHE_ADDR_2,
	VCMD_ENC_MODULE_MMU_ADDR_2},

	{VCMD_ENC_IO_ADDR_3,
	VCMD_ENC_IO_SIZE_3,
	VCMD_ENC_INT_PIN_3,
	VCMD_ENC_MODULE_TYPE_3,
	VCMD_ENC_MODULE_MAIN_ADDR_3,
	VCMD_ENC_MODULE_DEC400_ADDR_3,
	VCMD_ENC_MODULE_L2CACHE_ADDR_3,
	VCMD_ENC_MODULE_MMU_ADDR_3},

	//cutree/IM configuration
	{VCMD_IM_IO_ADDR_0,
	VCMD_IM_IO_SIZE_0,
	VCMD_IM_INT_PIN_0,
	VCMD_IM_MODULE_TYPE_0,
	VCMD_IM_MODULE_MAIN_ADDR_0,
	VCMD_IM_MODULE_DEC400_ADDR_0,
	VCMD_IM_MODULE_L2CACHE_ADDR_0,
	VCMD_IM_MODULE_MMU0_ADDR_0,
	VCMD_IM_MODULE_MMU1_ADDR_0,
	VCMD_IM_MODULE_AXIFE0_ADDR_0,
	VCMD_IM_MODULE_AXIFE1_ADDR_0},

	{VCMD_IM_IO_ADDR_1,
	VCMD_IM_IO_SIZE_1,
	VCMD_IM_INT_PIN_1,
	VCMD_IM_MODULE_TYPE_1,
	VCMD_IM_MODULE_MAIN_ADDR_1,
	VCMD_IM_MODULE_DEC400_ADDR_1,
	VCMD_IM_MODULE_L2CACHE_ADDR_1,
	VCMD_IM_MODULE_MMU_ADDR_1},

	{VCMD_IM_IO_ADDR_2,
	VCMD_IM_IO_SIZE_2,
	VCMD_IM_INT_PIN_2,
	VCMD_IM_MODULE_TYPE_2,
	VCMD_IM_MODULE_MAIN_ADDR_2,
	VCMD_IM_MODULE_DEC400_ADDR_2,
	VCMD_IM_MODULE_L2CACHE_ADDR_2,
	VCMD_IM_MODULE_MMU_ADDR_2},

	{VCMD_IM_IO_ADDR_3,
	VCMD_IM_IO_SIZE_3,
	VCMD_IM_INT_PIN_3,
	VCMD_IM_MODULE_TYPE_3,
	VCMD_IM_MODULE_MAIN_ADDR_3,
	VCMD_IM_MODULE_DEC400_ADDR_3,
	VCMD_IM_MODULE_L2CACHE_ADDR_3,
	VCMD_IM_MODULE_MMU_ADDR_3},
};

static struct class *encode_drv_class;

static int hantroenc_major = 0;
static int total_vcmd_core_num = 0;

static u32 dwProbeInit = 0;

struct list_head device_list_head;

static int vastai_pci_enc_callback(void *pci_dev, u32 die_index, int irq, void *die_info, void *mcu_msg);
static void clean_cmdbuf_obj(struct cmdbuf_obj* cmdbuf_obj, u32 cmdbuf_id, struct die_enc_info* die);

static int wait_alloc_channel_unlock(struct file *filp, u32 die_index);

static int wait_alloc_channel_lock(struct file *filp, u32 die_index)
{
	struct list_head *p = NULL, *n = NULL;
	device_handle_t *device_handle_node = NULL;
	int locked = 0;
	int counter = 0;
	int ret = 0;

	list_for_each_safe (p, n, &device_list_head) {
		device_handle_node = list_entry(p, device_handle_t, node);
		if (die_index == device_handle_node->die.die_index) {

			mutex_lock(&device_handle_node->device_mutex);

			if (device_handle_node->timestamp != 0
			  || (device_handle_node->timestamp == 0 && device_handle_node->die.venc_chanl_locked==VASTAI_ENC_LOCK_FLAG_FALSE)) {
				ktime_t current_time = ktime_get_seconds();
				if (current_time - device_handle_node->timestamp > 5) {
					VAVIDEO_INFO(device_handle_node->die.priv_dev,
						(u8)(device_handle_node->die.die_index),
						"unlock the zomb thread lock\n");
					device_handle_node->die.venc_chanl_locked = VASTAI_ENC_LOCK_FLAG_TRUE;
					mutex_unlock(&device_handle_node->chan_alloc_mutex);
					device_handle_node->timestamp = 0;
                    device_handle_node->lock_filp = 0;
				}
			}

			mutex_unlock(&device_handle_node->device_mutex);

			do {
				locked = mutex_trylock(
					&device_handle_node->chan_alloc_mutex);
				if (!locked) {
					ret = wait_event_interruptible_timeout(device_handle_node->die.venc_alloc_channel_wait, device_handle_node->die.venc_chanl_locked, msecs_to_jiffies(VASTAI_ENC_LOCK_TIMEOUT));
					if(ret == 0) {
						//VAVIDEO_INFO(device_handle_node->die.priv_dev, (u8)device_handle_node->die.die_index, "wait alloc channel timeout once, try again\n");
						counter++;
					} else if(ret < 0) {
						VAVIDEO_ERR(device_handle_node->die.priv_dev, (u8)device_handle_node->die.die_index, "wait alloc channel interrupted: %d\n", ret);
						return -1;
					}
				} else {
					device_handle_node->timestamp = ktime_get_seconds();
                    device_handle_node->lock_filp = filp;
					device_handle_node->die.venc_chanl_locked = VASTAI_ENC_LOCK_FLAG_FALSE;
				}

				if (counter == 100000) {
					VAVIDEO_ERR(device_handle_node->die.priv_dev,
							(u8)(device_handle_node->die.die_index),
							"pid[%d] hantroenc: "
							"die_index:%x failed "
							"to lock, timeout\n",
					       current->pid, die_index);
					return -1;
				}
			} while (!locked);

		}
	}

	return 0;
}

static int wait_alloc_channel_unlock(struct file *filp, u32 die_index)
{
	struct list_head *p = NULL, *n = NULL;
	device_handle_t *device_handle_node = NULL;

	list_for_each_safe (p, n, &device_list_head) {
		device_handle_node = list_entry(p, device_handle_t, node);
		if (die_index == device_handle_node->die.die_index) {

			mutex_lock(&device_handle_node->device_mutex);
			device_handle_node->timestamp = 0;
            device_handle_node->lock_filp = 0;
			mutex_unlock(&device_handle_node->device_mutex);

			device_handle_node->die.venc_chanl_locked = VASTAI_ENC_LOCK_FLAG_TRUE;
			mutex_unlock(&device_handle_node->chan_alloc_mutex);
			wake_up_interruptible_sync(&device_handle_node->die.venc_alloc_channel_wait);


			return 0;
		}
	}
	VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
	       "pid[%d] hantroenc: can not find lock to release\n",
	       current->pid);
	return -1;
}

int vastai_video_enc_reset_handler(u32 die_index, u32 core_bit, reset_event event)
{
	struct list_head *p = NULL, *n = NULL;
	device_handle_t *device_handle_node = NULL;
	struct die_enc_info* die = NULL;
	//struct enc_chn_info *info = NULL;
	int recover_core_num = 0;
	int core_id = 0;
	//int index = 0, core_index = 0;

	list_for_each_safe (p, n, &device_list_head) {
		device_handle_node = list_entry(p, device_handle_t, node);
		if (die_index == device_handle_node->die.die_index) {
			die = &device_handle_node->die;
			break;
		}
	}

	if (!die) {
		VAVIDEO_ERR(NULL, (u8)(die_index),
			"%s: device crash not found die for die_index=0x%x\n", __func__, die_index);
		return -1;
	}

	switch (core_bit)
	{
		case CORE_POINT_VEMCU0:
		case CORE_POINT_VEMCU1:
		case CORE_POINT_VEMCU2:
		case CORE_POINT_VEMCU3:
		{
			recover_core_num = 1;
			core_id = core_bit % CORE_POINT_VEMCU0;
			if (RESET_END == event) {
				die->reset_end_bitmap |= 1 << core_id;
				return 0;
			}

			break;
		}

		case CORE_TOTAL_NUM:
		{
			recover_core_num = VASTAI_MAX_ENC_CORES;
			core_id = 0;
			if (RESET_END == event) {
				die->reset_end_bitmap |= 0xf;
				return 0;
			}

			break;
		}

		default:
		{
			return 0;
		}

	}

	if (die->encoder_mode == SINGLE_CORE_MODE) {
#if 0
		for (core_index = 0; core_index < recover_core_num; core_index++) {

			for (index = 0; index < VASTAI_MAX_CORE_CHANNEL; index++) {

				info = &(die->venc_core_info[core_id + core_index].enc_chn_set[index]);

				if (info) {
					info->core_id = 0;
					info->die_index = 0;
					info->instance_addr = 0;
					info->msg_addr = 0;
				}

			}

		}

		VAVIDEO_INFO(die->priv_dev, (u8)(die->die_index),
			"%s: device crash die_index=0x%x, release channel info success!\n", __func__, die->die_index);
#endif
	} else if (die->encoder_mode == MULTI_CORE_MODE) {

		u32 cmdbuf_id = 0, release_cmdbuf_num = 0;
		struct cmdbuf_obj* cmdbuf_obj_temp = NULL;

		for (cmdbuf_id = 0; cmdbuf_id < TOTAL_DISCRETE_CMDBUF_NUM; cmdbuf_id++) {
			cmdbuf_obj_temp = &(die->cmdbuf_obj_sets[cmdbuf_id]);
				clean_cmdbuf_obj(cmdbuf_obj_temp, cmdbuf_id, die);
				release_cmdbuf_num++;
		}
		VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
			"%s released %d cmdbuf\n", __func__, release_cmdbuf_num);

	} else {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s: error encode mode, return\n", __func__);
		return -1;
	}

	return 0;
}


static struct enc_chn_info *get_enc_chn_info(struct file *filp)
{
	struct enc_chn_info *info;
	struct vastai_video_info *video_info;

	if (!strncmp(filp->f_path.dentry->d_iname, VC8000, sizeof(VC8000) - 1)) {
		info = (struct enc_chn_info *)filp->private_data;

	} else {
		video_info = (struct vastai_video_info *)filp->private_data;
		info = video_info->enc_info;
	}

	return info;
}

static void vcmd_workqueue_schedue(struct work_struct *work)
{
	struct die_enc_info *die = container_of(work, struct die_enc_info, work);

	unsigned int handled = 0;
	struct cmdbuf_obj* cmdbuf_obj = NULL;
	u32 cmdbuf_id = 0;
	u32 status = 0, ret = 0;
	u32 cmdbuf_processed_num = 0;
	multivemcu_to_host_msg_t *mcu_msg = NULL;

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"%s: venc Enter, die_index=0x%x\n", __func__, die->die_index);

	while (ret == 0) {

		ret = vastai_cmdid_dequeue(&die->cmdbufId_queue, &cmdbuf_id, &status, NULL, NULL);
		if (ret) {
			break;
		}

		VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
			"venc out-fifo: die_index=0x%x cmdbuf_id=%d status=0x%x \n", die->die_index, cmdbuf_id, status);

		if (cmdbuf_id) {
			if (cmdbuf_id >= TOTAL_DISCRETE_CMDBUF_NUM) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"venc error, die_inidex=%d, cmdbuf_id %d greater than the ceiling !!\n", die->die_index, cmdbuf_id);
				continue;
			}

			cmdbuf_obj = &die->cmdbuf_obj_sets[cmdbuf_id];

			if (cmdbuf_obj == NULL) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"venc error, die_inidex=%d, cmdbuf_id %d cmdbuf_obj is NULL !!\n", die->die_index, cmdbuf_id);
				continue;
			}

			mcu_msg = &die->mcu_msg[cmdbuf_id];
			if (mcu_msg == NULL) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"venc error, die_inidex=%d, cmdbuf_id %d mcu_msg is NULL !!\n", die->die_index, cmdbuf_id);
				continue;
			}

			cmdbuf_obj->core_id = mcu_msg->core_id;
			cmdbuf_obj->executing_status = mcu_msg->encstate;

			if (die->cmdbuf_used[cmdbuf_id] == 1) {
				cmdbuf_obj->cmdbuf_run_done = 1;
				cmdbuf_processed_num++;
			}

			handled++;

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc one cmdbuf_id done: die_index=0x%x core_id=%d cmdbuf_id=%d status=0x%x \n", die->die_index, mcu_msg->core_id, cmdbuf_id,status);

		}
	}

	if (!handled) {
		VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index), "venc IRQ received, but not process!\n");
	}

	if (cmdbuf_processed_num)
		wake_up_interruptible_all(&die->wait_queue);

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"venc work_queue-done:  die_index=0x%x, handled = %d\n", die->die_index, handled);
}

static int allocate_cmdbuf(struct die_enc_info *die, struct noncache_mem* new_cmdbuf_addr, struct noncache_mem* new_status_cmdbuf_addr, struct exchange_parameter* input_para)
{
	u16 i = 0;

	mutex_lock(&die->mutex);

	if (input_para->module_type == 0) {

		if (die->cmdbuf_used_residual == 0) {
			mutex_unlock(&die->mutex);
			//no empty cmdbuf
			return 0;
		}
		//there is one cmdbuf at least
		while (1) {
			i = die->cmdbuf_used_pos;
			if (die->cmdbuf_used[i] == 0) {

				die->cmdbuf_used[i] = 1;
				die->cmdbuf_used_residual -=1;

				new_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
				new_cmdbuf_addr->cmdbuf_id = i;

				new_cmdbuf_addr->busAddress = die->vcmd_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
				new_cmdbuf_addr->mmu_bus_address = die->vcmd_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->busAddress = die->vcmd_status_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->mmu_bus_address = die->vcmd_status_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;

				new_status_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->cmdbuf_id = i;
				die->cmdbuf_used_pos++;

				if (die->cmdbuf_used_pos >= TOTAL_DISCRETE_CMDBUF_NUM - IM_CMDBUF_NUM)
					die->cmdbuf_used_pos=0;

				mutex_unlock(&die->mutex);

				return 1;
			} else {
				die->cmdbuf_used_pos++;
				if(die->cmdbuf_used_pos >= TOTAL_DISCRETE_CMDBUF_NUM - IM_CMDBUF_NUM)
					die->cmdbuf_used_pos=0;
			}
		}

	} else if (input_para->module_type == 1) {
		if (die->cmdbuf_used_residual_im == 0) {
			mutex_unlock(&die->mutex);
			//no empty cmdbuf
			return 0;
		}
		//there is one cmdbuf at least
		while (1) {
			i = die->cmdbuf_used_pos_im;
			if (die->cmdbuf_used[i] == 0) {

				die->cmdbuf_used[i] = 1;
				die->cmdbuf_used_residual_im -=1;

				new_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
				new_cmdbuf_addr->cmdbuf_id = i;

				new_cmdbuf_addr->busAddress = die->vcmd_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
				new_cmdbuf_addr->mmu_bus_address = die->vcmd_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->busAddress = die->vcmd_status_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->mmu_bus_address = die->vcmd_status_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;

				new_status_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
				new_status_cmdbuf_addr->cmdbuf_id = i;
				die->cmdbuf_used_pos_im++;

				if (die->cmdbuf_used_pos_im >= TOTAL_DISCRETE_CMDBUF_NUM)
					die->cmdbuf_used_pos_im = TOTAL_DISCRETE_CMDBUF_NUM -  IM_CMDBUF_NUM + 1;

				mutex_unlock(&die->mutex);

				return 1;
			} else {
				die->cmdbuf_used_pos_im++;
				if(die->cmdbuf_used_pos_im >= TOTAL_DISCRETE_CMDBUF_NUM)
					die->cmdbuf_used_pos_im = TOTAL_DISCRETE_CMDBUF_NUM -  IM_CMDBUF_NUM + 1;
			}
		}

	}

	return 0;
}

static struct cmdbuf_obj* create_cmdbuf_obj(struct die_enc_info *die, struct exchange_parameter* input_para)
{
	/* bi_list_node* current_node=NULL; */
	struct cmdbuf_obj* cmdbuf_obj = NULL;
	struct noncache_mem  new_cmdbuf_addr = {0};
	struct noncache_mem  new_status_cmdbuf_addr = {0};
	u16 get_cmdbuf_id = -1;

	if(wait_event_interruptible_exclusive(die->vcmd_cmdbuf_memory_wait, allocate_cmdbuf(die, &new_cmdbuf_addr, &new_status_cmdbuf_addr, input_para)))
		return NULL;
	get_cmdbuf_id = new_cmdbuf_addr.cmdbuf_id;

	cmdbuf_obj = &(die->cmdbuf_obj_sets[get_cmdbuf_id]);
	cmdbuf_obj->cmdbuf_busAddress = new_cmdbuf_addr.busAddress;
	cmdbuf_obj->cmdbuf_size = new_cmdbuf_addr.size;
	cmdbuf_obj->cmdbuf_id = new_cmdbuf_addr.cmdbuf_id;
	cmdbuf_obj->status_busAddress = new_status_cmdbuf_addr.busAddress;
	cmdbuf_obj->status_size = new_status_cmdbuf_addr.size;

	return cmdbuf_obj;
}

static long reserve_cmdbuf(struct file *filp, struct die_enc_info *die, struct exchange_parameter* input_para)
{
	struct cmdbuf_obj* cmdbuf_obj=NULL;
	input_para->cmdbuf_id = 0;
	input_para->core_id = 0; //for multicore mode, not need core id when reserve cmdbuf

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"venc reserve cmdbuf filp %p, module_type=%d\n", (void *)filp, input_para->module_type);

	cmdbuf_obj = create_cmdbuf_obj(die, input_para);
	if (cmdbuf_obj == NULL) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s: core[%d] create_cmdbuf_obj failed \n", __func__, input_para->core_id);
		return -1;
	}

	cmdbuf_obj->module_type = input_para->module_type;
	cmdbuf_obj->priority = input_para->priority;
	cmdbuf_obj->executing_time = input_para->executing_time;
	cmdbuf_obj->cmdbuf_size = CMDBUF_MAX_SIZE;
	cmdbuf_obj->core_id = 0;
	cmdbuf_obj->cmdbuf_run_done = 0;
	cmdbuf_obj->filp = filp;

	input_para->cmdbuf_id = cmdbuf_obj->cmdbuf_id;

	return 0;
}

static void set_enc_chn_info(struct file *filp, struct enc_chn_info *info)
{
	if (!strncmp(filp->f_path.dentry->d_iname, VC8000, sizeof(VC8000) - 1)) {
		filp->private_data = info;

	} else {
		struct vastai_video_info *video_info;

		video_info = (struct vastai_video_info *)filp->private_data;
		video_info->enc_info = info;
	}
}

static long link_and_run_cmdbuf(struct file *filp, struct exchange_parameter* input_para, struct die_enc_info *die_info)
{
	struct cmdbuf_obj* cmdbuf_obj=NULL;
	struct vastai_pci_info *pcie_dev = (struct vastai_pci_info *)die_info->priv_dev;
	int ret = -1;
	struct vastai_dmadesc *dma_buf = NULL;
	union core_bitmap triger_core = {{0}};
	u16 cmdbuf_id = input_para->cmdbuf_id;
	//u16 core_id = input_para->core_id;
	host_to_vemcu_msg_t msg;
	int retry;

	VAVIDEO_DBG(pcie_dev, (u8)(die_info->die_index),
				"cmdbuf_id=%d, module_type=%d, vcmdbuf_src_addr=%llx, vcmdbuf_dst_addr=0x%llx, cmdbuf_size=%d\n", cmdbuf_id, input_para->module_type,
				input_para->vcmdbuf_desc.vcmdbuf_src_addr,
				input_para->vcmdbuf_desc.vcmdbuf_dst_addr, input_para->vcmdbuf_desc.vcmd_size);

	cmdbuf_obj = &(die_info->cmdbuf_obj_sets[cmdbuf_id]);

	if (cmdbuf_obj->filp != filp) {
		VAVIDEO_ERR(pcie_dev, (u8)(die_info->die_index),
				"%s:%d venc vastaivcmd: ERROR cmdbuf_id !!\n", __func__, __LINE__);
		return -1;
	}

	cmdbuf_obj->cmdbuf_data_loaded = 1;
	cmdbuf_obj->cmdbuf_size = input_para->cmdbuf_size;
	cmdbuf_obj->waited = 0;

	#ifdef VCMD_DEBUG_INTERNAL
	{
		u32 i, inst = 0, size = 0, ptr = 0;
		VAVIDEO_INFO(pcie_dev, (u8)(die_info->die_index), "vcmd link, current cmdbuf content\n");
		for(i=0;i<cmdbuf_obj->cmdbuf_size/4;i++)
		{
			__get_user(inst, (u32*)input_para->vcmdbuf_desc.vcmdbuf_src_addr + i);
			if (i == ptr) {
			PrintInstr(i, inst, &size);
			ptr += size;
			} else {
			VAVIDEO_INFO(pcie_dev, (u8)(die_info->die_index),"current cmdbuf data %d = 0x%x\n",i, inst);;
			}
		}
	}
	#endif

	cmdbuf_obj->has_end_cmdbuf = 0; //0: has jmp opcode,1 has end code
	cmdbuf_obj->no_normal_int_cmdbuf = 1; //0: interrupt when JMP,1 not interrupt when JMP
	cmdbuf_obj->cmdbuf_User_virtualAddress = (u32*)(input_para->vcmdbuf_desc.vcmdbuf_src_addr);

	dma_buf = kmalloc(sizeof(struct vastai_dmadesc), GFP_KERNEL);
	//triger_core.decode = BIT(input_para->core_id);
	dma_buf[VCMD].is_src_not_user_mem = 0;
	dma_buf[VCMD].is_src_dma_addr = 0;
	dma_buf[VCMD].is_host_to_dev = 1;
	dma_buf[VCMD].host_addr.vir_addr = (void*)(input_para->vcmdbuf_desc.vcmdbuf_src_addr);
	dma_buf[VCMD].dev_addr = cmdbuf_obj->cmdbuf_busAddress;
	dma_buf[VCMD].dma_lenth = cmdbuf_obj->cmdbuf_size;

	retry = 5;
	while(ret && retry) {
		ret = vastai_pci_dma_transfer_sync(pcie_dev,  die_info->die_index, triger_core, dma_buf, 1, -1);
		if (ret != 0) {
			if (ret == -EBUSY) {
				VAVIDEO_INFO(pcie_dev, (u8)(die_info->die_index),
					"warning vastai_pci_dma_transfer_sync: ret = %d !!\n", ret);
				mdelay(200);
				retry--;
			} else {
				VAVIDEO_ERR(pcie_dev, (u8)(die_info->die_index),
					"error vastai_pci_dma_transfer_sync: ret = %d !!\n", ret);
				kfree(dma_buf);
                return ret;
			}
		}
	}

	kfree(dma_buf);

	msg.magic = VENC_MAGIC_NUMBER;
	msg.cmdbuf_id = input_para->cmdbuf_id;
	msg.cmdbuf_len = input_para->cmdbuf_size;
	msg.module_type = input_para->module_type;
	msg.executing_time = cmdbuf_obj->executing_time;
#if 1
	mutex_lock(&die_info->vastai_fifo_mutex);
	ret = vastai_fifo_push_elem(pcie_dev, die_info->die_index, HOST_VEMCU0_MSG_ADDR, &msg, NULL);
	if (ret) {
		VAVIDEO_ERR(pcie_dev, (u8)(die_info->die_index),
			"%s: venc write ring buffer failed!!! ret=%d, die_index=0x%x, cmdbuf_id=%d, module_type=%d\n",
			__func__, ret, die_info->die_index, input_para->cmdbuf_id, input_para->module_type);
	}
	mutex_unlock(&die_info->vastai_fifo_mutex);
#endif
	return ret;
}

static void free_cmdbuf_mem(struct die_enc_info *die, u32 cmdbuf_id)
{
	mutex_lock(&die->mutex);
	die->cmdbuf_used[cmdbuf_id] = 0;
	if (die->cmdbuf_obj_sets[cmdbuf_id].module_type == 0)
		die->cmdbuf_used_residual += 1;
	else if (die->cmdbuf_obj_sets[cmdbuf_id].module_type == 1)
		die->cmdbuf_used_residual_im += 1;
	mutex_unlock(&die->mutex);
	wake_up_interruptible_sync(&die->vcmd_cmdbuf_memory_wait);
}

static void clean_cmdbuf_obj(struct cmdbuf_obj* cmdbuf_obj, u32 cmdbuf_id, struct die_enc_info* die)
{
	if (cmdbuf_obj == NULL) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s\n","remove_cmdbuf_node NULL");
		return;
	}

	cmdbuf_obj->cmdbuf_need_remove = 1;
	cmdbuf_obj->cmdbuf_busAddress = 0;
	cmdbuf_obj->cmdbuf_size = 0;
	cmdbuf_obj->cmdbuf_id = -1;
	cmdbuf_obj->status_busAddress = 0;
	cmdbuf_obj->status_size = 0;
	//cmdbuf_obj->module_type = -1;
	cmdbuf_obj->core_id = -1;
	cmdbuf_obj->filp = NULL;
	cmdbuf_obj->cmdbuf_run_done = 0;
//	cmdbuf_obj->cmdbuf_done_flag = 0;

	free_cmdbuf_mem(die, cmdbuf_id);
	return;
}

static long release_cmdbuf(struct file *filp, u16 cmdbuf_id, struct die_enc_info* die)
{
	struct cmdbuf_obj* cmdbuf_obj=NULL;
	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"%s: die_index=0x%x, cmdbuf_id=%d\n", __func__, die->die_index, cmdbuf_id);

	cmdbuf_obj = &(die->cmdbuf_obj_sets[cmdbuf_id]);
	if (cmdbuf_obj->filp!=filp) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s: venc invalid param, die_index=0x%x, cmdbuf_id=%d!!\n",
			__func__, die->die_index, cmdbuf_obj->cmdbuf_id);
		return -1;
	}

	clean_cmdbuf_obj(cmdbuf_obj, cmdbuf_id, die);

	return 0;
}

static int check_cmdbuf_irq(struct cmdbuf_obj* cmdbuf_obj)
{
  int rdy = 0;
  if(cmdbuf_obj->cmdbuf_run_done != 0)
  {
	rdy = 1;
	cmdbuf_obj->cmdbuf_run_done = 0;
  }
  return rdy;
}

static int wait_cmdbuf_ready(struct file *filp,  struct die_enc_info* die, u32 cmdbuf_id)
{
	struct cmdbuf_obj* cmdbuf_obj = NULL;
	int ret = -1;

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"%s: die_index=0x%x, cmdbuf_id=%d, HZ=%d\n", __func__, die->die_index, cmdbuf_id, HZ);

	if (cmdbuf_id != ANY_CMDBUF_ID) {

		if (cmdbuf_id >= TOTAL_DISCRETE_CMDBUF_NUM) {
			VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
				"venc vastaivcmd:%s:%s:%d invalid cmdbuf_id=%d !!\n",
				__FILE__, __func__, __LINE__, cmdbuf_id);
			return -1;
		}

		cmdbuf_obj = &(die->cmdbuf_obj_sets[cmdbuf_id]);
		if(cmdbuf_obj->filp != filp) {
			VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
				"venc vastaivcmd:%s:%s:%d ERROR cmdbuf_id=%d !!\n",
				__FILE__, __func__, __LINE__, cmdbuf_id);
			return -1;
		}

		ret = wait_event_interruptible(die->wait_queue, check_cmdbuf_irq(cmdbuf_obj));
		if (ret < 0) {
			VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
				"venc vcmd_wait_queue interrupted, die_index=0x%x, cmdbuf_id=%d\n",
				die->die_index, cmdbuf_id);
			//mutex_lock(&die->mutex);
			//mutex_lock(&die->mutex);
			return -1;
		}

		VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"%s: venc return,ret=%d, die_index=0x%x, cmdbufid=%d, core_id=%d, status=%d\n",
				 __func__, ret, die->die_index, cmdbuf_id, die->mcu_msg[cmdbuf_id].core_id, die->mcu_msg[cmdbuf_id].encstate);

		return 0;
	}

	return -1;

}

long hantroenc_ioctl(struct file *filp,
						  unsigned int cmd, unsigned long arg)
{
	struct device_handle *enc_device_handle;
	struct die_enc_info *die;
	struct vastai_video_info *video_info;

	VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
		"%s: filp=%p, ioctl cmd 0x%x\n", __func__, filp, cmd);

	/*
	 * extract the type and number bitfields, and don't encode
	 * wrong cmds: return ENOTTY (inappropriate ioctl) before access_ok()
	 */
	if(_IOC_TYPE(cmd) != VASTAI_ENC_IOC_MAGIC)
		return -ENOTTY;
	if((_IOC_TYPE(cmd) == VASTAI_ENC_IOC_MAGIC &&
		_IOC_NR(cmd) > VASTAI_ENC_IOC_MAXNR)
		)
		return -ENOTTY;

	/*
	 * the direction is a bitmask, and VERIFY_WRITE catches R/W
	 * transfers. `Type' is user-oriented, while
	 * access_ok is kernel-oriented, so the concept of "read" and
	 * "write" is reversed
	 */

	video_info = (struct vastai_video_info *)filp->private_data;
	enc_device_handle = video_info->enc_device_handle;
	die = &enc_device_handle->die;

	switch (cmd)
	{
		case VASTAI_ENC_IOCH_GET_DIE_ID:
		{
			int tmp = -1;

			tmp = video_copy_to_user((u32 *)arg, &(die->die_index), sizeof(int));
			if (tmp) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"copy_to_user failed, returned %d\n", tmp);
				return -EFAULT;
			}
			break;
		}

		case VASTAI_ENC_IOCH_INT_VEMCU:
		{
			TIntVEMCU tVemcuIntParam = {0};
			u64 qwAddr = 0;
			int ret;
			ret=video_copy_from_user(&tVemcuIntParam, (void*)arg, sizeof(TIntVEMCU));
			//printk("triger dieid %d core %d , addr %x val %x \n",tVemcuIntParam.dwDieId, tVemcuIntParam.dwCoreId, tVemcuIntParam.dwCsrAddr, tVemcuIntParam.dwVal);
			if(tVemcuIntParam.dwCoreId >= 0 && tVemcuIntParam.dwCoreId <= 3 && (tVemcuIntParam.dwCsrAddr & 0xffff0000) == 0x8bc0000)
			{
				struct vastai_pci_info *pcie_dev = get_vastai_pci_device_info(tVemcuIntParam.dwDeviceId);
				qwAddr = (u64)(tVemcuIntParam.dwCsrAddr);
				return vastai_pci_mem_write(pcie_dev, tVemcuIntParam.dwDieId, qwAddr, &tVemcuIntParam.dwVal, sizeof(int));
			}
			else
			{
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"VASTAI_ENC_IOCH_INT_VEMCU error \n");
				return -1;
			}

			break;
		}

		case VASTAI_ENC_IOCH_ALLOCCHANNEL_LOCK:
		{
			u32 die_index;
			//__get_user(die_index, (u32*)arg);
            int ret;
     		ret = video_copy_from_user(&die_index, (u32*)arg, sizeof(die_index));

            //printk("ALLOCCHANNEL_LOCK die_index %x\nj", die_index);

			if (wait_alloc_channel_lock(filp, die_index) != 0) {
				return -1;
			}

			break;
		}

		case VASTAI_ENC_IOCH_ALLOCCHANNEL_UNLOCK:
		{
			u32 die_index;
			//__get_user(die_index, (u32*)arg);
            int ret;
     		ret = video_copy_from_user(&die_index, (u32*)arg, sizeof(die_index));
            //printk("ALLOCCHANNEL_UNLOCK die_index %x\n", die_index);

			if (wait_alloc_channel_unlock(filp, die_index) != 0) {
				return -1;
			}

			break;
		}

		case VASTAI_ENC_IOCH_ATTACH_VENCCHNL:
		{
			struct list_head *p = NULL, *n = NULL;
			device_handle_t *device_handle_node = NULL;
			//struct die_enc_info* die = 0;
			venc_msg_chninfo_t chninfo = {0};
			u32 core_id;
			u32 die_index;
			u32 jobidx;

			struct enc_chn_info *info;

			info = get_enc_chn_info(filp);
			if (info != 0)
			{
				VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
					"chn is exist,to destry die idx:%d core:%d\n",info->die_index,info->core_id);
				//if (!list_empty(&info->node))
				//	list_del(&info->node);

//				kfree(info->rcv);
				info->core_id = 0;
				info->die_index = 0;
				info->instance_addr = 0;
				info->msg_addr = 0;
//				info->rcv = 0;
			}

			if (video_copy_from_user(&chninfo, (void*)arg, sizeof(venc_msg_chninfo_t)))
				return -2;

			core_id = chninfo.core_id>>16;
			jobidx = chninfo.core_id&0xFF;
			die_index = chninfo.die_index;
			list_for_each_safe(p, n, &device_list_head) {
				device_handle_node = list_entry(p, device_handle_t, node);
				if (die_index == device_handle_node->die.die_index)
				{
					die = &device_handle_node->die;
				}
			}

			if (die == 0 || core_id>= VASTAI_MAX_ENC_CORES || jobidx>= VASTAI_MAX_CORE_CHANNEL)
				return -3;

			//info = kzalloc(sizeof(struct enc_chn_info), GFP_KERNEL);
			//if (!info)
			//	return -4;

			info = &(die->venc_core_info[core_id].enc_chn_set[jobidx]);

			if (info->instance_addr) {
				VAVIDEO_INFO(die->priv_dev, (u8)(die->die_index),
					"die idx:%x core:%d chn instance=%x is exist,return\n",
					info->die_index, info->core_id, info->instance_addr);
				return -1;
			}

			set_enc_chn_info(filp, info);
			init_waitqueue_head(&info->wait_queue);
			info->core_id	= core_id;
			info->die_index = die->die_index;
			info->instance_addr = chninfo.instance_addr;
			info->msg_addr = 0;//(u64)(0x800000000|chninfo.msg_addr);
			info->event = 0;
#if 0
			if(info->rcv)
				kfree(info->rcv);
			info->rcv = (struct vastai_fifo*)kzalloc(4096, GFP_KERNEL);
			memset(info->rcv, 0, 4096);
			max_msg_num = (4096 - sizeof(struct vastai_fifo)) / sizeof(vemcu_to_host_msg_t);
			info->rcv->elem_count = max_msg_num;
			info->rcv->elem_size = sizeof(vemcu_to_host_msg_t);
#endif
			//printk("ioctl cmd   %x----insaddr:%x---%d---%d\n",chninfo.msg_addr,chninfo.instance_addr,die_index,core_id);
			//list_add_tail(&info->node, &(die->venc_core_info[core_id].enc_chn_head));
			break;
		}

		case VASTAI_ENC_IOCH_DETACH_VENCCHNL:
		{
			struct list_head *p = NULL, *n = NULL;
			//struct enc_chn_info *handle_node = NULL;
			device_handle_t *device_handle_node = NULL;
			//struct die_enc_info* die = 0;
			venc_msg_chninfo_t chninfo;
			u32 core_id;
			u32 die_index;
			u32 jobidx;
			struct enc_chn_info *info;

			info = get_enc_chn_info(filp);
			if (info == NULL)
				return -EFAULT;

			if (video_copy_from_user(&chninfo, (void*)arg, sizeof(venc_msg_chninfo_t)))
				return -EFAULT;

			core_id = chninfo.core_id>>16;
			jobidx = chninfo.core_id&0xFF;
			die_index = chninfo.die_index;
			if (die_index != info->die_index || core_id != info->core_id)
				return -EFAULT;

			list_for_each_safe(p, n, &device_list_head) {
				device_handle_node = list_entry(p, device_handle_t, node);
				if (die_index == device_handle_node->die.die_index)
				{
					die = &device_handle_node->die;
				}
			}
			if (die == 0 || core_id>= VASTAI_MAX_ENC_CORES || jobidx>= VASTAI_MAX_CORE_CHANNEL)
				return -3;

			if (info != &(die->venc_core_info[core_id].enc_chn_set[jobidx]))
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"chn error die idx:%d core:%d jobidx:%d\n",info->die_index,info->core_id,jobidx);


			info = &(die->venc_core_info[core_id].enc_chn_set[jobidx]);
//			kfree(info->rcv);
			info->core_id = 0;
			info->die_index = 0;
			info->instance_addr = 0;
			info->msg_addr = 0;
			/*  list_for_each_safe(p, n, &(die->venc_core_info[core_id].enc_chn_head)) {
					handle_node = list_entry(p, struct enc_chn_info, node);
					if (handle_node == info) {
						list_del(&info->node);
					}
				} */

//			info->rcv = 0;

			//kfree(info);
			set_enc_chn_info(filp, NULL);
			break;
		}

		case VASTAI_ENC_IOCH_SET_VENCCHNLMSG:
		{
			int ret;
			TVidEncCfgParam tvidencparam = {0};
			union die_index_data did;
			struct vastai_pci_info *pcie_dev;
			struct enc_chn_info *info;

			info = get_enc_chn_info(filp);
			if (info == NULL)
			{
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index), "chn not create..\n");
				return -1;
			}

			ret=video_copy_from_user(&tvidencparam, (void*)arg, sizeof(TVidEncCfgParam));
			if (ret)
			{
				return -2;
			}

			did.val = (u32)info->die_index;
			pcie_dev = get_vastai_pci_device_info(did.dev_id);
			if (pcie_dev == 0)
			{
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"get_vastai_pci_device_info error  %d\n",did.dev_id);
				return -3;
			}

			ret = vastai_fifo_push_elem(pcie_dev, info->die_index,info->msg_addr,&tvidencparam,NULL);
			if (ret)
				return -4;
			break;
		}

		case VASTAI_ENC_IOCH_GET_VENCCHNLMSG:
		{
			struct enc_chn_info *info;

			info = get_enc_chn_info(filp);
			if (info == NULL)
				return -EFAULT;

			/* if(!vastai_fifo_is_empty(info->rcv))
			{
				vemcu_to_host_msg_t *pmsg= (vemcu_to_host_msg_t *)((u8*)info->rcv+vastai_fifo_rd_pre_fetch(info->rcv));
				if (video_copy_to_user((void*)arg, pmsg, sizeof(vemcu_to_host_msg_t)))
				{
					return -EFAULT;
				}
				vastai_fifo_rd_next(info->rcv);
				info->event =0;
			}   */

			info->event =0;
			break;
		}

		case VASTAI_ENC_IOCH_GET_VCMD_ENABLE:
		{
			//__put_user(1, (u32 *) arg);
            u32 enable  = 1;
            if (video_copy_to_user((u32*)arg, &enable, sizeof(enable))) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),"VASTAI_ENC_IOCH_GET_VCMD_ENABLE failed!\n");
				return -EFAULT;
			}
			break;
		}

		case VASTAI_ENC_IOCH_GET_ENCMODE:
		{
			//__put_user(die->encoder_mode, (u16 *) arg);
            if (video_copy_to_user((u32*)arg, &die->encoder_mode, sizeof(u32))) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index), "VASTAI_ENC_IOCH_GET_ENCMODE failed!\n");
				return -EFAULT;
			}
			break;
		}

        case VASTAI_ENC_IOCH_GET_MULTIMODE_RESERVE:
        {
            u32 flag = 1;
            int i = 0;
            int current_pid = task_pid_nr(current);
            struct task_struct *task = NULL;
            struct multimode_limit_stream limit, *p_limit ;
			struct pid *pidpid = task_pid(current);

            limit.pid_ns = ns_of_pid(task_pid(current));
            limit.main_pid = current_pid;
            limit.namespace_pid = pidpid->numbers[pidpid->level].nr;

            if(die->encoder_mode == SINGLE_CORE_MODE){
                __put_user(0, (u32 *) arg);
                break;
            }

            mutex_lock(&enc_device_handle->device_mutex);
            for(i = 0; i < MULTI_MODE_ALLOW_MAX_STREAM; i++){

                p_limit = &die->limit_info[i];
                if(p_limit->main_pid == 0){
                    *p_limit = limit;
                    flag = 0;
                    break;
                }

                if(p_limit->main_pid != p_limit->namespace_pid){
                    pidpid = find_pid_ns(p_limit->namespace_pid,  p_limit->pid_ns);
                }else{
                    pidpid = find_pid_ns(p_limit->main_pid, p_limit->pid_ns);
                }

                if(!pidpid){
                    *p_limit = limit;
                    flag = 0;
                    break;
                }

                task = pid_task(pidpid, PIDTYPE_PID);
                if(!task || task->exit_state == EXIT_ZOMBIE ||  task->exit_state == EXIT_DEAD){
                    *p_limit = limit;
                    flag = 0;
                    break;
                }
            }
            mutex_unlock(&enc_device_handle->device_mutex);
            __put_user(flag, (u32 *) arg);
            break;
        }
        case VASTAI_ENC_IOCH_GET_MULTIMODE_RELEASE:
        {
            int current_pid = task_pid_nr(current);
            int i = 0;

            mutex_lock(&enc_device_handle->device_mutex);
            for(i = 0; i < MULTI_MODE_ALLOW_MAX_STREAM; i++){
                if(die->limit_info[i].main_pid == current_pid){
                    memset(&die->limit_info[i], 0, sizeof(struct multimode_limit_stream));
                    break;
                }
            }
            mutex_unlock(&enc_device_handle->device_mutex);
            __put_user(0, (u32 *) arg);

            break;
        }

		case VASTAI_ENC_IOCH_GET_CMDBUF_PARAMETER:
		{
			struct cmdbuf_mem_parameter local_cmdbuf_mem_data = {0};
			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd get cmdbuf parameter die_index=0x%x\n", die->die_index);

			if (video_copy_from_user(&local_cmdbuf_mem_data, (struct cmdbuf_mem_parameter*)arg, sizeof(struct cmdbuf_mem_parameter))) {
				return -EFAULT;
			}

			local_cmdbuf_mem_data.cmdbuf_unit_size = CMDBUF_MAX_SIZE;
			local_cmdbuf_mem_data.status_cmdbuf_unit_size = CMDBUF_MAX_SIZE;
			local_cmdbuf_mem_data.cmdbuf_total_size = CMDBUF_POOL_TOTAL_SIZE;
			local_cmdbuf_mem_data.status_cmdbuf_total_size = CMDBUF_POOL_TOTAL_SIZE;
			local_cmdbuf_mem_data.phy_status_cmdbuf_addr = die->vcmd_status_buf_mem_pool.busAddress;
			local_cmdbuf_mem_data.phy_cmdbuf_addr = die->vcmd_buf_mem_pool.busAddress;

			local_cmdbuf_mem_data.mmu_phy_status_cmdbuf_addr = 0;
			local_cmdbuf_mem_data.mmu_phy_cmdbuf_addr = 0;
			local_cmdbuf_mem_data.base_ddr_addr = 0;

			//local_cmdbuf_mem_data.vcmd_reg_mem_busAddress = die_info->vcmd_reg_mem_busAddress;

			if (video_copy_to_user((struct cmdbuf_mem_parameter*)arg, &local_cmdbuf_mem_data, sizeof(struct cmdbuf_mem_parameter))) {
				return -EFAULT;
			}

			break;
		}

		case VASTAI_ENC_IOCH_GET_VCMD_PARAMETER:
		{
			struct config_parameter input_para = {0};
			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd get vcmd config parameter die_index=0x%x\n", die->die_index);

			if (video_copy_from_user(&input_para,(struct config_parameter*)arg,sizeof(struct config_parameter))) {
				return -EFAULT;
			}

			if (die->vcmd_type_core_num[input_para.module_type]) {
				input_para.submodule_main_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_main_addr;
				input_para.submodule_dec400_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_dec400_addr;
				input_para.submodule_L2Cache_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_L2Cache_addr;
				input_para.submodule_MMU_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_MMU_addr;
				input_para.submodule_MMUWrite_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_MMUWrite_addr;
				input_para.submodule_axife_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_axife_addr;
				input_para.config_status_cmdbuf_id = die->vcmd_manager[input_para.module_type][0]->status_cmdbuf_id;
				input_para.vcmd_hw_version_id = die->vcmd_manager[input_para.module_type][0]->hw_version_id;
				input_para.vcmd_core_num = die->vcmd_type_core_num[input_para.module_type];

			} else {
				input_para.submodule_main_addr = 0xffff;
				input_para.submodule_dec400_addr = 0xffff;
				input_para.submodule_L2Cache_addr = 0xffff;
				input_para.submodule_MMU_addr = 0xffff;
				input_para.submodule_MMUWrite_addr = 0xffff;
				input_para.submodule_axife_addr = 0xffff;
				input_para.config_status_cmdbuf_id = 0;
				input_para.vcmd_core_num = 0;
				input_para.vcmd_hw_version_id =HW_ID_1_0_C;
			}

			if (video_copy_to_user((struct config_parameter*)arg, &input_para, sizeof(struct config_parameter))) {
				return -EFAULT;
			}

			break;
		}

		case VASTAI_ENC_IOCH_RESERVE_CMDBUF:
		{
			int ret = -1;
			struct exchange_parameter input_para = {0};
			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd reserve cmdbuf die_index=0x%x\n", die->die_index);

			if (video_copy_from_user(&input_para, (struct exchange_parameter*)arg, sizeof(struct exchange_parameter))) {
				return -EFAULT;
			}

			ret = reserve_cmdbuf(filp, die, &input_para);
			if (ret == 0) {
				if (video_copy_to_user((struct exchange_parameter*)arg,&input_para,sizeof(struct exchange_parameter))) {
					return -EFAULT;
				}
			} else {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"%s: reserve_cmdbuf failed ret=%d, die_index=0x%x!!!\n", __func__, ret, die->die_index);
				return -EFAULT;
			}

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"%s: reserve_cmdbuf success, die_index=0x%x cmdbuf_id=%d\n",
				__func__, die->die_index, input_para.cmdbuf_id);

			break;
		}

		case VASTAI_ENC_IOCH_LINK_RUN_CMDBUF:
		{
			struct exchange_parameter input_para = {0};
			int ret = -1;
			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd link and run cmdbuf die_index=0x%x, filp=%p\n", die->die_index, filp);

			if (video_copy_from_user(&input_para,(struct exchange_parameter*)arg, sizeof(struct exchange_parameter))) {
				return -EFAULT;
			}

			ret = link_and_run_cmdbuf(filp, &input_para, die);
			if (ret == 0) {
				if (video_copy_to_user((struct exchange_parameter*)arg, &input_para, sizeof(struct exchange_parameter))) {
					return -EFAULT;
				}
			} else {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"%s: link_and_run_cmdbuf failed ret=%d, die_index=0x%x, cmdbuf_id=%d, core_id=%d!!!\n",
					__func__, ret, die->die_index,  input_para.cmdbuf_id, input_para.core_id);
				return -EFAULT;
			}

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"%s: link_and_run_cmdbuf success, die_index=0x%x, cmdbuf_id=%d, core_id=%d\n",
				__func__, die->die_index,  input_para.cmdbuf_id, input_para.core_id);

			break;
		}

		case VASTAI_ENC_IOCH_WAIT_CMDBUF:
		{
			enc_waitcmd_parameter wait_param = {0};
			u32 cmdbuf_id = -1;
			u32 core_id = -1;
			int ret = -1;

			if (video_copy_from_user(&wait_param, (enc_waitcmd_parameter*)arg, sizeof(enc_waitcmd_parameter))) {
				return -EFAULT;
			}

			cmdbuf_id = wait_param.cmdbuf_id;

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd wait for cmdbuf. die_index=0x%x, cmdbuf_id=%d\n", die->die_index, cmdbuf_id);
			ret = wait_cmdbuf_ready(filp, die, cmdbuf_id);

			if (ret == 0) {
				if (video_copy_to_user((enc_waitcmd_parameter*)arg, &die->mcu_msg[cmdbuf_id], sizeof(enc_waitcmd_parameter))) {
					return -EFAULT;
				}
			} else {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"%s:wait_cmdbuf_ready failed ret=%d, die_index=0x%x, cmdbuf_id=%d, core_id=%d!!!\n",
					__func__, ret, die->die_index, cmdbuf_id, core_id);
				return -EFAULT;
			}

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"%s:wait_cmdbuf_ready success, die_index=0x%x, cmdbuf_id=%d, core_id=%d!!!\n",
				__func__, die->die_index, cmdbuf_id, core_id);

			break;
		}

		case VASTAI_ENC_IOCH_RELEASE_CMDBUF:
		{
			int ret = -1;
			u16 cmdbuf_id;
			//__get_user(cmdbuf_id, (u16*)arg);
            if( video_copy_from_user(&cmdbuf_id, (u16*)arg, sizeof(cmdbuf_id)) ) {
                return -EFAULT;
            }

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"venc vcmd release cmdbuf: die_index=0x%x, cmdbuf_id=%d\n", die->die_index, cmdbuf_id);
			ret = release_cmdbuf(filp, cmdbuf_id, die);
			if (ret != 0) {
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"%s:release_cmdbuf failed ret=%d, die_index=0x%x, cmdbuf_id=%d!!!\n",
					__func__, die->die_index, ret, cmdbuf_id);
				return -EFAULT;
			}

			VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
				"%s:release_cmdbuf success, die_index=0x%x, cmdbuf_id=%d!!!\n",
				__func__, die->die_index, cmdbuf_id);

			break;
		}

		default:
		{
			VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
				"%s: invalid ioctl cmd=0x%x!!!\n", __func__, cmd);
			return -1;
		}
	}

	return 0;
}

int hantroenc_open(struct inode *inode, struct file *filp)
{
	int result = 0;
	struct enc_chn_info *info = NULL;
	set_enc_chn_info(filp, info);

	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "hantroenc_open %p\n", (void *)filp);
	return result;
}
int hantroenc_release(struct inode *inode, struct file *filp)
{
	struct vastai_video_info *video_info = NULL;
	struct die_enc_info *die = NULL;
    struct device_handle *enc_device_handle = NULL;

	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "hantroenc_release %p\n", (void *)filp);

	video_info = (struct vastai_video_info *)filp->private_data;
	if (video_info == NULL || video_info->enc_device_handle == NULL) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
			"%s: video_info or enc_device_handle is null, return\n", __func__);
		return -1;
	}

	die = (struct die_enc_info*)&video_info->enc_device_handle->die;
    enc_device_handle = (struct device_handle *) video_info->enc_device_handle;

	if (die->encoder_mode == SINGLE_CORE_MODE) {
		struct enc_chn_info *info = get_enc_chn_info(filp);

        if (enc_device_handle->lock_filp == filp) {
            VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
                "%s: auto-unlock channel, filp %p\n", __func__, filp);
            wait_alloc_channel_unlock(filp, die->die_index);
        }
        
        if (info == NULL)
			return 0;
//		kfree(info->rcv);
		info->core_id = 0;
		info->die_index = 0;
		info->instance_addr = 0;
		info->msg_addr = 0;
//		info->rcv = 0;
		set_enc_chn_info(filp, NULL);

	} else if (die->encoder_mode == MULTI_CORE_MODE) {

		u32 cmdbuf_id = 0, release_cmdbuf_num = 0;
		struct cmdbuf_obj* cmdbuf_obj_temp = NULL;

		for (cmdbuf_id = 0; cmdbuf_id < TOTAL_DISCRETE_CMDBUF_NUM; cmdbuf_id++) {
			cmdbuf_obj_temp = &(die->cmdbuf_obj_sets[cmdbuf_id]);
			if (cmdbuf_obj_temp->filp == filp) {
				clean_cmdbuf_obj(cmdbuf_obj_temp, cmdbuf_id, die);
				release_cmdbuf_num++;
			}
		}
		VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
			"hantroenc_release %p, released %d cmdbuf\n", (void *)filp, release_cmdbuf_num);

	} else {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s: error encode mode, return\n", __func__);
		return -1;
	}

	return 0;
}

unsigned int hantroenc_poll(struct file *filp, poll_table *wait)
{
	unsigned int mask = 0;
	struct enc_chn_info *info;

	info = get_enc_chn_info(filp);
	if (info == NULL)
		return mask;

	poll_wait(filp, &info->wait_queue, wait);
	if (info->event) {
		mask |= POLLIN;
	}

	if (signal_pending(current)) {
                int i;
                unsigned long timeout = jiffies + 1*HZ;
                while (!info->event) {
                        msleep(1);
                        i++;
                        if (time_after(jiffies, timeout))
                                break;
                }
                //printk("i:%d\n", i);
                if (!info->event)
                        printk("not wait event complete:0x%x\n", info->instance_addr);
        }

	//printk("mask:%x\n", mask);
	return mask;
}
/* VFS methods */
static struct file_operations hantroenc_fops = {
	.owner= THIS_MODULE,
	.open = hantroenc_open,
	.release = hantroenc_release,
	.unlocked_ioctl = hantroenc_ioctl,
	.poll = hantroenc_poll,
	.fasync = NULL,
};

 static int vastai_singlecore_callback(void *pci_dev, u32 die_index, int irq, void *die_info, void *mcu_msg)
{
	u32 core_id = irq - ENCCORE0_IRQ_BASE;
	vemcu_to_host_msg_t* msg = (vemcu_to_host_msg_t*)mcu_msg;
//	struct enc_chn_info *info;
	struct die_enc_info* die;
	u32 index =0;

	if (core_id>= 4)
	{
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "error msg cord id:%d\n",core_id);
		return 0;
	}

	die = (struct die_enc_info*)die_info;
	//printk(" in_fifo: core[%d]---> status=%d--insaddr= %x %d\n", core_id, msg->enc_status, msg->instance_addr,die->die_index);
	for(index=0; index< VASTAI_MAX_CORE_CHANNEL; index++)
	{
		if (die->venc_core_info[core_id].enc_chn_set[index].instance_addr == msg->instance_addr)
		{
			die->venc_core_info[core_id].enc_chn_set[index].event =1;
			wake_up_interruptible(&die->venc_core_info[core_id].enc_chn_set[index].wait_queue);
			break;
		}
	}
	if (index == VASTAI_MAX_CORE_CHANNEL) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"err msg die:%u, cord id:%d, instance_addr:%u\n",die_index, core_id, msg->instance_addr);
	}
 #if 0
	list_for_each_entry(info, &(die->venc_core_info[core_id].enc_chn_head), node) {
		 if (info->instance_addr == msg->instance_addr) {
		   if(!vastai_fifo_is_full(info->rcv))
			{
				vemcu_to_host_msg_t *pmsg = (vemcu_to_host_msg_t *)((u8*)info->rcv+vastai_fifo_wr_pre_fetch(info->rcv));
				memcpy(pmsg, mcu_msg, sizeof(vemcu_to_host_msg_t));
				vastai_fifo_wr_next(info->rcv);
			}
			else
			{
				VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
					"error die_index[%x] venc[%d] fifo full\n",die_index,core_id);
				return 0;
			}
			info->event =1;
			wake_up_interruptible(&info->wait_queue);
			break;
		}
	}
#endif
	return 0;
}

static int vastai_multicore_callback(void *pci_dev, u32 die_id, int irq, void *die_info, void *mcu_msg)
{
	multivemcu_to_host_msg_t* msg = (multivemcu_to_host_msg_t *)mcu_msg;
	u32 cmdbuf_id = msg->cmdbuf_id;
	u32 status = msg->encstate;
	u32 enc_core_id =  msg->core_id;
	struct die_enc_info* die = (struct die_enc_info*)die_info;
	int ret = -1;
	int work_ret = 0;

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"venc in_fifo: die_index=0x%x, cmdbuf_id=%d mcu_vcmd_status=%d\n", die->die_index, cmdbuf_id, status);

	if (cmdbuf_id >= TOTAL_DISCRETE_CMDBUF_NUM || enc_core_id >= VASTAI_ENC_MAX_CORES) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"Venc die_index=0x%x, cmdbuf_id=%d or core_id=%d, invalid!\n", die->die_index, cmdbuf_id, enc_core_id);
		return ret;
	}

	memcpy(&die->mcu_msg[cmdbuf_id], msg, sizeof(multivemcu_to_host_msg_t));

	ret = vastai_cmdid_enqueue(&die->cmdbufId_queue, cmdbuf_id, status, 0, 0);
	if (ret) {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"venc cmdbuf id queue is full, die_index=0x%x, cmdbuf_id=%d, core_id=%d, return!\n",
			die->die_index, cmdbuf_id, enc_core_id);
		return ret;
	}

	work_ret = queue_work(die->workqueue, &(die->work));

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"%s: done: cmdbuf_id=%d core_id=%d, status=0x%x work_ret=%d\n",
		__func__, cmdbuf_id, enc_core_id, status, work_ret);

	return ret;
}

static int vastai_pci_enc_callback(void *pci_dev, u32 die_index, int irq, void *die_info, void *mcu_msg) {

	struct die_enc_info* die = (struct die_enc_info*)die_info;

	VAVIDEO_DBG(die->priv_dev, (u8)(die->die_index),
		"%s: die_index=0x%x, encoder_mode=%d, die_info=%p\n",
		__func__, die_index, die->encoder_mode, die_info);

	if (die->encoder_mode == SINGLE_CORE_MODE) {

		return vastai_singlecore_callback(pci_dev, die_index, irq, die_info, mcu_msg);

	} else if (die->encoder_mode == MULTI_CORE_MODE) {

		return vastai_multicore_callback(pci_dev, die_index, irq, die_info, mcu_msg);

	} else {
		VAVIDEO_ERR(die->priv_dev, (u8)(die->die_index),
			"%s: unsupported encoder mode!!!", __func__);
		return -1;

	}

}

/*------------------------------------------------------------------------------
 Function name   : vcmd_init
 Description	 : Initialize vcmd bus addr

 Return type	 : int
 ------------------------------------------------------------------------------*/
static int vcmd_init(struct die_enc_info *die_info)
{
	int i, k;
	struct vastaivcmd_dev* vastaivcmd_data = NULL;
	unsigned int hwid = 0x43421200;
	struct vastai_fifo fifo = {.rd = 0, .wr = 0, .elem_count=HOST_VEMCU_MAX_MSG_NUM, .elem_size=HOST_VEMCU_ELEM_SIZE};

	//set vcmd cmdbuf addr start
	die_info->vcmd_buf_mem_pool.busAddress = VCMD_ENC_DDR_BASE_ADDR_0;
	die_info->vcmd_buf_mem_pool.size = CMDBUF_POOL_TOTAL_SIZE;

	VAVIDEO_INFO(die_info->priv_dev, (u8)(die_info->die_index),
			"VENC VCMD buf mem addr=0x%lx, size=0x%08x\n",
			(unsigned long)die_info->vcmd_buf_mem_pool.busAddress,
			die_info->vcmd_buf_mem_pool.size);

	die_info->vcmd_status_buf_mem_pool.busAddress = VCMD_ENC_DDR_BASE_ADDR_0 + CMDBUF_POOL_TOTAL_SIZE;
	die_info->vcmd_status_buf_mem_pool.size = CMDBUF_POOL_TOTAL_SIZE;

	VAVIDEO_INFO(die_info->priv_dev, (u8)(die_info->die_index),
			"VENC VCMD status buf mem addr=0x%lx, size=0x%08x\n",
			(unsigned long)die_info->vcmd_status_buf_mem_pool.busAddress,
			die_info->vcmd_status_buf_mem_pool.size);

	die_info->vcmd_registers_mem_pool.busAddress = VCMD_ENC_DDR_BASE_ADDR_0  + CMDBUF_POOL_TOTAL_SIZE * 2;
	die_info->vcmd_registers_mem_pool.size = CMDBUF_VCMD_REGISTER_TOTAL_SIZE;

	VAVIDEO_INFO(die_info->priv_dev, (u8)(die_info->die_index),
			"VENC VCMD registers mem addr=0x%lx, size=0x%08x\n",
			(unsigned long)die_info->vcmd_registers_mem_pool.busAddress ,
			die_info->vcmd_registers_mem_pool.size);
	//set vcmd cmdbuf addr end

	vastaivcmd_data = (struct vastaivcmd_dev *)vmalloc(sizeof(struct vastaivcmd_dev) * total_vcmd_core_num);
	if (vastaivcmd_data == NULL) {
		VAVIDEO_ERR(die_info->priv_dev, (u8)(die_info->die_index),
			"%s: alloc mem failed!\n", __func__);
		return -1;
	}

	for (k=0; k < MAX_VCMD_TYPE; k++) {
		die_info->vcmd_type_core_num[k] = 0;
		for (i=0; i<MAX_VCMD_NUMBER; i++) {
			die_info->vcmd_manager[k][i] = NULL;
		}
	}

	die_info->workqueue = create_workqueue("video_encoder_workqueue");
	INIT_WORK(&(die_info->work), vcmd_workqueue_schedue);
	vastai_cmdid_init(&die_info->cmdbufId_queue, ENCODER);
	vastai_pci_mem_write(die_info->priv_dev, die_info->die_index, HOST_VEMCU0_MSG_ADDR, &fifo, sizeof(fifo));

	memset(vastaivcmd_data, 0, sizeof(struct vastaivcmd_dev) * total_vcmd_core_num);
	VAVIDEO_INFO(die_info->priv_dev, (u8)(die_info->die_index),
			"total_vcmd_core_num=%d\n", total_vcmd_core_num);

	for (i = 0; i < total_vcmd_core_num; i++) {
		vastaivcmd_data[i].vcmd_core_cfg = vcmd_core_array[i];
		vastaivcmd_data[i].hwregs = NULL;
		vastaivcmd_data[i].core_id = i;
		vastaivcmd_data[i].working_state = WORKING_STATE_IDLE;
		vastaivcmd_data[i].sw_cmdbuf_rdy_num = 0;
		mutex_init(&vastaivcmd_data[i].mutex);

		vastaivcmd_data[i].duration_without_int = 0;

		die_info->vcmd_manager[vcmd_core_array[i].sub_module_type][die_info->vcmd_type_core_num[vcmd_core_array[i].sub_module_type]] = &vastaivcmd_data[i];
		die_info->vcmd_type_core_num[vcmd_core_array[i].sub_module_type]++;
		vastaivcmd_data[i].vcmd_type_core_num[vcmd_core_array[i].sub_module_type]++;

		vastaivcmd_data[i].hw_version_id = hwid;
		spin_lock_init(&vastaivcmd_data[i].vcmd_cmdbuf_alloc_lock);

		die_info->cmdbuf_used[i+1] = 1;
	}

	die_info->vastaivcmd_data = vastaivcmd_data;

	mutex_init(&die_info->mutex);
	mutex_init(&die_info->vastai_fifo_mutex);
	init_waitqueue_head(&die_info->vcmd_cmdbuf_memory_wait);
	init_waitqueue_head(&die_info->venc_alloc_channel_wait);
	init_waitqueue_head(&die_info->wait_queue);

	die_info->cmdbuf_used[0] = 1;
	die_info->cmdbuf_used_pos = total_vcmd_core_num + 1;
	die_info->cmdbuf_used_pos_im = TOTAL_DISCRETE_CMDBUF_NUM - IM_CMDBUF_NUM + 1;
	die_info->cmdbuf_used_residual = TOTAL_DISCRETE_CMDBUF_NUM - total_vcmd_core_num - 1 - IM_CMDBUF_NUM;
	die_info->cmdbuf_used_residual_im = IM_CMDBUF_NUM;
	(die_info->vcmd_manager[VCMD_TYPE_ENCODER][0])->status_cmdbuf_id = 1;

	return 0;
}

static int do_work_mode_change(device_handle_t *device_handle_node, encoder_workmode_t work_mode, u32 init) {
	int core_id;
	int count = CHECK_RESET_STAT_INTERVAL;
	int magic_number = (work_mode == SINGLE_CORE_MODE ? ENCODER_SINGLE_MODE_MAGIC : ENCODER_MULTI_MODE_MAGIC);

	if (device_handle_node->die.encoder_mode == work_mode && !init) {
		VAVIDEO_INFO(device_handle_node->die.priv_dev,
				(u8)(device_handle_node->die.die_index),
				"current work mode(%s) is same with dest work mode, no need switch\n",
				(work_mode == SINGLE_CORE_MODE ? "single-core" : "multi-core"));
		return 0;
	}

	atomic_set(&(device_handle_node->die.encoder_state), VIDEO_STATE_CHANGING);
	VAVIDEO_INFO(device_handle_node->die.priv_dev,
				(u8)(device_handle_node->die.die_index),
				"die_index[%x] encoder change to %d start\n", device_handle_node->die.die_index, work_mode);

	vastai_pci_mem_write(device_handle_node->die.priv_dev, device_handle_node->die.die_index, ENCODER_WORKMODE_ADDR, &magic_number, sizeof(magic_number));

	if (!init) {

		if (work_mode == MULTI_CORE_MODE) {
			int i;
			struct vastai_fifo fifo = {.rd = 0, .wr = 0, .elem_count=HOST_VEMCU_MAX_MSG_NUM, .elem_size=HOST_VEMCU_ELEM_SIZE};
			// 1. reset cmdbuf id
			mutex_lock(&device_handle_node->die.mutex);
			device_handle_node->die.cmdbuf_used_pos = total_vcmd_core_num + 1;
			device_handle_node->die.cmdbuf_used_pos_im = TOTAL_DISCRETE_CMDBUF_NUM - IM_CMDBUF_NUM + 1;
			device_handle_node->die.cmdbuf_used_residual = TOTAL_DISCRETE_CMDBUF_NUM - total_vcmd_core_num - 1 - IM_CMDBUF_NUM;
			device_handle_node->die.cmdbuf_used_residual_im = IM_CMDBUF_NUM;
			memset(device_handle_node->die.cmdbuf_used, 0, sizeof(device_handle_node->die.cmdbuf_used));
			for (i = 0; i < total_vcmd_core_num + 1; i++) {
				device_handle_node->die.cmdbuf_used[i] = 1;
			}
			mutex_unlock(&device_handle_node->die.mutex);

			// 2. reinit host->vemcu ring buffer
			vastai_pci_mem_write(device_handle_node->die.priv_dev, device_handle_node->die.die_index, HOST_VEMCU0_MSG_ADDR, &fifo, sizeof(fifo));

			memset(&device_handle_node->die.limit_info, 0, sizeof(device_handle_node->die.limit_info));
		}

		//because multi-core mode we use vemcu0 to control venc 0~3, so reset vemcu0 finally;
		//single-core mode we need vemcu0 to init dieinfo and ringbuffer, so reset vemcu0 first;
		if (work_mode == MULTI_CORE_MODE) {
			for (core_id = CORE_POINT_VEMCU3; core_id >= CORE_POINT_VEMCU0; core_id--) {

				count = CHECK_RESET_STAT_INTERVAL;
				device_handle_node->die.reset_end_bitmap &= ~(1 << (core_id % CORE_POINT_VEMCU0));

				vastai_send_pcie_cmd(device_handle_node->die.priv_dev,device_handle_node->die.die_index,
								VASTAI_PCIE_SUB_CORE_RESET, core_id);

				while (count) {

					if (device_handle_node->die.reset_end_bitmap & (1 << (core_id % CORE_POINT_VEMCU0))) {
						VAVIDEO_INFO(device_handle_node->die.priv_dev,
								 (u8)(device_handle_node->die.die_index),
								 "die_index[%x] venc core %d reset to multi success\n", device_handle_node->die.die_index, core_id);
						break;
					}

					msleep(50);
					count--;

				}

				if (count == 0) {
					VAVIDEO_ERR(device_handle_node->die.priv_dev,
						(u8)(device_handle_node->die.die_index),
						"die_index[%x] venc core %d reset to multi failed!\n", device_handle_node->die.die_index, core_id);
					return -1;
				}
			}
		} else if (work_mode == SINGLE_CORE_MODE) {
			for (core_id = CORE_POINT_VEMCU0; core_id <= CORE_POINT_VEMCU3; core_id++) {

				count = CHECK_RESET_STAT_INTERVAL;
				device_handle_node->die.reset_end_bitmap &= ~(1 << (core_id % CORE_POINT_VEMCU0));

				vastai_send_pcie_cmd(device_handle_node->die.priv_dev,device_handle_node->die.die_index,
								VASTAI_PCIE_SUB_CORE_RESET, core_id);

				while (count) {

					if (device_handle_node->die.reset_end_bitmap & (1 << (core_id % CORE_POINT_VEMCU0))) {
						VAVIDEO_INFO(device_handle_node->die.priv_dev,
								 (u8)(device_handle_node->die.die_index),
								 "die_index[%x] core %d reset to single success\n", device_handle_node->die.die_index, core_id);
						break;
					}

					msleep(50);
					count--;

				}

				if (count == 0) {
					VAVIDEO_ERR(device_handle_node->die.priv_dev,
						(u8)(device_handle_node->die.die_index),
						"die_index[%x] core %d reset to single failed!\n", device_handle_node->die.die_index, core_id);
					return -1;
				}
			}
		}

		msleep(500);

		VAVIDEO_INFO(device_handle_node->die.priv_dev,
				(u8)(device_handle_node->die.die_index),
				"vasmi set encoder work mode to %s success!\n",
				(work_mode == SINGLE_CORE_MODE ? "single-core" : "multi-core"));
	} else {
		VAVIDEO_INFO(device_handle_node->die.priv_dev,
				(u8)(device_handle_node->die.die_index),
				"init set encoder work mode to %s success!\n",
				(work_mode == SINGLE_CORE_MODE ? "single-core" : "multi-core"));
	}

	device_handle_node->die.encoder_mode = work_mode;

	atomic_set(&(device_handle_node->die.encoder_state), VIDEO_STATE_READY);
	VAVIDEO_INFO(device_handle_node->die.priv_dev,
				(u8)(device_handle_node->die.die_index),
				"die_index[%x] encoder change to %d end\n", device_handle_node->die.die_index, work_mode);

	return 0;
}

void hantroenc_set_log_level(int level) {
	VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "plz set log level by /dev/kchar node\n");
}

int hantroenc_get_work_mode(int die_index, encoder_workmode_t* work_mode, int* job_count) {
	device_handle_t *device_handle_node = NULL;
	int ret = -1;

	ret = hantroenc_get_device_from_dieindex(die_index, &device_handle_node);
	if (ret) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
			"%s: failed to get die device, return\n", __func__);
		return -1;
	}

	*work_mode = device_handle_node->die.encoder_mode;
	*job_count = atomic_read(&(device_handle_node->die.enc_job_count));

	return 0;
}

int hantroenc_set_work_mode(int die_index, encoder_workmode_t work_mode, u32 init) {
	device_handle_t *device_handle_node = NULL;
	int ret = -1;

	ret = hantroenc_get_device_from_dieindex(die_index, &device_handle_node);
	if (ret) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
				"%s: failed to get die device, return\n", __func__);
		return -1;
	}

	if (atomic_read(&(device_handle_node->die.enc_job_count)) != 0) {
		VAVIDEO_INFO(device_handle_node->die.priv_dev,
			(u8)(device_handle_node->die.die_index),
			"still run %d task on die: 0x%x, switch encoder work mode failed, return\n",
			atomic_read(&(device_handle_node->die.enc_job_count)), die_index);
		return -1;
	}

	do_work_mode_change(device_handle_node, work_mode, init);

	return 0;
}

int hantroenc_get_device_from_dieindex(u32 die_index, device_handle_t** enc_device_handle) {

	struct list_head *p = NULL, *n = NULL;
	device_handle_t *device_handle_node = NULL;

	if(enc_device_handle == NULL || list_empty(&device_list_head)) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
			"%s: invalid paramater! or device_list_head is empty!!!\n", __func__);
		return -1;
	}

	list_for_each_safe(p, n, &device_list_head) {
		device_handle_node = list_entry(p, device_handle_t, node);
		if (die_index == device_handle_node->die.die_index) {
			*enc_device_handle = device_handle_node;
			return 0;
		}
	}

	VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
		"%s: can not find encode device!!!\n", __func__);

	return -1;
}

int  hantroenc_normal_init(void *pcie_dev, u32 die_index)
{
	int result = 0;
	int i = 0;
	int index = 0;
	device_handle_t* device_handle = NULL;
	int vastai_enc_irq[] = {VASTAI_ENC_CORE0, VASTAI_ENC_CORE1, VASTAI_ENC_CORE2,VASTAI_ENC_CORE3};
	VAVIDEO_INFO(pcie_dev, (u8)die_index, "hantroenc_normal_init\n");
	if (!dwProbeInit) {
		VAVIDEO_INFO(pcie_dev, (u8)die_index, "init char dev\n");

		result = register_chrdev(hantroenc_major, "vc8000", &hantroenc_fops);
		if(result < 0)
		{
			VAVIDEO_ERR(pcie_dev, (u8)die_index,
				"hantroenc: unable to get major <%d>\n",
				hantroenc_major);
			goto err;
		}
		else if(result != 0)	/* this is for dynamic major */
		{
			hantroenc_major = result;
		}
#if KERNEL_VERSION(6,4,0) > LINUX_VERSION_CODE
		encode_drv_class = class_create(THIS_MODULE, "vc8000");
#else
		encode_drv_class = class_create("vc8000");
#endif
		device_create(encode_drv_class, NULL, MKDEV(hantroenc_major, 0), NULL, "vc8000");
		VAVIDEO_INFO(pcie_dev, (u8)die_index,
			"hantroenc: module inserted. Major <%d>\n", hantroenc_major);

		INIT_LIST_HEAD(&device_list_head);

		dwProbeInit = 1;
	}


	device_handle = (device_handle_t*)kzalloc(sizeof(device_handle_t), GFP_KERNEL);
	if (!device_handle)
	{
		VAVIDEO_ERR(pcie_dev, (u8)die_index, "alloc device_handle failed \n");
		goto err;
	}

	mutex_init(&device_handle->chan_alloc_mutex);
	mutex_init(&device_handle->device_mutex);

	atomic_set(&(device_handle->die.encoder_state), VIDEO_STATE_INITING);
	atomic_set(&(device_handle->die.enc_job_count), 0);

	device_handle->die.priv_dev = (struct vastai_pci_info *)pcie_dev;
	device_handle->die.die_index = die_index;
        device_handle->die.venc_chanl_locked = VASTAI_ENC_LOCK_FLAG_TRUE;

	total_vcmd_core_num = sizeof(vcmd_core_array)/sizeof(struct vcmd_config);
	device_handle->die.core_num = total_vcmd_core_num;

	result = vcmd_init(&device_handle->die);
	if(result)
		goto err;

	list_add_tail(&(device_handle->node), &device_list_head);


	for (i = 0 ;i < VASTAI_MAX_ENC_CORES; i++)
	{
		result = vastai_irq_register(pcie_dev, die_index, vastai_enc_irq[i], vastai_pci_enc_callback, (void *)&(device_handle->die));
		if(result)
			goto err;
	}

	for(i = 0 ;i < VASTAI_MAX_ENC_CORES; i++)
	{
		//INIT_LIST_HEAD(&(device_handle->die.venc_core_info[i].enc_chn_head));
		 for(index = 0; index < VASTAI_MAX_CORE_CHANNEL; index++)
		{
			device_handle->die.venc_core_info[i].enc_chn_set[index].core_id = 0;
			device_handle->die.venc_core_info[i].enc_chn_set[index].die_index = 0;
			device_handle->die.venc_core_info[i].enc_chn_set[index].instance_addr = 0;
			device_handle->die.venc_core_info[i].enc_chn_set[index].msg_addr = 0;
//			device_handle->die.venc_core_info[i].enc_chn_set[index].rcv = 0;
		}
	}

	do_work_mode_change(device_handle, SINGLE_CORE_MODE, true);

	atomic_set(&(device_handle->die.encoder_state), VIDEO_STATE_READY);

	VAVIDEO_INFO(pcie_dev, (u8)die_index,
		"hantroenc_normal_init exit %d\n",device_handle->die.die_index);

	return 0;

  err:
	if (device_handle && device_handle->die.vastaivcmd_data != NULL)
		vfree(device_handle->die.vastaivcmd_data);

	unregister_chrdev(hantroenc_major, "vc8000");

	device_destroy(encode_drv_class, MKDEV(hantroenc_major, 0));
	class_destroy(encode_drv_class);
	VAVIDEO_ERR(pcie_dev, (u8)die_index, "hantroenc: module not inserted\n");
	return result;
}
void  hantroenc_normal_cleanup(void* pcie_dev)
{
	struct list_head *p = NULL, *n = NULL;
	device_handle_t *device_handle_node = NULL;
	u32 die_index = 0;
	int value = 0;

	list_for_each_safe(p, n, &device_list_head) {
		device_handle_node = list_entry(p, device_handle_t, node);
		if (pcie_dev == device_handle_node->die.priv_dev) {
			list_del(&device_handle_node->node);
			die_index = device_handle_node->die.die_index;

			//clear encoder work mode flag, because vemcu will check it when re-insmode driver.
			vastai_pci_mem_write(device_handle_node->die.priv_dev, device_handle_node->die.die_index, ENCODER_WORKMODE_ADDR, &value, sizeof(value));

			mutex_destroy(&device_handle_node->chan_alloc_mutex);
			mutex_destroy(&device_handle_node->device_mutex);
			mutex_destroy(&device_handle_node->die.mutex);
			mutex_destroy(&device_handle_node->die.vastai_fifo_mutex);

			if (device_handle_node->die.vastaivcmd_data != NULL)
				vfree(device_handle_node->die.vastaivcmd_data);
			flush_workqueue(device_handle_node->die.workqueue);
			destroy_workqueue(device_handle_node->die.workqueue);

			kfree(device_handle_node);
			device_handle_node = NULL;
			VAVIDEO_INFO(pcie_dev, (u8)die_index, "hantroenc: die:%x removed\n", die_index);
		}
	}

	if (list_empty(&device_list_head)) {
		unregister_chrdev(hantroenc_major, "vc8000");
		device_destroy(encode_drv_class, MKDEV(hantroenc_major, 0));
		class_destroy(encode_drv_class);
		dwProbeInit = 0;
		hantroenc_major = 0;
		VAVIDEO_INFO(pcie_dev, (u8)die_index, "hantroenc: module removed\n");
	}

	return;
}

int hantroenc_init(void *pcie_dev, u32 die_index)
{
	return hantroenc_normal_init(pcie_dev, die_index);
}

void  hantroenc_cleanup(void *pcie_dev)
{
	hantroenc_normal_cleanup(pcie_dev);
}


