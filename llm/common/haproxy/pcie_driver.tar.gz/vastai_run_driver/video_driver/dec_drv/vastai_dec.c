/* 
 * vastai Decoder device driver (kernel module)
*
* Copyright (C) 2020  VeriSilicon Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#include <asm/io.h>
#include <linux/uaccess.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/semaphore.h>
#include <linux/spinlock.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/wait.h>
#include <linux/timer.h>
#include <linux/clk.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/types.h>
#include <linux/bitops.h>
#include <linux/mod_devicetable.h>

#include "vastaidec.h"
#include "vastai_pci.h"

#include "dwl_defs.h"
#include "subsys.h"
#include "vastaiaxife.h"

#include "vastai_vcmd.h"

//#define VASTAIDEC_DEBUG

#define PCI_VENDOR_ID_VASTAI_LOCAL      0x1ec6
#define PCI_DEVICE_ID_VASTAI_PCI        0x0100

/* Base address DDR register */
#define PCI_DDR_BAR 2

/* Base address got control register */
#define PCI_CONTROL_BAR                 0

/* PCIe VASTAI driver offset in control register */
#define VASTAI_REG_OFFSET0               0x2000000
#define VASTAI_REG_OFFSET1               0x700000

/* TODO(mheikkinen) Implement multicore support. */
struct pci_dev *gDev = NULL;     /* PCI device structure. */
unsigned long gBaseHdwr;         /* PCI base register address (Hardware address) */
unsigned long gBaseDDRHw;        /* PCI base register address (memalloc) */
unsigned long gBaseLen;          /* Base register address Length */

/* VASTAI G1 regs config including dec and pp */
//#define VASTAI_DEC_ORG_REGS             60
//#define VASTAI_PP_ORG_REGS              41

#define VASTAI_DEC_EXT_REGS             27
#define VASTAI_PP_EXT_REGS              9

//#define VASTAI_G1_DEC_TOTAL_REGS        (VASTAI_DEC_ORG_REGS + VASTAI_DEC_EXT_REGS)
#define VASTAI_PP_TOTAL_REGS            (VASTAI_PP_ORG_REGS + VASTAI_PP_EXT_REGS)
#define VASTAI_G1_DEC_REGS              155 /*G1 total regs*/

//#define VASTAI_DEC_ORG_FIRST_REG        0
//#define VASTAI_DEC_ORG_LAST_REG         59
//#define VASTAI_DEC_EXT_FIRST_REG        119
//#define VASTAI_DEC_EXT_LAST_REG         145

#define VASTAI_PP_ORG_FIRST_REG         60
#define VASTAI_PP_ORG_LAST_REG          100
#define VASTAI_PP_EXT_FIRST_REG         146
#define VASTAI_PP_EXT_LAST_REG          154

/* VASTAI G2 reg config */
#define VASTAI_G2_DEC_REGS              337 /*G2 total regs*/
#define VASTAI_G2_DEC_FIRST_REG         0
#define VASTAI_G2_DEC_LAST_REG          VASTAI_G2_DEC_REGS-1

/* VASTAI VC8000D reg config */
#define VASTAI_VC8000D_REGS             503 /*VC8000D total regs*/
#define VASTAI_VC8000D_FIRST_REG        0
#define VASTAI_VC8000D_LAST_REG         VASTAI_VC8000D_REGS-1
#define VASTAIDEC_HWBUILD_ID_OFF (309 * 4)

/* Logic module IRQs */
#define HXDEC_NO_IRQ                    -1

#define MAX(a, b)                       (((a) > (b)) ? (a) : (b))

#define DEC_IO_SIZE_MAX                 (MAX(MAX(VASTAI_G2_DEC_REGS, VASTAI_G1_DEC_REGS), VASTAI_VC8000D_REGS) * 4)

/* User should modify these configuration if do porting to own platform. */
/* Please guarantee the base_addr, io_size, dec_irq belong to same core. */

/* Defines use kernel clk cfg or not**/
//#define CLK_CFG
#ifdef CLK_CFG
#define CLK_ID                          "vastaidec_clk"  /*this id should conform with platform define*/
#endif

/* Logic module base address */
#define SOCLE_LOGIC_0_BASE              0x38300000
#define SOCLE_LOGIC_1_BASE              0x38310000

#define VEXPRESS_LOGIC_0_BASE           0xFC010000
#define VEXPRESS_LOGIC_1_BASE           0xFC020000

#define DEC_IO_SIZE_0                   DEC_IO_SIZE_MAX /* bytes */
#define DEC_IO_SIZE_1                   DEC_IO_SIZE_MAX /* bytes */

#define DEC_IRQ_0                       HXDEC_NO_IRQ
#define DEC_IRQ_1                       HXDEC_NO_IRQ

#define IS_G1(hw_id)                    (((hw_id) == 0x6731)? 1 : 0)
#define IS_G2(hw_id)                    (((hw_id) == 0x6732)? 1 : 0)
#define IS_VC8000D(hw_id)               (((hw_id) == 0x8001)? 1 : 0)
#define IS_BIGOCEAN(hw_id)              (((hw_id) == 0xB16D)? 1 : 0)

/* Some IPs HW configuration paramters for APB Filter */
/* Because now such information can't be read from APB filter configuration registers */
/* The fixed value have to be used */
#define VC8000D_NUM_MASK_REG            336
#define VC8000D_NUM_MODE                4
#define VC8000D_MASK_REG_OFFSET         4096
#define VC8000D_MASK_BITS_PER_REG       1

#define VC8000DJ_NUM_MASK_REG           332
#define VC8000DJ_NUM_MODE               1
#define VC8000DJ_MASK_REG_OFFSET        4096
#define VC8000DJ_MASK_BITS_PER_REG      1

#define AV1_NUM_MASK_REG                303
#define AV1_NUM_MODE                    1
#define AV1_MASK_REG_OFFSET             4096
#define AV1_MASK_BITS_PER_REG           1

#define AXIFE_NUM_MASK_REG              144
#define AXIFE_NUM_MODE                  1
#define AXIFE_MASK_REG_OFFSET           4096
#define AXIFE_MASK_BITS_PER_REG         1

/*************************************************************/

/*********************local variable declaration*****************/

static const int DecHwId[] = {
  0x6731, /* G1 */
  0x6732, /* G2 */
  0xB16D, /* BigOcean */
  0x8001  /* VC8000D */
};

unsigned long base_port = -1;
unsigned int pcie = 1;
volatile unsigned char *reg = NULL;
unsigned int reg_access_opt = 0;

extern unsigned int vcmd;


struct list_head vast_dec_head;

unsigned long multicorebase[HXDEC_MAX_CORES] = {
  VASTAI_REG_OFFSET0,
  VASTAI_REG_OFFSET1,
  0,
  0
};

int irq[HXDEC_MAX_CORES] = {
  DEC_IRQ_0,
  DEC_IRQ_1,
  -1,
  -1
};

unsigned int iosize[HXDEC_MAX_CORES] = {
  DEC_IO_SIZE_0,
  DEC_IO_SIZE_1,
  -1,
  -1
};

/* Because one core may contain multi-pipeline, so multicore base may be changed */
unsigned long multicorebase_actual[HXDEC_MAX_CORES];

struct subsys_config vpu_subsys[MAX_SUBSYS_NUM];

struct apbfilter_cfg apbfilter_cfg[MAX_SUBSYS_NUM][HW_CORE_MAX];

struct axife_cfg axife_cfg[MAX_SUBSYS_NUM];
int elements = 2;

#ifdef CLK_CFG
struct clk *clk_cfg;
int is_clk_on;
struct timer_list timer;
#endif

/* module_param(name, type, perm) */
module_param(base_port, ulong, 0);
module_param(pcie, uint, 0);
module_param_array(irq, int, &elements, 0644);
module_param_array(multicorebase, ulong, &elements, 0644);
module_param(reg_access_opt, uint, 0);
module_param(vcmd, uint, 0);

/* here's all the must remember stuff */
typedef struct {
	char *buffer;
	volatile unsigned int iosize[HXDEC_MAX_CORES];
	/* mapped address to different HW cores regs*/
	volatile u8 *hwregs[HXDEC_MAX_CORES][HW_CORE_MAX];
	/* mapped address to different HW cores regs*/
	volatile u8 *apbfilter_hwregs[HXDEC_MAX_CORES][HW_CORE_MAX];
	volatile int irq[HXDEC_MAX_CORES];
	int hw_id[HXDEC_MAX_CORES][HW_CORE_MAX];
	/* Requested client type for given core, used when a subsys has multiple
	 decoders, e.g., VC8000D+VC8000DJ+BigOcean */
	int client_type[HXDEC_MAX_CORES];
	int cores;
	struct fasync_struct *async_queue_dec;
	struct fasync_struct *async_queue_pp;
} vastaidec_t;

typedef struct {
  u32 cfg[HXDEC_MAX_CORES];              /* indicate the supported format */
  u32 cfg_backup[HXDEC_MAX_CORES];       /* back up of cfg */
  int its_main_core_id[HXDEC_MAX_CORES]; /* indicate if main core exist */
  int its_aux_core_id[HXDEC_MAX_CORES];  /* indicate if aux core exist */
} core_cfg;

static vastaidec_t vastaidec_data; /* dynamic allocation? */

#ifdef VASTAIDEC_DEBUG
static void dump_regs(vastaidec_t *dev);
static void dump_l2cache_regs(vastaidec_t *dev);
#endif

/* IRQ handler */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18))
static irqreturn_t vastaidec_isr(int irq, void *dev_id, struct pt_regs *regs);
#else
static irqreturn_t vastaidec_isr(int irq, void *dev_id);
#endif

static u32 dec_regs[HXDEC_MAX_CORES][DEC_IO_SIZE_MAX/4];
static u32 apbfilter_regs[HXDEC_MAX_CORES][DEC_IO_SIZE_MAX/4+1];
/* shadow_regs used to compare whether it's necessary to write to registers */
static u32 shadow_dec_regs[HXDEC_MAX_CORES][DEC_IO_SIZE_MAX/4];

struct semaphore dec_core_sem;
struct semaphore pp_core_sem;

static int dec_irq = 0;
static int pp_irq = 0;

atomic_t irq_rx = ATOMIC_INIT(0);
atomic_t irq_tx = ATOMIC_INIT(0);

static struct file* dec_owner[HXDEC_MAX_CORES];
static struct file* pp_owner[HXDEC_MAX_CORES];
static int CoreHasFormat(const u32 *cfg, int core, u32 format);

/* spinlock_t owner_lock = SPIN_LOCK_UNLOCKED; */
DEFINE_SPINLOCK(owner_lock);

DECLARE_WAIT_QUEUE_HEAD(dec_wait_queue);
DECLARE_WAIT_QUEUE_HEAD(pp_wait_queue);
DECLARE_WAIT_QUEUE_HEAD(hw_queue);
#ifdef CLK_CFG
DEFINE_SPINLOCK(clk_lock);
#endif

#define DWL_CLIENT_TYPE_H264_DEC        1U
#define DWL_CLIENT_TYPE_MPEG4_DEC       2U
#define DWL_CLIENT_TYPE_JPEG_DEC        3U
#define DWL_CLIENT_TYPE_PP              4U
#define DWL_CLIENT_TYPE_VC1_DEC         5U
#define DWL_CLIENT_TYPE_MPEG2_DEC       6U
#define DWL_CLIENT_TYPE_VP6_DEC         7U
#define DWL_CLIENT_TYPE_AVS_DEC         8U
#define DWL_CLIENT_TYPE_RV_DEC          9U
#define DWL_CLIENT_TYPE_VP8_DEC         10U
#define DWL_CLIENT_TYPE_VP9_DEC         11U
#define DWL_CLIENT_TYPE_HEVC_DEC        12U
#define DWL_CLIENT_TYPE_ST_PP           14U
#define DWL_CLIENT_TYPE_H264_MAIN10     15U
#define DWL_CLIENT_TYPE_AVS2_DEC        16U
#define DWL_CLIENT_TYPE_AV1_DEC         17U
#define DWL_CLIENT_TYPE_BO_AV1_DEC      31U

#define BIGOCEANDEC_CFG 1
#define BIGOCEANDEC_AV1_E 5

static core_cfg config;

static int CoreHasFormat(const u32 *cfg, int core, u32 format) {
  return (cfg[core] & (1 << format)) ? 1 : 0;
}

int GetDecCore(long core, vastaidec_t *dev, struct file* filp, unsigned long format) {
  int success = 0;
  unsigned long flags;

  spin_lock_irqsave(&owner_lock, flags);
  if(CoreHasFormat(config.cfg, core, format) && dec_owner[core] == NULL /*&& config.its_main_core_id[core] >= 0*/) {
    dec_owner[core] = filp;
    success = 1;

    /* If one main core takes one format which doesn't supported by aux core, set aux core's cfg to none video format support */
    if (config.its_aux_core_id[core] >= 0 &&
        !CoreHasFormat(config.cfg, config.its_aux_core_id[core], format)) {
      config.cfg[config.its_aux_core_id[core]] = 0;
    }
    /* If one aux core takes one format, set main core's cfg to aux core supported video format */
    else if (config.its_main_core_id[core] >= 0) {
      config.cfg[config.its_main_core_id[core]] = config.cfg[core];
    }
  }

  spin_unlock_irqrestore(&owner_lock, flags);

  return success;
}

int GetDecCoreAny(long *core, vastaidec_t *dev, struct file* filp,
                  unsigned long format) {
  int success = 0;
  long c;

  *core = -1;

  for(c = 0; c < dev->cores; c++) {
    /* a free core that has format */
    if(GetDecCore(c, dev, filp, format)) {
      success = 1;
      *core = c;
      break;
    }
  }

  return success;
}

int GetDecCoreID(vastaidec_t *dev, struct file* filp,
                 unsigned long format) {
  long c;
  unsigned long flags;

  int core_id = -1;

  for(c = 0; c < dev->cores; c++) {
    /* a core that has format */
    spin_lock_irqsave(&owner_lock, flags);
    if(CoreHasFormat(config.cfg, c, format)) {
      core_id = c;
      spin_unlock_irqrestore(&owner_lock, flags);
      break;
    }
    spin_unlock_irqrestore(&owner_lock, flags);
  }
  return core_id;
}

#if 0
static int vastaidec_choose_core(int is_g1) {
  volatile unsigned char *reg = NULL;
  unsigned int blk_base = 0x38320000;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec_choose_core\n");
  if (!request_mem_region(blk_base, 0x1000, "blk_ctl")) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "blk_ctl: failed to reserve HW regs\n");
    return -EBUSY;
  }

  reg = (volatile u8 *) ioremap_nocache(blk_base, 0x1000);

  if (reg == NULL ) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "blk_ctl: failed to ioremap HW regs\n");
    if (reg)
      iounmap((void *)reg);
    release_mem_region(blk_base, 0x1000);
    return -EBUSY;
  }

  // G1 use, set to 1; G2 use, set to 0, choose the one you are using
  if (is_g1)
    vastai_iowrite32(0x1, (void*)(reg + 0x14));  // VPUMIX only use G1, user should modify the reg according to platform design
  else
    vastai_iowrite32(0x0, (void*)(reg + 0x14)); // VPUMIX only use G2, user should modify the reg according to platform design

  if (reg)
    iounmap((void *)reg);
  release_mem_region(blk_base, 0x1000);
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec_choose_core OK!\n");
  return 0;
}
#endif

long ReserveDecoder(vastaidec_t *dev, struct file* filp, unsigned long format) {
  long core = -1;

  /* reserve a core */
  if (down_interruptible(&dec_core_sem))
    return -ERESTARTSYS;

  /* lock a core that has specific format*/
  if(wait_event_interruptible(hw_queue,
                              GetDecCoreAny(&core, dev, filp, format) != 0 ))
    return -ERESTARTSYS;

#if 0
  if(IS_G1(dev->hw_id[core])) {
    if (0 == vastaidec_choose_core(1))
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "G1 is reserved\n");
    else
      return -1;
  } else {
    if (0 == vastaidec_choose_core(0))
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "G2 is reserved\n");
    else
      return -1;
  }
#endif

  dev->client_type[core] = format;
  return core;
}

void ReleaseDecoder(vastaidec_t *dev, long core) {
  u32 status;
  unsigned long flags;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "ReleaseDecoder %ld\n", core);

  if (dev->client_type[core] == DWL_CLIENT_TYPE_BO_AV1_DEC)
    status = vastai_ioread32((void*)(dev->hwregs[core][HW_BIGOCEAN] + BIGOCEAN_IRQ_STAT_DEC_OFF));
  else
    status = vastai_ioread32((void*)(dev->hwregs[core][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));

  /* make sure HW is disabled */
  if(status & VASTAIDEC_DEC_E) {
    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: DEC[%li] still enabled -> reset\n", core);

    /* abort decoder */
    status |= VASTAIDEC_DEC_ABORT | VASTAIDEC_DEC_IRQ_DISABLE;
    vastai_iowrite32(status, (void*)(dev->hwregs[core][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));
  }

  spin_lock_irqsave(&owner_lock, flags);

  /* If aux core released, revert main core's config back */
  if (config.its_main_core_id[core] >= 0) {
    config.cfg[config.its_main_core_id[core]] = config.cfg_backup[config.its_main_core_id[core]];
  }

  /* If main core released, revert aux core's config back */
  if (config.its_aux_core_id[core] >= 0) {
    config.cfg[config.its_aux_core_id[core]] = config.cfg_backup[config.its_aux_core_id[core]];
  }

  dec_owner[core] = NULL;

  spin_unlock_irqrestore(&owner_lock, flags);

  up(&dec_core_sem);

  wake_up_interruptible_all(&hw_queue);
}

long ReservePostProcessor(vastaidec_t *dev, struct file* filp) {
  unsigned long flags;

  long core = 0;

  /* single core PP only */
  if (down_interruptible(&pp_core_sem))
    return -ERESTARTSYS;

  spin_lock_irqsave(&owner_lock, flags);

  pp_owner[core] = filp;

  spin_unlock_irqrestore(&owner_lock, flags);

  return core;
}

void ReleasePostProcessor(vastaidec_t *dev, long core) {
  unsigned long flags;

  u32 status = vastai_ioread32((void*)(dev->hwregs[core][HW_VC8000D] + VASTAI_IRQ_STAT_PP_OFF));

  /* make sure HW is disabled */
  if(status & VASTAI_PP_E) {
    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: PP[%li] still enabled -> reset\n", core);

    /* disable IRQ */
    status |= VASTAI_PP_IRQ_DISABLE;

    /* disable postprocessor */
    status &= (~VASTAI_PP_E);
    vastai_iowrite32(0x10, (void*)(dev->hwregs[core][HW_VC8000D] + VASTAI_IRQ_STAT_PP_OFF));
  }

  spin_lock_irqsave(&owner_lock, flags);

  pp_owner[core] = NULL;

  spin_unlock_irqrestore(&owner_lock, flags);

  up(&pp_core_sem);
}

long ReserveDecPp(vastaidec_t *dev, struct file* filp, unsigned long format) {
  /* reserve core 0, DEC+PP for pipeline */
  unsigned long flags;

  long core = 0;

  /* check that core has the requested dec format */
  if(!CoreHasFormat(config.cfg, core, format))
    return -EFAULT;

  /* check that core has PP */
  if(!CoreHasFormat(config.cfg, core, DWL_CLIENT_TYPE_PP))
    return -EFAULT;

  /* reserve a core */
  if (down_interruptible(&dec_core_sem))
    return -ERESTARTSYS;

  /* wait until the core is available */
  if(wait_event_interruptible(hw_queue,
                              GetDecCore(core, dev, filp, format) != 0)) {
    up(&dec_core_sem);
    return -ERESTARTSYS;
  }

  if (down_interruptible(&pp_core_sem)) {
    ReleaseDecoder(dev, core);
    return -ERESTARTSYS;
  }

  spin_lock_irqsave(&owner_lock, flags);
  pp_owner[core] = filp;
  spin_unlock_irqrestore(&owner_lock, flags);

  return core;
}

#ifdef VASTAIDEC_DEBUG
static u32 flush_count = 0; /* times of calling of DecFlushRegs */
static u32 flush_regs = 0;  /* total number of registers flushed */
#endif

long DecFlushRegs(vastaidec_t *dev, struct core_desc *core) {
  long ret = 0, i;
#ifdef VASTAIDEC_DEBUG
  int reg_wr = 2;
#endif
  u32 id = core->id;
  u32 type = core->type;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: DecFlushRegs\n");
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
                    core->id, core->type, core->size, core->reg_id);

  if (type == HW_VC8000D && !vpu_subsys[id].submodule_hwregs[type])
    type = HW_VC8000DJ;
  if (dev->client_type[id] == DWL_CLIENT_TYPE_BO_AV1_DEC)
    type = HW_BIGOCEAN;

  if (id >= MAX_SUBSYS_NUM ||
      !vpu_subsys[id].base_addr ||
      core->type >= HW_CORE_MAX ||
      !vpu_subsys[id].submodule_hwregs[type])
    return -EINVAL;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: submodule_iosize = %d\n", vpu_subsys[id].submodule_iosize[type]);

  ret = video_copy_from_user(dec_regs[id], core->regs, vpu_subsys[id].submodule_iosize[type]);
  if (ret) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", ret);
    return -EFAULT;
  }

#ifdef VASTAIDEC_DEBUG
  int index;
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "\n----------------------dump vcmd start-----------------");
  for(index = 0; index < DEC_IO_SIZE_MAX/4 - 4; index+=4){
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "\toffset %d: %08X %08X %08X %08X\n", index,
        dec_regs[id][index], dec_regs[id][index+1], dec_regs[id][index+2],dec_regs[id][index+3]);
  }
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "\toffset %d: ", index);
  for(;index < DEC_IO_SIZE_MAX/4; index++){
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, " %08X", dec_regs[id][index]);
  }
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "\n----------------------dump vcmd end-----------------"); 
#endif

  if (type == HW_VC8000D || type == HW_BIGOCEAN || type == HW_VC8000DJ) {
    /* write all regs but the status reg[1] to hardware */

    if (reg_access_opt) {//0
      for(i = 3; i < vpu_subsys[id].submodule_iosize[type]/4; i++) {

        /* check whether register value is updated. */
        if (dec_regs[id][i] != shadow_dec_regs[id][i]) {
          vastai_iowrite32(dec_regs[id][i], (void*)(dev->hwregs[id][type] + i*4));
          shadow_dec_regs[id][i] = dec_regs[id][i];
#ifdef VASTAIDEC_DEBUG
          reg_wr++;
#endif
        }
      }
    } else {
		for(i = 3; i < vpu_subsys[id].submodule_iosize[type]/4; i++) {
			vastai_iowrite32(dec_regs[id][i], (void*)(dev->hwregs[id][type] + i*4));
#ifdef VALIDATE_REGS_WRITE
			if (dec_regs[id][i] != vastai_ioread32((void*)(dev->hwregs[id][type] + i*4)))
				VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
						"vastaidec: swreg[%ld]: read %08x != write %08x *\n",
						i, vastai_ioread32((void*)(dev->hwregs[id][type] + i*4)), dec_regs[id][i]);
#endif
		}
#ifdef VASTAIDEC_DEBUG
      reg_wr = vpu_subsys[id].submodule_iosize[type]/4 - 1;
#endif
    }

    /* write swreg2 for AV1, in which bit0 is the start bit */
    vastai_iowrite32(dec_regs[id][2], (void*)(dev->hwregs[id][type] + 8));
    shadow_dec_regs[id][2] = dec_regs[id][2];
    /* write the status register, which may start the decoder */
    vastai_iowrite32(dec_regs[id][1], (void*)(dev->hwregs[id][type] + 4));
    shadow_dec_regs[id][1] = dec_regs[id][1];

#ifdef VASTAIDEC_DEBUG
    flush_count++;
    flush_regs += reg_wr;
#endif

    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "flushed registers on core %d\n", id);
#ifdef VASTAIDEC_DEBUG
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
           "%d DecFlushRegs: flushed %d/%d registers (dec_mode = %d, avg %d regs per flush)\n",
           flush_count, reg_wr, flush_regs, dec_regs[id][3]>>27, flush_regs/flush_count);
#endif
  } else {
    /* write all regs but the status reg[1] to hardware */
    for(i = 0; i < vpu_subsys[id].submodule_iosize[type]/4; i++) {
      vastai_iowrite32(dec_regs[id][i], (void*)(dev->hwregs[id][type] + i*4));
#ifdef VALIDATE_REGS_WRITE
      if (dec_regs[id][i] != vastai_ioread32((void*)(dev->hwregs[id][type] + i*4)))
        VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
               "vastaidec: swreg[%ld]: read %08x != write %08x *\n",
               i, vastai_ioread32((void*)(dev->hwregs[id][type] + i*4)), dec_regs[id][i]);
#endif
    }
  }

  return 0;
}

long DecWriteRegs(vastaidec_t *dev, struct core_desc *core)
{
  long ret = 0;
  u32 i = core->reg_id;
  u32 id = core->id;
  u32 type = core->type;

  /* PDEBUG("vastaidec: DecWriteRegs\n");
   * PDEBUG("vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
   *         core->id, core->type, core->size, core->reg_id); */
 

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: DecWriteRegs\n");
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
          core->id, core->type, core->size, core->reg_id); 

  if (type == HW_VC8000D && !vpu_subsys[id].submodule_hwregs[type])
    type = HW_VC8000DJ;
  if (dev->client_type[id] == DWL_CLIENT_TYPE_BO_AV1_DEC)
    type = HW_BIGOCEAN;

  if (id >= MAX_SUBSYS_NUM ||
      !vpu_subsys[id].base_addr ||
      type >= HW_CORE_MAX ||
      !vpu_subsys[id].submodule_hwregs[type] ||
      (core->size & 0x3) ||
      core->reg_id * 4 + core->size > vpu_subsys[id].submodule_iosize[type])
    return -EINVAL;

  ret = video_copy_from_user(dec_regs[id], core->regs, core->size);
  if (ret) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", ret);
    return -EFAULT;
  }

  for (i = core->reg_id; i < core->reg_id + core->size/4; i++) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, 
		" %s------>type=%d: write= %08x to reg[%d] core %d\n", __func__, core->type, dec_regs[id][i-core->reg_id], i, id);
    vastai_iowrite32(dec_regs[id][i-core->reg_id], (void*)(dev->hwregs[id][type] + i*4));
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, 
		" %s------>      read_val= %08x \n", __func__, vastai_ioread32((void*)(dev->hwregs[id][type] + i*4)));
    if (type == HW_VC8000D)
      shadow_dec_regs[id][i] = dec_regs[id][i-core->reg_id];
  }
  return 0;
}

long DecWriteApbFilterRegs(vastaidec_t *dev, struct core_desc *core)
{
  long ret = 0;
  u32 i = core->reg_id;
  u32 id = core->id;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: DecWriteApbFilterRegs\n");
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
          core->id, core->type, core->size, core->reg_id);

  if (id >= MAX_SUBSYS_NUM ||
      !vpu_subsys[id].base_addr ||
      core->type >= HW_CORE_MAX ||
      !vpu_subsys[id].submodule_hwregs[core->type] ||
      (core->size & 0x3) ||
      core->reg_id * 4 + core->size > vpu_subsys[id].submodule_iosize[core->type] + 4)
    return -EINVAL;

  ret = copy_from_user(apbfilter_regs[id], core->regs, core->size);
  if (ret) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", ret);
    return -EFAULT;
  }

  for (i = core->reg_id; i < core->reg_id + core->size/4; i++) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: write %08x to reg[%d] core %d\n", dec_regs[id][i-core->reg_id], i, id);
    vastai_iowrite32(apbfilter_regs[id][i-core->reg_id], (void*)(dev->apbfilter_hwregs[id][core->type] + i*4));
  }
  return 0;
}

long DecReadRegs(vastaidec_t *dev, struct core_desc *core)
{
  long ret;
  u32 id = core->id;
  u32 i = core->reg_id;
  u32 type = core->type;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: DecReadRegs\n");
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
          core->id, core->type, core->size, core->reg_id);

  if (type == HW_VC8000D && !vpu_subsys[id].submodule_hwregs[type])
    type = HW_VC8000DJ;
  if (dev->client_type[id] == DWL_CLIENT_TYPE_BO_AV1_DEC)
    type = HW_BIGOCEAN;

  if (id >= MAX_SUBSYS_NUM ||
      !vpu_subsys[id].base_addr ||
      type >= HW_CORE_MAX ||
      !vpu_subsys[id].submodule_hwregs[type] ||
      (core->size & 0x3) ||
      core->reg_id * 4 + core->size > vpu_subsys[id].submodule_iosize[type])
    return -EINVAL;

  /* read specific registers from hardware */
  for (i = core->reg_id; i < core->reg_id + core->size/4; i++) {
    dec_regs[id][i-core->reg_id] = vastai_ioread32((void*)(dev->hwregs[id][type] + i*4));
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: read %08x from reg[%d] core %d\n", dec_regs[id][i-core->reg_id], i, id);
    if (type == HW_VC8000D)
      shadow_dec_regs[id][i] = dec_regs[id][i];
  }

  /* put registers to user space*/
  ret = video_copy_to_user(core->regs, dec_regs[id], core->size);
  if (ret) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_to_user failed, returned %li\n", ret);
    return -EFAULT;
  }
  return 0;
}

long DecRefreshRegs(vastaidec_t *dev, struct core_desc *core) {
  long ret, i;
  u32 id = core->id;
  u32 type = core->type;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: DecRefreshRegs\n");
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: id = %d, type = %d, size = %d, reg_id = %d\n",
                    core->id, core->type, core->size, core->reg_id);

  if (type == HW_VC8000D && !vpu_subsys[id].submodule_hwregs[type])
    type = HW_VC8000DJ;
  if (dev->client_type[id] == DWL_CLIENT_TYPE_BO_AV1_DEC)
    type = HW_BIGOCEAN;

  if (id >= MAX_SUBSYS_NUM ||
      !vpu_subsys[id].base_addr ||
      type >= HW_CORE_MAX ||
      !vpu_subsys[id].submodule_hwregs[type])
    return -EINVAL;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec: submodule_iosize = %d\n", vpu_subsys[id].submodule_iosize[type]);

  if (!reg_access_opt) {
    for(i = 0; i < vpu_subsys[id].submodule_iosize[type]/4; i++) {
      dec_regs[id][i] = vastai_ioread32((void*)(dev->hwregs[id][type] + i*4));
    }
  } else {
    // only need to read swreg1,62(?),63,168,169
#define REFRESH_REG(idx) i = (idx); shadow_dec_regs[id][i] = dec_regs[id][i] = vastai_ioread32((void*)(dev->hwregs[id][type] + i*4))
    REFRESH_REG(0);
    REFRESH_REG(1);
    REFRESH_REG(62);
    REFRESH_REG(63);
    REFRESH_REG(168);
    REFRESH_REG(169);
#undef REFRESH_REG
  }
  ret = video_copy_to_user(core->regs, dec_regs[id], vpu_subsys[id].submodule_iosize[type]);
  if (ret) {
    VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_to_user failed, returned %li\n", ret);
    return -EFAULT;
  }
  return 0;
}

static int CheckDecIrq(vastaidec_t *dev, int id) {
  unsigned long flags;
  int rdy = 0;

  const u32 irq_mask = (1 << id);

  spin_lock_irqsave(&owner_lock, flags);

  if(dec_irq & irq_mask) {
    /* reset the wait condition(s) */
    dec_irq &= ~irq_mask;
    rdy = 1;
  }

  spin_unlock_irqrestore(&owner_lock, flags);

  return rdy;
}

long WaitDecReadyAndRefreshRegs(vastaidec_t *dev, struct core_desc *core) {
  u32 id = core->id;
  long ret;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "wait_event_interruptible DEC[%d]\n", id);
#ifdef USE_SW_TIMEOUT
  u32 status;
  ret = wait_event_interruptible_timeout(dec_wait_queue, CheckDecIrq(dev, id), msecs_to_jiffies(2000));
  if(ret < 0) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "DEC[%d]  wait_event_interruptible interrupted\n", id);
    return -ERESTARTSYS;
  } else if (ret == 0) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "DEC[%d]  wait_event_interruptible timeout\n", id);
    status = vastai_ioread32((void*)(dev->hwregs[id][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));
    /* check if HW is enabled */
    if(status & VASTAIDEC_DEC_E) {
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: DEC[%d] reset becuase of timeout\n", id);

      /* abort decoder */
      status |= VASTAIDEC_DEC_ABORT | VASTAIDEC_DEC_IRQ_DISABLE;
      vastai_iowrite32(status, (void*)(dev->hwregs[id][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));
    }
  }
#else
  ret = wait_event_interruptible(dec_wait_queue, CheckDecIrq(dev, id));
  if(ret) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "DEC[%d]  wait_event_interruptible interrupted\n", id);
    return -ERESTARTSYS;
  }
#endif
  atomic_inc(&irq_tx);

  /* refresh registers */
  return DecRefreshRegs(dev, core);
}

static int CheckCoreIrq(vastaidec_t *dev, const struct file *filp, int *id) {
  unsigned long flags;
  int rdy = 0, n = 0;

  do {
    u32 irq_mask = (1 << n);

    spin_lock_irqsave(&owner_lock, flags);

    if(dec_irq & irq_mask) {
      if (dec_owner[n] == filp) {
        /* we have an IRQ for our client */

        /* reset the wait condition(s) */
        dec_irq &= ~irq_mask;

        /* signal ready core no. for our client */
        *id = n;

        rdy = 1;

        spin_unlock_irqrestore(&owner_lock, flags);
        break;
      } else if(dec_owner[n] == NULL) {
        /* zombie IRQ */
        VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "IRQ on core[%d], but no owner!!!\n", n);

        /* reset the wait condition(s) */
        dec_irq &= ~irq_mask;
      }
    }

    spin_unlock_irqrestore(&owner_lock, flags);

    n++; /* next core */
  } while(n < dev->cores);

  return rdy;
}

long WaitCoreReady(vastaidec_t *dev, const struct file *filp, int *id) {
  long ret;
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "wait_event_interruptible CORE\n");
#ifdef USE_SW_TIMEOUT
  u32 i, status;
  ret = wait_event_interruptible_timeout(dec_wait_queue, CheckCoreIrq(dev, filp, id), msecs_to_jiffies(2000));
  if(ret < 0) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "CORE  wait_event_interruptible interrupted\n");
    return -ERESTARTSYS;
  } else if (ret == 0) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "CORE  wait_event_interruptible timeout\n");
    for(i = 0; i < dev->cores; i++) {
      status = vastai_ioread32((void*)(dev->hwregs[i][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));
      /* check if HW is enabled */
      if((status & VASTAIDEC_DEC_E) && dec_owner[i] == filp) {
        VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: CORE[%d] reset becuase of timeout\n", i);
        *id = i;
        /* abort decoder */
        status |= VASTAIDEC_DEC_ABORT | VASTAIDEC_DEC_IRQ_DISABLE;
        vastai_iowrite32(status, (void*)(dev->hwregs[i][HW_VC8000D] + VASTAIDEC_IRQ_STAT_DEC_OFF));
        break;
      }
    }
  }
#else
  ret = wait_event_interruptible(dec_wait_queue, CheckCoreIrq(dev, filp, id));
  if(ret) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "CORE[%d] wait_event_interruptible interrupted with 0x%lx\n", *id, ret);
    return -ERESTARTSYS;
  }
#endif
  atomic_inc(&irq_tx);

  return 0;
}

/*------------------------------------------------------------------------------
 Function name   : vastaidec_ioctl
 Description     : communication method to/from the user space

 Return type     : long
------------------------------------------------------------------------------*/

long vastaidec_ioctl(struct file *filp, unsigned int cmd,
                            unsigned long arg) 
{
  int err = 0;
  long tmp;
#ifdef CLK_CFG
  unsigned long flags;
#endif

#ifdef HW_PERFORMANCE
  struct timeval *end_time_arg;
#endif

  //PDEBUG("ioctl cmd 0x%08x\n", cmd);
  /*
   * extract the type and number bitfields, and don't decode
   * wrong cmds: return ENOTTY (inappropriate ioctl) before access_ok()
   */
  if (_IOC_TYPE(cmd) != VASTAIDEC_IOC_MAGIC &&
      _IOC_TYPE(cmd) != VASTAI_VCMD_IOC_MAGIC)
    return -ENOTTY;
  if ((_IOC_TYPE(cmd) == VASTAIDEC_IOC_MAGIC &&
      _IOC_NR(cmd) > VASTAIDEC_IOC_MAXNR) ||
      (_IOC_TYPE(cmd) == VASTAI_VCMD_IOC_MAGIC &&
      _IOC_NR(cmd) > VASTAI_VCMD_IOC_MAXNR))
    return -ENOTTY;


#ifdef CLK_CFG
  spin_lock_irqsave(&clk_lock, flags);
  if (clk_cfg!=NULL && !IS_ERR(clk_cfg)&&(is_clk_on==0)) {
    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "turn on clock by user\n");
    if (clk_enable(clk_cfg)) {
      spin_unlock_irqrestore(&clk_lock, flags);
      return -EFAULT;
    } else
      is_clk_on=1;
  }
  spin_unlock_irqrestore(&clk_lock, flags);
  mod_timer(&timer, jiffies + 10*HZ); /*the interval is 10s*/
#endif

  switch (cmd) {
  case VASTAIDEC_IOC_CLI: {
    __u32 id;
    __get_user(id, (__u32*)arg);

    if(id >= vastaidec_data.cores) {
      return -EFAULT;
    }
    disable_irq(vastaidec_data.irq[id]);
    break;
  }
  case VASTAIDEC_IOC_STI: {
    __u32 id;
    __get_user(id, (__u32*)arg);

    if(id >= vastaidec_data.cores) {
      return -EFAULT;
    }
    enable_irq(vastaidec_data.irq[id]);
    break;
  }
  case VASTAIDEC_IOCGHWOFFSET: {
    __u32 id;
    __get_user(id, (__u32*)arg);

    if(id >= vastaidec_data.cores) {
      return -EFAULT;
    }

    __put_user(multicorebase_actual[id], (unsigned long *) arg);
    break;
  }
  case VASTAIDEC_IOCGHWIOSIZE: {
    struct regsize_desc core;

    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct regsize_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    if(core.id >= MAX_SUBSYS_NUM /*vastaidec_data.cores*/) {
      return -EFAULT;
    }

    if (core.type == HW_SHAPER) {
      u32 asic_id;
      /* Shaper is configured with l2cache. */
      if (vpu_subsys[core.id].submodule_hwregs[HW_L2CACHE]) {
        asic_id = vastai_ioread32((void*)vpu_subsys[core.id].submodule_hwregs[HW_L2CACHE]);
        switch ((asic_id >> 16) & 0x3) {
        case 1: /* cache only */
          core.size = 0; break;
        case 0: /* cache + shaper */
        case 2: /* shaper only*/
          core.size = vpu_subsys[core.id].submodule_iosize[HW_L2CACHE];
          break;
        default:
          return -EFAULT;
        }
      } else
        core.size = 0;
    } else {
      core.size = vpu_subsys[core.id].submodule_iosize[core.type];
      if (core.type == HW_VC8000D && !core.size &&
          vpu_subsys[core.id].submodule_hwregs[HW_VC8000DJ]) {
        /* If VC8000D doesn't exists, while VC8000DJ exists, return VC8000DJ. */
        core.size = vpu_subsys[core.id].submodule_iosize[HW_VC8000DJ];
      }
    }
	if (video_copy_to_user((u32 *) arg, &core, sizeof(struct regsize_desc))) {
		return -EFAULT;
	}

    return 0;
  }
  case VASTAIDEC_IOC_MC_OFFSETS: {
    tmp = video_copy_to_user((unsigned long *) arg, multicorebase_actual, sizeof(multicorebase_actual));
    if (err) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_to_user failed, returned %li\n", tmp);
      return -EFAULT;
    }
    break;
  }
  case VASTAIDEC_IOC_MC_CORES:
    __put_user(vastaidec_data.cores, (unsigned int *) arg);
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "vastaidec_data.cores=%d\n", vastaidec_data.cores);
    break;
  case VASTAIDEC_IOCS_DEC_PUSH_REG: {
    struct core_desc core;

    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return DecFlushRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCS_DEC_WRITE_REG: {
    struct core_desc core;
    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return DecWriteRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCS_DEC_WRITE_APBFILTER_REG: {
    struct core_desc core;

    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return DecWriteApbFilterRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCS_PP_PUSH_REG: {
    return EINVAL;
  }
  case VASTAIDEC_IOCS_DEC_PULL_REG: {
    struct core_desc core;

    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return DecRefreshRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCS_DEC_READ_REG: {
    struct core_desc core;

    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return DecReadRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCS_PP_PULL_REG: {
    return EINVAL;
  }
  case VASTAIDEC_IOCH_DEC_RESERVE: {
    u32 format = 0;
    __get_user(format, (unsigned long *)arg);
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "Reserve DEC core, format = %d\n", format);
    return ReserveDecoder(&vastaidec_data, filp, format);
  }
  case VASTAIDEC_IOCT_DEC_RELEASE: {
    u32 core = 0;
    __get_user(core, (unsigned long *)arg);
    if(core >= vastaidec_data.cores || dec_owner[core] != filp) {
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "bogus DEC release, core = %d\n", core);
      return -EFAULT;
    }

    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "Release DEC, core = %d\n", core);

    ReleaseDecoder(&vastaidec_data, core);

    break;
  }
  case VASTAIDEC_IOCQ_PP_RESERVE:
#if 0
    return ReservePostProcessor(&vastaidec_data, filp);
#else
    return EINVAL;
#endif
  case VASTAIDEC_IOCT_PP_RELEASE: {
#if 0
    if(arg != 0 || pp_owner[arg] != filp) {
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "bogus PP release %li\n", arg);
      return -EFAULT;
    }

    ReleasePostProcessor(&vastaidec_data, arg);
    break;
#else
    return EINVAL;
#endif
  }
  case VASTAIDEC_IOCX_DEC_WAIT: {
    struct core_desc core;

    /* get registers from user space */
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_desc));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    return WaitDecReadyAndRefreshRegs(&vastaidec_data, &core);
  }
  case VASTAIDEC_IOCX_PP_WAIT: {
    return EINVAL;
  }
  case VASTAIDEC_IOCG_CORE_WAIT: {
    int id;
    tmp = WaitCoreReady(&vastaidec_data, filp, &id);
    __put_user(id, (int *) arg);
	return tmp;
  }
  case VASTAIDEC_IOX_ASIC_ID: {
    struct core_param core;
    /* get registers from user space*/
    tmp = video_copy_from_user(&core, (void*)arg, sizeof(struct core_param));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    if (core.id >= MAX_SUBSYS_NUM /*vastaidec_data.cores*/ ||
       ((core.type == HW_VC8000D || core.type == HW_VC8000DJ) &&
        !vpu_subsys[core.id].submodule_iosize[core.type == HW_VC8000D] &&
        !vpu_subsys[core.id].submodule_iosize[core.type == HW_VC8000DJ]) ||
       ((core.type != HW_VC8000D && core.type != HW_VC8000DJ) &&
        !vpu_subsys[core.id].submodule_iosize[core.type])) {
      return -EFAULT;
    }

    core.size = vpu_subsys[core.id].submodule_iosize[core.type];
    if (vpu_subsys[core.id].submodule_hwregs[core.type])
      core.asic_id = vastai_ioread32((void*)vastaidec_data.hwregs[core.id][core.type]);
    else if (core.type == HW_VC8000D &&
             vastaidec_data.hwregs[core.id][HW_VC8000DJ]) {
      core.asic_id = vastai_ioread32((void*)vastaidec_data.hwregs[core.id][HW_VC8000DJ]);
    } else
      core.asic_id = 0;

	if (video_copy_to_user((u32 *) arg, &core, sizeof(struct core_param))) {
		return -EFAULT;
	}

    return 0;
  }
  case VASTAIDEC_IOCG_CORE_ID: {
    u32 format = 0;
    __get_user(format, (u32 *)arg);

    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "Get DEC Core_id, format = %d\n", format);
    return GetDecCoreID(&vastaidec_data, filp, format);
  }
  case VASTAIDEC_IOX_ASIC_BUILD_ID: {
    u32 id, hw_id;
    __get_user(id, (u32*)arg);

    if(id >= vastaidec_data.cores) {
      return -EFAULT;
    }
    if (vastaidec_data.hwregs[id][HW_VC8000D] ||
        vastaidec_data.hwregs[id][HW_VC8000DJ]) {
      volatile u8 *hwregs;
      /* VC8000D first if it exists, otherwise VC8000DJ. */
      if (vastaidec_data.hwregs[id][HW_VC8000D])
        hwregs = vastaidec_data.hwregs[id][HW_VC8000D];
      else
        hwregs = vastaidec_data.hwregs[id][HW_VC8000DJ];
      hw_id = vastai_ioread32((void*)hwregs);
      if (IS_G1(hw_id >> 16) || IS_G2(hw_id >> 16) ||
          (IS_VC8000D(hw_id >> 16) && ((hw_id & 0xFFFF) == 0x6010)))
        __put_user(hw_id, (u32 *) arg);
      else {
        hw_id = vastai_ioread32((void*)(hwregs + VASTAIDEC_HW_BUILD_ID_OFF));
        __put_user(hw_id, (u32 *) arg);
      }
    } else if (vastaidec_data.hwregs[id][HW_BIGOCEAN]) {
      hw_id = vastai_ioread32((void*)(vastaidec_data.hwregs[id][HW_BIGOCEAN]));
      if (IS_BIGOCEAN(hw_id >> 16))
        __put_user(hw_id, (u32 *) arg);
      else
        return -EFAULT;
    }
    return 0;
  }
  case VASTAIDEC_DEBUG_STATUS: {
    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: dec_irq     = 0x%08x \n", dec_irq);
    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: pp_irq      = 0x%08x \n", pp_irq);

    VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: IRQs received/sent2user = %d / %d \n",
           atomic_read(&irq_rx), atomic_read(&irq_tx));

    for (tmp = 0; tmp < vastaidec_data.cores; tmp++) {
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: dec_core[%li] %s\n",
             tmp, dec_owner[tmp] == NULL ? "FREE" : "RESERVED");
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "vastaidec: pp_core[%li]  %s\n",
             tmp, pp_owner[tmp] == NULL ? "FREE" : "RESERVED");
    }
    return 0;
  }
  case VASTAIDEC_IOX_SUBSYS: {
    struct subsys_desc subsys = {0};
    /* TODO(min): check all the subsys */
    if (vcmd) {
      subsys.subsys_vcmd_num = 1;
      subsys.subsys_num = subsys.subsys_vcmd_num;
    } else {
      subsys.subsys_num = vastaidec_data.cores;
      subsys.subsys_vcmd_num = 0;
    }
	if (video_copy_to_user((u32 *) arg, &subsys, sizeof(struct subsys_desc))) {
		return -EFAULT;
	}
    return 0;
  }
  case VASTAIDEC_IOCX_POLL: {
	vastaidec_isr(0, &vastaidec_data);
    return 0;
  }
  case VASTAIDEC_IOC_APBFILTER_CONFIG: {
    struct apbfilter_cfg tmp_apbfilter;

    /* get registers from user space*/
    tmp = video_copy_from_user(&tmp_apbfilter, (void*)arg, sizeof(struct apbfilter_cfg));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    if(tmp_apbfilter.id >= MAX_SUBSYS_NUM || tmp_apbfilter.type >= HW_CORE_MAX) {
      return -EFAULT;
    }
   
    apbfilter_cfg[tmp_apbfilter.id][tmp_apbfilter.type].id = tmp_apbfilter.id;
    apbfilter_cfg[tmp_apbfilter.id][tmp_apbfilter.type].type = tmp_apbfilter.type;
 
    memcpy(&tmp_apbfilter, &(apbfilter_cfg[tmp_apbfilter.id][tmp_apbfilter.type]), sizeof(struct apbfilter_cfg));

	if (video_copy_to_user((u32 *) arg, &tmp_apbfilter, sizeof(struct apbfilter_cfg))) {
		return -EFAULT;
	}

    return 0;
  }
  case VASTAIDEC_IOC_AXIFE_CONFIG: {
    struct axife_cfg tmp_axife;

    /* get registers from user space*/
    tmp = video_copy_from_user(&tmp_axife, (void*)arg, sizeof(struct axife_cfg));
    if (tmp) {
      VAVIDEO_ERR(NULL, DUMMY_DIE_ID, "copy_from_user failed, returned %li\n", tmp);
      return -EFAULT;
    }

    if(tmp_axife.id >= MAX_SUBSYS_NUM) {
      return -EFAULT;
    }

    axife_cfg[tmp_axife.id].id = tmp_axife.id;
    memcpy(&tmp_axife, &(axife_cfg[tmp_axife.id]), sizeof(struct axife_cfg));
	if (video_copy_to_user((u32 *) arg, &tmp_axife, sizeof(struct axife_cfg))) {
		return -EFAULT;
	}

    return 0;
  }
  default: 
    if (_IOC_TYPE(cmd) == VASTAI_VCMD_IOC_MAGIC) {
        return (vastaivcmd_ioctl(filp, cmd, arg));
    }
    return -ENOTTY;
  }

  return 0;
}

/*------------------------------------------------------------------------------
 Function name   : vastaidec_open
 Description     : open method

 Return type     : int
------------------------------------------------------------------------------*/
int vastaidec_open(struct inode *inode, struct file *filp) {
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "dev opened\n");
  if (vcmd)
    vastaivcmd_open(inode, filp);

  return 0;
}





#ifdef CLK_CFG
void vastaidec_disable_clk(unsigned long value) {
  unsigned long flags;
  /*entering this function means decoder is idle over expiry.So disable clk*/
  if (clk_cfg!=NULL && !IS_ERR(clk_cfg)) {
    spin_lock_irqsave(&clk_lock, flags);
    if (is_clk_on==1) {
      clk_disable(clk_cfg);
      is_clk_on = 0;
      VAVIDEO_INFO(NULL, DUMMY_DIE_ID, "turned off vastaidec clk\n");
    }
    spin_unlock_irqrestore(&clk_lock, flags);
  }
}
#endif

#if 0
/* VFS methods */
static struct file_operations vastaidec_fops = {
  .owner = THIS_MODULE,
  .open = vastaidec_open,
  .release = vastaidec_release,
  .unlocked_ioctl = vastaidec_ioctl,
  .fasync = NULL
};
#endif


/*------------------------------------------------------------------------------
 Function name   : vastaidec_isr
 Description     : interrupt handler

 Return type     : irqreturn_t
------------------------------------------------------------------------------*/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18))
irqreturn_t vastaidec_isr(int irq, void *dev_id, struct pt_regs *regs)
#else
irqreturn_t vastaidec_isr(int irq, void *dev_id)
#endif
{
  unsigned long flags;
  unsigned int handled = 0;
  int i;
  volatile u8 *hwregs;

  vastaidec_t *dev = (vastaidec_t *) dev_id;
  u32 irq_status_dec;

  spin_lock_irqsave(&owner_lock, flags);

  for(i=0; i<dev->cores; i++) {
    volatile u8 *hwregs = dev->hwregs[i][HW_VC8000D];

    /* interrupt status register read */
    irq_status_dec = vastai_ioread32((void*)(hwregs + VASTAIDEC_IRQ_STAT_DEC_OFF));

    if(irq_status_dec & VASTAIDEC_DEC_IRQ) {
      /* clear dec IRQ */
      irq_status_dec &= (~VASTAIDEC_DEC_IRQ);
      vastai_iowrite32(irq_status_dec, (void*)(hwregs + VASTAIDEC_IRQ_STAT_DEC_OFF));

      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "decoder IRQ received! core %d\n", i);

      atomic_inc(&irq_rx);

      dec_irq |= (1 << i);

      wake_up_interruptible_all(&dec_wait_queue);
      handled++;
    }
  }

  spin_unlock_irqrestore(&owner_lock, flags);

  if(!handled) {
    VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "IRQ received, but not vastaidec's!\n");
  }

  (void)hwregs;
  return IRQ_RETVAL(handled);
}

/*------------------------------------------------------------------------------
 Function name   : dump_regs
 Description     : Dump registers

 Return type     :
------------------------------------------------------------------------------*/
#ifdef VASTAIDEC_DEBUG
void dump_regs(vastaidec_t *dev) {
  int i,c;

  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "Reg Dump Start\n");
  for(c = 0; c < dev->cores; c++) {
    for(i = 0; i < dev->iosize[c]; i += 4*4) {
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
             "\toffset %04X: %08X  %08X  %08X  %08X\n", i,
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 4),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 16),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 24));
    }
  }
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "Reg Dump End\n");
}




void dump_l2cache_regs(vastaidec_t *dev)
{
  int i, c;
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "L2cache Reg Dump start\n");
  for(c = 0; c < dev->cores; c++) {
    for(i = 0; i <  vpu_subsys[c].submodule_iosize[HW_L2CACHE]; i += 4*4) {
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID,
             "\toffset %04X: %08X  %08X  %08X  %08X\n", i,
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 4),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 16),
             vastai_ioread32(dev->hwregs[c][HW_VC8000D] + i + 24));
    }
  }
  VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "L2cache Reg Dump end\n");
}

#endif
