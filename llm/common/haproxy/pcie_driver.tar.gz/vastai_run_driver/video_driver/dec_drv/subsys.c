/* 
 * Vastai Decoder device driver (kernel module)
*
* Copyright (C) 2020 VASTAI  Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#include "subsys.h"
#include "vastai_vcmd.h"

/******************************************************************************/
/* subsystem configuration                                                    */
/******************************************************************************/

/* List of subsystems */
struct SubsysDesc subsys_array[] = {
  /* {slice_index, index, base} */
  {0, 0, 0x2000000},
  {0, 1, 0x2100000},
  {0, 2, 0x2200000},
  {0, 3, 0x2300000},
  {0, 4, 0x2400000},
//  {0, 1, 0x700000}
};

/* List of all HW cores. */
struct CoreDesc core_array[] = {
  /* {slice, subsys, core_type, offset, iosize, irq, has_apbfilter} */
#if 0
  {0, 0, HW_VC8000DJ, 0x600000, 0, 0},
  {0, 0, HW_VC8000D, 0x602000, 0, 0},
  {0, 0, HW_L2CACHE, 0x604000, 0, 0},
  {0, 0, HW_DEC400, 0x606000, 0, 0},
  {0, 0, HW_BIGOCEAN, 0x608000, 0, 0},
  {0, 0, HW_NOC,0x60a000, 0, 0},
  {0, 0, HW_AXIFE, 0x60c000, 0, 0}
#endif
  {0, 0, HW_VCMD, 0x0, 27*4, -1},
  {0, 0, HW_VC8000D, 0x1000, 508*4, -1, 1},
  {0, 0, HW_L2CACHE, 0x2000, 231*4, -1, 0},

  {0, 1, HW_VCMD, 0x0, 27*4, -1},
  {0, 1, HW_VC8000D, 0x1000, 508*4, -1, 1},
  {0, 1, HW_L2CACHE, 0x2000, 231*4, -1, 0},
  {0, 2, HW_VCMD, 0x0, 27*4, -1},
  {0, 2, HW_VC8000D, 0x1000, 508*4, -1, 1},
  {0, 2, HW_L2CACHE, 0x2000, 231*4, -1, 0},

  {0, 3, HW_VCMD, 0x0, 27*4, -1},
  {0, 3, HW_VC8000D, 0x1000, 508*4, -1, 1},
  {0, 3, HW_L2CACHE, 0x2000, 231*4, -1, 0},
  {0, 4, HW_VCMD, 0x0, 27*4, -1},
  {0, 4, HW_VC8000D, 0x1000, 508*4, -1, 1},
  {0, 4, HW_L2CACHE, 0x2000, 231*4, -1, 0},

};

extern struct vcmd_config vcmd_core_array[MAX_SUBSYS_NUM];
extern int total_vcmd_core_num;
extern unsigned long multicorebase[];
extern int irq[];
extern unsigned int iosize[];
extern int reg_count[];

/*
   If VCMD is used, convert core_array to vcmd_core_array, which are used in
   hantor_vcmd.c.
   Otherwise, covnert core_array to multicore_base/irq/iosize, which are used in
   vastai_dec.c

   VCMD:
        - struct vcmd_config vcmd_core_array[MAX_SUBSYS_NUM]
        - total_vcmd_core_num

   NON-VCMD:
        - multicorebase[HXDEC_MAX_CORES]
        - irq[HXDEC_MAX_CORES]
        - iosize[HXDEC_MAX_CORES]
*/
void CheckSubsysCoreArray(void *die, struct subsys_config *subsys, int *vcmd)
{
  int num = sizeof(subsys_array)/sizeof(subsys_array[0]);
  int i, j;
  struct die_info *die_info = (struct die_info *)die;
  BUG_ON(!die_info);

  memset(subsys, 0, sizeof(subsys[0]) * MAX_SUBSYS_NUM);
  for (i = 0; i < num; i++) {
    subsys[i].base_addr = subsys_array[i].base;
    subsys[i].irq = -1;
    for (j = 0; j < HW_CORE_MAX; j++) {
      subsys[i].submodule_offset[j] = 0xffff;
      subsys[i].submodule_iosize[j] = 0;
      subsys[i].submodule_hwregs[j] = NULL;
    }
  }

  total_vcmd_core_num = 0;

  for (i = 0; i < sizeof(core_array)/sizeof(core_array[0]); i++) {
    if (!subsys[core_array[i].subsys].base_addr) {
      /* undefined subsystem */
      continue;
    }
    subsys[core_array[i].subsys].submodule_offset[core_array[i].core_type]
                                  = core_array[i].offset;
    subsys[core_array[i].subsys].submodule_iosize[core_array[i].core_type]
                                  = core_array[i].iosize;
    if (subsys[core_array[i].subsys].irq != -1 && core_array[i].irq != -1) {
      if (subsys[core_array[i].subsys].irq != core_array[i].irq) {
        VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
			"vastaidec: hw core type %d irq %d != subsystem irq %d\n",
			core_array[i].core_type,
			core_array[i].irq,
			subsys[core_array[i].subsys].irq);
		VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
			"vastaidec: hw cores of a subsystem should have same irq\n");
      } else {
        subsys[core_array[i].subsys].irq = core_array[i].irq;
      }
    }
    subsys[core_array[i].subsys].has_apbfilter[core_array[i].core_type] = core_array[i].has_apb; 
    /* vcmd found */
    if (core_array[i].core_type == HW_VCMD) {
      *vcmd = 1;
      total_vcmd_core_num++;
    }
  }

  VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
  		"vastaidec: vcmd_flag=%d  vcmd_core_num=%d\n", *vcmd, total_vcmd_core_num);

#if 0
  printk(" -------------------------HW_L2CACHE_info----------------------------- \n");
  printk("++++%s------->subsys[core_array[2].subsys].submodule_offset[core_array[2].core_type]=0x%x  \n", __func__, subsys[core_array[2].subsys].submodule_offset[core_array[2].core_type]);
  printk("++++%s------->subsys[core_array[2].subsys].submodule_iosize[core_array[2].core_type]=0x%x  \n", __func__, subsys[core_array[2].subsys].submodule_iosize[core_array[2].core_type]);
  printk("++++%s------->subsys[core_array[2].subsys].has_apbfilter[core_array[2].core_type]=0x%x  \n", __func__,    subsys[core_array[2].subsys].has_apbfilter[core_array[2].core_type]);
  printk(" --------------------------------------------------------------------- \n");
#endif

  /* To plug into vastai_vcmd.c */
  if (*vcmd) {
    for (i = 0; i < total_vcmd_core_num; i++) {
      vcmd_core_array[i].vcmd_base_addr = subsys[i].base_addr;
      vcmd_core_array[i].vcmd_iosize = subsys[i].submodule_iosize[HW_VCMD];
      vcmd_core_array[i].vcmd_irq = subsys[i].irq;
      vcmd_core_array[i].sub_module_type = 2;//decoder /* TODO(min): to be fixed */
      vcmd_core_array[i].submodule_main_addr = subsys[i].submodule_offset[HW_VC8000D];
      vcmd_core_array[i].submodule_dec400_addr = subsys[i].submodule_offset[HW_DEC400];
      vcmd_core_array[i].submodule_L2Cache_addr = subsys[i].submodule_offset[HW_L2CACHE];
      vcmd_core_array[i].submodule_MMU_addr = subsys[i].submodule_offset[HW_MMU];
      vcmd_core_array[i].submodule_MMUWrite_addr = subsys[i].submodule_offset[HW_MMU_WR];
      vcmd_core_array[i].submodule_axife_addr = subsys[i].submodule_offset[HW_AXIFE];
    }
  }
  memset(multicorebase, 0, sizeof(multicorebase[0]) * HXDEC_MAX_CORES);
  for (i = 0; i < num; i++) {
    multicorebase[i] = subsys[i].base_addr + subsys[i].submodule_offset[HW_VC8000D];
    irq[i] = subsys[i].irq;
    iosize[i] = subsys[i].submodule_iosize[HW_VC8000D];
    VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
		"vastaidec: core:[%d] multicorebase 0x%08lx, iosize %d\n", i, multicorebase[i], iosize[i]);
  }
}


