#ifndef __PCIE_H__
#define __PCIE_H__

#include <linux/pci.h>


extern struct pci_dev *gDev;     /* PCI device structure. */
extern unsigned long gBaseHdwr;         /* PCI base register address (Hardware address) */
extern unsigned long gBaseDDRHw;        /* PCI base register address (memalloc) */
extern u32  gBaseLen;                   /* Base register address Length */
extern unsigned int pcie;

int PcieInit(void);

static inline void disable_pcie_dev(void)
{
	pci_disable_device(gDev);
}

#endif
