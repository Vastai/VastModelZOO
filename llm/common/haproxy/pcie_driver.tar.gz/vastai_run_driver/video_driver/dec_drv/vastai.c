/*
 *    vastai driver main entrance.
 *
 *    Copyright (c) 2017, VASTAI Inc.
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License
 *    as published by the Free Software Foundation; either version 2
 *    of the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *    GNU General Public License for more details.
 *
 *    You may obtain a copy of the GNU General Public License
 *    Version 2 or later at the following locations:
 *    http://www.opensource.org/licenses/gpl-license.html
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include <linux/io.h>
#include <linux/sched.h>
#include <linux/uaccess.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/mm.h>
#include <linux/shmem_fs.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
//#include <linux/dma-contiguous.h>
//#include <drm/drm_modeset_helper.h>
#ifdef __amd64__
#include <asm/set_memory.h>
#endif
#include "vastaidec.h"
#include "vastai_priv.h"
#include <linux/of_reserved_mem.h>
#include <linux/of_irq.h>
#include <linux/reset.h>
#include <linux/clk.h>
#include <linux/delay.h>
#include "pcie.h"
#include "vastai_vcmd.h"
#include "vastai_enc.h"
#include "vastai_dev.h"
#include "vastai_render.h"

#define PIXEL_CMA 0
#define CODEC_RESERVED 1

#define DRIVER_NAME	"vastai"
#define DRIVER_DESC	"vastai DRM"
#define DRIVER_DATE	"20210819"
#define DRIVER_MAJOR	1
#define DRIVER_MINOR	1

struct list_head vast_handle_head;
static bool vastai_dec_inited = 0;

bool verbose = 1;
module_param(verbose, bool, 0);
MODULE_PARM_DESC(verbose, "Verbose log operations "
		"(default 0)");

bool enable_encode = 1;
module_param(enable_encode, bool, 0);
MODULE_PARM_DESC(enable_encode, "Enable Encode"
		"(default 1)");

bool enable_dec400 = 0;
module_param(enable_dec400, bool, 0);
MODULE_PARM_DESC(enable_dec400, "Enable DEC400/L2"
		"(default 1)");

bool enable_irqmode = 0;
module_param(enable_irqmode, bool, 0);
MODULE_PARM_DESC(enable_dec400, "Enable IRQ Mode"
        "(default 1)");
unsigned int vcmd = 0;

#ifdef CONFIG_DRM_DRIVER
extern int vastai_add_file(struct vastai_pci_info *pci_info);
extern int vastai_del_file(struct vastai_pci_info *pci_info);

static int vastai_device_open(struct inode *inode, struct file *filp)
{
	int ret;
	struct drm_file *file_priv = NULL;
	struct vastai_device_handle *device_handle = NULL;
	struct drm_device *drm_dev = NULL;
	struct vastai_pci_info *pci_info = NULL;
	ret = drm_open(inode, filp);
	vastaidec_open(inode, filp);

	file_priv = filp->private_data;
	drm_dev = file_priv->minor->dev;
	device_handle = (struct vastai_device_handle *)drm_dev->dev_private;
	pci_info = (struct vastai_pci_info *)device_handle->die.vcmd_pri;
	if ((atomic_read(&pci_info->pci_state) == VASTAI_HOTP_STATE)) {
		return -ENODEV;
	}
	ret = vastai_add_file(device_handle->die.vcmd_pri);
	atomic_inc(&(device_handle->die.dec_job_count));
	return ret;
}

static int vastai_device_release(struct inode *inode, struct file *filp)
{
	struct drm_file *file_priv = filp->private_data;
	struct vastai_device_handle *device_handle = NULL;
	struct die_info *die = NULL;
	struct drm_device *drm_dev = file_priv->minor->dev;

	//device_handle = container_of(file_priv->minor->dev, struct vastai_device_handle, drm_dev);
	device_handle = (struct vastai_device_handle *)drm_dev->dev_private;
	die =(struct die_info*)(&device_handle->die);
	vastaivcmd_release(filp, die);
	vastai_del_file(device_handle->die.vcmd_pri);
	atomic_dec(&(device_handle->die.dec_job_count));
	return drm_release(inode, filp);
}

static int vastai_get_version(struct drm_device *dev, void *data,
			      struct drm_file *file_priv)
{
	struct drm_version *pversion;
	char *sname = DRIVER_NAME;
	char *sdesc = DRIVER_DESC;
	char *sdate = DRIVER_DATE;

	pversion = (struct drm_version *)data;
	pversion->version_major = dev->driver->major;
	pversion->version_minor = dev->driver->minor;
	pversion->version_patchlevel = 0;
	pversion->name_len = strlen(DRIVER_NAME);
	pversion->desc_len = strlen(DRIVER_DESC);
	pversion->date_len = strlen(DRIVER_DATE);
	if (pversion->name)
		if (video_copy_to_user(pversion->name, sname, pversion->name_len))
			return -EFAULT;
	if (pversion->date)
		if (video_copy_to_user(pversion->date, sdate, pversion->date_len))
			return -EFAULT;
	if (pversion->desc)
		if (video_copy_to_user(pversion->desc, sdesc, pversion->desc_len))
			return -EFAULT;
	return 0;
}

#define DRM_IOCTL_DEF(ioctl, _func, _flags)                                    \
	[DRM_IOCTL_NR(ioctl)] = {                                              \
		.cmd = ioctl, .func = _func, .flags = _flags, .name = #ioctl   \
	}

/* after kernel 4.16 this definition is removed */
#ifndef DRM_CONTROL_ALLOW
#define DRM_CONTROL_ALLOW 0
#endif
/* after kernel 6.8.0 this definition is removed */
#ifndef DRM_UNLOCKED
#define DRM_UNLOCKED 0
#endif
/* Ioctl table */
static const struct drm_ioctl_desc vastai_ioctls[] = {
	DRM_IOCTL_DEF(DRM_IOCTL_VERSION, vastai_get_version,
		      DRM_UNLOCKED | DRM_RENDER_ALLOW | DRM_CONTROL_ALLOW),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_UNIQUE, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_IRQ_BUSID, drm_invalid_op,
		      DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_MAP, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_CLIENT, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_STATS, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_SET_CLIENT_CAP, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_SET_VERSION, drm_invalid_op,
		      DRM_UNLOCKED | DRM_MASTER),

	DRM_IOCTL_DEF(DRM_IOCTL_SET_UNIQUE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_BLOCK, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_UNBLOCK, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),

	DRM_IOCTL_DEF(DRM_IOCTL_ADD_MAP, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_RM_MAP, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_SET_SAREA_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_SAREA_CTX, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_SET_MASTER, drm_invalid_op,
		      DRM_UNLOCKED | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_DROP_MASTER, drm_invalid_op,
		      DRM_UNLOCKED | DRM_ROOT_ONLY),

	DRM_IOCTL_DEF(DRM_IOCTL_ADD_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_RM_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_MOD_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_GET_CTX, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_SWITCH_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_NEW_CTX, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_RES_CTX, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_ADD_DRAW, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_RM_DRAW, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),

	DRM_IOCTL_DEF(DRM_IOCTL_LOCK, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_UNLOCK, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_FINISH, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_ADD_BUFS, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_MARK_BUFS, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_INFO_BUFS, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_MAP_BUFS, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_FREE_BUFS, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_DMA, drm_invalid_op, DRM_AUTH),

	DRM_IOCTL_DEF(DRM_IOCTL_CONTROL, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),

#if IS_ENABLED(CONFIG_AGP)
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_ACQUIRE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_RELEASE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_ENABLE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_INFO, drm_invalid_op, DRM_AUTH),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_ALLOC, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_FREE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_BIND, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_AGP_UNBIND, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
#endif

	DRM_IOCTL_DEF(DRM_IOCTL_SG_ALLOC, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_SG_FREE, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),

	DRM_IOCTL_DEF(DRM_IOCTL_WAIT_VBLANK, drm_invalid_op, DRM_UNLOCKED),

	DRM_IOCTL_DEF(DRM_IOCTL_MODESET_CTL, drm_invalid_op, 0),

	DRM_IOCTL_DEF(DRM_IOCTL_UPDATE_DRAW, drm_invalid_op,
		      DRM_AUTH | DRM_MASTER | DRM_ROOT_ONLY),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETRESOURCES, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETPLANERESOURCES, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETCRTC, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_SETCRTC, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETPLANE, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_SETPLANE, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_CURSOR, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETGAMMA, drm_invalid_op, DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_SETGAMMA, drm_invalid_op,
		      DRM_MASTER | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETENCODER, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETCONNECTOR, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_ATTACHMODE, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_DETACHMODE, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETPROPERTY, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_SETPROPERTY, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETPROPBLOB, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_GETFB, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_RMFB, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_PAGE_FLIP, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_DIRTYFB, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_OBJ_GETPROPERTIES, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_OBJ_SETPROPERTY, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_CURSOR2, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_ATOMIC, drm_invalid_op,
		      DRM_MASTER | DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_CREATEPROPBLOB, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
	DRM_IOCTL_DEF(DRM_IOCTL_MODE_DESTROYPROPBLOB, drm_invalid_op,
		      DRM_CONTROL_ALLOW | DRM_UNLOCKED),
};

#if DRM_CONTROL_ALLOW == 0
#undef DRM_CONTROL_ALLOW
#endif

#define VASTAI_IOCTL_COUNT	ARRAY_SIZE(vastai_ioctls)

static long vastai_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{

	struct drm_file *file_priv = filp->private_data;
	struct drm_device *dev = file_priv->minor->dev;
	const struct drm_ioctl_desc *ioctl = NULL;
	drm_ioctl_t *func;
	unsigned int nr = DRM_IOCTL_NR(cmd);
	int retcode = 0;
	char stack_kdata[256];
	char *kdata = stack_kdata;
	unsigned int in_size, out_size;

	if (drm_dev_is_unplugged(dev))
		return -ENODEV;

	if (cmd == DRM_IOCTL_SET_MASTER || cmd == DRM_IOCTL_DROP_MASTER) {
		return -ENODEV;
	}

	out_size = in_size = _IOC_SIZE(cmd);

	if (_IOC_TYPE(cmd) == DRM_IOCTL_BASE && nr == DRM_IOCTL_NR(DRM_IOCTL_VERSION)) {
		out_size = in_size = sizeof(struct drm_version);
	}

	if (_IOC_TYPE(cmd) == VASTAIDEC_IOC_MAGIC ||
		_IOC_TYPE(cmd) == VASTAI_VCMD_IOC_MAGIC)
		return vastaidec_ioctl(filp, cmd, arg);

	if (nr >= VASTAI_IOCTL_COUNT)
		return -EINVAL;
	ioctl = &vastai_ioctls[nr];

	if((cmd == DRM_IOCTL_VASTAI_UPDATE_METADATA) ||
		(cmd == DRM_IOCTL_VASTAI_QUERY_METADATA) ) {
		if (video_copy_from_user(kdata, (void __user *)arg, sizeof(struct vastai_metainfo_params)) != 0)
			return  -EFAULT;
	} else {
		if (video_copy_from_user(kdata, (void __user *)arg, in_size) != 0)
			return -EFAULT;
	}

	if (cmd == DRM_IOCTL_MODE_SETCRTC ||
	    cmd == DRM_IOCTL_MODE_GETRESOURCES ||
	    cmd == DRM_IOCTL_SET_CLIENT_CAP || cmd == DRM_IOCTL_MODE_GETCRTC ||
	    cmd == DRM_IOCTL_MODE_GETENCODER ||
	    cmd == DRM_IOCTL_MODE_GETCONNECTOR || cmd == DRM_IOCTL_MODE_GETFB) {
		retcode = drm_ioctl(filp, cmd, arg);
		return retcode;
	}
	func = ioctl->func;
	if (func == NULL)
		return -EINVAL;
	retcode = func(dev, kdata, file_priv);

	if((cmd == DRM_IOCTL_VASTAI_UPDATE_METADATA) ||
		(cmd == DRM_IOCTL_VASTAI_QUERY_METADATA) ) {
		if (video_copy_to_user((void __user *)arg, kdata, sizeof(struct vastai_metainfo_params)) != 0) {
			retcode = -EFAULT;
		}
	} else {
		if (video_copy_to_user((void __user *)arg, kdata, out_size) != 0)
			retcode = -EFAULT;
	}

	return retcode;
}

/* VFS methods */
static const struct file_operations vastai_fops = {
	.owner		= THIS_MODULE,
	.open		= vastai_device_open,
	.release	= vastai_device_release,
	.poll		= drm_poll,
	.read		= drm_read,
	.unlocked_ioctl	= vastai_ioctl,
	.compat_ioctl	= vastai_ioctl,
};

#if 0
static void vastai_driver_release(struct drm_device *dev)
{
	struct vastai_device_handle *device_handle = container_of(dev, struct vastai_device_handle, drm_dev);
#if KERNEL_VERSION(5, 7, 19) < LINUX_VERSION_CODE
#else
	drm_dev_fini(device_handle->drm_dev);
#endif
	kfree(device_handle);
}
#endif
static struct drm_driver vastai_drm_driver = {
	//these two are related with controlD and renderD
	.driver_features		= DRIVER_GEM | DRIVER_RENDER,
	.fops				= &vastai_fops,
	.name				= DRIVER_NAME,
	.desc				= DRIVER_DESC,
	.date				= DRIVER_DATE,
	.major				= DRIVER_MAJOR,
	.minor				= DRIVER_MINOR,
	.release			= NULL,
};
#endif

void vastai_dec_pre_reset(void* arg, u32 core_id) ;
void vastai_dec_post_reset(void * arg, u32 core_id);

int vastai_video_dec_reset_handler(u32 die_index, u32 core_bit, reset_event event)
{
	int core_id;
	struct list_head *p = NULL, *n = NULL;
	struct vastai_device_handle *device_handle_node = NULL;
	struct die_info *die = NULL;

	list_for_each_safe(p, n, &vast_handle_head) {
		device_handle_node = list_entry(p, struct vastai_device_handle, node);
		if (die_index == device_handle_node->die.die_id) {
			die = &device_handle_node->die;
			break;
		}
	}

	if (!die) {
		VAVIDEO_ERR(NULL, (u8)(die_index),
			"%s: device crash not found die for die_index=0x%x\n", __func__, die_index);
		return -1;
	}

	switch (core_bit)
	{
		case CORE_POINT_VDMCU0:
		case CORE_POINT_VDMCU1:
		case CORE_POINT_VDMCU2:
		{
			core_id = core_bit % CORE_POINT_VDMCU0;

			if (RESET_START == event) {
				vastai_dec_pre_reset(die, core_id);
			}else if (RESET_END == event) {
				vastai_dec_post_reset(die, core_id);
			}

			if (RESET_END == event) {
				die->reset_end_bitmap |= 1 << core_id;
				return 0;
			}

			break;
		}

		case CORE_TOTAL_NUM:
		{
			if (RESET_END == event) {
				die->reset_end_bitmap |= 0xf;
				return 0;
			}

			break;
		}

		default:
		{
			return 0;
		}

	}

	return 0;
}

int vastai_video_reset_handler(u32 die_index, u32 core_bit, reset_event event)
{
	int ret = -1;

	if (RESET_START != event && RESET_END != event) {
		// ignore event not cared
		return 0;
	}

	switch (core_bit)
	{
		case CORE_POINT_VEMCU0:
		case CORE_POINT_VEMCU1:
		case CORE_POINT_VEMCU2:
		case CORE_POINT_VEMCU3:
		{
			return vastai_video_enc_reset_handler(die_index, core_bit, event);
		}

		case CORE_POINT_VDMCU0:
		case CORE_POINT_VDMCU1:
		case CORE_POINT_VDMCU2:
		{
			return vastai_video_dec_reset_handler(die_index, core_bit, event);
		}

		case CORE_TOTAL_NUM:
		{
			ret = vastai_video_enc_reset_handler(die_index, core_bit, event);
			if (ret) {
				VAVIDEO_ERR(NULL, die_index,"venc reset handler error core_bit=%d, event=%d\n", core_bit, event);
				return -1;
			}

			ret = vastai_video_dec_reset_handler(die_index, core_bit, event);
			if (ret) {
				VAVIDEO_ERR(NULL, die_index,"venc reset handler error core_bit=%d, event=%d\n", core_bit, event);
				return -1;
			}
		}
	}

	return 0;

}

void vastai_cleanup(void *pcie_dev)
{
	/* TODO: cleanup every node of the linklist */

	struct list_head *p = NULL, *n = NULL;
	struct vastai_device_handle *device_handle_node = NULL;

	VAVIDEO_INFO(pcie_dev, DUMMY_DIE_ID, "vastai_cleanup\n");

	list_for_each_safe(p, n, &vast_handle_head) {
		/* release drm_dev */
		device_handle_node = list_entry(p, struct vastai_device_handle, node);
		if (pcie_dev == device_handle_node->die.vcmd_pri) {
			VAVIDEO_INFO(pcie_dev, (u8)(device_handle_node->die.die_id),
					"vastai_cleanup find die to remove\n");
			list_del(&device_handle_node->node);

			/* release vcmd_data */
			vastaivcmd_cleanup(&device_handle_node->die);
#ifdef CONFIG_DRM_DRIVER
			drm_dev_unregister(device_handle_node->drm_dev);

#if KERNEL_VERSION(4, 14, 239) < LINUX_VERSION_CODE
			drm_dev_put(device_handle_node->drm_dev);
#else
			drm_dev_unref(device_handle_node->drm_dev);
#endif
			device_handle_node->drm_dev = NULL;
#endif
			kfree(device_handle_node);
			device_handle_node = NULL;
		}


	}

	/* vastaidec_cleanup(); */
	/* unregister platform */
	VAVIDEO_INFO(pcie_dev, DUMMY_DIE_ID, "vastai driver removed\n");
}

int vastai_video_init(void *pcie_dev, unsigned int die_id,
		      unsigned int* render_id)
{
	int ret;
	struct vastai_device_handle *dec_device_handle;
	struct device_handle * enc_device_handle;
#ifdef CONFIG_DRM_DRIVER
	struct drm_device* drm_dev = NULL;
#endif

	VAVIDEO_INFO(pcie_dev, (u8)die_id,
		    "vastai video module die_id=0x%x init start!\n", die_id);

	if (!vastai_dec_inited) {
		INIT_LIST_HEAD(&vast_handle_head);
		vastai_dec_inited = 1;
	}

	dec_device_handle = kzalloc(sizeof(struct vastai_device_handle), GFP_KERNEL);
	if (!dec_device_handle)
		return -ENOMEM;

	dec_device_handle->die.die_id = die_id;
	dec_device_handle->die.vcmd_pri = pcie_dev;
	list_add_tail(&(dec_device_handle->node), &vast_handle_head);

	ret = vastaivcmd_init(&dec_device_handle->die);
	if (ret) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id, "vcmd init failed\n");
		goto free;
	}
#ifdef CONFIG_DRM_DRIVER
	drm_dev = drm_dev_alloc(&vastai_drm_driver, &((struct vastai_pci_info*)pcie_dev)->dev->dev);
	//ret = drm_dev_init(&dec_device_handle->drm_dev, &vastai_drm_driver, &platform_dev->dev);

	if (IS_ERR(drm_dev)) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id, "init drm failed\n");
		ret = PTR_ERR(drm_dev);
		goto free;
	}

	drm_dev->dev_private = dec_device_handle;
	dec_device_handle->drm_dev = drm_dev;

	ret = drm_dev_register(dec_device_handle->drm_dev, 0);
	if (ret < 0) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id, "drm dev register fail\n");
		goto out_unreg_drm;
	}

	*render_id = dec_device_handle->drm_dev->render->index;
	((struct vastai_pci_info *)pcie_dev)->dies[vastai_pci_get_die_id(pcie_dev, die_id)].card_id =
				dec_device_handle->drm_dev->primary->index;
#endif

	ret = hantroenc_init(pcie_dev, die_id);
	if (ret) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id,
					"%s:cannot do hantroenc %d\n",
					pci_name(pcie_dev), ret);
	}

	ret = hantroenc_get_device_from_dieindex(die_id, &enc_device_handle);
	if (ret) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id,
					"%s:cannot do hantroenc %d\n",
					pci_name(pcie_dev), ret);
	}

	ret = vastai_render_file_init(pcie_dev, die_id, dec_device_handle, enc_device_handle);
	if (ret) {
		VAVIDEO_ERR(pcie_dev, (u8)die_id,
			       "%s:cannot do render %d\n",
			       pci_name(pcie_dev), ret);
	}

	vastai_video_reset_handle_reg(vastai_video_reset_handler);

	VAVIDEO_INFO(pcie_dev, (u8)die_id, "vastai video module die_id=0x%x init success!\n", die_id);

	return 0;

#ifdef CONFIG_DRM_DRIVER
out_unreg_drm:

#if KERNEL_VERSION(4, 14, 239) < LINUX_VERSION_CODE
		drm_dev_put(dec_device_handle->drm_dev);
#else
		drm_dev_unref(dec_device_handle->drm_dev);
#endif

#endif
free:
	kfree(dec_device_handle);

	return ret;
}

int dec_work_mode_change(u32 die_index, decoder_workmode_t work_mode)
{
	int core_id;
	struct list_head *p = NULL, *n = NULL;
	struct vastai_device_handle *device_handle_node = NULL;
	int count = CHECK_RESET_STAT_INTERVAL;

	list_for_each_safe(p, n, &vast_handle_head) {
		device_handle_node = list_entry(p, struct vastai_device_handle, node);
		if (die_index == device_handle_node->die.die_id) {
			break;
		}
	}

	if (atomic_read(&(device_handle_node->die.dec_job_count)) !=  0) {
		VAVIDEO_INFO(device_handle_node->die.vcmd_pri, (u8)die_index,
					"still run %d task on die: 0x%x, switch decoder work mode failed, return\n",
					atomic_read(&(device_handle_node->die.dec_job_count)), die_index);
		return -1;
	}


	if (work_mode == device_handle_node->die.work_mode)
	{
		VAVIDEO_INFO(device_handle_node->die.vcmd_pri, (u8)die_index,
				"current work mode(%s) is same with dest work mode, no need switch\n",
				(work_mode == DEC_SINGLE_CORE_MODE ? "dec-single-core" : "dec-multi-core"));
		return 0;
	}

	atomic_set(&(device_handle_node->die.decoder_state), VIDEO_STATE_CHANGING);
	VAVIDEO_INFO(device_handle_node->die.vcmd_pri, (u8)die_index, "die_index[%x] decoder change to %d start\n", device_handle_node->die.die_id, work_mode);


	set_dec_work_mode(&device_handle_node->die, work_mode);
		//reset vdmcu
	if (work_mode == DEC_SINGLE_CORE_MODE)
	{
		for (core_id = CORE_POINT_VDMCU0; core_id <= CORE_POINT_VDMCU2; core_id++) {

			count = CHECK_RESET_STAT_INTERVAL;
			device_handle_node->die.reset_end_bitmap &= ~(1 << (core_id % CORE_POINT_VDMCU0));

			vastai_send_pcie_cmd(device_handle_node->die.vcmd_pri,device_handle_node->die.die_id,
						VASTAI_PCIE_SUB_CORE_RESET, core_id);

			while (count) {

				if (device_handle_node->die.reset_end_bitmap & (1 << (core_id % CORE_POINT_VDMCU0))) {
					VAVIDEO_INFO(device_handle_node->die.vcmd_pri,
								(u8)(device_handle_node->die.die_id),
								"die_index[%x] vdec core %d reset to single success\n", device_handle_node->die.die_id, core_id);
					break;
				}

				msleep(50);
				count--;

			}

			if (count == 0) {
				VAVIDEO_ERR(device_handle_node->die.vcmd_pri,
					(u8)(device_handle_node->die.die_id),
					"die_index[%x] vdec core %d reset to single failed!\n", device_handle_node->die.die_id, core_id);
				return -1;
			}
		}
	}
	else
	{
		for (core_id = CORE_POINT_VDMCU2; core_id >= CORE_POINT_VDMCU0; core_id--) {

			count = CHECK_RESET_STAT_INTERVAL;
			device_handle_node->die.reset_end_bitmap &= ~(1 << (core_id % CORE_POINT_VDMCU0));

			vastai_send_pcie_cmd(device_handle_node->die.vcmd_pri,device_handle_node->die.die_id,
						VASTAI_PCIE_SUB_CORE_RESET, core_id);

			while (count) {

				if (device_handle_node->die.reset_end_bitmap & (1 << (core_id % CORE_POINT_VDMCU0))) {
					VAVIDEO_INFO(device_handle_node->die.vcmd_pri,
								(u8)(device_handle_node->die.die_id),
								"die_index[%x] vdec core %d reset to multi success\n", device_handle_node->die.die_id, core_id);
					break;
				}

				msleep(50);
				count--;

			}

			if (count == 0) {
				VAVIDEO_ERR(device_handle_node->die.vcmd_pri,
					(u8)(device_handle_node->die.die_id),
					"die_index[%x] vdec core %d reset to multi failed!\n", device_handle_node->die.die_id, core_id);
				return -1;
			}
		}
	}

	VAVIDEO_INFO(device_handle_node->die.vcmd_pri, (u8)die_index,
			"vasmi set decoder work mode to %s success!\n",
			(work_mode == DEC_SINGLE_CORE_MODE ? "dec-single-core" : "dec-multi-core"));

	msleep(500);

	atomic_set(&(device_handle_node->die.decoder_state), VIDEO_STATE_READY);

	VAVIDEO_INFO(device_handle_node->die.vcmd_pri, (u8)die_index, "die_index[%x] decoder change to %d end\n", device_handle_node->die.die_id, work_mode);

	return 0;
}

