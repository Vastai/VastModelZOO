/* SPDX-License-Identifier: GPL-2.0 */
/*
 *    vastai driver private header file.
 *
 *    Copyright (c) 2017,VASTAI Inc.
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License
 *    as published by the Free Software Foundation; either version 2
 *    of the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You may obtain a copy of the GNU General Public License
 *    Version 2 or later at the following locations:
 *    http://www.opensource.org/licenses/gpl-license.html
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef __VASTAI_PRIV_H__
#define __VASTAI_PRIV_H__
#include "vastai.h"

#define VASTAI_GEM_FLAG_IMPORT		(1 << 0)
#define VASTAI_GEM_FLAG_EXPORT		(1 << 1)
#define VASTAI_GEM_FLAG_EXPORTUSED	(1 << 2)

#define vastai_reserve_obj_shared(a, b) dma_resv_reserve_shared(a, b)
#define vastai_ref_drmobj drm_gem_object_get
#define vastai_unref_drmobj drm_gem_object_put_unlocked

#define NODENAME_DECODER	"decoder"
#define NODENAME_ENCODER	"encoder"
#define NODENAME_CACHE		"cache"
#define NODENAME_DEC400		"dec400"

typedef struct dtbnode {
	struct device_node *ofnode;
	int type;
	phys_addr_t ioaddr;
	phys_addr_t iosize;
	char reg_name[32];
	int irq[4];
	char irq_name[4][32];
	int parenttype;
	phys_addr_t parentaddr;
	int sliceidx;
	struct dtbnode *next;
	struct device *dev;
} dtbnode;

struct vastai_dev_handle {
	struct platform_device *platformdev; /* parent device */
	struct drm_device *drm_dev;
	u32 config;
	void *data;
	struct dentry *debugfs_root;
};
extern struct vastai_dev_handle vastai_dev;

#define VASTAI_FENCE_FLAG_ENABLE_SIGNAL_BIT	DMA_FENCE_FLAG_ENABLE_SIGNAL_BIT
#define VASTAI_FENCE_FLAG_SIGNAL_BIT		DMA_FENCE_FLAG_SIGNALED_BIT

typedef struct dma_fence vastai_fence_t;
typedef struct dma_fence_ops vastai_fence_op_t;

static inline signed long
vastai_fence_default_wait(vastai_fence_t *fence, bool intr, signed long timeout)
{
	return dma_fence_default_wait(fence, intr, timeout);
}

static inline void vastai_fence_init(vastai_fence_t *fence,
				     const vastai_fence_op_t *ops,
				     spinlock_t *lock, unsigned int context,
				     unsigned int seqno)
{
	return dma_fence_init(fence, ops, lock, context, seqno);
}

static inline unsigned int vastai_fence_context_alloc(unsigned int num)
{
	return dma_fence_context_alloc(num);
}

static inline signed long
vastai_fence_wait_timeout(vastai_fence_t *fence, bool intr, signed long timeout)
{
	return dma_fence_wait_timeout(fence, intr, timeout);
}
#ifdef CONFIG_DRM_DRIVER
static inline struct drm_gem_object *
vastai_gem_object_lookup(struct drm_device *dev, struct drm_file *filp,
			 u32 handle)
{
	return drm_gem_object_lookup(filp, handle);
}
#endif
static inline void vastai_fence_put(vastai_fence_t *fence)
{
	return dma_fence_put(fence);
}

static inline int vastai_fence_signal(vastai_fence_t *fence)
{
	return dma_fence_signal(fence);
}

static inline void ref_page(struct page *pp)
{
	atomic_inc(&pp->_refcount);
	atomic_inc(&pp->_mapcount);
}

static inline void unref_page(struct page *pp)
{
	atomic_dec(&pp->_refcount);
	atomic_dec(&pp->_mapcount);
}

static inline bool vastai_fence_is_signaled(vastai_fence_t *fence)
{
	return dma_fence_is_signaled(fence);
}

#ifdef CONFIG_DRM_DRIVER
static inline struct drm_gem_vastai_object *
to_drm_gem_vastai_obj(struct drm_gem_object *gem_obj)
{
	return container_of(gem_obj, struct drm_gem_vastai_object, base);
}
#endif
#ifdef CONFIG_DRM_DRIVER
int vastai_setdomain(struct drm_device *dev, void *data,
		     struct drm_file *file_priv);
int vastai_acquirebuf(struct drm_device *dev, void *data,
		      struct drm_file *file_priv);
int vastai_testbufvalid(struct drm_device *dev, void *data,
			struct drm_file *file_priv);
int vastai_releasebuf(struct drm_device *dev, void *data,
		      struct drm_file *file_priv);
#endif
/* int init_vastai_resv(struct dma_resv *presv,
 *              struct drm_gem_vastai_object *cma_obj); */
void initFenceData(void);
void releaseFenceData(void);

#endif /* __VASTAI_PRIV_H__ */
