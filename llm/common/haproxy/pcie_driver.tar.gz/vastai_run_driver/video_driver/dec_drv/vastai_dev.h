#ifndef __VASTAI_DEV_H__
#define __VASTAI_DEV_H__
#include "vastai_vcmd.h"

#ifdef CONFIG_DRM_DRIVER
#include <drm/drm_drv.h>
#include <drm/drm_file.h>
#endif

struct vastai_device_handle {
#ifdef CONFIG_DRM_DRIVER
	struct drm_device* drm_dev;
#endif
	struct die_info die;
	struct list_head node;
};


#endif
