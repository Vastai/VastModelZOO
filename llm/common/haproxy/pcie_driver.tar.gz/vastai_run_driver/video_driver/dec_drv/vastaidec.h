/* 
 * vastai Decoder device driver (kernel module)
*
* Copyright (C) 2020 VASTAI Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#ifndef _VASTAIDEC_H_
#define _VASTAIDEC_H_
#ifdef __FREERTOS__
#include "basetype.h"
#include "dev_common_freertos.h"
#elif defined(__linux__)
#include <linux/ioctl.h>
#include <linux/types.h>
#include "vastaimmu.h"
#else //For other os
//TODO...
#endif
#include "vastai_video.h"


enum CoreType {
  /* Decoder */
  HW_VC8000D = 0,
  HW_VC8000DJ,
  HW_BIGOCEAN,
  HW_VCMD,
  HW_MMU,  //if set HW_MMU_WR, then HW_MMU means HW_MMU_RD
  HW_MMU_WR,
  HW_DEC400,
  HW_L2CACHE,
  HW_SHAPER,
  /* Encoder*/
  /* Auxiliary IPs */
  HW_NOC,
  HW_AXIFE,
  HW_APBFILTER,
  HW_CORE_MAX     /* max number of cores supported */
}; 

struct core_desc {
  __u32 id; /* id of the subsystem */
  __u32 type; /* type of core to be written */
  __u32 *regs; /* pointer to user registers */
  __u32 size; /* size of register space */
  __u32 reg_id; /* id of reigster to be read/written */
};

struct regsize_desc {
  __u32 slice; /* id of the slice */
  __u32 id; /* id of the subsystem */
  __u32 type; /* type of core to be written */
  __u32 size; /* iosize of the core */
};

struct core_param {
  __u32 slice; /* id of the slice */
  __u32 id; /* id of the subsystem */
  __u32 type; /* type of core to be written */
  __u32 size; /* iosize of the core */
  __u32 asic_id; /* asic id of the core */
};


struct subsys_desc {
  __u32 subsys_num;   /* total subsystems count */
  __u32 subsys_vcmd_num;  /* subsystems with vcmd */
};

struct axife_cfg {
  __u8 axi_rd_chn_num;
  __u8 axi_wr_chn_num;
  __u8 axi_rd_burst_length;
  __u8 axi_wr_burst_length;
  __u8 fe_mode;
  __u32 id;
};

struct apbfilter_cfg {
  __u32 nbr_mask_regs;
  __u32 mask_reg_offset;
  __u32 page_sel_addr;
  __u8  num_mode;
  __u8  mask_bits_per_reg;
  __u32 id; /* id of the subsystem */
  __u32 type; /* type of core to be written */
  __u32 has_apbfilter;
};

typedef enum {
    DEC_SINGLE_CORE_MODE,    //one stream decode on one decoder core
    DEC_MULTI_CORE_MODE,     //one stream decode on multi decoder core
    DEC_WORK_MODE_MAX,
}decoder_workmode_t;

#define VDMCU_MULTICORE_MODE    (0xbbbbbbbb)
#define VDMCU_SINGLECORE_MODE   (0xaaaaaaaa)

/* Use 'k' as magic number */
#define VASTAIDEC_IOC_MAGIC  'k'

/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": G and S atomically
 * H means "sHift": T and Q atomically
 */

#define VASTAIDEC_PP_INSTANCE       _IO(VASTAIDEC_IOC_MAGIC, 1)
#define VASTAIDEC_HW_PERFORMANCE    _IO(VASTAIDEC_IOC_MAGIC, 2)
#define VASTAIDEC_IOCGHWOFFSET      _IOR(VASTAIDEC_IOC_MAGIC,  3, unsigned long *)
#define VASTAIDEC_IOCGHWIOSIZE      _IOR(VASTAIDEC_IOC_MAGIC,  4, struct regsize_desc *)

#define VASTAIDEC_IOC_CLI           _IO(VASTAIDEC_IOC_MAGIC,  5)
#define VASTAIDEC_IOC_STI           _IO(VASTAIDEC_IOC_MAGIC,  6)
#define VASTAIDEC_IOC_MC_OFFSETS    _IOR(VASTAIDEC_IOC_MAGIC, 7, unsigned long *)
#define VASTAIDEC_IOC_MC_CORES      _IOR(VASTAIDEC_IOC_MAGIC, 8, unsigned int *)


#define VASTAIDEC_IOCS_DEC_PUSH_REG  _IOW(VASTAIDEC_IOC_MAGIC, 9, struct core_desc *)
#define VASTAIDEC_IOCS_PP_PUSH_REG   _IOW(VASTAIDEC_IOC_MAGIC, 10, struct core_desc *)

#define VASTAIDEC_IOCH_DEC_RESERVE   _IO(VASTAIDEC_IOC_MAGIC, 11)
#define VASTAIDEC_IOCT_DEC_RELEASE   _IO(VASTAIDEC_IOC_MAGIC, 12)
#define VASTAIDEC_IOCQ_PP_RESERVE    _IO(VASTAIDEC_IOC_MAGIC, 13)
#define VASTAIDEC_IOCT_PP_RELEASE    _IO(VASTAIDEC_IOC_MAGIC, 14)

#define VASTAIDEC_IOCX_DEC_WAIT      _IOWR(VASTAIDEC_IOC_MAGIC, 15, struct core_desc *)
#define VASTAIDEC_IOCX_PP_WAIT       _IOWR(VASTAIDEC_IOC_MAGIC, 16, struct core_desc *)

#define VASTAIDEC_IOCS_DEC_PULL_REG  _IOWR(VASTAIDEC_IOC_MAGIC, 17, struct core_desc *)
#define VASTAIDEC_IOCS_PP_PULL_REG   _IOWR(VASTAIDEC_IOC_MAGIC, 18, struct core_desc *)

#define VASTAIDEC_IOCG_CORE_WAIT     _IOR(VASTAIDEC_IOC_MAGIC, 19, int *)

#define VASTAIDEC_IOX_ASIC_ID        _IOWR(VASTAIDEC_IOC_MAGIC, 20, struct core_param *)

#define VASTAIDEC_IOCG_CORE_ID       _IOR(VASTAIDEC_IOC_MAGIC, 21, unsigned long)

#define VASTAIDEC_IOCS_DEC_WRITE_REG  _IOW(VASTAIDEC_IOC_MAGIC, 22, struct core_desc *)

#define VASTAIDEC_IOCS_DEC_READ_REG   _IOWR(VASTAIDEC_IOC_MAGIC, 23, struct core_desc *)

#define VASTAIDEC_IOX_ASIC_BUILD_ID   _IOWR(VASTAIDEC_IOC_MAGIC, 24, __u32 *)

#define VASTAIDEC_IOX_SUBSYS _IOWR(VASTAIDEC_IOC_MAGIC, 25, struct subsys_desc *)

#define VASTAIDEC_IOCX_POLL _IO(VASTAIDEC_IOC_MAGIC, 26)

#define VASTAIDEC_DEBUG_STATUS       _IO(VASTAIDEC_IOC_MAGIC, 29)

#define VASTAIDEC_IOCS_DEC_WRITE_APBFILTER_REG  _IOW(VASTAIDEC_IOC_MAGIC, 30, struct core_desc *)

#define VASTAIDEC_IOC_APBFILTER_CONFIG     _IOR(VASTAIDEC_IOC_MAGIC,  31, struct apbfilter_cfg *)

#define VASTAIDEC_IOC_AXIFE_CONFIG   _IOR(VASTAIDEC_IOC_MAGIC,  32, struct axife_cfg *)

#define VASTAIDEC_IOC_MAXNR 32


int vastaidec_release(struct file *filp);
int vastaidec_open(struct inode *inode, struct file *filp);
long vastaidec_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
void vastaidec_cleanup(void);
int vastaidec_init(void);


#endif /* !_VASTAIDEC_H_ */
