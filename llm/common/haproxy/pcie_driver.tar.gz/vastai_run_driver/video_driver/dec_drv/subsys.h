/* 
 * vastai Decoder device driver (kernel module)
*
* Copyright (C) 2020 VASTAI Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#ifndef _SUBSYS_H_
#define _SUBSYS_H_

#ifdef __FREERTOS__
/* nothing */
#elif defined(__linux__)
#include <linux/fs.h>
#endif

#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

/******************************************************************************/
/* subsys level */
/******************************************************************************/

#include "vastaidec.h"
#include "vastai.h"

#define MAX_SUBSYS_NUM  5   /* up to 5 subsystem (temporary) */
#define HXDEC_MAX_CORES MAX_SUBSYS_NUM    /* used in vastai_dec_xxx.c */

/* SubsysDesc & CoreDesc are used for configuration */
struct SubsysDesc {
  int slice_index;    /* slice this subsys belongs to */
  int index;   /* subsystem index */
  long base;
};

struct CoreDesc {
  int slice;
  int subsys;     /* subsys this core belongs to */
  enum CoreType core_type;
  int offset;     /* offset to subsystem base */
  int iosize;
  int irq;
  int has_apb;
};

/* internal config struct (translated from SubsysDesc & CoreDesc) */
struct subsys_config {
  unsigned long base_addr;
  int irq;
  u32 subsys_type;  /* identifier for each subsys vc8000e=0,IM=1,vc8000d=2,jpege=3,jpegd=4 */
  u32 submodule_offset[HW_CORE_MAX]; /* in bytes */
  u16 submodule_iosize[HW_CORE_MAX]; /* in bytes */
  volatile u8 *submodule_hwregs[HW_CORE_MAX]; /* virtual address */
  int has_apbfilter[HW_CORE_MAX];
};

void CheckSubsysCoreArray(void *die, struct subsys_config *subsys, int *vcmd);

/******************************************************************************/
/* VCMD */
/******************************************************************************/
#define OPCODE_WREG               (0x01UL<<27)
#define OPCODE_END                (0x02UL<<27)
#define OPCODE_NOP                (0x03UL<<27)
#define OPCODE_RREG               (0x16UL<<27)
#define OPCODE_INT                (0x18UL<<27)
#define OPCODE_JMP                (0x19UL<<27)
#define OPCODE_STALL              (0x09UL<<27)
#define OPCODE_CLRINT             (0x1aUL<<27)
#define OPCODE_JMP_RDY0           (0x19UL<<27)
#define OPCODE_JMP_RDY1           ((0x19UL<<27)|(1UL<<26))
#define JMP_IE_1                  (1UL<<25)
#define JMP_RDY_1                 (1UL<<26)

/* Used in vcmd initialization in vastai_vcmd_xxx.c. */
/* May be unified in next step. */
struct vcmd_config {
  unsigned long vcmd_base_addr;
  u32 vcmd_iosize;
  int vcmd_irq;
  u32 sub_module_type;        /*input vc8000e=0,IM=1,vc8000d=2,jpege=3, jpegd=4*/
  u16 submodule_main_addr;    // in byte
  u16 submodule_dec400_addr;  //if submodule addr == 0xffff, this submodule does not exist.// in byte
  u16 submodule_L2Cache_addr; // in byte
  u16 submodule_MMU_addr;     // in byte
  u16 submodule_MMUWrite_addr;// in byte
  u16 submodule_axife_addr;   // in byte
  u16 submodule_axifeWrite_addr;   // in byte
};

#ifdef __FREERTOS__
/* nothing */
#elif defined(__linux__)

/******************************************************************************/
/* MMU */
/******************************************************************************/

/* Init MMU, should be called in driver init function. */
enum MMUStatus MMUInit(volatile unsigned char *hwregs);
/* Clean up all data in MMU, should be called in driver cleanup function
   when rmmod driver*/
enum MMUStatus MMUCleanup(volatile unsigned char *hwregs[MAX_SUBSYS_NUM][2]);
/* The function should be called in driver realease function
   when driver exit unnormally */
enum MMUStatus MMURelease(void *filp, volatile unsigned char *hwregs);

enum MMUStatus MMUEnable(volatile unsigned char *hwregs[MAX_SUBSYS_NUM][2]);

/* Used in kernel to map buffer */
enum MMUStatus MMUKernelMemNodeMap(struct kernel_addr_desc *addr);
/* Used in kernel to unmap buffer */
enum MMUStatus MMUKernelMemNodeUnmap(struct kernel_addr_desc *addr);

long MMUIoctl(unsigned int cmd, void *filp, unsigned long arg,
              volatile unsigned char *hwregs[MAX_SUBSYS_NUM][2]);

/******************************************************************************/
/* L2Cache */
/******************************************************************************/

/******************************************************************************/
/* DEC400 */
/******************************************************************************/


/******************************************************************************/
/* AXI FE */
/******************************************************************************/
#endif

#endif

