/*
 * Vastai Decoder device driver (kernel module)
*
* Copyright (C) 2020 VASTAI Microelectronics Co., Ltd.
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*
------------------------------------------------------------------------------*/

#include <linux/kernel.h>
#include <linux/module.h>
/* needed for __init,__exit directives */
#include <linux/init.h>
/* needed for remap_page_range
    SetPageReserved
    ClearPageReserved
*/
#include <linux/mm.h>
/* obviously, for kmalloc */
#include <linux/slab.h>
/* for struct file_operations, register_chrdev() */
#include <linux/fs.h>
/* standard error codes */
#include <linux/errno.h>

#include <linux/moduleparam.h>
/* request_irq(), free_irq() */
#include <linux/interrupt.h>
#include <linux/sched.h>

#include <linux/semaphore.h>
#include <linux/spinlock.h>
/* needed for virt_to_phys() */
#include <asm/io.h>
#include <linux/pci.h>
#include <linux/uaccess.h>
#include <linux/ioport.h>

#include <asm/irq.h>

#include <linux/version.h>
#include <linux/vmalloc.h>
#include <linux/timer.h>
#include <linux/delay.h>
#include <linux/sched/signal.h>
#include <linux/signal.h>
#include <linux/string.h>


/* our own stuff */
#include <linux/platform_device.h>


/* #include "vastaidec.h" */
#include "subsys.h"

#include"vastai_pci.h"
#include"vastai_pci_api.h"
#include "ipc.h"
#include "vastaimmu.h"

#include "vastai_dev.h"
#include "vastai_sv100_reg.h"
#include "vastai_render.h"
#include "vastai_video_utils.h"

#define VASTAI           "vastai"

/*------------------------------------------------------------------------
*****************************VCMD CONFIGURATION BY CUSTOMER********************************
-------------------------------------------------------------------------*/

//video decoder vcmd configuration
#define VCMD_DEC_IO_ADDR_0                      0x10000   /*customer specify according to own platform*/
#define VCMD_DEC_IO_SIZE_0                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_DEC_INT_PIN_0                      -1
#define VCMD_DEC_MODULE_TYPE_0                  2
#define VCMD_DEC_MODULE_MAIN_ADDR_0             0x1000    /*customer specify according to own platform*/
#define VCMD_DEC_MODULE_DEC400_ADDR_0           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_DEC_MODULE_L2CACHE_ADDR_0          0X2000
#define VCMD_DEC_MODULE_MMU_ADDR_0              0XFFFF


#define VCMD_DEC_IO_ADDR_1                      0x700000   /*customer specify according to own platform*/
#define VCMD_DEC_IO_SIZE_1                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_DEC_INT_PIN_1                      -1
#define VCMD_DEC_MODULE_TYPE_1                  2
#define VCMD_DEC_MODULE_MAIN_ADDR_1             0x1000    /*customer specify according to own platform*/
#define VCMD_DEC_MODULE_DEC400_ADDR_1           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_DEC_MODULE_L2CACHE_ADDR_1          0X2000
#define VCMD_DEC_MODULE_MMU_ADDR_1              0XFFFF

#define VCMD_DEC_IO_ADDR_2                      0xb2000   /*customer specify according to own platform*/
#define VCMD_DEC_IO_SIZE_2                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_DEC_INT_PIN_2                      -1
#define VCMD_DEC_MODULE_TYPE_2                  2
#define VCMD_DEC_MODULE_MAIN_ADDR_2             0x0000    /*customer specify according to own platform*/
#define VCMD_DEC_MODULE_DEC400_ADDR_2           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_DEC_MODULE_L2CACHE_ADDR_2          0XFFFF
#define VCMD_DEC_MODULE_MMU_ADDR_2              0XFFFF

#define VCMD_DEC_IO_ADDR_3                      0xb3000   /*customer specify according to own platform*/
#define VCMD_DEC_IO_SIZE_3                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_DEC_INT_PIN_3                      -1
#define VCMD_DEC_MODULE_TYPE_3                  2
#define VCMD_DEC_MODULE_MAIN_ADDR_3             0x0000    /*customer specify according to own platform*/
#define VCMD_DEC_MODULE_DEC400_ADDR_3           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_DEC_MODULE_L2CACHE_ADDR_3          0XFFFF
#define VCMD_DEC_MODULE_MMU_ADDR_3              0XFFFF


//JPEG decoder vcmd configuration

#define VCMD_JPEGD_IO_ADDR_0                      0x600000   /*customer specify according to own platform*/
#define VCMD_JPEGD_IO_SIZE_0                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_JPEGD_INT_PIN_0                      -1
#define VCMD_JPEGD_MODULE_TYPE_0                  4
#define VCMD_JPEGD_MODULE_MAIN_ADDR_0             0x1000    /*customer specify according to own platform*/
#define VCMD_JPEGD_MODULE_DEC400_ADDR_0           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_JPEGD_MODULE_L2CACHE_ADDR_0          0XFFFF
#define VCMD_JPEGD_MODULE_MMU_ADDR_0              0XFFFF

#define VCMD_JPEGD_IO_ADDR_1                      0xD1000   /*customer specify according to own platform*/
#define VCMD_JPEGD_IO_SIZE_1                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_JPEGD_INT_PIN_1                      -1
#define VCMD_JPEGD_MODULE_TYPE_1                  4
#define VCMD_JPEGD_MODULE_MAIN_ADDR_1             0x0000    /*customer specify according to own platform*/
#define VCMD_JPEGD_MODULE_DEC400_ADDR_1           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_JPEGD_MODULE_L2CACHE_ADDR_1          0XFFFF
#define VCMD_JPEGD_MODULE_MMU_ADDR_1              0XFFFF

#define VCMD_JPEGD_IO_ADDR_2                      0xD2000   /*customer specify according to own platform*/
#define VCMD_JPEGD_IO_SIZE_2                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_JPEGD_INT_PIN_2                      -1
#define VCMD_JPEGD_MODULE_TYPE_2                  4
#define VCMD_JPEGD_MODULE_MAIN_ADDR_2             0x0000    /*customer specify according to own platform*/
#define VCMD_JPEGD_MODULE_DEC400_ADDR_2           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_JPEGD_MODULE_L2CACHE_ADDR_2          0XFFFF
#define VCMD_JPEGD_MODULE_MMU_ADDR_2              0XFFFF

#define VCMD_JPEGD_IO_ADDR_3                      0xD3000   /*customer specify according to own platform*/
#define VCMD_JPEGD_IO_SIZE_3                      (ASIC_VCMD_SWREG_AMOUNT * 4)    /* bytes */
#define VCMD_JPEGD_INT_PIN_3                      -1
#define VCMD_JPEGD_MODULE_TYPE_3                  4
#define VCMD_JPEGD_MODULE_MAIN_ADDR_3             0x0000    /*customer specify according to own platform*/
#define VCMD_JPEGD_MODULE_DEC400_ADDR_3           0XFFFF    /*0xffff means no such kind of submodule*/
#define VCMD_JPEGD_MODULE_L2CACHE_ADDR_3          0XFFFF
#define VCMD_JPEGD_MODULE_MMU_ADDR_3              0XFFFF

/*these size need to be modified according to hw config.*/
#define VCMD_ENCODER_REGISTER_SIZE              (479 * 4)
#define VCMD_DECODER_REGISTER_SIZE              (512 * 4)
#define VCMD_IM_REGISTER_SIZE                   (479 * 4)
#define VCMD_JPEG_ENCODER_REGISTER_SIZE         (479 * 4)
#define VCMD_JPEG_DECODER_REGISTER_SIZE         (512 * 4)

#define HW_WORK_STATE_PEND            3

#define MAX_CMDBUF_INT_NUMBER         1
#define INT_MIN_SUM_OF_IMAGE_SIZE    (4096*2160*MAX_SAME_MODULE_TYPE_CORE_NUMBER*MAX_CMDBUF_INT_NUMBER)
#define MAX_PROCESS_CORE_NUMBER         4*8
#define PROCESS_MAX_VIDEO_SIZE          (4096*2160*MAX_SAME_MODULE_TYPE_CORE_NUMBER*MAX_PROCESS_CORE_NUMBER)
#define PROCESS_MAX_JPEG_SIZE           (2147483648) //32768*32768*2
#define PROCESS_MAX_SUM_OF_IMAGE_SIZE   (PROCESS_MAX_VIDEO_SIZE>PROCESS_MAX_JPEG_SIZE?PROCESS_MAX_VIDEO_SIZE:PROCESS_MAX_JPEG_SIZE)


/********variables declaration related with race condition**********/

#define REG_PACKAGE_SIZE     (CMDBUF_MAX_SIZE / 2)

//#define DDR_BASE_ADDR				(0x800000000)

#define VCMD_DEC_DDR_SIZE                   (1024 * 1024 * 5)
#define VCMD_DEC_DDR_BASE_ADDR_0            (0x80E000000)
#define VCMD_DEC_DDR_BASE_ADDR_1            (VCMD_DEC_DDR_BASE_ADDR_0 + VCMD_DEC_DDR_SIZE)
#define VCMD_DEC_DDR_BASE_ADDR_2            (VCMD_DEC_DDR_BASE_ADDR_1 + VCMD_DEC_DDR_SIZE)
#define VCMD_DEC_DDR_BASE_ADDR_3            (VCMD_DEC_DDR_BASE_ADDR_2 + VCMD_DEC_DDR_SIZE)
#define VCMD_DEC_DDR_BASE_ADDR_4            (VCMD_DEC_DDR_BASE_ADDR_3 + VCMD_DEC_DDR_SIZE)
//#define VCMD_DEC_OFFSET_ADDR              (VCMD_DDR_BASE_ADDR - DDR_BASE_ADDR)

#define align(x, y) (x + (y - 1)) / y

#define HW_VCMD_IRQ_INTCMD_MASK  (0xFFFF << 16)
#define HW_VCMD_IRQ_RESET_MASK   (1 << 5)
#define HW_VCMD_IRQ_ABORT_MASK   (1 << 4)
#define HW_VCMD_IRQ_CMDERR_MASK  (1 << 3)
#define HW_VCMD_IRQ_TIMEOUT_MASK (1 << 2)
#define HW_VCMD_IRQ_BUSERR_MASK  (1 << 1)
#define HW_VCMD_IRQ_ENDCMD_MASK  (1 << 0)
#define HW_VCMD_IRQ_DEC_MASK  (0x40)

#define VASTAI_MAX_DECODER_CORES  5
#define VASTAI_MAX_VDMCU_CORES  3

#define VASTAI_DEC_CORE0  VDMCU0_2_HOST_INT
#define VASTAI_DEC_CORE1  VDMCU1_2_HOST_INT
#define VASTAI_DEC_CORE2  VDMCU2_2_HOST_INT
#define CORE0_IRQ_BASE    VASTAI_DEC_CORE0

#define TO_MCU_DATA_TYPE  0
#define TO_MCU_CMDBUF_LEN 1

#define MAX_DECODE_CAPACITY		(60 * 1000 * 2)
#define MAX_SUPPORTED_RESOLUTION	(7680 * 4320)
#define BASE_DECODE_RESOLUTION		(1920 * 1080)

#define MAX_MULTICORE_DEC_CHN_BUM 32

extern struct dma_trans *dma_trans_tx;
enum data_subtype {
       VCMD,
       STREAM,
       SUB_TYPE_MAX,
};

/*for all vcmds, the core info should be listed here for subsequent use*/
struct vcmd_config vcmd_core_array[MAX_SUBSYS_NUM]= {
    //decoder configuration
    {VCMD_DEC_IO_ADDR_0,
    VCMD_DEC_IO_SIZE_0,
    VCMD_DEC_INT_PIN_0,
    VCMD_DEC_MODULE_TYPE_0,
    VCMD_DEC_MODULE_MAIN_ADDR_0,
    VCMD_DEC_MODULE_DEC400_ADDR_0,
    VCMD_DEC_MODULE_L2CACHE_ADDR_0,
    VCMD_DEC_MODULE_MMU_ADDR_0},

    {VCMD_DEC_IO_ADDR_1,
    VCMD_DEC_IO_SIZE_1,
    VCMD_DEC_INT_PIN_1,
    VCMD_DEC_MODULE_TYPE_1,
    VCMD_DEC_MODULE_MAIN_ADDR_1,
    VCMD_DEC_MODULE_DEC400_ADDR_1,
    VCMD_DEC_MODULE_L2CACHE_ADDR_1,
    VCMD_DEC_MODULE_MMU_ADDR_1},
};


//#define CSRAM_BASE_ADDR          				(0x8C00000)
/* vdmcu write hw_id build_id to host addr, ASIC_ID:4B HW_BUILDID:4B L2_CACHE_VERSION:4B reserved:4B*/
#define VDEC0_REPORT_ID_ADDR        			(CSRAM_BASE_ADDR + 0x000F0800) // 16 bytes
#define VDEC1_REPORT_ID_ADDR        			(CSRAM_BASE_ADDR + 0x000F0810) // 16 bytes
#define VDEC2_REPORT_ID_ADDR        			(CSRAM_BASE_ADDR + 0x000F0820) // 16 bytes
#define VDEC3_REPORT_ID_ADDR        			(CSRAM_BASE_ADDR + 0x000F0830) // 16 bytes
#define VDEC4_REPORT_ID_ADDR        			(CSRAM_BASE_ADDR + 0x000F0840) // 16 bytes

static u64 VDEC_REPORT_ID_ADDR[5] = {VDEC0_REPORT_ID_ADDR, VDEC1_REPORT_ID_ADDR, VDEC2_REPORT_ID_ADDR, VDEC3_REPORT_ID_ADDR, VDEC4_REPORT_ID_ADDR};

extern unsigned long gBaseDDRHw;        /* PCI base register address (memalloc) */
extern unsigned int mmu_enable;

#define DECODERID_2_VDMCUID(core)              ((core) > NORMAL2 ? ((core) - NORMAL2) : (core))
#define VDMCUID_2_AV1DECODERID(core)           ((core) == VDMCU1 ? AV10 : ( (core) == VDMCU2 ? AV11 : -1))
#define DECODERID_2_DECODERTYPE(core)          ((core) > NORMAL2 ? AV1_DECODE : NORMAL_DECODE)

/***************************TYPE AND FUNCTION DECLARATION****************/

/* here's all the must remember stuff */

static int allocate_cmdbuf(struct die_info *die, struct noncache_mem* new_cmdbuf_addr, struct noncache_mem* new_status_cmdbuf_addr, u16 core_id);


/*********************local variable declaration*****************/
/* and this is our MAJOR; use 0 for dynamic allocation (recommended)*/
int total_vcmd_core_num = 0;

extern unsigned int vcmd;
extern struct subsys_config vpu_subsys[MAX_SUBSYS_NUM];

static int vastai_pci_done_callback(void *pci_dev, u32 die_id, int irq, void *die_info, void *mcu_msg)
{
	dec_result_t* get_msg = (dec_result_t *)mcu_msg;
	u32 irq_status = get_msg->status;
	u32 cmdbuf_id = get_msg->cmd_id;
	u32 core_id = get_msg->core_id;
	u32 mcu_ccount = get_msg->mcu_ccount;
	u32 cycles = get_msg->cycles;
	struct die_info* die = (struct die_info*)die_info;
	int ret = 0;
	int work_ret = 0;
	struct vastaivcmd_dev *dev = &(die->vastaivcmd_data[core_id]);
	dev->mcu_vcmd_status = irq_status;

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		"in_fifo: core[%d] ---> cmdbuf_id=%d -- mcu_vcmd_status = %d \n",
		core_id, cmdbuf_id, irq_status);

#if 0
	if (irq_status != CMDBUF_EXE_STATUS_OK) {
		printk(KERN_INFO "vastaivcmd_isr error,irq_status :0x%x", irq_status);
		return IRQ_HANDLED;
	}
#endif

	ret = vastai_cmdid_enqueue(&dev->cmdbufId_queue, cmdbuf_id, irq_status, mcu_ccount, cycles);
	if (ret) {
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
			"cmdbuf id queue is full, return!\n");
		return ret;
	}

	if (cmdbuf_id >= TOTAL_DISCRETE_CMDBUF_NUM) {
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
			"vastaivcmd_isr error cmdbuf_id greater than the ceiling !!\n");
		return ret;
	}

	work_ret = queue_work(die->workqueue, &(dev->work));

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		"pcie-callback-done: core[%d] ---> cmdbuf_id=%d -- irq_status=0x%x work_ret=%d\n",
		core_id, cmdbuf_id, irq_status, work_ret);
	return ret;
}

void vcmd_workqueue_schedue(struct work_struct *work)
{
	struct vastaivcmd_dev *dev = container_of(work, struct vastaivcmd_dev, work);

	unsigned int handled = 0;
	struct cmdbuf_obj* cmdbuf_obj = NULL;
	u32 cmdbuf_id = 0;
	u32 irq_status = 0, ret = 0;
	u32 mcu_ccount = 0;
	u32 cycles = 0;
    struct vastai_video_info *video_info = NULL;

	VAVIDEO_DBG(dev->die->vcmd_pri, (u8)dev->die->die_id,
		"\x1b[31m ++++%s-> workqueue debug  \x1b[0m \n", __func__);

	while (ret == 0) {
		ret = vastai_cmdid_dequeue(&dev->cmdbufId_queue, &cmdbuf_id, &irq_status, &mcu_ccount, &cycles);
		if (ret) {
			break;
		}
		VAVIDEO_DBG(dev->die->vcmd_pri, (u8)dev->die->die_id,
			"out_fifo:die[%d] core[%d] ---> cmdbuf_id=%d -- mcu_vcmd_status=%d \n",
			dev->die->die_id, dev->core_id, cmdbuf_id, irq_status);
		//mutex_lock(&dev->mutex);
		if (cmdbuf_id) {
			if (cmdbuf_id >= TOTAL_DISCRETE_CMDBUF_NUM) {
				VAVIDEO_ERR(dev->die->vcmd_pri, (u8)dev->die->die_id,
					"vastaivcmd_isr error cmdbuf_id greater than the ceiling !!\n");
				//mutex_unlock(&dev->mutex);
				continue;

			}
			cmdbuf_obj = &dev->cmdbuf_obj_sets[cmdbuf_id];
			if (cmdbuf_obj == NULL) {
				VAVIDEO_ERR(dev->die->vcmd_pri, (u8)dev->die->die_id,
					"vastaivcmd_isr error cmdbuf_id !!\n");
				//mutex_unlock(&dev->mutex);
				continue;

			}
			cmdbuf_obj->executing_status = irq_status;
			if (dev->cmdbuf_used[cmdbuf_id] == 1) {
				cmdbuf_obj->cmdbuf_run_done = 1;
				cmdbuf_obj->mcu_ccount = mcu_ccount;
				cmdbuf_obj->cycles = cycles;
				if (cmdbuf_obj->filp != NULL) {
                    video_info = (struct vastai_video_info *)cmdbuf_obj->filp->private_data;
                    if (video_info == NULL) {
                        VAVIDEO_ERR(dev->die->vcmd_pri, (u8)dev->die->die_id, "video_info is null !!\n");
                    }
                    wake_up_interruptible(&video_info->wait_queue);
                }
			}
			//complete(&cmdbuf_obj->vcmd_process_comp);
			handled++;
		}
		//mutex_unlock(&dev->mutex);
	}

	if (!handled) {
		VAVIDEO_DBG(dev->die->vcmd_pri, (u8)dev->die->die_id,
			"IRQ received, but not process!\n");
	}
}

void PrintInstr(u32 i, u32 instr, u32 *size) {
  if ((instr & 0xF8000000) == OPCODE_WREG) {
    int length = ((instr >> 16) & 0x3FF);
	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s %s %d 0x%x]\n",
           i, instr, "WREG", ((instr >> 26) & 0x1) ? "FIX" : "",
           length, (instr & 0xFFFF));
    *size = ((length+2)>>1)<<1;
  } else if ((instr & 0xF8000000) == OPCODE_END) {
  	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s]\n", i, instr, "END");
    *size = 2;
  } else if ((instr & 0xF8000000) == OPCODE_NOP) {
  	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s]\n", i, instr, "NOP");
    *size = 2;
  } else if ((instr & 0xF8000000) == OPCODE_RREG) {
    int length = ((instr >> 16) & 0x3FF);
	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s %s %d 0x%x]\n",
           i, instr, "RREG", ((instr >> 26) & 0x1) ? "FIX" : "",
           length, (instr & 0xFFFF));
    *size = 4;
  } else if ((instr & 0xF8000000) == OPCODE_JMP) {
  	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s %s %s]\n",
           i, instr, "JMP", ((instr >> 26) & 0x1) ? "RDY" : "",
           ((instr >> 25) & 0x1) ? "IE" : "");
    *size = 4;
  } else if ((instr & 0xF8000000) == OPCODE_STALL) {
  	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s %s 0x%x]\n",
           i, instr, "STALL", ((instr >> 26) & 0x1) ? "IM" : "",
           (instr & 0xFFFF));
    *size = 2;
  } else if ((instr & 0xF8000000) == OPCODE_CLRINT) {
  	VAVIDEO_INFO(NULL, DUMMY_DIE_ID,
           "current cmdbuf data %d = 0x%08x => [%s %d 0x%x]\n",
           i, instr, "CLRINT", (instr >> 25) & 0x3,
           (instr & 0xFFFF));
    *size = 2;
  } else
    *size = 1;
}

static void free_cmdbuf_mem(struct die_info *die, u32 cmdbuf_id, u32 core_id)
{
    //spin_lock_irqsave(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_alloc_lock, flags);
    die->vastaivcmd_data[core_id].cmdbuf_used[cmdbuf_id] = 0;
    mutex_lock(&die->vastaivcmd_data[core_id].mutex);
    die->vastaivcmd_data[core_id].cmdbuf_used_residual += 1;
    mutex_unlock(&die->vastaivcmd_data[core_id].mutex);
    //spin_unlock_irqrestore(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_alloc_lock, flags);
    wake_up_interruptible_sync(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_memory_wait);
}

static void clean_cmdbuf_obj(struct cmdbuf_obj* cmdbuf_obj, u32 cmdbuf_id, u32 core_id, struct die_info* die)
{
	if (cmdbuf_obj == NULL) {
		VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "remove_cmdbuf_node NULL");
		return;
	}

	cmdbuf_obj->cmdbuf_need_remove = 1;
	cmdbuf_obj->cmdbuf_busAddress = 0;
	cmdbuf_obj->cmdbuf_size = 0;
	cmdbuf_obj->cmdbuf_id = -1;
	cmdbuf_obj->status_busAddress = 0;
	cmdbuf_obj->status_size = 0;
	cmdbuf_obj->module_type = -1;
	cmdbuf_obj->core_id = -1;
	cmdbuf_obj->filp = NULL;
	cmdbuf_obj->cmdbuf_run_done = 0;
//	cmdbuf_obj->cmdbuf_done_flag = 0;

	free_cmdbuf_mem(die, cmdbuf_id, core_id);
	return;
}

static struct cmdbuf_obj* create_cmdbuf_obj(struct die_info *die, u16 core_id)
{
	/* bi_list_node* current_node=NULL; */
	struct cmdbuf_obj* cmdbuf_obj = NULL;
	struct noncache_mem  new_cmdbuf_addr = {0};
	struct noncache_mem  new_status_cmdbuf_addr = {0};
	u16 get_cmdbuf_id = -1;

	if(wait_event_interruptible_exclusive(die->vastaivcmd_data[core_id].vcmd_cmdbuf_memory_wait, allocate_cmdbuf(die, &new_cmdbuf_addr, &new_status_cmdbuf_addr, core_id)))
			return NULL;

    get_cmdbuf_id = new_cmdbuf_addr.cmdbuf_id;

	cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[get_cmdbuf_id]);
	cmdbuf_obj->cmdbuf_busAddress = new_cmdbuf_addr.busAddress;
	cmdbuf_obj->cmdbuf_size = new_cmdbuf_addr.size;
	cmdbuf_obj->cmdbuf_id = new_cmdbuf_addr.cmdbuf_id;
	cmdbuf_obj->status_busAddress = new_status_cmdbuf_addr.busAddress;
	cmdbuf_obj->status_size = new_status_cmdbuf_addr.size;

	return cmdbuf_obj;
}

/**********************************************************************************************************\
*cmdbuf pool management
\***********************************************************************************************************/
static int allocate_cmdbuf(struct die_info *die, struct noncache_mem* new_cmdbuf_addr, struct noncache_mem* new_status_cmdbuf_addr, u16 core_id)
{
	u16 i = 0;

	mutex_lock(&die->vastaivcmd_data[core_id].mutex);
	//spin_lock_irqsave(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_alloc_lock, flags);
	if (die->vastaivcmd_data[core_id].cmdbuf_used_residual == 0) {
		mutex_unlock(&die->vastaivcmd_data[core_id].mutex);
		//spin_unlock_irqrestore(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_alloc_lock, flags);
		//no empty cmdbuf
		return 0;
	}
	//there is one cmdbuf at least
	while (1) {
		i = die->vastaivcmd_data[core_id].cmdbuf_used_pos;
		if (die->vastaivcmd_data[core_id].cmdbuf_used[i] == 0) {

			die->vastaivcmd_data[core_id].cmdbuf_used[i] = 1;
			die->vastaivcmd_data[core_id].cmdbuf_used_residual -=1;

			new_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
			new_cmdbuf_addr->cmdbuf_id = i;

			new_cmdbuf_addr->busAddress = die->vastaivcmd_data[core_id].vcmd_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
			new_cmdbuf_addr->mmu_bus_address = die->vastaivcmd_data[core_id].vcmd_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;
			new_status_cmdbuf_addr->busAddress = die->vastaivcmd_data[core_id].vcmd_status_buf_mem_pool.busAddress + i * CMDBUF_MAX_SIZE;
			new_status_cmdbuf_addr->mmu_bus_address = die->vastaivcmd_data[core_id].vcmd_status_buf_mem_pool.mmu_bus_address + i * CMDBUF_MAX_SIZE;

			new_status_cmdbuf_addr->size = CMDBUF_MAX_SIZE;
			new_status_cmdbuf_addr->cmdbuf_id = i;
			die->vastaivcmd_data[core_id].cmdbuf_used_pos++;

			if (die->vastaivcmd_data[core_id].cmdbuf_used_pos >= TOTAL_DISCRETE_CMDBUF_NUM)
				die->vastaivcmd_data[core_id].cmdbuf_used_pos=0;

			mutex_unlock(&die->vastaivcmd_data[core_id].mutex);
			//spin_unlock(&die->vastaivcmd_data[core_id].vcmd_cmdbuf_alloc_lock);
			return 1;
		} else {
			die->vastaivcmd_data[core_id].cmdbuf_used_pos++;
			if(die->vastaivcmd_data[core_id].cmdbuf_used_pos >= TOTAL_DISCRETE_CMDBUF_NUM)
				die->vastaivcmd_data[core_id].cmdbuf_used_pos=0;
		}
	}
	return 0;
}

#if 0
static void dump_cmdbuf(struct die_info *die, u16 core_id)
{
    u16 i = 0;
    u32 used =0;
    struct cmdbuf_obj* cmdbuf_obj=NULL;

    //there is one cmdbuf at least

    for(i=0;i<TOTAL_DISCRETE_CMDBUF_NUM;i++)
    {
        used = die->vastaivcmd_data[core_id].cmdbuf_used[i];
        cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[i]);
        printk("id,%d, used %d, run %d, file 0x%x\n",i, used, cmdbuf_obj->cmdbuf_run_done, cmdbuf_obj->filp);

    }
    printk("core %d, pos %d, residual %d\n",core_id,die->vastaivcmd_data[core_id].cmdbuf_used_pos, die->vastaivcmd_data[core_id].cmdbuf_used_residual);
}
#endif

static long reserve_cmdbuf(struct file *filp, struct die_info *die, struct exchange_parameter* input_para)
{
  struct cmdbuf_obj* cmdbuf_obj=NULL;

  input_para->cmdbuf_id = 0;
  if (input_para->cmdbuf_size > CMDBUF_MAX_SIZE) {
    return -1;
  }
  VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
	  "core[%d]:reserve cmdbuf filp %p\n", input_para->core_id, (void *)filp);

  cmdbuf_obj = create_cmdbuf_obj(die, input_para->core_id);
  if (cmdbuf_obj == NULL) {
	  VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
	      "%s: core[%d] create_cmdbuf_obj failed \n", __func__, input_para->core_id);
	  return -1;
  }

  cmdbuf_obj->module_type = input_para->module_type;
  cmdbuf_obj->priority = input_para->priority;
  cmdbuf_obj->executing_time = input_para->executing_time;
  cmdbuf_obj->cmdbuf_size = CMDBUF_MAX_SIZE;
  cmdbuf_obj->core_id = input_para->core_id;
  cmdbuf_obj->cmdbuf_run_done = 0;
  cmdbuf_obj->filp = filp;
  input_para->cmdbuf_size = CMDBUF_MAX_SIZE;
  input_para->cmdbuf_id = cmdbuf_obj->cmdbuf_id;

  //reinit_completion(&cmdbuf_obj->vcmd_process_comp);

  return 0;
}

static long release_cmdbuf(struct file *filp, u16 cmdbuf_id, u16 core_id, struct die_info* die)
{
	struct cmdbuf_obj* cmdbuf_obj=NULL;

	cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[cmdbuf_id]);
	if (cmdbuf_obj->filp!=filp ||  core_id != cmdbuf_obj->core_id) {
		//should not happen
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"%s:%d-->vastaivcmd:core[%d] ERROR cmdbuf_id=%d !!\n",
				__func__, __LINE__, core_id, cmdbuf_obj->cmdbuf_id);
		return -1;
	}

	clean_cmdbuf_obj(cmdbuf_obj, cmdbuf_id, core_id, die);

	return 0;
}

static long link_and_run_cmdbuf(struct file *filp, struct exchange_parameter* input_para, struct die_info *die_info)
{
  struct cmdbuf_obj* cmdbuf_obj=NULL;
  struct vastai_pci_info *pcie_dev = (struct vastai_pci_info *)die_info->vcmd_pri;
  struct vastaivcmd_dev* dev=NULL;
  int total = 0, count = 0, ret = -1, msg_len = 2;
  struct vastai_dmadesc *dma_buf = NULL;
  union core_bitmap triger_core = {{0}};
  u32* user_vcmd_end = NULL;
  packet_t* vcmd_msg_package = NULL;
  u16 cmdbuf_id = input_para->cmdbuf_id;
  u16 core_id = input_para->core_id;
  int retry;

  cmdbuf_obj = &(die_info->vastaivcmd_data[core_id].cmdbuf_obj_sets[cmdbuf_id]);
  if (cmdbuf_obj->core_id != input_para->core_id) {
    //should not happen
    VAVIDEO_ERR(pcie_dev, (u8)die_info->die_id,
    	"vastaivcmd: ERROR cmdbuf_id=%d ----> core[%d] !!\n", cmdbuf_id, core_id);
	BUG_ON(1);
  }

  if (cmdbuf_obj->filp!=filp) {
    //should not happen
    VAVIDEO_ERR(pcie_dev, (u8)die_info->die_id,
    	"%s:%d vastaivcmd: ERROR cmdbuf_id !!\n", __func__, __LINE__);
    return -1;
  }

  cmdbuf_obj->cmdbuf_data_loaded = 1;
  cmdbuf_obj->cmdbuf_size = input_para->cmdbuf_size;// (16 + offset_inc)*4
  cmdbuf_obj->waited = 0;

  #ifdef VCMD_DEBUG_INTERNAL
  {
    u32 i, inst = 0, size = 0, ptr = 0;
    VAVIDEO_INFO(pcie_dev, (u8)die_info->die_id, "vcmd link, current cmdbuf content\n");
    for(i=0;i<cmdbuf_obj->cmdbuf_size/4;i++)
    {
    __get_user(inst, (u32*)input_para->vcmdbuf_desc.vcmdbuf_src_addr + i);
      if (i == ptr) {
        PrintInstr(i, inst, &size);
        ptr += size;
      } else {
        VAVIDEO_INFO(pcie_dev, (u8)die_info->die_id, "current cmdbuf data %d = 0x%x\n",i, inst);;
      }
    }
  }
  #endif

  cmdbuf_obj->has_end_cmdbuf = 0; //0: has jmp opcode,1 has end code
  cmdbuf_obj->no_normal_int_cmdbuf = 1; //0: interrupt when JMP,1 not interrupt when JMP
  cmdbuf_obj->cmdbuf_User_virtualAddress = (u32*)(input_para->vcmdbuf_desc.vcmdbuf_src_addr);


  dev = &(die_info->vastaivcmd_data[core_id]);

  VAVIDEO_DBG(pcie_dev, (u8)die_info->die_id,
  	"Allocate cmd buffer [%d] to core [%d]\n", cmdbuf_id, input_para->core_id);

  user_vcmd_end = (u32 *)(input_para->vcmdbuf_desc.vcmdbuf_src_addr) + (cmdbuf_obj->cmdbuf_size/4);

  vcmd_msg_package = (packet_t *)kmalloc(sizeof(packet_t), GFP_KERNEL);
  if (vcmd_msg_package == NULL) {
	  VAVIDEO_ERR(pcie_dev, (u8)die_info->die_id,
	  	"kvzalloc for vcmd_dec_package fail!");
	  return -ENOMEM;
  }

  vcmd_msg_package->header.magic = MAGIC_NUMBER;
  vcmd_msg_package->header.len = sizeof(packet_t);
  vcmd_msg_package->header.channel = input_para->vcmdbuf_desc.channel;
  vcmd_msg_package->header.type = DECODERID_2_DECODERTYPE(input_para->core_id);
  vcmd_msg_package->header.cmd = DECODE;
  vcmd_msg_package->payload.len = cmdbuf_obj->cmdbuf_size;
  vcmd_msg_package->payload.cmd_id = cmdbuf_id;

  VAVIDEO_DBG(pcie_dev, (u8)die_info->die_id,
  	"\x1b[31m ++++%s->core[%d] ----> channel=%d cmdbuf_id=%d(size=%d)  \x1b[0m \n",
  	__func__, core_id, vcmd_msg_package->header.channel, cmdbuf_id, cmdbuf_obj->cmdbuf_size);
  VAVIDEO_DBG(pcie_dev, (u8)die_info->die_id,
  	"\x1b[31m ++++%s->to user:msg_len = %d  \x1b[0m \n",
  	__func__, vcmd_msg_package->header.len);

  dev->dma_package_size = cmdbuf_obj->cmdbuf_size + vcmd_msg_package->header.len + input_para->vcmdbuf_desc.stream_size;
  VAVIDEO_DBG(pcie_dev, (u8)die_info->die_id,
  	"\x1b[31m ++++%s->dma_package_size = %d  \x1b[0m \n",
  	__func__, dev->dma_package_size);

  if(video_copy_to_user((u32*)(user_vcmd_end), vcmd_msg_package, vcmd_msg_package->header.len)){
	kfree(vcmd_msg_package);
	return -EFAULT;
  }

  kfree(vcmd_msg_package);

  /************************ dma-api ******************************/

  total = input_para->vcmdbuf_desc.stream_size / 0x400000;
  if (input_para->vcmdbuf_desc.stream_size % 0x400000 != 0) {
	  total++;
  }

  dma_buf = kmalloc((total + 1) * sizeof(struct vastai_dmadesc), GFP_KERNEL);
  triger_core.decode = BIT(DECODERID_2_VDMCUID(input_para->core_id));
  dma_buf[VCMD].is_src_not_user_mem = 0;
  dma_buf[VCMD].is_src_dma_addr = 0;
  dma_buf[VCMD].is_host_to_dev = 1;
  dma_buf[VCMD].host_addr.vir_addr = (void*)(input_para->vcmdbuf_desc.vcmdbuf_src_addr);
  dma_buf[VCMD].dev_addr = cmdbuf_obj->cmdbuf_busAddress;
  dma_buf[VCMD].dma_lenth = cmdbuf_obj->cmdbuf_size + sizeof(header_t) + msg_len * 4;
  dma_buf[VCMD].user_prive[TO_MCU_DATA_TYPE] = VCMD;
  dma_buf[VCMD].user_prive[TO_MCU_CMDBUF_LEN] = cmdbuf_obj->cmdbuf_size;

  while (count < total) {
	  dma_buf[STREAM + count].is_src_not_user_mem = 0;
	  dma_buf[STREAM + count].is_src_dma_addr = 0;
	  dma_buf[STREAM + count].is_host_to_dev = 1;
	  dma_buf[STREAM + count].host_addr.vir_addr = (void*)(input_para->vcmdbuf_desc.stream_src_addr + count * 0x400000);
	  dma_buf[STREAM + count].dma_lenth = (count == total-1) ? input_para->vcmdbuf_desc.stream_size % 0x400000 : 0x400000;
	  dma_buf[STREAM + count].dev_addr = input_para->vcmdbuf_desc.stream_dst_addr + count * 0x400000;
	  dma_buf[STREAM + count].user_prive[TO_MCU_DATA_TYPE] = STREAM;
	  dma_buf[STREAM + count].user_prive[TO_MCU_CMDBUF_LEN] = 0;
	  count++;
  }

  retry = 5;
  while(ret && retry) {
	ret = vastai_pci_dma_transfer_sync(pcie_dev,  die_info->die_id, triger_core, dma_buf, total + 1, -1);
	if (ret != 0) {
		if (ret == -EBUSY) {
			VAVIDEO_INFO(pcie_dev, (u8)die_info->die_id,
				"warning vastai_pci_dma_transfer_sync: ret = %d !!\n", ret);
			mdelay(200);
			retry--;
		} else {
			VAVIDEO_ERR(pcie_dev, (u8)die_info->die_id,
				"error vastai_pci_dma_transfer_sync: ret = %d !!\n", ret);
			break;
		}
	}
  }

  kfree(dma_buf);

  return ret;
}

static int check_cmdbuf_irq(struct vastaivcmd_dev* dev,struct cmdbuf_obj* cmdbuf_obj,u32 *irq_status_ret, u32 *mcu_ccount, u32 *cycles)
{
  int rdy = 0;

  if (dev->decoder_crash_flag) {
    cmdbuf_obj->executing_status = CMDBUF_EXE_STATUS_RESET;
    cmdbuf_obj->cmdbuf_run_done = 1;
  }

  if(cmdbuf_obj->cmdbuf_run_done != 0)
  {
    rdy = 1;
    cmdbuf_obj->cmdbuf_run_done = 0;
    *irq_status_ret=cmdbuf_obj->executing_status;//need to decide how to assign this variable
    *mcu_ccount = cmdbuf_obj->mcu_ccount;
    *cycles = cmdbuf_obj->cycles;
  }
  return rdy;
}

/******************************************************************************/
static int check_mc_cmdbuf_irq(struct file *filp, struct vastaivcmd_dev* dev, struct cmdbuf_obj* cmdbuf_obj,u32 *irq_status_ret, u32 * cmdbuf_id, u32 *mcu_ccount, u32 *cycles)
{
  int k;

  for(k=0;k<TOTAL_DISCRETE_CMDBUF_NUM;k++)
  {
    cmdbuf_obj = &(dev->cmdbuf_obj_sets[k]);

//    if(cmdbuf_obj->waited==1)
//        continue;

    if(cmdbuf_obj->filp != filp){
		continue;
	}
        

    if (check_cmdbuf_irq(dev, cmdbuf_obj, irq_status_ret, mcu_ccount, cycles) == 1) {
      /* Return cmdbuf_id when ANY_CMDBUF_ID is used. */
      if (!cmdbuf_obj->waited) {
        *cmdbuf_id = cmdbuf_obj->cmdbuf_id;
        cmdbuf_obj->waited = 1;
        //printk("%s,%d ret OK, status 0x%x, cmdid %d\n",__func__,__LINE__, *irq_status_ret, *cmdbuf_id);
        return 1;
      }
    }
  }
//  printk("%s,%d ret 0\n",__func__,__LINE__);

  return 0;
}


static unsigned int wait_cmdbuf_ready(struct file *filp, u32 *cmdbuf_id, u32 core_id, u32 *status_ret, struct die_info* die, u32* mcu_ccount, u32* cycles)
{
  struct cmdbuf_obj* cmdbuf_obj = NULL;
  int ret = 0;
  struct vastaivcmd_dev* dev=NULL;
  struct vastai_video_info *video_info = NULL;

  VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
  	"%s:cmdbuf_id=%d, HZ=%d\n", __func__, *cmdbuf_id, HZ);
  dev = &die->vastaivcmd_data[core_id];
  video_info = (struct vastai_video_info *)filp->private_data;
  if (video_info == NULL) {
      VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "video_info is null !!\n");
  }


  if (*cmdbuf_id != ANY_CMDBUF_ID) {
	  cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[*cmdbuf_id]);
	  if(cmdbuf_obj->filp!=filp) {
		  //should not happen
		  VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
		  	"vastaivcmd:%s:%s:%d ERROR cmdbuf_id=%d !!\n", __FILE__, __func__, __LINE__, *cmdbuf_id);
		  return -1;
	  }
#if 0
	  ret = wait_for_completion_interruptible_timeout(&cmdbuf_obj->vcmd_process_comp,10 * HZ / 100);
	  if (ret == 0) {
		  VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		  	"%s: wait vcmd completion timeout core_id=%d cmdbuf_id=%d\n", __func__, core_id, cmdbuf_id );
		  //BUG_ON(1);
		  int i;
		 // for (i = 0; i < 3; i++ )
		  //	spin_lock(&die->vastaivcmd_data[i].vcmd_cmdbuf_alloc_lock);
		  //panic("oops");
	  }
#endif
	*mcu_ccount =  cmdbuf_obj->mcu_ccount;
	*cycles =  cmdbuf_obj->cycles;

    if (check_cmdbuf_irq(dev, cmdbuf_obj, status_ret, mcu_ccount, cycles) == 0) {
        ret = wait_event_interruptible(video_info->wait_queue, check_cmdbuf_irq(dev, cmdbuf_obj, status_ret, mcu_ccount, cycles));
        if (ret < 0) {
            VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "vcmd_wait_queue_0 interrupted\n");
            printk("\n\nvcmd_wait_queue_0 error\n\n\n");
            return -1;
        }
    }

    // if (pre_reset_flag) wait mcu reset ready flag
    if (dev->decoder_crash_flag == 1) {
        cmdbuf_obj->is_wakeup = 1;
        VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "wait event reset, core[%d], cmdbuf_id=%d\n", core_id, *cmdbuf_id);
        mutex_lock(&die->vastaivcmd_data[core_id].mutex);
        mutex_unlock(&die->vastaivcmd_data[core_id].mutex);

        cmdbuf_obj->is_wakeup = 0;

        VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "wait event reset done, core[%d], cmdbuf_id=%d\n", core_id, *cmdbuf_id);
        return 0;
    }

  } else {
     if (check_mc_cmdbuf_irq(filp, dev, cmdbuf_obj, status_ret, cmdbuf_id, mcu_ccount,cycles))
        return 0;
     ret = wait_event_interruptible_timeout(video_info->wait_queue, check_mc_cmdbuf_irq(filp, dev, cmdbuf_obj,status_ret, cmdbuf_id, mcu_ccount,cycles), 1*HZ);
     if (ret < 0) {
       VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "vcmd_wait_queue_0 interrupted: %d\n", ret);
       return -1;
     }
  }
 //     *status_ret = cmdbuf_obj->executing_status;//need to decide how to assign this variable
     VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
     	"%s: return,ret=%d, cmdbufid=%d, status=%d\n", __func__, ret, *cmdbuf_id, *status_ret);

     return 0;
}


void vastai_dec_pre_reset(void* arg, u32 core_id)
{
    struct die_info *die = (struct die_info*) arg;
    struct vastaivcmd_dev *dev = NULL;

    int i;
    //int vf_num;  //0   1-7
    struct cmdbuf_obj *cmdbuf_obj = NULL;
    struct vastai_video_info *video_info = NULL;
    int used_vcmd_num, wakeup_vcmd_num;
    int cmdbuf_id_start, cmdbuf_id_end;

    dev = &die->vastaivcmd_data[core_id];
    printk("pre_reset begin! die_info: %p, die_id: %d, core_id: %d\n", die, die->die_id, core_id);

#if 1
    mutex_lock(&die->vastaivcmd_data[core_id].mutex);
    // set flag for each vcmd obj
    dev->decoder_crash_flag = 1;

    cmdbuf_id_start = 2;
    cmdbuf_id_end = 255;

    // STEP1: find all used vcmd buf
    used_vcmd_num = 0;

    for (i=cmdbuf_id_start; i<cmdbuf_id_end; i++) {
        if (die->vastaivcmd_data[core_id].cmdbuf_used[i] == 1) {
            // Question2: can not wake up all wait threads on die, can not wake up thread on core?
            printk("cmdbuf_id %d used!\n", i);
            used_vcmd_num++;

            // STEP2: wake up all used vcmd
            cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[i]);
            if (cmdbuf_obj->filp != NULL) {
                video_info = (struct vastai_video_info *)cmdbuf_obj->filp->private_data;
                if (video_info == NULL) {
                    VAVIDEO_ERR(dev->die->vcmd_pri, (u8)dev->die->die_id, "video_info is null !!\n");
                }
                wake_up_interruptible(&video_info->wait_queue);
            }
        }
    } // endof for

    printk("used_vcmd_num = %d\n", used_vcmd_num);

    // STEP3: wait all vcmd buf ready
    while(1) {
        wakeup_vcmd_num = 0;

        for(i=cmdbuf_id_start; i<cmdbuf_id_end; i++) {
            cmdbuf_obj = &(die->vastaivcmd_data[core_id].cmdbuf_obj_sets[i]);
            if (die->vastaivcmd_data[core_id].cmdbuf_used[i] &&
                cmdbuf_obj->is_wakeup == 1) {
                    printk("cmdbuf_id %d wakeup!\n", i);
                    wakeup_vcmd_num ++;
                }
        }
        printk("wakeup_vcmd_num = %d\n", wakeup_vcmd_num);

        if (wakeup_vcmd_num >= used_vcmd_num)
            break;
        msleep(1);
    }
#endif
    printk("pre_reset done! die_info: %p\n", die);

}

void vastai_dec_post_reset(void * arg, u32 core_id)
{
    struct die_info *die = (struct die_info*) arg;
    struct vastaivcmd_dev *dev = NULL;
    struct vastai_pci_info *pcie_dev = (struct vastai_pci_info *)die->vcmd_pri;
    int die_id = vastai_pci_get_die_id(pcie_dev, die->die_id);
    
    dev = &die->vastaivcmd_data[core_id];

    if (dev->decoder_crash_flag) {
        printk("post_reset begin! die_info: %p, die_id: %d, core_id: %d\n", die, die->die_id, core_id);

        dev->decoder_crash_flag = 0;
        pcie_dev->dies[die_id].vdmcu_pre_addr_table[core_id] = 0;

        mutex_unlock(&die->vastaivcmd_data[core_id].mutex);

        printk("post_reset done! die_info: %p\n", die);
    }
}

static int vastai_release_core_channel(struct die_info* die, struct file *filp)
{
	struct list_head *p = NULL, *n = NULL;
	channel_desc_t *channel_desc = NULL;
	int i = 0;

	//spin_lock(&die->cfg_core_lock);
	mutex_lock(&die->allocate_core_mutex);
	list_for_each_safe(p, n, &die->die_channel_head) {
		channel_desc = list_entry(p, channel_desc_t, list);
		if (channel_desc->filp == filp) {
			list_del(&channel_desc->list);
			die->die_channels--;
			i = channel_desc->channel_info.core_id;
			die->dec_res.capacity[i] -= channel_desc->dec_ratio;
			VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
					"channel release: channel[%d] ---> core[%d], cap=%d\n",
					channel_desc->channel_info.channel,
					channel_desc->channel_info.core_id, die->dec_res.capacity[i]);
			kfree(channel_desc);
		}
	}
	//spin_unlock(&die->cfg_core_lock);
	mutex_unlock(&die->allocate_core_mutex);
	return 0;
}


static int list_available_channel(u32 channel, struct die_info* die)
{
	struct list_head *p = NULL;
	channel_desc_t *channel_desc = NULL;

	list_for_each(p, &die->die_channel_head) {
		channel_desc = list_entry(p, channel_desc_t, list);
		if (channel_desc->channel_info.channel == channel)
			return -1;
	}

	return 0;
}

static int vastai_find_core(int dec_ratio, decode_type_t type, struct die_info* die)
{
	int capacity = MAX_DECODE_CAPACITY;
	int i, index = 0, ret = 0;
	dec_res_t *dec_res = NULL;
	dec_res = &die->dec_res;

	if (type == NORMAL_DECODE)
	for (i = 0; i < die->core_num-2; i++) {
		if (capacity > dec_res->capacity[i]) {
			index = i;
			capacity = dec_res->capacity[i];
		}
	}
	else if (type == AV1_DECODE)
    for (i = 3; i < die->core_num; i++) {
        if (capacity > dec_res->capacity[i]) {
            index = i;
            capacity = dec_res->capacity[i];
        }
    }
	else {
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
        	"error: unknown decoder type.\n");
        ret = -1;
        goto exit;
    }

	if (MAX_DECODE_CAPACITY < (capacity + dec_ratio)) {
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
			"already beyond the max capacity.\n");
		ret = -1;
		goto exit;
	}

	capacity += dec_ratio;
	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		"%s: get core_id = %d, cur_capacity: %d\n", __func__, index, capacity);

	ret = index;

exit:
	return ret;
}

static int vastai_get_core_channel(channel_info_t *channel_info, struct die_info *die, struct file *filp)
{
	int ret = 0, dec_ratio = 0;
	channel_desc_t *channel_desc = NULL;
	u32 channel_id = 0;
    struct vastai_video_info *video_info = NULL;

    video_info = (struct vastai_video_info *)filp->private_data;
    if (video_info == NULL) {
        VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "video_info is null !!\n");
        return -1;
    }

	dec_ratio = ((channel_info->width * channel_info->height) * 1000 / BASE_DECODE_RESOLUTION);
	if(channel_info->width * channel_info->height >= MAX_SUPPORTED_RESOLUTION) {
		dec_ratio =  MAX_DECODE_CAPACITY;
	}

     init_waitqueue_head(&video_info->wait_queue);

	channel_desc = kzalloc(sizeof(channel_desc_t), GFP_KERNEL);
	channel_desc->dec_ratio = dec_ratio;

	//spin_lock(&die->cfg_core_lock);
	mutex_lock(&die->allocate_core_mutex);

	if (die->work_mode == DEC_MULTI_CORE_MODE && channel_info->type == NORMAL_DECODE) {
        if (die->die_channels < MAX_MULTICORE_DEC_CHN_BUM)
            ret = 0;
        else
            ret = -1;
	} else {
		/* find the core that has the minimum loading */
		ret = vastai_find_core(dec_ratio, channel_info->type, die);
	}

	if (ret < 0) {
		VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
			"cannot find suitable res to allocate.\n");
		ret = -1;
		goto exit;
	}

	die->dec_res.capacity[ret] += dec_ratio;
	channel_id = die->die_channels;
	while (list_available_channel(channel_id, die) < 0)
		channel_id++;
	channel_info->channel = channel_id;
	channel_info->core_id = ret;

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		"Done: channel=%d ---> core=%d\n", channel_info->channel, channel_info->core_id);

	channel_desc->channel_info = *channel_info;
	channel_desc->filp = filp;
	list_add(&channel_desc->list, &die->die_channel_head);
	die->die_channels++;
	//spin_unlock(&die->cfg_core_lock);
	mutex_unlock(&die->allocate_core_mutex);

	return 0;

exit:
	//spin_unlock(&die->cfg_core_lock);
	mutex_unlock(&die->allocate_core_mutex);
	kfree(channel_desc);
	return ret;
}

static void vastai_get_available_channels(channels_t *channels, struct die_info *die, struct file *filp)
{
	int i = 0, dec_ratio = 0;

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
		"Get channels, width=%d, height=%d, die id=%d, core_num=%d.\n",
		channels->width, channels->height, die->die_id, die->core_num);
	dec_ratio = ((channels->width * channels->height) * 1000 / BASE_DECODE_RESOLUTION);
	if(channels->width * channels->height >= MAX_SUPPORTED_RESOLUTION) {
		dec_ratio =  MAX_DECODE_CAPACITY;
	}

	for (i = 0; i < die->core_num; i++) {
		if (MAX_DECODE_CAPACITY < die->dec_res.capacity[i]) {
			continue;
		}
		channels->channels[i] = (MAX_DECODE_CAPACITY - die->dec_res.capacity[i])/dec_ratio;
	};
}

long vastaivcmd_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    int ret = 0, count = 0, total = 0;
    static int last_polling_cmd = 0;
//	struct drm_file *file_priv = filp->private_data;
	struct vastai_device_handle *device_handle = NULL;
	struct vastai_video_info *video_info = NULL;
	struct die_info *die = NULL;
	struct vastaivcmd_dev *vastaivcmd_data = NULL;
	struct vastai_pci_info *pcie_dev = NULL;
	struct vastai_dmadesc *dma_buf = NULL;
	union core_bitmap triger_core = {{0}};
#ifdef CONFIG_DRM_DRIVER
	struct drm_device* drm_dev = NULL;
#endif

    if (cmd != VASTAI_VCMD_IOCH_POLLING_CMDBUF) {
      last_polling_cmd = 0;
      VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "ioctl cmd 0x%08x\n", cmd);
    } else {
      if (!last_polling_cmd)
        VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "ioctl cmd 0x%08x\n", cmd);
      last_polling_cmd = 1;
    }
    /*
     * extract the type and number bitfields, and don't encode
     * wrong cmds: return ENOTTY (inappropriate ioctl) before access_ok()
     */
    if(_IOC_TYPE(cmd) != VASTAI_VCMD_IOC_MAGIC )
        return -ENOTTY;
    if((_IOC_TYPE(cmd) == VASTAI_VCMD_IOC_MAGIC &&
        _IOC_NR(cmd) > VASTAI_VCMD_IOC_MAXNR)  )
        return -ENOTTY;
    /*
     * the direction is a bitmask, and VERIFY_WRITE catches R/W
     * transfers. `Type' is user-oriented, while
     * access_ok is kernel-oriented, so the concept of "read" and
     * "write" is reversed
     */

    //device_handle = container_of(file_priv->minor->dev, struct vastai_device_handle, drm_dev);
    if (strncmp(filp->f_path.dentry->d_iname, VASTAI, sizeof(VASTAI) - 1)) {
#ifdef CONFIG_DRM_DRIVER
	struct drm_file *file_priv = filp->private_data;
	drm_dev = file_priv->minor->dev;
	device_handle = (struct vastai_device_handle *)drm_dev->dev_private;
#else
	VAVIDEO_DBG(NULL, DUMMY_DIE_ID, "not define drm\n");
	return -EFAULT;
#endif
    } else {
	video_info = (struct vastai_video_info *)filp->private_data;
	device_handle = video_info->dec_device_handle;
    }

	if (device_handle == NULL) {
		VAVIDEO_ERR(NULL, DUMMY_DIE_ID,
			"device_handle is null, return!\n");
		return -EFAULT;
	}

	if (atomic_read(&device_handle->die.decoder_state) != VIDEO_STATE_READY){
		VAVIDEO_ERR(device_handle->die.vcmd_pri,
					(u8)(device_handle->die.die_id),
					"current decoder state is not ready, return\n");
		return -EFAULT;
	}

    die = &device_handle->die;
    pcie_dev = (struct vastai_pci_info *)die->vcmd_pri;
    vastaivcmd_data = die->vastaivcmd_data;
	/* core_id = vastaivcmd_data->core_id; */

    switch (cmd) {
    case VASTAI_VCMD_IOCH_GET_CMDBUF_PARAMETER:
      {
       struct cmdbuf_mem_parameter local_cmdbuf_mem_data = {0};
	   u16 core_id = -1;

	   if (video_copy_from_user(&local_cmdbuf_mem_data, (struct cmdbuf_mem_parameter*)arg, sizeof(struct cmdbuf_mem_parameter))) {
		   return -EFAULT;
	   }
	   core_id = local_cmdbuf_mem_data.vcmd_core_id;
	   VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "core[%d]: get vcmdbuf param!!\n", core_id);

       local_cmdbuf_mem_data.cmdbuf_unit_size = CMDBUF_MAX_SIZE;
       local_cmdbuf_mem_data.status_cmdbuf_unit_size = CMDBUF_MAX_SIZE;
       local_cmdbuf_mem_data.cmdbuf_total_size = CMDBUF_POOL_TOTAL_SIZE;
       local_cmdbuf_mem_data.status_cmdbuf_total_size = CMDBUF_POOL_TOTAL_SIZE;
       local_cmdbuf_mem_data.phy_status_cmdbuf_addr = die->vastaivcmd_data[core_id].vcmd_status_buf_mem_pool.busAddress;
       local_cmdbuf_mem_data.phy_cmdbuf_addr = die->vastaivcmd_data[core_id].vcmd_buf_mem_pool.busAddress;

       local_cmdbuf_mem_data.mmu_phy_status_cmdbuf_addr = 0;
       local_cmdbuf_mem_data.mmu_phy_cmdbuf_addr = 0;
       local_cmdbuf_mem_data.vcmd_reg_mem_busAddress = 0;
       local_cmdbuf_mem_data.base_ddr_addr = 0;

	   local_cmdbuf_mem_data.vcmd_reg_mem_busAddress = vastaivcmd_data[core_id].vcmd_reg_mem_busAddress;

	   if (video_copy_to_user((struct cmdbuf_mem_parameter*)arg, &local_cmdbuf_mem_data, sizeof(struct cmdbuf_mem_parameter))) {
		   return -EFAULT;
	   }
       break;
      }
    case VASTAI_VCMD_IOCH_GET_VCMD_PARAMETER:
      {
       struct config_parameter input_para = {0};
       VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "VCMD get vcmd config parameter \n");
	   if (video_copy_from_user(&input_para,(struct config_parameter*)arg,sizeof(struct config_parameter))) {
		   return -EFAULT;
	   }
       if(die->vcmd_type_core_num[input_para.module_type])
       {
         input_para.submodule_main_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_main_addr;
         input_para.submodule_dec400_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_dec400_addr;
         input_para.submodule_L2Cache_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_L2Cache_addr;
         input_para.submodule_MMU_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_MMU_addr;
         input_para.submodule_MMUWrite_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_MMUWrite_addr;
         input_para.submodule_axife_addr = die->vcmd_manager[input_para.module_type][0]->vcmd_core_cfg.submodule_axife_addr;
         input_para.config_status_cmdbuf_id = die->vcmd_manager[input_para.module_type][0]->status_cmdbuf_id;
         input_para.vcmd_hw_version_id = die->vcmd_manager[input_para.module_type][0]->hw_version_id;
         input_para.vcmd_core_num = die->vcmd_type_core_num[input_para.module_type];
       }
       else
       {
         input_para.submodule_main_addr = 0xffff;
         input_para.submodule_dec400_addr = 0xffff;
         input_para.submodule_L2Cache_addr = 0xffff;
         input_para.submodule_MMU_addr = 0xffff;
         input_para.submodule_MMUWrite_addr = 0xffff;
         input_para.submodule_axife_addr = 0xffff;
         input_para.config_status_cmdbuf_id = 0;
         input_para.vcmd_core_num = 0;
         input_para.vcmd_hw_version_id =HW_ID_1_0_C;
       }
	   if (video_copy_to_user((struct config_parameter*)arg, &input_para, sizeof(struct config_parameter))) {
		   return -EFAULT;
	   }
       break;
      }
    case VASTAI_VCMD_IOCH_RESERVE_CMDBUF:
      {
       int ret = 0;
       struct exchange_parameter input_para = {0};
	   if (video_copy_from_user(&input_para, (struct exchange_parameter*)arg, sizeof(struct exchange_parameter))) {
		   return -EFAULT;
	   }
       VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "----core[%d]: VCMD Reserve CMDBUF\n", input_para.core_id);

       ret = reserve_cmdbuf(filp, die, &input_para);
	   if (ret == 0) {
		   if (video_copy_to_user((struct exchange_parameter*)arg, &input_para, sizeof(struct exchange_parameter))) {
			   return -EFAULT;
		   }
	   }
       return ret;
      }

    case VASTAI_VCMD_IOCH_LINK_RUN_CMDBUF:
      {
        struct exchange_parameter input_para = {0};
        long retVal = 0;
        VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "VCMD link and run cmdbuf\n");

		if (video_copy_from_user(&input_para,(struct exchange_parameter*)arg, sizeof(struct exchange_parameter))) {
			return -EFAULT;
		}

        retVal = link_and_run_cmdbuf(filp, &input_para, die);
		if (video_copy_to_user((struct exchange_parameter*)arg,&input_para,sizeof(struct exchange_parameter))) {
			return -EFAULT;
		}
        return retVal;
        break;
      }

    case VASTAI_VCMD_IOCH_WAIT_CMDBUF:
      {
	struct waitcmd_parameter wait_param = {0};
	u32 status_ret = -1, tmp = -1;
	u32 cmdbuf_id = -1;
	u32 core_id = -1;
	u32 mcu_ccount = 0;
	u32 cycles = 0;

	if (video_copy_from_user(&wait_param, (struct waitcmd_parameter*)arg, sizeof(struct waitcmd_parameter))) {
		return -EFAULT;
	}

	cmdbuf_id = wait_param.cmdbuf_id;
	core_id = wait_param.core_id;

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
			"core[%d] wait for CMDBUF. cmdbuf_id=%d\n", core_id, cmdbuf_id);

	tmp = wait_cmdbuf_ready(filp, &cmdbuf_id, core_id, &status_ret, die, &mcu_ccount, &cycles);

	wait_param.status = status_ret;
	wait_param.cmdbuf_id = cmdbuf_id;
	wait_param.mcu_ccount = mcu_ccount;
	wait_param.cycles = cycles;

	if (tmp==0) {
		if (video_copy_to_user((struct waitcmd_parameter*)arg, &wait_param, sizeof(struct waitcmd_parameter))) {
			return -EFAULT;
		}
		return tmp;
	} else {
		wait_param.status = -1;
		if (video_copy_to_user((struct waitcmd_parameter*)arg, &wait_param, sizeof(struct waitcmd_parameter))) {
				return -EFAULT;
		}
		return -1;
	}

	break;
      }

    case VASTAI_VCMD_IOCH_RELEASE_CMDBUF:
      {
		struct waitcmd_parameter wait_param = {0};
        u16 cmdbuf_id = -1, core_id = -1;

		if (video_copy_from_user(&wait_param, (struct waitcmd_parameter*)arg, sizeof(struct waitcmd_parameter))) {
			return -EFAULT;
		}
        cmdbuf_id = wait_param.cmdbuf_id;
		core_id = wait_param.core_id;

        VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
			"release CMDBUF: core[%d]: cmdbuf_id=%d\n", core_id, cmdbuf_id);
        return release_cmdbuf(filp, cmdbuf_id, core_id, die);

      }
#if 0
    case VASTAI_VCMD_IOCH_DUMP_CMDBUF:
      {
        u32 core_id = -1;

		if (video_copy_from_user(&core_id, (void *)arg, sizeof(u32))) {
			return -EFAULT;
		}
        dump_cmdbuf(die, core_id);
        return 0;
      }
#endif
    case VASTAI_VCMD_IOCH_POLLING_CMDBUF:
      {
        //u16 core_id;
        //__get_user(core_id, (u16*)arg);
        /*16 bits are cmdbuf_id*/
        //if(core_id>=total_vcmd_core_num)
          //return -1;
        //vastaivcmd_isr(core_id,&vastaivcmd_data[core_id]);
        return 0;
        break;
      }
    case VASTAIDEC_IOCX_GET_VCMDCFG: {
		__put_user(vcmd, (unsigned int *)arg);
		break;
	}
    case VASTAI_VCMD_IOCH_GET_FRAMEBUF: {
        framebuf_desc_t frame_desc = {0};
        VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "VCMD get_framebuf  \n");
		if (video_copy_from_user(&frame_desc, (framebuf_desc_t*)arg, sizeof(framebuf_desc_t))) {
		    return -EFAULT;
		}

		/****************  dma-get-stream *************/
        if (frame_desc.stream_size == 0) {
            return -EFAULT;
        }

		total = frame_desc.stream_size / 0x400000;
		if (frame_desc.stream_size % 0x400000 != 0) {
		    total++;
		}

		dma_buf = kmalloc((total + 1) * sizeof(struct vastai_dmadesc), GFP_KERNEL);
		/* union core_bitmap triger_core = {0}; */
		triger_core.decode = 0;

		while (count < total) {
		    dma_buf[count].is_src_not_user_mem = 0;
		    dma_buf[count].is_src_dma_addr = 0;
		    dma_buf[count].is_host_to_dev = 0;
		    dma_buf[count].host_addr.vir_addr = (void*)(frame_desc.stream_dst_addr + count * 0x400000);
		    dma_buf[count].dev_addr = frame_desc.stream_src_addr + count * 0x400000;
		    dma_buf[count].dma_lenth = (count == total - 1) ? ((frame_desc.stream_size - 1) % 0x400000 + 1): 0x400000;
		    VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
				"%s %d: src=%lx, dst=%lx, size=%d\n", __func__, __LINE__,
				(long unsigned int)dma_buf[count].host_addr.vir_addr,
				(long unsigned int)dma_buf[count].dev_addr, dma_buf[count].dma_lenth);
		    count++;
		}

		ret = vastai_pci_dma_transfer_sync(pcie_dev, die->die_id, triger_core, dma_buf, total, -1);
		if (ret != 0) {
		    VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"vastai_pci_dma_transfer_sync: ERROR ret = %d !!\n", ret);
		}
		kfree(dma_buf);
		return ret;
		break;
	}
    case VASTAI_VCMD_IOCH_GET_ID_PARAMETER:{
		u16 core_id = -1;
		vcmd_id_parameter id_params = {0};
		u32 reg[4] = {0};
		if (video_copy_from_user(&id_params, (vcmd_id_parameter*)arg, sizeof(vcmd_id_parameter))) {
			return -EFAULT;
		}

		core_id = id_params.vcmd_core_id;
		if (core_id < 0 || core_id > 4) {
			VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "invalid core_id\n");
			return -EFAULT;;
		}

		VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
			"%s:core[%d]:vcmd_get_id_parameter.\n", __func__, core_id);

		vastai_video_read_pcie(die->vcmd_pri, die->die_id, (void*)&reg, (void*)VDEC_REPORT_ID_ADDR[core_id], sizeof(reg));
		id_params.decoderAsicId  = reg[0];
		id_params.hwBuildId      = reg[1];
		id_params.l2CacheVersion = reg[2];

		VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
			"asicid=0x%x, buildid=0x%x, cachever=0x%x", id_params.decoderAsicId, id_params.hwBuildId, id_params.l2CacheVersion);
		/* id_params.vcmd_die_id = die->die_id; */
		if (video_copy_to_user((vcmd_id_parameter*)arg, &id_params, sizeof(vcmd_id_parameter))) {
			return -EFAULT;
		}
        break;
    }
	case VASTAI_GET_DEC_WORK_MODE:
	{
		int tmp = -1;

		tmp = video_copy_to_user((u32 *)arg, &(die->work_mode), sizeof(u32));
		if (tmp) {
		    VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "copy_to_user failed, returned %d\n", tmp);
		    return -EFAULT;
		}
		break;
	}
	case VASTAI_CONFIG_CORE_CHANNEL:
	{
		channel_info_t channel_info = {0};
		int tmp = -1;

		VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "%s: config core channel id.\n", __func__);

		tmp = video_copy_from_user(&channel_info, (void*)arg, sizeof(channel_info_t));
		if (tmp) {
			VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"config core channel err: copy_from_user failed, returned %d\n", tmp);
			return -EFAULT;
		}

		tmp = vastai_get_core_channel(&channel_info, die, filp);
		if (tmp) {
			VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"config core channel failed, returned %d\n", tmp);
			return -EFAULT;
		}
		channel_info.die_id = die->die_id;
		if (video_copy_to_user((u32 *) arg, &channel_info, sizeof(channel_info_t))) {
			return -EFAULT;
		}
		break;
	}

	case VASTAI_RELEASE_CORE_CHANNEL:
	{
		u32 tmp = -1;
		tmp = vastai_release_core_channel(die, filp);
		if (tmp) {
			VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"release core channel failed, returned %d\n", tmp);
			return -EFAULT;
		}
		break;
	}

	case VASTAI_GET_AVAILABLE_CHANNELS:
	{
		channels_t channels = {0};
		int tmp = -1;

		VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "%s: get available channels.\n", __func__);

		tmp = video_copy_from_user(&channels, (void*)arg, sizeof(channels_t));
		if (tmp) {
			VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"get available channels err: copy_from_user failed, returned %d\n", tmp);
			return -EFAULT;
		}

		vastai_get_available_channels(&channels, die, filp);

		if (video_copy_to_user((u32 *)arg, &channels, sizeof(channels_t))) {
			return -EFAULT;
		}
		break;
	}
	case VASTAI_DEC_GET_DIE_ID:
	{
		int tmp = -1;

		tmp = video_copy_to_user((u32 *)arg, &(die->die_id), sizeof(int));
		if (tmp) {
		    VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "copy_to_user failed, returned %d\n", tmp);
		    return -EFAULT;
		}
		break;
	}

    case VASTAI_VCMD_IOCH_READWRITE_DEVICE_MEM:{
        transfer_mem_param mem_params = {0};
        void* temp_buffer = NULL;
        long tmp = 0;
        int ret = 0;
        tmp = video_copy_from_user(&mem_params, (void*)arg, sizeof(transfer_mem_param));
        if(tmp){
            VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
				"copy_from_user failed, ioctl: %x, returned %ld\n", VASTAI_VCMD_IOCH_READWRITE_DEVICE_MEM, tmp);
            return -EFAULT;
        }

        if(!mem_params.bus_addr || !mem_params.local_addr) {
            VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "param is invalid, return!\n");
            return -EINVAL;
        }

        temp_buffer = kmalloc(mem_params.len, GFP_KERNEL);
        if (NULL == temp_buffer) {
            VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "Alloc mem failed!\n");
            return -ENOMEM;
        }
        if (mem_params.dir == VASTAI_MEM_READ) {
            //read from device to host;
            vastai_video_read_pcie(die->vcmd_pri, die->die_id, temp_buffer, (void*)mem_params.bus_addr, mem_params.len);
            tmp = video_copy_to_user((void __user *)mem_params.local_addr, temp_buffer, mem_params.len);
            if(tmp){
                VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
					"copy_to_user failed, ioctl: %x, returned %ld\n", VASTAI_VCMD_IOCH_READWRITE_DEVICE_MEM, tmp);
                ret = -EFAULT;
            }
        } else if(mem_params.dir == VASTAI_MEM_WRITE){
            //write from host to device
            tmp = video_copy_from_user(temp_buffer, (void __user *)mem_params.local_addr, mem_params.len);
            if(tmp){
                VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id,
					"copy_from_user failed, ioctl: %x, returned %ld\n", VASTAI_VCMD_IOCH_READWRITE_DEVICE_MEM, tmp);
                ret = -EFAULT;
                goto end;
            }
            vastai_video_write_pcie(die->vcmd_pri, die->die_id, temp_buffer, (void *)mem_params.bus_addr, mem_params.len);
        } else {
            VAVIDEO_ERR(die->vcmd_pri, (u8)die->die_id, "invalid param! dir=%d\n", mem_params.dir);
            ret = -EINVAL;
        }
    end:
        kfree(temp_buffer);
        return ret;
    }

    default:
        break;
    }
    return 0;
}

int vastaivcmd_open(struct inode *inode, struct file *filp)
{
    return 0;
}

int vastaivcmd_release(struct file *filp, struct die_info* die)
{
	struct vastaivcmd_dev *dev = die->vastaivcmd_data;
	u32 core_id = 0, cmdbuf_id = 0;
	u32 release_cmdbuf_num=0;
	struct cmdbuf_obj* cmdbuf_obj_temp = NULL;

	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id,
			"vastaivcmd_release %p\n", (void *)filp);
	VAVIDEO_DBG(die->vcmd_pri, (u8)die->die_id, "dev-node closed\n");

	for (core_id = 0; core_id < die->core_num; core_id++) {
		if ((&dev[core_id]) == NULL)
			continue;
		for (cmdbuf_id = 0; cmdbuf_id < TOTAL_DISCRETE_CMDBUF_NUM; cmdbuf_id++) {
			cmdbuf_obj_temp = &(dev[core_id].cmdbuf_obj_sets[cmdbuf_id]);
			if (cmdbuf_obj_temp->filp == filp) {
				clean_cmdbuf_obj(cmdbuf_obj_temp, cmdbuf_id, core_id, die);
				release_cmdbuf_num++;
			}
		}
	}
	vastai_release_core_channel(die, filp);

	return 0;
}


/*------------------------------------------------------------------------------
 Function name   : vcmd_pcie_init
 Description     : Initialize PCI Hw access

 Return type     : int
 ------------------------------------------------------------------------------*/
static int vcmd_init(struct die_info *die_info)
{
	int i = 0;
	u64 core_busaddress[VASTAI_MAX_DECODER_CORES] = {VCMD_DEC_DDR_BASE_ADDR_0, VCMD_DEC_DDR_BASE_ADDR_1, VCMD_DEC_DDR_BASE_ADDR_2, VCMD_DEC_DDR_BASE_ADDR_3, VCMD_DEC_DDR_BASE_ADDR_4};

	for (i = 0; i < die_info->core_num; i++) {
		die_info->vastaivcmd_data[i].vcmd_buf_mem_pool.busAddress = core_busaddress[i];
		die_info->vastaivcmd_data[i].vcmd_buf_mem_pool.size = CMDBUF_POOL_TOTAL_SIZE;

		VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
				"VCMD[%d] buf mem addr=0x%lx, size=0x%08x\n",
				i, (unsigned long)die_info->vastaivcmd_data[i].vcmd_buf_mem_pool.busAddress,
				die_info->vastaivcmd_data[i].vcmd_buf_mem_pool.size);

		die_info->vastaivcmd_data[i].vcmd_status_buf_mem_pool.busAddress = core_busaddress[i] + CMDBUF_POOL_TOTAL_SIZE;
		die_info->vastaivcmd_data[i].vcmd_status_buf_mem_pool.size = CMDBUF_POOL_TOTAL_SIZE;

		VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
				"VCMD[%d] status buf mem addr=0x%lx, size=0x%08x\n",
				i, (unsigned long)die_info->vastaivcmd_data[i].vcmd_status_buf_mem_pool.busAddress,
				die_info->vastaivcmd_data[i].vcmd_status_buf_mem_pool.size);

		die_info->vastaivcmd_data[i].vcmd_registers_mem_pool.busAddress = core_busaddress[i]  + CMDBUF_POOL_TOTAL_SIZE * 2;
		die_info->vastaivcmd_data[i].vcmd_registers_mem_pool.size = CMDBUF_VCMD_REGISTER_TOTAL_SIZE;

		VAVIDEO_INFO(die_info->vcmd_pri, (u8)die_info->die_id,
				"VCMD[%d] registers mem addr=0x%lx, size=0x%08x\n",
				i, (unsigned long)die_info->vastaivcmd_data[i].vcmd_registers_mem_pool.busAddress,
				die_info->vastaivcmd_data[i].vcmd_registers_mem_pool.size);

	}
    return 0;
}

int vastaivcmd_init(struct die_info *die_info)
{
	int i = 0, k = 0;
	int result = 0;
	struct kernel_addr_desc;
	struct vastaivcmd_dev* vastaivcmd_data = NULL;
	unsigned int hwid = 0x43421101;// for dbg
	struct vastai_pci_info *pcie_dev = (struct vastai_pci_info *)die_info->vcmd_pri;

	int vastai_dec_irq[] = {VASTAI_DEC_CORE0, VASTAI_DEC_CORE1, VASTAI_DEC_CORE2};

	VAVIDEO_INFO(pcie_dev, (u8)die_info->die_id,
                   "Vastai Decoder Driver Version: %d.%d.%d,  build date: %s, time: %s.\n",
                   VASTAI_DECODER_VERSION_MAJOR, VASTAI_DECODER_VERSION_MINOR, VASTAI_DECODER_VERSION_REVISION,
                   __DATE__, __TIME__);

	atomic_set(&(die_info->decoder_state), VIDEO_STATE_INITING);

	atomic_set(&(die_info->dec_job_count), 0);
	CheckSubsysCoreArray(die_info, vpu_subsys, &vcmd);

	// TODO multi_die/dev:pci-callback-init
	for (i = 0 ;i < VASTAI_MAX_VDMCU_CORES; i++) {
		result = vastai_irq_register(pcie_dev, die_info->die_id, vastai_dec_irq[i], vastai_pci_done_callback, (void *)die_info);
		if(result)
			goto err;
	}

	for (i = 0; i< total_vcmd_core_num; i++) {
		VAVIDEO_INFO(pcie_dev, (u8)die_info->die_id,
				"vcmd: module init - vcmdcore[%d] addr =0x%llx\n",i,
				(long long unsigned int)vcmd_core_array[i].vcmd_base_addr);
	}

	vastaivcmd_data = die_info->vastaivcmd_data = (struct vastaivcmd_dev *)vmalloc(sizeof(struct vastaivcmd_dev) * total_vcmd_core_num);
	if (vastaivcmd_data == NULL)
		goto err;
	memset(vastaivcmd_data, 0, sizeof(struct vastaivcmd_dev) * total_vcmd_core_num);
	die_info->core_num = total_vcmd_core_num;

	result = vcmd_init(die_info);
	if(result)
		goto err;

	for (k=0; k < MAX_VCMD_TYPE; k++) {
		die_info->vcmd_type_core_num[k] = 0;
		/* die_info->vcmd_position[k]=0; */
		for (i=0; i<MAX_VCMD_NUMBER; i++) {
			die_info->vcmd_manager[k][i] = NULL;
		}
	}

	die_info->workqueue = create_workqueue("video_decoder_workqueue");
	for (i=0; i < total_vcmd_core_num; i++) {
		vastaivcmd_data[i].die = die_info;
		vastaivcmd_data[i].vcmd_core_cfg = vcmd_core_array[i];
		vastaivcmd_data[i].hwregs = NULL;
		vastaivcmd_data[i].core_id = i;
		vastaivcmd_data[i].working_state = WORKING_STATE_IDLE;
		vastaivcmd_data[i].sw_cmdbuf_rdy_num = 0;
		mutex_init(&vastaivcmd_data[i].mutex);

		INIT_WORK(&(vastaivcmd_data[i].work), vcmd_workqueue_schedue);
		vastaivcmd_data[i].duration_without_int = 0;

		init_waitqueue_head(&die_info->vastaivcmd_data[i].vcmd_cmdbuf_memory_wait);

		vastai_cmdid_init(&vastaivcmd_data[i].cmdbufId_queue, DECODER);

		die_info->vcmd_manager[vcmd_core_array[i].sub_module_type][die_info->vcmd_type_core_num[vcmd_core_array[i].sub_module_type]] = &vastaivcmd_data[i];
		die_info->vcmd_type_core_num[vcmd_core_array[i].sub_module_type]++;
		vastaivcmd_data[i].vcmd_type_core_num[vcmd_core_array[i].sub_module_type]++;
		vastaivcmd_data[i].vcmd_reg_mem_busAddress = die_info->vastaivcmd_data[i].vcmd_registers_mem_pool.busAddress;
		vastaivcmd_data[i].vcmd_reg_mem_size = VCMD_REGISTER_SIZE;
		vastaivcmd_data[i].hw_version_id = hwid;

		die_info->vastaivcmd_data[i].cmdbuf_used_pos = 2;
		die_info->vastaivcmd_data[i].cmdbuf_used_residual = TOTAL_DISCRETE_CMDBUF_NUM - 2;
		die_info->vastaivcmd_data[i].cmdbuf_used[0] = 1;
		die_info->vastaivcmd_data[i].cmdbuf_used[1] = 1;

#if 0
		for (k = 2; k < TOTAL_DISCRETE_CMDBUF_NUM; k++) {
			init_completion(&die_info->vastaivcmd_data[i].cmdbuf_obj_sets[k].vcmd_process_comp);
		}
#endif
		spin_lock_init(&die_info->vastaivcmd_data[i].vcmd_cmdbuf_alloc_lock);
	}

	//spin_lock_init(&die_info->cfg_core_lock);
	mutex_init(&die_info->allocate_core_mutex);
	die_info->die_channels = 0;
	INIT_LIST_HEAD(&die_info->die_channel_head);

	(die_info->vcmd_manager[VCMD_TYPE_DECODER][0])->status_cmdbuf_id = 1;
	set_dec_work_mode(die_info, DEC_SINGLE_CORE_MODE);

	atomic_set(&(die_info->decoder_state), VIDEO_STATE_READY);

	return 0;
err:
	if (vastaivcmd_data != NULL)
		vfree(vastaivcmd_data);

	VAVIDEO_ERR(pcie_dev, (u8)die_info->die_id, "vastai_decoder_driver: module not inserted\n");
	return result;
}

void vastaivcmd_cleanup(struct die_info *die)
{
	if (NULL != die) {
		flush_workqueue(die->workqueue);
		destroy_workqueue(die->workqueue);
		vfree(die->vastaivcmd_data);
	}
	VAVIDEO_INFO(die->vcmd_pri, (u8)die->die_id,
			"vastai_decoder_driver: module removed\n");
	return;
}

int set_dec_work_mode(struct die_info *die_info, decoder_workmode_t work_mode)
{
	int magic_number = (work_mode == DEC_SINGLE_CORE_MODE ? VDMCU_SINGLECORE_MODE : VDMCU_MULTICORE_MODE);
	int core_id;
	for (core_id = 0; core_id < 5; core_id++) {
		vastai_video_write_pcie(die_info->vcmd_pri, die_info->die_id, (void*)&magic_number,  (void*)VDEC_REPORT_ID_ADDR[core_id] + 12, sizeof(unsigned int));
	}

	die_info->work_mode = work_mode;

	return 0;
}

