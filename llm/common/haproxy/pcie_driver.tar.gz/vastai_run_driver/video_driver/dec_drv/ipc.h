/*
 * ipc.h
 *
 *  Created on: 2021��1��28��
 *      Author: lee
 */

#ifndef __IPC_H__
#define __IPC_H__


#define MAX_QUEUE_NUM						(7)
#define MAX_DMA_DESC_NUM					(16)

#define DDR_MEM_BASE_ADDR					(0x30000000)

/* DMA descriptor RAM */
#define DMA_DESC_START_ADDR					(0x30400000)

#define DMA_DESC_RD_ADDR					(0x31000E00)		
#define DMA_DESC_WR_ADDR					(0x31000F00)

/* host to mcu MSG RAM */
#define HOST2MCU_MSG_START_ADDR				(0x30401000)

#define HOST2MCU_MSG_RD_ADDR				(0x31001700)
#define HOST2MCU_MSG_WR_ADDR				(0x31001780)

/* MCU to host MSG RAM */
#define MCU2HOST_MSG_START_ADDR				(0x30401800)

#define MCU2HOST_MSG_RD_ADDR				(0x31001F00)
#define MCU2HOST_MSG_WR_ADDR				(0x31001F80)

/* element SIZE of queue */
#define FIFO_ELEM_SIZE						(0x80)

/* DMA REGS RAM */
#define DMA_REGS_START_ADDR					(0x30402000)
#define DMA_REGS_END_ADDR					(0x3040a000)


#define FIFO_REGS_SIZE						(508 * 4)


typedef enum cmd {
	INIT,
	DECODE,
	/* START, */
	RESET,
	HANDLE_EXCEPTION,
	RELEASE,// abort-->release
	MAX_CMD,
} cmd_t;

#define MAGIC_NUMBER		(0x5AA5)
typedef struct header {
	uint32_t magic;
	uint32_t len;
	uint32_t channel;
	uint32_t type;
	cmd_t cmd;
} header_t;



#define CMDBUF_EXE_STATUS_OK            0
#define CMDBUF_EXE_STATUS_CMDERR        1
#define CMDBUF_EXE_STATUS_BUSERR        2
#define CMDBUF_EXE_STATUS_END           3
#define CMDBUF_EXE_STATUS_RESET         4


typedef struct __attribute__((packed)) dec_result {
    uint32_t status;
    uint32_t cmd_id;
    uint32_t core_id;
	uint32_t mcu_ccount;
	uint32_t cycles;	
} dec_result_t;

typedef struct payload {
    uint32_t len;
    uint32_t cmd_id;
} payload_t;

typedef struct packet {
	header_t header;
	payload_t payload;
} packet_t;

typedef enum sub_type{
	DECODER_REGS,
	VCMD_REGS,
} subtype_t;

typedef struct dma_desc {
	volatile uint32_t channel;
	volatile uint32_t dir;
	volatile uint32_t type;
	volatile uint32_t seq;
	volatile subtype_t subtype;
	volatile uint32_t buf_addr;
	volatile uint32_t len;
} dma_desc_t;

typedef struct {
	volatile int rd;
	volatile int wr;
	volatile int max_size;
	uint8_t buf[0];
} ring_buf_t;

#if 0
typedef struct {
	int rd;
	int wr;
	int max_size;
	dma_desc_t buf[MAX_DMA_DESC_NUM];
} dma_ring_buf_t;

typedef struct {
	int rd;
	int wr;
	int max_size;
	uint8_t buf[MAX_QUEUE_NUM][FIFO_REGS_SIZE];
} dma_reg_ring_buf_t;
#endif

typedef struct {
	ring_buf_t *virt_addr;
	dma_addr_t bus_addr;
	uint32_t size;
} linear_mem_t;

typedef struct {
	linear_mem_t host2mcu_msg_buf;
	linear_mem_t mcu2host_msg_buf;
	linear_mem_t dma_desc_buf;
	linear_mem_t dma_reg_buf;
	struct mutex wr_mutex;
	struct mutex rd_mutex;
} ipc_comm_queue_t;

int ipc_init_comm_queue(void);
int ipc_send_msg(uint8_t *data, uint8_t len);
int ipc_recv_msg(uint8_t *data, uint8_t *len);
//int dma_put_desc(uint8_t *data);
int dma_put_regs(uint8_t *data, u32 core, u32 channel);
void ipc_comm_queue_cleanup(void);
#endif /*  */
