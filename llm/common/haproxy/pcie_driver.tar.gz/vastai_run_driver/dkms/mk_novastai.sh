#!/bin/bash

OLD_STR_MIN="vastai"
OLD_STR_MAJ="VASTAI"
OLD_STR_HUMP="Vastai"
#OLD_STR_PRE="va"

NEW_STR_MIN="komect"
NEW_STR_MAJ="KOMECT"
NEW_STR_HUMP="Komect"
#NEW_STR_PRE="km"

CUR_PATH=$(readlink -f "$(dirname "$0")")
SRC_ROOT="${CUR_PATH}/.."
OUT_DIR="${SRC_ROOT}"

# if [ $(id -u) != 0 ]; then
# 	echo "ERROR: you must be root to use the shell script!"
# 	exit 1
# fi

while getopts Ch:mv: opt
do
	case "$opt" in
        # v) module_version=$OPTARG ;;
	# C) noClean="True";;
	# m) multiHwType="True";;
	# h) hwType=$OPTARG;;
	*) echo "ERROR: Unknown option!"; exit 2 ;;
	esac
done

# 0. change to source tree and make clean
cd $SRC_ROOT
make clean

# 1. string substitution
# 1.1 .c and .h
find -name "*.[ch]" | xargs sed -i 's/'${OLD_STR_MIN}'/'${NEW_STR_MIN}'/g'
find -name "*.[ch]" | xargs sed -i 's/'${OLD_STR_MAJ}'/'${NEW_STR_MAJ}'/g'
find -name "*.[ch]" | xargs sed -i 's/'${OLD_STR_HUMP}'/'${NEW_STR_HUMP}'/g'
#find -name "*.[ch]" | xargs sed -i 's/'${OLD_STR_PRE}'/'${NEW_STR_PRE}'/g'

# 1.2 Misc files
sed -i 's/'${OLD_STR_MIN}'/'${NEW_STR_MIN}'/g' Makefile
sed -i 's/'${OLD_STR_MAJ}'/'${NEW_STR_MAJ}'/g' Makefile
sed -i 's/'${OLD_STR_HUMP}'/'${NEW_STR_HUMP}'/g' Makefile
#sed -i 's/'${OLD_STR_PRE}'/'${NEW_STR_PRE}'/g' Makefile

sed -i 's/'${OLD_STR_MIN}'/'${NEW_STR_MIN}'/g' .gitignore

cd dkms
sed -i 's/'${OLD_STR_MIN}'/'${NEW_STR_MIN}'/g' `grep -rn --exclude="mk_novastai.sh" "${OLD_STR_MIN}" . | awk -F : '{print $1}'`
sed -i 's/'${OLD_STR_MAJ}'/'${NEW_STR_MAJ}'/g' `grep -rn --exclude="mk_novastai.sh" "${OLD_STR_MAJ}" . | awk -F : '{print $1}'`
sed -i 's/'${OLD_STR_HUMP}'/'${NEW_STR_HUMP}'/g' `grep -rn --exclude="mk_novastai.sh" "${OLD_STR_HUMP}" . | awk -F : '{print $1}'`
#sed -i 's/'${OLD_STR_PRE}'/'${NEW_STR_PRE}'/g' `grep -rn --exclude="mk_novastai.sh" "${OLD_STR_PRE}" . | awk -F : '{print $1}'`
cd ..

# 2. rename files
mv tool/"${OLD_STR_MIN}"_user_lib tool/"${NEW_STR_MIN}"_user_lib
find . -path "./dkms/mk_no"${OLD_STR_MIN}".sh" -prune -o -name "*${OLD_STR_MIN}*" -print | sed -e 'p;s/'${OLD_STR_MIN}'/'${NEW_STR_MIN}'/g' | xargs -n2 mv

# 3. restore node name
find -name "*.[ch]" | xargs sed -i 's/'${NEW_STR_MIN}'%d_ctl/'${OLD_STR_MIN}'%d_ctl/g'
find -name "*.[ch]" | xargs sed -i 's/'${NEW_STR_MIN}'%d_version/'${OLD_STR_MIN}'%d_version/g'
find -name "*.[ch]" | xargs sed -i 's/'${NEW_STR_MIN}'_video%d/'${OLD_STR_MIN}'_video%d/g'
