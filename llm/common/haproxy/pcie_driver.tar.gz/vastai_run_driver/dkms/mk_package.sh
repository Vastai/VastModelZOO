#!/bin/bash

# define print log leve
LOG_LEVEL=1
# log info
function log_info(){
	content="[INFO] $(date '+%Y-%m-%d %H:%M:%S') $@"
	[ $LOG_LEVEL -le 2  ] && echo -e "\033[32m"  ${content} "\033[0m"
}
#log warn
function log_warn(){
	content="[WARN] $(date '+%Y-%m-%d %H:%M:%S') $@"
	[ $LOG_LEVEL -le 3  ] && echo -e "\033[33m" ${content} "\033[0m"
}
#log err
function log_err(){
	content="[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $@"
	[ $LOG_LEVEL -le 4  ] && echo -e "\033[31m" ${content} "\033[0m"
}

PACKAGE_TYPE=""
module_version=""
cur_version=""
hwType="0" #default type
target=$(arch)

CUR_PATH=$(readlink -f "$(dirname "$0")")
SRC_ROOT="${CUR_PATH}/.."
OUT_DIR="${SRC_ROOT}"

echo -e "\n"
log_info "Step 0. Pre Check"
echo =====================================================
# -------- 0.1 Check script execution permissions start ---------
if [ $(id -u) != 0 ]; then
	log_err "You must be root to use the shell script!"
	exit 1
else
	log_info "Check script execution permissions [PASS]"
fi
# ----------------------------- end -----------------------------

# ---------------- 0.2 Check driver build start -----------------
cd $SRC_ROOT
# make
make clean > /dev/null 2>&1
# ----------------------------- end -----------------------------

# ------------- 0.3 Check Dependency Support start ---------------
# check lsb_release
if type lsb_release >/dev/null 2>&1; then
	DISTRIB_ID=$(lsb_release -i -s)
	log_info "Check lsb_release support [PASS]"
else
	log_err "error: Failed dependencies: \n
		\t lsb_release is needed, please install redhat-lsb-core"
	exit 2
fi

# Function to check DKMS version
check_dkms() {
	# Check DKMS install
	if ! type dkms >/dev/null 2>&1; then
		log_err "error: Failed dependencies: \n
			\t DKMS is needed, please install dkms (>=1.95, <=2.8)"
		exit 1
	fi

	local dkms_version=$(dkms --version)
	echo $dkms_version | grep '-' > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		local dkms_v=$(echo $dkms_version | cut -d'-' -f2)
	else
		local dkms_v=$(echo $dkms_version | cut -d':' -f2)
	fi

	local dkms_v1=$(echo "$dkms_v" | cut -d"." -f1)
	local dkms_v2=$(echo "$dkms_v" | cut -d"." -f2)

	if [ "$dkms_v1" -eq 1 ] && [ "$dkms_v2" -ge 95 ]; then
		log_info "Check DKMS support (Current version $dkms_v) [PASS]"
	elif [ "$dkms_v1" -eq 2 ] && [ "$dkms_v2" -le 8 ]; then
		log_info "Check DKMS support (Current version $dkms_v) [PASS]"
	else
		log_err "error: Failed dependencies: \n
			\t DKMS (>=1.95, <=2.8) is needed, current DKMS version is $dkms_v"
		exit 1
	fi
}

check_rpmbuild_rpm() {
	if type rpmbuild >/dev/null 2>&1; then
		log_info "Check rpmbuild support [PASS]"
	else
		log_err "error: Failed dependencies: \n
			\t rpm-build is needed, please install rpm-build"
		exit 1
	fi
}

check_dpkg_deb() {
	if type dpkg >/dev/null 2>&1; then
		log_info "Check dpkg support [PASS]"
	else
		log_err "error: Failed dependencies: \n
			\t dpkg is needed, please install dpkg"
		exit 1
	fi
}

check_dpkg_dev_deb() {
	local package_status=$(dpkg --get-selections | grep dpkg-dev | awk '{print $2}')

	if [ "$package_status" = "install" ]; then
		log_info "Check dpkg-dev support [PASS]"
	else
		log_err "error: Failed dependencies: \n
			\t dpkg-dev is needed, please install dpkg-dev"
		exit 1
	fi
}

check_python() {
	if [ "$1" = "rpm" ]; then
		local python_v=`python -V 2>&1 | awk '{print $2}'`
	else
		local python_v=`python3 -V 2>&1 | awk '{print $2}'`
	fi

	local python_v1=$(echo $python_v | awk -F '.' '{print $1}')

	if [ $python_v1 == 2 ]; then
		log_info "Check Python support (Current version $python_v) [PASS]"
	elif [ $python_v1 == 3 ]; then
		log_info "Check Python support (Current version $python_v) [PASS]"
	else
		log_err "error: Failed dependencies: \n
			\t Python is needed, please install python2 and python3"
		exit 1
	fi
}

add_module_params() {
	echo "options vastai_pci ${1}" >> vastai_pci.conf
}

case $DISTRIB_ID in
	CentOS)
		PACKAGE_TYPE="rpm"
		;;
	Ubuntu)
		PACKAGE_TYPE="deb"
		;;
	RedHatEnterprise)
		PACKAGE_TYPE="rpm"
		;;
	*)
		log_err "Running OS($DISTRIB_ID) don't support make package"
		exit 2
		;;
esac

case $PACKAGE_TYPE in
	deb)
		check_dkms
		check_dpkg_deb
		check_dpkg_dev_deb
		check_python "$PACKAGE_TYPE"
		;;
	rpm)
		check_rpmbuild_rpm
		check_dkms
		check_python "$PACKAGE_TYPE"
		;;
	*)
		log_err "Running OS($DISTRIB_ID) doesn't support make package"
		exit 1
		;;
esac
# ----------------------------- end -----------------------------


echo -e "\n"
log_info "Step 1. Configure packing rules"
echo =====================================================
cat /dev/null > vastai_pci.conf
while getopts Ch:v:m: opt; do
	case "$opt" in
		v)
			module_version=$OPTARG
			;;
		h)
			hwType=$OPTARG
			;;
		m)
			module_params=$OPTARG
			add_module_params "${module_params}"
			;;
		*)
			log_err "Unknown option!"
			exit 2
	esac
done

cd $SRC_ROOT

#we create dkms.conf auto, avoid git status is dirty after we package
echo 'PACKAGE_NAME="vastai-pci-pcie-dev"' > dkms.conf
echo 'PACKAGE_VERSION="000"' >> dkms.conf
echo 'CLEAN="make clean"' >> dkms.conf
echo "MAKE[0]=\"'make' CONFIG_VASTAI_HW_TYPE=${hwType} KVERSION=\${kernelver}\"" >> dkms.conf
echo 'BUILT_MODULE_NAME[0]="vastai_pci"' >> dkms.conf
echo 'DEST_MODULE_LOCATION[0]="/extra"' >> dkms.conf
echo 'AUTOINSTALL="yes"' >> dkms.conf
echo 'NO_WEAK_MODULES="yes"' >> dkms.conf
# dkms matches the kernel version(=4.x.x), otherwise skip
echo 'BUILD_EXCLUSIVE_KERNEL="^[4-9].*"' >> dkms.conf

if [ $module_version ]; then
	VASTAI_DRV_VERSION=$module_version
else
	#default version:  compiled_ver increase 1
	cur_version=$(cat include/vastai_version.h | grep "VASTAI_PCI_DRIVER_VERSION" \
		| awk '{print $3}' | sed 's/[()"]//g')
	cur_major_ver=$(echo ${cur_version} | awk -F '.' '{print $1}')
	cur_minor_ver=$(echo ${cur_version} | awk -F '.' '{print $2}')
	cur_revision_ver=$(echo ${cur_version} | awk -F '.' '{print $3}')
	cur_compiled_ver=$(echo ${cur_version} | awk -F '.' '{print $4}')
	cur_compiled_ver=$(expr $cur_compiled_ver + 1)

	if [ $cur_compiled_ver -ge "100" ]; then
		log_err "Compiled_version is greater than 99, pls modify versoin manually"
		exit 3
	fi

	VASTAI_DRV_VERSION=$(printf "%02d.%02d.%02d.%02d" \
		$cur_major_ver  $cur_minor_ver $cur_revision_ver $cur_compiled_ver)
fi

#keep branch name is lowercase
GIT_BRANCH_NAME=$(echo $(git rev-parse --abbrev-ref HEAD) | sed 's/[A-Z]/\L&/g')
GIT_COMMIT_HASH=$(git log -1 --format="%h")
GIT_COMMIT_MSG=$(git log -1 --format="%s")
GIT_COMMIT_MSG_FORMAT=$(echo "$GIT_COMMIT_MSG" | sed 's/["]//g')
MKPACKAGE_TIME=$(date +"%Y%m%d")
PACKAGE_NAME_PREFIX="vastai_pci"

if [ -n "$module_params" ]; then
	if [ "$module_params" = "onedie=1" ]; then
		PACKAGE_NAME=$(echo "${PACKAGE_NAME_PREFIX}_${GIT_BRANCH_NAME}_hwtype_${hwType}_onedie" | sed 's/_/-/g')
	fi
	if [ "$module_params" = "parallel_load=1" ]; then
		PACKAGE_NAME=$(echo "${PACKAGE_NAME_PREFIX}_${GIT_BRANCH_NAME}_hwtype_${hwType}_pl" | sed 's/_/-/g')
	fi
	if [ "$module_params" = "dpm=1" ]; then
		PACKAGE_NAME=$(echo "${PACKAGE_NAME_PREFIX}_${GIT_BRANCH_NAME}_hwtype_${hwType}_dpm" | sed 's/_/-/g')
	fi
else
	PACKAGE_NAME=$(echo "${PACKAGE_NAME_PREFIX}_${GIT_BRANCH_NAME}_hwtype_${hwType}" | sed 's/_/-/g')
fi

sed -i "s/BuildArch:.*/BuildArch:\t${target}/" ${CUR_PATH}/${PACKAGE_NAME_PREFIX}-dkms-mkrpm.spec

DKMS_SRC_DIR=/usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}
DKMS_TREE_DIR=/var/lib/dkms/${PACKAGE_NAME}/${VASTAI_DRV_VERSION}
DKMS_SOURCES="dkms.conf
	vastai_pcie_public.h
	vastai_sg100_bbox.h
	vastai_cmd.c
	Makefile
	README.md
	ai_driver
	boot
	file_node
	ep_driver
	fw
	include
	logsys
	ras
	tools_driver
	dkms
	video_driver
	common
	gfx
	unittest.mk
	download
	vastai_pci.conf"

log_info "Driver package info:\n
\t Type \t [$PACKAGE_TYPE] \n
\t Arch \t [$target] \n
\t Version [$VASTAI_DRV_VERSION] \n
\t Name \t [$PACKAGE_NAME]"


echo -e "\n"
log_info "Step 2. Remove kernel modules from dkms tree"
echo =====================================================
added_versions=$(dkms status -m ${PACKAGE_NAME} -v ${VASTAI_DRV_VERSION})
if [ -n "$added_versions" ]; then
	dkms remove -m ${PACKAGE_NAME} -v ${VASTAI_DRV_VERSION} --all
	rm -rf /usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}
	log_info "Remove done!"
else
	log_info "Dkms tree is clean!"
fi

old_src=$(ls /usr/src/ | grep vastai-pci)
if [ -n "$old_src" ]; then
	log_info "Remove old driver source from /usr/src"
	for old in $old_src; do
		rm -rf /usr/src/$old
		log_info "Remove $old done!"
	done
else
	log_info "Old driver source under path /usr/src is clean!"
fi


echo -e "\n"
log_info "Step 3. Modify dkms.conf"
echo =====================================================
log_info "Modify package name of dkms.conf to $PACKAGE_NAME done!"
sed -i 's/PACKAGE_NAME=.*$/PACKAGE_NAME='"\"${PACKAGE_NAME}\""'/g' dkms.conf
log_info "Modify version of dkms.conf to $VASTAI_DRV_VERSION done!"
sed -i 's/PACKAGE_VERSION=.*$/PACKAGE_VERSION='"\"${VASTAI_DRV_VERSION}\""'/g' dkms.conf
log_info "Modify version of include/vastai_version.h to $VASTAI_DRV_VERSION done!"
sed -i 's/^.*VASTAI_PCI_DRIVER_VERSION.*$/#define VASTAI_PCI_DRIVER_VERSION '"\(\"${VASTAI_DRV_VERSION}\"\)"'/g' include/vastai_version.h


echo -e "\n"
log_info "Step 4. Copy driver source code to $DKMS_SRC_DIR"
echo =====================================================
if [ ! -d $DKMS_SRC_DIR ]; then
	mkdir $DEBUG_EN $DKMS_SRC_DIR
fi
for dkms_src in $DKMS_SOURCES; do
	cp -a $DEBUG_EN $dkms_src ${DKMS_SRC_DIR}/${dkms_src}
done
if [ $PACKAGE_TYPE = "rpm" ]; then
	cp ${CUR_PATH}/${PACKAGE_NAME_PREFIX}-dkms-mkrpm.spec ${DKMS_SRC_DIR}/${PACKAGE_NAME}-dkms-mkrpm.spec
fi
if [ $PACKAGE_TYPE = "deb" ]; then
	cp ${CUR_PATH}/${PACKAGE_NAME_PREFIX}-dkms-mkdeb ${DKMS_SRC_DIR}/${PACKAGE_NAME}-dkms-mkdeb -r
fi
cp ${CUR_PATH}/vastai.rules ${DKMS_SRC_DIR}/
log_info "Copy source code done!"

# put git info to package
sed -i 's/^.*VASTAI_PCI_GIT_BRANCH_NAME.*$/#define VASTAI_PCI_GIT_BRANCH_NAME '"\(\"${GIT_BRANCH_NAME}\"\)"'/g' \
	${DKMS_SRC_DIR}/include/vastai_version.h
sed -i 's/^.*VASTAI_PCI_GIT_COMMIT_HASH.*$/#define VASTAI_PCI_GIT_COMMIT_HASH '"\(\"${GIT_COMMIT_HASH}\"\)"'/g' \
	${DKMS_SRC_DIR}/include/vastai_version.h
sed -i 's/^.*VASTAI_PCI_MKPACKAGE_TIME.*$/#define VASTAI_PCI_MKPACKAGE_TIME '"\(\"${MKPACKAGE_TIME}\"\)"'/g' \
	${DKMS_SRC_DIR}/include/vastai_version.h


echo -e "\n"
log_info "Step 5. Adding and building new kernel modules to DKMS"
echo =====================================================
dkms add ${PACKAGE_NAME}/${VASTAI_DRV_VERSION}
dkms build ${PACKAGE_NAME}/${VASTAI_DRV_VERSION}
if [ $? != 0 ]; then
	if grep -q 'Error\|failed\|error' /var/lib/dkms/${PACKAGE_NAME}/${VASTAI_DRV_VERSION}/build/make.log > /dev/null 2>&1
	then
		cat /var/lib/dkms/${PACKAGE_NAME}/${VASTAI_DRV_VERSION}/build/make.log
	fi
	log_err "Dkms build failed!"
	exit 2
fi


echo -e "\n"
log_info "Step 6. Make ${PACKAGE_TYPE} package to $(readlink -f $OUT_DIR)"
echo =====================================================
log_info "Version: change from $cur_version to $VASTAI_DRV_VERSION"
rm -rf /usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}/fw/bin2hex
rm -rf /usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}/fw/sg100/bin2hex
if [ $PACKAGE_TYPE = "rpm" ]; then
	dkms mk${PACKAGE_TYPE} ${PACKAGE_NAME}/${VASTAI_DRV_VERSION} --source-only
elif [ $PACKAGE_TYPE = "deb" ]; then
	dkms mk${PACKAGE_TYPE} ${PACKAGE_NAME}/${VASTAI_DRV_VERSION} --source-only
fi

if [ ! -d $OUT_DIR ]; then
	mkdir $OUT_DIR
fi

if [ $PACKAGE_TYPE = "rpm" ]; then
	mv -f ${DKMS_TREE_DIR}/rpm/*${target}* $OUT_DIR/${PACKAGE_NAME}_${VASTAI_DRV_VERSION}_${target}.rpm
elif [ $PACKAGE_TYPE = "deb" ]; then
	mv -f ${DKMS_TREE_DIR}/deb/* $OUT_DIR/${PACKAGE_NAME}_${VASTAI_DRV_VERSION}_${target}.deb
fi


echo -e "\n"
log_info "Step 7. Remove new installed modules from dkms tree"
echo =====================================================
dkms remove ${PACKAGE_NAME}/${VASTAI_DRV_VERSION} --all
if [ $? != 0 ]; then
	log_err "ERROR: dkms remove failed!"
	exit 2
fi

if [ -d "/usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}" ]; then
	rm -rf /usr/src/${PACKAGE_NAME}-${VASTAI_DRV_VERSION}
	log_info "Clean driver source code done!"
fi
