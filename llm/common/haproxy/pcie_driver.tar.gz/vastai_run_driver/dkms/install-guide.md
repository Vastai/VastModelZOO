# SV100 PCIe Driver Install Guide

This guide is intended to help you install the latest version of SV100 PCIe driver on your system.

## 1. Overview

PCIe driver是瀚博SV100架构系列芯片的内核驱动。

## 2. PCIe driver安装包

……

## 3. 安装准备

请检查下列环境及版本要求是否已经安装：

- dkms (>=1.95, <=2.8)
- linux-headers
- dpkg (Ubuntu)
- rpm  (CentOS)
- python2
- python3

## 4. 全新安装

### 4.1 Ubuntu Installation

1. 安装环境准备：

```bash
sudo apt-get install dh-make dkms dpkg dpkg-dev python2 python3
```

2. PCIe driver安装

```bash
sudo dpkg -i vastai-pci_dkms_xx.xx.xx.xx_xx.deb
```

3. Verify the installation.

首先，运行如下命令，查看deb包是否安装成功；
```bash
dpkg --status vastai-pci-dkms
```
```bash
#output
Package: vastai-pci-dkms
Status: install ok installed
……
Version: xx.xx.xx.xx
Provides: vastai-pci-modules (= xx.xx.xx.xx)
Depends: dkms (>= 1.95)
Description: vastai-pci driver in DKMS format.
```

然后，运行如下命令查看驱动是否已加载到内核。
```bash
lsmod | grep vastai_pci
```
```bash
#output
vastai_pci        xxx  x
```

(注意：SV100加速卡需插入服务器，否则驱动无法加载到内核。)

### 4.2 CentOS Installation

1. 安装环境准备：

```bash
sudo yum install epel-release python2 python3
sudo yum install kernel-headers kernel-devel dkms
```

2. PCIe driver安装

```bash
sudo rpm -i vastai-pci_dkms_xx.xx.xx.xx_xx.rpm
```
3. Verify the installation.

首先，运行如下命令，查看rpm包是否安装成功；
```bash
rpm -qa | grep vastai_pci
```
```bash
#output
vastai_pci-00.00.00.00-1dkms.x86_64
```

然后，运行如下命令查看驱动是否已加载到内核。
```bash
lsmod | grep vastai_pci
```
```bash
#output
vastai_pci        xxx  x
```

(注意：SV100加速卡需插入服务器，否则驱动无法加载到内核。)


## 5. 升级驱动

### 5.1 Ubuntu Upgrade

```bash
sudo dpkg -i vastai-pci_dkms_xx.xx.xx.xx_xx.deb
```

### 5.2 CentOS Upgrade

```bash
#升级到新版本
sudo rpm -U vastai-pci_dkms_xx.xx.xx.xx_xx.rpm
#更新到老版本
sudo rpm -U --oldpackage vastai-pci_dkms_xx.xx.xx.xx_xx.rpm
#重新安装相同版本(分两步)
sudo rpm -e vastai-pci_dkms_xx.xx.xx.xx_xx.rpm
sudo rpm -i vastai-pci_dkms_xx.xx.xx.xx_xx.rpm
```

## 6. 卸载驱动

### 6.1 Ubuntu

```bash
#查询安装包名字
dpkg -l | grep vastai
#卸载安装包
sudo dpkg -r vastai-pci-dkms
```

### 6.2 CentOS

```bash
#查询安装包名字
rpm -qa | grep vastai
#卸载安装包
sudo rpm -e vastai-pci_dkms_xx.xx.xx.xx_xx
```
## 7. PCIe tar驱动源码安装包

### 7.1 环境准备
请检查下列环境及版本要求是否已经安装：

- gcc
- linux-header
- make
- tar

### 7.2 解压驱动源码tar包

```bash
tar -zxvf  pcie_XX_XX_XX.tar.gz
#解压完成后，会在当前目录生成相关目录，如：
vastai-pci-xx-hwtype-xx.xx.xx.xx
```
### 7.3 编译源码
```bash
#进入源码目录
cd vastai-pci-xx-hwtype-xx.xx.xx.xx
#编译
make
#编译成功后，会在当前目录下生成ko文件，如 vastai_pci.ko
```
### 7.4 安装驱动
```bash
#首先删除原先驱动的firmware文件
cd /lib/firmware
#查看是否存在vastai文件夹
ls vastai
#若存在，则进入该目录，将目录下之前的firmware文件删除
cd vastai
sudo rm -rf *
```
```bash
#安装ko文件
sudo insmod vastai_pci.ko
```
然后，运行如下命令查看驱动是否已加载到内核。
```bash
lsmod | grep vastai_pci
```
```bash
#output
vastai_pci        xxx  x
```

### 7.5 卸载驱动
```bash
#查看驱动是否已加载到内核中
lsmod | grep vastai_pci
```
```bash
#output
vastai_pci        xxx  x
#若最后的x不为0，说明驱动正在被其他程序所占用，无法卸载。此时请检查相关应用程序已全部关闭。
```
```bash
#卸载驱动
sudo rmmod vastai_pci
```
## 8. Troubleshooting

For troubleshooting, please contact us directly.
