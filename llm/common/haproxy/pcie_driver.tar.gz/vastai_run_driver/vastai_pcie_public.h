#ifndef __VASTAI_PCIE_PUBLIC_H__
#define __VASTAI_PCIE_PUBLIC_H__

#define VASTAI_CARD_DEVICE_NAME "vastai_card_hw"

/* Valid values for MEMORY_CONFIG configuration option */
#define VASTAI_MEMORY_LOCAL  (1)
#define VASTAI_MEMORY_HOST   (2)
#define VASTAI_MEMORY_HYBRID (3)

#define VASTAI_CARD_MEMORY_CONFIG VASTAI_MEMORY_LOCAL

#define VASTAI_DMA_TX_CHAN_NAME "vastai_dma_tx"
#define VASTAI_DMA_RX_CHAN_NAME "vastai_dma_rx"

#define COMMON_MSIX_GFX_VECTOR  1


#define VA_GPU_REG_REGION_SIZE 0x7ffff

struct va_platform_data {
	/* The testchip memory mode (LOCAL, HOST or HYBRID) */
	int mem_mode;

	resource_size_t heap_dev_base;

	/* The following is used to setup the services heaps that map to the
	 * ion heaps
	 */
	resource_size_t heap_memory_base;
	resource_size_t heap_memory_size;

	/* DMA channel names for RGX usage */
	char *dma_tx_chan_name;
	char *dma_rx_chan_name;

	resource_size_t display_heap_dev_base;
	resource_size_t display_heap_memory_base;
	resource_size_t display_heap_memory_size;
#if CONFIG_D2H_BY_GART_OR_ATU
	void *vastai_priv;
	int fn_mode;
#endif
};

#endif
