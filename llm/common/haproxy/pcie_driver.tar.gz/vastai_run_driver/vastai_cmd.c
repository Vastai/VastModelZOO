#include "vastai_pci.h"
#include "hw_queue.h"
#include "sg100_gmcu.h"
#include "vastai_cmd.h"
#include "hw_config.h"
#include "vastai_fifo.h"

/**
* @brief host trigger m2o interupt to mcu 
* @param priv 
* @param index 
*/
void host_triger_m2o_int_mcu(struct vastai_pci_info *priv,
							int index)
{
	u64   vf_m2o_int_addr  = 0;
	u32   triger_m2o_int   = 0;
	vf_m2o_int_addr  = priv->ring_buf[index]->vf_m2o_reg_base;
	triger_m2o_int   = 0x80000000 | (1<<0);

	vastai_pci_mem_write(priv, 0, vf_m2o_int_addr, &triger_m2o_int, 4);

	return;
}


static void vastai_ring_buf_init(struct vastai_pci_info *priv,
				int index,char *ring_buf_name)
{
	struct  ring_buf_entry *hw_entry;
	hw_entry = find_hw_cfg_acord_name(priv,ring_buf_name);
	if( NULL != hw_entry ) {
		priv->ring_buf[index] = kzalloc(sizeof(struct ring_buf_info), GFP_KERNEL);
		spin_lock_init(&priv->ring_buf[index]->wr_ring_buf_lock);
		spin_lock_init(&priv->ring_buf[index]->rd_ring_buf_lock);
		priv->ring_buf[index]->ring_buf_base   = hw_entry->ring_buf_base;
		priv->ring_buf[index]->ring_buf_size   = hw_entry->ring_buf_size;
		priv->ring_buf[index]->vf_m2o_reg_base = hw_entry->m2o_reg_base;
		priv->ring_buf[index]->ring_buf_fn_base= 0x800000 +(hw_entry->ring_buf_base - priv->priv_hw_cfg->header.csram_base);
	} else {
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "%s buf init fail\n",ring_buf_name);
	}
	return;
}

/**
 * @brief init all cmd buffer 
 * 
 */
int init_all_ring_buf(struct vastai_pci_info *priv)
{
	if( ONLY_1_PF == priv->fn_mode)	{
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_SMCU_CMD_BUF,   		ONLY_1_PF_HOST_WR_M2O_CMD_SMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_CMCU_CMD_BUF,   		ONLY_1_PF_HOST_WR_M2O_CMD_CMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VEMCU0_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU0_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VEMCU1_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU1_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VEMCU2_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU2_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VEMCU3_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VEMCU3_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VDSP0_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_VDSP0_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VDSP1_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_VDSP1_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_ODSP0_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_ODSP0_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_ODSP1_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_ODSP1_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VDMCU0_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU0_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_VDMCU1_CMD_BUF, 		ONLY_1_PF_HOST_WR_M2O_CMD_VDMCU1_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_GMCU1_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_GMCU1_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_HOST_TO_GMCU3_CMD_BUF,  		ONLY_1_PF_HOST_WR_M2O_CMD_GMCU3_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_SMCU_TO_HOST_INFO_BUF,  		ONLY_1_PF_SMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_CMCU_TO_HOST_INFO_BUF,  		ONLY_1_PF_CMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VEMCU0_TO_HOST_INFO_BUF,		ONLY_1_PF_VEMCU0_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VEMCU1_TO_HOST_INFO_BUF,		ONLY_1_PF_VEMCU1_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VEMCU2_TO_HOST_INFO_BUF,		ONLY_1_PF_VEMCU2_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VEMCU3_TO_HOST_INFO_BUF,		ONLY_1_PF_VEMCU3_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VDSP0_TO_HOST_INFO_BUF, 		ONLY_1_PF_VDSP0_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VDSP1_TO_HOST_INFO_BUF, 		ONLY_1_PF_VDSP1_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_ODSP0_TO_HOST_INFO_BUF, 		ONLY_1_PF_ODSP0_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_ODSP1_TO_HOST_INFO_BUF, 		ONLY_1_PF_ODSP1_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VDMCU0_TO_HOST_INFO_BUF,		ONLY_1_PF_VDMCU0_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_VDMCU1_TO_HOST_INFO_BUF,		ONLY_1_PF_VDMCU1_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_GMCU1_TO_HOST_INFO_BUF, 		ONLY_1_PF_GMCU1_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_GMCU3_TO_HOST_INFO_BUF, 		ONLY_1_PF_GMCU3_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_DISPLAY_H2D_BUF, 				ONLY_1_PF_DISPLAY_H2D_NAME);
		vastai_ring_buf_init(priv, ONLY_1PF_DISPLAY_D2H_BUF, 				ONLY_1_PF_DISPLAY_D2H_NAME);
	} else if (ONLY_2_PF == priv->fn_mode){
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_SMCU_CMD_BUF,        	ONLY_2_PF_HOST_WR_M2O_CMD_SMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_CMCU_CMD_BUF,        	ONLY_2_PF_HOST_WR_M2O_CMD_CMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_1ST_VEMCU_CMD_BUF,   	ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VEMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_2ND_VEMCU_CMD_BUF,   	ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VEMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_1ST_VDSP_CMD_BUF,    	ONLY_2_PF_HOST_WR_M2O_CMD_1ST_VDSP_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_2ND_VDSP_CMD_BUF,    	ONLY_2_PF_HOST_WR_M2O_CMD_2ND_VDSP_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_VDMCU_CMD_BUF,       	ONLY_2_PF_HOST_WR_M2O_CMD_VDMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_HOST_TO_GMCU_CMD_BUF,        	ONLY_2_PF_HOST_WR_M2O_CMD_GMCU_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_SMCU_TO_HOST_INFO_BUF,       	ONLY_2_PF_SMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_CMCU_TO_HOST_INFO_BUF,       	ONLY_2_PF_CMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_1ST_VEMCU_TO_HOST_INFO_BUF,  	ONLY_2_PF_1ST_VEMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_2ND_VEMCU_TO_HOST_INFO_BUF,  	ONLY_2_PF_2ND_VEMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_1ST_VDSP_TO_HOST_INFO_BUF,   	ONLY_2_PF_1ST_VDSP_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_2ND_VDSP_TO_HOST_INFO_BUF,   	ONLY_2_PF_2ND_VDSP_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_VDMCU_TO_HOST_INFO_BUF,      	ONLY_2_PF_VDMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_GMCU_TO_HOST_INFO_BUF,       	ONLY_2_PF_GMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_DISPLAY_H2D_BUF,       	        ONLY_2_PF_DISPLAY_H2D_NAME);
		vastai_ring_buf_init(priv, ONLY_2PF_DISPLAY_D2H_BUF,       	        ONLY_2_PF_DISPLAY_D2H_NAME);
	} else {
		vastai_ring_buf_init(priv, COMMON_HOST_TO_SMCU_CMD_BUF,   			COMMON_HOST_WR_M2O_CMD_SMCU_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_HOST_TO_CMCU_CMD_BUF,   			COMMON_HOST_WR_M2O_CMD_CMCU_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_HOST_TO_VEMCU_CMD_BUF,  			COMMON_HOST_WR_M2O_CMD_VEMCU_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_HOST_TO_VDSP_CMD_BUF,   			COMMON_HOST_WR_M2O_CMD_VDSP_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_HOST_TO_VDMCU_CMD_BUF,  			COMMON_HOST_WR_M2O_CMD_VDMCU_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_HOST_TO_GMCU_CMD_BUF,   			COMMON_HOST_WR_M2O_CMD_GMCU_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_SMCU_TO_HOST_INFO_BUF,  			COMMON_SMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_CMCU_TO_HOST_INFO_BUF,  			COMMON_CMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_VEMCU_TO_HOST_INFO_BUF,			COMMON_VEMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_VDSP_TO_HOST_INFO_BUF,  			COMMON_VDSP_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_VDMCU_TO_HOST_INFO_BUF, 			COMMON_VDMCU_WR_MSIX_INFO_HOST_RD_NAME);
		vastai_ring_buf_init(priv, COMMON_GMCU_TO_HOST_INFO_BUF,  			COMMON_GMCU_WR_MSIX_INFO_HOST_RD_NAME);
		
	}	
			
	return 0;
}

struct vastai_cmd_entry *get_cmd_entry(struct vastai_pci_info *priv,
									   int cmd_buf_type)
{
	if(NULL == priv->cmd_entrys[cmd_buf_type]){
		VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID, "m2o_cmd_smcu buf init fail\n");
		return NULL;
	}
	return priv->cmd_entrys[cmd_buf_type];
}

int h2d_cmd_buf_deinit(struct vastai_pci_info *priv)
{
	int i;
	for(i=0; i<CMD_BUF_MAX; i++){
		if(NULL!=priv->cmd_entrys[i]){
			kfree(priv->cmd_entrys[i]->hw_msgq);
			kfree(priv->cmd_entrys[i]);
		}		
	}
	return 0;
}

/*==================== DMA transfer && MSG api ====================*/
/* Don't call this function at irq, This only use spin_lock */
int vastai_pci_send_msg_pid_sg(void *pcie_dev, int die_index,
			int index, void *msg_buf, u32 msg_len, pid_t pid)
{
	int ret = 0;
	struct vastai_pci_info *priv=pcie_dev;
	u64   vf_m2o_int_addr  = 0;
	u64   msg_addr         = 0;
	u32   triger_m2o_int   = 0;
	unsigned long flags;

	if(NULL == priv->ring_buf[index]){
		return -1;
	}

	vf_m2o_int_addr  = priv->ring_buf[index]->vf_m2o_reg_base;
	msg_addr         = priv->ring_buf[index]->ring_buf_base;
	triger_m2o_int   = 0x80000000 | (1<<0);

	spin_lock_irqsave(&priv->ring_buf[index]->wr_ring_buf_lock, flags);

	ret = vastai_fifo_push_elem(priv, die_index, msg_addr, msg_buf, NULL);
	vastai_pci_mem_write(priv, 0, vf_m2o_int_addr, &triger_m2o_int, 4);

	spin_unlock_irqrestore(&priv->ring_buf[index]->wr_ring_buf_lock, flags);

	return ret;
}

int vastai_pci_send_msg(void *pcie_dev, int die_index,
			int index, void *msg_buf, u32 msg_len)
{
	return vastai_pci_send_msg_pid_sg(pcie_dev, die_index,
				index, msg_buf, msg_len, -1);

}

int vastai_pci_receive_msg(void *pcie_dev, int die_index,
			int index, void *elem)
{
	struct vastai_pci_info *priv=pcie_dev;
	u64 msg_addr   = priv->ring_buf[index]->ring_buf_base;
	unsigned long flags;
	int ret;
	spin_lock_irqsave(&priv->ring_buf[index]->rd_ring_buf_lock, flags);

	ret = vastai_fifo_pop_elem(pcie_dev, die_index, msg_addr,elem, NULL, NORMAL_FIFO);

	spin_unlock_irqrestore(&priv->ring_buf[index]->rd_ring_buf_lock, flags);

	return	ret;
}

