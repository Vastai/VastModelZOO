#!/usr/bin/env python3
import struct
import os
import sys
import shutil

out_bin_name='../vastai_fw.bin'
file_path='./'

tmp_file_path=file_path+'tmp/'

class item:
    def __init__(self):
        self.file_name=''
        self.image_type=0
        self.startAddr=0
        self.image_len=0
        self.offset=0


head=[           item(),     item(),    item(),    item(),      item(),     item(),    item(),     item(),      item(),        item()]
list_keyword=[  'smcu',     'cmcu',     'lmcu',    'gmcu',      'vemcu',   'odsp',     'vdsp',     'pmcu',      'vdmcu']
#   img_type:   fw = 2
#   core_type:  1           2           3           4           5           6           7           8           9
#   sub_core:   0           0           2           4           4           2           2           0           4
list_type=[     0x21000000, 0x22000000, 0x23030000, 0x240f0000, 0x250f0000, 0x26030000, 0x27030000, 0x28000000, 0x290f0000,    0x20010000]
list_startAddr=[0x0000000,  0x200000,   0x400000,   0x800000,   0x1800000,  0x3800000,  0x4800000,  0x6800000,  0x800000,      0x40000000]
list_offset=[   0x0,        0x0,        0x2000,     0x4000,     0x8000,     0x8000,     0x8000,     0x0,        0x4000,        0x0]

def set_head_type():
    for i in range(len(list_type)-1):
        head[i+1].image_type = list_type[i]
        # print(hex(head[i+1].image_type))
    head[0].image_type = list_type[-1]

def set_head_startAddr():
    for i in range(len(list_type)-1):
        head[i+1].startAddr = list_startAddr[i]
    head[0].startAddr=list_startAddr[-1]

def set_head_offset():
    for i in range(len(list_type)-1):
        head[i+1].offset = list_offset[i]
    head[0].offset=list_offset[-1]

if(os.path.exists(out_bin_name)):
    os.remove(out_bin_name)

if os.path.exists(tmp_file_path):
    shutil.rmtree(tmp_file_path)
os.mkdir(tmp_file_path)

def file_filter(f):
    if f[-4:] in ['.bin']:
        return True
    else:
        return False

list_fileName = os.listdir(file_path)
list_fileName = list(filter(file_filter,list_fileName))

def get_bin_file_size(keyword):
    file_path1=tmp_file_path
    for i in list_fileName:
        if keyword in i:
            return os.path.getsize(file_path1+i)
    print("WARN: %s.bin not exist"%keyword)
    return 0

def get_bin_file_name(keyword):
    cnt=0
    for i in list_fileName:
        if keyword in i:
            return list_fileName[cnt]
        cnt=cnt+1

def copy_bin_to_tmp():
    for i in range(len(list_keyword)):
        if head[i+1].file_name is not None:
            print(head[i+1].file_name)
            shutil.copy(file_path+head[i+1].file_name,tmp_file_path)

def byte_16_align():
    file_path1=tmp_file_path
    for i in range(len(list_keyword)):
        if head[i+1].file_name is not None:
            read_bin_size=os.path.getsize(file_path1+head[i+1].file_name)
            if read_bin_size % 16 != 0:
                read_bin=open(file_path1+head[i+1].file_name,'ab+')
                for i in range(16-(read_bin_size%16)):
                    read_bin.write(struct.pack('B',0x00))
                read_bin.close()

def set_head():
    set_head_type()
    set_head_startAddr()
    cnt=0
    for i in list_keyword:
        head[cnt + 1].file_name = get_bin_file_name(i)
        # print(head[cnt+1].file_name,head[cnt+1].image_len)
        cnt=cnt+1

    copy_bin_to_tmp()
    byte_16_align()

    cnt=0
    for i in list_keyword:
        head[cnt + 1].image_len = get_bin_file_size(i)
        cnt=cnt+1

    head[0].image_len = (len(list_type))*4*4
    for i in range(len(list_keyword)):
        head[0].image_len = head[0].image_len + head[i+1].image_len

    set_head_offset()

out_bin = open(file_path+out_bin_name,'wb')

def write_head_to_outBin(i):
    # print(hex(head[i].image_type))
    out_bin.write(struct.pack('I',head[i].image_type))
    out_bin.write(struct.pack('I',head[i].startAddr))
    out_bin.write(struct.pack('I',head[i].image_len))
    out_bin.write(struct.pack('I',head[i].offset))


def merge_bin_with_head():
    file_path1=tmp_file_path
    write_head_to_outBin(0)
    for i in range(len(list_keyword)):
        write_head_to_outBin(i+1)
        if head[i+1].file_name is not None:
            read_bin=open(file_path1+head[i+1].file_name,'rb+')
            # print(head[i+1].file_name)
            read_bin_size=os.path.getsize(file_path1+head[i+1].file_name)
            data=read_bin.read(read_bin_size)
            out_bin.write(data)
            read_bin.close()
    out_bin.close()


if __name__ == '__main__':
    set_head()
    merge_bin_with_head()
    shutil.rmtree(tmp_file_path)
    print("bin merge ok !!!")
