#!/usr/bin/env python3
import struct
import os
import sys
import shutil

out_bin_name='../vastai_fw.bin'
file_path='./'

tmp_file_path=file_path+'tmp/'

list_keyword=['vdsp','vemcu','vdmcu','odsp','lmcu','cmcu','smcu','common_boot']

class item:
    def __init__(self):
        self.file_name=''
        self.image_type=0
        self.startAddr=0
        self.image_len=0
        self.offset=0

head          =[item(),    item(),    item(),    item(),    item(),    item(),    item(),    item(),        item()]
#list_keyword =['vdsp',    'vemcu',   'vdmcu',   'odsp',    'lmcu',    'cmcu',    'smcu',    'common_boot']
list_type     =[0x290f0000,0x280f0000,0x27070000,0x26ff0000,0x25ff0000,0x24000000,0x23000000,0x22000000,    0x20010000]
list_startAddr=[0x0b000000,0x09000000,0x07800000,0x02800000,0x00800000,0x00400000,0x00000000,0xc0000000,    0x40000000]
list_offset   =[0x00008000,0x00008000,0x00008000,0x00008000,0x00004000,0x0,       0x0,       0x0,           0x0]

def set_head_type():
    for i in range(len(list_type)-1):
        head[i+1].image_type = list_type[i]
        # print(hex(head[i+1].image_type))
    head[0].image_type = list_type[-1]

def set_head_startAddr():
    for i in range(len(list_type)-1):
        head[i+1].startAddr = list_startAddr[i]
    head[0].startAddr=list_startAddr[-1]

def set_head_offset():
    for i in range(len(list_type)-1):
        head[i+1].offset = list_offset[i]
    head[0].offset=list_offset[-1]

if(os.path.exists(out_bin_name)):
    os.remove(out_bin_name)

if os.path.exists(tmp_file_path):
    shutil.rmtree(tmp_file_path)
os.mkdir(tmp_file_path)

def file_filter(f):
    if f[-4:] in ['.bin']:
        return True
    else:
        return False

list_fileName = os.listdir(file_path)
list_fileName = list(filter(file_filter,list_fileName))

def get_bin_file_size(keyword):
    file_path1=tmp_file_path
    for i in list_fileName:
        if keyword in i:
            return os.path.getsize(file_path1+i)
    print("WARN: %s.bin not exist"%keyword)
    return 0

def get_bin_file_name(keyword):
    cnt=0
    first_match_flag=0
    first_match_cnt=0
    for i in list_fileName:
        if keyword in i:
            if first_match_flag==1:
                print("WARN: %s.bin has more than one, python don't know choose which one, pls keep only one %s.bin!!!!"%(keyword,keyword))
                print("WARN: repeat %s.bin list : %s %s"%(keyword,list_fileName[first_match_cnt],list_fileName[cnt]))
                return 0
            if first_match_flag==0:
                first_match_flag=1
                first_match_cnt=cnt
        cnt=cnt+1
    if first_match_flag==1:
        return list_fileName[first_match_cnt]

def copy_bin_to_tmp():
    for i in range(len(list_keyword)):
        if head[i+1].file_name is not None:
            print(head[i+1].file_name)
            shutil.copy(file_path+head[i+1].file_name,tmp_file_path)

def byte_16_align():
    file_path1=tmp_file_path
    for i in range(len(list_keyword)):
        if head[i+1].file_name is not None:
            read_bin_size=os.path.getsize(file_path1+head[i+1].file_name)
            if read_bin_size % 16 != 0:
                read_bin=open(file_path1+head[i+1].file_name,'ab+')
                for i in range(16-(read_bin_size%16)):
                    read_bin.write(struct.pack('B',0x00))
                read_bin.close()
        

def set_head():
    set_head_type()
    set_head_startAddr()
    cnt=0
    for i in list_keyword:
        head[cnt + 1].file_name = get_bin_file_name(i)
        # print(head[cnt+1].file_name,head[cnt+1].image_len)
        cnt=cnt+1

    copy_bin_to_tmp()
    byte_16_align()

    cnt=0
    for i in list_keyword:
        head[cnt + 1].image_len = get_bin_file_size(i)
        cnt=cnt+1


    head[0].image_len = (len(list_type))*4*4
    for i in range(len(list_keyword)):
        head[0].image_len = head[0].image_len + head[i+1].image_len

    set_head_offset()

out_bin = open(file_path+out_bin_name,'wb')

def write_head_to_outBin(i):
    # print(hex(head[i].image_type))
    out_bin.write(struct.pack('I',head[i].image_type))
    out_bin.write(struct.pack('I',head[i].startAddr))
    out_bin.write(struct.pack('I',head[i].image_len))
    out_bin.write(struct.pack('I',head[i].offset))


def merge_bin_with_head():
    file_path1=tmp_file_path
    write_head_to_outBin(0)
    for i in range(len(list_keyword)):
        write_head_to_outBin(i+1)
        if head[i+1].file_name is not None:
            read_bin=open(file_path1+head[i+1].file_name,'rb+')
            # print(head[i+1].file_name)
            read_bin_size=os.path.getsize(file_path1+head[i+1].file_name)
            data=read_bin.read(read_bin_size)
            out_bin.write(data)
            read_bin.close()
    out_bin.close()


if __name__ == '__main__':
    set_head()
    merge_bin_with_head()
    shutil.rmtree(tmp_file_path)
    print("bin merge ok !!!")
