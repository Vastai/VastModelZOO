#include <linux/platform_device.h>

#include "vastai_pci.h"
#include "hw_config.h"
#include "gfx_drv.h"
#include "../ep_driver/hw/va_dma_core.h"
#include "../vastai_pcie_public.h"

static int g_dsu_ring_buf_index;

void *va_dma_get_byname(struct device *dev, char *name);
int va_register_display_interrupt(struct device *dev,
				void (*handler_function)(void *), void *arg);
int va_unregister_display_interrupt(struct device *dev);
int va_get_display_irq_data(struct device *dev, void *irq_data);
int va_register_gpu_interrupt(struct device *dev, int interrupt_id,
				void (*handler_function)(void *), void *data);
int va_unregister_gpu_interrupt(struct device *dev, int interrupt_id);
int va_enable_gpu_interrupt(struct device *dev, int interrupt_id);
int va_disable_gpu_interrupt(struct device *dev, int interrupt_id);

void *va_dma_get_byname(struct device *dev, char *name)
{
	va_dma_t *dma;
	struct vastai_pci_info *priv = dev_get_drvdata(dev);

	dma = va_dma_alloc(priv, 0, VA_DMA_ATTR_DIR_MEM_TO_DEV |
			      VA_DMA_ATTR_DIR_DEV_TO_MEM);
	if (!dma) {
		VASTAI_PCI_ERR(priv, 0,
				"%s: dma alloc failed\n", __func__);
		return NULL;
	}

	return dma;
}
EXPORT_SYMBOL(va_dma_get_byname);

/* display driver register irq interface */
int va_register_display_interrupt(struct device *dev,
	void (*handler_function)(void *),
	void *arg)
{
	int ret;
	struct vastai_pci_info *priv = dev_get_drvdata(dev);

	if (1 != priv->priv_hw_cfg->sys_cfg.dp_en)
		return -EIO;

	VASTAI_PCI_INFO(priv, DUMMY_DIE_ID, "%s\n", __func__);

	switch (priv->priv_hw_cfg->sys_cfg.fn_mode)
	{
		case ONLY_1_PF:
			ret = va_register_pcie_interrupt(priv, ONLY_1_PF_MSIX_DSU_VECTOR, handler_function, arg);
			g_dsu_ring_buf_index = ONLY_1PF_DISPLAY_D2H_BUF;
			break;
		
		case ONLY_2_PF:
			ret = va_register_pcie_interrupt(priv, ONLY_2_PF_MSIX_DSU_VECTOR, handler_function, arg);
			g_dsu_ring_buf_index = ONLY_2PF_DISPLAY_D2H_BUF;
			break;

		default:
			ret = -EIO;
			break;
	}
	if (ret) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID, "%s: va_register_pcie_interrupt() fail!, %d\n", __func__, ret);
		ret = -EIO;
	}

	return ret;
}
EXPORT_SYMBOL(va_register_display_interrupt);

int va_unregister_display_interrupt(struct device *dev)
{
	int ret;
	struct vastai_pci_info *priv = dev_get_drvdata(dev);

	switch (priv->priv_hw_cfg->sys_cfg.fn_mode)
	{
		case ONLY_1_PF:
			ret = va_unregister_pcie_interrupt(priv, ONLY_1_PF_MSIX_DSU_VECTOR);
			break;
		
		case ONLY_2_PF:
			ret = va_unregister_pcie_interrupt(priv, ONLY_2_PF_MSIX_DSU_VECTOR);
			break;

		default:
			ret = -EIO;
			break;
	}

	return ret;
}
EXPORT_SYMBOL(va_unregister_display_interrupt);

/* display driver fetch irq_msg interface */
int va_get_display_irq_data(struct device *dev, void *irq_data)
{
	int ret;
	struct vastai_pci_info *priv = dev_get_drvdata(dev);
	struct vdm_irq_data *irq_msg = (struct vdm_irq_data *) irq_data;

	ret = vastai_pci_receive_msg(priv, 0, g_dsu_ring_buf_index, irq_msg);

	return ret;
}
EXPORT_SYMBOL(va_get_display_irq_data);

int va_register_gpu_interrupt(struct device *dev, int interrupt_id,
			      void (*handler_function)(void *), void *data)
{
	struct vastai_pci_info *priv = dev_get_drvdata(dev);

	return va_register_pcie_interrupt(priv, interrupt_id,
					handler_function, data);
}
EXPORT_SYMBOL(va_register_gpu_interrupt);

int va_unregister_gpu_interrupt(struct device *dev, int interrupt_id)
{
	struct vastai_pci_info *priv = dev_get_drvdata(dev);

	return va_unregister_pcie_interrupt(priv, interrupt_id);
}
EXPORT_SYMBOL(va_unregister_gpu_interrupt);

int va_enable_gpu_interrupt(struct device *dev, int interrupt_id)
{
	(void)dev;
	(void)interrupt_id;

	return 0;
}
EXPORT_SYMBOL(va_enable_gpu_interrupt);

int va_disable_gpu_interrupt(struct device *dev, int interrupt_id)
{
	(void)dev;
	(void)interrupt_id;

	return 0;
}
EXPORT_SYMBOL(va_disable_gpu_interrupt);

struct tc_pdp_platform_data {
//#if defined(SUPPORT_ION) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 12, 0))
//	struct ion_device *ion_device;
//	int ion_heap_id;
//#endif
	resource_size_t memory_base;

	/* The following is used by the drm_pdp driver as it manages the
	 * pdp memory
	 */
	resource_size_t pdp_heap_memory_base;
	resource_size_t pdp_heap_memory_size;

	/* Used to export host address instead of pdp address, depends on the
	 * TC memory mode.
	 *
	 * PDP phys address space is from 0 to end of local device memory,
	 * however if the TC is configured to operate in hybrid mode then the
	 * GPU is configured to match the CPU phys address space view.
	 */
	bool dma_map_export_host_addr;
};

static int va_nulldisp_device_register(struct vastai_pci_info *priv,
				       struct va_gfx_cfg *cfg)
{
	struct pci_dev *pdev = priv->dev;
	int err = 0;
	char name[32];
	struct resource reg_resources[] = {
		DEFINE_RES_MEM_NAMED(pci_resource_start(pdev, cfg->display_reg.bar_num)
					+ cfg->display_reg.bar_offset,
					cfg->display_reg.size, "rogue-dp-regs"),
		DEFINE_RES_MEM_NAMED(pci_resource_start(pdev, cfg->dsu_reg.bar_num)
					+ cfg->dsu_reg.bar_offset,
					cfg->dsu_reg.size, "rogue-dsu-regs"),
	};

	struct tc_pdp_platform_data nulldisp_pdata = {
		.memory_base = pci_resource_start(pdev, cfg->disp_heap.bar_num)
			       + cfg->disp_heap.bar_offset,
		.pdp_heap_memory_base = cfg->disp_heap.dev_paddr,
		.pdp_heap_memory_size = cfg->disp_heap.size,
		.dma_map_export_host_addr = 0,
	};

	struct platform_device_info nulldisp_device_info = {
		.parent     = &pdev->dev,
		.name		= NULL,
		.id		    = -1,
		.res        = reg_resources,
		.num_res    = ARRAY_SIZE(reg_resources),
		.data		= &nulldisp_pdata,
		.size_data	= sizeof(nulldisp_pdata),
		.dma_mask	= DMA_BIT_MASK(64),
	};

	snprintf(name, 32, "sg100_nulldisp_%d", priv->dev_id);
	nulldisp_device_info.name = name;

	if((priv->priv_hw_cfg->sys_cfg.pfn!=0) || priv->is_vf){
		nulldisp_device_info.res = 0;
		nulldisp_device_info.num_res = 0;
	} 
	priv->nulldisp_dev = platform_device_register_full(&nulldisp_device_info);
	if (IS_ERR(priv->nulldisp_dev)) {
		err = PTR_ERR(priv->nulldisp_dev);
		priv->nulldisp_dev = NULL;
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: sg100 nulldisp reg fail (%d)\n",
				__func__, err);
		return -1;
	}

	return 0;
}

//TODO unregister device

static int va_register_card_device(struct vastai_pci_info *priv,
				   struct va_gfx_cfg *cfg)
{
	int err = 0;
	struct pci_dev *pdev = priv->dev;

	//FIXME: reg addr, used by ddk
	struct resource gpu_reg_resources[] = {
		DEFINE_RES_MEM_NAMED(pci_resource_start(pdev, cfg->regs.bar_num)
					+ cfg->regs.bar_offset,
					cfg->regs.size, "rogue-regs"),
	};

	struct va_platform_data pdata = {
		.mem_mode = VASTAI_CARD_MEMORY_CONFIG,

		.heap_dev_base = cfg->gfx_heap.dev_paddr,
		.heap_memory_base
			 = pci_resource_start(pdev, cfg->gfx_heap.bar_num)
			   + cfg->gfx_heap.bar_offset,
		.heap_memory_size = cfg->gfx_heap.size,

		.dma_tx_chan_name = VASTAI_DMA_TX_CHAN_NAME,
		.dma_rx_chan_name = VASTAI_DMA_RX_CHAN_NAME,

		.display_heap_dev_base = cfg->disp_heap.dev_paddr,
		.display_heap_memory_base
			 = pci_resource_start(pdev, cfg->disp_heap.bar_num)
			   + cfg->disp_heap.bar_offset,
		.display_heap_memory_size = cfg->disp_heap.size,
#if CONFIG_D2H_BY_GART_OR_ATU
		.vastai_priv = (void *)priv,
		.fn_mode = priv->fn_mode,
#endif
	};

	struct platform_device_info dev_info = {
		.parent = &pdev->dev,
		.name = VASTAI_CARD_DEVICE_NAME,
		.id = priv->dev_id,
		.res = gpu_reg_resources,
		.num_res = ARRAY_SIZE(gpu_reg_resources),
		.data = &pdata,
		.size_data = sizeof(pdata),
		.dma_mask = DMA_BIT_MASK(64),
	};

	err = arch_io_reserve_memtype_wc(pdata.heap_memory_base,
									 pci_resource_len(pdev, cfg->gfx_heap.bar_num) - cfg->gfx_heap.bar_offset);
	if (err) {
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"%s: set pat fail (%d)\n", __func__, err);
	}
	if (arch_phys_wc_add(pdata.heap_memory_base,
			     pdata.heap_memory_size) < 0) {
		arch_io_free_memtype_wc(pdata.heap_memory_base,
					pdata.heap_memory_size);
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
			       "%s: enable mtrr fail (%d)\n", __func__, err);
	}

	priv->gfx_card_dev = platform_device_register_full(&dev_info);

	if (IS_ERR(priv->gfx_card_dev)) {
		err = PTR_ERR(priv->gfx_card_dev);
		VASTAI_PCI_ERR(priv, DUMMY_DIE_ID,
				"Failed to register gpu card device (%d)\n", err);
	}

	VASTAI_PCI_INFO(NULL, DUMMY_DIE_ID,
			"register gpu card device done\n");

	return err;
}

int va_pcie_ddk_init(struct vastai_pci_info *priv, struct va_gfx_cfg *cfg)
{
	int ret = 0;
	ret = va_nulldisp_device_register(priv, cfg);
	if (ret)
		return ret;

	ret = va_register_card_device(priv, cfg);
	if (ret)
		return ret;

	return 0;
}

int va_pcie_ddk_deinit(struct vastai_pci_info *priv)
{
	if (priv->nulldisp_dev) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"platform_device_unregister nulldisp_dev\n");
		platform_device_unregister(priv->nulldisp_dev);
	}

	if (priv->gfx_card_dev) {
		VASTAI_PCI_INFO(priv, DUMMY_DIE_ID,
				"platform_device_unregister gfx_card_dev\n");
		platform_device_unregister(priv->gfx_card_dev);
	}

	return 0;
}

void va_install_physheap_alloc_func(void *priv, void *alloc)
{
	struct vastai_pci_info  *pci_info = (struct vastai_pci_info *)priv;
	pci_info->alloc = (alloc_physmem_by_ddk)alloc;
}
EXPORT_SYMBOL(va_install_physheap_alloc_func);

void va_install_physheap_free_func(void *priv, void *free)
{
	struct vastai_pci_info  *pci_info = (struct vastai_pci_info *)priv;
	pci_info->free = (free_physmem_by_ddk)free;
}
EXPORT_SYMBOL(va_install_physheap_free_func);

void va_install_pvr_devnode(void *priv, void *dev_node)
{
	struct vastai_pci_info  *pci_info = (struct vastai_pci_info *)priv;
	pci_info->ddk_node = dev_node;
}
EXPORT_SYMBOL(va_install_pvr_devnode);

#if CONFIG_D2H_BY_GART_OR_ATU
void RegisterGfxMMCallBack(void *priv, void *heapPtr, u64 (*alloc)(void *, int), void (*free)(void *, u64))
{
	struct vastai_pci_info *devInfo = (struct vastai_pci_info *)priv;
	devInfo->hasInitGfxMemAlloc = true;
	devInfo->heapPtr = heapPtr;
	devInfo->AllocMemFromGfxHeap = alloc;
	devInfo->FreeMemToGfxHeap    = free;
	return;
}
EXPORT_SYMBOL(RegisterGfxMMCallBack);
#endif
