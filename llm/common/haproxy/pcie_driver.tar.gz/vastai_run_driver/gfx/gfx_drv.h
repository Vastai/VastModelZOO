#ifndef __GFX_DRV_H__
#define __GFX_DRV_H__

#include "../ep_driver/hw/va_hw_init.h"
struct va_addr_region {
	u32 bar_num;
	u64 bar_offset;
	u64 dev_paddr;
	u64 size;
};

#define VA_ADDR_REGION(_bar_num, _bar_offset, _dev_paddr, _size) {	\
	.bar_num = _bar_num,						\
	.bar_offset = _bar_offset,					\
	.dev_paddr = _dev_paddr,					\
	.size = _size,							\
}

struct va_gfx_cfg {
	struct va_dev_owner owner;

	/* rogue-regs */
	struct va_addr_region regs;
	/* gfx heap */
	struct va_addr_region gfx_heap;
	/* display heap */
	struct va_addr_region disp_heap;
	struct va_addr_region display_reg;
	struct va_addr_region dsu_reg;
};

int va_pcie_ddk_init(struct vastai_pci_info *priv, struct va_gfx_cfg *cfg);
int va_pcie_ddk_deinit(struct vastai_pci_info *priv);
void va_install_physheap_alloc_func(void *priv, void *alloc);
void va_install_physheap_free_func(void *priv, void *free);
void va_install_pvr_devnode(void *priv, void *dev_node);

#if CONFIG_D2H_BY_GART_OR_ATU
void RegisterGfxMMCallBack(void *priv, void *heapPtr, u64 (*alloc)(void *, int), void (*free)(void *, u64));
#endif

#endif
